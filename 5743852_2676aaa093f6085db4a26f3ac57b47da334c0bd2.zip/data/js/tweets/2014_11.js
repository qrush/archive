Grailbird.data.tweets_2014_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jenn",
      "screen_name" : "jennschiffer",
      "indices" : [ 0, 13 ],
      "id_str" : "12524622",
      "id" : 12524622
    }, {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 14, 21 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539278419348185088",
  "geo" : { },
  "id_str" : "539278574365474818",
  "in_reply_to_user_id" : 12524622,
  "text" : "@jennschiffer @wycats i KNEW IT",
  "id" : 539278574365474818,
  "in_reply_to_status_id" : 539278419348185088,
  "created_at" : "2014-12-01 04:43:26 +0000",
  "in_reply_to_screen_name" : "jennschiffer",
  "in_reply_to_user_id_str" : "12524622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/Nr6SdJnprt",
      "expanded_url" : "http:\/\/i.imgur.com\/0XckhzK.png",
      "display_url" : "i.imgur.com\/0XckhzK.png"
    } ]
  },
  "geo" : { },
  "id_str" : "539260823533662208",
  "text" : "Basically how the new Smash Bros has been so far http:\/\/t.co\/Nr6SdJnprt",
  "id" : 539260823533662208,
  "created_at" : "2014-12-01 03:32:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/umpt1vMjPH",
      "expanded_url" : "http:\/\/www.exurbe.com\/?p=2219",
      "display_url" : "exurbe.com\/?p=2219"
    } ]
  },
  "geo" : { },
  "id_str" : "539259833262678017",
  "text" : "What a fun read. I am happy to live in a city with yet an inch of these miles of history: http:\/\/t.co\/umpt1vMjPH",
  "id" : 539259833262678017,
  "created_at" : "2014-12-01 03:28:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/hV9s9D97vd",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=2eBibggCibE",
      "display_url" : "youtube.com\/watch?v=2eBibg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539243587414663169",
  "text" : "Deleting tests and listening to the Tahoe Tweezer. Pretty alright. https:\/\/t.co\/hV9s9D97vd",
  "id" : 539243587414663169,
  "created_at" : "2014-12-01 02:24:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex McHale",
      "screen_name" : "alexmchale",
      "indices" : [ 0, 11 ],
      "id_str" : "13964832",
      "id" : 13964832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539237718589329408",
  "geo" : { },
  "id_str" : "539238110031147008",
  "in_reply_to_user_id" : 13964832,
  "text" : "@alexmchale because it's a fun constraint, and why not?",
  "id" : 539238110031147008,
  "in_reply_to_status_id" : 539237718589329408,
  "created_at" : "2014-12-01 02:02:38 +0000",
  "in_reply_to_screen_name" : "alexmchale",
  "in_reply_to_user_id_str" : "13964832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    }, {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 13, 23 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539234499541086208",
  "geo" : { },
  "id_str" : "539235657621585921",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv @ngauthier i don't have a need for this with minecraft, using my finger sausages is enough. maybe if we ever get to capacity.",
  "id" : 539235657621585921,
  "in_reply_to_status_id" : 539234499541086208,
  "created_at" : "2014-12-01 01:52:53 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 0, 12 ],
      "id_str" : "156708162",
      "id" : 156708162
    }, {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 48, 57 ],
      "id_str" : "148198686",
      "id" : 148198686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539225573630148609",
  "geo" : { },
  "id_str" : "539233171213021184",
  "in_reply_to_user_id" : 156708162,
  "text" : "@barelyknown one of the cheaper gTLDs to buy on @dnsimple, probably a good thing",
  "id" : 539233171213021184,
  "in_reply_to_status_id" : 539225573630148609,
  "created_at" : "2014-12-01 01:43:01 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539223525576679424",
  "geo" : { },
  "id_str" : "539224963815714818",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier i just dont see what that gets us over the ingame chat. meant to be as vanilla as possible :)",
  "id" : 539224963815714818,
  "in_reply_to_status_id" : 539223525576679424,
  "created_at" : "2014-12-01 01:10:24 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539223525576679424",
  "geo" : { },
  "id_str" : "539224685020332034",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier why?",
  "id" : 539224685020332034,
  "in_reply_to_status_id" : 539223525576679424,
  "created_at" : "2014-12-01 01:09:17 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wellington Cordeiro",
      "screen_name" : "wldcordeiro",
      "indices" : [ 0, 12 ],
      "id_str" : "7244302",
      "id" : 7244302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539215878970441728",
  "geo" : { },
  "id_str" : "539220687496286208",
  "in_reply_to_user_id" : 7244302,
  "text" : "@wldcordeiro yeah i watched some guy's youtube videos talking about how to survive there. that's crazy.",
  "id" : 539220687496286208,
  "in_reply_to_status_id" : 539215878970441728,
  "created_at" : "2014-12-01 00:53:24 +0000",
  "in_reply_to_screen_name" : "wldcordeiro",
  "in_reply_to_user_id_str" : "7244302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/biwDqI2DUP",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "539216850454724608",
  "text" : "Clarifying terms on http:\/\/t.co\/biwDqI2DUP: donations not required to play, but are welcome.",
  "id" : 539216850454724608,
  "created_at" : "2014-12-01 00:38:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/0kEncK5VQZ",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/Buffalo\/comments\/2nsym5\/any_places_around_buffalo_accept_bitcoin\/cmgr0zc",
      "display_url" : "reddit.com\/r\/Buffalo\/comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539213021420077056",
  "text" : "Actual laugh out louding at someone asking a bartender at the Pink if they take bitcoin http:\/\/t.co\/0kEncK5VQZ",
  "id" : 539213021420077056,
  "created_at" : "2014-12-01 00:22:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wellington Cordeiro",
      "screen_name" : "wldcordeiro",
      "indices" : [ 0, 12 ],
      "id_str" : "7244302",
      "id" : 7244302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539210073726144512",
  "geo" : { },
  "id_str" : "539210130173091840",
  "in_reply_to_user_id" : 7244302,
  "text" : "@wldcordeiro Vanilla survival",
  "id" : 539210130173091840,
  "in_reply_to_status_id" : 539210073726144512,
  "created_at" : "2014-12-01 00:11:27 +0000",
  "in_reply_to_screen_name" : "wldcordeiro",
  "in_reply_to_user_id_str" : "7244302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/biwDqI2DUP",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "539209758096375809",
  "text" : "Say hello to http:\/\/t.co\/biwDqI2DUP. Weekend-only Minecraft. Donate anything to play, excess donations over server cost goes to charity.",
  "id" : 539209758096375809,
  "created_at" : "2014-12-01 00:09:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Friebel",
      "screen_name" : "freebly",
      "indices" : [ 0, 8 ],
      "id_str" : "201948826",
      "id" : 201948826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539202235867992064",
  "geo" : { },
  "id_str" : "539202805903286272",
  "in_reply_to_user_id" : 201948826,
  "text" : "@freebly I like the time constraints. You can play any server anytime.",
  "id" : 539202805903286272,
  "in_reply_to_status_id" : 539202235867992064,
  "created_at" : "2014-11-30 23:42:21 +0000",
  "in_reply_to_screen_name" : "freebly",
  "in_reply_to_user_id_str" : "201948826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539197030644465664",
  "text" : "First home made banh mi a success. Fresh jalape\u00F1os and Brooklyn Brine's Damn Spicy pickles make it.",
  "id" : 539197030644465664,
  "created_at" : "2014-11-30 23:19:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B-McC",
      "screen_name" : "BeeMickSee",
      "indices" : [ 3, 14 ],
      "id_str" : "44134863",
      "id" : 44134863
    }, {
      "name" : "Jinxso",
      "screen_name" : "JinxsoMc",
      "indices" : [ 70, 79 ],
      "id_str" : "363507905",
      "id" : 363507905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/w0KlyWYyVL",
      "expanded_url" : "http:\/\/youtu.be\/v93Jh6JNBng",
      "display_url" : "youtu.be\/v93Jh6JNBng"
    } ]
  },
  "geo" : { },
  "id_str" : "539141854764077057",
  "text" : "RT @BeeMickSee: The Force Awakens, George Lucas' Special Edition (via @JinxsoMc) http:\/\/t.co\/w0KlyWYyVL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jinxso",
        "screen_name" : "JinxsoMc",
        "indices" : [ 54, 63 ],
        "id_str" : "363507905",
        "id" : 363507905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/w0KlyWYyVL",
        "expanded_url" : "http:\/\/youtu.be\/v93Jh6JNBng",
        "display_url" : "youtu.be\/v93Jh6JNBng"
      } ]
    },
    "geo" : { },
    "id_str" : "539066813909569536",
    "text" : "The Force Awakens, George Lucas' Special Edition (via @JinxsoMc) http:\/\/t.co\/w0KlyWYyVL",
    "id" : 539066813909569536,
    "created_at" : "2014-11-30 14:41:58 +0000",
    "user" : {
      "name" : "B-McC",
      "screen_name" : "BeeMickSee",
      "protected" : false,
      "id_str" : "44134863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545353037905027072\/j1MbnG14_normal.jpeg",
      "id" : 44134863,
      "verified" : false
    }
  },
  "id" : 539141854764077057,
  "created_at" : "2014-11-30 19:40:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 41, 53 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539141219629006850",
  "text" : "Well the verdict is in: 1 year old loves @whereslloyd rice bowls. Chip off the block.",
  "id" : 539141219629006850,
  "created_at" : "2014-11-30 19:37:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Kehn",
      "screen_name" : "joshkehn",
      "indices" : [ 0, 9 ],
      "id_str" : "261821011",
      "id" : 261821011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539140808008810500",
  "geo" : { },
  "id_str" : "539140929790038017",
  "in_reply_to_user_id" : 261821011,
  "text" : "@joshkehn weird. Well there is a update in review, hopefully will help!",
  "id" : 539140929790038017,
  "in_reply_to_status_id" : 539140808008810500,
  "created_at" : "2014-11-30 19:36:29 +0000",
  "in_reply_to_screen_name" : "joshkehn",
  "in_reply_to_user_id_str" : "261821011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Kehn",
      "screen_name" : "joshkehn",
      "indices" : [ 0, 9 ],
      "id_str" : "261821011",
      "id" : 261821011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539132404620070912",
  "geo" : { },
  "id_str" : "539140620627894272",
  "in_reply_to_user_id" : 261821011,
  "text" : "@joshkehn Hey there! Are you signing out from the desktop? If you do that it\u2019ll log out of the app too.",
  "id" : 539140620627894272,
  "in_reply_to_status_id" : 539132404620070912,
  "created_at" : "2014-11-30 19:35:15 +0000",
  "in_reply_to_screen_name" : "joshkehn",
  "in_reply_to_user_id_str" : "261821011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saladin Ahmed",
      "screen_name" : "saladinahmed",
      "indices" : [ 3, 16 ],
      "id_str" : "29995782",
      "id" : 29995782
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/saladinahmed\/status\/538893660860190721\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/UI0zSEwJGu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3qI7ENCMAAGehK.jpg",
      "id_str" : "538893653746266112",
      "id" : 538893653746266112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3qI7ENCMAAGehK.jpg",
      "sizes" : [ {
        "h" : 672,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 672,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UI0zSEwJGu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/U9w2Ykukgd",
      "expanded_url" : "http:\/\/aol.it\/1uXmT2O",
      "display_url" : "aol.it\/1uXmT2O"
    } ]
  },
  "geo" : { },
  "id_str" : "539135739695357952",
  "text" : "RT @saladinahmed: As part of his \"You don't like it? Well fuck you.\" tour, Pope Francis just prayed in a mosque. http:\/\/t.co\/U9w2Ykukgd htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/saladinahmed\/status\/538893660860190721\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/UI0zSEwJGu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3qI7ENCMAAGehK.jpg",
        "id_str" : "538893653746266112",
        "id" : 538893653746266112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3qI7ENCMAAGehK.jpg",
        "sizes" : [ {
          "h" : 672,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 223,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 672,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/UI0zSEwJGu"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/U9w2Ykukgd",
        "expanded_url" : "http:\/\/aol.it\/1uXmT2O",
        "display_url" : "aol.it\/1uXmT2O"
      } ]
    },
    "geo" : { },
    "id_str" : "538893660860190721",
    "text" : "As part of his \"You don't like it? Well fuck you.\" tour, Pope Francis just prayed in a mosque. http:\/\/t.co\/U9w2Ykukgd http:\/\/t.co\/UI0zSEwJGu",
    "id" : 538893660860190721,
    "created_at" : "2014-11-30 03:13:55 +0000",
    "user" : {
      "name" : "Saladin Ahmed",
      "screen_name" : "saladinahmed",
      "protected" : false,
      "id_str" : "29995782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491401748503076865\/CiUrJ-o2_normal.jpeg",
      "id" : 29995782,
      "verified" : false
    }
  },
  "id" : 539135739695357952,
  "created_at" : "2014-11-30 19:15:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tow truck central",
      "screen_name" : "duh_nellll",
      "indices" : [ 86, 97 ],
      "id_str" : "146513248",
      "id" : 146513248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/iA7XkctcqJ",
      "expanded_url" : "http:\/\/m.rochesterschampion.com\/Home\/142-Park-Rd-Perinton-NY-14534\/5130\/R251897\/Gallery\/",
      "display_url" : "m.rochesterschampion.com\/Home\/142-Park-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539128295824969728",
  "text" : "In case you want to live in a mushroom, you can for $775K http:\/\/t.co\/iA7XkctcqJ (via @duh_nellll)",
  "id" : 539128295824969728,
  "created_at" : "2014-11-30 18:46:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539126598163648512",
  "text" : "Maintaining open source over years and years with varying degrees of commitment and life changes is hard. That it happens at all is amazing.",
  "id" : 539126598163648512,
  "created_at" : "2014-11-30 18:39:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539122978324115456",
  "geo" : { },
  "id_str" : "539123975779917825",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats for certain. Some projects tend to be allergic to that over time it seems",
  "id" : 539123975779917825,
  "in_reply_to_status_id" : 539122978324115456,
  "created_at" : "2014-11-30 18:29:06 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539123008904773632",
  "text" : "And definitely: Someone has to say no or nothing can get done. This is true of most things though.",
  "id" : 539123008904773632,
  "created_at" : "2014-11-30 18:25:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539122909759827969",
  "text" : "Basically: Someone needs to be looking out for the entire project or things break down quickly. Cruft builds up.",
  "id" : 539122909759827969,
  "created_at" : "2014-11-30 18:24:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539122783293165568",
  "text" : "The lack of large-scale overhead when just accepting PRs\/small patches for a project means the code debt stratification increases quickly",
  "id" : 539122783293165568,
  "created_at" : "2014-11-30 18:24:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeCraft Hosting",
      "screen_name" : "GetNodeCraft",
      "indices" : [ 0, 13 ],
      "id_str" : "584983019",
      "id" : 584983019
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539113663362125824",
  "in_reply_to_user_id" : 584983019,
  "text" : "@GetNodeCraft is it possible to spin down a server and restart it? thinking of running one for the weekends only",
  "id" : 539113663362125824,
  "created_at" : "2014-11-30 17:48:08 +0000",
  "in_reply_to_screen_name" : "GetNodeCraft",
  "in_reply_to_user_id_str" : "584983019",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539111726583939072",
  "geo" : { },
  "id_str" : "539112373689122816",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier that's hilarious. why do i even bother",
  "id" : 539112373689122816,
  "in_reply_to_status_id" : 539111726583939072,
  "created_at" : "2014-11-30 17:43:00 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 13, 23 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539110630222213121",
  "geo" : { },
  "id_str" : "539111761777922049",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @ngauthier yeah seems to be a similar situation",
  "id" : 539111761777922049,
  "in_reply_to_status_id" : 539110630222213121,
  "created_at" : "2014-11-30 17:40:34 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539089653140586496",
  "geo" : { },
  "id_str" : "539097555351523328",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier still seems more complicated than just spinning up\/down a droplet",
  "id" : 539097555351523328,
  "in_reply_to_status_id" : 539089653140586496,
  "created_at" : "2014-11-30 16:44:07 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539037737241018368",
  "geo" : { },
  "id_str" : "539049371963105281",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps i need to find the Wikipedia article for this guy again, he was amazing",
  "id" : 539049371963105281,
  "in_reply_to_status_id" : 539037737241018368,
  "created_at" : "2014-11-30 13:32:39 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 0, 16 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539048590572675073",
  "geo" : { },
  "id_str" : "539049246960279554",
  "in_reply_to_user_id" : 10114802,
  "text" : "@whentheponydies found a music video and the little guy immediately started dancing, not headbanging \uD83D\uDE12",
  "id" : 539049246960279554,
  "in_reply_to_status_id" : 539048590572675073,
  "created_at" : "2014-11-30 13:32:10 +0000",
  "in_reply_to_screen_name" : "whentheponydies",
  "in_reply_to_user_id_str" : "10114802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 0, 7 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539048533467213824",
  "geo" : { },
  "id_str" : "539048587141726208",
  "in_reply_to_user_id" : 5743852,
  "text" : "@gedeon I mean for the entire game so far.",
  "id" : 539048587141726208,
  "in_reply_to_status_id" : 539048533467213824,
  "created_at" : "2014-11-30 13:29:32 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 0, 7 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539045661598318592",
  "geo" : { },
  "id_str" : "539048533467213824",
  "in_reply_to_user_id" : 38003,
  "text" : "@gedeon I feel this one is broken. Only arrow towers seem to perform well.",
  "id" : 539048533467213824,
  "in_reply_to_status_id" : 539045661598318592,
  "created_at" : "2014-11-30 13:29:20 +0000",
  "in_reply_to_screen_name" : "gedeon",
  "in_reply_to_user_id_str" : "38003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pocket",
      "screen_name" : "Pocket",
      "indices" : [ 43, 50 ],
      "id_str" : "27530178",
      "id" : 27530178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/hZA9Yc5tiY",
      "expanded_url" : "http:\/\/pocket.co\/suKDr",
      "display_url" : "pocket.co\/suKDr"
    } ]
  },
  "geo" : { },
  "id_str" : "539033795085623297",
  "text" : "When Whites Just Don\u2019t Get It, Part 5 (via @Pocket) http:\/\/t.co\/hZA9Yc5tiY",
  "id" : 539033795085623297,
  "created_at" : "2014-11-30 12:30:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538907582552088576",
  "geo" : { },
  "id_str" : "538929419180453889",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek under 10 so far",
  "id" : 538929419180453889,
  "in_reply_to_status_id" : 538907582552088576,
  "created_at" : "2014-11-30 05:36:01 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah rich",
      "screen_name" : "micahbrich",
      "indices" : [ 0, 11 ],
      "id_str" : "14566614",
      "id" : 14566614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538919383532195842",
  "geo" : { },
  "id_str" : "538923625898704896",
  "in_reply_to_user_id" : 14566614,
  "text" : "@micahbrich still better than going to the DMV",
  "id" : 538923625898704896,
  "in_reply_to_status_id" : 538919383532195842,
  "created_at" : "2014-11-30 05:12:59 +0000",
  "in_reply_to_screen_name" : "micahbrich",
  "in_reply_to_user_id_str" : "14566614",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/538903044532875265\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/hhFrtms7K1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3qRdmMCIAA_BFy.jpg",
      "id_str" : "538903043077447680",
      "id" : 538903043077447680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3qRdmMCIAA_BFy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 143,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 863,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/hhFrtms7K1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538903044532875265",
  "text" : "Thinking a .club domain would be cool for the minecraft server but can't find a good one. The road network has grown! http:\/\/t.co\/hhFrtms7K1",
  "id" : 538903044532875265,
  "created_at" : "2014-11-30 03:51:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 7, 16 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538902519166930946",
  "geo" : { },
  "id_str" : "538902805293981696",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr @konklone basically",
  "id" : 538902805293981696,
  "in_reply_to_status_id" : 538902519166930946,
  "created_at" : "2014-11-30 03:50:15 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 7, 16 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538901904013533186",
  "geo" : { },
  "id_str" : "538902287733645312",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr @konklone thrown out = deleted",
  "id" : 538902287733645312,
  "in_reply_to_status_id" : 538901904013533186,
  "created_at" : "2014-11-30 03:48:12 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 3, 11 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Ezra Zygmuntowicz",
      "screen_name" : "ezmobius",
      "indices" : [ 24, 33 ],
      "id_str" : "3560241",
      "id" : 3560241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538896557320732672",
  "text" : "RT @evanphx: Heard that @ezmobius passed away on Facebook. No details. What a loss.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ezra Zygmuntowicz",
        "screen_name" : "ezmobius",
        "indices" : [ 11, 20 ],
        "id_str" : "3560241",
        "id" : 3560241
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538874433654779904",
    "text" : "Heard that @ezmobius passed away on Facebook. No details. What a loss.",
    "id" : 538874433654779904,
    "created_at" : "2014-11-30 01:57:31 +0000",
    "user" : {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "protected" : false,
      "id_str" : "5444392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500424848519077892\/9BhPED16_normal.jpeg",
      "id" : 5444392,
      "verified" : false
    }
  },
  "id" : 538896557320732672,
  "created_at" : "2014-11-30 03:25:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KusuriNetwork",
      "screen_name" : "KusuriNetwork",
      "indices" : [ 0, 14 ],
      "id_str" : "2898652384",
      "id" : 2898652384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538889850519572481",
  "geo" : { },
  "id_str" : "538894845452902400",
  "in_reply_to_user_id" : 2898652384,
  "text" : "@KusuriNetwork thinking about running it on weekends for donations.",
  "id" : 538894845452902400,
  "in_reply_to_status_id" : 538889850519572481,
  "created_at" : "2014-11-30 03:18:37 +0000",
  "in_reply_to_screen_name" : "KusuriNetwork",
  "in_reply_to_user_id_str" : "2898652384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538511932014477312",
  "geo" : { },
  "id_str" : "538873862927024128",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc congrats!!",
  "id" : 538873862927024128,
  "in_reply_to_status_id" : 538511932014477312,
  "created_at" : "2014-11-30 01:55:15 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Willis",
      "screen_name" : "derekwillis",
      "indices" : [ 0, 12 ],
      "id_str" : "14517538",
      "id" : 14517538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538872735372304384",
  "geo" : { },
  "id_str" : "538872939387437056",
  "in_reply_to_user_id" : 14517538,
  "text" : "@derekwillis especially relevant is \"Press release\"",
  "id" : 538872939387437056,
  "in_reply_to_status_id" : 538872735372304384,
  "created_at" : "2014-11-30 01:51:35 +0000",
  "in_reply_to_screen_name" : "derekwillis",
  "in_reply_to_user_id_str" : "14517538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/71lwxeHyN1",
      "expanded_url" : "http:\/\/www.mookieandsam.com\/",
      "display_url" : "mookieandsam.com"
    } ]
  },
  "geo" : { },
  "id_str" : "538853332656222208",
  "text" : "The guy who's the mayor of Portlandia and Paul Atreides has a site for his dogs that is very infected with malware http:\/\/t.co\/71lwxeHyN1",
  "id" : 538853332656222208,
  "created_at" : "2014-11-30 00:33:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 10, 16 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538851519706435584",
  "geo" : { },
  "id_str" : "538851890172133377",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone @parkr same. have thrown out many posts because of this.",
  "id" : 538851890172133377,
  "in_reply_to_status_id" : 538851519706435584,
  "created_at" : "2014-11-30 00:27:56 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/WkaLw8lPJR",
      "expanded_url" : "http:\/\/www.splendidtable.org\/recipes\/thai-fried-omelet",
      "display_url" : "splendidtable.org\/recipes\/thai-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538850571298418688",
  "text" : "I ordered the book but this is the recipe they described on NPR tonight. Ughhh. http:\/\/t.co\/WkaLw8lPJR",
  "id" : 538850571298418688,
  "created_at" : "2014-11-30 00:22:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NEIL cicierega",
      "screen_name" : "neilyourself",
      "indices" : [ 0, 13 ],
      "id_str" : "15360428",
      "id" : 15360428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538847176122990592",
  "geo" : { },
  "id_str" : "538849943453040642",
  "in_reply_to_user_id" : 15360428,
  "text" : "@neilyourself needs some \u201CHooooooo rwraaah?\u201D",
  "id" : 538849943453040642,
  "in_reply_to_status_id" : 538847176122990592,
  "created_at" : "2014-11-30 00:20:12 +0000",
  "in_reply_to_screen_name" : "neilyourself",
  "in_reply_to_user_id_str" : "15360428",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Borenstein",
      "screen_name" : "pborenstein",
      "indices" : [ 0, 12 ],
      "id_str" : "3675931",
      "id" : 3675931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538849308117057536",
  "geo" : { },
  "id_str" : "538849727551246336",
  "in_reply_to_user_id" : 3675931,
  "text" : "@pborenstein yeah exactly. Planning to do that already. Snapshot and spin the droplet down",
  "id" : 538849727551246336,
  "in_reply_to_status_id" : 538849308117057536,
  "created_at" : "2014-11-30 00:19:21 +0000",
  "in_reply_to_screen_name" : "pborenstein",
  "in_reply_to_user_id_str" : "3675931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Allen Quotes",
      "screen_name" : "TimAllenQuote",
      "indices" : [ 3, 17 ],
      "id_str" : "2842029543",
      "id" : 2842029543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538849583132987392",
  "text" : "RT @TimAllenQuote: \"Arrghaugh aughhargh hhhugh hhhughough, urgh huagh... Roigh\" - Tim Allen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/TimAllenQuote\" rel=\"nofollow\"\u003ETim Allen Quotes\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538632535287148544",
    "text" : "\"Arrghaugh aughhargh hhhugh hhhughough, urgh huagh... Roigh\" - Tim Allen",
    "id" : 538632535287148544,
    "created_at" : "2014-11-29 09:56:18 +0000",
    "user" : {
      "name" : "Tim Allen Quotes",
      "screen_name" : "TimAllenQuote",
      "protected" : false,
      "id_str" : "2842029543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525335533350699009\/Z0Qg4rFi_normal.jpeg",
      "id" : 2842029543,
      "verified" : false
    }
  },
  "id" : 538849583132987392,
  "created_at" : "2014-11-30 00:18:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Allen Quotes",
      "screen_name" : "TimAllenQuote",
      "indices" : [ 3, 17 ],
      "id_str" : "2842029543",
      "id" : 2842029543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538849485573472256",
  "text" : "RT @TimAllenQuote: \"Aughhohrugh\" - Tim Allen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/TimAllenQuote\" rel=\"nofollow\"\u003ETim Allen Quotes\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538836376985165824",
    "text" : "\"Aughhohrugh\" - Tim Allen",
    "id" : 538836376985165824,
    "created_at" : "2014-11-29 23:26:18 +0000",
    "user" : {
      "name" : "Tim Allen Quotes",
      "screen_name" : "TimAllenQuote",
      "protected" : false,
      "id_str" : "2842029543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525335533350699009\/Z0Qg4rFi_normal.jpeg",
      "id" : 2842029543,
      "verified" : false
    }
  },
  "id" : 538849485573472256,
  "created_at" : "2014-11-30 00:18:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Allen Quotes",
      "screen_name" : "TimAllenQuote",
      "indices" : [ 3, 17 ],
      "id_str" : "2842029543",
      "id" : 2842029543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538849457131905025",
  "text" : "RT @TimAllenQuote: \"Hoharghugh harghaughugghh huagh urrugh hargh huaghurgh\" - Tim Allen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/TimAllenQuote\" rel=\"nofollow\"\u003ETim Allen Quotes\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538847702042169344",
    "text" : "\"Hoharghugh harghaughugghh huagh urrugh hargh huaghurgh\" - Tim Allen",
    "id" : 538847702042169344,
    "created_at" : "2014-11-30 00:11:18 +0000",
    "user" : {
      "name" : "Tim Allen Quotes",
      "screen_name" : "TimAllenQuote",
      "protected" : false,
      "id_str" : "2842029543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525335533350699009\/Z0Qg4rFi_normal.jpeg",
      "id" : 2842029543,
      "verified" : false
    }
  },
  "id" : 538849457131905025,
  "created_at" : "2014-11-30 00:18:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Small",
      "screen_name" : "IanTSmall",
      "indices" : [ 0, 10 ],
      "id_str" : "355753921",
      "id" : 355753921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538832056554229761",
  "geo" : { },
  "id_str" : "538835738519814144",
  "in_reply_to_user_id" : 355753921,
  "text" : "@IanTSmall *orders 12 pizzas shipped to your door to watch reaction*",
  "id" : 538835738519814144,
  "in_reply_to_status_id" : 538832056554229761,
  "created_at" : "2014-11-29 23:23:45 +0000",
  "in_reply_to_screen_name" : "IanTSmall",
  "in_reply_to_user_id_str" : "355753921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/538835172926316545\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/1ISYyuAHvR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3pTu50CMAEDPGH.png",
      "id_str" : "538835170682351617",
      "id" : 538835170682351617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3pTu50CMAEDPGH.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1242,
        "resize" : "fit",
        "w" : 2208
      } ],
      "display_url" : "pic.twitter.com\/1ISYyuAHvR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538835172926316545",
  "text" : "I was gonna buy it, but http:\/\/t.co\/1ISYyuAHvR",
  "id" : 538835172926316545,
  "created_at" : "2014-11-29 23:21:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Borenstein",
      "screen_name" : "pborenstein",
      "indices" : [ 0, 12 ],
      "id_str" : "3675931",
      "id" : 3675931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538829715084439552",
  "geo" : { },
  "id_str" : "538833139104092160",
  "in_reply_to_user_id" : 3675931,
  "text" : "@pborenstein cute but basically already have it right? Just installed the server and Overviewer. That\u2019s it.",
  "id" : 538833139104092160,
  "in_reply_to_status_id" : 538829715084439552,
  "created_at" : "2014-11-29 23:13:26 +0000",
  "in_reply_to_screen_name" : "pborenstein",
  "in_reply_to_user_id_str" : "3675931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538829215726968833",
  "geo" : { },
  "id_str" : "538832959298478080",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal nah that\u2019s no fun",
  "id" : 538832959298478080,
  "in_reply_to_status_id" : 538829215726968833,
  "created_at" : "2014-11-29 23:12:43 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stevens",
      "screen_name" : "kevdog",
      "indices" : [ 0, 7 ],
      "id_str" : "10696812",
      "id" : 10696812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538828990191271936",
  "geo" : { },
  "id_str" : "538832921021276160",
  "in_reply_to_user_id" : 10696812,
  "text" : "@kevdog 2GB droplet",
  "id" : 538832921021276160,
  "in_reply_to_status_id" : 538828990191271936,
  "created_at" : "2014-11-29 23:12:34 +0000",
  "in_reply_to_screen_name" : "kevdog",
  "in_reply_to_user_id_str" : "10696812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/538828752759705600\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/bpboiYPkID",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3pN5OoCUAAqCB7.png",
      "id_str" : "538828750998097920",
      "id" : 538828750998097920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3pN5OoCUAAqCB7.png",
      "sizes" : [ {
        "h" : 217,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 127,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 72,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 1750
      } ],
      "display_url" : "pic.twitter.com\/bpboiYPkID"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538828752759705600",
  "text" : "Stupid idea: Run the minecraft server only on weekends and charge ($1-5?) for access. Might be fun (Y\/N) ? http:\/\/t.co\/bpboiYPkID",
  "id" : 538828752759705600,
  "created_at" : "2014-11-29 22:56:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 37, 49 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/zHJn3vU50o",
      "expanded_url" : "http:\/\/www.npr.org\/blogs\/codeswitch\/2014\/11\/29\/366611344\/the-banh-mi-handbook-a-guide-to-a-viet-french-sandwich",
      "display_url" : "npr.org\/blogs\/codeswit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538827555696959488",
  "text" : "Heard this story on my way back from @whereslloyd and now I want all the banh mis http:\/\/t.co\/zHJn3vU50o",
  "id" : 538827555696959488,
  "created_at" : "2014-11-29 22:51:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 34, 46 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/idA828esYB",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/5W9oQV9EIf6",
      "display_url" : "swarmapp.com\/c\/5W9oQV9EIf6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.911854117, -78.8768139658 ]
  },
  "id_str" : "538822573417836545",
  "text" : "I'm at Lloyd the III Taco Truck - @whereslloyd in Buffalo, NY https:\/\/t.co\/idA828esYB",
  "id" : 538822573417836545,
  "created_at" : "2014-11-29 22:31:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 97, 109 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/sW3yOTjjXq",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wnBdY94z7bU",
      "display_url" : "youtube.com\/watch?v=wnBdY9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538801318270230530",
  "text" : "Well, I'm going to freeze a pair of headphones and crush them with a concrete weight. But first, @AqueousBand! https:\/\/t.co\/sW3yOTjjXq",
  "id" : 538801318270230530,
  "created_at" : "2014-11-29 21:06:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Joyce",
      "screen_name" : "chris_joyce",
      "indices" : [ 0, 12 ],
      "id_str" : "15686931",
      "id" : 15686931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538794995575443457",
  "geo" : { },
  "id_str" : "538799584235909120",
  "in_reply_to_user_id" : 15686931,
  "text" : "@chris_joyce i just played 6 \"FUN\" online games and maybe got 3 kills.",
  "id" : 538799584235909120,
  "in_reply_to_status_id" : 538794995575443457,
  "created_at" : "2014-11-29 21:00:05 +0000",
  "in_reply_to_screen_name" : "chris_joyce",
  "in_reply_to_user_id_str" : "15686931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538787749453508609",
  "text" : "Smash finally arrived after being delayed by the snowstorm. I'm quaranto on there if you can figure out how to add it.",
  "id" : 538787749453508609,
  "created_at" : "2014-11-29 20:13:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/538553842615746561\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/qKP8UEibT8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3lT3YBIYAAqzzD.jpg",
      "id_str" : "538553841252589568",
      "id" : 538553841252589568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3lT3YBIYAAqzzD.jpg",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/qKP8UEibT8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538534182612643841",
  "geo" : { },
  "id_str" : "538553842615746561",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek yeeees? http:\/\/t.co\/qKP8UEibT8",
  "id" : 538553842615746561,
  "in_reply_to_status_id" : 538534182612643841,
  "created_at" : "2014-11-29 04:43:36 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538525522926776321",
  "geo" : { },
  "id_str" : "538526008300036096",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier AMAZING",
  "id" : 538526008300036096,
  "in_reply_to_status_id" : 538525522926776321,
  "created_at" : "2014-11-29 02:53:00 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 3, 13 ],
      "id_str" : "15243796",
      "id" : 15243796
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 15, 21 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ngauthier\/status\/538525522926776321\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/YkqDzwMVMt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3k6G-dCYAAOgDI.png",
      "id_str" : "538525521965899776",
      "id" : 538525521965899776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3k6G-dCYAAOgDI.png",
      "sizes" : [ {
        "h" : 477,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 649,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 649,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com\/YkqDzwMVMt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538525994756628480",
  "text" : "RT @ngauthier: @qrush thanks for hosting the server! I left you a special gift. http:\/\/t.co\/YkqDzwMVMt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ngauthier\/status\/538525522926776321\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/YkqDzwMVMt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3k6G-dCYAAOgDI.png",
        "id_str" : "538525521965899776",
        "id" : 538525521965899776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3k6G-dCYAAOgDI.png",
        "sizes" : [ {
          "h" : 477,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 649,
          "resize" : "fit",
          "w" : 816
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 649,
          "resize" : "fit",
          "w" : 816
        } ],
        "display_url" : "pic.twitter.com\/YkqDzwMVMt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538525522926776321",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush thanks for hosting the server! I left you a special gift. http:\/\/t.co\/YkqDzwMVMt",
    "id" : 538525522926776321,
    "created_at" : "2014-11-29 02:51:04 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "protected" : false,
      "id_str" : "15243796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539452893112201217\/aJOphfgM_normal.png",
      "id" : 15243796,
      "verified" : false
    }
  },
  "id" : 538525994756628480,
  "created_at" : "2014-11-29 02:52:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/538508834047021056\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/UAVNn8Lgjh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3kq7idIgAADXeR.jpg",
      "id_str" : "538508832797130752",
      "id" : 538508832797130752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3kq7idIgAADXeR.jpg",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/UAVNn8Lgjh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538508834047021056",
  "text" : "I don't think we have enough cows http:\/\/t.co\/UAVNn8Lgjh",
  "id" : 538508834047021056,
  "created_at" : "2014-11-29 01:44:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538499350872485888",
  "text" : "Doing that Minecraft thing again. Who's in?",
  "id" : 538499350872485888,
  "created_at" : "2014-11-29 01:07:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2192() \u007B Robertt \u007D",
      "screen_name" : "robertodecurnex",
      "indices" : [ 0, 16 ],
      "id_str" : "63124269",
      "id" : 63124269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538443952462913536",
  "geo" : { },
  "id_str" : "538453152144850944",
  "in_reply_to_user_id" : 63124269,
  "text" : "@robertodecurnex not following you. can you please elaborate in the thread?",
  "id" : 538453152144850944,
  "in_reply_to_status_id" : 538443952462913536,
  "created_at" : "2014-11-28 22:03:30 +0000",
  "in_reply_to_screen_name" : "robertodecurnex",
  "in_reply_to_user_id_str" : "63124269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/33aYApI4Hq",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/zenHfuMFNE",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/issues\/610",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538437691290157058",
  "text" : "http:\/\/t.co\/33aYApI4Hq's repo is now over 500MB (if the site's down, how do we get gems?) Any ideas on improving it? https:\/\/t.co\/zenHfuMFNE",
  "id" : 538437691290157058,
  "created_at" : "2014-11-28 21:02:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamil Smith",
      "screen_name" : "JamilSmith",
      "indices" : [ 3, 14 ],
      "id_str" : "46213956",
      "id" : 46213956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/NPWTSYaMUP",
      "expanded_url" : "http:\/\/s.cleveland.com\/6Bkwt7Q",
      "display_url" : "s.cleveland.com\/6Bkwt7Q"
    } ]
  },
  "geo" : { },
  "id_str" : "538413162182488064",
  "text" : "RT @JamilSmith: The Cleveland police account of the Tamir Rice shooting doesn't really wash, because video. Plain Dealer editorial: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/NPWTSYaMUP",
        "expanded_url" : "http:\/\/s.cleveland.com\/6Bkwt7Q",
        "display_url" : "s.cleveland.com\/6Bkwt7Q"
      } ]
    },
    "geo" : { },
    "id_str" : "538395711574798336",
    "text" : "The Cleveland police account of the Tamir Rice shooting doesn't really wash, because video. Plain Dealer editorial: http:\/\/t.co\/NPWTSYaMUP",
    "id" : 538395711574798336,
    "created_at" : "2014-11-28 18:15:15 +0000",
    "user" : {
      "name" : "Jamil Smith",
      "screen_name" : "JamilSmith",
      "protected" : false,
      "id_str" : "46213956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567954389764431873\/L3XH47M3_normal.jpeg",
      "id" : 46213956,
      "verified" : true
    }
  },
  "id" : 538413162182488064,
  "created_at" : "2014-11-28 19:24:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Fayram",
      "screen_name" : "KirinDave",
      "indices" : [ 0, 10 ],
      "id_str" : "784519",
      "id" : 784519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538399978507337729",
  "geo" : { },
  "id_str" : "538404476319981568",
  "in_reply_to_user_id" : 784519,
  "text" : "@KirinDave Vanilla.",
  "id" : 538404476319981568,
  "in_reply_to_status_id" : 538399978507337729,
  "created_at" : "2014-11-28 18:50:04 +0000",
  "in_reply_to_screen_name" : "KirinDave",
  "in_reply_to_user_id_str" : "784519",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cole Townsend",
      "screen_name" : "twnsndco",
      "indices" : [ 3, 12 ],
      "id_str" : "232639632",
      "id" : 232639632
    }, {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 52, 67 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538382892830040064",
  "text" : "RT @twnsndco: If you\u2019re in Buffalo and not drinking @PublicEspresso what\u2019s the point? They\u2019ll be at Horsefeathers and Hertel Market Sat 9-1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PublicEspresso",
        "screen_name" : "PublicEspresso",
        "indices" : [ 38, 53 ],
        "id_str" : "1472209542",
        "id" : 1472209542
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538382749468733440",
    "text" : "If you\u2019re in Buffalo and not drinking @PublicEspresso what\u2019s the point? They\u2019ll be at Horsefeathers and Hertel Market Sat 9-1.  Get some.",
    "id" : 538382749468733440,
    "created_at" : "2014-11-28 17:23:44 +0000",
    "user" : {
      "name" : "Cole Townsend",
      "screen_name" : "twnsndco",
      "protected" : false,
      "id_str" : "232639632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531214628580106240\/oGpL8Z7k_normal.jpeg",
      "id" : 232639632,
      "verified" : false
    }
  },
  "id" : 538382892830040064,
  "created_at" : "2014-11-28 17:24:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Fayram",
      "screen_name" : "KirinDave",
      "indices" : [ 0, 10 ],
      "id_str" : "784519",
      "id" : 784519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538382508010659841",
  "geo" : { },
  "id_str" : "538382691901906945",
  "in_reply_to_user_id" : 784519,
  "text" : "@KirinDave been running a MC server for the holiday(s) if you want in",
  "id" : 538382691901906945,
  "in_reply_to_status_id" : 538382508010659841,
  "created_at" : "2014-11-28 17:23:31 +0000",
  "in_reply_to_screen_name" : "KirinDave",
  "in_reply_to_user_id_str" : "784519",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/K5dKADk79E",
      "expanded_url" : "https:\/\/store.cardsagainsthumanity.com\/",
      "display_url" : "store.cardsagainsthumanity.com"
    } ]
  },
  "geo" : { },
  "id_str" : "538380803923640320",
  "text" : "Dear god is it actually poop? https:\/\/t.co\/K5dKADk79E",
  "id" : 538380803923640320,
  "created_at" : "2014-11-28 17:16:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538378670470352896",
  "geo" : { },
  "id_str" : "538378902859943937",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss we've only used an audio monitor so far",
  "id" : 538378902859943937,
  "in_reply_to_status_id" : 538378670470352896,
  "created_at" : "2014-11-28 17:08:27 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538375287558651906",
  "geo" : { },
  "id_str" : "538375612990500864",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss tempting but i am convinced Nest will integrate it into their app. Will wait.",
  "id" : 538375612990500864,
  "in_reply_to_status_id" : 538375287558651906,
  "created_at" : "2014-11-28 16:55:23 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stacey Pensgen",
      "screen_name" : "spensgen",
      "indices" : [ 3, 12 ],
      "id_str" : "16688474",
      "id" : 16688474
    }, {
      "name" : "NWS BUFFALO",
      "screen_name" : "NWSBUFFALO",
      "indices" : [ 25, 36 ],
      "id_str" : "982762350",
      "id" : 982762350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/BrMIshLvtv",
      "expanded_url" : "http:\/\/www.weather.gov\/buf\/lake1415_stormb.html",
      "display_url" : "weather.gov\/buf\/lake1415_s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538367895328530432",
  "text" : "RT @spensgen: ICYMI: the @NWSBUFFALO's write-up of the Lake Effect snow event last week: http:\/\/t.co\/BrMIshLvtv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NWS BUFFALO",
        "screen_name" : "NWSBUFFALO",
        "indices" : [ 11, 22 ],
        "id_str" : "982762350",
        "id" : 982762350
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/BrMIshLvtv",
        "expanded_url" : "http:\/\/www.weather.gov\/buf\/lake1415_stormb.html",
        "display_url" : "weather.gov\/buf\/lake1415_s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "538367367701860353",
    "text" : "ICYMI: the @NWSBUFFALO's write-up of the Lake Effect snow event last week: http:\/\/t.co\/BrMIshLvtv",
    "id" : 538367367701860353,
    "created_at" : "2014-11-28 16:22:37 +0000",
    "user" : {
      "name" : "Stacey Pensgen",
      "screen_name" : "spensgen",
      "protected" : false,
      "id_str" : "16688474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440264936846262272\/I1vaWqZe_normal.jpeg",
      "id" : 16688474,
      "verified" : false
    }
  },
  "id" : 538367895328530432,
  "created_at" : "2014-11-28 16:24:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Friebel",
      "screen_name" : "freebly",
      "indices" : [ 0, 8 ],
      "id_str" : "201948826",
      "id" : 201948826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538361421520584704",
  "geo" : { },
  "id_str" : "538364031057543168",
  "in_reply_to_user_id" : 201948826,
  "text" : "@freebly Mine, but i'm fine with sharing anything\/everything. The swamp fort was generated.",
  "id" : 538364031057543168,
  "in_reply_to_status_id" : 538361421520584704,
  "created_at" : "2014-11-28 16:09:21 +0000",
  "in_reply_to_screen_name" : "freebly",
  "in_reply_to_user_id_str" : "201948826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/538359281914220545\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/iOhYOIxlrL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ii6XyCYAIKFjR.png",
      "id_str" : "538359279170772994",
      "id" : 538359279170772994,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ii6XyCYAIKFjR.png",
      "sizes" : [ {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 1958
      }, {
        "h" : 539,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/iOhYOIxlrL"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/538359281914220545\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/iOhYOIxlrL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ii3I3CAAEZbNM.png",
      "id_str" : "538359223625580545",
      "id" : 538359223625580545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ii3I3CAAEZbNM.png",
      "sizes" : [ {
        "h" : 180,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 542,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 1352
      }, {
        "h" : 317,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/iOhYOIxlrL"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/538359281914220545\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/iOhYOIxlrL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ii4SNCEAAMxQo.png",
      "id_str" : "538359243313647616",
      "id" : 538359243313647616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ii4SNCEAAMxQo.png",
      "sizes" : [ {
        "h" : 413,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 966,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iOhYOIxlrL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538359281914220545",
  "text" : "Installed Overviewer and here's some initial shots from the Minecraft world. Let me know if you want the IP! http:\/\/t.co\/iOhYOIxlrL",
  "id" : 538359281914220545,
  "created_at" : "2014-11-28 15:50:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/juwQUeIONa",
      "expanded_url" : "http:\/\/services.amazon.com\/selling-services\/pricing.htm",
      "display_url" : "services.amazon.com\/selling-servic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538307712980099072",
  "text" : "Wondering if the \"find\/recommend a contractor\" game every houseowner plays is about to be over soon http:\/\/t.co\/juwQUeIONa",
  "id" : 538307712980099072,
  "created_at" : "2014-11-28 12:25:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538299380781293568",
  "text" : "I hope the new Star Wars trailer is just 60 seconds of TIE fighter screeching",
  "id" : 538299380781293568,
  "created_at" : "2014-11-28 11:52:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538059980679962624",
  "text" : "Also a quick reminder that I'm running a Minecraft server for the holiday. Ping me for the IP!",
  "id" : 538059980679962624,
  "created_at" : "2014-11-27 20:01:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538059810806460418",
  "text" : "I have watched more network TV in one day today than in a year. Verdict: I cannot stop doing Christopher Walken impressions as Hook",
  "id" : 538059810806460418,
  "created_at" : "2014-11-27 20:00:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rachel",
      "screen_name" : "ohhoe",
      "indices" : [ 0, 6 ],
      "id_str" : "2141321",
      "id" : 2141321
    }, {
      "name" : "jessicard",
      "screen_name" : "jessicard",
      "indices" : [ 7, 17 ],
      "id_str" : "253464752",
      "id" : 253464752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538019805048356865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1928593355, -80.5593271147 ]
  },
  "id_str" : "538022609494233089",
  "in_reply_to_user_id" : 2141321,
  "text" : "@ohhoe @jessicard I was rooting for the husky :(",
  "id" : 538022609494233089,
  "in_reply_to_status_id" : 538019805048356865,
  "created_at" : "2014-11-27 17:32:40 +0000",
  "in_reply_to_screen_name" : "ohhoe",
  "in_reply_to_user_id_str" : "2141321",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/k3oauJt2yP",
      "expanded_url" : "https:\/\/www.digitalocean.com\/?refcode=2d1532006d25",
      "display_url" : "digitalocean.com\/?refcode=2d153\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537997118905253888",
  "text" : "Running a minecraft server on DigitalOcean for a little bit. Reply or DM for the IP. Oh, and: https:\/\/t.co\/k3oauJt2yP",
  "id" : 537997118905253888,
  "created_at" : "2014-11-27 15:51:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537976804615933952",
  "geo" : { },
  "id_str" : "537987184591405057",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier Just vanilla. I've barely played.",
  "id" : 537987184591405057,
  "in_reply_to_status_id" : 537976804615933952,
  "created_at" : "2014-11-27 15:11:54 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Friebel",
      "screen_name" : "freebly",
      "indices" : [ 0, 8 ],
      "id_str" : "201948826",
      "id" : 201948826
    }, {
      "name" : "Alex McHale",
      "screen_name" : "alexmchale",
      "indices" : [ 9, 20 ],
      "id_str" : "13964832",
      "id" : 13964832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537826276061347840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1930426907, -80.5592436637 ]
  },
  "id_str" : "537973081068027904",
  "in_reply_to_user_id" : 201948826,
  "text" : "@freebly @alexmchale fell asleep instead. Oops",
  "id" : 537973081068027904,
  "in_reply_to_status_id" : 537826276061347840,
  "created_at" : "2014-11-27 14:15:52 +0000",
  "in_reply_to_screen_name" : "freebly",
  "in_reply_to_user_id_str" : "201948826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537823234180526080",
  "text" : "Uhhhh anyone want to play some minecraft?",
  "id" : 537823234180526080,
  "created_at" : "2014-11-27 04:20:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 8, 16 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/i5yaRLyLaE",
      "expanded_url" : "http:\/\/alt.org\/nethack\/player-stats.php?player=DoctorNick",
      "display_url" : "alt.org\/nethack\/player\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "537801381164642305",
  "geo" : { },
  "id_str" : "537801809990254592",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw @jayunit correction, i have a problem http:\/\/t.co\/i5yaRLyLaE",
  "id" : 537801809990254592,
  "in_reply_to_status_id" : 537801381164642305,
  "created_at" : "2014-11-27 02:55:18 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 9, 16 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537800890501963776",
  "geo" : { },
  "id_str" : "537801011042484224",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @gabebw you're playing nethack!!!?",
  "id" : 537801011042484224,
  "in_reply_to_status_id" : 537800890501963776,
  "created_at" : "2014-11-27 02:52:07 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asher Vollmer",
      "screen_name" : "AsherVo",
      "indices" : [ 0, 8 ],
      "id_str" : "16741826",
      "id" : 16741826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537756624073814016",
  "in_reply_to_user_id" : 16741826,
  "text" : "@AsherVo do you get some kind of special treatment from apple\u2019s review process? Amazed how fast releases are pushed through for threes",
  "id" : 537756624073814016,
  "created_at" : "2014-11-26 23:55:44 +0000",
  "in_reply_to_screen_name" : "AsherVo",
  "in_reply_to_user_id_str" : "16741826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Benson",
      "screen_name" : "natebenson",
      "indices" : [ 0, 11 ],
      "id_str" : "25678101",
      "id" : 25678101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537752917265362944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1929726251, -80.5592933578 ]
  },
  "id_str" : "537756036959338496",
  "in_reply_to_user_id" : 25678101,
  "text" : "@natebenson penn station is like that every day",
  "id" : 537756036959338496,
  "in_reply_to_status_id" : 537752917265362944,
  "created_at" : "2014-11-26 23:53:24 +0000",
  "in_reply_to_screen_name" : "natebenson",
  "in_reply_to_user_id_str" : "25678101",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Eppstein",
      "screen_name" : "chriseppstein",
      "indices" : [ 0, 14 ],
      "id_str" : "14148091",
      "id" : 14148091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537754328308523008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1925072067, -80.5596681844 ]
  },
  "id_str" : "537754957945241600",
  "in_reply_to_user_id" : 14148091,
  "text" : "@chriseppstein nope, no confederate flags either. Yet.",
  "id" : 537754957945241600,
  "in_reply_to_status_id" : 537754328308523008,
  "created_at" : "2014-11-26 23:49:07 +0000",
  "in_reply_to_screen_name" : "chriseppstein",
  "in_reply_to_user_id_str" : "14148091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537754140429275137",
  "text" : "How I know I\u2019m out of the city: sticker on a truck proudly proclaiming:\n\nMUD SLUT\nHITTIN EVERY HOLE",
  "id" : 537754140429275137,
  "created_at" : "2014-11-26 23:45:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 10, 18 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 19, 31 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537649765157441537",
  "geo" : { },
  "id_str" : "537655229278195712",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone @evanphx @dwradcliffe we\u2019ve been talking about a ToS and privacy policy for years but haven\u2019t done it. Hard when it\u2019s volunteer.",
  "id" : 537655229278195712,
  "in_reply_to_status_id" : 537649765157441537,
  "created_at" : "2014-11-26 17:12:50 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 40, 48 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 49, 61 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537614906288525313",
  "geo" : { },
  "id_str" : "537640238651170816",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone whaaat? Can you gist it? Wtf? @evanphx @dwradcliffe",
  "id" : 537640238651170816,
  "in_reply_to_status_id" : 537614906288525313,
  "created_at" : "2014-11-26 16:13:16 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruben Bolling",
      "screen_name" : "RubenBolling",
      "indices" : [ 3, 16 ],
      "id_str" : "17212474",
      "id" : 17212474
    }, {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 49, 60 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RubenBolling\/status\/537596038581092352\/photo\/1",
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/Iv3hAgjzwO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3Xsv38IcAAkC3O.png",
      "id_str" : "537596037754810368",
      "id" : 537596037754810368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3Xsv38IcAAkC3O.png",
      "sizes" : [ {
        "h" : 280,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 499
      } ],
      "display_url" : "pic.twitter.com\/Iv3hAgjzwO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Itbz9uqOjo",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/11\/26\/tom-the-dancing-bug-richard-s.html",
      "display_url" : "boingboing.net\/2014\/11\/26\/tom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537602557271498752",
  "text" : "RT @RubenBolling: THIS WEEK'S COMIC is now up on @BoingBoing:\n\nRichard Scarry's Bush 21st Century\n\nhttp:\/\/t.co\/Itbz9uqOjo http:\/\/t.co\/Iv3hA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Boing Boing",
        "screen_name" : "BoingBoing",
        "indices" : [ 31, 42 ],
        "id_str" : "5971922",
        "id" : 5971922
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RubenBolling\/status\/537596038581092352\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/Iv3hAgjzwO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3Xsv38IcAAkC3O.png",
        "id_str" : "537596037754810368",
        "id" : 537596037754810368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3Xsv38IcAAkC3O.png",
        "sizes" : [ {
          "h" : 280,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 499
        } ],
        "display_url" : "pic.twitter.com\/Iv3hAgjzwO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/Itbz9uqOjo",
        "expanded_url" : "http:\/\/boingboing.net\/2014\/11\/26\/tom-the-dancing-bug-richard-s.html",
        "display_url" : "boingboing.net\/2014\/11\/26\/tom\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "537596038581092352",
    "text" : "THIS WEEK'S COMIC is now up on @BoingBoing:\n\nRichard Scarry's Bush 21st Century\n\nhttp:\/\/t.co\/Itbz9uqOjo http:\/\/t.co\/Iv3hAgjzwO",
    "id" : 537596038581092352,
    "created_at" : "2014-11-26 13:17:38 +0000",
    "user" : {
      "name" : "Ruben Bolling",
      "screen_name" : "RubenBolling",
      "protected" : false,
      "id_str" : "17212474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3548061070\/7cc8915fd0499a7ec4b5b260ff43fc80_normal.png",
      "id" : 17212474,
      "verified" : false
    }
  },
  "id" : 537602557271498752,
  "created_at" : "2014-11-26 13:43:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537473779513823234",
  "geo" : { },
  "id_str" : "537474465009893376",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety wat",
  "id" : 537474465009893376,
  "in_reply_to_status_id" : 537473779513823234,
  "created_at" : "2014-11-26 05:14:32 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Coyier",
      "screen_name" : "chriscoyier",
      "indices" : [ 0, 12 ],
      "id_str" : "793830",
      "id" : 793830
    }, {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 13, 21 ],
      "id_str" : "668863",
      "id" : 668863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537406603793010688",
  "geo" : { },
  "id_str" : "537465421205479424",
  "in_reply_to_user_id" : 793830,
  "text" : "@chriscoyier @tomdale my favorite game to play now: give change after the transaction completed. Most cannot handle a break in the monotony",
  "id" : 537465421205479424,
  "in_reply_to_status_id" : 537406603793010688,
  "created_at" : "2014-11-26 04:38:36 +0000",
  "in_reply_to_screen_name" : "chriscoyier",
  "in_reply_to_user_id_str" : "793830",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Coyier",
      "screen_name" : "chriscoyier",
      "indices" : [ 0, 12 ],
      "id_str" : "793830",
      "id" : 793830
    }, {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 13, 21 ],
      "id_str" : "668863",
      "id" : 668863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537406603793010688",
  "geo" : { },
  "id_str" : "537465155185938433",
  "in_reply_to_user_id" : 793830,
  "text" : "@chriscoyier @tomdale my 2 years as a cashier was in part messing with these contracts: my favorite, counting change manually",
  "id" : 537465155185938433,
  "in_reply_to_status_id" : 537406603793010688,
  "created_at" : "2014-11-26 04:37:33 +0000",
  "in_reply_to_screen_name" : "chriscoyier",
  "in_reply_to_user_id_str" : "793830",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/LXyNQz8cNX",
      "expanded_url" : "https:\/\/vine.co\/v\/O1TDrijX56E",
      "display_url" : "vine.co\/v\/O1TDrijX56E"
    } ]
  },
  "geo" : { },
  "id_str" : "537455829675278336",
  "text" : "You'll never be a dancer Mario! https:\/\/t.co\/LXyNQz8cNX",
  "id" : 537455829675278336,
  "created_at" : "2014-11-26 04:00:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 20, 34 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537319217704341505",
  "text" : "15 people in\/around @coworkbuffalo today. This coworking thing. It\u2019s great.",
  "id" : 537319217704341505,
  "created_at" : "2014-11-25 18:57:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Marquet",
      "screen_name" : "ldavidmarquet",
      "indices" : [ 3, 17 ],
      "id_str" : "165091971",
      "id" : 165091971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537300856215859200",
  "text" : "RT @ldavidmarquet: The role we play in a company does not make us a leader. \nThe role we play to serve others makes us a leader.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537243106010488832",
    "text" : "The role we play in a company does not make us a leader. \nThe role we play to serve others makes us a leader.",
    "id" : 537243106010488832,
    "created_at" : "2014-11-25 13:55:12 +0000",
    "user" : {
      "name" : "David Marquet",
      "screen_name" : "ldavidmarquet",
      "protected" : false,
      "id_str" : "165091971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525651227585941504\/1DFb50tl_normal.jpeg",
      "id" : 165091971,
      "verified" : false
    }
  },
  "id" : 537300856215859200,
  "created_at" : "2014-11-25 17:44:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Veix",
      "screen_name" : "joeveix",
      "indices" : [ 3, 11 ],
      "id_str" : "18205994",
      "id" : 18205994
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/joeveix\/status\/537138111168278529\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/biq1E06Oy4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3RMRAMCIAAIAxV.png",
      "id_str" : "537138110555889664",
      "id" : 537138110555889664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3RMRAMCIAAIAxV.png",
      "sizes" : [ {
        "h" : 285,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 161,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 1016
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 1016
      } ],
      "display_url" : "pic.twitter.com\/biq1E06Oy4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537282916191989761",
  "text" : "RT @joeveix: Sneak peek of tomorrow's New York Times. http:\/\/t.co\/biq1E06Oy4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/joeveix\/status\/537138111168278529\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/biq1E06Oy4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3RMRAMCIAAIAxV.png",
        "id_str" : "537138110555889664",
        "id" : 537138110555889664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3RMRAMCIAAIAxV.png",
        "sizes" : [ {
          "h" : 285,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 161,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 1016
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 1016
        } ],
        "display_url" : "pic.twitter.com\/biq1E06Oy4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537138111168278529",
    "text" : "Sneak peek of tomorrow's New York Times. http:\/\/t.co\/biq1E06Oy4",
    "id" : 537138111168278529,
    "created_at" : "2014-11-25 06:57:59 +0000",
    "user" : {
      "name" : "Joe Veix",
      "screen_name" : "joeveix",
      "protected" : false,
      "id_str" : "18205994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533732321589874688\/1pQ_CSeO_normal.jpeg",
      "id" : 18205994,
      "verified" : false
    }
  },
  "id" : 537282916191989761,
  "created_at" : "2014-11-25 16:33:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Long Nguyen",
      "screen_name" : "lnguyen11288",
      "indices" : [ 0, 13 ],
      "id_str" : "158124243",
      "id" : 158124243
    }, {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 26, 42 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537251522489241602",
  "geo" : { },
  "id_str" : "537256462506942464",
  "in_reply_to_user_id" : 158124243,
  "text" : "@lnguyen11288 not sure cc @rubygems_status",
  "id" : 537256462506942464,
  "in_reply_to_status_id" : 537251522489241602,
  "created_at" : "2014-11-25 14:48:17 +0000",
  "in_reply_to_screen_name" : "lnguyen11288",
  "in_reply_to_user_id_str" : "158124243",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zeddonymous",
      "screen_name" : "ZeddRebel",
      "indices" : [ 3, 13 ],
      "id_str" : "322735335",
      "id" : 322735335
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NewsBreaker\/status\/537086972720734208\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/aj7SE7ZjUA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3QdwUZCEAEhbtJ.png",
      "id_str" : "537086971508559873",
      "id" : 537086971508559873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3QdwUZCEAEhbtJ.png",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/aj7SE7ZjUA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537092710000119808",
  "text" : "RT @ZeddRebel: America. https:\/\/t.co\/aj7SE7ZjUA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NewsBreaker\/status\/537086972720734208\/photo\/1",
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/aj7SE7ZjUA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3QdwUZCEAEhbtJ.png",
        "id_str" : "537086971508559873",
        "id" : 537086971508559873,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3QdwUZCEAEhbtJ.png",
        "sizes" : [ {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/aj7SE7ZjUA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537089736998125570",
    "text" : "America. https:\/\/t.co\/aj7SE7ZjUA",
    "id" : 537089736998125570,
    "created_at" : "2014-11-25 03:45:46 +0000",
    "user" : {
      "name" : "Zeddonymous",
      "screen_name" : "ZeddRebel",
      "protected" : false,
      "id_str" : "322735335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572410111860035584\/UUy1umQz_normal.jpeg",
      "id" : 322735335,
      "verified" : false
    }
  },
  "id" : 537092710000119808,
  "created_at" : "2014-11-25 03:57:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus Johnston",
      "screen_name" : "studentactivism",
      "indices" : [ 3, 19 ],
      "id_str" : "20919626",
      "id" : 20919626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537066955451027456",
  "text" : "RT @studentactivism: BREAKING: Shit is fucked up and bullshit.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537066709069594624",
    "text" : "BREAKING: Shit is fucked up and bullshit.",
    "id" : 537066709069594624,
    "created_at" : "2014-11-25 02:14:16 +0000",
    "user" : {
      "name" : "Angus Johnston",
      "screen_name" : "studentactivism",
      "protected" : false,
      "id_str" : "20919626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529088043370573825\/9s_WXZK6_normal.jpeg",
      "id" : 20919626,
      "verified" : false
    }
  },
  "id" : 537066955451027456,
  "created_at" : "2014-11-25 02:15:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Werner Vogels",
      "screen_name" : "Werner",
      "indices" : [ 0, 7 ],
      "id_str" : "113963",
      "id" : 113963
    }, {
      "name" : "Ezra Zygmuntowicz",
      "screen_name" : "ezmobius",
      "indices" : [ 8, 17 ],
      "id_str" : "3560241",
      "id" : 3560241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/0EnIvU8vXh",
      "expanded_url" : "http:\/\/github.com\/qrush\/lambda-function-wrapper-ruby",
      "display_url" : "github.com\/qrush\/lambda-f\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "534154101265678336",
  "geo" : { },
  "id_str" : "537063627144974336",
  "in_reply_to_user_id" : 113963,
  "text" : "@Werner @ezmobius Ruby! http:\/\/t.co\/0EnIvU8vXh",
  "id" : 537063627144974336,
  "in_reply_to_status_id" : 534154101265678336,
  "created_at" : "2014-11-25 02:02:01 +0000",
  "in_reply_to_screen_name" : "Werner",
  "in_reply_to_user_id_str" : "113963",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M-A",
      "screen_name" : "MileHighMusik",
      "indices" : [ 0, 14 ],
      "id_str" : "184501661",
      "id" : 184501661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537054385977950209",
  "geo" : { },
  "id_str" : "537054850781945856",
  "in_reply_to_user_id" : 184501661,
  "text" : "@MileHighMusik holy shit how did I not know about the bourbon wings",
  "id" : 537054850781945856,
  "in_reply_to_status_id" : 537054385977950209,
  "created_at" : "2014-11-25 01:27:09 +0000",
  "in_reply_to_screen_name" : "MileHighMusik",
  "in_reply_to_user_id_str" : "184501661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Brown",
      "screen_name" : "ryan_sb",
      "indices" : [ 0, 8 ],
      "id_str" : "165290994",
      "id" : 165290994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537040042301341696",
  "geo" : { },
  "id_str" : "537054107417071617",
  "in_reply_to_user_id" : 165290994,
  "text" : "@ryan_sb can help with deploying\/transferring etc later this week. Thanks for the reminder.",
  "id" : 537054107417071617,
  "in_reply_to_status_id" : 537040042301341696,
  "created_at" : "2014-11-25 01:24:11 +0000",
  "in_reply_to_screen_name" : "ryan_sb",
  "in_reply_to_user_id_str" : "165290994",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zac Gorman",
      "screen_name" : "zacgormania",
      "indices" : [ 3, 15 ],
      "id_str" : "237985689",
      "id" : 237985689
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/zacgormania\/status\/537042174396088321\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/sl1nfgvfEp",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B3P1AvrCcAAupDG.png",
      "id_str" : "537042173733007360",
      "id" : 537042173733007360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B3P1AvrCcAAupDG.png",
      "sizes" : [ {
        "h" : 1026,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1026,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/sl1nfgvfEp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/GGtqyu4c3T",
      "expanded_url" : "http:\/\/magicalgametime.com\/post\/103503479990",
      "display_url" : "magicalgametime.com\/post\/103503479\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537052802929803264",
  "text" : "RT @zacgormania: I haven't done an MGT comic in so long but I drew one about Master Hand. See it big here http:\/\/t.co\/GGtqyu4c3T http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/zacgormania\/status\/537042174396088321\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/sl1nfgvfEp",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B3P1AvrCcAAupDG.png",
        "id_str" : "537042173733007360",
        "id" : 537042173733007360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B3P1AvrCcAAupDG.png",
        "sizes" : [ {
          "h" : 1026,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 615,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1026,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/sl1nfgvfEp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/GGtqyu4c3T",
        "expanded_url" : "http:\/\/magicalgametime.com\/post\/103503479990",
        "display_url" : "magicalgametime.com\/post\/103503479\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "537042174396088321",
    "text" : "I haven't done an MGT comic in so long but I drew one about Master Hand. See it big here http:\/\/t.co\/GGtqyu4c3T http:\/\/t.co\/sl1nfgvfEp",
    "id" : 537042174396088321,
    "created_at" : "2014-11-25 00:36:46 +0000",
    "user" : {
      "name" : "Zac Gorman",
      "screen_name" : "zacgormania",
      "protected" : false,
      "id_str" : "237985689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530760979781406720\/qyDRpLnB_normal.jpeg",
      "id" : 237985689,
      "verified" : false
    }
  },
  "id" : 537052802929803264,
  "created_at" : "2014-11-25 01:19:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Brown",
      "screen_name" : "ryan_sb",
      "indices" : [ 0, 8 ],
      "id_str" : "165290994",
      "id" : 165290994
    }, {
      "name" : "Jo Liss",
      "screen_name" : "jo_liss",
      "indices" : [ 56, 64 ],
      "id_str" : "223422672",
      "id" : 223422672
    }, {
      "name" : "Nico Gulden",
      "screen_name" : "ngulden",
      "indices" : [ 69, 77 ],
      "id_str" : "30441261",
      "id" : 30441261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537040042301341696",
  "geo" : { },
  "id_str" : "537050167568920577",
  "in_reply_to_user_id" : 165290994,
  "text" : "@ryan_sb Added to the owners for the org. Also promoted @jo_liss and @ngulden since they had write access to everything.",
  "id" : 537050167568920577,
  "in_reply_to_status_id" : 537040042301341696,
  "created_at" : "2014-11-25 01:08:32 +0000",
  "in_reply_to_screen_name" : "ryan_sb",
  "in_reply_to_user_id_str" : "165290994",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 0, 12 ],
      "id_str" : "158098704",
      "id" : 158098704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537037277508411392",
  "geo" : { },
  "id_str" : "537038839588454400",
  "in_reply_to_user_id" : 158098704,
  "text" : "@mikemikemac holy shit",
  "id" : 537038839588454400,
  "in_reply_to_status_id" : 537037277508411392,
  "created_at" : "2014-11-25 00:23:31 +0000",
  "in_reply_to_screen_name" : "mikemikemac",
  "in_reply_to_user_id_str" : "158098704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Brown",
      "screen_name" : "ryan_sb",
      "indices" : [ 0, 8 ],
      "id_str" : "165290994",
      "id" : 165290994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537024034974994432",
  "geo" : { },
  "id_str" : "537038426751524864",
  "in_reply_to_user_id" : 165290994,
  "text" : "@ryan_sb haven\u2019t had a chance. Up for it? There\u2019s a bunch of PRs now. Maybe a team would be in order?",
  "id" : 537038426751524864,
  "in_reply_to_status_id" : 537024034974994432,
  "created_at" : "2014-11-25 00:21:53 +0000",
  "in_reply_to_screen_name" : "ryan_sb",
  "in_reply_to_user_id_str" : "165290994",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537004873745969153",
  "text" : "Clouds are moving so fast off the lake that looking up makes me dizzy",
  "id" : 537004873745969153,
  "created_at" : "2014-11-24 22:08:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/536986036694310913\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/1wDfZqZqNp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3PB9F-CcAA_tnQ.jpg",
      "id_str" : "536986035905785856",
      "id" : 536986035905785856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3PB9F-CcAA_tnQ.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/1wDfZqZqNp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536986036694310913",
  "text" : "itunes_submission_process.jpg http:\/\/t.co\/1wDfZqZqNp",
  "id" : 536986036694310913,
  "created_at" : "2014-11-24 20:53:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "any other name",
      "screen_name" : "direhellswan",
      "indices" : [ 3, 16 ],
      "id_str" : "237596959",
      "id" : 237596959
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/direhellswan\/status\/536979434449158145\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/ht52aSuw1V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3O78zMCQAAZKnx.jpg",
      "id_str" : "536979433794453504",
      "id" : 536979433794453504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3O78zMCQAAZKnx.jpg",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ht52aSuw1V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536980312597618688",
  "text" : "RT @direhellswan: what cleverly hidden mystery lies within http:\/\/t.co\/ht52aSuw1V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/direhellswan\/status\/536979434449158145\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/ht52aSuw1V",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3O78zMCQAAZKnx.jpg",
        "id_str" : "536979433794453504",
        "id" : 536979433794453504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3O78zMCQAAZKnx.jpg",
        "sizes" : [ {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ht52aSuw1V"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "536967332648992769",
    "geo" : { },
    "id_str" : "536979434449158145",
    "in_reply_to_user_id" : 237596959,
    "text" : "what cleverly hidden mystery lies within http:\/\/t.co\/ht52aSuw1V",
    "id" : 536979434449158145,
    "in_reply_to_status_id" : 536967332648992769,
    "created_at" : "2014-11-24 20:27:28 +0000",
    "in_reply_to_screen_name" : "direhellswan",
    "in_reply_to_user_id_str" : "237596959",
    "user" : {
      "name" : "any other name",
      "screen_name" : "direhellswan",
      "protected" : false,
      "id_str" : "237596959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568476983433388032\/1befi0Ex_normal.jpeg",
      "id" : 237596959,
      "verified" : false
    }
  },
  "id" : 536980312597618688,
  "created_at" : "2014-11-24 20:30:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 42, 51 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/SOXevTJCcV",
      "expanded_url" : "http:\/\/demoduck.com\/2014\/11\/business-video-basecamp\/",
      "display_url" : "demoduck.com\/2014\/11\/busine\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "536975636921720833",
  "text" : "Truth: \"Because screencasts are boring\" - @shildner http:\/\/t.co\/SOXevTJCcV",
  "id" : 536975636921720833,
  "created_at" : "2014-11-24 20:12:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536918300929048577",
  "text" : "Because of the incredible speed of your rocket",
  "id" : 536918300929048577,
  "created_at" : "2014-11-24 16:24:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Melissa Virus",
      "screen_name" : "0xabad1dea",
      "indices" : [ 3, 14 ],
      "id_str" : "126030998",
      "id" : 126030998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/OWGxkHklS6",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/11\/24\/us\/boy-12-dies-after-being-shot-by-cleveland-police-officer.html",
      "display_url" : "nytimes.com\/2014\/11\/24\/us\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "536730346683760640",
  "text" : "RT @0xabad1dea: 12yo in Cleveland shot and killed by police over toy pistol *after police were advised it was probably a toy* http:\/\/t.co\/O\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/OWGxkHklS6",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/11\/24\/us\/boy-12-dies-after-being-shot-by-cleveland-police-officer.html",
        "display_url" : "nytimes.com\/2014\/11\/24\/us\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "536699329629937664",
    "text" : "12yo in Cleveland shot and killed by police over toy pistol *after police were advised it was probably a toy* http:\/\/t.co\/OWGxkHklS6",
    "id" : 536699329629937664,
    "created_at" : "2014-11-24 01:54:26 +0000",
    "user" : {
      "name" : "The Melissa Virus",
      "screen_name" : "0xabad1dea",
      "protected" : false,
      "id_str" : "126030998",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528398279571038208\/Zc_ZWgUI_normal.png",
      "id" : 126030998,
      "verified" : false
    }
  },
  "id" : 536730346683760640,
  "created_at" : "2014-11-24 03:57:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 0, 7 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536728794170929153",
  "geo" : { },
  "id_str" : "536728923782930432",
  "in_reply_to_user_id" : 6981492,
  "text" : "@ftrain Pisstules",
  "id" : 536728923782930432,
  "in_reply_to_status_id" : 536728794170929153,
  "created_at" : "2014-11-24 03:52:02 +0000",
  "in_reply_to_screen_name" : "ftrain",
  "in_reply_to_user_id_str" : "6981492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 3, 11 ],
      "id_str" : "20844341",
      "id" : 20844341
    }, {
      "name" : "Tiffany Zhong",
      "screen_name" : "tzhongg",
      "indices" : [ 56, 64 ],
      "id_str" : "2458844640",
      "id" : 2458844640
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tzhongg\/status\/536565474041937921\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/OWMqYZItQo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3JDctGCQAEcbG-.jpg",
      "id_str" : "536565466030817281",
      "id" : 536565466030817281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3JDctGCQAEcbG-.jpg",
      "sizes" : [ {
        "h" : 878,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1021,
        "resize" : "fit",
        "w" : 697
      }, {
        "h" : 1021,
        "resize" : "fit",
        "w" : 697
      }, {
        "h" : 498,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OWMqYZItQo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536725318296285184",
  "text" : "RT @patio11: Friendly reminder to raise your rates: RT \u201C@tzhongg: Friend made a list of top internship offers \uD83D\uDCB0 http:\/\/t.co\/OWMqYZItQo\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tiffany Zhong",
        "screen_name" : "tzhongg",
        "indices" : [ 43, 51 ],
        "id_str" : "2458844640",
        "id" : 2458844640
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tzhongg\/status\/536565474041937921\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/OWMqYZItQo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3JDctGCQAEcbG-.jpg",
        "id_str" : "536565466030817281",
        "id" : 536565466030817281,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3JDctGCQAEcbG-.jpg",
        "sizes" : [ {
          "h" : 878,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1021,
          "resize" : "fit",
          "w" : 697
        }, {
          "h" : 1021,
          "resize" : "fit",
          "w" : 697
        }, {
          "h" : 498,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OWMqYZItQo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "536565474041937921",
    "geo" : { },
    "id_str" : "536725202210549760",
    "in_reply_to_user_id" : 2458844640,
    "text" : "Friendly reminder to raise your rates: RT \u201C@tzhongg: Friend made a list of top internship offers \uD83D\uDCB0 http:\/\/t.co\/OWMqYZItQo\u201D",
    "id" : 536725202210549760,
    "in_reply_to_status_id" : 536565474041937921,
    "created_at" : "2014-11-24 03:37:14 +0000",
    "in_reply_to_screen_name" : "tzhongg",
    "in_reply_to_user_id_str" : "2458844640",
    "user" : {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "protected" : false,
      "id_str" : "20844341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476049306072276993\/s9QMnPC5_normal.jpeg",
      "id" : 20844341,
      "verified" : false
    }
  },
  "id" : 536725318296285184,
  "created_at" : "2014-11-24 03:37:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jessicard",
      "screen_name" : "jessicard",
      "indices" : [ 0, 10 ],
      "id_str" : "253464752",
      "id" : 253464752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536674360744890369",
  "geo" : { },
  "id_str" : "536677677000704002",
  "in_reply_to_user_id" : 253464752,
  "text" : "@jessicard we\u2019re quaranto and aquaranto if you can navigate the twisty passages to adding a friend",
  "id" : 536677677000704002,
  "in_reply_to_status_id" : 536674360744890369,
  "created_at" : "2014-11-24 00:28:23 +0000",
  "in_reply_to_screen_name" : "jessicard",
  "in_reply_to_user_id_str" : "253464752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 48, 58 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536667848467558400",
  "geo" : { },
  "id_str" : "536667995322339328",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents haha. I think it\u2019s aquaranto for @aquaranto",
  "id" : 536667995322339328,
  "in_reply_to_status_id" : 536667848467558400,
  "created_at" : "2014-11-23 23:49:55 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Jahchan",
      "screen_name" : "rudy",
      "indices" : [ 3, 8 ],
      "id_str" : "779715",
      "id" : 779715
    }, {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 37, 44 ],
      "id_str" : "9038902",
      "id" : 9038902
    }, {
      "name" : "Jess Eldredge",
      "screen_name" : "jessabean",
      "indices" : [ 111, 121 ],
      "id_str" : "15735952",
      "id" : 15735952
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rudy\/status\/536568878923386881\/photo\/1",
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/7MPUC0FiCC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3JGjVICYAAyfrS.png",
      "id_str" : "536568878390730752",
      "id" : 536568878390730752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3JGjVICYAAyfrS.png",
      "sizes" : [ {
        "h" : 465,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 849,
        "resize" : "fit",
        "w" : 1094
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 794,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7MPUC0FiCC"
    } ],
    "hashtags" : [ {
      "text" : "sketchnotes",
      "indices" : [ 20, 32 ]
    }, {
      "text" : "rubyconf",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/qUDNVxBPiO",
      "expanded_url" : "https:\/\/raw.githubusercontent.com\/rudyjahchan\/sketchnotes\/master\/2014\/rubyconf\/searls-keynote.png",
      "display_url" : "raw.githubusercontent.com\/rudyjahchan\/sk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "536661744136232960",
  "text" : "RT @rudy: Redrew my #sketchnotes for @searls\u2019 great #rubyconf talk (hi-res here): https:\/\/t.co\/qUDNVxBPiO (cc: @jessabean) http:\/\/t.co\/7MPU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Justin Searls",
        "screen_name" : "searls",
        "indices" : [ 27, 34 ],
        "id_str" : "9038902",
        "id" : 9038902
      }, {
        "name" : "Jess Eldredge",
        "screen_name" : "jessabean",
        "indices" : [ 101, 111 ],
        "id_str" : "15735952",
        "id" : 15735952
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rudy\/status\/536568878923386881\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/7MPUC0FiCC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3JGjVICYAAyfrS.png",
        "id_str" : "536568878390730752",
        "id" : 536568878390730752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3JGjVICYAAyfrS.png",
        "sizes" : [ {
          "h" : 465,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 849,
          "resize" : "fit",
          "w" : 1094
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 794,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7MPUC0FiCC"
      } ],
      "hashtags" : [ {
        "text" : "sketchnotes",
        "indices" : [ 10, 22 ]
      }, {
        "text" : "rubyconf",
        "indices" : [ 42, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/qUDNVxBPiO",
        "expanded_url" : "https:\/\/raw.githubusercontent.com\/rudyjahchan\/sketchnotes\/master\/2014\/rubyconf\/searls-keynote.png",
        "display_url" : "raw.githubusercontent.com\/rudyjahchan\/sk\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "536568878923386881",
    "text" : "Redrew my #sketchnotes for @searls\u2019 great #rubyconf talk (hi-res here): https:\/\/t.co\/qUDNVxBPiO (cc: @jessabean) http:\/\/t.co\/7MPUC0FiCC",
    "id" : 536568878923386881,
    "created_at" : "2014-11-23 17:16:04 +0000",
    "user" : {
      "name" : "Rudy Jahchan",
      "screen_name" : "rudy",
      "protected" : false,
      "id_str" : "779715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531622034912980992\/dJlKi-SN_normal.jpeg",
      "id" : 779715,
      "verified" : false
    }
  },
  "id" : 536661744136232960,
  "created_at" : "2014-11-23 23:25:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tow truck central",
      "screen_name" : "duh_nellll",
      "indices" : [ 0, 11 ],
      "id_str" : "146513248",
      "id" : 146513248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536547302228254720",
  "geo" : { },
  "id_str" : "536547364769497088",
  "in_reply_to_user_id" : 5743852,
  "text" : "@duh_nellll or maybe I\u2019m thinking the Light that came after",
  "id" : 536547364769497088,
  "in_reply_to_status_id" : 536547302228254720,
  "created_at" : "2014-11-23 15:50:34 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tow truck central",
      "screen_name" : "duh_nellll",
      "indices" : [ 0, 11 ],
      "id_str" : "146513248",
      "id" : 146513248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536547192463687681",
  "geo" : { },
  "id_str" : "536547302228254720",
  "in_reply_to_user_id" : 146513248,
  "text" : "@duh_nellll the Rochester one from last year was weiiirrd",
  "id" : 536547302228254720,
  "in_reply_to_status_id" : 536547192463687681,
  "created_at" : "2014-11-23 15:50:20 +0000",
  "in_reply_to_screen_name" : "duh_nellll",
  "in_reply_to_user_id_str" : "146513248",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jenn",
      "screen_name" : "jennschiffer",
      "indices" : [ 0, 13 ],
      "id_str" : "12524622",
      "id" : 12524622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536382701016985600",
  "geo" : { },
  "id_str" : "536386961284423680",
  "in_reply_to_user_id" : 12524622,
  "text" : "@jennschiffer how did you get skrillex to dj at a karaoke bar (hi Steve!)",
  "id" : 536386961284423680,
  "in_reply_to_status_id" : 536382701016985600,
  "created_at" : "2014-11-23 05:13:11 +0000",
  "in_reply_to_screen_name" : "jennschiffer",
  "in_reply_to_user_id_str" : "12524622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Mordaunt",
      "screen_name" : "juliamordaunt",
      "indices" : [ 0, 14 ],
      "id_str" : "15641417",
      "id" : 15641417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536357779452469248",
  "geo" : { },
  "id_str" : "536360449189482497",
  "in_reply_to_user_id" : 15641417,
  "text" : "@juliamordaunt Pop",
  "id" : 536360449189482497,
  "in_reply_to_status_id" : 536357779452469248,
  "created_at" : "2014-11-23 03:27:50 +0000",
  "in_reply_to_screen_name" : "juliamordaunt",
  "in_reply_to_user_id_str" : "15641417",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 3, 6 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/HnTJOKtUBS",
      "expanded_url" : "http:\/\/apne.ws\/1xOYcN2",
      "display_url" : "apne.ws\/1xOYcN2"
    } ]
  },
  "geo" : { },
  "id_str" : "536357034870833152",
  "text" : "RT @AP: Naked man falls through women's bathroom ceiling at Boston airport, runs out and bites elderly man: http:\/\/t.co\/HnTJOKtUBS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/HnTJOKtUBS",
        "expanded_url" : "http:\/\/apne.ws\/1xOYcN2",
        "display_url" : "apne.ws\/1xOYcN2"
      } ]
    },
    "geo" : { },
    "id_str" : "536353921426808832",
    "text" : "Naked man falls through women's bathroom ceiling at Boston airport, runs out and bites elderly man: http:\/\/t.co\/HnTJOKtUBS",
    "id" : 536353921426808832,
    "created_at" : "2014-11-23 03:01:54 +0000",
    "user" : {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "protected" : false,
      "id_str" : "51241574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461964160838803457\/8z9FImcv_normal.png",
      "id" : 51241574,
      "verified" : true
    }
  },
  "id" : 536357034870833152,
  "created_at" : "2014-11-23 03:14:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hoepfinger",
      "screen_name" : "FrackingSabres",
      "indices" : [ 0, 15 ],
      "id_str" : "248748749",
      "id" : 248748749
    }, {
      "name" : "Beardo",
      "screen_name" : "Mechaphil",
      "indices" : [ 16, 26 ],
      "id_str" : "250785234",
      "id" : 250785234
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/536351538617131010\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/pI5SqVzldA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3GA1iXCUAEl-tM.jpg",
      "id_str" : "536351487878647809",
      "id" : 536351487878647809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3GA1iXCUAEl-tM.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pI5SqVzldA"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/536351538617131010\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/pI5SqVzldA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3GA4L3CIAAKQ9d.jpg",
      "id_str" : "536351533378445312",
      "id" : 536351533378445312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3GA4L3CIAAKQ9d.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pI5SqVzldA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536346107094499328",
  "geo" : { },
  "id_str" : "536351538617131010",
  "in_reply_to_user_id" : 248748749,
  "text" : "@FrackingSabres @Mechaphil I found this in the kids section at B&amp;N while my 1 year old was running around it http:\/\/t.co\/pI5SqVzldA",
  "id" : 536351538617131010,
  "in_reply_to_status_id" : 536346107094499328,
  "created_at" : "2014-11-23 02:52:26 +0000",
  "in_reply_to_screen_name" : "FrackingSabres",
  "in_reply_to_user_id_str" : "248748749",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536350191310225408",
  "text" : "That review literally broke me",
  "id" : 536350191310225408,
  "created_at" : "2014-11-23 02:47:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 3, 9 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vrunt\/status\/447500276648652801\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/473fhXpgMR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjXXIWgIQAEs0Ge.jpg",
      "id_str" : "447500276472496129",
      "id" : 447500276472496129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjXXIWgIQAEs0Ge.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/473fhXpgMR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536349949886083072",
  "text" : "RT @vrunt: this is why you always check the reviews before ordering one thousand live crickets http:\/\/t.co\/473fhXpgMR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vrunt\/status\/447500276648652801\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/473fhXpgMR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjXXIWgIQAEs0Ge.jpg",
        "id_str" : "447500276472496129",
        "id" : 447500276472496129,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjXXIWgIQAEs0Ge.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/473fhXpgMR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "447500276648652801",
    "text" : "this is why you always check the reviews before ordering one thousand live crickets http:\/\/t.co\/473fhXpgMR",
    "id" : 447500276648652801,
    "created_at" : "2014-03-22 22:29:14 +0000",
    "user" : {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "protected" : false,
      "id_str" : "15062828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566801374143586305\/yApDWRcm_normal.jpeg",
      "id" : 15062828,
      "verified" : false
    }
  },
  "id" : 536349949886083072,
  "created_at" : "2014-11-23 02:46:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vince Eckert",
      "screen_name" : "vinceness",
      "indices" : [ 0, 10 ],
      "id_str" : "21607190",
      "id" : 21607190
    }, {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 42, 48 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536342767790989312",
  "geo" : { },
  "id_str" : "536349860065054722",
  "in_reply_to_user_id" : 21607190,
  "text" : "@vinceness oh man is there an underground @vrunt feed",
  "id" : 536349860065054722,
  "in_reply_to_status_id" : 536342767790989312,
  "created_at" : "2014-11-23 02:45:46 +0000",
  "in_reply_to_screen_name" : "vinceness",
  "in_reply_to_user_id_str" : "21607190",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Claghorn",
      "screen_name" : "georgeclaghorn",
      "indices" : [ 0, 15 ],
      "id_str" : "35202006",
      "id" : 35202006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536303806611722240",
  "geo" : { },
  "id_str" : "536313321108942848",
  "in_reply_to_user_id" : 35202006,
  "text" : "@georgeclaghorn sheesh",
  "id" : 536313321108942848,
  "in_reply_to_status_id" : 536303806611722240,
  "created_at" : "2014-11-23 00:20:34 +0000",
  "in_reply_to_screen_name" : "georgeclaghorn",
  "in_reply_to_user_id_str" : "35202006",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "keeran",
      "screen_name" : "keeran",
      "indices" : [ 0, 7 ],
      "id_str" : "10075872",
      "id" : 10075872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536145587167842305",
  "geo" : { },
  "id_str" : "536146549915398145",
  "in_reply_to_user_id" : 10075872,
  "text" : "@keeran The dynamo paper is fantastic. And lol.",
  "id" : 536146549915398145,
  "in_reply_to_status_id" : 536145587167842305,
  "created_at" : "2014-11-22 13:17:53 +0000",
  "in_reply_to_screen_name" : "keeran",
  "in_reply_to_user_id_str" : "10075872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536141810406412288",
  "text" : "Stories just now coming out of people being buried alive in cars on roads I have been on many times and it\u2019s fucking terrifying.",
  "id" : 536141810406412288,
  "created_at" : "2014-11-22 12:59:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Werner Vogels",
      "screen_name" : "Werner",
      "indices" : [ 0, 7 ],
      "id_str" : "113963",
      "id" : 113963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/fMrCPhWcm8",
      "expanded_url" : "https:\/\/github.com\/qrush\/lambda-function-wrapper-ruby",
      "display_url" : "github.com\/qrush\/lambda-f\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "536038230680801280",
  "geo" : { },
  "id_str" : "536038712946085888",
  "in_reply_to_user_id" : 113963,
  "text" : "@Werner I managed to get Ruby working last night. Would be neat to support Heroku\u2019s build packs for any language. https:\/\/t.co\/fMrCPhWcm8",
  "id" : 536038712946085888,
  "in_reply_to_status_id" : 536038230680801280,
  "created_at" : "2014-11-22 06:09:22 +0000",
  "in_reply_to_screen_name" : "Werner",
  "in_reply_to_user_id_str" : "113963",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Mark Zalar",
      "screen_name" : "ZalarMark",
      "indices" : [ 15, 25 ],
      "id_str" : "483153848",
      "id" : 483153848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536013211251003392",
  "geo" : { },
  "id_str" : "536013976362971137",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents @ZalarMark we need to be wii u friends",
  "id" : 536013976362971137,
  "in_reply_to_status_id" : 536013211251003392,
  "created_at" : "2014-11-22 04:31:05 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535878636805844993",
  "geo" : { },
  "id_str" : "535882865696059392",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k ruby penn &amp; teller act",
  "id" : 535882865696059392,
  "in_reply_to_status_id" : 535878636805844993,
  "created_at" : "2014-11-21 19:50:06 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535874383676735489",
  "geo" : { },
  "id_str" : "535880703192612865",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik have mercy!",
  "id" : 535880703192612865,
  "in_reply_to_status_id" : 535874383676735489,
  "created_at" : "2014-11-21 19:41:30 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/NCrYdTzxDN",
      "expanded_url" : "http:\/\/kotaku.com\/pokemon-omega-ruby-and-alpha-sapphire-bundled-together-1651196825",
      "display_url" : "kotaku.com\/pokemon-omega-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535871384241848320",
  "text" : "Not sure what took Nintendo this long, but genius idea to sell both new Pokemon games in one box: http:\/\/t.co\/NCrYdTzxDN",
  "id" : 535871384241848320,
  "created_at" : "2014-11-21 19:04:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 27, 41 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/535867897915400192\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/fhWJMurqEk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2_JA2bCYAA9B8Z.png",
      "id_str" : "535867897126477824",
      "id" : 535867897126477824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2_JA2bCYAA9B8Z.png",
      "sizes" : [ {
        "h" : 588,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1156
      }, {
        "h" : 195,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fhWJMurqEk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535867897915400192",
  "text" : "Hipster logo rebranding of @coworkbuffalo: Tupper &amp; Main http:\/\/t.co\/fhWJMurqEk",
  "id" : 535867897915400192,
  "created_at" : "2014-11-21 18:50:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ANDREW W.K.",
      "screen_name" : "AndrewWK",
      "indices" : [ 3, 12 ],
      "id_str" : "42744294",
      "id" : 42744294
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AndrewWK\/status\/535855229242056704\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/A63Fvkh5lY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B25mS20CIAEjcF7.png",
      "id_str" : "535477879841103873",
      "id" : 535477879841103873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B25mS20CIAEjcF7.png",
      "sizes" : [ {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 762
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 762
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/A63Fvkh5lY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535861845442441216",
  "text" : "RT @AndrewWK: When it's time for story time, we'll always read it hard! BOOKS ARE PARTY. http:\/\/t.co\/A63Fvkh5lY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AndrewWK\/status\/535855229242056704\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/A63Fvkh5lY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B25mS20CIAEjcF7.png",
        "id_str" : "535477879841103873",
        "id" : 535477879841103873,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B25mS20CIAEjcF7.png",
        "sizes" : [ {
          "h" : 341,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 766,
          "resize" : "fit",
          "w" : 762
        }, {
          "h" : 766,
          "resize" : "fit",
          "w" : 762
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/A63Fvkh5lY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535855229242056704",
    "text" : "When it's time for story time, we'll always read it hard! BOOKS ARE PARTY. http:\/\/t.co\/A63Fvkh5lY",
    "id" : 535855229242056704,
    "created_at" : "2014-11-21 18:00:17 +0000",
    "user" : {
      "name" : "ANDREW W.K.",
      "screen_name" : "AndrewWK",
      "protected" : false,
      "id_str" : "42744294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474004600823894016\/-Zy1asQQ_normal.png",
      "id" : 42744294,
      "verified" : true
    }
  },
  "id" : 535861845442441216,
  "created_at" : "2014-11-21 18:26:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535846996486389760",
  "geo" : { },
  "id_str" : "535847129663934464",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 *you* can use git transparently, locally and push up to a svn server. check out git-svn.",
  "id" : 535847129663934464,
  "in_reply_to_status_id" : 535846996486389760,
  "created_at" : "2014-11-21 17:28:05 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Yang",
      "screen_name" : "kai3x5",
      "indices" : [ 0, 7 ],
      "id_str" : "2252363606",
      "id" : 2252363606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535842455950589952",
  "geo" : { },
  "id_str" : "535842684116926464",
  "in_reply_to_user_id" : 2252363606,
  "text" : "@kai3x5 yeah it's not a joke in some areas, and some of the major highways are still closed. however the entire city was not hit.",
  "id" : 535842684116926464,
  "in_reply_to_status_id" : 535842455950589952,
  "created_at" : "2014-11-21 17:10:26 +0000",
  "in_reply_to_screen_name" : "kai3x5",
  "in_reply_to_user_id_str" : "2252363606",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/5JlSsTOJWq",
      "expanded_url" : "https:\/\/www.facebook.com\/events\/1538669866349861\/?ref_newsfeed_story_type=regular",
      "display_url" : "facebook.com\/events\/1538669\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535841669183442944",
  "text" : "This is real Buffalo right, here. There's a reason it's the City of Good Neighbors: https:\/\/t.co\/5JlSsTOJWq",
  "id" : 535841669183442944,
  "created_at" : "2014-11-21 17:06:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Yang",
      "screen_name" : "kai3x5",
      "indices" : [ 0, 7 ],
      "id_str" : "2252363606",
      "id" : 2252363606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535839803330158592",
  "geo" : { },
  "id_str" : "535840211385602048",
  "in_reply_to_user_id" : 2252363606,
  "text" : "@kai3x5 downtown and the northern part of the city only got maybe 4-6\" total, so this is a fairly normal storm for us",
  "id" : 535840211385602048,
  "in_reply_to_status_id" : 535839803330158592,
  "created_at" : "2014-11-21 17:00:36 +0000",
  "in_reply_to_screen_name" : "kai3x5",
  "in_reply_to_user_id_str" : "2252363606",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535838676342034432",
  "geo" : { },
  "id_str" : "535839812750569472",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy dude really? isn't there a more important part of the city to plow right now?",
  "id" : 535839812750569472,
  "in_reply_to_status_id" : 535838676342034432,
  "created_at" : "2014-11-21 16:59:01 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/dQIqtwUSgP",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/news\/opinions\/wp\/2014\/11\/21\/friday-rant-six-feet-under-edition\/",
      "display_url" : "washingtonpost.com\/news\/opinions\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535839119205597185",
  "text" : "\u201CWhy would anyone live there?\u201D http:\/\/t.co\/dQIqtwUSgP",
  "id" : 535839119205597185,
  "created_at" : "2014-11-21 16:56:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "indices" : [ 3, 17 ],
      "id_str" : "20104013",
      "id" : 20104013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "https:\/\/t.co\/p3jgjI4Gw3",
      "expanded_url" : "https:\/\/github.com\/qrush\/lambda-function-wrapper-ruby",
      "display_url" : "github.com\/qrush\/lambda-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535819011762552833",
  "text" : "RT @yukihiro_matz: link: qrush\/lambda-function-wrapper-ruby - Run Ruby from AWS Lambda. proof of concept, but it works!\nhttps:\/\/t.co\/p3jgjI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/p3jgjI4Gw3",
        "expanded_url" : "https:\/\/github.com\/qrush\/lambda-function-wrapper-ruby",
        "display_url" : "github.com\/qrush\/lambda-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "535818949993058305",
    "text" : "link: qrush\/lambda-function-wrapper-ruby - Run Ruby from AWS Lambda. proof of concept, but it works!\nhttps:\/\/t.co\/p3jgjI4Gw3",
    "id" : 535818949993058305,
    "created_at" : "2014-11-21 15:36:07 +0000",
    "user" : {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "protected" : false,
      "id_str" : "20104013",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511244255294001152\/v5phEU1O_normal.jpeg",
      "id" : 20104013,
      "verified" : false
    }
  },
  "id" : 535819011762552833,
  "created_at" : "2014-11-21 15:36:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate West",
      "screen_name" : "nate_west",
      "indices" : [ 0, 10 ],
      "id_str" : "942661",
      "id" : 942661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535815757129469952",
  "geo" : { },
  "id_str" : "535815905238740992",
  "in_reply_to_user_id" : 942661,
  "text" : "@nate_west really only south buffalo and the southtowns was hit bad. downtown, north of the city had maybe 4-6\"",
  "id" : 535815905238740992,
  "in_reply_to_status_id" : 535815757129469952,
  "created_at" : "2014-11-21 15:24:01 +0000",
  "in_reply_to_screen_name" : "nate_west",
  "in_reply_to_user_id_str" : "942661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 8, 22 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535814947289055232",
  "text" : "NOTICE: @coworkbuffalo is open today and there are cookies. Happy Friday!",
  "id" : 535814947289055232,
  "created_at" : "2014-11-21 15:20:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535664136798359553",
  "geo" : { },
  "id_str" : "535664375994912768",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox funny I just did this tonight to edit a repo description",
  "id" : 535664375994912768,
  "in_reply_to_status_id" : 535664136798359553,
  "created_at" : "2014-11-21 05:21:54 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Greg",
      "screen_name" : "dannygreg",
      "indices" : [ 3, 13 ],
      "id_str" : "1764931",
      "id" : 1764931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/oyBHqXp44k",
      "expanded_url" : "https:\/\/github.com\/dotnet\/corefx\/pull\/31",
      "display_url" : "github.com\/dotnet\/corefx\/\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/crgLZCFiRR",
      "expanded_url" : "http:\/\/opensource.apple.com",
      "display_url" : "opensource.apple.com"
    } ]
  },
  "geo" : { },
  "id_str" : "535654271098703872",
  "text" : "RT @dannygreg: MS open source 2014: accepting pull requests on GitHub: https:\/\/t.co\/oyBHqXp44k.\n\nApple? Throwing shit over a wall: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/oyBHqXp44k",
        "expanded_url" : "https:\/\/github.com\/dotnet\/corefx\/pull\/31",
        "display_url" : "github.com\/dotnet\/corefx\/\u2026"
      }, {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/crgLZCFiRR",
        "expanded_url" : "http:\/\/opensource.apple.com",
        "display_url" : "opensource.apple.com"
      } ]
    },
    "geo" : { },
    "id_str" : "535653895683334144",
    "text" : "MS open source 2014: accepting pull requests on GitHub: https:\/\/t.co\/oyBHqXp44k.\n\nApple? Throwing shit over a wall: http:\/\/t.co\/crgLZCFiRR",
    "id" : 535653895683334144,
    "created_at" : "2014-11-21 04:40:15 +0000",
    "user" : {
      "name" : "Danny Greg",
      "screen_name" : "dannygreg",
      "protected" : false,
      "id_str" : "1764931",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000713442866\/93b8333a9964cbf87c8cddd157acc2e9_normal.jpeg",
      "id" : 1764931,
      "verified" : false
    }
  },
  "id" : 535654271098703872,
  "created_at" : "2014-11-21 04:41:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/mVW5NO5BrC",
      "expanded_url" : "http:\/\/guides.rubygems.org\/publishing\/#serving-your-own-gems",
      "display_url" : "guides.rubygems.org\/publishing\/#se\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535649319445999616",
  "text" : "Periodic reminder to please set allowed_push_host on private gems so you don't accidentally push them http:\/\/t.co\/mVW5NO5BrC",
  "id" : 535649319445999616,
  "created_at" : "2014-11-21 04:22:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/PQNZpH7gox",
      "expanded_url" : "https:\/\/github.com\/mruby\/mruby\/blob\/master\/mrbgems\/default.gembox",
      "display_url" : "github.com\/mruby\/mruby\/bl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535645343770099712",
  "text" : "\"And is this what you wanted \/ to live in a house that is haunted\" https:\/\/t.co\/PQNZpH7gox",
  "id" : 535645343770099712,
  "created_at" : "2014-11-21 04:06:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 15, 28 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/535644367059316736\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/s2cUB9mCnY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B279togCEAA_J1K.png",
      "id_str" : "535644366111379456",
      "id" : 535644366111379456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B279togCEAA_J1K.png",
      "sizes" : [ {
        "h" : 217,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1248,
        "resize" : "fit",
        "w" : 1948
      } ],
      "display_url" : "pic.twitter.com\/s2cUB9mCnY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535643946924642304",
  "geo" : { },
  "id_str" : "535644367059316736",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents @steveklabnik fixed http:\/\/t.co\/s2cUB9mCnY",
  "id" : 535644367059316736,
  "in_reply_to_status_id" : 535643946924642304,
  "created_at" : "2014-11-21 04:02:23 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 93, 100 ],
      "id_str" : "5186831",
      "id" : 5186831
    }, {
      "name" : "Eric Hammond",
      "screen_name" : "esh",
      "indices" : [ 106, 110 ],
      "id_str" : "606083",
      "id" : 606083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/fMrCPhWcm8",
      "expanded_url" : "https:\/\/github.com\/qrush\/lambda-function-wrapper-ruby",
      "display_url" : "github.com\/qrush\/lambda-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535643850174234626",
  "text" : "Just got Ruby working on AWS Lambda via mruby. Pretty cool stuff! https:\/\/t.co\/fMrCPhWcm8 cc @lsegal, h\/t @esh",
  "id" : 535643850174234626,
  "created_at" : "2014-11-21 04:00:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/HCBRWDgbxD",
      "expanded_url" : "https:\/\/github.com\/mruby\/mruby\/tree\/master\/doc\/mrbgems",
      "display_url" : "github.com\/mruby\/mruby\/tr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535637351544807425",
  "text" : "So apparently there's a \"mrbgems\" that is totally separate from RubyGems? https:\/\/t.co\/HCBRWDgbxD",
  "id" : 535637351544807425,
  "created_at" : "2014-11-21 03:34:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535635691598659585",
  "geo" : { },
  "id_str" : "535636079324315648",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal well you can just upload any code you want, right? so could just upload a Linux Ruby binary right?",
  "id" : 535636079324315648,
  "in_reply_to_status_id" : 535635691598659585,
  "created_at" : "2014-11-21 03:29:27 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535635576628580352",
  "text" : "Most interesting is that ImageMagick is installed, so you could easily wire up a service to process image thumbnails, etc from S3.",
  "id" : 535635576628580352,
  "created_at" : "2014-11-21 03:27:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Wbaz8YStGm",
      "expanded_url" : "https:\/\/github.com\/qrush\/lambda-function-wrapper",
      "display_url" : "github.com\/qrush\/lambda-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535635290136645632",
  "text" : "So looks like AWS Lambda can run Node officially, Perl and Python by some hacks - https:\/\/t.co\/Wbaz8YStGm. No Ruby yet.",
  "id" : 535635290136645632,
  "created_at" : "2014-11-21 03:26:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 0, 12 ],
      "id_str" : "158098704",
      "id" : 158098704
    }, {
      "name" : "Con-Wan Kanobi",
      "screen_name" : "somethingconcon",
      "indices" : [ 13, 29 ],
      "id_str" : "37885397",
      "id" : 37885397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/LbTwx0fvdq",
      "expanded_url" : "https:\/\/twitter.com\/bquarant\/status\/535629282606059521",
      "display_url" : "twitter.com\/bquarant\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "535633300098801664",
  "geo" : { },
  "id_str" : "535633749874991104",
  "in_reply_to_user_id" : 158098704,
  "text" : "@mikemikemac @somethingconcon see https:\/\/t.co\/LbTwx0fvdq and the next tweet",
  "id" : 535633749874991104,
  "in_reply_to_status_id" : 535633300098801664,
  "created_at" : "2014-11-21 03:20:12 +0000",
  "in_reply_to_screen_name" : "mikemikemac",
  "in_reply_to_user_id_str" : "158098704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley needs tats",
      "screen_name" : "rabcyr",
      "indices" : [ 0, 7 ],
      "id_str" : "26157562",
      "id" : 26157562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/DaTYW398wi",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/Buffalo\/wiki\/neighborhoods",
      "display_url" : "reddit.com\/r\/Buffalo\/wiki\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "535631435106099200",
  "geo" : { },
  "id_str" : "535633657298309120",
  "in_reply_to_user_id" : 26157562,
  "text" : "@rabcyr http:\/\/t.co\/DaTYW398wi has a ton of information about nightlife in various neighborhoods.",
  "id" : 535633657298309120,
  "in_reply_to_status_id" : 535631435106099200,
  "created_at" : "2014-11-21 03:19:50 +0000",
  "in_reply_to_screen_name" : "rabcyr",
  "in_reply_to_user_id_str" : "26157562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley needs tats",
      "screen_name" : "rabcyr",
      "indices" : [ 0, 7 ],
      "id_str" : "26157562",
      "id" : 26157562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/p1rQ4MOdF8",
      "expanded_url" : "http:\/\/forecast.io\/#\/f\/42.8854,-78.8785",
      "display_url" : "forecast.io\/#\/f\/42.8854,-7\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "535631070411382784",
  "geo" : { },
  "id_str" : "535631214418227201",
  "in_reply_to_user_id" : 26157562,
  "text" : "@rabcyr NOAA called off the lake effect alert. I'd trust that. http:\/\/t.co\/p1rQ4MOdF8 is clear too.",
  "id" : 535631214418227201,
  "in_reply_to_status_id" : 535631070411382784,
  "created_at" : "2014-11-21 03:10:07 +0000",
  "in_reply_to_screen_name" : "rabcyr",
  "in_reply_to_user_id_str" : "26157562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535630601739440128",
  "text" : "Real life is your med student brother diagnosing your twitter avatar from the year 1432",
  "id" : 535630601739440128,
  "created_at" : "2014-11-21 03:07:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley needs tats",
      "screen_name" : "rabcyr",
      "indices" : [ 0, 7 ],
      "id_str" : "26157562",
      "id" : 26157562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535630428573802496",
  "geo" : { },
  "id_str" : "535630549763624962",
  "in_reply_to_user_id" : 26157562,
  "text" : "@rabcyr north buffalo and downtown is quite normal",
  "id" : 535630549763624962,
  "in_reply_to_status_id" : 535630428573802496,
  "created_at" : "2014-11-21 03:07:29 +0000",
  "in_reply_to_screen_name" : "rabcyr",
  "in_reply_to_user_id_str" : "26157562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535630292963565568",
  "geo" : { },
  "id_str" : "535630453198176256",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant developers are well aware of this",
  "id" : 535630453198176256,
  "in_reply_to_status_id" : 535630292963565568,
  "created_at" : "2014-11-21 03:07:06 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535629734324219905",
  "geo" : { },
  "id_str" : "535630082698514435",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant why do i follow you",
  "id" : 535630082698514435,
  "in_reply_to_status_id" : 535629734324219905,
  "created_at" : "2014-11-21 03:05:37 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535623501609041920",
  "text" : "Doing anything with structured data with Google is just awful.",
  "id" : 535623501609041920,
  "created_at" : "2014-11-21 02:39:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535620477398822912",
  "geo" : { },
  "id_str" : "535621146339598336",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef i believe so",
  "id" : 535621146339598336,
  "in_reply_to_status_id" : 535620477398822912,
  "created_at" : "2014-11-21 02:30:07 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/x04miACbhj",
      "expanded_url" : "http:\/\/upload.wikimedia.org\/wikipedia\/commons\/5\/5e\/Oswald_von_Wolkenstein_2.jpg",
      "display_url" : "upload.wikimedia.org\/wikipedia\/comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535617241778114560",
  "text" : "Current status http:\/\/t.co\/x04miACbhj",
  "id" : 535617241778114560,
  "created_at" : "2014-11-21 02:14:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535511684119793665",
  "geo" : { },
  "id_str" : "535612947146371073",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik ah, catching up now. It's like I've seen this somewhere before.",
  "id" : 535612947146371073,
  "in_reply_to_status_id" : 535511684119793665,
  "created_at" : "2014-11-21 01:57:32 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535609519787622401",
  "geo" : { },
  "id_str" : "535609584035983360",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza been top of the app store for months",
  "id" : 535609584035983360,
  "in_reply_to_status_id" : 535609519787622401,
  "created_at" : "2014-11-21 01:44:10 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harris-Gershon",
      "screen_name" : "David_EHG",
      "indices" : [ 3, 13 ],
      "id_str" : "271461410",
      "id" : 271461410
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/David_EHG\/status\/535595104313278466\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/6mOvOTmtIO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B27Q4z4CEAAvMJf.png",
      "id_str" : "535595080120143872",
      "id" : 535595080120143872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B27Q4z4CEAAvMJf.png",
      "sizes" : [ {
        "h" : 388,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 388,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 388,
        "resize" : "fit",
        "w" : 523
      } ],
      "display_url" : "pic.twitter.com\/6mOvOTmtIO"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/David_EHG\/status\/535595104313278466\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/6mOvOTmtIO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B27Q6KCCEAAIt-m.png",
      "id_str" : "535595103247536128",
      "id" : 535595103247536128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B27Q6KCCEAAIt-m.png",
      "sizes" : [ {
        "h" : 201,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 734
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 734
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6mOvOTmtIO"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535597280175218689",
  "text" : "RT @David_EHG: Dear Missouri, the image on the left is what a \"State of Emergency\" looks like.\n\nOn the right? Racism.    #Ferguson http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/David_EHG\/status\/535595104313278466\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/6mOvOTmtIO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B27Q4z4CEAAvMJf.png",
        "id_str" : "535595080120143872",
        "id" : 535595080120143872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B27Q4z4CEAAvMJf.png",
        "sizes" : [ {
          "h" : 388,
          "resize" : "fit",
          "w" : 523
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 388,
          "resize" : "fit",
          "w" : 523
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 388,
          "resize" : "fit",
          "w" : 523
        } ],
        "display_url" : "pic.twitter.com\/6mOvOTmtIO"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/David_EHG\/status\/535595104313278466\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/6mOvOTmtIO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B27Q6KCCEAAIt-m.png",
        "id_str" : "535595103247536128",
        "id" : 535595103247536128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B27Q6KCCEAAIt-m.png",
        "sizes" : [ {
          "h" : 201,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 734
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 734
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6mOvOTmtIO"
      } ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535595104313278466",
    "text" : "Dear Missouri, the image on the left is what a \"State of Emergency\" looks like.\n\nOn the right? Racism.    #Ferguson http:\/\/t.co\/6mOvOTmtIO",
    "id" : 535595104313278466,
    "created_at" : "2014-11-21 00:46:38 +0000",
    "user" : {
      "name" : "David Harris-Gershon",
      "screen_name" : "David_EHG",
      "protected" : false,
      "id_str" : "271461410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468540196217036800\/4BUu4YEv_normal.jpeg",
      "id" : 271461410,
      "verified" : false
    }
  },
  "id" : 535597280175218689,
  "created_at" : "2014-11-21 00:55:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535589724694384641",
  "text" : "One year old just picked out Babes in Toyland on his own from the Netflix queue and played it. Some taste this kid has.",
  "id" : 535589724694384641,
  "created_at" : "2014-11-21 00:25:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy Sandora-Nastyn",
      "screen_name" : "BillybobN",
      "indices" : [ 0, 10 ],
      "id_str" : "97221495",
      "id" : 97221495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535588150610235392",
  "geo" : { },
  "id_str" : "535589143737147392",
  "in_reply_to_user_id" : 97221495,
  "text" : "@BillybobN I think you meant to say \u201Cfuck\u201D",
  "id" : 535589143737147392,
  "in_reply_to_status_id" : 535588150610235392,
  "created_at" : "2014-11-21 00:22:57 +0000",
  "in_reply_to_screen_name" : "BillybobN",
  "in_reply_to_user_id_str" : "97221495",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/kguBlJsvuk",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=HdCaZyvXJO8",
      "display_url" : "youtube.com\/watch?v=HdCaZy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535588797770002433",
  "text" : "10,000 tweets! https:\/\/t.co\/kguBlJsvuk",
  "id" : 535588797770002433,
  "created_at" : "2014-11-21 00:21:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535587301825728512",
  "geo" : { },
  "id_str" : "535588697446432768",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik flipped over in 2009. Why?",
  "id" : 535588697446432768,
  "in_reply_to_status_id" : 535587301825728512,
  "created_at" : "2014-11-21 00:21:10 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Verhoeve",
      "screen_name" : "wesleyverhoeve",
      "indices" : [ 3, 18 ],
      "id_str" : "15393128",
      "id" : 15393128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/YzIP54SbDN",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=HdCaZyvXJO8",
      "display_url" : "youtube.com\/watch?v=HdCaZy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535588630559862784",
  "text" : "RT @wesleyverhoeve: A great SNL skit about tweeting that got cut from last episode https:\/\/t.co\/YzIP54SbDN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/YzIP54SbDN",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=HdCaZyvXJO8",
        "display_url" : "youtube.com\/watch?v=HdCaZy\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "535582334297575424",
    "text" : "A great SNL skit about tweeting that got cut from last episode https:\/\/t.co\/YzIP54SbDN",
    "id" : 535582334297575424,
    "created_at" : "2014-11-20 23:55:53 +0000",
    "user" : {
      "name" : "Wesley Verhoeve",
      "screen_name" : "wesleyverhoeve",
      "protected" : false,
      "id_str" : "15393128",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460813574084911106\/mwv-SYOJ_normal.jpeg",
      "id" : 15393128,
      "verified" : false
    }
  },
  "id" : 535588630559862784,
  "created_at" : "2014-11-21 00:20:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Gould",
      "screen_name" : "KBMattG",
      "indices" : [ 3, 11 ],
      "id_str" : "15291280",
      "id" : 15291280
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/KBMattG\/status\/535505595206750208\/photo\/1",
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/ArCiuv9lR8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B25_f_3CYAELTHz.png",
      "id_str" : "535505593398616065",
      "id" : 535505593398616065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B25_f_3CYAELTHz.png",
      "sizes" : [ {
        "h" : 632,
        "resize" : "fit",
        "w" : 958
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 958
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ArCiuv9lR8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535558914482241537",
  "text" : "RT @KBMattG: We've seen a lot of great images this week.\nBut this wins.\nBuffalo's storm from Fort Erie, by Larry Mathewson http:\/\/t.co\/ArCi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/KBMattG\/status\/535505595206750208\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/ArCiuv9lR8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B25_f_3CYAELTHz.png",
        "id_str" : "535505593398616065",
        "id" : 535505593398616065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B25_f_3CYAELTHz.png",
        "sizes" : [ {
          "h" : 632,
          "resize" : "fit",
          "w" : 958
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 958
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ArCiuv9lR8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535505595206750208",
    "text" : "We've seen a lot of great images this week.\nBut this wins.\nBuffalo's storm from Fort Erie, by Larry Mathewson http:\/\/t.co\/ArCiuv9lR8",
    "id" : 535505595206750208,
    "created_at" : "2014-11-20 18:50:57 +0000",
    "user" : {
      "name" : "Matt Gould",
      "screen_name" : "KBMattG",
      "protected" : false,
      "id_str" : "15291280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/534190763999911936\/oLJ1YQzE_normal.png",
      "id" : 15291280,
      "verified" : false
    }
  },
  "id" : 535558914482241537,
  "created_at" : "2014-11-20 22:22:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535547964974854145",
  "geo" : { },
  "id_str" : "535548672751460352",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking the point is you never need to with Jekyll?",
  "id" : 535548672751460352,
  "in_reply_to_status_id" : 535547964974854145,
  "created_at" : "2014-11-20 21:42:08 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 3, 17 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WallOfSnow",
      "indices" : [ 19, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/GONxxFs4ij",
      "expanded_url" : "http:\/\/instagram.com\/p\/vomLKVQtdN\/",
      "display_url" : "instagram.com\/p\/vomLKVQtdN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "535535410425110529",
  "text" : "RT @communitybeer: #WallOfSnow http:\/\/t.co\/GONxxFs4ij",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WallOfSnow",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/GONxxFs4ij",
        "expanded_url" : "http:\/\/instagram.com\/p\/vomLKVQtdN\/",
        "display_url" : "instagram.com\/p\/vomLKVQtdN\/"
      } ]
    },
    "geo" : { },
    "id_str" : "535524417833414657",
    "text" : "#WallOfSnow http:\/\/t.co\/GONxxFs4ij",
    "id" : 535524417833414657,
    "created_at" : "2014-11-20 20:05:45 +0000",
    "user" : {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "protected" : false,
      "id_str" : "145294977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477088444733071361\/g7q5sNbw_normal.jpeg",
      "id" : 145294977,
      "verified" : false
    }
  },
  "id" : 535535410425110529,
  "created_at" : "2014-11-20 20:49:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/535474242632953856\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/b3Tm3vT5AY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B25i_EOCIAE1hzV.png",
      "id_str" : "535474241307549697",
      "id" : 535474241307549697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B25i_EOCIAE1hzV.png",
      "sizes" : [ {
        "h" : 371,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 123,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 1174
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/b3Tm3vT5AY"
    } ],
    "hashtags" : [ {
      "text" : "FF00FF",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/gkqtscOvBI",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "535474242632953856",
  "text" : "Everyone just wait until I change the color of http:\/\/t.co\/gkqtscOvBI to #FF00FF. Just wait! http:\/\/t.co\/b3Tm3vT5AY",
  "id" : 535474242632953856,
  "created_at" : "2014-11-20 16:46:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/CuwZTstZzT",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/#!topic\/rubygems-org\/RMzueTqpi3g",
      "display_url" : "groups.google.com\/forum\/#!topic\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535472213294452736",
  "text" : "\"Someone please have mercy!\" https:\/\/t.co\/CuwZTstZzT",
  "id" : 535472213294452736,
  "created_at" : "2014-11-20 16:38:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 0, 15 ],
      "id_str" : "155998525",
      "id" : 155998525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535469023149187072",
  "geo" : { },
  "id_str" : "535469198063828993",
  "in_reply_to_user_id" : 155998525,
  "text" : "@1ofyourmeteors I'm staying home today, but it's open today and folks are there. I'd watch the weather though.",
  "id" : 535469198063828993,
  "in_reply_to_status_id" : 535469023149187072,
  "created_at" : "2014-11-20 16:26:20 +0000",
  "in_reply_to_screen_name" : "1ofyourmeteors",
  "in_reply_to_user_id_str" : "155998525",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/Bbe7RLtkLF",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=EAESJ56or38",
      "display_url" : "youtube.com\/watch?v=EAESJ5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535468625482625026",
  "text" : "Funny that every time I hear a different Free, my brain wants to hear \"Your spaceship is about to take off!\" https:\/\/t.co\/Bbe7RLtkLF",
  "id" : 535468625482625026,
  "created_at" : "2014-11-20 16:24:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Jared Carroll",
      "screen_name" : "PumpMyBicep",
      "indices" : [ 8, 20 ],
      "id_str" : "2458480788",
      "id" : 2458480788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535463703424942081",
  "geo" : { },
  "id_str" : "535463793099165697",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky @PumpMyBicep 2-3 feet incoming today apparently",
  "id" : 535463793099165697,
  "in_reply_to_status_id" : 535463703424942081,
  "created_at" : "2014-11-20 16:04:51 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Wood",
      "screen_name" : "joshuap",
      "indices" : [ 0, 8 ],
      "id_str" : "12742912",
      "id" : 12742912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535460181908287488",
  "geo" : { },
  "id_str" : "535460519465861120",
  "in_reply_to_user_id" : 12742912,
  "text" : "@joshuap i think that's covered by a host of other services. too many competing factors here :(",
  "id" : 535460519465861120,
  "in_reply_to_status_id" : 535460181908287488,
  "created_at" : "2014-11-20 15:51:50 +0000",
  "in_reply_to_screen_name" : "joshuap",
  "in_reply_to_user_id_str" : "12742912",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/NPFeERAzfu",
      "expanded_url" : "http:\/\/github.com\/rubygems\/gemwhisperer",
      "display_url" : "github.com\/rubygems\/gemwh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535459632144076801",
  "text" : "Re http:\/\/t.co\/NPFeERAzfu, it might be nice to turn it into a tutorial on how to setup your own webhook.",
  "id" : 535459632144076801,
  "created_at" : "2014-11-20 15:48:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Roselli",
      "screen_name" : "aardrian",
      "indices" : [ 0, 9 ],
      "id_str" : "16515870",
      "id" : 16515870
    }, {
      "name" : "Jen Simmons",
      "screen_name" : "jensimmons",
      "indices" : [ 10, 21 ],
      "id_str" : "975691",
      "id" : 975691
    }, {
      "name" : "Owen Williams",
      "screen_name" : "ow",
      "indices" : [ 22, 25 ],
      "id_str" : "14767730",
      "id" : 14767730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535455323872849920",
  "geo" : { },
  "id_str" : "535455840832978945",
  "in_reply_to_user_id" : 16515870,
  "text" : "@aardrian @jensimmons @ow luckily i'm north of the travel ban...so far...",
  "id" : 535455840832978945,
  "in_reply_to_status_id" : 535455323872849920,
  "created_at" : "2014-11-20 15:33:15 +0000",
  "in_reply_to_screen_name" : "aardrian",
  "in_reply_to_user_id_str" : "16515870",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/IwHXFfFq3y",
      "expanded_url" : "http:\/\/m.rubygems.org\/",
      "display_url" : "m.rubygems.org"
    }, {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/uEsLMgYR2b",
      "expanded_url" : "https:\/\/github.com\/rubygems\/gemwhisperer",
      "display_url" : "github.com\/rubygems\/gemwh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535453409776648193",
  "text" : "Anyone up for updating http:\/\/t.co\/IwHXFfFq3y with the new style? Also wonder if we should change the URL. https:\/\/t.co\/uEsLMgYR2b",
  "id" : 535453409776648193,
  "created_at" : "2014-11-20 15:23:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Simmons",
      "screen_name" : "jensimmons",
      "indices" : [ 0, 11 ],
      "id_str" : "975691",
      "id" : 975691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535451304597159937",
  "geo" : { },
  "id_str" : "535452023626268672",
  "in_reply_to_user_id" : 975691,
  "text" : "@jensimmons I definitely remember searching for it too. Twitter...fail? :P",
  "id" : 535452023626268672,
  "in_reply_to_status_id" : 535451304597159937,
  "created_at" : "2014-11-20 15:18:05 +0000",
  "in_reply_to_screen_name" : "jensimmons",
  "in_reply_to_user_id_str" : "975691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Simmons",
      "screen_name" : "jensimmons",
      "indices" : [ 0, 11 ],
      "id_str" : "975691",
      "id" : 975691
    }, {
      "name" : "Yiying Lu",
      "screen_name" : "YiyingLu",
      "indices" : [ 101, 110 ],
      "id_str" : "15201143",
      "id" : 15201143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/aA5OH7raaV",
      "expanded_url" : "http:\/\/www.whatisfailwhale.info\/",
      "display_url" : "whatisfailwhale.info"
    } ]
  },
  "in_reply_to_status_id_str" : "535451304597159937",
  "geo" : { },
  "id_str" : "535451750564515840",
  "in_reply_to_user_id" : 975691,
  "text" : "@jensimmons i'd gladly give up the spot (or at least another mention!) on http:\/\/t.co\/aA5OH7raaV \/cc @YiyingLu",
  "id" : 535451750564515840,
  "in_reply_to_status_id" : 535451304597159937,
  "created_at" : "2014-11-20 15:17:00 +0000",
  "in_reply_to_screen_name" : "jensimmons",
  "in_reply_to_user_id_str" : "975691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pingdom",
      "screen_name" : "pingdom",
      "indices" : [ 0, 8 ],
      "id_str" : "15674759",
      "id" : 15674759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535447785160470528",
  "geo" : { },
  "id_str" : "535447981416546304",
  "in_reply_to_user_id" : 15674759,
  "text" : "@pingdom thanks!",
  "id" : 535447981416546304,
  "in_reply_to_status_id" : 535447785160470528,
  "created_at" : "2014-11-20 15:02:01 +0000",
  "in_reply_to_screen_name" : "pingdom",
  "in_reply_to_user_id_str" : "15674759",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirill Nikitin",
      "screen_name" : "Locke23rus",
      "indices" : [ 0, 11 ],
      "id_str" : "18718296",
      "id" : 18718296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535446810102616064",
  "geo" : { },
  "id_str" : "535447183550873600",
  "in_reply_to_user_id" : 18718296,
  "text" : "@Locke23rus no idea! That is rough for sure.",
  "id" : 535447183550873600,
  "in_reply_to_status_id" : 535446810102616064,
  "created_at" : "2014-11-20 14:58:51 +0000",
  "in_reply_to_screen_name" : "Locke23rus",
  "in_reply_to_user_id_str" : "18718296",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/gkqtscOvBI",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/U57v1jkZj8",
      "expanded_url" : "http:\/\/uptime.rubygems.org\/131647\/history",
      "display_url" : "uptime.rubygems.org\/131647\/history"
    } ]
  },
  "geo" : { },
  "id_str" : "535445139498336258",
  "text" : "Also there's uptime data going back to November 2009 for http:\/\/t.co\/gkqtscOvBI here: http:\/\/t.co\/U57v1jkZj8 Pretty wild to see it all.",
  "id" : 535445139498336258,
  "created_at" : "2014-11-20 14:50:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pingdom",
      "screen_name" : "pingdom",
      "indices" : [ 32, 40 ],
      "id_str" : "15674759",
      "id" : 15674759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/UEadehxo9E",
      "expanded_url" : "http:\/\/uptime.rubygems.org\/",
      "display_url" : "uptime.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "535444781766152193",
  "text" : "Do I know anyone that works for @pingdom? We'd love to expand http:\/\/t.co\/UEadehxo9E further, not sure if they offer free OSS accounts.",
  "id" : 535444781766152193,
  "created_at" : "2014-11-20 14:49:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535443491095347200",
  "geo" : { },
  "id_str" : "535443826794434560",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape it's the AC\/DC of folk rock",
  "id" : 535443826794434560,
  "in_reply_to_status_id" : 535443491095347200,
  "created_at" : "2014-11-20 14:45:31 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Lewison",
      "screen_name" : "facethewind_com",
      "indices" : [ 3, 19 ],
      "id_str" : "243856902",
      "id" : 243856902
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 124, 132 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/1ynoHwdC42",
      "expanded_url" : "http:\/\/youtu.be\/cXW6TjGd1t8?a",
      "display_url" : "youtu.be\/cXW6TjGd1t8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "535441251579854849",
  "text" : "RT @facethewind_com: 11\/18\/2014 - Historic Lake Effect Snowfall in Buffalo NY - Radar Animation: http:\/\/t.co\/1ynoHwdC42 via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 103, 111 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/1ynoHwdC42",
        "expanded_url" : "http:\/\/youtu.be\/cXW6TjGd1t8?a",
        "display_url" : "youtu.be\/cXW6TjGd1t8?a"
      } ]
    },
    "geo" : { },
    "id_str" : "535257973539745792",
    "text" : "11\/18\/2014 - Historic Lake Effect Snowfall in Buffalo NY - Radar Animation: http:\/\/t.co\/1ynoHwdC42 via @YouTube",
    "id" : 535257973539745792,
    "created_at" : "2014-11-20 02:27:00 +0000",
    "user" : {
      "name" : "Dave Lewison",
      "screen_name" : "facethewind_com",
      "protected" : false,
      "id_str" : "243856902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1227649645\/_DSC1671_normal.jpg",
      "id" : 243856902,
      "verified" : false
    }
  },
  "id" : 535441251579854849,
  "created_at" : "2014-11-20 14:35:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535424791726284800",
  "geo" : { },
  "id_str" : "535425530989150209",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz it\u2019s mostly powder.",
  "id" : 535425530989150209,
  "in_reply_to_status_id" : 535424791726284800,
  "created_at" : "2014-11-20 13:32:48 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/535421546714521600\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/bjlfoNfhDC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B24zDqVCMAAgF7H.jpg",
      "id_str" : "535421543698804736",
      "id" : 535421543698804736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B24zDqVCMAAgF7H.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2444,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bjlfoNfhDC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535421546714521600",
  "text" : "The only time this derp face stood still http:\/\/t.co\/bjlfoNfhDC",
  "id" : 535421546714521600,
  "created_at" : "2014-11-20 13:16:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Elliott",
      "screen_name" : "p_elliott",
      "indices" : [ 0, 10 ],
      "id_str" : "18047782",
      "id" : 18047782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535419144599261184",
  "geo" : { },
  "id_str" : "535419729679097857",
  "in_reply_to_user_id" : 18047782,
  "text" : "@p_elliott \u2026",
  "id" : 535419729679097857,
  "in_reply_to_status_id" : 535419144599261184,
  "created_at" : "2014-11-20 13:09:45 +0000",
  "in_reply_to_screen_name" : "p_elliott",
  "in_reply_to_user_id_str" : "18047782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535397160188395520",
  "geo" : { },
  "id_str" : "535410464927150081",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel don\u2019t copy that floppy",
  "id" : 535410464927150081,
  "in_reply_to_status_id" : 535397160188395520,
  "created_at" : "2014-11-20 12:32:56 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Jared Carroll",
      "screen_name" : "PumpMyBicep",
      "indices" : [ 8, 20 ],
      "id_str" : "2458480788",
      "id" : 2458480788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535330572621471744",
  "geo" : { },
  "id_str" : "535407758544076801",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky @PumpMyBicep haha thanks. Looks like we only got 4-5\u2033 or so overnight at my place",
  "id" : 535407758544076801,
  "in_reply_to_status_id" : 535330572621471744,
  "created_at" : "2014-11-20 12:22:11 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bufwx",
      "indices" : [ 13, 19 ]
    }, {
      "text" : "nywx",
      "indices" : [ 24, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535303216896823296",
  "text" : "Have to say, #bufwx and #nywx have been great to follow. Also when the pros say it\u2019s bad out\u2026it\u2019s bad.",
  "id" : 535303216896823296,
  "created_at" : "2014-11-20 05:26:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Lamarche",
      "screen_name" : "Lamarche",
      "indices" : [ 0, 9 ],
      "id_str" : "16166161",
      "id" : 16166161
    }, {
      "name" : "Amy",
      "screen_name" : "AmyStephen",
      "indices" : [ 10, 21 ],
      "id_str" : "8966062",
      "id" : 8966062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535287476126900224",
  "geo" : { },
  "id_str" : "535297578888200193",
  "in_reply_to_user_id" : 16166161,
  "text" : "@Lamarche @AmyStephen luckily no ice like that here. Yet. (Geez)",
  "id" : 535297578888200193,
  "in_reply_to_status_id" : 535287476126900224,
  "created_at" : "2014-11-20 05:04:22 +0000",
  "in_reply_to_screen_name" : "Lamarche",
  "in_reply_to_user_id_str" : "16166161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Simmons",
      "screen_name" : "jensimmons",
      "indices" : [ 11, 22 ],
      "id_str" : "975691",
      "id" : 975691
    }, {
      "name" : "Owen Williams",
      "screen_name" : "ow",
      "indices" : [ 89, 92 ],
      "id_str" : "14767730",
      "id" : 14767730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/43B3Dddv3g",
      "expanded_url" : "https:\/\/twitter.com\/search?q=fail%20whale%20since%3A2005-07-01%20until%3A2008-05-31&src=typd",
      "display_url" : "twitter.com\/search?q=fail%\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535296103717949440",
  "text" : "Looks like @jensimmons beat me by a long shot for Failwhale: https:\/\/t.co\/43B3Dddv3g \/cc @ow",
  "id" : 535296103717949440,
  "created_at" : "2014-11-20 04:58:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    }, {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 15, 23 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535295368309661696",
  "geo" : { },
  "id_str" : "535295785949069312",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting @paulehr that is seriously fucking wrong",
  "id" : 535295785949069312,
  "in_reply_to_status_id" : 535295368309661696,
  "created_at" : "2014-11-20 04:57:15 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hooker",
      "screen_name" : "GeekOnCoffee",
      "indices" : [ 0, 13 ],
      "id_str" : "14381032",
      "id" : 14381032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535280287660257280",
  "geo" : { },
  "id_str" : "535290264475009024",
  "in_reply_to_user_id" : 14381032,
  "text" : "@GeekOnCoffee yeah we don\u2019t do a good job of closing issues either. Maybe time to first response is a better metric",
  "id" : 535290264475009024,
  "in_reply_to_status_id" : 535280287660257280,
  "created_at" : "2014-11-20 04:35:18 +0000",
  "in_reply_to_screen_name" : "GeekOnCoffee",
  "in_reply_to_user_id_str" : "14381032",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "indices" : [ 0, 12 ],
      "id_str" : "9526722",
      "id" : 9526722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535281456906768384",
  "geo" : { },
  "id_str" : "535283258171211776",
  "in_reply_to_user_id" : 9526722,
  "text" : "@CoralineAda great! I\u2019ll update it after I dig out of snow tomorrow",
  "id" : 535283258171211776,
  "in_reply_to_status_id" : 535281456906768384,
  "created_at" : "2014-11-20 04:07:28 +0000",
  "in_reply_to_screen_name" : "CoralineAda",
  "in_reply_to_user_id_str" : "9526722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535280626308349952",
  "text" : "Be prepared for some husky deep snow GIFs\/video tomorrow.",
  "id" : 535280626308349952,
  "created_at" : "2014-11-20 03:57:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NWS BUFFALO",
      "screen_name" : "NWSBUFFALO",
      "indices" : [ 3, 14 ],
      "id_str" : "982762350",
      "id" : 982762350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 61, 69 ]
    }, {
      "text" : "LakeEffect",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535280514387566592",
  "text" : "RT @NWSBUFFALO: Just measured 1.6 inches in the last hour at #Buffalo airport. Multiple lightning stikes. #LakeEffect",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 45, 53 ]
      }, {
        "text" : "LakeEffect",
        "indices" : [ 90, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535280405616656385",
    "text" : "Just measured 1.6 inches in the last hour at #Buffalo airport. Multiple lightning stikes. #LakeEffect",
    "id" : 535280405616656385,
    "created_at" : "2014-11-20 03:56:08 +0000",
    "user" : {
      "name" : "NWS BUFFALO",
      "screen_name" : "NWSBUFFALO",
      "protected" : false,
      "id_str" : "982762350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465137770696957952\/-6l64r-b_normal.jpeg",
      "id" : 982762350,
      "verified" : true
    }
  },
  "id" : 535280514387566592,
  "created_at" : "2014-11-20 03:56:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/fCspDCO6hm",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    }, {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/NTLoKYJytJ",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/7f12469d9c1cb9b39788",
      "display_url" : "gist.github.com\/qrush\/7f12469d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535279974060920833",
  "text" : "Looking for some copy suggestions for http:\/\/t.co\/fCspDCO6hm's intro text: https:\/\/t.co\/NTLoKYJytJ",
  "id" : 535279974060920833,
  "created_at" : "2014-11-20 03:54:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 53, 63 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535278413473669120",
  "text" : "Also a stat that makes me embarrassed compared to my @37signals support coworkers - 742h 39m avg time to resolve issues for 2014. (30 days!)",
  "id" : 535278413473669120,
  "created_at" : "2014-11-20 03:48:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/fCspDCO6hm",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    }, {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/e16oyndKqP",
      "expanded_url" : "http:\/\/i.imgur.com\/NDvJAMK.jpg",
      "display_url" : "i.imgur.com\/NDvJAMK.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "535277710080487424",
  "text" : "5 years of http:\/\/t.co\/fCspDCO6hm  resolving tickets. This is the real work behind OSS - http:\/\/t.co\/e16oyndKqP",
  "id" : 535277710080487424,
  "created_at" : "2014-11-20 03:45:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535277539598798848",
  "text" : "Twitter is awful so let me repost that graph.",
  "id" : 535277539598798848,
  "created_at" : "2014-11-20 03:44:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pookleblinky",
      "screen_name" : "pookleblinky",
      "indices" : [ 0, 13 ],
      "id_str" : "35163668",
      "id" : 35163668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535276400220332033",
  "geo" : { },
  "id_str" : "535277342856581120",
  "in_reply_to_user_id" : 35163668,
  "text" : "@pookleblinky even the NWS alerts say \"THUNDERSNOW\" now",
  "id" : 535277342856581120,
  "in_reply_to_status_id" : 535276400220332033,
  "created_at" : "2014-11-20 03:43:58 +0000",
  "in_reply_to_screen_name" : "pookleblinky",
  "in_reply_to_user_id_str" : "35163668",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 0, 12 ],
      "id_str" : "158098704",
      "id" : 158098704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535276419073335296",
  "geo" : { },
  "id_str" : "535276485037551616",
  "in_reply_to_user_id" : 158098704,
  "text" : "@mikemikemac new band name",
  "id" : 535276485037551616,
  "in_reply_to_status_id" : 535276419073335296,
  "created_at" : "2014-11-20 03:40:33 +0000",
  "in_reply_to_screen_name" : "mikemikemac",
  "in_reply_to_user_id_str" : "158098704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thundersnow",
      "indices" : [ 16, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535276293135556608",
  "text" : "First rumble of #thundersnow and huge flash of lightning tonight I've seen D:",
  "id" : 535276293135556608,
  "created_at" : "2014-11-20 03:39:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "entp",
      "screen_name" : "entp",
      "indices" : [ 14, 19 ],
      "id_str" : "14080083",
      "id" : 14080083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/ZV1ol56eJl",
      "expanded_url" : "http:\/\/help.rubygems.org\/",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "535274803142606848",
  "text" : "Big thanks to @entp for keeping http:\/\/t.co\/ZV1ol56eJl free for us all these years. Has made a big difference.",
  "id" : 535274803142606848,
  "created_at" : "2014-11-20 03:33:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/ZV1ol56eJl",
      "expanded_url" : "http:\/\/help.rubygems.org\/",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "535274647571681280",
  "text" : "Killed the custom header and other awful CSS hacks going on with http:\/\/t.co\/ZV1ol56eJl, and it's a lot nicer now.",
  "id" : 535274647571681280,
  "created_at" : "2014-11-20 03:33:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/DIESPGNNjJ",
      "expanded_url" : "http:\/\/help.rubygems.org\/discussions\/suggestions\/7806-please-back-old-design",
      "display_url" : "help.rubygems.org\/discussions\/su\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535270808219037696",
  "text" : "Sheesh. http:\/\/t.co\/DIESPGNNjJ",
  "id" : 535270808219037696,
  "created_at" : "2014-11-20 03:18:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    }, {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 8, 17 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535270231741308928",
  "geo" : { },
  "id_str" : "535270555663204352",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j @bitsweat FOMO",
  "id" : 535270555663204352,
  "in_reply_to_status_id" : 535270231741308928,
  "created_at" : "2014-11-20 03:16:59 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/ZYE9SHFIa4",
      "expanded_url" : "http:\/\/guides.rubygems.org\/",
      "display_url" : "guides.rubygems.org"
    }, {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/2bEZ2lUhPm",
      "expanded_url" : "http:\/\/docs.rubygems.org",
      "display_url" : "docs.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "535270507839754241",
  "text" : "Oh, and http:\/\/t.co\/ZYE9SHFIa4 got a refresh as well. This has also come a huge way since the http:\/\/t.co\/2bEZ2lUhPm days.",
  "id" : 535270507839754241,
  "created_at" : "2014-11-20 03:16:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/535269363809800193\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/AwTlabwS62",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B22opjoCAAAkZni.png",
      "id_str" : "535269362618204160",
      "id" : 535269362618204160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B22opjoCAAAkZni.png",
      "sizes" : [ {
        "h" : 993,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 329,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1048,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 582,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/AwTlabwS62"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/33aYApI4Hq",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "535269363809800193",
  "text" : "Traffic's up quite a bit on http:\/\/t.co\/33aYApI4Hq due to the redesign as well. I wonder if it'll stay? http:\/\/t.co\/AwTlabwS62",
  "id" : 535269363809800193,
  "created_at" : "2014-11-20 03:12:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyStephen",
      "indices" : [ 0, 11 ],
      "id_str" : "8966062",
      "id" : 8966062
    }, {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 93, 103 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535243280527925249",
  "geo" : { },
  "id_str" : "535244610390745088",
  "in_reply_to_user_id" : 8966062,
  "text" : "@AmyStephen it's awful to watch. I've learned a lot from following several folks, especially @ShaunKing. I wonder what we'd do here in NY.",
  "id" : 535244610390745088,
  "in_reply_to_status_id" : 535243280527925249,
  "created_at" : "2014-11-20 01:33:54 +0000",
  "in_reply_to_screen_name" : "AmyStephen",
  "in_reply_to_user_id_str" : "8966062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535243264501510144",
  "text" : "I'm still excited for the \"next\" thing to come. Given the speed of Ruby, I am sure we will see something better than RubyGems. I welcome it.",
  "id" : 535243264501510144,
  "created_at" : "2014-11-20 01:28:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535243060947730432",
  "text" : "Despite that I am really proud of how far the site's come. 4 billion gem downloads since 2009. Wild.",
  "id" : 535243060947730432,
  "created_at" : "2014-11-20 01:27:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/33aYApI4Hq",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/D7dNgXpXSB",
      "expanded_url" : "http:\/\/rubygems.org\/pages\/about",
      "display_url" : "rubygems.org\/pages\/about"
    } ]
  },
  "geo" : { },
  "id_str" : "535242899697709060",
  "text" : "It's exciting to see the design revamp for http:\/\/t.co\/33aYApI4Hq really hit home on point 3 here - http:\/\/t.co\/D7dNgXpXSB",
  "id" : 535242899697709060,
  "created_at" : "2014-11-20 01:27:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535232745300328448",
  "geo" : { },
  "id_str" : "535233376249450496",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 holy shit NWS uses \u201Cthundersnow\u201D",
  "id" : 535233376249450496,
  "in_reply_to_status_id" : 535232745300328448,
  "created_at" : "2014-11-20 00:49:15 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NWS BUFFALO",
      "screen_name" : "NWSBUFFALO",
      "indices" : [ 3, 14 ],
      "id_str" : "982762350",
      "id" : 982762350
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NWSBUFFALO\/status\/535230315032477697\/photo\/1",
      "indices" : [ 147, 148 ],
      "url" : "http:\/\/t.co\/mC8cwnQFg0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B22FIi4IIAEPP_O.png",
      "id_str" : "535230312574623745",
      "id" : 535230312574623745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B22FIi4IIAEPP_O.png",
      "sizes" : [ {
        "h" : 504,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 729,
        "resize" : "fit",
        "w" : 867
      }, {
        "h" : 729,
        "resize" : "fit",
        "w" : 867
      }, {
        "h" : 285,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mC8cwnQFg0"
    } ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 78, 86 ]
    }, {
      "text" : "LakeEffect",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/1OdtPzFf34",
      "expanded_url" : "http:\/\/forecast.weather.gov\/product.php?site=buf&product=SPS&issuedby=BUF&format=ci&version=1",
      "display_url" : "forecast.weather.gov\/product.php?si\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535230870719049730",
  "text" : "RT @NWSBUFFALO: Here it comes! Niagara County by 9&amp;10pm, Northtowns &amp; #Buffalo around midnight. #LakeEffect http:\/\/t.co\/1OdtPzFf34 http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NWSBUFFALO\/status\/535230315032477697\/photo\/1",
        "indices" : [ 123, 145 ],
        "url" : "http:\/\/t.co\/mC8cwnQFg0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B22FIi4IIAEPP_O.png",
        "id_str" : "535230312574623745",
        "id" : 535230312574623745,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B22FIi4IIAEPP_O.png",
        "sizes" : [ {
          "h" : 504,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 729,
          "resize" : "fit",
          "w" : 867
        }, {
          "h" : 729,
          "resize" : "fit",
          "w" : 867
        }, {
          "h" : 285,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/mC8cwnQFg0"
      } ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 62, 70 ]
      }, {
        "text" : "LakeEffect",
        "indices" : [ 88, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/1OdtPzFf34",
        "expanded_url" : "http:\/\/forecast.weather.gov\/product.php?site=buf&product=SPS&issuedby=BUF&format=ci&version=1",
        "display_url" : "forecast.weather.gov\/product.php?si\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "535230315032477697",
    "text" : "Here it comes! Niagara County by 9&amp;10pm, Northtowns &amp; #Buffalo around midnight. #LakeEffect http:\/\/t.co\/1OdtPzFf34 http:\/\/t.co\/mC8cwnQFg0",
    "id" : 535230315032477697,
    "created_at" : "2014-11-20 00:37:05 +0000",
    "user" : {
      "name" : "NWS BUFFALO",
      "screen_name" : "NWSBUFFALO",
      "protected" : false,
      "id_str" : "982762350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465137770696957952\/-6l64r-b_normal.jpeg",
      "id" : 982762350,
      "verified" : true
    }
  },
  "id" : 535230870719049730,
  "created_at" : "2014-11-20 00:39:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535222731944779776",
  "text" : "Got the email for AWS Lambda access but can't get to the console. :(",
  "id" : 535222731944779776,
  "created_at" : "2014-11-20 00:06:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 0, 14 ],
      "id_str" : "45490102",
      "id" : 45490102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535218933830524928",
  "geo" : { },
  "id_str" : "535221802080157696",
  "in_reply_to_user_id" : 45490102,
  "text" : "@markpoloncarz can we just pretend for a minute that we're launching a spaceship?",
  "id" : 535221802080157696,
  "in_reply_to_status_id" : 535218933830524928,
  "created_at" : "2014-11-20 00:03:16 +0000",
  "in_reply_to_screen_name" : "markpoloncarz",
  "in_reply_to_user_id_str" : "45490102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 0, 7 ],
      "id_str" : "638323",
      "id" : 638323
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teampullrequest",
      "indices" : [ 18, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/nO4VUNBn3Q",
      "expanded_url" : "http:\/\/github.com\/rubygems\/rubygems.org",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "535189580119830528",
  "geo" : { },
  "id_str" : "535212682576945153",
  "in_reply_to_user_id" : 638323,
  "text" : "@kneath how about #teampullrequest instead? :) http:\/\/t.co\/nO4VUNBn3Q",
  "id" : 535212682576945153,
  "in_reply_to_status_id" : 535189580119830528,
  "created_at" : "2014-11-19 23:27:01 +0000",
  "in_reply_to_screen_name" : "kneath",
  "in_reply_to_user_id_str" : "638323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Gee",
      "screen_name" : "DerekGeePhoto",
      "indices" : [ 3, 17 ],
      "id_str" : "1634451608",
      "id" : 1634451608
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DerekGeePhoto\/status\/535207395384127489\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/QHmlYZvKRK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B21wSirIAAEtcUC.jpg",
      "id_str" : "535207394574598145",
      "id" : 535207394574598145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B21wSirIAAEtcUC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/QHmlYZvKRK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535207600493961216",
  "text" : "RT @DerekGeePhoto: Ralph Wilson Stadium is under there somewhere... http:\/\/t.co\/QHmlYZvKRK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DerekGeePhoto\/status\/535207395384127489\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/QHmlYZvKRK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B21wSirIAAEtcUC.jpg",
        "id_str" : "535207394574598145",
        "id" : 535207394574598145,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B21wSirIAAEtcUC.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/QHmlYZvKRK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535207395384127489",
    "text" : "Ralph Wilson Stadium is under there somewhere... http:\/\/t.co\/QHmlYZvKRK",
    "id" : 535207395384127489,
    "created_at" : "2014-11-19 23:06:01 +0000",
    "user" : {
      "name" : "Derek Gee",
      "screen_name" : "DerekGeePhoto",
      "protected" : false,
      "id_str" : "1634451608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000226582128\/ae10cebbc5d83d1014a8cfd45e3a0044_normal.jpeg",
      "id" : 1634451608,
      "verified" : false
    }
  },
  "id" : 535207600493961216,
  "created_at" : "2014-11-19 23:06:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 3, 17 ],
      "id_str" : "45490102",
      "id" : 45490102
    }, {
      "name" : "BUFFALOHULK",
      "screen_name" : "BUFFALOHULK",
      "indices" : [ 19, 31 ],
      "id_str" : "705378674",
      "id" : 705378674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535146132783915008",
  "text" : "RT @markpoloncarz: @BUFFALOHULK YES!!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BUFFALOHULK",
        "screen_name" : "BUFFALOHULK",
        "indices" : [ 0, 12 ],
        "id_str" : "705378674",
        "id" : 705378674
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "535070247754403840",
    "geo" : { },
    "id_str" : "535070354084216832",
    "in_reply_to_user_id" : 705378674,
    "text" : "@BUFFALOHULK YES!!!!",
    "id" : 535070354084216832,
    "in_reply_to_status_id" : 535070247754403840,
    "created_at" : "2014-11-19 14:01:28 +0000",
    "in_reply_to_screen_name" : "BUFFALOHULK",
    "in_reply_to_user_id_str" : "705378674",
    "user" : {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "protected" : false,
      "id_str" : "45490102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572114131579179008\/EAk-fMOk_normal.jpeg",
      "id" : 45490102,
      "verified" : false
    }
  },
  "id" : 535146132783915008,
  "created_at" : "2014-11-19 19:02:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BUFFALOHULK",
      "screen_name" : "BUFFALOHULK",
      "indices" : [ 3, 15 ],
      "id_str" : "705378674",
      "id" : 705378674
    }, {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 17, 31 ],
      "id_str" : "45490102",
      "id" : 45490102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535146116363599873",
  "text" : "RT @BUFFALOHULK: @markpoloncarz YOU NEED HULK TO MOVE SOME CARS AND SNOW?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Poloncarz",
        "screen_name" : "markpoloncarz",
        "indices" : [ 0, 14 ],
        "id_str" : "45490102",
        "id" : 45490102
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535070247754403840",
    "in_reply_to_user_id" : 45490102,
    "text" : "@markpoloncarz YOU NEED HULK TO MOVE SOME CARS AND SNOW?",
    "id" : 535070247754403840,
    "created_at" : "2014-11-19 14:01:02 +0000",
    "in_reply_to_screen_name" : "markpoloncarz",
    "in_reply_to_user_id_str" : "45490102",
    "user" : {
      "name" : "BUFFALOHULK",
      "screen_name" : "BUFFALOHULK",
      "protected" : false,
      "id_str" : "705378674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2412628277\/hulkbuffalo_normal.gif",
      "id" : 705378674,
      "verified" : false
    }
  },
  "id" : 535146116363599873,
  "created_at" : "2014-11-19 19:02:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 4, 13 ],
      "id_str" : "16222737",
      "id" : 16222737
    }, {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 31, 41 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/6hyIGWTPgx",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=XN5a7rk2pzI",
      "display_url" : "youtube.com\/watch?v=XN5a7r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535134502901649408",
  "text" : "The @rubyconf live stream from @confreaks is really fantastic: https:\/\/t.co\/6hyIGWTPgx",
  "id" : 535134502901649408,
  "created_at" : "2014-11-19 18:16:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tow truck central",
      "screen_name" : "duh_nellll",
      "indices" : [ 0, 11 ],
      "id_str" : "146513248",
      "id" : 146513248
    }, {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 12, 25 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535121819947515904",
  "geo" : { },
  "id_str" : "535122754085744640",
  "in_reply_to_user_id" : 146513248,
  "text" : "@duh_nellll @antelopeezer Dang it. Also glad you made it back.",
  "id" : 535122754085744640,
  "in_reply_to_status_id" : 535121819947515904,
  "created_at" : "2014-11-19 17:29:41 +0000",
  "in_reply_to_screen_name" : "duh_nellll",
  "in_reply_to_user_id_str" : "146513248",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/rqLF1WmVdj",
      "expanded_url" : "http:\/\/rubygems.org\/",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "535122691502526464",
  "text" : "4 BILLION! http:\/\/t.co\/rqLF1WmVdj",
  "id" : 535122691502526464,
  "created_at" : "2014-11-19 17:29:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535118697988624385",
  "geo" : { },
  "id_str" : "535120554227818497",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer so gonna make it to the Heavy Pets show?!? :P",
  "id" : 535120554227818497,
  "in_reply_to_status_id" : 535118697988624385,
  "created_at" : "2014-11-19 17:20:56 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "indices" : [ 0, 14 ],
      "id_str" : "369585978",
      "id" : 369585978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535108090967109633",
  "geo" : { },
  "id_str" : "535108285498548227",
  "in_reply_to_user_id" : 369585978,
  "text" : "@meaganewaller wow those scientologists are trying new angles out",
  "id" : 535108285498548227,
  "in_reply_to_status_id" : 535108090967109633,
  "created_at" : "2014-11-19 16:32:11 +0000",
  "in_reply_to_screen_name" : "meaganewaller",
  "in_reply_to_user_id_str" : "369585978",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535090819280416768",
  "geo" : { },
  "id_str" : "535091112768065537",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale fuckin miracles in every way",
  "id" : 535091112768065537,
  "in_reply_to_status_id" : 535090819280416768,
  "created_at" : "2014-11-19 15:23:57 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00D8rta",
      "screen_name" : "orta",
      "indices" : [ 3, 8 ],
      "id_str" : "2569881",
      "id" : 2569881
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 27, 36 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/w4vZ9SCdX7",
      "expanded_url" : "https:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "535090003567591424",
  "text" : "RT @orta: I _love_ the new @rubygems website.\n\nReally really well done. https:\/\/t.co\/w4vZ9SCdX7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyGems",
        "screen_name" : "rubygems",
        "indices" : [ 17, 26 ],
        "id_str" : "14881835",
        "id" : 14881835
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/w4vZ9SCdX7",
        "expanded_url" : "https:\/\/rubygems.org",
        "display_url" : "rubygems.org"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 40.7190332838, -74.0025536083 ]
    },
    "id_str" : "535086559041957889",
    "text" : "I _love_ the new @rubygems website.\n\nReally really well done. https:\/\/t.co\/w4vZ9SCdX7",
    "id" : 535086559041957889,
    "created_at" : "2014-11-19 15:05:51 +0000",
    "user" : {
      "name" : "\u00D8rta",
      "screen_name" : "orta",
      "protected" : false,
      "id_str" : "2569881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549202886253887488\/iFw5zrSw_normal.jpeg",
      "id" : 2569881,
      "verified" : false
    }
  },
  "id" : 535090003567591424,
  "created_at" : "2014-11-19 15:19:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 73, 80 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/wdfGlEJZQn",
      "expanded_url" : "https:\/\/medium.com\/the-nib\/what-to-pack-for-certain-death-11cc8f343f31",
      "display_url" : "medium.com\/the-nib\/what-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535085838887960576",
  "text" : "Good ideas for winter storm prep in Buffalo https:\/\/t.co\/wdfGlEJZQn (via @ftrain)",
  "id" : 535085838887960576,
  "created_at" : "2014-11-19 15:03:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "indyK1ng",
      "screen_name" : "indyK1ng",
      "indices" : [ 0, 9 ],
      "id_str" : "18765238",
      "id" : 18765238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535077760922705920",
  "geo" : { },
  "id_str" : "535085053915574273",
  "in_reply_to_user_id" : 18765238,
  "text" : "@indyK1ng come here and get it",
  "id" : 535085053915574273,
  "in_reply_to_status_id" : 535077760922705920,
  "created_at" : "2014-11-19 14:59:52 +0000",
  "in_reply_to_screen_name" : "indyK1ng",
  "in_reply_to_user_id_str" : "18765238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535069376399937536",
  "text" : "Snow band seems to have moved northward out of downtown. Just another 3-4\u2033 or so.",
  "id" : 535069376399937536,
  "created_at" : "2014-11-19 13:57:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 3, 17 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/ndcnCS9KyN",
      "expanded_url" : "http:\/\/wp.me\/p1fV9-a7v",
      "display_url" : "wp.me\/p1fV9-a7v"
    } ]
  },
  "geo" : { },
  "id_str" : "535062803837501440",
  "text" : "RT @buffalopundit: Buffalo Knows Snow http:\/\/t.co\/ndcnCS9KyN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/ndcnCS9KyN",
        "expanded_url" : "http:\/\/wp.me\/p1fV9-a7v",
        "display_url" : "wp.me\/p1fV9-a7v"
      } ]
    },
    "geo" : { },
    "id_str" : "535056052065038336",
    "text" : "Buffalo Knows Snow http:\/\/t.co\/ndcnCS9KyN",
    "id" : 535056052065038336,
    "created_at" : "2014-11-19 13:04:38 +0000",
    "user" : {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "protected" : false,
      "id_str" : "5795572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554430715308560384\/LnSJ-sAY_normal.jpeg",
      "id" : 5795572,
      "verified" : false
    }
  },
  "id" : 535062803837501440,
  "created_at" : "2014-11-19 13:31:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535062490200014848",
  "text" : "RT @coworkbuffalo: We are once more effectively closed today, unless existing members can walk across their roof or take the sewers here. S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535054366424973312",
    "text" : "We are once more effectively closed today, unless existing members can walk across their roof or take the sewers here. Stay safe, folks.",
    "id" : 535054366424973312,
    "created_at" : "2014-11-19 12:57:56 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 535062490200014848,
  "created_at" : "2014-11-19 13:30:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535054258710654977",
  "text" : "This snow is one thing but if 5-6 feet of snow melts this weekend some towns are going to be in some major trouble.",
  "id" : 535054258710654977,
  "created_at" : "2014-11-19 12:57:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535048112814170112",
  "geo" : { },
  "id_str" : "535048186595778560",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer lol",
  "id" : 535048186595778560,
  "in_reply_to_status_id" : 535048112814170112,
  "created_at" : "2014-11-19 12:33:23 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erie County DPW",
      "screen_name" : "ErieCountyDPW",
      "indices" : [ 0, 14 ],
      "id_str" : "2775996411",
      "id" : 2775996411
    }, {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 15, 29 ],
      "id_str" : "45490102",
      "id" : 45490102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535032227915390976",
  "geo" : { },
  "id_str" : "535048001668931585",
  "in_reply_to_user_id" : 2775996411,
  "text" : "@ErieCountyDPW @markpoloncarz that\u2019s awesome. Is this page publicly available?",
  "id" : 535048001668931585,
  "in_reply_to_status_id" : 535032227915390976,
  "created_at" : "2014-11-19 12:32:38 +0000",
  "in_reply_to_screen_name" : "ErieCountyDPW",
  "in_reply_to_user_id_str" : "2775996411",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Scarcello",
      "screen_name" : "WordsWithSam",
      "indices" : [ 0, 13 ],
      "id_str" : "26401150",
      "id" : 26401150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535033996372361216",
  "geo" : { },
  "id_str" : "535047886673694720",
  "in_reply_to_user_id" : 26401150,
  "text" : "@WordsWithSam or my dog got out",
  "id" : 535047886673694720,
  "in_reply_to_status_id" : 535033996372361216,
  "created_at" : "2014-11-19 12:32:11 +0000",
  "in_reply_to_screen_name" : "WordsWithSam",
  "in_reply_to_user_id_str" : "26401150",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535047412386000896",
  "text" : "Oh no the snow band moved north.",
  "id" : 535047412386000896,
  "created_at" : "2014-11-19 12:30:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Gilbert",
      "screen_name" : "zackgilbert",
      "indices" : [ 0, 12 ],
      "id_str" : "822454",
      "id" : 822454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534953701279272960",
  "geo" : { },
  "id_str" : "534991694731563008",
  "in_reply_to_user_id" : 822454,
  "text" : "@zackgilbert yeah. It looks awful. We live in the city in Elmwood Village and have been lucky so far",
  "id" : 534991694731563008,
  "in_reply_to_status_id" : 534953701279272960,
  "created_at" : "2014-11-19 08:48:54 +0000",
  "in_reply_to_screen_name" : "zackgilbert",
  "in_reply_to_user_id_str" : "822454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534937233028300800",
  "geo" : { },
  "id_str" : "534937380025663488",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox I\u2019ll take credit for that \uD83D\uDE01",
  "id" : 534937380025663488,
  "in_reply_to_status_id" : 534937233028300800,
  "created_at" : "2014-11-19 05:13:04 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534936907638394881",
  "geo" : { },
  "id_str" : "534937061988397056",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox no credit deserved here! I just learned this was happening a few weeks ago.",
  "id" : 534937061988397056,
  "in_reply_to_status_id" : 534936907638394881,
  "created_at" : "2014-11-19 05:11:48 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/hYwjaMPYpW",
      "expanded_url" : "https:\/\/twitter.com\/ilikevests\/status\/534935718460923904",
      "display_url" : "twitter.com\/ilikevests\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534936318946443264",
  "text" : "Where does YC continue to find so many dudes for the meat grinder? https:\/\/t.co\/hYwjaMPYpW",
  "id" : 534936318946443264,
  "created_at" : "2014-11-19 05:08:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Bayer",
      "screen_name" : "vogon",
      "indices" : [ 0, 6 ],
      "id_str" : "6326912",
      "id" : 6326912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534930056632479744",
  "geo" : { },
  "id_str" : "534933573560586240",
  "in_reply_to_user_id" : 6326912,
  "text" : "@vogon welp that\u2019s it you beat wow time to cancel",
  "id" : 534933573560586240,
  "in_reply_to_status_id" : 534930056632479744,
  "created_at" : "2014-11-19 04:57:57 +0000",
  "in_reply_to_screen_name" : "vogon",
  "in_reply_to_user_id_str" : "6326912",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Fry",
      "screen_name" : "JamesAFry",
      "indices" : [ 3, 13 ],
      "id_str" : "104649717",
      "id" : 104649717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JamesAFry\/status\/534927493837651969\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/oSBLhyPECF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2xxtg9IMAA_qmU.jpg",
      "id_str" : "534927482504622080",
      "id" : 534927482504622080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2xxtg9IMAA_qmU.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/oSBLhyPECF"
    } ],
    "hashtags" : [ {
      "text" : "buffalo",
      "indices" : [ 26, 34 ]
    }, {
      "text" : "snowmageddon14",
      "indices" : [ 43, 58 ]
    }, {
      "text" : "LakeEffect",
      "indices" : [ 59, 70 ]
    }, {
      "text" : "beyondthewall",
      "indices" : [ 71, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534933208593203200",
  "text" : "RT @JamesAFry: Landing in #buffalo at 11pm #snowmageddon14 #LakeEffect #beyondthewall http:\/\/t.co\/oSBLhyPECF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JamesAFry\/status\/534927493837651969\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/oSBLhyPECF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2xxtg9IMAA_qmU.jpg",
        "id_str" : "534927482504622080",
        "id" : 534927482504622080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2xxtg9IMAA_qmU.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 581,
          "resize" : "fit",
          "w" : 1032
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/oSBLhyPECF"
      } ],
      "hashtags" : [ {
        "text" : "buffalo",
        "indices" : [ 11, 19 ]
      }, {
        "text" : "snowmageddon14",
        "indices" : [ 28, 43 ]
      }, {
        "text" : "LakeEffect",
        "indices" : [ 44, 55 ]
      }, {
        "text" : "beyondthewall",
        "indices" : [ 56, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "534927493837651969",
    "text" : "Landing in #buffalo at 11pm #snowmageddon14 #LakeEffect #beyondthewall http:\/\/t.co\/oSBLhyPECF",
    "id" : 534927493837651969,
    "created_at" : "2014-11-19 04:33:47 +0000",
    "user" : {
      "name" : "James A Fry",
      "screen_name" : "JamesAFry",
      "protected" : false,
      "id_str" : "104649717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629677446\/Christmas_2009_047_normal.JPG",
      "id" : 104649717,
      "verified" : false
    }
  },
  "id" : 534933208593203200,
  "created_at" : "2014-11-19 04:56:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 25, 34 ],
      "id_str" : "19297751",
      "id" : 19297751
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 36, 50 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534927493275193344",
  "text" : "Fixed DNS for quaran.to, @gitready, @coworkbuffalo and of course now TTL is the problem. \/play horn",
  "id" : 534927493275193344,
  "created_at" : "2014-11-19 04:33:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Past",
      "screen_name" : "JasonRPast",
      "indices" : [ 0, 11 ],
      "id_str" : "113540027",
      "id" : 113540027
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 12, 26 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534898305600593920",
  "geo" : { },
  "id_str" : "534923784516419584",
  "in_reply_to_user_id" : 113540027,
  "text" : "@JasonRPast @coworkbuffalo gah yeah github is doing some \u201Cbrownouts\u201D. Need to fix it up. We are most likely closed tomorrow anyways :)",
  "id" : 534923784516419584,
  "in_reply_to_status_id" : 534898305600593920,
  "created_at" : "2014-11-19 04:19:03 +0000",
  "in_reply_to_screen_name" : "JasonRPast",
  "in_reply_to_user_id_str" : "113540027",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534922238718648320",
  "geo" : { },
  "id_str" : "534922337754169344",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer you\u2019ve made a huge mistake",
  "id" : 534922337754169344,
  "in_reply_to_status_id" : 534922238718648320,
  "created_at" : "2014-11-19 04:13:18 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 0, 13 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534918233187291136",
  "geo" : { },
  "id_str" : "534921820147703808",
  "in_reply_to_user_id" : 14204623,
  "text" : "@moonpolysoft I won\u2019t arrest you",
  "id" : 534921820147703808,
  "in_reply_to_status_id" : 534918233187291136,
  "created_at" : "2014-11-19 04:11:14 +0000",
  "in_reply_to_screen_name" : "moonpolysoft",
  "in_reply_to_user_id_str" : "14204623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534919110518665216",
  "geo" : { },
  "id_str" : "534921578643877888",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer you got stuck?!? Wtf man",
  "id" : 534921578643877888,
  "in_reply_to_status_id" : 534919110518665216,
  "created_at" : "2014-11-19 04:10:17 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Panovich",
      "screen_name" : "wxbrad",
      "indices" : [ 3, 10 ],
      "id_str" : "22215485",
      "id" : 22215485
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/wxbrad\/status\/534907422289428480\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Niz8bJdke7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2xfd2GIEAEEjIP.jpg",
      "id_str" : "534907422092300289",
      "id" : 534907422092300289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2xfd2GIEAEEjIP.jpg",
      "sizes" : [ {
        "h" : 364,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 621,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1207
      } ],
      "display_url" : "pic.twitter.com\/Niz8bJdke7"
    } ],
    "hashtags" : [ {
      "text" : "Bufwx",
      "indices" : [ 92, 98 ]
    }, {
      "text" : "LakeEffect",
      "indices" : [ 99, 110 ]
    }, {
      "text" : "nywx",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534912427695955968",
  "text" : "RT @wxbrad: These locations are just 6 mi apart but one got has 60\" of snow the other 3.9\". #Bufwx #LakeEffect #nywx http:\/\/t.co\/Niz8bJdke7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/wxbrad\/status\/534907422289428480\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/Niz8bJdke7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2xfd2GIEAEEjIP.jpg",
        "id_str" : "534907422092300289",
        "id" : 534907422092300289,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2xfd2GIEAEEjIP.jpg",
        "sizes" : [ {
          "h" : 364,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 206,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 621,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1207
        } ],
        "display_url" : "pic.twitter.com\/Niz8bJdke7"
      } ],
      "hashtags" : [ {
        "text" : "Bufwx",
        "indices" : [ 80, 86 ]
      }, {
        "text" : "LakeEffect",
        "indices" : [ 87, 98 ]
      }, {
        "text" : "nywx",
        "indices" : [ 99, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "534907422289428480",
    "text" : "These locations are just 6 mi apart but one got has 60\" of snow the other 3.9\". #Bufwx #LakeEffect #nywx http:\/\/t.co\/Niz8bJdke7",
    "id" : 534907422289428480,
    "created_at" : "2014-11-19 03:14:02 +0000",
    "user" : {
      "name" : "Brad Panovich",
      "screen_name" : "wxbrad",
      "protected" : false,
      "id_str" : "22215485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/495078741270224896\/h4qoVRWY_normal.jpeg",
      "id" : 22215485,
      "verified" : true
    }
  },
  "id" : 534912427695955968,
  "created_at" : "2014-11-19 03:33:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 3, 10 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "DockYard",
      "screen_name" : "DockYard",
      "indices" : [ 112, 121 ],
      "id_str" : "18545770",
      "id" : 18545770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/0G0NLUlj6a",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "534909945590726656",
  "text" : "RT @sferik: There\u2019s a new design for http:\/\/t.co\/0G0NLUlj6a as we approach 4 billion gems served. Great work by @DockYard.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DockYard",
        "screen_name" : "DockYard",
        "indices" : [ 100, 109 ],
        "id_str" : "18545770",
        "id" : 18545770
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/0G0NLUlj6a",
        "expanded_url" : "http:\/\/rubygems.org",
        "display_url" : "rubygems.org"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 52.5378207583, 13.3970325828 ]
    },
    "id_str" : "534877916761698304",
    "text" : "There\u2019s a new design for http:\/\/t.co\/0G0NLUlj6a as we approach 4 billion gems served. Great work by @DockYard.",
    "id" : 534877916761698304,
    "created_at" : "2014-11-19 01:16:47 +0000",
    "user" : {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "protected" : false,
      "id_str" : "7505382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567932260847206401\/ErQwT5za_normal.jpeg",
      "id" : 7505382,
      "verified" : false
    }
  },
  "id" : 534909945590726656,
  "created_at" : "2014-11-19 03:24:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/9D0H0IoFAt",
      "expanded_url" : "http:\/\/pocket.co\/sKXXy",
      "display_url" : "pocket.co\/sKXXy"
    } ]
  },
  "geo" : { },
  "id_str" : "534904081546883072",
  "text" : "Wild chimpanzees plan brunch based on the fruits available. I can't even make this up. http:\/\/t.co\/9D0H0IoFAt",
  "id" : 534904081546883072,
  "created_at" : "2014-11-19 03:00:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534902744646025216",
  "geo" : { },
  "id_str" : "534902909280858112",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic the API does have all of this info. The front end and the back end for stats really needs help still afaik",
  "id" : 534902909280858112,
  "in_reply_to_status_id" : 534902744646025216,
  "created_at" : "2014-11-19 02:56:06 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Nguyen",
      "screen_name" : "dancow",
      "indices" : [ 3, 10 ],
      "id_str" : "14335332",
      "id" : 14335332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/51YIBcdx5M",
      "expanded_url" : "http:\/\/rubygems.org\/",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "534899719298764800",
  "text" : "RT @dancow: Whoa...what is this Ruby...gems...thing? It's homepage is so slick...is it Nodejs? http:\/\/t.co\/51YIBcdx5M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/51YIBcdx5M",
        "expanded_url" : "http:\/\/rubygems.org\/",
        "display_url" : "rubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "534891617975402496",
    "text" : "Whoa...what is this Ruby...gems...thing? It's homepage is so slick...is it Nodejs? http:\/\/t.co\/51YIBcdx5M",
    "id" : 534891617975402496,
    "created_at" : "2014-11-19 02:11:14 +0000",
    "user" : {
      "name" : "Dan Nguyen",
      "screen_name" : "dancow",
      "protected" : false,
      "id_str" : "14335332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3134267999\/54b1603856efb494c0fb6095089b769a_normal.jpeg",
      "id" : 14335332,
      "verified" : false
    }
  },
  "id" : 534899719298764800,
  "created_at" : "2014-11-19 02:43:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534897041512480768",
  "geo" : { },
  "id_str" : "534897457428045825",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic there was I think. Was causing problems and removed. I think the download stats are putting pressure on Redis once again.",
  "id" : 534897457428045825,
  "in_reply_to_status_id" : 534897041512480768,
  "created_at" : "2014-11-19 02:34:26 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Letterle",
      "screen_name" : "mletterle",
      "indices" : [ 0, 10 ],
      "id_str" : "458173",
      "id" : 458173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534892512432111616",
  "geo" : { },
  "id_str" : "534892768171016193",
  "in_reply_to_user_id" : 458173,
  "text" : "@mletterle been staring at these clouds all day. We are just north of the line.",
  "id" : 534892768171016193,
  "in_reply_to_status_id" : 534892512432111616,
  "created_at" : "2014-11-19 02:15:48 +0000",
  "in_reply_to_screen_name" : "mletterle",
  "in_reply_to_user_id_str" : "458173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DockYard",
      "screen_name" : "DockYard",
      "indices" : [ 92, 101 ],
      "id_str" : "18545770",
      "id" : 18545770
    }, {
      "name" : "MaTIAS eL HuMiLDE;)",
      "screen_name" : "rubycentral",
      "indices" : [ 106, 118 ],
      "id_str" : "256225697",
      "id" : 256225697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/33aYApI4Hq",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "534871456212344833",
  "text" : "New http:\/\/t.co\/33aYApI4Hq design is out now! It\u2019s grown up a lot since 2009. Big thanks to @dockyard and @rubycentral for making it real!",
  "id" : 534871456212344833,
  "created_at" : "2014-11-19 00:51:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534860580713414656",
  "text" : "I need some stuff that is worthy to read to send to Pocket. Any suggestions?",
  "id" : 534860580713414656,
  "created_at" : "2014-11-19 00:07:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "HI\u039BTVS",
      "screen_name" : "inky",
      "indices" : [ 97, 102 ],
      "id_str" : "13148",
      "id" : 13148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/fZkIudlSrb",
      "expanded_url" : "https:\/\/twitter.com\/inky\/status\/534838244312354816",
      "display_url" : "twitter.com\/inky\/status\/53\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534860429886251008",
  "text" : "RT @waxpancake: What happens if you send an image to every image-processing Twitter bot at once? @inky finds out. https:\/\/t.co\/fZkIudlSrb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HI\u039BTVS",
        "screen_name" : "inky",
        "indices" : [ 81, 86 ],
        "id_str" : "13148",
        "id" : 13148
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/fZkIudlSrb",
        "expanded_url" : "https:\/\/twitter.com\/inky\/status\/534838244312354816",
        "display_url" : "twitter.com\/inky\/status\/53\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "534859742053937152",
    "text" : "What happens if you send an image to every image-processing Twitter bot at once? @inky finds out. https:\/\/t.co\/fZkIudlSrb",
    "id" : 534859742053937152,
    "created_at" : "2014-11-19 00:04:34 +0000",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539845905889775616\/_tilXA5z_normal.png",
      "id" : 13461,
      "verified" : false
    }
  },
  "id" : 534860429886251008,
  "created_at" : "2014-11-19 00:07:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pote",
      "screen_name" : "poteland",
      "indices" : [ 0, 9 ],
      "id_str" : "49102992",
      "id" : 49102992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534856549207130113",
  "geo" : { },
  "id_str" : "534858463252611072",
  "in_reply_to_user_id" : 49102992,
  "text" : "@poteland Rhombus!",
  "id" : 534858463252611072,
  "in_reply_to_status_id" : 534856549207130113,
  "created_at" : "2014-11-18 23:59:29 +0000",
  "in_reply_to_screen_name" : "poteland",
  "in_reply_to_user_id_str" : "49102992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 3, 11 ],
      "id_str" : "2890961",
      "id" : 2890961
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Gizmodo\/status\/534846629707522048\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Ah2nldEteG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2woLP7IgAEmpsp.jpg",
      "id_str" : "534846629468471297",
      "id" : 534846629468471297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2woLP7IgAEmpsp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Ah2nldEteG"
    } ],
    "hashtags" : [ {
      "text" : "snowwall",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/QO67xQSlSe",
      "expanded_url" : "http:\/\/gizmo.do\/zund7oa",
      "display_url" : "gizmo.do\/zund7oa"
    } ]
  },
  "geo" : { },
  "id_str" : "534850596696621056",
  "text" : "RT @Gizmodo: Holy mother of god, check out the videos and photos of the giant #snowwall swallowing Buffalo http:\/\/t.co\/QO67xQSlSe http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Gizmodo\/status\/534846629707522048\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Ah2nldEteG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2woLP7IgAEmpsp.jpg",
        "id_str" : "534846629468471297",
        "id" : 534846629468471297,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2woLP7IgAEmpsp.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Ah2nldEteG"
      } ],
      "hashtags" : [ {
        "text" : "snowwall",
        "indices" : [ 65, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/QO67xQSlSe",
        "expanded_url" : "http:\/\/gizmo.do\/zund7oa",
        "display_url" : "gizmo.do\/zund7oa"
      } ]
    },
    "geo" : { },
    "id_str" : "534846629707522048",
    "text" : "Holy mother of god, check out the videos and photos of the giant #snowwall swallowing Buffalo http:\/\/t.co\/QO67xQSlSe http:\/\/t.co\/Ah2nldEteG",
    "id" : 534846629707522048,
    "created_at" : "2014-11-18 23:12:28 +0000",
    "user" : {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "protected" : false,
      "id_str" : "2890961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1860214036\/Gizmodo-Twitter-Avatar_normal.jpeg",
      "id" : 2890961,
      "verified" : true
    }
  },
  "id" : 534850596696621056,
  "created_at" : "2014-11-18 23:28:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 3, 13 ],
      "id_str" : "15243796",
      "id" : 15243796
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 15, 21 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/PfkFB2n3fx",
      "expanded_url" : "http:\/\/youtubedoubler.com\/?video1=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DVxuacZudBPU&start1=0&video2=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DJ9d9UrK0Jsw&start2=0&authorName=",
      "display_url" : "youtubedoubler.com\/?video1=http%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534801044967288833",
  "text" : "RT @ngauthier: @qrush ENHANCE http:\/\/t.co\/PfkFB2n3fx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/PfkFB2n3fx",
        "expanded_url" : "http:\/\/youtubedoubler.com\/?video1=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DVxuacZudBPU&start1=0&video2=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DJ9d9UrK0Jsw&start2=0&authorName=",
        "display_url" : "youtubedoubler.com\/?video1=http%3\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "534798325816778752",
    "geo" : { },
    "id_str" : "534800199060029440",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush ENHANCE http:\/\/t.co\/PfkFB2n3fx",
    "id" : 534800199060029440,
    "in_reply_to_status_id" : 534798325816778752,
    "created_at" : "2014-11-18 20:07:58 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "protected" : false,
      "id_str" : "15243796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539452893112201217\/aJOphfgM_normal.png",
      "id" : 15243796,
      "verified" : false
    }
  },
  "id" : 534801044967288833,
  "created_at" : "2014-11-18 20:11:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/FtNDYKx3qL",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=VxuacZudBPU",
      "display_url" : "youtube.com\/watch?v=VxuacZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534798325816778752",
  "text" : "Timelapse of lake effect picking up https:\/\/t.co\/FtNDYKx3qL",
  "id" : 534798325816778752,
  "created_at" : "2014-11-18 20:00:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Newland",
      "screen_name" : "jnewland",
      "indices" : [ 0, 9 ],
      "id_str" : "13518",
      "id" : 13518
    }, {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 16, 22 ],
      "id_str" : "18673",
      "id" : 18673
    }, {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 52, 61 ],
      "id_str" : "148198686",
      "id" : 148198686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534794713115537408",
  "geo" : { },
  "id_str" : "534795412591624192",
  "in_reply_to_user_id" : 13518,
  "text" : "@jnewland heyyy @aeden is there an easy upgrade for @dnsimple powered domains?",
  "id" : 534795412591624192,
  "in_reply_to_status_id" : 534794713115537408,
  "created_at" : "2014-11-18 19:48:57 +0000",
  "in_reply_to_screen_name" : "jnewland",
  "in_reply_to_user_id_str" : "13518",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Newland",
      "screen_name" : "jnewland",
      "indices" : [ 0, 9 ],
      "id_str" : "13518",
      "id" : 13518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534793256777691136",
  "geo" : { },
  "id_str" : "534794250127695872",
  "in_reply_to_user_id" : 13518,
  "text" : "@jnewland I sure did, but i skimmed over and just remembered the blackout date. My fault obviously.",
  "id" : 534794250127695872,
  "in_reply_to_status_id" : 534793256777691136,
  "created_at" : "2014-11-18 19:44:19 +0000",
  "in_reply_to_screen_name" : "jnewland",
  "in_reply_to_user_id_str" : "13518",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    }, {
      "name" : "Jesse Newland",
      "screen_name" : "jnewland",
      "indices" : [ 74, 83 ],
      "id_str" : "13518",
      "id" : 13518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534789625043107840",
  "geo" : { },
  "id_str" : "534790193170350080",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman ah, i didn't get as far as the brownout. i wonder if any did. \/cc @jnewland",
  "id" : 534790193170350080,
  "in_reply_to_status_id" : 534789625043107840,
  "created_at" : "2014-11-18 19:28:12 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Newland",
      "screen_name" : "jnewland",
      "indices" : [ 0, 9 ],
      "id_str" : "13518",
      "id" : 13518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534789369966518272",
  "geo" : { },
  "id_str" : "534789543791435777",
  "in_reply_to_user_id" : 13518,
  "text" : "@jnewland i know it's free but some kind of warning this was going to happen would have been nice. also i'd pay for this not to happen, ever",
  "id" : 534789543791435777,
  "in_reply_to_status_id" : 534789369966518272,
  "created_at" : "2014-11-18 19:25:37 +0000",
  "in_reply_to_screen_name" : "jnewland",
  "in_reply_to_user_id_str" : "13518",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534788832214781952",
  "geo" : { },
  "id_str" : "534789374484168705",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman doing this in the middle of the day without warning is really inconsiderate to everyone's time :(",
  "id" : 534789374484168705,
  "in_reply_to_status_id" : 534788832214781952,
  "created_at" : "2014-11-18 19:24:57 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/kq6x1p0wZn",
      "expanded_url" : "https:\/\/github.com\/blog\/1925-github-pages-legacy-ip-brownout",
      "display_url" : "github.com\/blog\/1925-gith\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534788460012642304",
  "text" : "Lame. https:\/\/t.co\/kq6x1p0wZn",
  "id" : 534788460012642304,
  "created_at" : "2014-11-18 19:21:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish Dry Goods",
      "screen_name" : "phishdrygoods",
      "indices" : [ 3, 17 ],
      "id_str" : "69779454",
      "id" : 69779454
    }, {
      "name" : "Oxford Pennant",
      "screen_name" : "OxfordPennant",
      "indices" : [ 93, 107 ],
      "id_str" : "2213449884",
      "id" : 2213449884
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/phishdrygoods\/status\/534420515147243520\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/FIhXUjMC4z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2qkoF-CUAEq7LH.jpg",
      "id_str" : "534420514500923393",
      "id" : 534420514500923393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2qkoF-CUAEq7LH.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/FIhXUjMC4z"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/d39qYouyBY",
      "expanded_url" : "http:\/\/drygoods.phish.com\/Product.aspx?cp=773_1428&pc=PHAM415",
      "display_url" : "drygoods.phish.com\/Product.aspx?c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534785700026388480",
  "text" : "RT @phishdrygoods: Get it: \"Waiting All Night\" wool felt pennant. Manufactured in the USA by @OxfordPennant http:\/\/t.co\/d39qYouyBY http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oxford Pennant",
        "screen_name" : "OxfordPennant",
        "indices" : [ 74, 88 ],
        "id_str" : "2213449884",
        "id" : 2213449884
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/phishdrygoods\/status\/534420515147243520\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/FIhXUjMC4z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2qkoF-CUAEq7LH.jpg",
        "id_str" : "534420514500923393",
        "id" : 534420514500923393,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2qkoF-CUAEq7LH.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/FIhXUjMC4z"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/d39qYouyBY",
        "expanded_url" : "http:\/\/drygoods.phish.com\/Product.aspx?cp=773_1428&pc=PHAM415",
        "display_url" : "drygoods.phish.com\/Product.aspx?c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "534420515147243520",
    "text" : "Get it: \"Waiting All Night\" wool felt pennant. Manufactured in the USA by @OxfordPennant http:\/\/t.co\/d39qYouyBY http:\/\/t.co\/FIhXUjMC4z",
    "id" : 534420515147243520,
    "created_at" : "2014-11-17 18:59:14 +0000",
    "user" : {
      "name" : "Phish Dry Goods",
      "screen_name" : "phishdrygoods",
      "protected" : false,
      "id_str" : "69779454",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500007861489922050\/zxu6P9XK_normal.jpeg",
      "id" : 69779454,
      "verified" : false
    }
  },
  "id" : 534785700026388480,
  "created_at" : "2014-11-18 19:10:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tow truck central",
      "screen_name" : "duh_nellll",
      "indices" : [ 0, 11 ],
      "id_str" : "146513248",
      "id" : 146513248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534784399142047744",
  "geo" : { },
  "id_str" : "534784660191318016",
  "in_reply_to_user_id" : 146513248,
  "text" : "@duh_nellll YOUR TRIP IS UNADVISABLE AND YOU WILL BECOME TRAPPED",
  "id" : 534784660191318016,
  "in_reply_to_status_id" : 534784399142047744,
  "created_at" : "2014-11-18 19:06:13 +0000",
  "in_reply_to_screen_name" : "duh_nellll",
  "in_reply_to_user_id_str" : "146513248",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/ihIlsJzSou",
      "expanded_url" : "http:\/\/media-cache-ak0.pinimg.com\/736x\/11\/3e\/3e\/113e3e498790c4e55ff0f46a73fd13c8.jpg",
      "display_url" : "media-cache-ak0.pinimg.com\/736x\/11\/3e\/3e\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534784561251897344",
  "text" : "Current status http:\/\/t.co\/ihIlsJzSou",
  "id" : 534784561251897344,
  "created_at" : "2014-11-18 19:05:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Upton",
      "screen_name" : "uptonic",
      "indices" : [ 0, 8 ],
      "id_str" : "14408469",
      "id" : 14408469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534752002107248640",
  "geo" : { },
  "id_str" : "534752180683931649",
  "in_reply_to_user_id" : 14408469,
  "text" : "@uptonic do they charge for this coworking space?",
  "id" : 534752180683931649,
  "in_reply_to_status_id" : 534752002107248640,
  "created_at" : "2014-11-18 16:57:09 +0000",
  "in_reply_to_screen_name" : "uptonic",
  "in_reply_to_user_id_str" : "14408469",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karissa Hejna",
      "screen_name" : "hejna122",
      "indices" : [ 3, 12 ],
      "id_str" : "2371556291",
      "id" : 2371556291
    }, {
      "name" : "WGRZ",
      "screen_name" : "WGRZ",
      "indices" : [ 62, 67 ],
      "id_str" : "15308015",
      "id" : 15308015
    }, {
      "name" : "Country 106.5 WYRK",
      "screen_name" : "1065WYRK",
      "indices" : [ 68, 77 ],
      "id_str" : "15137073",
      "id" : 15137073
    }, {
      "name" : "7 Eyewitness News",
      "screen_name" : "WKBW",
      "indices" : [ 78, 83 ],
      "id_str" : "23686162",
      "id" : 23686162
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hejna122\/status\/534730430915035137\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/4mBW2LPZSE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2u-e22CEAAbYkf.jpg",
      "id_str" : "534730418101030912",
      "id" : 534730418101030912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2u-e22CEAAbYkf.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4mBW2LPZSE"
    } ],
    "hashtags" : [ {
      "text" : "truehero",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534732282431410176",
  "text" : "RT @hejna122: Buffalo fireman walking to work today #truehero @WGRZ @1065WYRK @WKBW http:\/\/t.co\/4mBW2LPZSE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WGRZ",
        "screen_name" : "WGRZ",
        "indices" : [ 48, 53 ],
        "id_str" : "15308015",
        "id" : 15308015
      }, {
        "name" : "Country 106.5 WYRK",
        "screen_name" : "1065WYRK",
        "indices" : [ 54, 63 ],
        "id_str" : "15137073",
        "id" : 15137073
      }, {
        "name" : "7 Eyewitness News",
        "screen_name" : "WKBW",
        "indices" : [ 64, 69 ],
        "id_str" : "23686162",
        "id" : 23686162
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/hejna122\/status\/534730430915035137\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/4mBW2LPZSE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2u-e22CEAAbYkf.jpg",
        "id_str" : "534730418101030912",
        "id" : 534730418101030912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2u-e22CEAAbYkf.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/4mBW2LPZSE"
      } ],
      "hashtags" : [ {
        "text" : "truehero",
        "indices" : [ 38, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "534730430915035137",
    "text" : "Buffalo fireman walking to work today #truehero @WGRZ @1065WYRK @WKBW http:\/\/t.co\/4mBW2LPZSE",
    "id" : 534730430915035137,
    "created_at" : "2014-11-18 15:30:44 +0000",
    "user" : {
      "name" : "Karissa Hejna",
      "screen_name" : "hejna122",
      "protected" : false,
      "id_str" : "2371556291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544305091243962369\/BD_Z26cB_normal.jpeg",
      "id" : 2371556291,
      "verified" : false
    }
  },
  "id" : 534732282431410176,
  "created_at" : "2014-11-18 15:38:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Love",
      "screen_name" : "marcslove",
      "indices" : [ 3, 13 ],
      "id_str" : "15644361",
      "id" : 15644361
    }, {
      "name" : "Lyft",
      "screen_name" : "lyft",
      "indices" : [ 28, 33 ],
      "id_str" : "569569550",
      "id" : 569569550
    }, {
      "name" : "Uber",
      "screen_name" : "Uber",
      "indices" : [ 53, 58 ],
      "id_str" : "19103481",
      "id" : 19103481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534728874421006336",
  "text" : "RT @marcslove: If you think @Lyft is any better than @Uber, keep in mind their company\u2019s identify is based on the \u201Cmustache-ride\u201D pun.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lyft",
        "screen_name" : "lyft",
        "indices" : [ 13, 18 ],
        "id_str" : "569569550",
        "id" : 569569550
      }, {
        "name" : "Uber",
        "screen_name" : "Uber",
        "indices" : [ 38, 43 ],
        "id_str" : "19103481",
        "id" : 19103481
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "534561866337357826",
    "text" : "If you think @Lyft is any better than @Uber, keep in mind their company\u2019s identify is based on the \u201Cmustache-ride\u201D pun.",
    "id" : 534561866337357826,
    "created_at" : "2014-11-18 04:20:55 +0000",
    "user" : {
      "name" : "Marc Love",
      "screen_name" : "marcslove",
      "protected" : false,
      "id_str" : "15644361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493560225132068865\/KCvZMgXz_normal.jpeg",
      "id" : 15644361,
      "verified" : false
    }
  },
  "id" : 534728874421006336,
  "created_at" : "2014-11-18 15:24:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Borncamp",
      "screen_name" : "borncamp",
      "indices" : [ 0, 9 ],
      "id_str" : "1002573926",
      "id" : 1002573926
    }, {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 10, 17 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534723896113897472",
  "geo" : { },
  "id_str" : "534724080579002368",
  "in_reply_to_user_id" : 1002573926,
  "text" : "@borncamp @zobar2 wow what a deal! I hope you won\u2019t ask for a contract or money until it is delivered",
  "id" : 534724080579002368,
  "in_reply_to_status_id" : 534723896113897472,
  "created_at" : "2014-11-18 15:05:30 +0000",
  "in_reply_to_screen_name" : "borncamp",
  "in_reply_to_user_id_str" : "1002573926",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "Brian Borncamp",
      "screen_name" : "borncamp",
      "indices" : [ 8, 17 ],
      "id_str" : "1002573926",
      "id" : 1002573926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534708927565692928",
  "geo" : { },
  "id_str" : "534709626861023232",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 @borncamp sounds like something for that civic app challenge",
  "id" : 534709626861023232,
  "in_reply_to_status_id" : 534708927565692928,
  "created_at" : "2014-11-18 14:08:04 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/534685507741949952\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/nIq06ZTjUA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2uVomsCYAAynXt.png",
      "id_str" : "534685505586094080",
      "id" : 534685505586094080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2uVomsCYAAynXt.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nIq06ZTjUA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534684985551122432",
  "geo" : { },
  "id_str" : "534685507741949952",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack not much better, very windy http:\/\/t.co\/nIq06ZTjUA",
  "id" : 534685507741949952,
  "in_reply_to_status_id" : 534684985551122432,
  "created_at" : "2014-11-18 12:32:13 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beardo",
      "screen_name" : "Mechaphil",
      "indices" : [ 0, 10 ],
      "id_str" : "250785234",
      "id" : 250785234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534683420115607552",
  "geo" : { },
  "id_str" : "534683681000931328",
  "in_reply_to_user_id" : 250785234,
  "text" : "@Mechaphil ahh dang. My grandparents are near that Tim\u2019s and most likely are buried",
  "id" : 534683681000931328,
  "in_reply_to_status_id" : 534683420115607552,
  "created_at" : "2014-11-18 12:24:58 +0000",
  "in_reply_to_screen_name" : "Mechaphil",
  "in_reply_to_user_id_str" : "250785234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534682829381062657",
  "text" : "Only an inch or so of snow in the City of Buffalo. We got lucky so far.",
  "id" : 534682829381062657,
  "created_at" : "2014-11-18 12:21:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Bov\u00E9",
      "screen_name" : "Matt_Bove",
      "indices" : [ 3, 13 ],
      "id_str" : "258871053",
      "id" : 258871053
    }, {
      "name" : "7 Eyewitness News",
      "screen_name" : "WKBW",
      "indices" : [ 33, 38 ],
      "id_str" : "23686162",
      "id" : 23686162
    }, {
      "name" : "WKBW Weather",
      "screen_name" : "7FirstAlert",
      "indices" : [ 39, 51 ],
      "id_str" : "2794746065",
      "id" : 2794746065
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Matt_Bove\/status\/534677401683648512\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/sChQBzcUMx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2uOPuNCUAEpTbw.jpg",
      "id_str" : "534677381525426177",
      "id" : 534677381525426177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2uOPuNCUAEpTbw.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sChQBzcUMx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534682458717818880",
  "text" : "RT @Matt_Bove: I think it snowed @WKBW @7FirstAlert http:\/\/t.co\/sChQBzcUMx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "7 Eyewitness News",
        "screen_name" : "WKBW",
        "indices" : [ 18, 23 ],
        "id_str" : "23686162",
        "id" : 23686162
      }, {
        "name" : "WKBW Weather",
        "screen_name" : "7FirstAlert",
        "indices" : [ 24, 36 ],
        "id_str" : "2794746065",
        "id" : 2794746065
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Matt_Bove\/status\/534677401683648512\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/sChQBzcUMx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2uOPuNCUAEpTbw.jpg",
        "id_str" : "534677381525426177",
        "id" : 534677381525426177,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2uOPuNCUAEpTbw.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/sChQBzcUMx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.8712348501, -78.787061507 ]
    },
    "id_str" : "534677401683648512",
    "text" : "I think it snowed @WKBW @7FirstAlert http:\/\/t.co\/sChQBzcUMx",
    "id" : 534677401683648512,
    "created_at" : "2014-11-18 12:00:01 +0000",
    "user" : {
      "name" : "Matthew Bov\u00E9",
      "screen_name" : "Matt_Bove",
      "protected" : false,
      "id_str" : "258871053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488455820791672833\/efnwfuP__normal.jpeg",
      "id" : 258871053,
      "verified" : false
    }
  },
  "id" : 534682458717818880,
  "created_at" : "2014-11-18 12:20:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tessa Thornton",
      "screen_name" : "tessthornton",
      "indices" : [ 0, 13 ],
      "id_str" : "86598888",
      "id" : 86598888
    }, {
      "name" : "David Chang",
      "screen_name" : "davidchchang",
      "indices" : [ 14, 27 ],
      "id_str" : "23032290",
      "id" : 23032290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534579244899512320",
  "geo" : { },
  "id_str" : "534580404561272832",
  "in_reply_to_user_id" : 86598888,
  "text" : "@tessthornton @davidchchang i need to remember how to patch again, trying out a new font. Always include instructions!!",
  "id" : 534580404561272832,
  "in_reply_to_status_id" : 534579244899512320,
  "created_at" : "2014-11-18 05:34:35 +0000",
  "in_reply_to_screen_name" : "tessthornton",
  "in_reply_to_user_id_str" : "86598888",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Chong",
      "screen_name" : "sylvzc",
      "indices" : [ 0, 7 ],
      "id_str" : "2544124698",
      "id" : 2544124698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534577965657378817",
  "geo" : { },
  "id_str" : "534578892439187456",
  "in_reply_to_user_id" : 2544124698,
  "text" : "@sylvzc I don\u2019t understand 20 somethings",
  "id" : 534578892439187456,
  "in_reply_to_status_id" : 534577965657378817,
  "created_at" : "2014-11-18 05:28:34 +0000",
  "in_reply_to_screen_name" : "sylvzc",
  "in_reply_to_user_id_str" : "2544124698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kilzer",
      "screen_name" : "ddkilzer",
      "indices" : [ 0, 9 ],
      "id_str" : "63552322",
      "id" : 63552322
    }, {
      "name" : "smfr",
      "screen_name" : "smfr",
      "indices" : [ 10, 15 ],
      "id_str" : "14776762",
      "id" : 14776762
    }, {
      "name" : "Timothy Hatcher",
      "screen_name" : "xeenon",
      "indices" : [ 16, 23 ],
      "id_str" : "15400531",
      "id" : 15400531
    }, {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 44, 54 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534578140849262592",
  "in_reply_to_user_id" : 63552322,
  "text" : "@ddkilzer @smfr @xeenon not yet! Can do. Cc @zachwaugh",
  "id" : 534578140849262592,
  "created_at" : "2014-11-18 05:25:35 +0000",
  "in_reply_to_screen_name" : "ddkilzer",
  "in_reply_to_user_id_str" : "63552322",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kelliott",
      "screen_name" : "kelliotttt",
      "indices" : [ 3, 14 ],
      "id_str" : "14684697",
      "id" : 14684697
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kelliotttt\/status\/534252563432873986\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/HzhCbYMtgh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2oL30lCMAAhxWp.jpg",
      "id_str" : "534252559431512064",
      "id" : 534252559431512064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2oL30lCMAAhxWp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HzhCbYMtgh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534575144220385280",
  "text" : "RT @kelliotttt: Please stop giving money to nerds http:\/\/t.co\/HzhCbYMtgh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kelliotttt\/status\/534252563432873986\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/HzhCbYMtgh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2oL30lCMAAhxWp.jpg",
        "id_str" : "534252559431512064",
        "id" : 534252559431512064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2oL30lCMAAhxWp.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/HzhCbYMtgh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "534252329185193984",
    "geo" : { },
    "id_str" : "534252563432873986",
    "in_reply_to_user_id" : 14684697,
    "text" : "Please stop giving money to nerds http:\/\/t.co\/HzhCbYMtgh",
    "id" : 534252563432873986,
    "in_reply_to_status_id" : 534252329185193984,
    "created_at" : "2014-11-17 07:51:51 +0000",
    "in_reply_to_screen_name" : "kelliotttt",
    "in_reply_to_user_id_str" : "14684697",
    "user" : {
      "name" : "kelliott",
      "screen_name" : "kelliotttt",
      "protected" : false,
      "id_str" : "14684697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528581441928445952\/T_NBcYkB_normal.jpeg",
      "id" : 14684697,
      "verified" : false
    }
  },
  "id" : 534575144220385280,
  "created_at" : "2014-11-18 05:13:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/WgLRgDfoQH",
      "expanded_url" : "http:\/\/m.pnas.org\/content\/early\/2014\/11\/13\/1400229111",
      "display_url" : "m.pnas.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534562436913704960",
  "text" : "New term: \u201Cfemtorisks\u201D - http:\/\/t.co\/WgLRgDfoQH (I need to read more papers)",
  "id" : 534562436913704960,
  "created_at" : "2014-11-18 04:23:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "smfr",
      "screen_name" : "smfr",
      "indices" : [ 0, 5 ],
      "id_str" : "14776762",
      "id" : 14776762
    }, {
      "name" : "Timothy Hatcher",
      "screen_name" : "xeenon",
      "indices" : [ 6, 13 ],
      "id_str" : "15400531",
      "id" : 15400531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534465254730641408",
  "geo" : { },
  "id_str" : "534556016600309760",
  "in_reply_to_user_id" : 14776762,
  "text" : "@smfr @xeenon will WKWebView ever share cookies with other parts of the NSHTTP stack? Big problem for us so far in fully adopting it",
  "id" : 534556016600309760,
  "in_reply_to_status_id" : 534465254730641408,
  "created_at" : "2014-11-18 03:57:40 +0000",
  "in_reply_to_screen_name" : "smfr",
  "in_reply_to_user_id_str" : "14776762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534532560286937088",
  "geo" : { },
  "id_str" : "534541142503596032",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety we have maybe an inch so far in the city. (\u266F\uFF40\u2227\u00B4)",
  "id" : 534541142503596032,
  "in_reply_to_status_id" : 534532560286937088,
  "created_at" : "2014-11-18 02:58:34 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/534532143142420480\/photo\/1",
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/yZdApNho8J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2sKJrqIMAAJJXl.jpg",
      "id_str" : "534532142228058112",
      "id" : 534532142228058112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2sKJrqIMAAJJXl.jpg",
      "sizes" : [ {
        "h" : 532,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 532,
        "resize" : "fit",
        "w" : 639
      } ],
      "display_url" : "pic.twitter.com\/yZdApNho8J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534532179305320448",
  "text" : "RT @coworkbuffalo: We're going to be **members only** tomorrow, due to expected snow. Newcomers and day-passers: see you soon! http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/534532143142420480\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/yZdApNho8J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2sKJrqIMAAJJXl.jpg",
        "id_str" : "534532142228058112",
        "id" : 534532142228058112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2sKJrqIMAAJJXl.jpg",
        "sizes" : [ {
          "h" : 532,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 283,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 639
        } ],
        "display_url" : "pic.twitter.com\/yZdApNho8J"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "534532143142420480",
    "text" : "We're going to be **members only** tomorrow, due to expected snow. Newcomers and day-passers: see you soon! http:\/\/t.co\/yZdApNho8J",
    "id" : 534532143142420480,
    "created_at" : "2014-11-18 02:22:48 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 534532179305320448,
  "created_at" : "2014-11-18 02:22:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo\/Erie Library",
      "screen_name" : "buffalolibrary",
      "indices" : [ 3, 18 ],
      "id_str" : "34322946",
      "id" : 34322946
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buffalolibrary\/status\/534527819230216193\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/rXATJdB5Kn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2sGN-LIYAAq1WY.jpg",
      "id_str" : "534527817871286272",
      "id" : 534527817871286272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2sGN-LIYAAq1WY.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 526
      } ],
      "display_url" : "pic.twitter.com\/rXATJdB5Kn"
    } ],
    "hashtags" : [ {
      "text" : "buffalo",
      "indices" : [ 52, 60 ]
    }, {
      "text" : "books",
      "indices" : [ 61, 67 ]
    }, {
      "text" : "reading",
      "indices" : [ 68, 76 ]
    }, {
      "text" : "libraries",
      "indices" : [ 77, 87 ]
    }, {
      "text" : "winterstorm",
      "indices" : [ 88, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534532002783834112",
  "text" : "RT @buffalolibrary: Are you ready Western New York? #buffalo #books #reading #libraries #winterstorm http:\/\/t.co\/rXATJdB5Kn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/buffalolibrary\/status\/534527819230216193\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/rXATJdB5Kn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2sGN-LIYAAq1WY.jpg",
        "id_str" : "534527817871286272",
        "id" : 534527817871286272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2sGN-LIYAAq1WY.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 526,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 526,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 526,
          "resize" : "fit",
          "w" : 526
        } ],
        "display_url" : "pic.twitter.com\/rXATJdB5Kn"
      } ],
      "hashtags" : [ {
        "text" : "buffalo",
        "indices" : [ 32, 40 ]
      }, {
        "text" : "books",
        "indices" : [ 41, 47 ]
      }, {
        "text" : "reading",
        "indices" : [ 48, 56 ]
      }, {
        "text" : "libraries",
        "indices" : [ 57, 67 ]
      }, {
        "text" : "winterstorm",
        "indices" : [ 68, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "534527819230216193",
    "text" : "Are you ready Western New York? #buffalo #books #reading #libraries #winterstorm http:\/\/t.co\/rXATJdB5Kn",
    "id" : 534527819230216193,
    "created_at" : "2014-11-18 02:05:37 +0000",
    "user" : {
      "name" : "Buffalo\/Erie Library",
      "screen_name" : "buffalolibrary",
      "protected" : false,
      "id_str" : "34322946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552899931749380096\/AYFTbkPi_normal.png",
      "id" : 34322946,
      "verified" : false
    }
  },
  "id" : 534532002783834112,
  "created_at" : "2014-11-18 02:22:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534464124726824960",
  "text" : "RT @bquarant: Wow. Well, Snapcash will no doubt be used in many highly suspicious exchanges.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "534463859848142848",
    "text" : "Wow. Well, Snapcash will no doubt be used in many highly suspicious exchanges.",
    "id" : 534463859848142848,
    "created_at" : "2014-11-17 21:51:28 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 534464124726824960,
  "created_at" : "2014-11-17 21:52:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest W. Durbin III",
      "screen_name" : "EWDurbin",
      "indices" : [ 0, 9 ],
      "id_str" : "14590010",
      "id" : 14590010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534458328374456320",
  "geo" : { },
  "id_str" : "534458461019705345",
  "in_reply_to_user_id" : 14590010,
  "text" : "@EWDurbin I've come to talk to yo...zzzzzzzzzzzzzzz",
  "id" : 534458461019705345,
  "in_reply_to_status_id" : 534458328374456320,
  "created_at" : "2014-11-17 21:30:01 +0000",
  "in_reply_to_screen_name" : "EWDurbin",
  "in_reply_to_user_id_str" : "14590010",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/mmpSgKz7tW",
      "expanded_url" : "http:\/\/blog.snapchat.com\/post\/102895720555\/introducing-snapcash",
      "display_url" : "blog.snapchat.com\/post\/102895720\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534458171692425216",
  "text" : "Maybe I'm wrong, but isn't there an obvious use case for accepting $ through a service that keeps images temporarily? http:\/\/t.co\/mmpSgKz7tW",
  "id" : 534458171692425216,
  "created_at" : "2014-11-17 21:28:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina\u00AE",
      "screen_name" : "chrismessina",
      "indices" : [ 3, 16 ],
      "id_str" : "1186",
      "id" : 1186
    }, {
      "name" : "Alex Hillman",
      "screen_name" : "alexhillman",
      "indices" : [ 103, 115 ],
      "id_str" : "8412",
      "id" : 8412
    }, {
      "name" : "Brad Neuberg",
      "screen_name" : "bradneuberg",
      "indices" : [ 119, 131 ],
      "id_str" : "14608670",
      "id" : 14608670
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/chrismessina\/status\/534444165052919808\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/BLDaVzFgUz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2q6ItmCcAAGuwl.jpg",
      "id_str" : "534444164637683712",
      "id" : 534444164637683712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2q6ItmCcAAGuwl.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BLDaVzFgUz"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/chrismessina\/status\/534444165052919808\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/BLDaVzFgUz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2q6ItmCIAAFp7t.jpg",
      "id_str" : "534444164637663232",
      "id" : 534444164637663232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2q6ItmCIAAFp7t.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BLDaVzFgUz"
    } ],
    "hashtags" : [ {
      "text" : "coworking",
      "indices" : [ 31, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/Ots4LmG2lp",
      "expanded_url" : "http:\/\/www.smallbizlabs.com\/2014\/05\/coworking-forecast.html",
      "display_url" : "smallbizlabs.com\/2014\/05\/cowork\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534444698710982656",
  "text" : "RT @chrismessina: Staggered by #coworking's projected growth through 2018: http:\/\/t.co\/Ots4LmG2lp \/via @alexhillman cc @bradneuberg http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alex Hillman",
        "screen_name" : "alexhillman",
        "indices" : [ 85, 97 ],
        "id_str" : "8412",
        "id" : 8412
      }, {
        "name" : "Brad Neuberg",
        "screen_name" : "bradneuberg",
        "indices" : [ 101, 113 ],
        "id_str" : "14608670",
        "id" : 14608670
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/chrismessina\/status\/534444165052919808\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/BLDaVzFgUz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2q6ItmCcAAGuwl.jpg",
        "id_str" : "534444164637683712",
        "id" : 534444164637683712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2q6ItmCcAAGuwl.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BLDaVzFgUz"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/chrismessina\/status\/534444165052919808\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/BLDaVzFgUz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2q6ItmCIAAFp7t.jpg",
        "id_str" : "534444164637663232",
        "id" : 534444164637663232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2q6ItmCIAAFp7t.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BLDaVzFgUz"
      } ],
      "hashtags" : [ {
        "text" : "coworking",
        "indices" : [ 13, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/Ots4LmG2lp",
        "expanded_url" : "http:\/\/www.smallbizlabs.com\/2014\/05\/coworking-forecast.html",
        "display_url" : "smallbizlabs.com\/2014\/05\/cowork\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "534444165052919808",
    "text" : "Staggered by #coworking's projected growth through 2018: http:\/\/t.co\/Ots4LmG2lp \/via @alexhillman cc @bradneuberg http:\/\/t.co\/BLDaVzFgUz",
    "id" : 534444165052919808,
    "created_at" : "2014-11-17 20:33:13 +0000",
    "user" : {
      "name" : "Chris Messina\u00AE",
      "screen_name" : "chrismessina",
      "protected" : false,
      "id_str" : "1186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540697175609454592\/tMtgCBAj_normal.jpeg",
      "id" : 1186,
      "verified" : false
    }
  },
  "id" : 534444698710982656,
  "created_at" : "2014-11-17 20:35:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534418625403187200",
  "geo" : { },
  "id_str" : "534418821424365569",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy Who knows!",
  "id" : 534418821424365569,
  "in_reply_to_status_id" : 534418625403187200,
  "created_at" : "2014-11-17 18:52:30 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534418348855918592",
  "geo" : { },
  "id_str" : "534418528594849792",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy i think this is the fundamental problem with the language. Cocoa wasn't designed to be dealt with in Swift.",
  "id" : 534418528594849792,
  "in_reply_to_status_id" : 534418348855918592,
  "created_at" : "2014-11-17 18:51:20 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 0, 12 ],
      "id_str" : "19627341",
      "id" : 19627341
    }, {
      "name" : "Ted Han",
      "screen_name" : "knowtheory",
      "indices" : [ 13, 24 ],
      "id_str" : "14227842",
      "id" : 14227842
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 25, 33 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 34, 45 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 81, 92 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/aQ1bRkPGrY",
      "expanded_url" : "http:\/\/github.com\/rubygems\/gemwhisperer",
      "display_url" : "github.com\/rubygems\/gemwh\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "534399999069536256",
  "geo" : { },
  "id_str" : "534402298169266176",
  "in_reply_to_user_id" : 19627341,
  "text" : "@dwradcliffe @knowtheory @evanphx @samkottler that's http:\/\/t.co\/aQ1bRkPGrY. \/cc @laserlemon",
  "id" : 534402298169266176,
  "in_reply_to_status_id" : 534399999069536256,
  "created_at" : "2014-11-17 17:46:51 +0000",
  "in_reply_to_screen_name" : "dwradcliffe",
  "in_reply_to_user_id_str" : "19627341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Han",
      "screen_name" : "knowtheory",
      "indices" : [ 0, 11 ],
      "id_str" : "14227842",
      "id" : 14227842
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 23, 31 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 32, 43 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 44, 56 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534399644273352704",
  "geo" : { },
  "id_str" : "534399785810534400",
  "in_reply_to_user_id" : 14227842,
  "text" : "@knowtheory what?? \/cc @evanphx @samkottler @dwradcliffe first i've heard of something wrong",
  "id" : 534399785810534400,
  "in_reply_to_status_id" : 534399644273352704,
  "created_at" : "2014-11-17 17:36:52 +0000",
  "in_reply_to_screen_name" : "knowtheory",
  "in_reply_to_user_id_str" : "14227842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alton Brown",
      "screen_name" : "altonbrown",
      "indices" : [ 3, 14 ],
      "id_str" : "293850289",
      "id" : 293850289
    }, {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 58, 73 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/altonbrown\/status\/534378478016417793\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/MhkYly9bKv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2p-X_BIMAEj5Dt.jpg",
      "id_str" : "534378456315080705",
      "id" : 534378456315080705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2p-X_BIMAEj5Dt.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MhkYly9bKv"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/altonbrown\/status\/534378478016417793\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/MhkYly9bKv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2p-X_QIUAAFGWu.jpg",
      "id_str" : "534378456378003456",
      "id" : 534378456378003456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2p-X_QIUAAFGWu.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MhkYly9bKv"
    } ],
    "hashtags" : [ {
      "text" : "ABRoadEatsBuffalo",
      "indices" : [ 74, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534378918376407040",
  "text" : "RT @altonbrown: Brazilian bean pour over from the guys at @PublicEspresso #ABRoadEatsBuffalo http:\/\/t.co\/MhkYly9bKv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PublicEspresso",
        "screen_name" : "PublicEspresso",
        "indices" : [ 42, 57 ],
        "id_str" : "1472209542",
        "id" : 1472209542
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/altonbrown\/status\/534378478016417793\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/MhkYly9bKv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2p-X_BIMAEj5Dt.jpg",
        "id_str" : "534378456315080705",
        "id" : 534378456315080705,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2p-X_BIMAEj5Dt.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/MhkYly9bKv"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/altonbrown\/status\/534378478016417793\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/MhkYly9bKv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2p-X_QIUAAFGWu.jpg",
        "id_str" : "534378456378003456",
        "id" : 534378456378003456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2p-X_QIUAAFGWu.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/MhkYly9bKv"
      } ],
      "hashtags" : [ {
        "text" : "ABRoadEatsBuffalo",
        "indices" : [ 58, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "534378478016417793",
    "text" : "Brazilian bean pour over from the guys at @PublicEspresso #ABRoadEatsBuffalo http:\/\/t.co\/MhkYly9bKv",
    "id" : 534378478016417793,
    "created_at" : "2014-11-17 16:12:12 +0000",
    "user" : {
      "name" : "Alton Brown",
      "screen_name" : "altonbrown",
      "protected" : false,
      "id_str" : "293850289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1341899337\/IMG_1719_normal.jpg",
      "id" : 293850289,
      "verified" : true
    }
  },
  "id" : 534378918376407040,
  "created_at" : "2014-11-17 16:13:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534371676125798400",
  "geo" : { },
  "id_str" : "534373620475514881",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren sup",
  "id" : 534373620475514881,
  "in_reply_to_status_id" : 534371676125798400,
  "created_at" : "2014-11-17 15:52:53 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534367532681945088",
  "text" : "Smash and OmegaRuby\/AlphaSapphire this week. \\o\/",
  "id" : 534367532681945088,
  "created_at" : "2014-11-17 15:28:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    }, {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 16, 28 ],
      "id_str" : "5744132",
      "id" : 5744132
    }, {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 34, 39 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531192573944397824",
  "geo" : { },
  "id_str" : "534210552256417793",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d oh geez. @singheyjude meet @popo, who has a \u201Creal\u201C McDavid jersey",
  "id" : 534210552256417793,
  "in_reply_to_status_id" : 531192573944397824,
  "created_at" : "2014-11-17 05:04:55 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 26, 41 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    }, {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "indices" : [ 46, 56 ],
      "id_str" : "816041347",
      "id" : 816041347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534204982627540993",
  "text" : "Good luck and Godspeed to @PublicEspresso and @BreadHive for Mr Brown. Not sure how I\u2019d be able to sleep.",
  "id" : 534204982627540993,
  "created_at" : "2014-11-17 04:42:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    }, {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 47, 59 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534172104200323072",
  "geo" : { },
  "id_str" : "534204745762627585",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d I think we played the PC version right? @john_floren might remember",
  "id" : 534204745762627585,
  "in_reply_to_status_id" : 534172104200323072,
  "created_at" : "2014-11-17 04:41:51 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534168830713794560",
  "text" : "First Halo 1 multiplayer game in at least 7? 8? years. (\u00B4\uFF65\u0414\uFF65)\u300D",
  "id" : 534168830713794560,
  "created_at" : "2014-11-17 02:19:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534125538395164673",
  "text" : "I know it\u2019s a kids show but Ash is 10 and they just let him roam around the countryside battling monsters?! What awesome parents.",
  "id" : 534125538395164673,
  "created_at" : "2014-11-16 23:27:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534035473069387776",
  "text" : "My heart goes out to the Node team paving the way for CoC\u2019s and dealing with trolls. Someday we\u2019ll wonder why every lang didn\u2019t have one.",
  "id" : 534035473069387776,
  "created_at" : "2014-11-16 17:29:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susie Cagle",
      "screen_name" : "susie_c",
      "indices" : [ 3, 11 ],
      "id_str" : "14145296",
      "id" : 14145296
    }, {
      "name" : "Al Jazeera America ",
      "screen_name" : "ajam",
      "indices" : [ 20, 25 ],
      "id_str" : "1178700896",
      "id" : 1178700896
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/susie_c\/status\/534007424940658689\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/rDeuKboX9n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2ks6-PCcAERjl4.jpg",
      "id_str" : "534007422470221825",
      "id" : 534007422470221825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2ks6-PCcAERjl4.jpg",
      "sizes" : [ {
        "h" : 330,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/rDeuKboX9n"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Jg4Ir0QBmE",
      "expanded_url" : "http:\/\/america.aljazeera.com\/opinions\/2014\/11\/san-francisco-techindustryhousingtwitterairbnbuber.html",
      "display_url" : "america.aljazeera.com\/opinions\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534028928923340800",
  "text" : "RT @susie_c: Me for @ajam: Tech couldn't buy SF if the city weren't more than happy to sell http:\/\/t.co\/Jg4Ir0QBmE http:\/\/t.co\/rDeuKboX9n",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Al Jazeera America ",
        "screen_name" : "ajam",
        "indices" : [ 7, 12 ],
        "id_str" : "1178700896",
        "id" : 1178700896
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/susie_c\/status\/534007424940658689\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/rDeuKboX9n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2ks6-PCcAERjl4.jpg",
        "id_str" : "534007422470221825",
        "id" : 534007422470221825,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2ks6-PCcAERjl4.jpg",
        "sizes" : [ {
          "h" : 330,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/rDeuKboX9n"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/Jg4Ir0QBmE",
        "expanded_url" : "http:\/\/america.aljazeera.com\/opinions\/2014\/11\/san-francisco-techindustryhousingtwitterairbnbuber.html",
        "display_url" : "america.aljazeera.com\/opinions\/2014\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "534007424940658689",
    "text" : "Me for @ajam: Tech couldn't buy SF if the city weren't more than happy to sell http:\/\/t.co\/Jg4Ir0QBmE http:\/\/t.co\/rDeuKboX9n",
    "id" : 534007424940658689,
    "created_at" : "2014-11-16 15:37:46 +0000",
    "user" : {
      "name" : "Susie Cagle",
      "screen_name" : "susie_c",
      "protected" : false,
      "id_str" : "14145296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565616681444077568\/PyrsiB___normal.png",
      "id" : 14145296,
      "verified" : false
    }
  },
  "id" : 534028928923340800,
  "created_at" : "2014-11-16 17:03:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alton Brown",
      "screen_name" : "altonbrown",
      "indices" : [ 0, 11 ],
      "id_str" : "293850289",
      "id" : 293850289
    }, {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 12, 27 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    }, {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "indices" : [ 32, 42 ],
      "id_str" : "816041347",
      "id" : 816041347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534020406660038656",
  "geo" : { },
  "id_str" : "534023150866923520",
  "in_reply_to_user_id" : 293850289,
  "text" : "@altonbrown @PublicEspresso hey @BreadHive are you open tomorrow for breakfast?!!?",
  "id" : 534023150866923520,
  "in_reply_to_status_id" : 534020406660038656,
  "created_at" : "2014-11-16 16:40:15 +0000",
  "in_reply_to_screen_name" : "altonbrown",
  "in_reply_to_user_id_str" : "293850289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alton Brown",
      "screen_name" : "altonbrown",
      "indices" : [ 3, 14 ],
      "id_str" : "293850289",
      "id" : 293850289
    }, {
      "name" : "Paula's Donuts",
      "screen_name" : "PaulasDonuts",
      "indices" : [ 30, 43 ],
      "id_str" : "739385342",
      "id" : 739385342
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/altonbrown\/status\/534022379861995520\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/BsP0z6xe4q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2k6hBEIMAAHnfc.jpg",
      "id_str" : "534022369715957760",
      "id" : 534022369715957760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2k6hBEIMAAHnfc.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/BsP0z6xe4q"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/altonbrown\/status\/534022379861995520\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/BsP0z6xe4q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2k6hBRIAAAnE10.jpg",
      "id_str" : "534022369770471424",
      "id" : 534022369770471424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2k6hBRIAAAnE10.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com\/BsP0z6xe4q"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/altonbrown\/status\/534022379861995520\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/BsP0z6xe4q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2k6hBSIEAA4e3F.jpg",
      "id_str" : "534022369774669824",
      "id" : 534022369774669824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2k6hBSIEAA4e3F.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com\/BsP0z6xe4q"
    } ],
    "hashtags" : [ {
      "text" : "ABRoadEatsBuffalo",
      "indices" : [ 95, 113 ]
    }, {
      "text" : "AltonBrownLive",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534022939918598144",
  "text" : "RT @altonbrown: Oh heck yeah, @PaulasDonuts. That's a solid old-fashioned sour cream doughnut. #ABRoadEatsBuffalo #AltonBrownLive http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paula's Donuts",
        "screen_name" : "PaulasDonuts",
        "indices" : [ 14, 27 ],
        "id_str" : "739385342",
        "id" : 739385342
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/altonbrown\/status\/534022379861995520\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/BsP0z6xe4q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2k6hBEIMAAHnfc.jpg",
        "id_str" : "534022369715957760",
        "id" : 534022369715957760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2k6hBEIMAAHnfc.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/BsP0z6xe4q"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/altonbrown\/status\/534022379861995520\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/BsP0z6xe4q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2k6hBRIAAAnE10.jpg",
        "id_str" : "534022369770471424",
        "id" : 534022369770471424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2k6hBRIAAAnE10.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 852
        } ],
        "display_url" : "pic.twitter.com\/BsP0z6xe4q"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/altonbrown\/status\/534022379861995520\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/BsP0z6xe4q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2k6hBSIEAA4e3F.jpg",
        "id_str" : "534022369774669824",
        "id" : 534022369774669824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2k6hBSIEAA4e3F.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 852
        } ],
        "display_url" : "pic.twitter.com\/BsP0z6xe4q"
      } ],
      "hashtags" : [ {
        "text" : "ABRoadEatsBuffalo",
        "indices" : [ 79, 97 ]
      }, {
        "text" : "AltonBrownLive",
        "indices" : [ 98, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "534022379861995520",
    "text" : "Oh heck yeah, @PaulasDonuts. That's a solid old-fashioned sour cream doughnut. #ABRoadEatsBuffalo #AltonBrownLive http:\/\/t.co\/BsP0z6xe4q",
    "id" : 534022379861995520,
    "created_at" : "2014-11-16 16:37:11 +0000",
    "user" : {
      "name" : "Alton Brown",
      "screen_name" : "altonbrown",
      "protected" : false,
      "id_str" : "293850289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1341899337\/IMG_1719_normal.jpg",
      "id" : 293850289,
      "verified" : true
    }
  },
  "id" : 534022939918598144,
  "created_at" : "2014-11-16 16:39:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twistopher",
      "screen_name" : "GhostTwist",
      "indices" : [ 0, 11 ],
      "id_str" : "272688913",
      "id" : 272688913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533975521487765504",
  "geo" : { },
  "id_str" : "533978980596998145",
  "in_reply_to_user_id" : 272688913,
  "text" : "@GhostTwist yep! I wrote a setlist parser\/tracker after scraping all of their shows since 2009. Finally flipped it over a few weeks ago :)",
  "id" : 533978980596998145,
  "in_reply_to_status_id" : 533975521487765504,
  "created_at" : "2014-11-16 13:44:44 +0000",
  "in_reply_to_screen_name" : "GhostTwist",
  "in_reply_to_user_id_str" : "272688913",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twistopher",
      "screen_name" : "GhostTwist",
      "indices" : [ 0, 11 ],
      "id_str" : "272688913",
      "id" : 272688913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533964605119533057",
  "geo" : { },
  "id_str" : "533973562348937216",
  "in_reply_to_user_id" : 272688913,
  "text" : "@GhostTwist sweet. We\u2019ll get the setlist filled out on the site soon.",
  "id" : 533973562348937216,
  "in_reply_to_status_id" : 533964605119533057,
  "created_at" : "2014-11-16 13:23:12 +0000",
  "in_reply_to_screen_name" : "GhostTwist",
  "in_reply_to_user_id_str" : "272688913",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twistopher",
      "screen_name" : "GhostTwist",
      "indices" : [ 0, 11 ],
      "id_str" : "272688913",
      "id" : 272688913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533849499987640320",
  "geo" : { },
  "id_str" : "533960931923857408",
  "in_reply_to_user_id" : 272688913,
  "text" : "@GhostTwist awesome. How was it?",
  "id" : 533960931923857408,
  "in_reply_to_status_id" : 533849499987640320,
  "created_at" : "2014-11-16 12:33:01 +0000",
  "in_reply_to_screen_name" : "GhostTwist",
  "in_reply_to_user_id_str" : "272688913",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Baugues",
      "screen_name" : "greggyb",
      "indices" : [ 0, 8 ],
      "id_str" : "15048829",
      "id" : 15048829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533938248880750593",
  "geo" : { },
  "id_str" : "533960144489435136",
  "in_reply_to_user_id" : 15048829,
  "text" : "@greggyb congrats dude! How goes it?",
  "id" : 533960144489435136,
  "in_reply_to_status_id" : 533938248880750593,
  "created_at" : "2014-11-16 12:29:53 +0000",
  "in_reply_to_screen_name" : "greggyb",
  "in_reply_to_user_id_str" : "15048829",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 0, 7 ],
      "id_str" : "9038902",
      "id" : 9038902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533688289681612801",
  "geo" : { },
  "id_str" : "533864479671320576",
  "in_reply_to_user_id" : 9038902,
  "text" : "@searls Siri pronounces \u201CBasecamp\u201D as \u201CBasacamp\u201D and it drives me nuts",
  "id" : 533864479671320576,
  "in_reply_to_status_id" : 533688289681612801,
  "created_at" : "2014-11-16 06:09:45 +0000",
  "in_reply_to_screen_name" : "searls",
  "in_reply_to_user_id_str" : "9038902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533851123510018048",
  "text" : "Just saying if you keep friends close, have their fucking phone number.",
  "id" : 533851123510018048,
  "created_at" : "2014-11-16 05:16:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533851005771722756",
  "text" : "One of my closest friends\u2019 father just passed away and I don\u2019t even have his phone number. Lost in an abyss of contact merges and phones. \uD83D\uDE2D",
  "id" : 533851005771722756,
  "created_at" : "2014-11-16 05:16:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/O6GZ6xMTNV",
      "expanded_url" : "https:\/\/bentomiso.com\/",
      "display_url" : "bentomiso.com"
    } ]
  },
  "geo" : { },
  "id_str" : "533792241404219392",
  "text" : "How awesome is this? A coworking space in Toronto offers health insurance to its members: https:\/\/t.co\/O6GZ6xMTNV",
  "id" : 533792241404219392,
  "created_at" : "2014-11-16 01:22:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ghouls, buddy!",
      "screen_name" : "AaronM",
      "indices" : [ 0, 7 ],
      "id_str" : "9194742",
      "id" : 9194742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533791072770469890",
  "geo" : { },
  "id_str" : "533791207596363776",
  "in_reply_to_user_id" : 9194742,
  "text" : "@AaronM that\u2019s a lot of semi toasted bagels",
  "id" : 533791207596363776,
  "in_reply_to_status_id" : 533791072770469890,
  "created_at" : "2014-11-16 01:18:35 +0000",
  "in_reply_to_screen_name" : "AaronM",
  "in_reply_to_user_id_str" : "9194742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ghouls, buddy!",
      "screen_name" : "AaronM",
      "indices" : [ 0, 7 ],
      "id_str" : "9194742",
      "id" : 9194742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533788985215037440",
  "geo" : { },
  "id_str" : "533790962359615488",
  "in_reply_to_user_id" : 9194742,
  "text" : "@AaronM gotta have those Timbits",
  "id" : 533790962359615488,
  "in_reply_to_status_id" : 533788985215037440,
  "created_at" : "2014-11-16 01:17:37 +0000",
  "in_reply_to_screen_name" : "AaronM",
  "in_reply_to_user_id_str" : "9194742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "triflin brand indeed",
      "screen_name" : "vogon",
      "indices" : [ 0, 6 ],
      "id_str" : "6326912",
      "id" : 6326912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533757205011369984",
  "geo" : { },
  "id_str" : "533760433874681856",
  "in_reply_to_user_id" : 6326912,
  "text" : "@vogon I am so used to vanilla prices. that feels like more than I\u2019d ever have",
  "id" : 533760433874681856,
  "in_reply_to_status_id" : 533757205011369984,
  "created_at" : "2014-11-15 23:16:18 +0000",
  "in_reply_to_screen_name" : "vogon",
  "in_reply_to_user_id_str" : "6326912",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THAT isaac",
      "screen_name" : "izs",
      "indices" : [ 3, 7 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533703370242920448",
  "text" : "RT @izs: THE POINT of a CoC\u2014whether a conf, an OSS project, or a traffic law\u2014is to make some behaviors \"unsafe\", for the safety of everyone\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "533675031788679168",
    "text" : "THE POINT of a CoC\u2014whether a conf, an OSS project, or a traffic law\u2014is to make some behaviors \"unsafe\", for the safety of everyone else.",
    "id" : 533675031788679168,
    "created_at" : "2014-11-15 17:36:57 +0000",
    "user" : {
      "name" : "THAT isaac",
      "screen_name" : "izs",
      "protected" : false,
      "id_str" : "8038312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563826348121001984\/1ZoTytsX_normal.jpeg",
      "id" : 8038312,
      "verified" : false
    }
  },
  "id" : 533703370242920448,
  "created_at" : "2014-11-15 19:29:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533681115626999810",
  "geo" : { },
  "id_str" : "533684925442977792",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer I\u2019ve listened to that Free maybe 20 times. Unbelievable.",
  "id" : 533684925442977792,
  "in_reply_to_status_id" : 533681115626999810,
  "created_at" : "2014-11-15 18:16:16 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zac Gorman",
      "screen_name" : "zacgormania",
      "indices" : [ 3, 15 ],
      "id_str" : "237985689",
      "id" : 237985689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533500251764584448",
  "text" : "RT @zacgormania: How old were you when your parents gave you \"the talk\" about monsters? That they are absolutely real and that you were bor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "533497937121529856",
    "text" : "How old were you when your parents gave you \"the talk\" about monsters? That they are absolutely real and that you were born to fight them",
    "id" : 533497937121529856,
    "created_at" : "2014-11-15 05:53:14 +0000",
    "user" : {
      "name" : "Zac Gorman",
      "screen_name" : "zacgormania",
      "protected" : false,
      "id_str" : "237985689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530760979781406720\/qyDRpLnB_normal.jpeg",
      "id" : 237985689,
      "verified" : false
    }
  },
  "id" : 533500251764584448,
  "created_at" : "2014-11-15 06:02:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elisa D'Alessandro",
      "screen_name" : "eeleesuh",
      "indices" : [ 0, 9 ],
      "id_str" : "43253261",
      "id" : 43253261
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 34, 44 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/533429316361916417\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/UPhyTCo3Zy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2cfIpOCEAABpeN.jpg",
      "id_str" : "533429314230816768",
      "id" : 533429314230816768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2cfIpOCEAABpeN.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UPhyTCo3Zy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533424446582063104",
  "geo" : { },
  "id_str" : "533429316361916417",
  "in_reply_to_user_id" : 43253261,
  "text" : "@eeleesuh well in any case I told @aquaranto you are Thorgi\u2019s keeper and now suddenly we need something for our husky http:\/\/t.co\/UPhyTCo3Zy",
  "id" : 533429316361916417,
  "in_reply_to_status_id" : 533424446582063104,
  "created_at" : "2014-11-15 01:20:34 +0000",
  "in_reply_to_screen_name" : "eeleesuh",
  "in_reply_to_user_id_str" : "43253261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elisa D'Alessandro",
      "screen_name" : "eeleesuh",
      "indices" : [ 0, 9 ],
      "id_str" : "43253261",
      "id" : 43253261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533424446582063104",
  "geo" : { },
  "id_str" : "533427731883900928",
  "in_reply_to_user_id" : 43253261,
  "text" : "@eeleesuh I don\u2019t remember! I think we did some 40 person BWL runs? I quit just after BC. Sharded everything and gave 500g to someone random",
  "id" : 533427731883900928,
  "in_reply_to_status_id" : 533424446582063104,
  "created_at" : "2014-11-15 01:14:16 +0000",
  "in_reply_to_screen_name" : "eeleesuh",
  "in_reply_to_user_id_str" : "43253261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elisa D'Alessandro",
      "screen_name" : "eeleesuh",
      "indices" : [ 0, 9 ],
      "id_str" : "43253261",
      "id" : 43253261
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 44, 54 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533423020749369345",
  "geo" : { },
  "id_str" : "533423617183612928",
  "in_reply_to_user_id" : 43253261,
  "text" : "@eeleesuh pretty sure. Had a Druid, Noshik. @aquaranto had a Mage, Irica. My brother had Turbage (Hunter)",
  "id" : 533423617183612928,
  "in_reply_to_status_id" : 533423020749369345,
  "created_at" : "2014-11-15 00:57:55 +0000",
  "in_reply_to_screen_name" : "eeleesuh",
  "in_reply_to_user_id_str" : "43253261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elisa D'Alessandro",
      "screen_name" : "eeleesuh",
      "indices" : [ 0, 9 ],
      "id_str" : "43253261",
      "id" : 43253261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533420946779295744",
  "geo" : { },
  "id_str" : "533423262328692736",
  "in_reply_to_user_id" : 43253261,
  "text" : "@eeleesuh after 3 months of \/played in college I just can\u2019t do MMOs anymore (and to most people that\u2019s nothing)",
  "id" : 533423262328692736,
  "in_reply_to_status_id" : 533420946779295744,
  "created_at" : "2014-11-15 00:56:30 +0000",
  "in_reply_to_screen_name" : "eeleesuh",
  "in_reply_to_user_id_str" : "43253261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elisa D'Alessandro",
      "screen_name" : "eeleesuh",
      "indices" : [ 0, 9 ],
      "id_str" : "43253261",
      "id" : 43253261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533419563749507072",
  "geo" : { },
  "id_str" : "533420808820248576",
  "in_reply_to_user_id" : 43253261,
  "text" : "@eeleesuh Skullcrusher is still around!!?",
  "id" : 533420808820248576,
  "in_reply_to_status_id" : 533419563749507072,
  "created_at" : "2014-11-15 00:46:45 +0000",
  "in_reply_to_screen_name" : "eeleesuh",
  "in_reply_to_user_id_str" : "43253261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 0, 6 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533416546006077440",
  "geo" : { },
  "id_str" : "533417039302754304",
  "in_reply_to_user_id" : 205281746,
  "text" : "@ahuj9 dude get the hidden package",
  "id" : 533417039302754304,
  "in_reply_to_status_id" : 533416546006077440,
  "created_at" : "2014-11-15 00:31:47 +0000",
  "in_reply_to_screen_name" : "ahuj9",
  "in_reply_to_user_id_str" : "205281746",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HARBORCENTER",
      "screen_name" : "HARBORCTR",
      "indices" : [ 59, 69 ],
      "id_str" : "1255847137",
      "id" : 1255847137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/PWw9AA09ah",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/fxZrxCWFOds",
      "display_url" : "swarmapp.com\/c\/fxZrxCWFOds"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8766559893, -78.8767504692 ]
  },
  "id_str" : "533410628569165824",
  "text" : "RIT at a even newer arena than their own (@ HARBORcenter - @harborctr in Buffalo, NY) https:\/\/t.co\/PWw9AA09ah",
  "id" : 533410628569165824,
  "created_at" : "2014-11-15 00:06:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 0, 7 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533403712912621569",
  "geo" : { },
  "id_str" : "533408743078502400",
  "in_reply_to_user_id" : 38003,
  "text" : "@gedeon there\u2019s a new one?!",
  "id" : 533408743078502400,
  "in_reply_to_status_id" : 533403712912621569,
  "created_at" : "2014-11-14 23:58:49 +0000",
  "in_reply_to_screen_name" : "gedeon",
  "in_reply_to_user_id_str" : "38003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533395701557104641",
  "text" : "RT @rubygems_status: Sorry about that everyone. We were doing some redis maintenance that took longer than expected. Everything should be b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "533395210630225921",
    "text" : "Sorry about that everyone. We were doing some redis maintenance that took longer than expected. Everything should be back to normal now.",
    "id" : 533395210630225921,
    "created_at" : "2014-11-14 23:05:02 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 533395701557104641,
  "created_at" : "2014-11-14 23:06:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533394575206137857",
  "geo" : { },
  "id_str" : "533394814835109889",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy it is over stimulating",
  "id" : 533394814835109889,
  "in_reply_to_status_id" : 533394575206137857,
  "created_at" : "2014-11-14 23:03:28 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(716) Food and Sport",
      "screen_name" : "716FoodandSport",
      "indices" : [ 30, 46 ],
      "id_str" : "2414651984",
      "id" : 2414651984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/YwJqDpnCQf",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/9iclLwzt3YM",
      "display_url" : "swarmapp.com\/c\/9iclLwzt3YM"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.877092206, -78.8761948594 ]
  },
  "id_str" : "533389234720501761",
  "text" : "I'm at (716) Food and Sport - @716foodandsport in Buffalo, NY https:\/\/t.co\/YwJqDpnCQf",
  "id" : 533389234720501761,
  "created_at" : "2014-11-14 22:41:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533376082523594752",
  "text" : "I just blue-screened my iPhone 6+ as I pushed a build from Xcode to it. It flashed bright blue then restarted. The BSOD lives.",
  "id" : 533376082523594752,
  "created_at" : "2014-11-14 21:49:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533361947148689408",
  "text" : "\"If I had been dependent on Soylent as my primary food source, I would have died waiting for it\" - Surprise! You're dead inside already",
  "id" : 533361947148689408,
  "created_at" : "2014-11-14 20:52:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Hamou",
      "screen_name" : "alikhamou",
      "indices" : [ 3, 13 ],
      "id_str" : "552936888",
      "id" : 552936888
    }, {
      "name" : "Ed Finkler",
      "screen_name" : "funkatron",
      "indices" : [ 15, 25 ],
      "id_str" : "65583",
      "id" : 65583
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/alikhamou\/status\/530820172580270080\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/JqayW70j4h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B13aIi_CMAAKf7s.jpg",
      "id_str" : "530820171464585216",
      "id" : 530820171464585216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B13aIi_CMAAKf7s.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/JqayW70j4h"
    } ],
    "hashtags" : [ {
      "text" : "tnphp",
      "indices" : [ 113, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533360109326315522",
  "text" : "RT @alikhamou: @funkatron gave an amazing talk about being a great developer. Applicable to life - not just dev. #tnphp http:\/\/t.co\/JqayW70\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/backtoblaq.com\" rel=\"nofollow\"\u003EBlaq for BlackBerry\u00AE 10\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ed Finkler",
        "screen_name" : "funkatron",
        "indices" : [ 0, 10 ],
        "id_str" : "65583",
        "id" : 65583
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/alikhamou\/status\/530820172580270080\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/JqayW70j4h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B13aIi_CMAAKf7s.jpg",
        "id_str" : "530820171464585216",
        "id" : 530820171464585216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B13aIi_CMAAKf7s.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/JqayW70j4h"
      } ],
      "hashtags" : [ {
        "text" : "tnphp",
        "indices" : [ 98, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "530820172580270080",
    "in_reply_to_user_id" : 65583,
    "text" : "@funkatron gave an amazing talk about being a great developer. Applicable to life - not just dev. #tnphp http:\/\/t.co\/JqayW70j4h",
    "id" : 530820172580270080,
    "created_at" : "2014-11-07 20:32:45 +0000",
    "in_reply_to_screen_name" : "funkatron",
    "in_reply_to_user_id_str" : "65583",
    "user" : {
      "name" : "Ali Hamou",
      "screen_name" : "alikhamou",
      "protected" : false,
      "id_str" : "552936888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2146622514\/102_0420_normal.JPG",
      "id" : 552936888,
      "verified" : false
    }
  },
  "id" : 533360109326315522,
  "created_at" : "2014-11-14 20:45:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Mordaunt",
      "screen_name" : "juliamordaunt",
      "indices" : [ 0, 14 ],
      "id_str" : "15641417",
      "id" : 15641417
    }, {
      "name" : "Oxford Pennant",
      "screen_name" : "OxfordPennant",
      "indices" : [ 15, 29 ],
      "id_str" : "2213449884",
      "id" : 2213449884
    }, {
      "name" : "David Horesh",
      "screen_name" : "dhoresh",
      "indices" : [ 30, 38 ],
      "id_str" : "93549918",
      "id" : 93549918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533351686103130112",
  "geo" : { },
  "id_str" : "533351939723894784",
  "in_reply_to_user_id" : 15641417,
  "text" : "@juliamordaunt @OxfordPennant @dhoresh Sold, can I pick up in person? Today? Holy crap.",
  "id" : 533351939723894784,
  "in_reply_to_status_id" : 533351686103130112,
  "created_at" : "2014-11-14 20:13:06 +0000",
  "in_reply_to_screen_name" : "juliamordaunt",
  "in_reply_to_user_id_str" : "15641417",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Mordaunt",
      "screen_name" : "juliamordaunt",
      "indices" : [ 3, 17 ],
      "id_str" : "15641417",
      "id" : 15641417
    }, {
      "name" : "Phish Dry Goods",
      "screen_name" : "phishdrygoods",
      "indices" : [ 26, 40 ],
      "id_str" : "69779454",
      "id" : 69779454
    }, {
      "name" : "Oxford Pennant",
      "screen_name" : "OxfordPennant",
      "indices" : [ 65, 79 ],
      "id_str" : "2213449884",
      "id" : 2213449884
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/phishdrygoods\/status\/533350531549646850\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/PJ8jKg6Kml",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2bXe1VCYAA4JUI.jpg",
      "id_str" : "533350530601345024",
      "id" : 533350530601345024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2bXe1VCYAA4JUI.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/PJ8jKg6Kml"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/phishdrygoods\/status\/533350531549646850\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/PJ8jKg6Kml",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2bXe1ECMAAHzq4.jpg",
      "id_str" : "533350530530029568",
      "id" : 533350530530029568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2bXe1ECMAAHzq4.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/PJ8jKg6Kml"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533351799063707648",
  "text" : "RT @juliamordaunt: Sexy! \u201C@phishdrygoods: New collaboration with @OxfordPennant: USA Made \"Waiting All Night\" and \"555\" pennants ! http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Phish Dry Goods",
        "screen_name" : "phishdrygoods",
        "indices" : [ 7, 21 ],
        "id_str" : "69779454",
        "id" : 69779454
      }, {
        "name" : "Oxford Pennant",
        "screen_name" : "OxfordPennant",
        "indices" : [ 46, 60 ],
        "id_str" : "2213449884",
        "id" : 2213449884
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/phishdrygoods\/status\/533350531549646850\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/PJ8jKg6Kml",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2bXe1VCYAA4JUI.jpg",
        "id_str" : "533350530601345024",
        "id" : 533350530601345024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2bXe1VCYAA4JUI.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/PJ8jKg6Kml"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/phishdrygoods\/status\/533350531549646850\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/PJ8jKg6Kml",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2bXe1ECMAAHzq4.jpg",
        "id_str" : "533350530530029568",
        "id" : 533350530530029568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2bXe1ECMAAHzq4.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/PJ8jKg6Kml"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "533350531549646850",
    "geo" : { },
    "id_str" : "533351686103130112",
    "in_reply_to_user_id" : 69779454,
    "text" : "Sexy! \u201C@phishdrygoods: New collaboration with @OxfordPennant: USA Made \"Waiting All Night\" and \"555\" pennants ! http:\/\/t.co\/PJ8jKg6Kml\u201D",
    "id" : 533351686103130112,
    "in_reply_to_status_id" : 533350531549646850,
    "created_at" : "2014-11-14 20:12:05 +0000",
    "in_reply_to_screen_name" : "phishdrygoods",
    "in_reply_to_user_id_str" : "69779454",
    "user" : {
      "name" : "Julia Mordaunt",
      "screen_name" : "juliamordaunt",
      "protected" : false,
      "id_str" : "15641417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/424752655844782080\/sVTDb-M__normal.jpeg",
      "id" : 15641417,
      "verified" : false
    }
  },
  "id" : 533351799063707648,
  "created_at" : "2014-11-14 20:12:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 0, 11 ],
      "id_str" : "67117740",
      "id" : 67117740
    }, {
      "name" : "YEMblog",
      "screen_name" : "YEMblog",
      "indices" : [ 12, 20 ],
      "id_str" : "16518086",
      "id" : 16518086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533343978750754816",
  "geo" : { },
  "id_str" : "533347327893725185",
  "in_reply_to_user_id" : 67117740,
  "text" : "@Dianna_2Ns @YEMblog Cities is absolutely amazing",
  "id" : 533347327893725185,
  "in_reply_to_status_id" : 533343978750754816,
  "created_at" : "2014-11-14 19:54:46 +0000",
  "in_reply_to_screen_name" : "Dianna_2Ns",
  "in_reply_to_user_id_str" : "67117740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/AZt17HPiyZ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=B-_PC6TlIhs",
      "display_url" : "youtube.com\/watch?v=B-_PC6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533346586428841985",
  "text" : "The Talking Heads are even better live https:\/\/t.co\/AZt17HPiyZ",
  "id" : 533346586428841985,
  "created_at" : "2014-11-14 19:51:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Daniels",
      "screen_name" : "jamesuriah",
      "indices" : [ 0, 11 ],
      "id_str" : "21390942",
      "id" : 21390942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533328859908014081",
  "geo" : { },
  "id_str" : "533329485236428801",
  "in_reply_to_user_id" : 21390942,
  "text" : "@jamesuriah it's iOS, but wtf took the screenshot?",
  "id" : 533329485236428801,
  "in_reply_to_status_id" : 533328859908014081,
  "created_at" : "2014-11-14 18:43:52 +0000",
  "in_reply_to_screen_name" : "jamesuriah",
  "in_reply_to_user_id_str" : "21390942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533298547777499136",
  "geo" : { },
  "id_str" : "533299523431723008",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda thanks! hows the new addic^H^H^H^H^H expac?",
  "id" : 533299523431723008,
  "in_reply_to_status_id" : 533298547777499136,
  "created_at" : "2014-11-14 16:44:49 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 16, 28 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Pzjb82pgcA",
      "expanded_url" : "http:\/\/www.jambands.com\/reviews\/cds\/2014\/11\/10\/aqueous-cycles",
      "display_url" : "jambands.com\/reviews\/cds\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533274704702746624",
  "text" : "Great review of @AqueousBand's new album: http:\/\/t.co\/Pzjb82pgcA (Have you listened to it yet?)",
  "id" : 533274704702746624,
  "created_at" : "2014-11-14 15:06:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/LyvBe5HCj4",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Spacer_GIF",
      "display_url" : "en.wikipedia.org\/wiki\/Spacer_GIF"
    }, {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/AR8FP9QO3N",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Spacer_.GIF",
      "display_url" : "en.wikipedia.org\/wiki\/Spacer_.G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533273335828709377",
  "text" : "Just in case, there's 2 wikipedia articles on spacer gifs. http:\/\/t.co\/LyvBe5HCj4 http:\/\/t.co\/AR8FP9QO3N",
  "id" : 533273335828709377,
  "created_at" : "2014-11-14 15:00:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "christopher hyzy",
      "screen_name" : "christopherhyzy",
      "indices" : [ 3, 19 ],
      "id_str" : "41014237",
      "id" : 41014237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/3LsBSHTVtu",
      "expanded_url" : "http:\/\/instagram.com\/p\/vYaC3Ah-cA\/",
      "display_url" : "instagram.com\/p\/vYaC3Ah-cA\/"
    } ]
  },
  "geo" : { },
  "id_str" : "533261762716372993",
  "text" : "RT @christopherhyzy: Someone left a bag of shit on my doorstep and forgot to set it on fire http:\/\/t.co\/3LsBSHTVtu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/3LsBSHTVtu",
        "expanded_url" : "http:\/\/instagram.com\/p\/vYaC3Ah-cA\/",
        "display_url" : "instagram.com\/p\/vYaC3Ah-cA\/"
      } ]
    },
    "geo" : { },
    "id_str" : "533245944104370176",
    "text" : "Someone left a bag of shit on my doorstep and forgot to set it on fire http:\/\/t.co\/3LsBSHTVtu",
    "id" : 533245944104370176,
    "created_at" : "2014-11-14 13:11:54 +0000",
    "user" : {
      "name" : "christopher hyzy",
      "screen_name" : "christopherhyzy",
      "protected" : false,
      "id_str" : "41014237",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1689682424\/tumblr_lw29dbGeYz1qfkx9zo1_500_normal.png",
      "id" : 41014237,
      "verified" : false
    }
  },
  "id" : 533261762716372993,
  "created_at" : "2014-11-14 14:14:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Saunders",
      "screen_name" : "chris_saunders",
      "indices" : [ 0, 15 ],
      "id_str" : "19147270",
      "id" : 19147270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533238779629555712",
  "geo" : { },
  "id_str" : "533244222367735808",
  "in_reply_to_user_id" : 19147270,
  "text" : "@chris_saunders not the first time I\u2019ve gotten this",
  "id" : 533244222367735808,
  "in_reply_to_status_id" : 533238779629555712,
  "created_at" : "2014-11-14 13:05:04 +0000",
  "in_reply_to_screen_name" : "chris_saunders",
  "in_reply_to_user_id_str" : "19147270",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533135770291150849",
  "geo" : { },
  "id_str" : "533136707621617664",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky thanks!",
  "id" : 533136707621617664,
  "in_reply_to_status_id" : 533135770291150849,
  "created_at" : "2014-11-14 05:57:50 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533133358772281344",
  "geo" : { },
  "id_str" : "533134211138351104",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler I feel personally responsible still for this kind of bullshit. It\u2019s awful.",
  "id" : 533134211138351104,
  "in_reply_to_status_id" : 533133358772281344,
  "created_at" : "2014-11-14 05:47:55 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533133358772281344",
  "geo" : { },
  "id_str" : "533133861245313024",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler I think we should, but we have historically lacked the time\/focus to even do basic things. That gem (and many others) need to go",
  "id" : 533133861245313024,
  "in_reply_to_status_id" : 533133358772281344,
  "created_at" : "2014-11-14 05:46:32 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533130229837877248",
  "geo" : { },
  "id_str" : "533130789026689025",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale I can\u2019t wait for this next Facebook comment to really change the President\u2019s mind on this critical issue",
  "id" : 533130789026689025,
  "in_reply_to_status_id" : 533130229837877248,
  "created_at" : "2014-11-14 05:34:19 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rubits (sponge)",
      "screen_name" : "mikerubits",
      "indices" : [ 0, 11 ],
      "id_str" : "18455656",
      "id" : 18455656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533118855518765056",
  "geo" : { },
  "id_str" : "533118984351006720",
  "in_reply_to_user_id" : 18455656,
  "text" : "@mikerubits well any ssh\/telnet client will do\u2026but none I\u2019ve found",
  "id" : 533118984351006720,
  "in_reply_to_status_id" : 533118855518765056,
  "created_at" : "2014-11-14 04:47:25 +0000",
  "in_reply_to_screen_name" : "mikerubits",
  "in_reply_to_user_id_str" : "18455656",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 0, 12 ],
      "id_str" : "156708162",
      "id" : 156708162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533117343468359680",
  "geo" : { },
  "id_str" : "533117710062731264",
  "in_reply_to_user_id" : 156708162,
  "text" : "@barelyknown I am very glad there is no basketball or college football around here to care about",
  "id" : 533117710062731264,
  "in_reply_to_status_id" : 533117343468359680,
  "created_at" : "2014-11-14 04:42:21 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533117358588428288",
  "text" : "Random tired thoughts: why can\u2019t I play nethack or dwarf fortress on my phone (efficiently)",
  "id" : 533117358588428288,
  "created_at" : "2014-11-14 04:40:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533117138085482496",
  "text" : "Random tired thoughts: when will sportsball see a sportsballgate",
  "id" : 533117138085482496,
  "created_at" : "2014-11-14 04:40:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533116545384185856",
  "geo" : { },
  "id_str" : "533116789136166912",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale hey thanks man",
  "id" : 533116789136166912,
  "in_reply_to_status_id" : 533116545384185856,
  "created_at" : "2014-11-14 04:38:42 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 0, 11 ],
      "id_str" : "67117740",
      "id" : 67117740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533116565114617856",
  "geo" : { },
  "id_str" : "533116729929375744",
  "in_reply_to_user_id" : 67117740,
  "text" : "@Dianna_2Ns didn\u2019t notice that !! \uD83D\uDC7B",
  "id" : 533116729929375744,
  "in_reply_to_status_id" : 533116565114617856,
  "created_at" : "2014-11-14 04:38:27 +0000",
  "in_reply_to_screen_name" : "Dianna_2Ns",
  "in_reply_to_user_id_str" : "67117740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533116285672894464",
  "text" : "Also pure irony re sportsball as we\u2019re headed to the Canisius\/RIT game tomorrow.",
  "id" : 533116285672894464,
  "created_at" : "2014-11-14 04:36:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533115983347453953",
  "text" : "Oh yeah I turned 27 today, that\u2019s a thing",
  "id" : 533115983347453953,
  "created_at" : "2014-11-14 04:35:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "indices" : [ 0, 14 ],
      "id_str" : "369585978",
      "id" : 369585978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533115645513068546",
  "geo" : { },
  "id_str" : "533115751880593409",
  "in_reply_to_user_id" : 369585978,
  "text" : "@meaganewaller I compel you to charge your iPhone!",
  "id" : 533115751880593409,
  "in_reply_to_status_id" : 533115645513068546,
  "created_at" : "2014-11-14 04:34:34 +0000",
  "in_reply_to_screen_name" : "meaganewaller",
  "in_reply_to_user_id_str" : "369585978",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533115611841179649",
  "text" : "To think of what humanity could achieve if the effort and passion put into being fans of professional sports was used in any other fashion",
  "id" : 533115611841179649,
  "created_at" : "2014-11-14 04:34:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "keeran",
      "screen_name" : "keeran",
      "indices" : [ 3, 10 ],
      "id_str" : "10075872",
      "id" : 10075872
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "value",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/JBk02Ymp1s",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=pquYAEfbBFM",
      "display_url" : "youtube.com\/watch?v=pquYAE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533092682474602499",
  "text" : "RT @keeran: 4 mins of pro wrestlers inhaling before shouting https:\/\/t.co\/JBk02Ymp1s #value",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "value",
        "indices" : [ 73, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/JBk02Ymp1s",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=pquYAEfbBFM",
        "display_url" : "youtube.com\/watch?v=pquYAE\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "533092232380039171",
    "text" : "4 mins of pro wrestlers inhaling before shouting https:\/\/t.co\/JBk02Ymp1s #value",
    "id" : 533092232380039171,
    "created_at" : "2014-11-14 03:01:07 +0000",
    "user" : {
      "name" : "keeran",
      "screen_name" : "keeran",
      "protected" : false,
      "id_str" : "10075872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2870642136\/2165965c12d2c88fc21fb4ba84ab86a8_normal.png",
      "id" : 10075872,
      "verified" : false
    }
  },
  "id" : 533092682474602499,
  "created_at" : "2014-11-14 03:02:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533069473323155456",
  "text" : "New Mario Kart 8 tracks!! Anyone playing online?",
  "id" : 533069473323155456,
  "created_at" : "2014-11-14 01:30:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 58, 68 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/533054630612045825\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/EyptOPGcAu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2XKXDRCEAEakl4.jpg",
      "id_str" : "533054628275818497",
      "id" : 533054628275818497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2XKXDRCEAEakl4.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/EyptOPGcAu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533054630612045825",
  "text" : "I don\u2019t take selfies often, but this meta tie handmade by @aquaranto is worth it http:\/\/t.co\/EyptOPGcAu",
  "id" : 533054630612045825,
  "created_at" : "2014-11-14 00:31:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allan branch",
      "screen_name" : "allanbranch",
      "indices" : [ 3, 15 ],
      "id_str" : "6183972",
      "id" : 6183972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/AmAmDA27gf",
      "expanded_url" : "https:\/\/signalvnoise.com\/posts\/2028-i-have-no-desire-to-scale-up-or-get",
      "display_url" : "signalvnoise.com\/posts\/2028-i-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532947530842001408",
  "text" : "RT @allanbranch: I love this quote so much.\nhttps:\/\/t.co\/AmAmDA27gf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/AmAmDA27gf",
        "expanded_url" : "https:\/\/signalvnoise.com\/posts\/2028-i-have-no-desire-to-scale-up-or-get",
        "display_url" : "signalvnoise.com\/posts\/2028-i-h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "532946452579098624",
    "text" : "I love this quote so much.\nhttps:\/\/t.co\/AmAmDA27gf",
    "id" : 532946452579098624,
    "created_at" : "2014-11-13 17:21:50 +0000",
    "user" : {
      "name" : "allan branch",
      "screen_name" : "allanbranch",
      "protected" : false,
      "id_str" : "6183972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501026341396176897\/BVRWtRWq_normal.jpeg",
      "id" : 6183972,
      "verified" : false
    }
  },
  "id" : 532947530842001408,
  "created_at" : "2014-11-13 17:26:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/bUshJJHM63",
      "expanded_url" : "https:\/\/www.destroyallsoftware.com\/talks\/the-birth-and-death-of-javascript",
      "display_url" : "destroyallsoftware.com\/talks\/the-birt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532930918046892033",
  "text" : "If you haven't been introduced to Yavascript, take it away https:\/\/t.co\/bUshJJHM63",
  "id" : 532930918046892033,
  "created_at" : "2014-11-13 16:20:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 62, 76 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532929639950188544",
  "text" : "Everytime I'm frustrated with JavaScript I now slide into the @garybernhardt \"Yavascript\" pronunciation out of protest",
  "id" : 532929639950188544,
  "created_at" : "2014-11-13 16:15:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Twining",
      "screen_name" : "trevortwining",
      "indices" : [ 0, 14 ],
      "id_str" : "10249542",
      "id" : 10249542
    }, {
      "name" : "Cowork Niagara",
      "screen_name" : "coworkniagara",
      "indices" : [ 15, 29 ],
      "id_str" : "180632001",
      "id" : 180632001
    }, {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 50, 65 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532873772341014528",
  "geo" : { },
  "id_str" : "532884340137422849",
  "in_reply_to_user_id" : 10249542,
  "text" : "@trevortwining @coworkniagara we need to get some @PublicEspresso exported for you",
  "id" : 532884340137422849,
  "in_reply_to_status_id" : 532873772341014528,
  "created_at" : "2014-11-13 13:15:01 +0000",
  "in_reply_to_screen_name" : "trevortwining",
  "in_reply_to_user_id_str" : "10249542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James O'Leary",
      "screen_name" : "jpohh",
      "indices" : [ 0, 6 ],
      "id_str" : "14174759",
      "id" : 14174759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532751533981450241",
  "geo" : { },
  "id_str" : "532751772977086465",
  "in_reply_to_user_id" : 14174759,
  "text" : "@jpohh dealing with any Cocoa API in swift is so gross. I don\u2019t feel they thought about this enough.",
  "id" : 532751772977086465,
  "in_reply_to_status_id" : 532751533981450241,
  "created_at" : "2014-11-13 04:28:15 +0000",
  "in_reply_to_screen_name" : "jpohh",
  "in_reply_to_user_id_str" : "14174759",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    }, {
      "name" : "Sylvia Chong",
      "screen_name" : "sylvzc",
      "indices" : [ 48, 55 ],
      "id_str" : "2544124698",
      "id" : 2544124698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532729376170074112",
  "geo" : { },
  "id_str" : "532729557564928000",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety holy shit, it\u2019s still going? Also find @sylvzc and say hi",
  "id" : 532729557564928000,
  "in_reply_to_status_id" : 532729376170074112,
  "created_at" : "2014-11-13 02:59:58 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Willis",
      "screen_name" : "derekwillis",
      "indices" : [ 3, 15 ],
      "id_str" : "14517538",
      "id" : 14517538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532729108003061760",
  "text" : "RT @derekwillis: It's possible for me to find a century-old newspaper, yet work I did 8-10 years ago on the web is gone.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532722547167887362",
    "text" : "It's possible for me to find a century-old newspaper, yet work I did 8-10 years ago on the web is gone.",
    "id" : 532722547167887362,
    "created_at" : "2014-11-13 02:32:07 +0000",
    "user" : {
      "name" : "Derek Willis",
      "screen_name" : "derekwillis",
      "protected" : false,
      "id_str" : "14517538",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492346787080851456\/sNvis_r-_normal.jpeg",
      "id" : 14517538,
      "verified" : true
    }
  },
  "id" : 532729108003061760,
  "created_at" : "2014-11-13 02:58:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Kerr",
      "screen_name" : "jessitron",
      "indices" : [ 0, 10 ],
      "id_str" : "25103",
      "id" : 25103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532673498435829760",
  "geo" : { },
  "id_str" : "532676732634288129",
  "in_reply_to_user_id" : 25103,
  "text" : "@jessitron whatever it is, it\u2019s the furthest thing from \u201CEngineering\u201D possible. (This from someone with a Softear Engineering degree)",
  "id" : 532676732634288129,
  "in_reply_to_status_id" : 532673498435829760,
  "created_at" : "2014-11-12 23:30:04 +0000",
  "in_reply_to_screen_name" : "jessitron",
  "in_reply_to_user_id_str" : "25103",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "indices" : [ 0, 14 ],
      "id_str" : "369585978",
      "id" : 369585978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532616228498468864",
  "geo" : { },
  "id_str" : "532661233041014784",
  "in_reply_to_user_id" : 369585978,
  "text" : "@meaganewaller what\u2019s the emoji for brain washing",
  "id" : 532661233041014784,
  "in_reply_to_status_id" : 532616228498468864,
  "created_at" : "2014-11-12 22:28:28 +0000",
  "in_reply_to_screen_name" : "meaganewaller",
  "in_reply_to_user_id_str" : "369585978",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/oqtATzDHtX",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/qrush\/8299297108\/sizes\/l",
      "display_url" : "flickr.com\/photos\/qrush\/8\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "532654188186976256",
  "geo" : { },
  "id_str" : "532654995314065408",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms agreed :) well if you make it to Buffalo, the Barkyard awaits https:\/\/t.co\/oqtATzDHtX",
  "id" : 532654995314065408,
  "in_reply_to_status_id" : 532654188186976256,
  "created_at" : "2014-11-12 22:03:41 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532645984916893696",
  "geo" : { },
  "id_str" : "532653787761348608",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms lol gonna have a backyard in NYC? :P",
  "id" : 532653787761348608,
  "in_reply_to_status_id" : 532645984916893696,
  "created_at" : "2014-11-12 21:58:53 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532650473267138560",
  "text" : "I'm so glad they're installing Christmas lights on Main Street for all of these Cars On Main Street to drive by and look at",
  "id" : 532650473267138560,
  "created_at" : "2014-11-12 21:45:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532649698830852097",
  "text" : "Shipping a product is saying no 100 times to say yes once. If you're saying yes to everything, you're not shipping.",
  "id" : 532649698830852097,
  "created_at" : "2014-11-12 21:42:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Langford",
      "screen_name" : "Chris_Langford",
      "indices" : [ 3, 18 ],
      "id_str" : "130242651",
      "id" : 130242651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/GbrGKrCpg7",
      "expanded_url" : "http:\/\/www.neogaf.com\/forum\/showpost.php?p=138575953&postcount=41",
      "display_url" : "neogaf.com\/forum\/showpost\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532645893833773056",
  "text" : "RT @Chris_Langford: Holy hell. Nintendo lost the source code to Link's Awakening and coded DX by disassembling the original rom - http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/GbrGKrCpg7",
        "expanded_url" : "http:\/\/www.neogaf.com\/forum\/showpost.php?p=138575953&postcount=41",
        "display_url" : "neogaf.com\/forum\/showpost\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "532643459073855488",
    "text" : "Holy hell. Nintendo lost the source code to Link's Awakening and coded DX by disassembling the original rom - http:\/\/t.co\/GbrGKrCpg7",
    "id" : 532643459073855488,
    "created_at" : "2014-11-12 21:17:51 +0000",
    "user" : {
      "name" : "Chris Langford",
      "screen_name" : "Chris_Langford",
      "protected" : false,
      "id_str" : "130242651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565142560402702337\/fhoTIxdC_normal.jpeg",
      "id" : 130242651,
      "verified" : false
    }
  },
  "id" : 532645893833773056,
  "created_at" : "2014-11-12 21:27:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    }, {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 47, 59 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532645121263554560",
  "geo" : { },
  "id_str" : "532645358237929473",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms heh I'll say the same thing I said to @jamesgolick: Don't forget there's a NYS.",
  "id" : 532645358237929473,
  "in_reply_to_status_id" : 532645121263554560,
  "created_at" : "2014-11-12 21:25:24 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532637475764969472",
  "geo" : { },
  "id_str" : "532643828843675648",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms also where in NY? Have a feeling you're thinking NYC.",
  "id" : 532643828843675648,
  "in_reply_to_status_id" : 532637475764969472,
  "created_at" : "2014-11-12 21:19:19 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532637475764969472",
  "geo" : { },
  "id_str" : "532638099843846144",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms i'll take snow over tornadoes, hurricanes, earthquakes, or volcanos anyday",
  "id" : 532638099843846144,
  "in_reply_to_status_id" : 532637475764969472,
  "created_at" : "2014-11-12 20:56:33 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/tPO7seRrcd",
      "expanded_url" : "https:\/\/ifttt.com\/recipes\/147701-text-me-erie-county-ny-buffalo-weather-alerts-from-national-weather-service",
      "display_url" : "ifttt.com\/recipes\/147701\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532635527343005696",
  "text" : "Given NOAA is already starting to issue alerts for Erie County, if you want them SMS'd to your phone, get this: https:\/\/t.co\/tPO7seRrcd",
  "id" : 532635527343005696,
  "created_at" : "2014-11-12 20:46:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "The Public",
      "screen_name" : "PublicBFLO",
      "indices" : [ 85, 96 ],
      "id_str" : "2837661305",
      "id" : 2837661305
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kevinpurdy\/status\/532619511137337344\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/CZKlnKbCY9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2Q-mlGCEAAMUgF.jpg",
      "id_str" : "532619488449925120",
      "id" : 532619488449925120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2Q-mlGCEAAMUgF.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/CZKlnKbCY9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532620096192380928",
  "text" : "RT @kevinpurdy: Please keep this 2-page, amusing, informative spread feature coming, @PublicBFLO. http:\/\/t.co\/CZKlnKbCY9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Public",
        "screen_name" : "PublicBFLO",
        "indices" : [ 69, 80 ],
        "id_str" : "2837661305",
        "id" : 2837661305
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kevinpurdy\/status\/532619511137337344\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/CZKlnKbCY9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2Q-mlGCEAAMUgF.jpg",
        "id_str" : "532619488449925120",
        "id" : 532619488449925120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2Q-mlGCEAAMUgF.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/CZKlnKbCY9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532619511137337344",
    "text" : "Please keep this 2-page, amusing, informative spread feature coming, @PublicBFLO. http:\/\/t.co\/CZKlnKbCY9",
    "id" : 532619511137337344,
    "created_at" : "2014-11-12 19:42:41 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 532620096192380928,
  "created_at" : "2014-11-12 19:45:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/Gw1YpfGNkc",
      "expanded_url" : "https:\/\/twitter.com\/37signals\/status\/532568956444225536",
      "display_url" : "twitter.com\/37signals\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532604981351043072",
  "text" : "Today in device testing https:\/\/t.co\/Gw1YpfGNkc",
  "id" : 532604981351043072,
  "created_at" : "2014-11-12 18:44:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Public",
      "screen_name" : "PublicBFLO",
      "indices" : [ 27, 38 ],
      "id_str" : "2837661305",
      "id" : 2837661305
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/532600167002685440\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/Roy19LQs2V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2QtBsqCIAAx_ch.jpg",
      "id_str" : "532600163127140352",
      "id" : 532600163127140352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2QtBsqCIAAx_ch.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Roy19LQs2V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532600167002685440",
  "text" : "You\u2019ve made a huge mistake @PublicBFLO http:\/\/t.co\/Roy19LQs2V",
  "id" : 532600167002685440,
  "created_at" : "2014-11-12 18:25:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532598636463808513",
  "text" : "Canceled my LivePhish trial before it bills tomorrow. $99 is a lot, and there's a lot of music, but it doesn't feel worth it.",
  "id" : 532598636463808513,
  "created_at" : "2014-11-12 18:19:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532594942930354176",
  "text" : "And especially compared to webview\/html\/css, it's laughably difficult.",
  "id" : 532594942930354176,
  "created_at" : "2014-11-12 18:05:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532594875146203136",
  "text" : "Autolayout and the VFL is nice, but it does not make laying out native elements *any* easier compared to frames.",
  "id" : 532594875146203136,
  "created_at" : "2014-11-12 18:04:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/37signals\/status\/532568956444225536\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/MsYY1DShy0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2QQpLzCAAAPWRk.jpg",
      "id_str" : "532568955664072704",
      "id" : 532568955664072704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2QQpLzCAAAPWRk.jpg",
      "sizes" : [ {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MsYY1DShy0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532575016333094912",
  "text" : "RT @37signals: Just doing some testing... http:\/\/t.co\/MsYY1DShy0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/37signals\/status\/532568956444225536\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/MsYY1DShy0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2QQpLzCAAAPWRk.jpg",
        "id_str" : "532568955664072704",
        "id" : 532568955664072704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2QQpLzCAAAPWRk.jpg",
        "sizes" : [ {
          "h" : 447,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1529,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/MsYY1DShy0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532568956444225536",
    "text" : "Just doing some testing... http:\/\/t.co\/MsYY1DShy0",
    "id" : 532568956444225536,
    "created_at" : "2014-11-12 16:21:48 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 532575016333094912,
  "created_at" : "2014-11-12 16:45:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532569470137806848",
  "geo" : { },
  "id_str" : "532569645371625472",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis Luckily you have infinite oxygen! We'll send a rescue mission right away.",
  "id" : 532569645371625472,
  "in_reply_to_status_id" : 532569470137806848,
  "created_at" : "2014-11-12 16:24:32 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532568292272406528",
  "text" : "Kerbin: We've landed on the comet! Wooo!\nJeb: Hey, I've planted the flag! How do I get back to Kerbin now?\nKerbin: Uh...",
  "id" : 532568292272406528,
  "created_at" : "2014-11-12 16:19:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532566827248128002",
  "text" : "Ok, the planet name is Kerbin. WHATEVER",
  "id" : 532566827248128002,
  "created_at" : "2014-11-12 16:13:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532566566521802752",
  "text" : "Seriously, someone extend the antenna and transmit that Science Value back to Kerbal from the comet. That's easily enough for new boosters.",
  "id" : 532566566521802752,
  "created_at" : "2014-11-12 16:12:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 0, 13 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532566138043899904",
  "geo" : { },
  "id_str" : "532566220651102208",
  "in_reply_to_user_id" : 14204623,
  "text" : "@moonpolysoft *starts playing Aerosmith and slowly walks to a launch pad*",
  "id" : 532566220651102208,
  "in_reply_to_status_id" : 532566138043899904,
  "created_at" : "2014-11-12 16:10:56 +0000",
  "in_reply_to_screen_name" : "moonpolysoft",
  "in_reply_to_user_id_str" : "14204623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532566082289410048",
  "text" : "It's really funny to see that MS is more dedicated to OSS than Apple is. Can you imagine if iOS was opened up?",
  "id" : 532566082289410048,
  "created_at" : "2014-11-12 16:10:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532560164654940160",
  "text" : "*slow blink* re MS news - I wonder if it will actually change anything.",
  "id" : 532560164654940160,
  "created_at" : "2014-11-12 15:46:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532557177391968256",
  "geo" : { },
  "id_str" : "532557485748396032",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit Oh for fuck's sake",
  "id" : 532557485748396032,
  "in_reply_to_status_id" : 532557177391968256,
  "created_at" : "2014-11-12 15:36:13 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/p95W7hRTMX",
      "expanded_url" : "https:\/\/vimeo.com\/111593693",
      "display_url" : "vimeo.com\/111593693"
    } ]
  },
  "geo" : { },
  "id_str" : "532538097083224064",
  "text" : "This little guy is 1 today. https:\/\/t.co\/p95W7hRTMX",
  "id" : 532538097083224064,
  "created_at" : "2014-11-12 14:19:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532521958269673473",
  "text" : "Replay is really a great app, but never leave a video incomplete. App crashes on load, and support\u2019s only suggestion is to delete the app. \uD83D\uDE10",
  "id" : 532521958269673473,
  "created_at" : "2014-11-12 13:15:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/WKixKzhjX1",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=i6zaVYWLTkU",
      "display_url" : "m.youtube.com\/watch?v=i6zaVY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532506419753279489",
  "text" : "First lake effect snow warning of the year for Buffalo!  https:\/\/t.co\/WKixKzhjX1",
  "id" : 532506419753279489,
  "created_at" : "2014-11-12 12:13:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cuff\u00E9",
      "screen_name" : "CuffyMeh",
      "indices" : [ 3, 12 ],
      "id_str" : "100480088",
      "id" : 100480088
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/CuffyMeh\/status\/531879244000145408\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/G5cTl2ZAB2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2GdWofCYAA9c6Q.jpg",
      "id_str" : "531879243156709376",
      "id" : 531879243156709376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2GdWofCYAA9c6Q.jpg",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/G5cTl2ZAB2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532393369159225345",
  "text" : "RT @CuffyMeh: \"I hereby grant full amnesty to all Romulan ships entering the Neutral Zone.\" http:\/\/t.co\/G5cTl2ZAB2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CuffyMeh\/status\/531879244000145408\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/G5cTl2ZAB2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2GdWofCYAA9c6Q.jpg",
        "id_str" : "531879243156709376",
        "id" : 531879243156709376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2GdWofCYAA9c6Q.jpg",
        "sizes" : [ {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/G5cTl2ZAB2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531879244000145408",
    "text" : "\"I hereby grant full amnesty to all Romulan ships entering the Neutral Zone.\" http:\/\/t.co\/G5cTl2ZAB2",
    "id" : 531879244000145408,
    "created_at" : "2014-11-10 18:41:08 +0000",
    "user" : {
      "name" : "Cuff\u00E9",
      "screen_name" : "CuffyMeh",
      "protected" : false,
      "id_str" : "100480088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1707882029\/cuffy128_normal.jpg",
      "id" : 100480088,
      "verified" : false
    }
  },
  "id" : 532393369159225345,
  "created_at" : "2014-11-12 04:44:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Public",
      "screen_name" : "PublicBFLO",
      "indices" : [ 3, 14 ],
      "id_str" : "2837661305",
      "id" : 2837661305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/uFX759pTE9",
      "expanded_url" : "http:\/\/www.dailypublic.com",
      "display_url" : "dailypublic.com"
    } ]
  },
  "geo" : { },
  "id_str" : "532333152782413825",
  "text" : "RT @PublicBFLO: We'll just leave this here... http:\/\/t.co\/uFX759pTE9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/uFX759pTE9",
        "expanded_url" : "http:\/\/www.dailypublic.com",
        "display_url" : "dailypublic.com"
      } ]
    },
    "geo" : { },
    "id_str" : "532331033270579200",
    "text" : "We'll just leave this here... http:\/\/t.co\/uFX759pTE9",
    "id" : 532331033270579200,
    "created_at" : "2014-11-12 00:36:23 +0000",
    "user" : {
      "name" : "The Public",
      "screen_name" : "PublicBFLO",
      "protected" : false,
      "id_str" : "2837661305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526847131340906496\/xOmk8i64_normal.png",
      "id" : 2837661305,
      "verified" : false
    }
  },
  "id" : 532333152782413825,
  "created_at" : "2014-11-12 00:44:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 3, 11 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532332989049348096",
  "text" : "RT @bascule: Every major TLS stack: OpenSSL, GNUTLS, NSS, MS SChannel, and Apple SecureTransport has had a severe vulnerability this year",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532268499331448832",
    "text" : "Every major TLS stack: OpenSSL, GNUTLS, NSS, MS SChannel, and Apple SecureTransport has had a severe vulnerability this year",
    "id" : 532268499331448832,
    "created_at" : "2014-11-11 20:27:53 +0000",
    "user" : {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "protected" : false,
      "id_str" : "6083342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450061818606522368\/pjDTHFB9_normal.jpeg",
      "id" : 6083342,
      "verified" : false
    }
  },
  "id" : 532332989049348096,
  "created_at" : "2014-11-12 00:44:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hamad",
      "screen_name" : "MikeHamad",
      "indices" : [ 0, 10 ],
      "id_str" : "27085484",
      "id" : 27085484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532169931790778369",
  "geo" : { },
  "id_str" : "532325618478628866",
  "in_reply_to_user_id" : 27085484,
  "text" : "@MikeHamad how'd it go? :)",
  "id" : 532325618478628866,
  "in_reply_to_status_id" : 532169931790778369,
  "created_at" : "2014-11-12 00:14:52 +0000",
  "in_reply_to_screen_name" : "MikeHamad",
  "in_reply_to_user_id_str" : "27085484",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "indices" : [ 0, 10 ],
      "id_str" : "816041347",
      "id" : 816041347
    }, {
      "name" : "Tori BreadHive",
      "screen_name" : "ToriBreadHive",
      "indices" : [ 64, 78 ],
      "id_str" : "1945549338",
      "id" : 1945549338
    }, {
      "name" : "Allison BreadHive",
      "screen_name" : "AlisonBreadHive",
      "indices" : [ 79, 95 ],
      "id_str" : "1945604605",
      "id" : 1945604605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532301894631170048",
  "in_reply_to_user_id" : 816041347,
  "text" : "@BreadHive crap I forgot to pickup. Are you still open until 6? @ToriBreadHive @AlisonBreadHive",
  "id" : 532301894631170048,
  "created_at" : "2014-11-11 22:40:36 +0000",
  "in_reply_to_screen_name" : "BreadHive",
  "in_reply_to_user_id_str" : "816041347",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/37signals\/status\/532254048510939136\/photo\/1",
      "indices" : [ 142, 143 ],
      "url" : "http:\/\/t.co\/UIy0gKNhoD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2LyPIPCEAA-kYg.jpg",
      "id_str" : "532254047705632768",
      "id" : 532254047705632768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2LyPIPCEAA-kYg.jpg",
      "sizes" : [ {
        "h" : 459,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1384,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 4096,
        "resize" : "fit",
        "w" : 3030
      }, {
        "h" : 811,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UIy0gKNhoD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/5TwOdf0VTC",
      "expanded_url" : "http:\/\/www.stickermule.com\/marketplace\/3036-meetings-are-toxic",
      "display_url" : "stickermule.com\/marketplace\/30\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532256433103208448",
  "text" : "RT @37signals: Tuesday tip: Get the official \u201CMeetings are toxic\u201D sticker for your office meeting room! \u2014&gt; http:\/\/t.co\/5TwOdf0VTC http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/37signals\/status\/532254048510939136\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/UIy0gKNhoD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2LyPIPCEAA-kYg.jpg",
        "id_str" : "532254047705632768",
        "id" : 532254047705632768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2LyPIPCEAA-kYg.jpg",
        "sizes" : [ {
          "h" : 459,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1384,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 4096,
          "resize" : "fit",
          "w" : 3030
        }, {
          "h" : 811,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/UIy0gKNhoD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/5TwOdf0VTC",
        "expanded_url" : "http:\/\/www.stickermule.com\/marketplace\/3036-meetings-are-toxic",
        "display_url" : "stickermule.com\/marketplace\/30\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "532254048510939136",
    "text" : "Tuesday tip: Get the official \u201CMeetings are toxic\u201D sticker for your office meeting room! \u2014&gt; http:\/\/t.co\/5TwOdf0VTC http:\/\/t.co\/UIy0gKNhoD",
    "id" : 532254048510939136,
    "created_at" : "2014-11-11 19:30:28 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 532256433103208448,
  "created_at" : "2014-11-11 19:39:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bruntlett",
      "screen_name" : "modacitylife",
      "indices" : [ 3, 16 ],
      "id_str" : "44974922",
      "id" : 44974922
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/modacitylife\/status\/532251475540316160\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/h6vUZKx0v0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2Lv5BpCEAAU9cQ.jpg",
      "id_str" : "532251468955258880",
      "id" : 532251468955258880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2Lv5BpCEAAU9cQ.jpg",
      "sizes" : [ {
        "h" : 796,
        "resize" : "fit",
        "w" : 586
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 796,
        "resize" : "fit",
        "w" : 586
      }, {
        "h" : 461,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 796,
        "resize" : "fit",
        "w" : 586
      } ],
      "display_url" : "pic.twitter.com\/h6vUZKx0v0"
    } ],
    "hashtags" : [ {
      "text" : "2WalkAndCycle",
      "indices" : [ 119, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532256398642782209",
  "text" : "RT @modacitylife: Brilliant depiction of the sad state of walking in our cities. (Artist unknown, via Daniel Sauter at #2WalkAndCycle). htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/modacitylife\/status\/532251475540316160\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/h6vUZKx0v0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2Lv5BpCEAAU9cQ.jpg",
        "id_str" : "532251468955258880",
        "id" : 532251468955258880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2Lv5BpCEAAU9cQ.jpg",
        "sizes" : [ {
          "h" : 796,
          "resize" : "fit",
          "w" : 586
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 796,
          "resize" : "fit",
          "w" : 586
        }, {
          "h" : 461,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 796,
          "resize" : "fit",
          "w" : 586
        } ],
        "display_url" : "pic.twitter.com\/h6vUZKx0v0"
      } ],
      "hashtags" : [ {
        "text" : "2WalkAndCycle",
        "indices" : [ 101, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532251475540316160",
    "text" : "Brilliant depiction of the sad state of walking in our cities. (Artist unknown, via Daniel Sauter at #2WalkAndCycle). http:\/\/t.co\/h6vUZKx0v0",
    "id" : 532251475540316160,
    "created_at" : "2014-11-11 19:20:15 +0000",
    "user" : {
      "name" : "Chris Bruntlett",
      "screen_name" : "modacitylife",
      "protected" : false,
      "id_str" : "44974922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524712182211047424\/e-_wryVC_normal.jpeg",
      "id" : 44974922,
      "verified" : false
    }
  },
  "id" : 532256398642782209,
  "created_at" : "2014-11-11 19:39:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 0, 7 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532229168856313856",
  "geo" : { },
  "id_str" : "532232560206569473",
  "in_reply_to_user_id" : 38003,
  "text" : "@gedeon RGB Express has been pretty great",
  "id" : 532232560206569473,
  "in_reply_to_status_id" : 532229168856313856,
  "created_at" : "2014-11-11 18:05:05 +0000",
  "in_reply_to_screen_name" : "gedeon",
  "in_reply_to_user_id_str" : "38003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/BgB8SXZvF5",
      "expanded_url" : "http:\/\/www.shareyouroffice.com\/blog-syo\/us-coworking-survey\/",
      "display_url" : "shareyouroffice.com\/blog-syo\/us-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532192770182483968",
  "text" : "RT @coworkbuffalo: The U.S. Coworking Survey is out! http:\/\/t.co\/BgB8SXZvF5 More than 500 spaces for 42 million freelancers in U.S. We are \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/BgB8SXZvF5",
        "expanded_url" : "http:\/\/www.shareyouroffice.com\/blog-syo\/us-coworking-survey\/",
        "display_url" : "shareyouroffice.com\/blog-syo\/us-co\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "532191974468505600",
    "text" : "The U.S. Coworking Survey is out! http:\/\/t.co\/BgB8SXZvF5 More than 500 spaces for 42 million freelancers in U.S. We are one of them.",
    "id" : 532191974468505600,
    "created_at" : "2014-11-11 15:23:49 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 532192770182483968,
  "created_at" : "2014-11-11 15:26:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hamad",
      "screen_name" : "MikeHamad",
      "indices" : [ 0, 10 ],
      "id_str" : "27085484",
      "id" : 27085484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532168709688004608",
  "geo" : { },
  "id_str" : "532168995219070978",
  "in_reply_to_user_id" : 27085484,
  "text" : "@MikeHamad awesome. The entire thing feels really cohesive too. Let me know if you get a chance to listen!",
  "id" : 532168995219070978,
  "in_reply_to_status_id" : 532168709688004608,
  "created_at" : "2014-11-11 13:52:30 +0000",
  "in_reply_to_screen_name" : "MikeHamad",
  "in_reply_to_user_id_str" : "27085484",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hamad",
      "screen_name" : "MikeHamad",
      "indices" : [ 0, 10 ],
      "id_str" : "27085484",
      "id" : 27085484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/zSkL1HAtlT",
      "expanded_url" : "http:\/\/aqueous1.bandcamp.com\/album\/cycles?from=embed",
      "display_url" : "aqueous1.bandcamp.com\/album\/cycles?f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532168590418407424",
  "in_reply_to_user_id" : 27085484,
  "text" : "@MikeHamad have you listened to the new Aqueous album yet? Lots of long (mappable) jams\u2026 http:\/\/t.co\/zSkL1HAtlT",
  "id" : 532168590418407424,
  "created_at" : "2014-11-11 13:50:53 +0000",
  "in_reply_to_screen_name" : "MikeHamad",
  "in_reply_to_user_id_str" : "27085484",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hamad",
      "screen_name" : "MikeHamad",
      "indices" : [ 0, 10 ],
      "id_str" : "27085484",
      "id" : 27085484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532162575476486145",
  "geo" : { },
  "id_str" : "532162752697991168",
  "in_reply_to_user_id" : 27085484,
  "text" : "@MikeHamad your trip is short!",
  "id" : 532162752697991168,
  "in_reply_to_status_id" : 532162575476486145,
  "created_at" : "2014-11-11 13:27:42 +0000",
  "in_reply_to_screen_name" : "MikeHamad",
  "in_reply_to_user_id_str" : "27085484",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532148621073215488",
  "geo" : { },
  "id_str" : "532148976988864512",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j I have dreamt of doing this for years",
  "id" : 532148976988864512,
  "in_reply_to_status_id" : 532148621073215488,
  "created_at" : "2014-11-11 12:32:57 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532027671060836353",
  "geo" : { },
  "id_str" : "532028214093152256",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck funny how they don\u2019t ever mention being robbed before",
  "id" : 532028214093152256,
  "in_reply_to_status_id" : 532027671060836353,
  "created_at" : "2014-11-11 04:33:05 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/PzN4idI4wD",
      "expanded_url" : "https:\/\/gnome.org\/groupon\/",
      "display_url" : "gnome.org\/groupon\/"
    } ]
  },
  "geo" : { },
  "id_str" : "532027695371022337",
  "text" : "Actually it\u2019s about ethics in daily deals marketing https:\/\/t.co\/PzN4idI4wD",
  "id" : 532027695371022337,
  "created_at" : "2014-11-11 04:31:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@Pete716",
      "screen_name" : "Pete716",
      "indices" : [ 7, 15 ],
      "id_str" : "33588043",
      "id" : 33588043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/l84hHYrgtG",
      "expanded_url" : "http:\/\/imgur.com\/MFQBcSo",
      "display_url" : "imgur.com\/MFQBcSo"
    } ]
  },
  "geo" : { },
  "id_str" : "532026089787232257",
  "text" : "I hope @pete716 takes photos like this every few years so we can see how things change. My neighborhood: http:\/\/t.co\/l84hHYrgtG",
  "id" : 532026089787232257,
  "created_at" : "2014-11-11 04:24:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Kanalley",
      "screen_name" : "ckanal",
      "indices" : [ 0, 7 ],
      "id_str" : "15964196",
      "id" : 15964196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532008207154425856",
  "geo" : { },
  "id_str" : "532008348044886016",
  "in_reply_to_user_id" : 15964196,
  "text" : "@ckanal ?- what\u2019s in those brownies at the Harborcenter?",
  "id" : 532008348044886016,
  "in_reply_to_status_id" : 532008207154425856,
  "created_at" : "2014-11-11 03:14:09 +0000",
  "in_reply_to_screen_name" : "ckanal",
  "in_reply_to_user_id_str" : "15964196",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barf bag",
      "screen_name" : "barf_bag_",
      "indices" : [ 3, 13 ],
      "id_str" : "32544087",
      "id" : 32544087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/CSBXtmBiAd",
      "expanded_url" : "https:\/\/vine.co\/v\/OiKpdBK52nV",
      "display_url" : "vine.co\/v\/OiKpdBK52nV"
    } ]
  },
  "geo" : { },
  "id_str" : "532004763273936897",
  "text" : "RT @barf_bag_: https:\/\/t.co\/CSBXtmBiAd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/CSBXtmBiAd",
        "expanded_url" : "https:\/\/vine.co\/v\/OiKpdBK52nV",
        "display_url" : "vine.co\/v\/OiKpdBK52nV"
      } ]
    },
    "geo" : { },
    "id_str" : "532002665073762305",
    "text" : "https:\/\/t.co\/CSBXtmBiAd",
    "id" : 532002665073762305,
    "created_at" : "2014-11-11 02:51:34 +0000",
    "user" : {
      "name" : "barf bag",
      "screen_name" : "barf_bag_",
      "protected" : false,
      "id_str" : "32544087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458143107653980160\/Ve91M7wk_normal.jpeg",
      "id" : 32544087,
      "verified" : false
    }
  },
  "id" : 532004763273936897,
  "created_at" : "2014-11-11 02:59:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrminer",
      "screen_name" : "mrminer",
      "indices" : [ 0, 8 ],
      "id_str" : "16519576",
      "id" : 16519576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531893390627991552",
  "geo" : { },
  "id_str" : "531949708629925888",
  "in_reply_to_user_id" : 16519576,
  "text" : "@mrminer glad to see some positive feedback. Nice post!",
  "id" : 531949708629925888,
  "in_reply_to_status_id" : 531893390627991552,
  "created_at" : "2014-11-10 23:21:08 +0000",
  "in_reply_to_screen_name" : "mrminer",
  "in_reply_to_user_id_str" : "16519576",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Phunion",
      "screen_name" : "thephunion",
      "indices" : [ 3, 14 ],
      "id_str" : "270005139",
      "id" : 270005139
    }, {
      "name" : "Umphrey's McGee",
      "screen_name" : "umphreysmcgee",
      "indices" : [ 37, 51 ],
      "id_str" : "16724705",
      "id" : 16724705
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 53, 65 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531940307613409280",
  "text" : "RT @thephunion: Not to be outdone by @umphreysmcgee, @AqueousBand will write the intro music for 'Wake Up Buffalo'",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Umphrey's McGee",
        "screen_name" : "umphreysmcgee",
        "indices" : [ 21, 35 ],
        "id_str" : "16724705",
        "id" : 16724705
      }, {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 37, 49 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531933534743982080",
    "text" : "Not to be outdone by @umphreysmcgee, @AqueousBand will write the intro music for 'Wake Up Buffalo'",
    "id" : 531933534743982080,
    "created_at" : "2014-11-10 22:16:52 +0000",
    "user" : {
      "name" : "The Phunion",
      "screen_name" : "thephunion",
      "protected" : false,
      "id_str" : "270005139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/503188230334722048\/6GhG3cl2_normal.jpeg",
      "id" : 270005139,
      "verified" : false
    }
  },
  "id" : 531940307613409280,
  "created_at" : "2014-11-10 22:43:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531925970060861440",
  "geo" : { },
  "id_str" : "531926221303459840",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow burning hilarious amounts of cash on billboards in the SF area?",
  "id" : 531926221303459840,
  "in_reply_to_status_id" : 531925970060861440,
  "created_at" : "2014-11-10 21:47:48 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "twilio",
      "screen_name" : "twilio",
      "indices" : [ 0, 7 ],
      "id_str" : "15936194",
      "id" : 15936194
    }, {
      "name" : "Greg Baugues",
      "screen_name" : "greggyb",
      "indices" : [ 109, 117 ],
      "id_str" : "15048829",
      "id" : 15048829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531924965952466944",
  "in_reply_to_user_id" : 15936194,
  "text" : "@twilio I haven't heard from your support and it's been hours now. Any chance 272171 could get an update? cc @greggyb",
  "id" : 531924965952466944,
  "created_at" : "2014-11-10 21:42:49 +0000",
  "in_reply_to_screen_name" : "twilio",
  "in_reply_to_user_id_str" : "15936194",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531910628924223488",
  "geo" : { },
  "id_str" : "531910929923842048",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit now you can retire as a Buffalo News commenter",
  "id" : 531910929923842048,
  "in_reply_to_status_id" : 531910628924223488,
  "created_at" : "2014-11-10 20:47:02 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/5bCmLMGE26",
      "expanded_url" : "http:\/\/quaran.to\/archive\/",
      "display_url" : "quaran.to\/archive\/"
    } ]
  },
  "geo" : { },
  "id_str" : "531894032444563456",
  "text" : "Updated http:\/\/t.co\/5bCmLMGE26 once again. I wish I could do the same for other sites.",
  "id" : 531894032444563456,
  "created_at" : "2014-11-10 19:39:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 0, 15 ],
      "id_str" : "155998525",
      "id" : 155998525
    }, {
      "name" : "Billy Sandora-Nastyn",
      "screen_name" : "BillybobN",
      "indices" : [ 16, 26 ],
      "id_str" : "97221495",
      "id" : 97221495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531884996404195328",
  "geo" : { },
  "id_str" : "531889343443398656",
  "in_reply_to_user_id" : 155998525,
  "text" : "@1ofyourmeteors @BillybobN I'm convinced these are an elaborate troll on the business world. Which is an actual direction.",
  "id" : 531889343443398656,
  "in_reply_to_status_id" : 531884996404195328,
  "created_at" : "2014-11-10 19:21:16 +0000",
  "in_reply_to_screen_name" : "1ofyourmeteors",
  "in_reply_to_user_id_str" : "155998525",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "objc.io",
      "screen_name" : "objcio",
      "indices" : [ 0, 7 ],
      "id_str" : "1416260550",
      "id" : 1416260550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/gXzszZu8Uh",
      "expanded_url" : "http:\/\/github.com\/qrush\/kidsmash",
      "display_url" : "github.com\/qrush\/kidsmash"
    } ]
  },
  "in_reply_to_status_id_str" : "531861198263058432",
  "geo" : { },
  "id_str" : "531874972617023488",
  "in_reply_to_user_id" : 1416260550,
  "text" : "@objcio is this issue still open for articles? I would love to contribute a little SpriteKit walkthrough of http:\/\/t.co\/gXzszZu8Uh",
  "id" : 531874972617023488,
  "in_reply_to_status_id" : 531861198263058432,
  "created_at" : "2014-11-10 18:24:09 +0000",
  "in_reply_to_screen_name" : "objcio",
  "in_reply_to_user_id_str" : "1416260550",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy Sandora-Nastyn",
      "screen_name" : "BillybobN",
      "indices" : [ 77, 87 ],
      "id_str" : "97221495",
      "id" : 97221495
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/531868706771439616\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/k0X8A9NSWF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2GTxLqCQAEinmO.jpg",
      "id_str" : "531868704158400513",
      "id" : 531868704158400513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2GTxLqCQAEinmO.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/k0X8A9NSWF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531868706771439616",
  "text" : "AV\u2019s new art direction is one without titles. Or a title. Or a direction. Cc @BillybobN http:\/\/t.co\/k0X8A9NSWF",
  "id" : 531868706771439616,
  "created_at" : "2014-11-10 17:59:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u277A\u27A0 David Copeland",
      "screen_name" : "davetron5000",
      "indices" : [ 0, 13 ],
      "id_str" : "5660222",
      "id" : 5660222
    }, {
      "name" : "iRoller",
      "screen_name" : "iroller",
      "indices" : [ 14, 22 ],
      "id_str" : "185605018",
      "id" : 185605018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531830724039831552",
  "geo" : { },
  "id_str" : "531864812092129281",
  "in_reply_to_user_id" : 5660222,
  "text" : "@davetron5000 @iroller has been playing with Lita, seems to be pretty good?",
  "id" : 531864812092129281,
  "in_reply_to_status_id" : 531830724039831552,
  "created_at" : "2014-11-10 17:43:47 +0000",
  "in_reply_to_screen_name" : "davetron5000",
  "in_reply_to_user_id_str" : "5660222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531843810217955329",
  "geo" : { },
  "id_str" : "531844188275347457",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove when is your fanfic coming out?",
  "id" : 531844188275347457,
  "in_reply_to_status_id" : 531843810217955329,
  "created_at" : "2014-11-10 16:21:50 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M-A",
      "screen_name" : "MileHighMusik",
      "indices" : [ 0, 14 ],
      "id_str" : "184501661",
      "id" : 184501661
    }, {
      "name" : "Prince Hakeem",
      "screen_name" : "iDont_WorkHere",
      "indices" : [ 15, 30 ],
      "id_str" : "256645800",
      "id" : 256645800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/2zsxFShGWp",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=CIjXUg1s5gc",
      "display_url" : "youtube.com\/watch?v=CIjXUg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "531841042677784576",
  "geo" : { },
  "id_str" : "531843085932568576",
  "in_reply_to_user_id" : 184501661,
  "text" : "@MileHighMusik @iDont_WorkHere did you see https:\/\/t.co\/2zsxFShGWp ? holy shit.",
  "id" : 531843085932568576,
  "in_reply_to_status_id" : 531841042677784576,
  "created_at" : "2014-11-10 16:17:27 +0000",
  "in_reply_to_screen_name" : "MileHighMusik",
  "in_reply_to_user_id_str" : "184501661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/Tz9q52W2zf",
      "expanded_url" : "http:\/\/shorttermmemoryloss.com\/nor\/2014\/11\/07\/all-cameras-are-police-cameras\/",
      "display_url" : "shorttermmemoryloss.com\/nor\/2014\/11\/07\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531808116158267395",
  "text" : "A terrifying vision of the surveillance state: http:\/\/t.co\/Tz9q52W2zf",
  "id" : 531808116158267395,
  "created_at" : "2014-11-10 13:58:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "indices" : [ 0, 13 ],
      "id_str" : "29200620",
      "id" : 29200620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531640918060060672",
  "geo" : { },
  "id_str" : "531645745682604033",
  "in_reply_to_user_id" : 29200620,
  "text" : "@TheOtherZach Your academic language is probably accidentally nostalgic. Learn something that is *ridiculous*\n\nAPL\nJ\nFALSE\nWhitespace",
  "id" : 531645745682604033,
  "in_reply_to_status_id" : 531640918060060672,
  "created_at" : "2014-11-10 03:13:17 +0000",
  "in_reply_to_screen_name" : "TheOtherZach",
  "in_reply_to_user_id_str" : "29200620",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531642664907591682",
  "text" : "Ottawa and Montreal are closer to Buffalo than Boston is. Why hasn't anyone told me this before?",
  "id" : 531642664907591682,
  "created_at" : "2014-11-10 03:01:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 0, 12 ],
      "id_str" : "19627341",
      "id" : 19627341
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 13, 24 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531625749468282881",
  "geo" : { },
  "id_str" : "531626114628612096",
  "in_reply_to_user_id" : 19627341,
  "text" : "@dwradcliffe @samkottler cool. Let me know if I can help at all",
  "id" : 531626114628612096,
  "in_reply_to_status_id" : 531625749468282881,
  "created_at" : "2014-11-10 01:55:17 +0000",
  "in_reply_to_screen_name" : "dwradcliffe",
  "in_reply_to_user_id_str" : "19627341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham McIntire",
      "screen_name" : "gmcintire",
      "indices" : [ 3, 13 ],
      "id_str" : "642713",
      "id" : 642713
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 15, 21 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/gmcintire\/status\/531625799670312962\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/rxvF6OnCqu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2C22OdCYAEc23d.png",
      "id_str" : "531625798738796545",
      "id" : 531625798738796545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2C22OdCYAEc23d.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rxvF6OnCqu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531625891671986176",
  "text" : "RT @gmcintire: @qrush http:\/\/t.co\/rxvF6OnCqu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/gmcintire\/status\/531625799670312962\/photo\/1",
        "indices" : [ 7, 29 ],
        "url" : "http:\/\/t.co\/rxvF6OnCqu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2C22OdCYAEc23d.png",
        "id_str" : "531625798738796545",
        "id" : 531625798738796545,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2C22OdCYAEc23d.png",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/rxvF6OnCqu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "531507698164957184",
    "geo" : { },
    "id_str" : "531625799670312962",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush http:\/\/t.co\/rxvF6OnCqu",
    "id" : 531625799670312962,
    "in_reply_to_status_id" : 531507698164957184,
    "created_at" : "2014-11-10 01:54:02 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Graham McIntire",
      "screen_name" : "gmcintire",
      "protected" : false,
      "id_str" : "642713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477130364175933440\/4YsRI83Y_normal.jpeg",
      "id" : 642713,
      "verified" : false
    }
  },
  "id" : 531625891671986176,
  "created_at" : "2014-11-10 01:54:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Knoer",
      "screen_name" : "kknoer",
      "indices" : [ 0, 7 ],
      "id_str" : "28633363",
      "id" : 28633363
    }, {
      "name" : "Matt Stauffer",
      "screen_name" : "stauffermatt",
      "indices" : [ 8, 21 ],
      "id_str" : "14280918",
      "id" : 14280918
    }, {
      "name" : "Taylor Otwell",
      "screen_name" : "taylorotwell",
      "indices" : [ 22, 35 ],
      "id_str" : "28870687",
      "id" : 28870687
    }, {
      "name" : "Ian Landsman",
      "screen_name" : "ianlandsman",
      "indices" : [ 36, 48 ],
      "id_str" : "1383161",
      "id" : 1383161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531422682194403328",
  "geo" : { },
  "id_str" : "531625848462262272",
  "in_reply_to_user_id" : 28633363,
  "text" : "@kknoer @stauffermatt @taylorotwell @ianlandsman you\u2019re too kind, 4 other partners help run the space. Come on by sometime!",
  "id" : 531625848462262272,
  "in_reply_to_status_id" : 531422682194403328,
  "created_at" : "2014-11-10 01:54:14 +0000",
  "in_reply_to_screen_name" : "kknoer",
  "in_reply_to_user_id_str" : "28633363",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 0, 7 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 8, 20 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531625168150339584",
  "geo" : { },
  "id_str" : "531625534904479744",
  "in_reply_to_user_id" : 15317640,
  "text" : "@hone02 @dwradcliffe FWIW my inbox is full of pingdom\/pager duty, and it\u2019s happening daily. Any ideas?",
  "id" : 531625534904479744,
  "in_reply_to_status_id" : 531625168150339584,
  "created_at" : "2014-11-10 01:52:59 +0000",
  "in_reply_to_screen_name" : "hone02",
  "in_reply_to_user_id_str" : "15317640",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Cruz",
      "screen_name" : "mraaroncruz",
      "indices" : [ 0, 12 ],
      "id_str" : "66482772",
      "id" : 66482772
    }, {
      "name" : "Christoph Olszowka",
      "screen_name" : "TheDeadSerious",
      "indices" : [ 13, 28 ],
      "id_str" : "6151392",
      "id" : 6151392
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 39, 47 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 48, 57 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 58, 65 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 66, 78 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531534489944858625",
  "geo" : { },
  "id_str" : "531545761612177408",
  "in_reply_to_user_id" : 66482772,
  "text" : "@mraaroncruz @TheDeadSerious yipes! cc @evanphx @indirect @hone02 @dwradcliffe",
  "id" : 531545761612177408,
  "in_reply_to_status_id" : 531534489944858625,
  "created_at" : "2014-11-09 20:35:59 +0000",
  "in_reply_to_screen_name" : "mraaroncruz",
  "in_reply_to_user_id_str" : "66482772",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Olszowka",
      "screen_name" : "TheDeadSerious",
      "indices" : [ 0, 15 ],
      "id_str" : "6151392",
      "id" : 6151392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531526276755226628",
  "geo" : { },
  "id_str" : "531526531353284608",
  "in_reply_to_user_id" : 6151392,
  "text" : "@TheDeadSerious looks up here",
  "id" : 531526531353284608,
  "in_reply_to_status_id" : 531526276755226628,
  "created_at" : "2014-11-09 19:19:35 +0000",
  "in_reply_to_screen_name" : "TheDeadSerious",
  "in_reply_to_user_id_str" : "6151392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Dowell",
      "screen_name" : "CerebroJD",
      "indices" : [ 0, 10 ],
      "id_str" : "5744302",
      "id" : 5744302
    }, {
      "name" : "Alicia",
      "screen_name" : "aliciamc",
      "indices" : [ 11, 20 ],
      "id_str" : "15828171",
      "id" : 15828171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531515081171800064",
  "geo" : { },
  "id_str" : "531517619921121280",
  "in_reply_to_user_id" : 5744302,
  "text" : "@CerebroJD @aliciamc congrats!! \uD83D\uDC4D\uD83D\uDCA5\uD83D\uDC8D",
  "id" : 531517619921121280,
  "in_reply_to_status_id" : 531515081171800064,
  "created_at" : "2014-11-09 18:44:10 +0000",
  "in_reply_to_screen_name" : "CerebroJD",
  "in_reply_to_user_id_str" : "5744302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/531507698164957184\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/WHbzMXv7Sr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2BLbvBCUAAd9AX.png",
      "id_str" : "531507695879081984",
      "id" : 531507695879081984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2BLbvBCUAAd9AX.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/WHbzMXv7Sr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531507698164957184",
  "text" : "I can\u2019t even http:\/\/t.co\/WHbzMXv7Sr",
  "id" : 531507698164957184,
  "created_at" : "2014-11-09 18:04:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Bray",
      "screen_name" : "timbray",
      "indices" : [ 3, 11 ],
      "id_str" : "1235521",
      "id" : 1235521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531428039712727040",
  "text" : "RT @timbray: The instant Kathy Sierra\u2019s serious pony account expired, somebody grabbed it for abusive purposes. It\u2019s about ethics in game j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531203293687848960",
    "text" : "The instant Kathy Sierra\u2019s serious pony account expired, somebody grabbed it for abusive purposes. It\u2019s about ethics in game journalism.",
    "id" : 531203293687848960,
    "created_at" : "2014-11-08 21:55:09 +0000",
    "user" : {
      "name" : "Tim Bray",
      "screen_name" : "timbray",
      "protected" : false,
      "id_str" : "1235521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421637246\/Tim_normal.jpg",
      "id" : 1235521,
      "verified" : false
    }
  },
  "id" : 531428039712727040,
  "created_at" : "2014-11-09 12:48:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531427928601415681",
  "text" : "Please report Serious Pony\u2019s account as spam\/abusive. I am really starting to hate Twitter as a platform for anything. The hate is too much.",
  "id" : 531427928601415681,
  "created_at" : "2014-11-09 12:47:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    }, {
      "name" : "danielle",
      "screen_name" : "duh_nellll",
      "indices" : [ 14, 25 ],
      "id_str" : "146513248",
      "id" : 146513248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531230299649507328",
  "geo" : { },
  "id_str" : "531230695184928768",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer @duh_nellll I had ranch with wings last night because I forgot to pick up blue cheese. I am still ashamed",
  "id" : 531230695184928768,
  "in_reply_to_status_id" : 531230299649507328,
  "created_at" : "2014-11-08 23:44:02 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531138515992469506",
  "text" : "Why didn't anyone tell me there's an Octodad update?!",
  "id" : 531138515992469506,
  "created_at" : "2014-11-08 17:37:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Norman Wilson",
      "screen_name" : "oclsc",
      "indices" : [ 0, 6 ],
      "id_str" : "38055290",
      "id" : 38055290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531068183629688833",
  "geo" : { },
  "id_str" : "531069426473238529",
  "in_reply_to_user_id" : 38055290,
  "text" : "@oclsc sadly this is what always happens. The train is always late. If they put the actual arrival time no one buys tickets",
  "id" : 531069426473238529,
  "in_reply_to_status_id" : 531068183629688833,
  "created_at" : "2014-11-08 13:03:12 +0000",
  "in_reply_to_screen_name" : "oclsc",
  "in_reply_to_user_id_str" : "38055290",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530959885383372800",
  "text" : "Snowpiercer was an awful film. I will never get that time back.",
  "id" : 530959885383372800,
  "created_at" : "2014-11-08 05:47:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530889735783186433",
  "text" : "LINKS WORK IN DMs!!!! I AM SHOUTING BECAUSE TWITTER FIXED SOMETHING! LOUD NOISES! CHAOS!",
  "id" : 530889735783186433,
  "created_at" : "2014-11-08 01:09:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530888431610908673",
  "geo" : { },
  "id_str" : "530888496806780928",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej yes! Will invite.",
  "id" : 530888496806780928,
  "in_reply_to_status_id" : 530888431610908673,
  "created_at" : "2014-11-08 01:04:15 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530887922145558528",
  "geo" : { },
  "id_str" : "530888172658384896",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej I know this feel. Lightroom helps.",
  "id" : 530888172658384896,
  "in_reply_to_status_id" : 530887922145558528,
  "created_at" : "2014-11-08 01:02:58 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530855218192588801",
  "geo" : { },
  "id_str" : "530856490244898816",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant too many cooks!",
  "id" : 530856490244898816,
  "in_reply_to_status_id" : 530855218192588801,
  "created_at" : "2014-11-07 22:57:04 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/a0RzGLT0aQ",
      "expanded_url" : "http:\/\/replayapp.com",
      "display_url" : "replayapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "530798685576507392",
  "text" : "I can't stress enough how great Replay is. Toss together a bunch of videos\/photos and you have a semipro looking cut. http:\/\/t.co\/a0RzGLT0aQ",
  "id" : 530798685576507392,
  "created_at" : "2014-11-07 19:07:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 0, 8 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530797181033537536",
  "geo" : { },
  "id_str" : "530797319076446208",
  "in_reply_to_user_id" : 20844341,
  "text" : "@patio11 funny how things change. cool.",
  "id" : 530797319076446208,
  "in_reply_to_status_id" : 530797181033537536,
  "created_at" : "2014-11-07 19:01:57 +0000",
  "in_reply_to_screen_name" : "patio11",
  "in_reply_to_user_id_str" : "20844341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 0, 8 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530796638353498112",
  "geo" : { },
  "id_str" : "530796767038935041",
  "in_reply_to_user_id" : 20844341,
  "text" : "@patio11 I meant to Japan :)",
  "id" : 530796767038935041,
  "in_reply_to_status_id" : 530796638353498112,
  "created_at" : "2014-11-07 18:59:45 +0000",
  "in_reply_to_screen_name" : "patio11",
  "in_reply_to_user_id_str" : "20844341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/KE5zdwCoN8",
      "expanded_url" : "http:\/\/www.kalzumeus.com\/2014\/11\/07\/doing-business-in-japan\/",
      "display_url" : "kalzumeus.com\/2014\/11\/07\/doi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530793802890371073",
  "text" : "Culture shock doesn't even cover this: http:\/\/t.co\/KE5zdwCoN8",
  "id" : 530793802890371073,
  "created_at" : "2014-11-07 18:47:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 0, 8 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530790632457908224",
  "geo" : { },
  "id_str" : "530792601310351361",
  "in_reply_to_user_id" : 20844341,
  "text" : "@patio11 wow. maybe a different article, but why did you move?",
  "id" : 530792601310351361,
  "in_reply_to_status_id" : 530790632457908224,
  "created_at" : "2014-11-07 18:43:12 +0000",
  "in_reply_to_screen_name" : "patio11",
  "in_reply_to_user_id_str" : "20844341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530782086882656256",
  "geo" : { },
  "id_str" : "530782161607999488",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy whaaat",
  "id" : 530782161607999488,
  "in_reply_to_status_id" : 530782086882656256,
  "created_at" : "2014-11-07 18:01:43 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    }, {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 9, 16 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530775728065748992",
  "geo" : { },
  "id_str" : "530779980762869761",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale @wycats why is there anything?",
  "id" : 530779980762869761,
  "in_reply_to_status_id" : 530775728065748992,
  "created_at" : "2014-11-07 17:53:03 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 0, 9 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/H4NfXOKbdV",
      "expanded_url" : "http:\/\/i.imgur.com\/TzEUSHs.jpg?fb",
      "display_url" : "i.imgur.com\/TzEUSHs.jpg?fb"
    } ]
  },
  "in_reply_to_status_id_str" : "530766131573706752",
  "geo" : { },
  "id_str" : "530766435010629632",
  "in_reply_to_user_id" : 15946976,
  "text" : "@tinybaby http:\/\/t.co\/H4NfXOKbdV",
  "id" : 530766435010629632,
  "in_reply_to_status_id" : 530766131573706752,
  "created_at" : "2014-11-07 16:59:13 +0000",
  "in_reply_to_screen_name" : "tinybaby",
  "in_reply_to_user_id_str" : "15946976",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P \u014D T \u014D",
      "screen_name" : "Pote",
      "indices" : [ 10, 15 ],
      "id_str" : "2890371",
      "id" : 2890371
    }, {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 16, 24 ],
      "id_str" : "9337082",
      "id" : 9337082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/MegVOKFnCx",
      "expanded_url" : "http:\/\/sriracha2go.com\/",
      "display_url" : "sriracha2go.com"
    } ]
  },
  "geo" : { },
  "id_str" : "530751964540567552",
  "text" : "Attention @pote @godfoca http:\/\/t.co\/MegVOKFnCx",
  "id" : 530751964540567552,
  "created_at" : "2014-11-07 16:01:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530747961140322304",
  "geo" : { },
  "id_str" : "530748072414806017",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold Snowing here too. :S",
  "id" : 530748072414806017,
  "in_reply_to_status_id" : 530747961140322304,
  "created_at" : "2014-11-07 15:46:15 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Bortch",
      "screen_name" : "buenothebear",
      "indices" : [ 3, 16 ],
      "id_str" : "15472368",
      "id" : 15472368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/F7HcuH84u5",
      "expanded_url" : "http:\/\/youtu.be\/KNs9shgQ2rI",
      "display_url" : "youtu.be\/KNs9shgQ2rI"
    } ]
  },
  "geo" : { },
  "id_str" : "530577296340824064",
  "text" : "RT @buenothebear: Bee and Puppycat is out!  http:\/\/t.co\/F7HcuH84u5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/F7HcuH84u5",
        "expanded_url" : "http:\/\/youtu.be\/KNs9shgQ2rI",
        "display_url" : "youtu.be\/KNs9shgQ2rI"
      } ]
    },
    "geo" : { },
    "id_str" : "530575024038903808",
    "text" : "Bee and Puppycat is out!  http:\/\/t.co\/F7HcuH84u5",
    "id" : 530575024038903808,
    "created_at" : "2014-11-07 04:18:38 +0000",
    "user" : {
      "name" : "George Bortch",
      "screen_name" : "buenothebear",
      "protected" : false,
      "id_str" : "15472368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573681833126162433\/DLtpJZcT_normal.jpeg",
      "id" : 15472368,
      "verified" : false
    }
  },
  "id" : 530577296340824064,
  "created_at" : "2014-11-07 04:27:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530565251566403586",
  "geo" : { },
  "id_str" : "530565530621865984",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam any Google search for red pill has this awful shit in it. Even with buffet. Try with MRA for extra awful",
  "id" : 530565530621865984,
  "in_reply_to_status_id" : 530565251566403586,
  "created_at" : "2014-11-07 03:40:54 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530564552950562816",
  "geo" : { },
  "id_str" : "530564671691309056",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam me either. Change the title?",
  "id" : 530564671691309056,
  "in_reply_to_status_id" : 530564552950562816,
  "created_at" : "2014-11-07 03:37:29 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530564143875907584",
  "geo" : { },
  "id_str" : "530564357537939456",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam I hate to break it to you but \u201Cred pill\u201D is a huge MRA term. Take a look on reddit for this",
  "id" : 530564357537939456,
  "in_reply_to_status_id" : 530564143875907584,
  "created_at" : "2014-11-07 03:36:14 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 0, 9 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530518593256308738",
  "geo" : { },
  "id_str" : "530518861125529600",
  "in_reply_to_user_id" : 15946976,
  "text" : "@tinybaby it\u2019s like Vine in one sheet of paper",
  "id" : 530518861125529600,
  "in_reply_to_status_id" : 530518593256308738,
  "created_at" : "2014-11-07 00:35:27 +0000",
  "in_reply_to_screen_name" : "tinybaby",
  "in_reply_to_user_id_str" : "15946976",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530502180785381377",
  "text" : "\u03B5=\u03B5=\u03B5=\u03B5=\u03B5=\u03B5=\u250C(;\uFFE3\u25C7\uFFE3)\u2518",
  "id" : 530502180785381377,
  "created_at" : "2014-11-06 23:29:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat McDermott",
      "screen_name" : "nerdofthunder",
      "indices" : [ 0, 14 ],
      "id_str" : "14457987",
      "id" : 14457987
    }, {
      "name" : "Penguinoh",
      "screen_name" : "jettingpenguin",
      "indices" : [ 15, 30 ],
      "id_str" : "186310759",
      "id" : 186310759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530469728163471362",
  "in_reply_to_user_id" : 14457987,
  "text" : "@nerdofthunder @jettingpenguin any response to this sir?",
  "id" : 530469728163471362,
  "created_at" : "2014-11-06 21:20:13 +0000",
  "in_reply_to_screen_name" : "nerdofthunder",
  "in_reply_to_user_id_str" : "14457987",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "triflin brand indeed",
      "screen_name" : "vogon",
      "indices" : [ 3, 9 ],
      "id_str" : "6326912",
      "id" : 6326912
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vogon\/status\/530462603320250369\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/gwNavgcNYC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1yU7RIIUAAi1r6.png",
      "id_str" : "530462602053570560",
      "id" : 530462602053570560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1yU7RIIUAAi1r6.png",
      "sizes" : [ {
        "h" : 308,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 175,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gwNavgcNYC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530464524709933056",
  "text" : "RT @vogon: *bites his knuckle, desperately trying to resist the urge to crack up in the office* http:\/\/t.co\/gwNavgcNYC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vogon\/status\/530462603320250369\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/gwNavgcNYC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1yU7RIIUAAi1r6.png",
        "id_str" : "530462602053570560",
        "id" : 530462602053570560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1yU7RIIUAAi1r6.png",
        "sizes" : [ {
          "h" : 308,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 676
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 676
        }, {
          "h" : 175,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/gwNavgcNYC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "530462603320250369",
    "text" : "*bites his knuckle, desperately trying to resist the urge to crack up in the office* http:\/\/t.co\/gwNavgcNYC",
    "id" : 530462603320250369,
    "created_at" : "2014-11-06 20:51:54 +0000",
    "user" : {
      "name" : "triflin brand indeed",
      "screen_name" : "vogon",
      "protected" : false,
      "id_str" : "6326912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558124800065806336\/lQmUONLf_normal.png",
      "id" : 6326912,
      "verified" : false
    }
  },
  "id" : 530464524709933056,
  "created_at" : "2014-11-06 20:59:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tow truck central",
      "screen_name" : "duh_nellll",
      "indices" : [ 0, 11 ],
      "id_str" : "146513248",
      "id" : 146513248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530459237571629057",
  "geo" : { },
  "id_str" : "530459285952946179",
  "in_reply_to_user_id" : 146513248,
  "text" : "@duh_nellll Find one!",
  "id" : 530459285952946179,
  "in_reply_to_status_id" : 530459237571629057,
  "created_at" : "2014-11-06 20:38:43 +0000",
  "in_reply_to_screen_name" : "duh_nellll",
  "in_reply_to_user_id_str" : "146513248",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530458962093953025",
  "text" : "(What other band has fans making stat charts\/spreadsheets of songs played?)",
  "id" : 530458962093953025,
  "created_at" : "2014-11-06 20:37:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 3, 14 ],
      "id_str" : "247090698",
      "id" : 247090698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Phish",
      "indices" : [ 20, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/E6DcNVR6rZ",
      "expanded_url" : "http:\/\/bit.ly\/Ms55J7",
      "display_url" : "bit.ly\/Ms55J7"
    } ]
  },
  "geo" : { },
  "id_str" : "530458837137227776",
  "text" : "RT @bizarchive: The #Phish Song Total \/ Bustout chart has been updated through the end of fall 2014: http:\/\/t.co\/E6DcNVR6rZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Phish",
        "indices" : [ 4, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/E6DcNVR6rZ",
        "expanded_url" : "http:\/\/bit.ly\/Ms55J7",
        "display_url" : "bit.ly\/Ms55J7"
      } ]
    },
    "geo" : { },
    "id_str" : "530406484044423168",
    "text" : "The #Phish Song Total \/ Bustout chart has been updated through the end of fall 2014: http:\/\/t.co\/E6DcNVR6rZ",
    "id" : 530406484044423168,
    "created_at" : "2014-11-06 17:08:54 +0000",
    "user" : {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "protected" : false,
      "id_str" : "247090698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547876491015774208\/yVt9TX1t_normal.jpeg",
      "id" : 247090698,
      "verified" : false
    }
  },
  "id" : 530458837137227776,
  "created_at" : "2014-11-06 20:36:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530390320169910272",
  "geo" : { },
  "id_str" : "530391450605735936",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 as for your magical parking spot, i have no idea. but i haven't seen any trouble here",
  "id" : 530391450605735936,
  "in_reply_to_status_id" : 530390320169910272,
  "created_at" : "2014-11-06 16:09:10 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530389677379825664",
  "geo" : { },
  "id_str" : "530390121204301825",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 nope",
  "id" : 530390121204301825,
  "in_reply_to_status_id" : 530389677379825664,
  "created_at" : "2014-11-06 16:03:53 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 3, 14 ],
      "id_str" : "14620776",
      "id" : 14620776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/ynUiId0ngh",
      "expanded_url" : "http:\/\/www.thebaffler.com\/salvos\/dads-tech",
      "display_url" : "thebaffler.com\/salvos\/dads-te\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530387736364974080",
  "text" : "RT @ellenchisa: Best thing I've ever read on gender\/tech: http:\/\/t.co\/ynUiId0ngh (seriously: they literally processed my own experiences be\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/ynUiId0ngh",
        "expanded_url" : "http:\/\/www.thebaffler.com\/salvos\/dads-tech",
        "display_url" : "thebaffler.com\/salvos\/dads-te\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "530098229564936194",
    "text" : "Best thing I've ever read on gender\/tech: http:\/\/t.co\/ynUiId0ngh (seriously: they literally processed my own experiences better than I did).",
    "id" : 530098229564936194,
    "created_at" : "2014-11-05 20:44:01 +0000",
    "user" : {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "protected" : false,
      "id_str" : "14620776",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468872839676698624\/Q9jgyAa0_normal.jpeg",
      "id" : 14620776,
      "verified" : false
    }
  },
  "id" : 530387736364974080,
  "created_at" : "2014-11-06 15:54:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 14, 27 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530383952226160640",
  "geo" : { },
  "id_str" : "530385519553687553",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda @steveklabnik doing more iOS has definitely changed my perspective a lot. it feels more \"real\" since you can touch it",
  "id" : 530385519553687553,
  "in_reply_to_status_id" : 530383952226160640,
  "created_at" : "2014-11-06 15:45:36 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#techismaterial",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530383057253986304",
  "geo" : { },
  "id_str" : "530383716598550529",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik who cares about this, someone is still working on nethack!!!!!!!??!!",
  "id" : 530383716598550529,
  "in_reply_to_status_id" : 530383057253986304,
  "created_at" : "2014-11-06 15:38:26 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 51, 63 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/1JCQ184S8w",
      "expanded_url" : "http:\/\/aqueousband.com\/shows\/2014-11-01",
      "display_url" : "aqueousband.com\/shows\/2014-11-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530382118665191424",
  "text" : "Need some music for today? Here's 70+ minutes from @AqueousBand. Put it on and get shit done. http:\/\/t.co\/1JCQ184S8w",
  "id" : 530382118665191424,
  "created_at" : "2014-11-06 15:32:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 51, 66 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/o9CX91RXb1",
      "expanded_url" : "http:\/\/instagram.com\/p\/vEAWGZMOTz\/",
      "display_url" : "instagram.com\/p\/vEAWGZMOTz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "530376543579541504",
  "text" : "RT @coworkbuffalo: Welcome to the neighborhood! MT @PublicEspresso: Set up for inaugural Indoor Winter Market at Washington Market! http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PublicEspresso",
        "screen_name" : "PublicEspresso",
        "indices" : [ 32, 47 ],
        "id_str" : "1472209542",
        "id" : 1472209542
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/o9CX91RXb1",
        "expanded_url" : "http:\/\/instagram.com\/p\/vEAWGZMOTz\/",
        "display_url" : "instagram.com\/p\/vEAWGZMOTz\/"
      } ]
    },
    "geo" : { },
    "id_str" : "530375398958596096",
    "text" : "Welcome to the neighborhood! MT @PublicEspresso: Set up for inaugural Indoor Winter Market at Washington Market! http:\/\/t.co\/o9CX91RXb1",
    "id" : 530375398958596096,
    "created_at" : "2014-11-06 15:05:23 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 530376543579541504,
  "created_at" : "2014-11-06 15:09:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "benjamin dilzraeli",
      "screen_name" : "adventuresofrob",
      "indices" : [ 3, 19 ],
      "id_str" : "195938284",
      "id" : 195938284
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/adventuresofrob\/status\/530346214437691392\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/TuMoSOlJwN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1wrEkOCUAA41nF.jpg",
      "id_str" : "530346213564895232",
      "id" : 530346213564895232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1wrEkOCUAA41nF.jpg",
      "sizes" : [ {
        "h" : 224,
        "resize" : "fit",
        "w" : 419
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 419
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 419
      } ],
      "display_url" : "pic.twitter.com\/TuMoSOlJwN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530361556576399362",
  "text" : "RT @adventuresofrob: Kind of amazing that the message of this ad isn't \"these vehicles are unsafe for urban streets\" but \"watch your back\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/adventuresofrob\/status\/530346214437691392\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/TuMoSOlJwN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1wrEkOCUAA41nF.jpg",
        "id_str" : "530346213564895232",
        "id" : 530346213564895232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1wrEkOCUAA41nF.jpg",
        "sizes" : [ {
          "h" : 224,
          "resize" : "fit",
          "w" : 419
        }, {
          "h" : 181,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 419
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 419
        } ],
        "display_url" : "pic.twitter.com\/TuMoSOlJwN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "530346214437691392",
    "text" : "Kind of amazing that the message of this ad isn't \"these vehicles are unsafe for urban streets\" but \"watch your back\" http:\/\/t.co\/TuMoSOlJwN",
    "id" : 530346214437691392,
    "created_at" : "2014-11-06 13:09:25 +0000",
    "user" : {
      "name" : "benjamin dilzraeli",
      "screen_name" : "adventuresofrob",
      "protected" : false,
      "id_str" : "195938284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2066828892\/oie_31025293QMIVKJH_normal.gif",
      "id" : 195938284,
      "verified" : false
    }
  },
  "id" : 530361556576399362,
  "created_at" : "2014-11-06 14:10:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530338503503003648",
  "geo" : { },
  "id_str" : "530343783238336513",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer the door creak could go.",
  "id" : 530343783238336513,
  "in_reply_to_status_id" : 530338503503003648,
  "created_at" : "2014-11-06 12:59:45 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "indices" : [ 3, 16 ],
      "id_str" : "29200620",
      "id" : 29200620
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 18, 24 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "The Atlantic",
      "screen_name" : "TheAtlantic",
      "indices" : [ 31, 43 ],
      "id_str" : "35773039",
      "id" : 35773039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530336616250757120",
  "text" : "RT @TheOtherZach: @qrush Isn't @TheAtlantic one of those sites that prints out the things they write?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "The Atlantic",
        "screen_name" : "TheAtlantic",
        "indices" : [ 13, 25 ],
        "id_str" : "35773039",
        "id" : 35773039
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "530329494846832641",
    "geo" : { },
    "id_str" : "530336511972352001",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush Isn't @TheAtlantic one of those sites that prints out the things they write?",
    "id" : 530336511972352001,
    "in_reply_to_status_id" : 530329494846832641,
    "created_at" : "2014-11-06 12:30:52 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "protected" : false,
      "id_str" : "29200620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427580633745854465\/Oo8wowKC_normal.png",
      "id" : 29200620,
      "verified" : false
    }
  },
  "id" : 530336616250757120,
  "created_at" : "2014-11-06 12:31:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Dave Stukus",
      "screen_name" : "AllergyKidsDoc",
      "indices" : [ 3, 18 ],
      "id_str" : "1371044154",
      "id" : 1371044154
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 54, 60 ]
    }, {
      "text" : "flushot",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530333490139512834",
  "text" : "RT @AllergyKidsDoc: Actual discussion:\nParent \"I want #Ebola vaccine for my child\"\nDoc \"There isn't one, but we have #flushot\"\nParent \"We d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 34, 40 ]
      }, {
        "text" : "flushot",
        "indices" : [ 97, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "529665665045893120",
    "text" : "Actual discussion:\nParent \"I want #Ebola vaccine for my child\"\nDoc \"There isn't one, but we have #flushot\"\nParent \"We don't believe in that\"",
    "id" : 529665665045893120,
    "created_at" : "2014-11-04 16:05:09 +0000",
    "user" : {
      "name" : "Dr. Dave Stukus",
      "screen_name" : "AllergyKidsDoc",
      "protected" : false,
      "id_str" : "1371044154",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447794787786047488\/rJURLoNG_normal.jpeg",
      "id" : 1371044154,
      "verified" : false
    }
  },
  "id" : 530333490139512834,
  "created_at" : "2014-11-06 12:18:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530333307632754688",
  "text" : "Actually that article is from 2012 but I don\u2019t feel the \u201CMillenial\u201D discussion has progressed any.",
  "id" : 530333307632754688,
  "created_at" : "2014-11-06 12:18:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/ExXBIaVHQm",
      "expanded_url" : "http:\/\/m.theatlantic.com\/magazine\/archive\/2012\/09\/the-cheapest-generation\/309060\/2\/",
      "display_url" : "m.theatlantic.com\/magazine\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530329494846832641",
  "text" : "Today in \u201Cwho understands these damn kids!?\u201D I can\u2019t wait until they try to figure out the next generation http:\/\/t.co\/ExXBIaVHQm",
  "id" : 530329494846832641,
  "created_at" : "2014-11-06 12:02:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 0, 7 ],
      "id_str" : "9038902",
      "id" : 9038902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530192884314562564",
  "geo" : { },
  "id_str" : "530192999628546049",
  "in_reply_to_user_id" : 9038902,
  "text" : "@searls Yup.",
  "id" : 530192999628546049,
  "in_reply_to_status_id" : 530192884314562564,
  "created_at" : "2014-11-06 03:00:36 +0000",
  "in_reply_to_screen_name" : "searls",
  "in_reply_to_user_id_str" : "9038902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/hx3qXRuAz4",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/m\/pubmed\/2299306\/",
      "display_url" : "ncbi.nlm.nih.gov\/m\/pubmed\/22993\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530192619507163138",
  "text" : "Today in \"don't click any links your med student brother sends you\" http:\/\/t.co\/hx3qXRuAz4",
  "id" : 530192619507163138,
  "created_at" : "2014-11-06 02:59:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 29, 37 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530189762615705600",
  "text" : "RT @bquarant: Oh my goodness @twitter moved the box where you type. Everybody freak out",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 15, 23 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "530187909647724546",
    "text" : "Oh my goodness @twitter moved the box where you type. Everybody freak out",
    "id" : 530187909647724546,
    "created_at" : "2014-11-06 02:40:22 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 530189762615705600,
  "created_at" : "2014-11-06 02:47:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u1D48\u02B3\u1D43\u1D4F\u1D4F\u02B0\u1D49\u207F",
      "screen_name" : "drakkhen",
      "indices" : [ 70, 79 ],
      "id_str" : "18176030",
      "id" : 18176030
    }, {
      "name" : "Danimal\/Armcannon",
      "screen_name" : "armcannon",
      "indices" : [ 86, 96 ],
      "id_str" : "86775045",
      "id" : 86775045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/HVAxBI0zcv",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=rtR63-ecUNo",
      "display_url" : "youtube.com\/watch?v=rtR63-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530183249788538881",
  "text" : "*Mind explodes into thousands of pieces* https:\/\/t.co\/HVAxBI0zcv (via @drakkhen, ping @armcannon)",
  "id" : 530183249788538881,
  "created_at" : "2014-11-06 02:21:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Letterle",
      "screen_name" : "mletterle",
      "indices" : [ 0, 10 ],
      "id_str" : "458173",
      "id" : 458173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530182314240655361",
  "geo" : { },
  "id_str" : "530182603093983233",
  "in_reply_to_user_id" : 458173,
  "text" : "@mletterle such a good reminder that (most) every band starts at the bottom. like, playing to high school kids napping bottom.",
  "id" : 530182603093983233,
  "in_reply_to_status_id" : 530182314240655361,
  "created_at" : "2014-11-06 02:19:17 +0000",
  "in_reply_to_screen_name" : "mletterle",
  "in_reply_to_user_id_str" : "458173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pote",
      "screen_name" : "poteland",
      "indices" : [ 0, 9 ],
      "id_str" : "49102992",
      "id" : 49102992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530168781050363906",
  "geo" : { },
  "id_str" : "530168937246248960",
  "in_reply_to_user_id" : 49102992,
  "text" : "@poteland I just saw a store with bottles under $3, and giant gallon containers",
  "id" : 530168937246248960,
  "in_reply_to_status_id" : 530168781050363906,
  "created_at" : "2014-11-06 01:24:59 +0000",
  "in_reply_to_screen_name" : "poteland",
  "in_reply_to_user_id_str" : "49102992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrminer",
      "screen_name" : "mrminer",
      "indices" : [ 14, 22 ],
      "id_str" : "16519576",
      "id" : 16519576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530168134318051331",
  "text" : "I really hope @mrminer is right and Miami is full of Chilling, Thrilling jams. Martian, Dogs, Birds, Shipwreck deserve to stay.",
  "id" : 530168134318051331,
  "created_at" : "2014-11-06 01:21:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530167002376048641",
  "text" : "I think it's also telling how differently the boys play when they're facing each other and communicating directly. Way more smiles.",
  "id" : 530167002376048641,
  "created_at" : "2014-11-06 01:17:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530166184818118657",
  "text" : "Can't stop replaying the Halloween set. So many fun jams in here. Such a huge risk to take.",
  "id" : 530166184818118657,
  "created_at" : "2014-11-06 01:14:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530148067761082368",
  "geo" : { },
  "id_str" : "530148623011414016",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo dang! When is your store opening?",
  "id" : 530148623011414016,
  "in_reply_to_status_id" : 530148067761082368,
  "created_at" : "2014-11-06 00:04:16 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530115312491171840",
  "geo" : { },
  "id_str" : "530119734780788736",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox swarm\u2019s is good. Have you seen ours? Any feedback?",
  "id" : 530119734780788736,
  "in_reply_to_status_id" : 530115312491171840,
  "created_at" : "2014-11-05 22:09:28 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florent Monbillard",
      "screen_name" : "fmonbillard",
      "indices" : [ 0, 12 ],
      "id_str" : "29411057",
      "id" : 29411057
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 13, 24 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530064865231400962",
  "geo" : { },
  "id_str" : "530064993010872320",
  "in_reply_to_user_id" : 29411057,
  "text" : "@fmonbillard @tenderlove Use it. Have always used it.",
  "id" : 530064993010872320,
  "in_reply_to_status_id" : 530064865231400962,
  "created_at" : "2014-11-05 18:31:57 +0000",
  "in_reply_to_screen_name" : "fmonbillard",
  "in_reply_to_user_id_str" : "29411057",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530020796232511488",
  "geo" : { },
  "id_str" : "530060003156037634",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove do you mean FileVault?",
  "id" : 530060003156037634,
  "in_reply_to_status_id" : 530020796232511488,
  "created_at" : "2014-11-05 18:12:07 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Churlish",
      "screen_name" : "Cryptoterra",
      "indices" : [ 3, 15 ],
      "id_str" : "40578249",
      "id" : 40578249
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Cryptoterra\/status\/529856729413337088\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/jq7YlO3kdt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1pt4yLIYAAX63f.jpg",
      "id_str" : "529856728478015488",
      "id" : 529856728478015488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1pt4yLIYAAX63f.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/jq7YlO3kdt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530015685364043776",
  "text" : "RT @Cryptoterra: EXCLUSIVE: First look at republican controlled senate http:\/\/t.co\/jq7YlO3kdt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Cryptoterra\/status\/529856729413337088\/photo\/1",
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/jq7YlO3kdt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1pt4yLIYAAX63f.jpg",
        "id_str" : "529856728478015488",
        "id" : 529856728478015488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1pt4yLIYAAX63f.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/jq7YlO3kdt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "529856729413337088",
    "text" : "EXCLUSIVE: First look at republican controlled senate http:\/\/t.co\/jq7YlO3kdt",
    "id" : 529856729413337088,
    "created_at" : "2014-11-05 04:44:23 +0000",
    "user" : {
      "name" : "Churlish",
      "screen_name" : "Cryptoterra",
      "protected" : false,
      "id_str" : "40578249",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3747436082\/4d176f3ea77c39c99783bfb1ab557c80_normal.gif",
      "id" : 40578249,
      "verified" : false
    }
  },
  "id" : 530015685364043776,
  "created_at" : "2014-11-05 15:16:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cohn",
      "screen_name" : "CitizenCohn",
      "indices" : [ 3, 15 ],
      "id_str" : "21634627",
      "id" : 21634627
    }, {
      "name" : "Greg Dworkin",
      "screen_name" : "DemFromCT",
      "indices" : [ 70, 80 ],
      "id_str" : "19087651",
      "id" : 19087651
    }, {
      "name" : "NBC News",
      "screen_name" : "NBCNews",
      "indices" : [ 81, 89 ],
      "id_str" : "14173315",
      "id" : 14173315
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/CitizenCohn\/status\/529994195399114753\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Wmva674ipS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1rq6XTIIAAS-U3.jpg",
      "id_str" : "529994194577006592",
      "id" : 529994194577006592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1rq6XTIIAAS-U3.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Wmva674ipS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/GIXmFajKHI",
      "expanded_url" : "http:\/\/www.newrepublic.com\/article\/120137\/midterm-election-results-republicans-rout-senate-governor-races",
      "display_url" : "newrepublic.com\/article\/120137\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530012141034545152",
  "text" : "RT @CitizenCohn: The election in one graph http:\/\/t.co\/GIXmFajKHI h\/t @DemFromCT @NBCNews http:\/\/t.co\/Wmva674ipS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Greg Dworkin",
        "screen_name" : "DemFromCT",
        "indices" : [ 53, 63 ],
        "id_str" : "19087651",
        "id" : 19087651
      }, {
        "name" : "NBC News",
        "screen_name" : "NBCNews",
        "indices" : [ 64, 72 ],
        "id_str" : "14173315",
        "id" : 14173315
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CitizenCohn\/status\/529994195399114753\/photo\/1",
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/Wmva674ipS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1rq6XTIIAAS-U3.jpg",
        "id_str" : "529994194577006592",
        "id" : 529994194577006592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1rq6XTIIAAS-U3.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/Wmva674ipS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/GIXmFajKHI",
        "expanded_url" : "http:\/\/www.newrepublic.com\/article\/120137\/midterm-election-results-republicans-rout-senate-governor-races",
        "display_url" : "newrepublic.com\/article\/120137\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529994195399114753",
    "text" : "The election in one graph http:\/\/t.co\/GIXmFajKHI h\/t @DemFromCT @NBCNews http:\/\/t.co\/Wmva674ipS",
    "id" : 529994195399114753,
    "created_at" : "2014-11-05 13:50:37 +0000",
    "user" : {
      "name" : "Jonathan Cohn",
      "screen_name" : "CitizenCohn",
      "protected" : false,
      "id_str" : "21634627",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540936766585188353\/swV7LqKm_normal.jpeg",
      "id" : 21634627,
      "verified" : true
    }
  },
  "id" : 530012141034545152,
  "created_at" : "2014-11-05 15:01:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530005548851548160",
  "geo" : { },
  "id_str" : "530011482499473408",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier doesn't look like it. What's wrong with that?",
  "id" : 530011482499473408,
  "in_reply_to_status_id" : 530005548851548160,
  "created_at" : "2014-11-05 14:59:19 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530005201940660225",
  "geo" : { },
  "id_str" : "530005409138884608",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier huh? We still use rbenv and our internal sub named 37 daily.",
  "id" : 530005409138884608,
  "in_reply_to_status_id" : 530005201940660225,
  "created_at" : "2014-11-05 14:35:11 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/We1B5vqDjs",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Dish,_Texas",
      "display_url" : "en.m.wikipedia.org\/wiki\/Dish,_Tex\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529866683737841664",
  "text" : "If the election results don\u2019t have you down, here\u2019s a town that renamed itself to get free TV service for residents https:\/\/t.co\/We1B5vqDjs",
  "id" : 529866683737841664,
  "created_at" : "2014-11-05 05:23:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529844315065823232",
  "text" : "Favorite pizza place in the city closed. SADFACE",
  "id" : 529844315065823232,
  "created_at" : "2014-11-05 03:55:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 0, 11 ],
      "id_str" : "67117740",
      "id" : 67117740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529841174412947457",
  "geo" : { },
  "id_str" : "529842357491863553",
  "in_reply_to_user_id" : 67117740,
  "text" : "@Dianna_2Ns your trip is short!",
  "id" : 529842357491863553,
  "in_reply_to_status_id" : 529841174412947457,
  "created_at" : "2014-11-05 03:47:16 +0000",
  "in_reply_to_screen_name" : "Dianna_2Ns",
  "in_reply_to_user_id_str" : "67117740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/529824278594613248\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/MslXJdKQoo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1pQXF-CQAAO84n.jpg",
      "id_str" : "529824263839039488",
      "id" : 529824263839039488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1pQXF-CQAAO84n.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2356,
        "resize" : "fit",
        "w" : 3147
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/MslXJdKQoo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529824278594613248",
  "text" : "Draw me like one of your french huskies http:\/\/t.co\/MslXJdKQoo",
  "id" : 529824278594613248,
  "created_at" : "2014-11-05 02:35:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Blair",
      "screen_name" : "ArrBlair",
      "indices" : [ 0, 9 ],
      "id_str" : "240076424",
      "id" : 240076424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529810802011025409",
  "geo" : { },
  "id_str" : "529811108803010561",
  "in_reply_to_user_id" : 240076424,
  "text" : "@ArrBlair Because of the incredible speed of your rocket",
  "id" : 529811108803010561,
  "in_reply_to_status_id" : 529810802011025409,
  "created_at" : "2014-11-05 01:43:06 +0000",
  "in_reply_to_screen_name" : "ArrBlair",
  "in_reply_to_user_id_str" : "240076424",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529810018397212672",
  "text" : "Your spaceship is about to blast off!",
  "id" : 529810018397212672,
  "created_at" : "2014-11-05 01:38:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529808746122199040",
  "text" : "You fear the feathered creatures.",
  "id" : 529808746122199040,
  "created_at" : "2014-11-05 01:33:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529806354408833024",
  "geo" : { },
  "id_str" : "529808206030061569",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy I've always played a house rule where if you get a hand of all 9s\/10s, you can force everyone to toss in and redeal.",
  "id" : 529808206030061569,
  "in_reply_to_status_id" : 529806354408833024,
  "created_at" : "2014-11-05 01:31:34 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/WQraTEeiZF",
      "expanded_url" : "https:\/\/medium.com\/@ericajoy\/the-other-side-of-diversity-1bb3de2f053e",
      "display_url" : "medium.com\/@ericajoy\/the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529778841409945601",
  "text" : "A must read: https:\/\/t.co\/WQraTEeiZF",
  "id" : 529778841409945601,
  "created_at" : "2014-11-04 23:34:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 3, 17 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529778721046028289",
  "text" : "RT @buffalopundit: Not a lot of Weppner signs on the East Side. Wonder why.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "529675153048080384",
    "text" : "Not a lot of Weppner signs on the East Side. Wonder why.",
    "id" : 529675153048080384,
    "created_at" : "2014-11-04 16:42:52 +0000",
    "user" : {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "protected" : false,
      "id_str" : "5795572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554430715308560384\/LnSJ-sAY_normal.jpeg",
      "id" : 5795572,
      "verified" : false
    }
  },
  "id" : 529778721046028289,
  "created_at" : "2014-11-04 23:34:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zac Williams",
      "screen_name" : "jzw",
      "indices" : [ 0, 4 ],
      "id_str" : "14585326",
      "id" : 14585326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529762648930656256",
  "geo" : { },
  "id_str" : "529762823119699968",
  "in_reply_to_user_id" : 14585326,
  "text" : "@jzw YOUR TRIP IS SHORT!!!",
  "id" : 529762823119699968,
  "in_reply_to_status_id" : 529762648930656256,
  "created_at" : "2014-11-04 22:31:14 +0000",
  "in_reply_to_screen_name" : "jzw",
  "in_reply_to_user_id_str" : "14585326",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529762510258204672",
  "text" : "Because of the incredible speed of your rocket",
  "id" : 529762510258204672,
  "created_at" : "2014-11-04 22:29:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 0, 11 ],
      "id_str" : "137891464",
      "id" : 137891464
    }, {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 12, 24 ],
      "id_str" : "158098704",
      "id" : 158098704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529685497099345920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9251250474, -78.8834076635 ]
  },
  "id_str" : "529686287784349696",
  "in_reply_to_user_id" : 137891464,
  "text" : "@nickelcity @mikemikemac \uD83D\uDC50",
  "id" : 529686287784349696,
  "in_reply_to_status_id" : 529685497099345920,
  "created_at" : "2014-11-04 17:27:06 +0000",
  "in_reply_to_screen_name" : "nickelcity",
  "in_reply_to_user_id_str" : "137891464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne van Kesteren",
      "screen_name" : "annevk",
      "indices" : [ 3, 10 ],
      "id_str" : "3616991",
      "id" : 3616991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/PZEFg7yIzB",
      "expanded_url" : "http:\/\/www.unicode.org\/reports\/tr51\/",
      "display_url" : "unicode.org\/reports\/tr51\/"
    } ]
  },
  "geo" : { },
  "id_str" : "529623055471874048",
  "text" : "RT @annevk: http:\/\/t.co\/PZEFg7yIzB brings skin tone modifier characters to emoji.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/PZEFg7yIzB",
        "expanded_url" : "http:\/\/www.unicode.org\/reports\/tr51\/",
        "display_url" : "unicode.org\/reports\/tr51\/"
      } ]
    },
    "geo" : { },
    "id_str" : "529577475756797952",
    "text" : "http:\/\/t.co\/PZEFg7yIzB brings skin tone modifier characters to emoji.",
    "id" : 529577475756797952,
    "created_at" : "2014-11-04 10:14:43 +0000",
    "user" : {
      "name" : "Anne van Kesteren",
      "screen_name" : "annevk",
      "protected" : false,
      "id_str" : "3616991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466483130011234305\/5jT_75o__normal.jpeg",
      "id" : 3616991,
      "verified" : false
    }
  },
  "id" : 529623055471874048,
  "created_at" : "2014-11-04 13:15:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "indices" : [ 3, 16 ],
      "id_str" : "16275936",
      "id" : 16275936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/QnBCipJBZO",
      "expanded_url" : "http:\/\/mobile.nytimes.com\/2014\/11\/04\/nyregion\/de-niros-hudson-valley-neighbors-feel-his-presence-mostly-in-court.html?ref=nyregion&_r=0&referrer=",
      "display_url" : "mobile.nytimes.com\/2014\/11\/04\/nyr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529622086319222785",
  "text" : "RT @rachbarnhart: Robert DeNiro fighting tax bill in Ulster County, losing him fans in small town  http:\/\/t.co\/QnBCipJBZO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/QnBCipJBZO",
        "expanded_url" : "http:\/\/mobile.nytimes.com\/2014\/11\/04\/nyregion\/de-niros-hudson-valley-neighbors-feel-his-presence-mostly-in-court.html?ref=nyregion&_r=0&referrer=",
        "display_url" : "mobile.nytimes.com\/2014\/11\/04\/nyr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529620938976161792",
    "text" : "Robert DeNiro fighting tax bill in Ulster County, losing him fans in small town  http:\/\/t.co\/QnBCipJBZO",
    "id" : 529620938976161792,
    "created_at" : "2014-11-04 13:07:26 +0000",
    "user" : {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "protected" : false,
      "id_str" : "16275936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521680125583048706\/TIU0iX_J_normal.jpeg",
      "id" : 16275936,
      "verified" : false
    }
  },
  "id" : 529622086319222785,
  "created_at" : "2014-11-04 13:11:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ochonicki",
      "screen_name" : "fromonesrc",
      "indices" : [ 3, 14 ],
      "id_str" : "14420513",
      "id" : 14420513
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/fromonesrc\/status\/529611490291376128\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/b4GH3Fsdkp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1mO1_QIgAAil2g.png",
      "id_str" : "529611489356054528",
      "id" : 529611489356054528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1mO1_QIgAAil2g.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/b4GH3Fsdkp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529617556147933184",
  "text" : "RT @fromonesrc: People's feelings about computers in 2014 http:\/\/t.co\/b4GH3Fsdkp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/fromonesrc\/status\/529611490291376128\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/b4GH3Fsdkp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1mO1_QIgAAil2g.png",
        "id_str" : "529611489356054528",
        "id" : 529611489356054528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1mO1_QIgAAil2g.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 1065,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/b4GH3Fsdkp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "529611490291376128",
    "text" : "People's feelings about computers in 2014 http:\/\/t.co\/b4GH3Fsdkp",
    "id" : 529611490291376128,
    "created_at" : "2014-11-04 12:29:53 +0000",
    "user" : {
      "name" : "Adam Ochonicki",
      "screen_name" : "fromonesrc",
      "protected" : false,
      "id_str" : "14420513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514496188117438464\/ZdUrUp0B_normal.jpeg",
      "id" : 14420513,
      "verified" : false
    }
  },
  "id" : 529617556147933184,
  "created_at" : "2014-11-04 12:53:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dezeen",
      "screen_name" : "Dezeen",
      "indices" : [ 3, 10 ],
      "id_str" : "26012202",
      "id" : 26012202
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Dezeen\/status\/529579100227502082\/photo\/1",
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/wB6J3udZvt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1lxYo0IIAAC2KL.jpg",
      "id_str" : "529579099279597568",
      "id" : 529579099279597568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1lxYo0IIAAC2KL.jpg",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 159,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wB6J3udZvt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/Y1qI06A1gg",
      "expanded_url" : "http:\/\/www.dezeen.com\/2014\/11\/03\/elizabeth-diller-ricardo-scofidio-interview-high-line-new-york\/",
      "display_url" : "dezeen.com\/2014\/11\/03\/eli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529601590718525440",
  "text" : "RT @Dezeen: The architects behind New York's High Line park on how the project has changed the city: http:\/\/t.co\/Y1qI06A1gg http:\/\/t.co\/wB6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Dezeen\/status\/529579100227502082\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/wB6J3udZvt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1lxYo0IIAAC2KL.jpg",
        "id_str" : "529579099279597568",
        "id" : 529579099279597568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1lxYo0IIAAC2KL.jpg",
        "sizes" : [ {
          "h" : 376,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 159,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/wB6J3udZvt"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/Y1qI06A1gg",
        "expanded_url" : "http:\/\/www.dezeen.com\/2014\/11\/03\/elizabeth-diller-ricardo-scofidio-interview-high-line-new-york\/",
        "display_url" : "dezeen.com\/2014\/11\/03\/eli\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529579100227502082",
    "text" : "The architects behind New York's High Line park on how the project has changed the city: http:\/\/t.co\/Y1qI06A1gg http:\/\/t.co\/wB6J3udZvt",
    "id" : 529579100227502082,
    "created_at" : "2014-11-04 10:21:11 +0000",
    "user" : {
      "name" : "Dezeen",
      "screen_name" : "Dezeen",
      "protected" : false,
      "id_str" : "26012202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/232541366\/thezeen_normal.png",
      "id" : 26012202,
      "verified" : false
    }
  },
  "id" : 529601590718525440,
  "created_at" : "2014-11-04 11:50:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529495949949693952",
  "text" : "RT @IAM_SHAKESPEARE: I shall as famous be by this exploit.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "529495768642887681",
    "text" : "I shall as famous be by this exploit.",
    "id" : 529495768642887681,
    "created_at" : "2014-11-04 04:50:03 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 529495949949693952,
  "created_at" : "2014-11-04 04:50:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nasma Ahmed",
      "screen_name" : "Nasma_Ahmed",
      "indices" : [ 3, 15 ],
      "id_str" : "907454808",
      "id" : 907454808
    }, {
      "name" : "Model View Culture",
      "screen_name" : "ModelViewMedia",
      "indices" : [ 60, 75 ],
      "id_str" : "2262399740",
      "id" : 2262399740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/tWLLOwgUlm",
      "expanded_url" : "https:\/\/modelviewculture.com\/pieces\/where-are-you-really-from-microaggressions-and-making-tech-meetups-safe",
      "display_url" : "modelviewculture.com\/pieces\/where-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529495353830035456",
  "text" : "RT @Nasma_Ahmed: My piece about microagressions is now live @ModelViewMedia check it out https:\/\/t.co\/tWLLOwgUlm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Model View Culture",
        "screen_name" : "ModelViewMedia",
        "indices" : [ 43, 58 ],
        "id_str" : "2262399740",
        "id" : 2262399740
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/tWLLOwgUlm",
        "expanded_url" : "https:\/\/modelviewculture.com\/pieces\/where-are-you-really-from-microaggressions-and-making-tech-meetups-safe",
        "display_url" : "modelviewculture.com\/pieces\/where-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "527500267739414528",
    "text" : "My piece about microagressions is now live @ModelViewMedia check it out https:\/\/t.co\/tWLLOwgUlm",
    "id" : 527500267739414528,
    "created_at" : "2014-10-29 16:40:38 +0000",
    "user" : {
      "name" : "Nasma Ahmed",
      "screen_name" : "Nasma_Ahmed",
      "protected" : false,
      "id_str" : "907454808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538795757910781952\/K7euRVcF_normal.png",
      "id" : 907454808,
      "verified" : false
    }
  },
  "id" : 529495353830035456,
  "created_at" : "2014-11-04 04:48:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529452811084234752",
  "text" : "THEY ATTACK!",
  "id" : 529452811084234752,
  "created_at" : "2014-11-04 01:59:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Madsen",
      "screen_name" : "sjmadsen",
      "indices" : [ 0, 9 ],
      "id_str" : "14061433",
      "id" : 14061433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529427386576945153",
  "geo" : { },
  "id_str" : "529427883815481344",
  "in_reply_to_user_id" : 14061433,
  "text" : "@sjmadsen I can\u2019t recall. Integration testing of iOS is way too difficult.",
  "id" : 529427883815481344,
  "in_reply_to_status_id" : 529427386576945153,
  "created_at" : "2014-11-04 00:20:18 +0000",
  "in_reply_to_screen_name" : "sjmadsen",
  "in_reply_to_user_id_str" : "14061433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/529419242844614656\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/nyxxKQPFab",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1jf_oQCMAA1a_M.png",
      "id_str" : "529419240445456384",
      "id" : 529419240445456384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1jf_oQCMAA1a_M.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nyxxKQPFab"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529419242844614656",
  "text" : "11K people following the GIFs Room and it\u2019s basically an inefficient Tumblog. I don\u2019t get the point. http:\/\/t.co\/nyxxKQPFab",
  "id" : 529419242844614656,
  "created_at" : "2014-11-03 23:45:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 3, 9 ],
      "id_str" : "1679",
      "id" : 1679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/1jRx8ASksD",
      "expanded_url" : "https:\/\/bugs.webkit.org\/show_bug.cgi?id=19893",
      "display_url" : "bugs.webkit.org\/show_bug.cgi?i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529417870782898176",
  "text" : "RT @javan: 10 years ago, WebKit stopped copy+pasting HTML to work around a bug in Excel. It's still broken in Safari. https:\/\/t.co\/1jRx8ASk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/1jRx8ASksD",
        "expanded_url" : "https:\/\/bugs.webkit.org\/show_bug.cgi?id=19893",
        "display_url" : "bugs.webkit.org\/show_bug.cgi?i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529417661659115521",
    "text" : "10 years ago, WebKit stopped copy+pasting HTML to work around a bug in Excel. It's still broken in Safari. https:\/\/t.co\/1jRx8ASksD",
    "id" : 529417661659115521,
    "created_at" : "2014-11-03 23:39:41 +0000",
    "user" : {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "protected" : false,
      "id_str" : "1679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526722729123143680\/0-ppDKP__normal.jpeg",
      "id" : 1679,
      "verified" : false
    }
  },
  "id" : 529417870782898176,
  "created_at" : "2014-11-03 23:40:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529374303134162944",
  "text" : "Your spaceship is about to blast off!",
  "id" : 529374303134162944,
  "created_at" : "2014-11-03 20:47:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 3, 15 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529358167742771201",
  "text" : "RT @kylebragger: You definitely can only build great companies in San Francisco! The rest of y'all jokers are just wasting your time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "529356480232030208",
    "text" : "You definitely can only build great companies in San Francisco! The rest of y'all jokers are just wasting your time.",
    "id" : 529356480232030208,
    "created_at" : "2014-11-03 19:36:34 +0000",
    "user" : {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "protected" : false,
      "id_str" : "2039761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507847698108530688\/kxTiyE6b_normal.png",
      "id" : 2039761,
      "verified" : false
    }
  },
  "id" : 529358167742771201,
  "created_at" : "2014-11-03 19:43:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529357348905963520",
  "geo" : { },
  "id_str" : "529357451175288834",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda fav'd so hard I broke the star button",
  "id" : 529357451175288834,
  "in_reply_to_status_id" : 529357348905963520,
  "created_at" : "2014-11-03 19:40:26 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529356853642526720",
  "geo" : { },
  "id_str" : "529357047951654913",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda agreed. Been wondering if it still works on other parts of the body.",
  "id" : 529357047951654913,
  "in_reply_to_status_id" : 529356853642526720,
  "created_at" : "2014-11-03 19:38:49 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529355405995278336",
  "geo" : { },
  "id_str" : "529356225050202113",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda yeah, i suppose so. i consider it the same as not going through the TSA's bodyscanners. Let me have something.",
  "id" : 529356225050202113,
  "in_reply_to_status_id" : 529355405995278336,
  "created_at" : "2014-11-03 19:35:33 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529353935539408896",
  "geo" : { },
  "id_str" : "529354131773739008",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda everyone's on the grid - they take prints when you're born. the difference is using it as an everyday way to authenticate",
  "id" : 529354131773739008,
  "in_reply_to_status_id" : 529353935539408896,
  "created_at" : "2014-11-03 19:27:14 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/mDsk8kSM0g",
      "expanded_url" : "http:\/\/www.macrumors.com\/2014\/10\/31\/fingerprints-not-protected-by-fifth-amendment\/",
      "display_url" : "macrumors.com\/2014\/10\/31\/fin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529353329164300289",
  "text" : "Yet another reason to avoid TouchID: http:\/\/t.co\/mDsk8kSM0g",
  "id" : 529353329164300289,
  "created_at" : "2014-11-03 19:24:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Russell",
      "screen_name" : "bratschecody",
      "indices" : [ 0, 13 ],
      "id_str" : "85608393",
      "id" : 85608393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529350831275913216",
  "geo" : { },
  "id_str" : "529351109857398784",
  "in_reply_to_user_id" : 85608393,
  "text" : "@bratschecody Cool - have introduced a few people via Twitter, just curious. :) And nice, I'll queue that up :)",
  "id" : 529351109857398784,
  "in_reply_to_status_id" : 529350831275913216,
  "created_at" : "2014-11-03 19:15:14 +0000",
  "in_reply_to_screen_name" : "bratschecody",
  "in_reply_to_user_id_str" : "85608393",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheWashingtonMarket",
      "screen_name" : "WashingtonMkt",
      "indices" : [ 3, 17 ],
      "id_str" : "22851867",
      "id" : 22851867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/HjGmFNhQW9",
      "expanded_url" : "http:\/\/fb.me\/36WWCGVrG",
      "display_url" : "fb.me\/36WWCGVrG"
    } ]
  },
  "geo" : { },
  "id_str" : "529350588639612928",
  "text" : "RT @WashingtonMkt: Three days until our FIRST Indoor Winter Farmer's Market!\n\nAmong our many vendors: Cedar's Bakery &amp; Deli. They... http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/HjGmFNhQW9",
        "expanded_url" : "http:\/\/fb.me\/36WWCGVrG",
        "display_url" : "fb.me\/36WWCGVrG"
      } ]
    },
    "geo" : { },
    "id_str" : "529344067445227520",
    "text" : "Three days until our FIRST Indoor Winter Farmer's Market!\n\nAmong our many vendors: Cedar's Bakery &amp; Deli. They... http:\/\/t.co\/HjGmFNhQW9",
    "id" : 529344067445227520,
    "created_at" : "2014-11-03 18:47:15 +0000",
    "user" : {
      "name" : "TheWashingtonMarket",
      "screen_name" : "WashingtonMkt",
      "protected" : false,
      "id_str" : "22851867",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/87971303\/GetImage.ashx_normal.jpeg",
      "id" : 22851867,
      "verified" : false
    }
  },
  "id" : 529350588639612928,
  "created_at" : "2014-11-03 19:13:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Russell",
      "screen_name" : "bratschecody",
      "indices" : [ 0, 13 ],
      "id_str" : "85608393",
      "id" : 85608393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529350003957854209",
  "geo" : { },
  "id_str" : "529350404438372352",
  "in_reply_to_user_id" : 85608393,
  "text" : "@bratschecody Loving this. Free last night echoed it. As usual, I wish I was there. Was that your first show?",
  "id" : 529350404438372352,
  "in_reply_to_status_id" : 529350003957854209,
  "created_at" : "2014-11-03 19:12:25 +0000",
  "in_reply_to_screen_name" : "bratschecody",
  "in_reply_to_user_id_str" : "85608393",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529349140057051137",
  "text" : "Your trip is short.",
  "id" : 529349140057051137,
  "created_at" : "2014-11-03 19:07:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LivePhish",
      "screen_name" : "LivePhish",
      "indices" : [ 16, 26 ],
      "id_str" : "232312841",
      "id" : 232312841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529348706386976769",
  "text" : "Not sure if the @LivePhish sub is worth it. Can't remember what song was playing if you pause. :(",
  "id" : 529348706386976769,
  "created_at" : "2014-11-03 19:05:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529319771662061568",
  "geo" : { },
  "id_str" : "529320275372830720",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik your trip is short!",
  "id" : 529320275372830720,
  "in_reply_to_status_id" : 529319771662061568,
  "created_at" : "2014-11-03 17:12:42 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529319434473586689",
  "text" : "Finally sitting down with the Halloween set. Wow.",
  "id" : 529319434473586689,
  "created_at" : "2014-11-03 17:09:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 0, 10 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529318192494415872",
  "geo" : { },
  "id_str" : "529318312912515073",
  "in_reply_to_user_id" : 14620798,
  "text" : "@zachwaugh that's the problem entirely - disabling is awful.",
  "id" : 529318312912515073,
  "in_reply_to_status_id" : 529318192494415872,
  "created_at" : "2014-11-03 17:04:54 +0000",
  "in_reply_to_screen_name" : "zachwaugh",
  "in_reply_to_user_id_str" : "14620798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eli Perkins",
      "screen_name" : "_eliperkins",
      "indices" : [ 0, 12 ],
      "id_str" : "139504833",
      "id" : 139504833
    }, {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 13, 23 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529317432557862912",
  "geo" : { },
  "id_str" : "529317561507147776",
  "in_reply_to_user_id" : 139504833,
  "text" : "@_eliperkins @listrophy actually that's super helpful. thanks to both. XVim can only do so much.",
  "id" : 529317561507147776,
  "in_reply_to_status_id" : 529317432557862912,
  "created_at" : "2014-11-03 17:01:55 +0000",
  "in_reply_to_screen_name" : "_eliperkins",
  "in_reply_to_user_id_str" : "139504833",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sadvil",
      "screen_name" : "crylenol",
      "indices" : [ 3, 12 ],
      "id_str" : "65433646",
      "id" : 65433646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529317246187749377",
  "text" : "RT @crylenol: \"have you seen the wire??\"\n- Nik Wallenda in serious trouble",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "529317184322158594",
    "text" : "\"have you seen the wire??\"\n- Nik Wallenda in serious trouble",
    "id" : 529317184322158594,
    "created_at" : "2014-11-03 17:00:25 +0000",
    "user" : {
      "name" : "sadvil",
      "screen_name" : "crylenol",
      "protected" : false,
      "id_str" : "65433646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548664026050199552\/zHvu3Wlg_normal.png",
      "id" : 65433646,
      "verified" : false
    }
  },
  "id" : 529317246187749377,
  "created_at" : "2014-11-03 17:00:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529317070857441280",
  "geo" : { },
  "id_str" : "529317170774151169",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy are you fucking kidding me. a DRAG action in a code editor!?!",
  "id" : 529317170774151169,
  "in_reply_to_status_id" : 529317070857441280,
  "created_at" : "2014-11-03 17:00:22 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529316678908141568",
  "text" : "Xcode's breakpoints are infuriating. One click to add, shouldn't another click remove? Why does it have to be a context action to undo?",
  "id" : 529316678908141568,
  "created_at" : "2014-11-03 16:58:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529294965528997888",
  "text" : "Context: I was stopped at an intersection (Utica\/Richmond), light turned green. He was trying to turn left and I was in his way. Yelled.",
  "id" : 529294965528997888,
  "created_at" : "2014-11-03 15:32:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529293350570975233",
  "text" : "Got called an asshole and to bike on the sidewalk on my ride in this morning. I was in a bike lane.",
  "id" : 529293350570975233,
  "created_at" : "2014-11-03 15:25:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hampton",
      "screen_name" : "hcatlin",
      "indices" : [ 0, 8 ],
      "id_str" : "12986052",
      "id" : 12986052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529255483417575425",
  "geo" : { },
  "id_str" : "529255919759015937",
  "in_reply_to_user_id" : 12986052,
  "text" : "@hcatlin isn\u2019t this everyone? I hate that \u201C10x\u201D term",
  "id" : 529255919759015937,
  "in_reply_to_status_id" : 529255483417575425,
  "created_at" : "2014-11-03 12:56:59 +0000",
  "in_reply_to_screen_name" : "hcatlin",
  "in_reply_to_user_id_str" : "12986052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Public",
      "screen_name" : "PublicBFLO",
      "indices" : [ 0, 11 ],
      "id_str" : "2837661305",
      "id" : 2837661305
    }, {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 12, 26 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529106963029065728",
  "geo" : { },
  "id_str" : "529240434598363136",
  "in_reply_to_user_id" : 2837661305,
  "text" : "@PublicBFLO @buffalopundit what will I do without my sex ads and full page interrupting Hobby Lobby interstitials?",
  "id" : 529240434598363136,
  "in_reply_to_status_id" : 529106963029065728,
  "created_at" : "2014-11-03 11:55:27 +0000",
  "in_reply_to_screen_name" : "PublicBFLO",
  "in_reply_to_user_id_str" : "2837661305",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 0, 11 ],
      "id_str" : "247090698",
      "id" : 247090698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529163933051936768",
  "geo" : { },
  "id_str" : "529164081018572800",
  "in_reply_to_user_id" : 247090698,
  "text" : "@bizarchive Blimey from Fish",
  "id" : 529164081018572800,
  "in_reply_to_status_id" : 529163933051936768,
  "created_at" : "2014-11-03 06:52:02 +0000",
  "in_reply_to_screen_name" : "bizarchive",
  "in_reply_to_user_id_str" : "247090698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529141466723934208",
  "text" : "Holy shit, this Free.",
  "id" : 529141466723934208,
  "created_at" : "2014-11-03 05:22:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 1, 7 ],
      "id_str" : "14503997",
      "id" : 14503997
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 43, 55 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Y4xQIqOYnm",
      "expanded_url" : "http:\/\/aqueousband.com\/tour",
      "display_url" : "aqueousband.com\/tour"
    } ]
  },
  "geo" : { },
  "id_str" : "529122743120179200",
  "text" : ".@phish tour wrapping up this evening, and @AqueousBand is still firing on all cylinders throughout 2014 =&gt; http:\/\/t.co\/Y4xQIqOYnm",
  "id" : 529122743120179200,
  "created_at" : "2014-11-03 04:07:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529119000752832513",
  "geo" : { },
  "id_str" : "529119051423809536",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo whaaat",
  "id" : 529119051423809536,
  "in_reply_to_status_id" : 529119000752832513,
  "created_at" : "2014-11-03 03:53:07 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 16, 27 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529108004101451777",
  "geo" : { },
  "id_str" : "529108319210713089",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox someday @kevinpurdy will do a behind the music for paper towels",
  "id" : 529108319210713089,
  "in_reply_to_status_id" : 529108004101451777,
  "created_at" : "2014-11-03 03:10:28 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529107614836457472",
  "geo" : { },
  "id_str" : "529107822567387137",
  "in_reply_to_user_id" : 750823,
  "text" : "@Maddox but have you read the one about paper towels yet?! Or garbage cans?!",
  "id" : 529107822567387137,
  "in_reply_to_status_id" : 529107614836457472,
  "created_at" : "2014-11-03 03:08:29 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Zinni",
      "screen_name" : "MarkZinni",
      "indices" : [ 0, 10 ],
      "id_str" : "16200497",
      "id" : 16200497
    }, {
      "name" : "Michael Letterle",
      "screen_name" : "mletterle",
      "indices" : [ 11, 21 ],
      "id_str" : "458173",
      "id" : 458173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529071938598359041",
  "geo" : { },
  "id_str" : "529083491539902466",
  "in_reply_to_user_id" : 16200497,
  "text" : "@MarkZinni @mletterle he\u2019s been an inspiration to an entire summer\u2019s worth of awful ads for the local Six Flags here",
  "id" : 529083491539902466,
  "in_reply_to_status_id" : 529071938598359041,
  "created_at" : "2014-11-03 01:31:48 +0000",
  "in_reply_to_screen_name" : "MarkZinni",
  "in_reply_to_user_id_str" : "16200497",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brianna Wu",
      "screen_name" : "Spacekatgal",
      "indices" : [ 3, 15 ],
      "id_str" : "17264476",
      "id" : 17264476
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Spacekatgal\/status\/527821599219916801\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/km8bFw9d4W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1My8oEIMAI0-nL.png",
      "id_str" : "527821598460751874",
      "id" : 527821598460751874,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1My8oEIMAI0-nL.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 711,
        "resize" : "fit",
        "w" : 951
      }, {
        "h" : 711,
        "resize" : "fit",
        "w" : 951
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/km8bFw9d4W"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529083138224291840",
  "text" : "RT @Spacekatgal: Meant as a joke, but it's true. Gamergate is a viral cult that taps into the outsider feelings of gamer culture. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Spacekatgal\/status\/527821599219916801\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/km8bFw9d4W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1My8oEIMAI0-nL.png",
        "id_str" : "527821598460751874",
        "id" : 527821598460751874,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1My8oEIMAI0-nL.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 711,
          "resize" : "fit",
          "w" : 951
        }, {
          "h" : 711,
          "resize" : "fit",
          "w" : 951
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/km8bFw9d4W"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "527821599219916801",
    "text" : "Meant as a joke, but it's true. Gamergate is a viral cult that taps into the outsider feelings of gamer culture. http:\/\/t.co\/km8bFw9d4W",
    "id" : 527821599219916801,
    "created_at" : "2014-10-30 13:57:30 +0000",
    "user" : {
      "name" : "Brianna Wu",
      "screen_name" : "Spacekatgal",
      "protected" : false,
      "id_str" : "17264476",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514771515514945536\/gNvkOLn0_normal.jpeg",
      "id" : 17264476,
      "verified" : false
    }
  },
  "id" : 529083138224291840,
  "created_at" : "2014-11-03 01:30:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 0, 8 ],
      "id_str" : "20844341",
      "id" : 20844341
    }, {
      "name" : "Greg Baugues",
      "screen_name" : "greggyb",
      "indices" : [ 9, 17 ],
      "id_str" : "15048829",
      "id" : 15048829
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 36, 50 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529068520743501824",
  "geo" : { },
  "id_str" : "529082117834039296",
  "in_reply_to_user_id" : 20844341,
  "text" : "@patio11 @greggyb for sure. This is @coworkbuffalo for me \uD83D\uDE01",
  "id" : 529082117834039296,
  "in_reply_to_status_id" : 529068520743501824,
  "created_at" : "2014-11-03 01:26:21 +0000",
  "in_reply_to_screen_name" : "patio11",
  "in_reply_to_user_id_str" : "20844341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hampton",
      "screen_name" : "hcatlin",
      "indices" : [ 0, 8 ],
      "id_str" : "12986052",
      "id" : 12986052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529071694926053376",
  "geo" : { },
  "id_str" : "529071905261641728",
  "in_reply_to_user_id" : 12986052,
  "text" : "@hcatlin lol. All 3 are accurate.",
  "id" : 529071905261641728,
  "in_reply_to_status_id" : 529071694926053376,
  "created_at" : "2014-11-03 00:45:46 +0000",
  "in_reply_to_screen_name" : "hcatlin",
  "in_reply_to_user_id_str" : "12986052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 0, 7 ],
      "id_str" : "5452072",
      "id" : 5452072
    }, {
      "name" : "Riker Googling",
      "screen_name" : "RikerGoogling",
      "indices" : [ 25, 39 ],
      "id_str" : "2341337263",
      "id" : 2341337263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529031494678097921",
  "geo" : { },
  "id_str" : "529058204244656128",
  "in_reply_to_user_id" : 5452072,
  "text" : "@nb3004 deserves to be a @RikerGoogling entry",
  "id" : 529058204244656128,
  "in_reply_to_status_id" : 529031494678097921,
  "created_at" : "2014-11-02 23:51:19 +0000",
  "in_reply_to_screen_name" : "nb3004",
  "in_reply_to_user_id_str" : "5452072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hampton",
      "screen_name" : "hcatlin",
      "indices" : [ 0, 8 ],
      "id_str" : "12986052",
      "id" : 12986052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529047618526400512",
  "geo" : { },
  "id_str" : "529057948924801024",
  "in_reply_to_user_id" : 12986052,
  "text" : "@hcatlin we try to get as many neutral colors as possible. It takes a lot more effort.",
  "id" : 529057948924801024,
  "in_reply_to_status_id" : 529047618526400512,
  "created_at" : "2014-11-02 23:50:19 +0000",
  "in_reply_to_screen_name" : "hcatlin",
  "in_reply_to_user_id_str" : "12986052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Steinberg",
      "screen_name" : "zzyzx",
      "indices" : [ 0, 6 ],
      "id_str" : "6073352",
      "id" : 6073352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529040789222199296",
  "geo" : { },
  "id_str" : "529047359548702720",
  "in_reply_to_user_id" : 6073352,
  "text" : "@zzyzx these guys were so good in Buffalo. This and Phish in one day?!? \uD83D\uDE31",
  "id" : 529047359548702720,
  "in_reply_to_status_id" : 529040789222199296,
  "created_at" : "2014-11-02 23:08:14 +0000",
  "in_reply_to_screen_name" : "zzyzx",
  "in_reply_to_user_id_str" : "6073352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529022387011211264",
  "geo" : { },
  "id_str" : "529030527483785216",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss it was paid before apple featured it",
  "id" : 529030527483785216,
  "in_reply_to_status_id" : 529022387011211264,
  "created_at" : "2014-11-02 22:01:21 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529010689315069952",
  "geo" : { },
  "id_str" : "529019780259274752",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik new LinkedIn profile picture",
  "id" : 529019780259274752,
  "in_reply_to_status_id" : 529010689315069952,
  "created_at" : "2014-11-02 21:18:38 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529019543474024448",
  "text" : "RGB Express is such a well designed game. Kind of wish there was a way to design puzzles in it.",
  "id" : 529019543474024448,
  "created_at" : "2014-11-02 21:17:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pookleblinky",
      "screen_name" : "pookleblinky",
      "indices" : [ 0, 13 ],
      "id_str" : "35163668",
      "id" : 35163668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/WLulCDKSzj",
      "expanded_url" : "https:\/\/www.dropbox.com\/s\/w570b5nqnpd2a4l\/Susan_thought_she_could_talk_to_fish.gif?dl=0",
      "display_url" : "dropbox.com\/s\/w570b5nqnpd2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "529014100282847232",
  "geo" : { },
  "id_str" : "529015276545650690",
  "in_reply_to_user_id" : 35163668,
  "text" : "@pookleblinky nope https:\/\/t.co\/WLulCDKSzj",
  "id" : 529015276545650690,
  "in_reply_to_status_id" : 529014100282847232,
  "created_at" : "2014-11-02 21:00:45 +0000",
  "in_reply_to_screen_name" : "pookleblinky",
  "in_reply_to_user_id_str" : "35163668",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sadvil",
      "screen_name" : "crylenol",
      "indices" : [ 3, 12 ],
      "id_str" : "65433646",
      "id" : 65433646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529014972190179328",
  "text" : "RT @crylenol: Adulthood is basically, you think a lot about lunch and then you die.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "529005005953855488",
    "text" : "Adulthood is basically, you think a lot about lunch and then you die.",
    "id" : 529005005953855488,
    "created_at" : "2014-11-02 20:19:56 +0000",
    "user" : {
      "name" : "sadvil",
      "screen_name" : "crylenol",
      "protected" : false,
      "id_str" : "65433646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548664026050199552\/zHvu3Wlg_normal.png",
      "id" : 65433646,
      "verified" : false
    }
  },
  "id" : 529014972190179328,
  "created_at" : "2014-11-02 20:59:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528996402903678976",
  "geo" : { },
  "id_str" : "528997125854871552",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark but can it play drums?",
  "id" : 528997125854871552,
  "in_reply_to_status_id" : 528996402903678976,
  "created_at" : "2014-11-02 19:48:37 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 8, 20 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 21, 28 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528979016259497984",
  "geo" : { },
  "id_str" : "528980129444544512",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek @bcardarella @jayroh 400 BABIES",
  "id" : 528980129444544512,
  "in_reply_to_status_id" : 528979016259497984,
  "created_at" : "2014-11-02 18:41:05 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528974860899606531",
  "geo" : { },
  "id_str" : "528975379340341249",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh Awesome! I edited out a lot of snark of this post. If you need some let me know.",
  "id" : 528975379340341249,
  "in_reply_to_status_id" : 528974860899606531,
  "created_at" : "2014-11-02 18:22:12 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528974574508310528",
  "geo" : { },
  "id_str" : "528974751708897280",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy luckily we haven't experienced any water aversion yet. will keep in mind if we do!",
  "id" : 528974751708897280,
  "in_reply_to_status_id" : 528974574508310528,
  "created_at" : "2014-11-02 18:19:43 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528974554983858177",
  "geo" : { },
  "id_str" : "528974640102666240",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh did I miss some news?",
  "id" : 528974640102666240,
  "in_reply_to_status_id" : 528974554983858177,
  "created_at" : "2014-11-02 18:19:16 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/FfyebQiuU4",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2014\/11\/04\/essential-new-dad-stuff\/",
      "display_url" : "quaran.to\/blog\/2014\/11\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528971893752098817",
  "text" : "Wrote a quick post about 3 essential new dad things to get. No baby photos. Two gifs. One swear word. http:\/\/t.co\/FfyebQiuU4",
  "id" : 528971893752098817,
  "created_at" : "2014-11-02 18:08:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u277A\u27A0 David Copeland",
      "screen_name" : "davetron5000",
      "indices" : [ 0, 13 ],
      "id_str" : "5660222",
      "id" : 5660222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528924810445717505",
  "geo" : { },
  "id_str" : "528935302593642497",
  "in_reply_to_user_id" : 5660222,
  "text" : "@davetron5000 don\u2019t put that cutting board in the dishwasher. Learn from my mistakes.",
  "id" : 528935302593642497,
  "in_reply_to_status_id" : 528924810445717505,
  "created_at" : "2014-11-02 15:42:57 +0000",
  "in_reply_to_screen_name" : "davetron5000",
  "in_reply_to_user_id_str" : "5660222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "Sylvia Chong",
      "screen_name" : "sylvzc",
      "indices" : [ 11, 18 ],
      "id_str" : "2544124698",
      "id" : 2544124698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528902462938157056",
  "geo" : { },
  "id_str" : "528905232885874688",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack @sylvzc every part of this video is amazing. also i wish he'd dress up like this for Yo Gabba Gabba.",
  "id" : 528905232885874688,
  "in_reply_to_status_id" : 528902462938157056,
  "created_at" : "2014-11-02 13:43:28 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Honest Toddler",
      "screen_name" : "HonestToddler",
      "indices" : [ 3, 17 ],
      "id_str" : "568247551",
      "id" : 568247551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528877744642195457",
  "text" : "RT @HonestToddler: \"Extra hour of sleep.\" LOL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "528710145317273600",
    "text" : "\"Extra hour of sleep.\" LOL",
    "id" : 528710145317273600,
    "created_at" : "2014-11-02 00:48:16 +0000",
    "user" : {
      "name" : "Honest Toddler",
      "screen_name" : "HonestToddler",
      "protected" : false,
      "id_str" : "568247551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560809677643333632\/Sj__ucsm_normal.jpeg",
      "id" : 568247551,
      "verified" : false
    }
  },
  "id" : 528877744642195457,
  "created_at" : "2014-11-02 11:54:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528766622098415616",
  "text" : "I have not played a more defeating game than Letters from Whitechapel. Not sure if we were playing wrong, it\u2019s unbalanced, but wow.",
  "id" : 528766622098415616,
  "created_at" : "2014-11-02 04:32:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hamad",
      "screen_name" : "MikeHamad",
      "indices" : [ 0, 10 ],
      "id_str" : "27085484",
      "id" : 27085484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528697906933825536",
  "geo" : { },
  "id_str" : "528703660893540353",
  "in_reply_to_user_id" : 27085484,
  "text" : "@MikeHamad great! Looking forward to it.",
  "id" : 528703660893540353,
  "in_reply_to_status_id" : 528697906933825536,
  "created_at" : "2014-11-02 00:22:30 +0000",
  "in_reply_to_screen_name" : "MikeHamad",
  "in_reply_to_user_id_str" : "27085484",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hamad",
      "screen_name" : "MikeHamad",
      "indices" : [ 0, 10 ],
      "id_str" : "27085484",
      "id" : 27085484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528697470357094400",
  "geo" : { },
  "id_str" : "528697801371172864",
  "in_reply_to_user_id" : 27085484,
  "text" : "@MikeHamad are you going to map out that set?",
  "id" : 528697801371172864,
  "in_reply_to_status_id" : 528697470357094400,
  "created_at" : "2014-11-01 23:59:13 +0000",
  "in_reply_to_screen_name" : "MikeHamad",
  "in_reply_to_user_id_str" : "27085484",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528666389897568257",
  "geo" : { },
  "id_str" : "528667723757531136",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold this is some seriously timecube stuff",
  "id" : 528667723757531136,
  "in_reply_to_status_id" : 528666389897568257,
  "created_at" : "2014-11-01 21:59:42 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528661274515632129",
  "geo" : { },
  "id_str" : "528667407918039040",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal funny how it\u2019s that way now for native",
  "id" : 528667407918039040,
  "in_reply_to_status_id" : 528661274515632129,
  "created_at" : "2014-11-01 21:58:26 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528640983865376770",
  "text" : "We need a Karl account for lake effect snow.",
  "id" : 528640983865376770,
  "created_at" : "2014-11-01 20:13:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528616016860180480",
  "geo" : { },
  "id_str" : "528616329499381760",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss so assumes your CI _xcs user has Ruby and everything set up. There\u2019s a ton of hidden complexity in assuming that just works",
  "id" : 528616329499381760,
  "in_reply_to_status_id" : 528616016860180480,
  "created_at" : "2014-11-01 18:35:28 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528614700163280896",
  "geo" : { },
  "id_str" : "528615365455392768",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss I can write it up, good idea. Any custom scripts in Xcode always seem to break horribly in strange ways for us",
  "id" : 528615365455392768,
  "in_reply_to_status_id" : 528614700163280896,
  "created_at" : "2014-11-01 18:31:38 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528613934103035904",
  "geo" : { },
  "id_str" : "528614716944695296",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss it uses whatever branch you created the bot on locally. CocoaPods is hard too- have to check in everything",
  "id" : 528614716944695296,
  "in_reply_to_status_id" : 528613934103035904,
  "created_at" : "2014-11-01 18:29:04 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528611984707964929",
  "geo" : { },
  "id_str" : "528614530696626176",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss still hard to notify on builds. We use Mailgun and a webhook to dump into Campfire.",
  "id" : 528614530696626176,
  "in_reply_to_status_id" : 528611984707964929,
  "created_at" : "2014-11-01 18:28:19 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528611984707964929",
  "geo" : { },
  "id_str" : "528613531441442817",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss can\u2019t change branches without recreating the bot.",
  "id" : 528613531441442817,
  "in_reply_to_status_id" : 528611984707964929,
  "created_at" : "2014-11-01 18:24:21 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528610728300011522",
  "geo" : { },
  "id_str" : "528611816176640001",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss cool idea. We just got our bots working again on 10.10. They have removed so many features :(",
  "id" : 528611816176640001,
  "in_reply_to_status_id" : 528610728300011522,
  "created_at" : "2014-11-01 18:17:32 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 45, 55 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528558309285302272",
  "geo" : { },
  "id_str" : "528558495604301824",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack that would be a sweet DIY project @aquaranto",
  "id" : 528558495604301824,
  "in_reply_to_status_id" : 528558309285302272,
  "created_at" : "2014-11-01 14:45:40 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528557369203384320",
  "geo" : { },
  "id_str" : "528558084600254465",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack holy crap",
  "id" : 528558084600254465,
  "in_reply_to_status_id" : 528557369203384320,
  "created_at" : "2014-11-01 14:44:02 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528511285453803521",
  "text" : "RT @anildash: What are the system requirements for this game? Well it requires a system that numbs us to extreme violence &amp; is uncritical o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405416741037428736",
    "text" : "What are the system requirements for this game? Well it requires a system that numbs us to extreme violence &amp; is uncritical of capitalism.",
    "id" : 405416741037428736,
    "created_at" : "2013-11-26 19:24:18 +0000",
    "user" : {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529664614863101952\/yBQgCUMW_normal.png",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 528511285453803521,
  "created_at" : "2014-11-01 11:38:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Russell",
      "screen_name" : "bratschecody",
      "indices" : [ 0, 13 ],
      "id_str" : "85608393",
      "id" : 85608393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528415315848204288",
  "geo" : { },
  "id_str" : "528511180965281793",
  "in_reply_to_user_id" : 85608393,
  "text" : "@bratschecody fell asleep. Looks like you caught an amazing one!",
  "id" : 528511180965281793,
  "in_reply_to_status_id" : 528415315848204288,
  "created_at" : "2014-11-01 11:37:39 +0000",
  "in_reply_to_screen_name" : "bratschecody",
  "in_reply_to_user_id_str" : "85608393",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 20, 26 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/rAX414DExm",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=2KaQORj_eE0",
      "display_url" : "m.youtube.com\/watch?v=2KaQOR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528397083024175104",
  "text" : "Free webcast up for @phish! https:\/\/t.co\/rAX414DExm",
  "id" : 528397083024175104,
  "created_at" : "2014-11-01 04:04:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109040142035062784",
  "geo" : { },
  "id_str" : "109051950137483264",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove rubygems blurgh needs more styling love but ZOMG thanks!!",
  "id" : 109051950137483264,
  "in_reply_to_status_id" : 109040142035062784,
  "created_at" : "2011-08-31 23:56:25 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 3, 14 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 62 ],
      "url" : "http:\/\/t.co\/TMwQtFp",
      "expanded_url" : "http:\/\/blog.rubygems.org\/2011\/08\/31\/shaving-the-yaml-yacc.html",
      "display_url" : "blog.rubygems.org\/2011\/08\/31\/sha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "109051868092698625",
  "text" : "RT @tenderlove: OMG I wrote a blurgh post. http:\/\/t.co\/TMwQtFp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 46 ],
        "url" : "http:\/\/t.co\/TMwQtFp",
        "expanded_url" : "http:\/\/blog.rubygems.org\/2011\/08\/31\/shaving-the-yaml-yacc.html",
        "display_url" : "blog.rubygems.org\/2011\/08\/31\/sha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "109040142035062784",
    "text" : "OMG I wrote a blurgh post. http:\/\/t.co\/TMwQtFp",
    "id" : 109040142035062784,
    "created_at" : "2011-08-31 23:09:30 +0000",
    "user" : {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "protected" : false,
      "id_str" : "14761655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000325798111\/ca48276f8ebbbbac9c6ce83aac3c8548_normal.jpeg",
      "id" : 14761655,
      "verified" : false
    }
  },
  "id" : 109051868092698625,
  "created_at" : "2011-08-31 23:56:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 0, 8 ],
      "id_str" : "5502392",
      "id" : 5502392
    }, {
      "name" : "Scott Chacon",
      "screen_name" : "chacon",
      "indices" : [ 9, 16 ],
      "id_str" : "127583",
      "id" : 127583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109011392845201408",
  "geo" : { },
  "id_str" : "109011936661876737",
  "in_reply_to_user_id" : 5502392,
  "text" : "@mojombo @chacon i dont mean to hate but why arent posts like this on the github blog?",
  "id" : 109011936661876737,
  "in_reply_to_status_id" : 109011392845201408,
  "created_at" : "2011-08-31 21:17:25 +0000",
  "in_reply_to_screen_name" : "mojombo",
  "in_reply_to_user_id_str" : "5502392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 42, 53 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 36 ],
      "url" : "http:\/\/t.co\/EPB75ao",
      "expanded_url" : "http:\/\/blade.nagaokaut.ac.jp\/cgi-bin\/scat.rb\/ruby\/ruby-talk\/387196",
      "display_url" : "blade.nagaokaut.ac.jp\/cgi-bin\/scat.r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "108995966199283712",
  "text" : "RUBY ON CHIPS!!! http:\/\/t.co\/EPB75ao (via @tenderlove)",
  "id" : 108995966199283712,
  "created_at" : "2011-08-31 20:13:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Greene",
      "screen_name" : "techiferous",
      "indices" : [ 0, 12 ],
      "id_str" : "44238666",
      "id" : 44238666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108869815254528000",
  "geo" : { },
  "id_str" : "108876879544598529",
  "in_reply_to_user_id" : 44238666,
  "text" : "@techiferous how so? blog post?",
  "id" : 108876879544598529,
  "in_reply_to_status_id" : 108869815254528000,
  "created_at" : "2011-08-31 12:20:45 +0000",
  "in_reply_to_screen_name" : "techiferous",
  "in_reply_to_user_id_str" : "44238666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 0, 11 ],
      "id_str" : "9887102",
      "id" : 9887102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/UfPO6DI",
      "expanded_url" : "http:\/\/help.rubygems.org\/kb\/gemcutter\/removing-a-published-rubygem",
      "display_url" : "help.rubygems.org\/kb\/gemcutter\/r\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "108868819908431873",
  "geo" : { },
  "id_str" : "108872702193967106",
  "in_reply_to_user_id" : 9887102,
  "text" : "@metaskills correct, you need to bump a version number always. you're never going to run out of numbers. see FAQ here: http:\/\/t.co\/UfPO6DI",
  "id" : 108872702193967106,
  "in_reply_to_status_id" : 108868819908431873,
  "created_at" : "2011-08-31 12:04:09 +0000",
  "in_reply_to_screen_name" : "metaskills",
  "in_reply_to_user_id_str" : "9887102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 3, 17 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108865938283171840",
  "text" : "RT @garybernhardt: STOP NAMING CLASSES BASE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "108675173913329664",
    "text" : "STOP NAMING CLASSES BASE",
    "id" : 108675173913329664,
    "created_at" : "2011-08-30 22:59:15 +0000",
    "user" : {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "protected" : false,
      "id_str" : "809685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1170938305\/twitter_headshot_normal.png",
      "id" : 809685,
      "verified" : false
    }
  },
  "id" : 108865938283171840,
  "created_at" : "2011-08-31 11:37:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108748728399175681",
  "geo" : { },
  "id_str" : "108865756363620352",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini congrats in advance! the real party is in buffalo if you want to come :P",
  "id" : 108865756363620352,
  "in_reply_to_status_id" : 108748728399175681,
  "created_at" : "2011-08-31 11:36:33 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108788436432990208",
  "text" : "Big drive done, and love seeing rubygems.org on top of HN. Useful automatic release pages w\/ install info: still going strong!",
  "id" : 108788436432990208,
  "created_at" : "2011-08-31 06:29:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108703309203910657",
  "geo" : { },
  "id_str" : "108704927819374593",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox doing...what?",
  "id" : 108704927819374593,
  "in_reply_to_status_id" : 108703309203910657,
  "created_at" : "2011-08-31 00:57:29 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.1583678167, -72.6098382333 ]
  },
  "id_str" : "108685319481729024",
  "text" : "Did a factory reset on my Droid to stop ridiculous slowdowns...imagine what, they went away!",
  "id" : 108685319481729024,
  "created_at" : "2011-08-30 23:39:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108638309932216321",
  "text" : "Wedding plans ENGAGE! I feel like I'm in an episode of 24. Except there's 96 hours. And I'm not Kiefer Sutherland.",
  "id" : 108638309932216321,
  "created_at" : "2011-08-30 20:32:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 30 ],
      "url" : "http:\/\/t.co\/6v45scV",
      "expanded_url" : "http:\/\/images.icanhascheezburger.com\/completestore\/2008\/11\/16\/128713226668583807.jpg",
      "display_url" : "images.icanhascheezburger.com\/completestore\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "108633490181992448",
  "geo" : { },
  "id_str" : "108635231682179072",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette http:\/\/t.co\/6v45scV",
  "id" : 108635231682179072,
  "in_reply_to_status_id" : 108633490181992448,
  "created_at" : "2011-08-30 20:20:32 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Haney",
      "screen_name" : "notasausage",
      "indices" : [ 3, 15 ],
      "id_str" : "11718",
      "id" : 11718
    }, {
      "name" : "Wegmans Food Markets",
      "screen_name" : "Wegmans",
      "indices" : [ 73, 81 ],
      "id_str" : "66482863",
      "id" : 66482863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/RXOfANU",
      "expanded_url" : "http:\/\/newstores.wegmans.com\/Default.aspx?alias=newstores.wegmans.com\/northborough",
      "display_url" : "newstores.wegmans.com\/Default.aspx?a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "108605050208788481",
  "text" : "RT @notasausage: You Bostonians are about to get a grocery wake-up call. @Wegmans opens in Northborough on October 16th: http:\/\/t.co\/RXOfANU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wegmans Food Markets",
        "screen_name" : "Wegmans",
        "indices" : [ 56, 64 ],
        "id_str" : "66482863",
        "id" : 66482863
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 123 ],
        "url" : "http:\/\/t.co\/RXOfANU",
        "expanded_url" : "http:\/\/newstores.wegmans.com\/Default.aspx?alias=newstores.wegmans.com\/northborough",
        "display_url" : "newstores.wegmans.com\/Default.aspx?a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "108572687210782720",
    "text" : "You Bostonians are about to get a grocery wake-up call. @Wegmans opens in Northborough on October 16th: http:\/\/t.co\/RXOfANU",
    "id" : 108572687210782720,
    "created_at" : "2011-08-30 16:12:00 +0000",
    "user" : {
      "name" : "Patrick Haney",
      "screen_name" : "notasausage",
      "protected" : false,
      "id_str" : "11718",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/516633810239508480\/I9aY_yEK_normal.jpeg",
      "id" : 11718,
      "verified" : false
    }
  },
  "id" : 108605050208788481,
  "created_at" : "2011-08-30 18:20:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Le Berrigaud",
      "screen_name" : "its_damo",
      "indices" : [ 0, 9 ],
      "id_str" : "81470248",
      "id" : 81470248
    }, {
      "name" : "planckscaleservices\u2122",
      "screen_name" : "freshtonic",
      "indices" : [ 10, 21 ],
      "id_str" : "14383576",
      "id" : 14383576
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 121, 129 ],
      "id_str" : "670283",
      "id" : 670283
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 130, 138 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108579251829227520",
  "geo" : { },
  "id_str" : "108591924209922048",
  "in_reply_to_user_id" : 81470248,
  "text" : "@its_damo @freshtonic sounds like a bug, not \"pure evil\". Can you make an issue? github.com\/rubygems\/rubygems\/issues \/cc @drbrain @evanphx",
  "id" : 108591924209922048,
  "in_reply_to_status_id" : 108579251829227520,
  "created_at" : "2011-08-30 17:28:26 +0000",
  "in_reply_to_screen_name" : "its_damo",
  "in_reply_to_user_id_str" : "81470248",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108557640874987520",
  "text" : "Ahahahah \"omg NEVER GOOGLE ABSCESS\nNEVER EVER\"",
  "id" : 108557640874987520,
  "created_at" : "2011-08-30 15:12:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "reddit",
      "screen_name" : "reddit",
      "indices" : [ 100, 107 ],
      "id_str" : "811377",
      "id" : 811377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 95 ],
      "url" : "http:\/\/t.co\/oDVM8Td",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=pGQahmBx90c",
      "display_url" : "youtube.com\/watch?v=pGQahm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "108534307550789633",
  "text" : "Dog loses both its front legs from a bear trap, and is still happy as fuck. http:\/\/t.co\/oDVM8Td via @reddit",
  "id" : 108534307550789633,
  "created_at" : "2011-08-30 13:39:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Venkat Subramaniam",
      "screen_name" : "venkat_s",
      "indices" : [ 0, 9 ],
      "id_str" : "14429713",
      "id" : 14429713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108321999796969475",
  "geo" : { },
  "id_str" : "108327104529174528",
  "in_reply_to_user_id" : 14429713,
  "text" : "@venkat_s what's even worse in ruby is !!var. I just don't think most understand boolean logic, which is astounding given their job :(",
  "id" : 108327104529174528,
  "in_reply_to_status_id" : 108321999796969475,
  "created_at" : "2011-08-29 23:56:08 +0000",
  "in_reply_to_screen_name" : "venkat_s",
  "in_reply_to_user_id_str" : "14429713",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108326245577670657",
  "geo" : { },
  "id_str" : "108326568346132480",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv kill: wrong argument - me. Did you mean 'sudo kill' ?",
  "id" : 108326568346132480,
  "in_reply_to_status_id" : 108326245577670657,
  "created_at" : "2011-08-29 23:54:01 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Lindsay",
      "screen_name" : "ejlindsay",
      "indices" : [ 0, 10 ],
      "id_str" : "90351184",
      "id" : 90351184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108284412738797569",
  "geo" : { },
  "id_str" : "108284764800294912",
  "in_reply_to_user_id" : 90351184,
  "text" : "@ejlindsay i am so confused",
  "id" : 108284764800294912,
  "in_reply_to_status_id" : 108284412738797569,
  "created_at" : "2011-08-29 21:07:54 +0000",
  "in_reply_to_screen_name" : "ejlindsay",
  "in_reply_to_user_id_str" : "90351184",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/gYYVC0f",
      "expanded_url" : "http:\/\/26.media.tumblr.com\/tumblr_lk6a09Hg6i1qa1zngo1_500.gif",
      "display_url" : "26.media.tumblr.com\/tumblr_lk6a09H\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "108270968878800896",
  "text" : "Current status: http:\/\/t.co\/gYYVC0f",
  "id" : 108270968878800896,
  "created_at" : "2011-08-29 20:13:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Voss",
      "screen_name" : "seldo",
      "indices" : [ 3, 9 ],
      "id_str" : "15453",
      "id" : 15453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108261046220894209",
  "text" : "RT @seldo: Microsoft UI has officially entered the realm of self-parody: http:\/\/ljv.me\/Fn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/totally.awe.sm\" rel=\"nofollow\"\u003Eawe.sm\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "108227373970886657",
    "text" : "Microsoft UI has officially entered the realm of self-parody: http:\/\/ljv.me\/Fn",
    "id" : 108227373970886657,
    "created_at" : "2011-08-29 17:19:51 +0000",
    "user" : {
      "name" : "Laurie Voss",
      "screen_name" : "seldo",
      "protected" : false,
      "id_str" : "15453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565049845677699072\/BKdxhQWl_normal.jpeg",
      "id" : 15453,
      "verified" : false
    }
  },
  "id" : 108261046220894209,
  "created_at" : "2011-08-29 19:33:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 0, 6 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108230687999524864",
  "geo" : { },
  "id_str" : "108231220432875520",
  "in_reply_to_user_id" : 8000842,
  "text" : "@tpope you have truly created a new norm of dysfunction within this untapped market",
  "id" : 108231220432875520,
  "in_reply_to_status_id" : 108230687999524864,
  "created_at" : "2011-08-29 17:35:08 +0000",
  "in_reply_to_screen_name" : "tpope",
  "in_reply_to_user_id_str" : "8000842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 3, 9 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 89 ],
      "url" : "http:\/\/t.co\/M5kpLSA",
      "expanded_url" : "https:\/\/github.com\/tpope\/gem-browse",
      "display_url" : "github.com\/tpope\/gem-brow\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "108231092393353216",
  "text" : "RT @tpope: The command-line gem opener market is ripe for disruption! http:\/\/t.co\/M5kpLSA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 78 ],
        "url" : "http:\/\/t.co\/M5kpLSA",
        "expanded_url" : "https:\/\/github.com\/tpope\/gem-browse",
        "display_url" : "github.com\/tpope\/gem-brow\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "108230687999524864",
    "text" : "The command-line gem opener market is ripe for disruption! http:\/\/t.co\/M5kpLSA",
    "id" : 108230687999524864,
    "created_at" : "2011-08-29 17:33:01 +0000",
    "user" : {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "protected" : false,
      "id_str" : "8000842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547265874705395712\/cLZFf4tq_normal.jpeg",
      "id" : 8000842,
      "verified" : false
    }
  },
  "id" : 108231092393353216,
  "created_at" : "2011-08-29 17:34:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108230871760388096",
  "text" : "NPM, Y U NO INSTALL PACKAGES GLOBALLY BY DEFAULT? U ARE REALLY CONFUSING",
  "id" : 108230871760388096,
  "created_at" : "2011-08-29 17:33:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/1vhiw1G",
      "expanded_url" : "http:\/\/i.imgur.com\/V1uSD.gif",
      "display_url" : "i.imgur.com\/V1uSD.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "108223865586597888",
  "text" : "Current status: http:\/\/t.co\/1vhiw1G",
  "id" : 108223865586597888,
  "created_at" : "2011-08-29 17:05:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 68, 80 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 43 ],
      "url" : "http:\/\/t.co\/C6vQujP",
      "expanded_url" : "http:\/\/cdn.theatlantic.com\/static\/infocus\/irene082911\/i11_28016748.jpg",
      "display_url" : "cdn.theatlantic.com\/static\/infocus\u2026"
    }, {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/A8TlBfK",
      "expanded_url" : "http:\/\/www.theatlantic.com\/infocus\/2011\/08\/hurricane-irene\/100138\/",
      "display_url" : "theatlantic.com\/infocus\/2011\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "108214387004817408",
  "text" : "FUCK YOU I'M A CRAYFISH http:\/\/t.co\/C6vQujP \/cc http:\/\/t.co\/A8TlBfK @fredyatesiv",
  "id" : 108214387004817408,
  "created_at" : "2011-08-29 16:28:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108211853171232768",
  "geo" : { },
  "id_str" : "108212918029529088",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh all of the comments are positive. what is this twisted world we live in?",
  "id" : 108212918029529088,
  "in_reply_to_status_id" : 108211853171232768,
  "created_at" : "2011-08-29 16:22:24 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108210354047291392",
  "geo" : { },
  "id_str" : "108211516691578882",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh i love the absurdly tiny \"Share\" dialog the most.",
  "id" : 108211516691578882,
  "in_reply_to_status_id" : 108210354047291392,
  "created_at" : "2011-08-29 16:16:50 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http:\/\/t.co\/YWmB30a",
      "expanded_url" : "http:\/\/blogs.msdn.com\/b\/b8\/archive\/2011\/08\/26\/improvements-in-windows-explorer.aspx",
      "display_url" : "blogs.msdn.com\/b\/b8\/archive\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "108209825086840834",
  "text" : "Microsoft is such a joke. Spy on user data, then add MORE BUTTONS AND CHROME AND UI http:\/\/t.co\/YWmB30a",
  "id" : 108209825086840834,
  "created_at" : "2011-08-29 16:10:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/kjCRczG",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=31g0YE61PLQ",
      "display_url" : "youtube.com\/watch?v=31g0YE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "108149362433081344",
  "text" : "Current status: http:\/\/t.co\/kjCRczG",
  "id" : 108149362433081344,
  "created_at" : "2011-08-29 12:09:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108020237408026624",
  "text" : "Dog has been sleeping all day. Currently barking in his dreams. Had way too much fun with other puppies.",
  "id" : 108020237408026624,
  "created_at" : "2011-08-29 03:36:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 45 ],
      "url" : "http:\/\/t.co\/YZBCdbN",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=pZfwUwDJdV8",
      "display_url" : "youtube.com\/watch?v=pZfwUw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "107986371444097025",
  "text" : "Built in *two hours* !?!? http:\/\/t.co\/YZBCdbN",
  "id" : 107986371444097025,
  "created_at" : "2011-08-29 01:22:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 38, 45 ],
      "id_str" : "5186831",
      "id" : 5186831
    }, {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 46, 58 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 33 ],
      "url" : "http:\/\/t.co\/PR1fwq4",
      "expanded_url" : "http:\/\/i.imgur.com\/qbbSH.jpg",
      "display_url" : "i.imgur.com\/qbbSH.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "107977196760604673",
  "text" : "lol canadians http:\/\/t.co\/PR1fwq4 \/cc @lsegal @jamesgolick",
  "id" : 107977196760604673,
  "created_at" : "2011-08-29 00:45:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107942402014183424",
  "geo" : { },
  "id_str" : "107950381945987072",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser I started writing a ruby wrapper for git that would do this over a year ago...didn't go far.",
  "id" : 107950381945987072,
  "in_reply_to_status_id" : 107942402014183424,
  "created_at" : "2011-08-28 22:59:11 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Fiedler",
      "screen_name" : "kylefiedler",
      "indices" : [ 0, 12 ],
      "id_str" : "14838050",
      "id" : 14838050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107841206507147264",
  "geo" : { },
  "id_str" : "107841834876796928",
  "in_reply_to_user_id" : 14838050,
  "text" : "@kylefiedler now is not the time for playing lumberjack",
  "id" : 107841834876796928,
  "in_reply_to_status_id" : 107841206507147264,
  "created_at" : "2011-08-28 15:47:51 +0000",
  "in_reply_to_screen_name" : "kylefiedler",
  "in_reply_to_user_id_str" : "14838050",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Venkat Subramaniam",
      "screen_name" : "venkat_s",
      "indices" : [ 0, 9 ],
      "id_str" : "14429713",
      "id" : 14429713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107822978166824960",
  "geo" : { },
  "id_str" : "107825641017184259",
  "in_reply_to_user_id" : 14429713,
  "text" : "@venkat_s sadly not everyone in the industry shares this feeling :(",
  "id" : 107825641017184259,
  "in_reply_to_status_id" : 107822978166824960,
  "created_at" : "2011-08-28 14:43:30 +0000",
  "in_reply_to_screen_name" : "venkat_s",
  "in_reply_to_user_id_str" : "14429713",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107825121393250304",
  "text" : "Really glad we picked up the pup early today from the sitter trial run for the wedding. Shit is getting real outside!",
  "id" : 107825121393250304,
  "created_at" : "2011-08-28 14:41:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 47 ],
      "url" : "http:\/\/t.co\/nD3A3o4",
      "expanded_url" : "http:\/\/www.imdb.com\/chart\/bottom",
      "display_url" : "imdb.com\/chart\/bottom"
    } ]
  },
  "geo" : { },
  "id_str" : "107640164309925889",
  "text" : "How is Kazaam in this list? http:\/\/t.co\/nD3A3o4 I think if you watch all 50 movies in a row your brain will explode.",
  "id" : 107640164309925889,
  "created_at" : "2011-08-28 02:26:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107636236352630784",
  "text" : "BREAKING NEWS: It is raining. A lot. All over.",
  "id" : 107636236352630784,
  "created_at" : "2011-08-28 02:10:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107634172364984320",
  "text" : "Out of liquids. FALSE. There is way too much beer left.",
  "id" : 107634172364984320,
  "created_at" : "2011-08-28 02:02:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107630478068170752",
  "geo" : { },
  "id_str" : "107633971520745474",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene agreed, hence guides.rubygems.org. also, do you tweet anything positive, ever?",
  "id" : 107633971520745474,
  "in_reply_to_status_id" : 107630478068170752,
  "created_at" : "2011-08-28 02:01:53 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Epic Meal Time",
      "screen_name" : "EpicMealTime",
      "indices" : [ 10, 23 ],
      "id_str" : "209169572",
      "id" : 209169572
    }, {
      "name" : "Harley Morenstein",
      "screen_name" : "HarleyPlays",
      "indices" : [ 49, 61 ],
      "id_str" : "24560836",
      "id" : 24560836
    }, {
      "name" : "Muscles Glasses",
      "screen_name" : "MusclesGlasses",
      "indices" : [ 62, 77 ],
      "id_str" : "236709206",
      "id" : 236709206
    }, {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 78, 85 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 44 ],
      "url" : "http:\/\/t.co\/eJ45vc8",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=umE08FCqHEU",
      "display_url" : "youtube.com\/watch?v=umE08F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "107596392729554944",
  "text" : "Minecraft @EpicMealTime! http:\/\/t.co\/eJ45vc8 \/cc @HarleyPlays @MusclesGlasses @lsegal",
  "id" : 107596392729554944,
  "created_at" : "2011-08-27 23:32:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mbtaGM",
      "screen_name" : "mbtaGM",
      "indices" : [ 3, 10 ],
      "id_str" : "1875510546",
      "id" : 1875510546
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mbta",
      "indices" : [ 78, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107588811596369920",
  "text" : "RT @mbtaGM: All MBTA Service will be suspended Sunday due to Hurricane Irene. #mbta",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mbta",
        "indices" : [ 66, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "107585574164111360",
    "text" : "All MBTA Service will be suspended Sunday due to Hurricane Irene. #mbta",
    "id" : 107585574164111360,
    "created_at" : "2011-08-27 22:49:34 +0000",
    "user" : {
      "name" : "MBTA",
      "screen_name" : "MBTA",
      "protected" : false,
      "id_str" : "150334831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/950550372\/ProfilePic_normal.jpg",
      "id" : 150334831,
      "verified" : true
    }
  },
  "id" : 107588811596369920,
  "created_at" : "2011-08-27 23:02:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 9, 21 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107577856367931392",
  "geo" : { },
  "id_str" : "107588061503823872",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @tristandunn hangover part 3",
  "id" : 107588061503823872,
  "in_reply_to_status_id" : 107577856367931392,
  "created_at" : "2011-08-27 22:59:27 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/Jrw4lFd",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=J6z88ur-8bY",
      "display_url" : "youtube.com\/watch?v=J6z88u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "107518839067131904",
  "text" : "Current status: http:\/\/t.co\/Jrw4lFd",
  "id" : 107518839067131904,
  "created_at" : "2011-08-27 18:24:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107379108618571776",
  "text" : "Today, the pup learns that stealing and eating everything in the house for attention makes him throw up. JUST KIDDING IT'S 5AM AND HHURRRKKK",
  "id" : 107379108618571776,
  "created_at" : "2011-08-27 09:09:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107220030395129858",
  "text" : "New term ripe for disruption: untapped. This untapped bag of chips is ripe for disruption.",
  "id" : 107220030395129858,
  "created_at" : "2011-08-26 22:37:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107218764940050432",
  "geo" : { },
  "id_str" : "107219894629695488",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss this bus ride is ripe for disruption",
  "id" : 107219894629695488,
  "in_reply_to_status_id" : 107218764940050432,
  "created_at" : "2011-08-26 22:36:29 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107167350872223744",
  "geo" : { },
  "id_str" : "107172565180628992",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh no, i dont want that for sure...i'd just rather have stuff in one place.",
  "id" : 107172565180628992,
  "in_reply_to_status_id" : 107167350872223744,
  "created_at" : "2011-08-26 19:28:25 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107162013876240384",
  "text" : "Good suggestions all around for guides.rubygems.org ...will be incorporated after the wedding! (almost 1 week ZOMG @ablissfulgal!)",
  "id" : 107162013876240384,
  "created_at" : "2011-08-26 18:46:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107159170419142656",
  "geo" : { },
  "id_str" : "107159675836964864",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine where instead?",
  "id" : 107159675836964864,
  "in_reply_to_status_id" : 107159170419142656,
  "created_at" : "2011-08-26 18:37:12 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107158224205127680",
  "geo" : { },
  "id_str" : "107158366433984512",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates yeah, i'll reach out more",
  "id" : 107158366433984512,
  "in_reply_to_status_id" : 107158224205127680,
  "created_at" : "2011-08-26 18:32:00 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107143698336317440",
  "geo" : { },
  "id_str" : "107157331342655488",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates i really wish we would get contributions to github.com\/rubygems\/guides instead of random blog posts :(",
  "id" : 107157331342655488,
  "in_reply_to_status_id" : 107143698336317440,
  "created_at" : "2011-08-26 18:27:53 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 73 ],
      "url" : "http:\/\/t.co\/FfJqVtm",
      "expanded_url" : "http:\/\/bit.ly\/n8jFhe",
      "display_url" : "bit.ly\/n8jFhe"
    } ]
  },
  "geo" : { },
  "id_str" : "107155567243558912",
  "text" : "This link shortener and parser is ripe for disruption http:\/\/t.co\/FfJqVtm",
  "id" : 107155567243558912,
  "created_at" : "2011-08-26 18:20:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 64 ],
      "url" : "http:\/\/t.co\/HwgohOF",
      "expanded_url" : "http:\/\/www.hnsearch.com\/search#request\/all",
      "display_url" : "hnsearch.com\/search#request\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "107155387161133058",
  "text" : "This social news site is ripe for disruption http:\/\/t.co\/HwgohOF&q=ripe+for+disruption",
  "id" : 107155387161133058,
  "created_at" : "2011-08-26 18:20:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 25 ],
      "url" : "http:\/\/t.co\/bD9dDfj",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems\/blob\/master\/lib\/rubygems\/specification.rb#L696-700",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "107114651694792705",
  "text" : "what: http:\/\/t.co\/bD9dDfj",
  "id" : 107114651694792705,
  "created_at" : "2011-08-26 15:38:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/Vw0ACGS",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=n-TKGqA_XJg",
      "display_url" : "youtube.com\/watch?v=n-TKGq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "107066464506347520",
  "text" : "Current status: http:\/\/t.co\/Vw0ACGS",
  "id" : 107066464506347520,
  "created_at" : "2011-08-26 12:26:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106948855593054209",
  "text" : "This burger is ripe for disruption. Dude, that group of ducks is ripe for disruption. Your mom is ripe for disruption. Disruption.",
  "id" : 106948855593054209,
  "created_at" : "2011-08-26 04:39:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106948568614576128",
  "text" : "I'm going to use the phrase \"ripe for disruption\" more in normal conversation.",
  "id" : 106948568614576128,
  "created_at" : "2011-08-26 04:38:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106933905931771905",
  "geo" : { },
  "id_str" : "106947718672420864",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky DUM DUM",
  "id" : 106947718672420864,
  "in_reply_to_status_id" : 106933905931771905,
  "created_at" : "2011-08-26 04:34:57 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Ryan",
      "screen_name" : "iamdanryan",
      "indices" : [ 0, 11 ],
      "id_str" : "21336288",
      "id" : 21336288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106946749662380032",
  "geo" : { },
  "id_str" : "106947172649533440",
  "in_reply_to_user_id" : 21336288,
  "text" : "@iamdanryan not a viable business solution. If you're squatting a lot I'm not going to stand for it :)",
  "id" : 106947172649533440,
  "in_reply_to_status_id" : 106946749662380032,
  "created_at" : "2011-08-26 04:32:47 +0000",
  "in_reply_to_screen_name" : "iamdanryan",
  "in_reply_to_user_id_str" : "21336288",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106889338574479360",
  "text" : "PRINT ALL THE THINGS",
  "id" : 106889338574479360,
  "created_at" : "2011-08-26 00:42:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Bleigh",
      "screen_name" : "mbleigh",
      "indices" : [ 0, 8 ],
      "id_str" : "12025282",
      "id" : 12025282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106867636746461184",
  "geo" : { },
  "id_str" : "106872087112728576",
  "in_reply_to_user_id" : 12025282,
  "text" : "@mbleigh i'd have to understand your use case, but i feel like you may be using redis wrong ;)",
  "id" : 106872087112728576,
  "in_reply_to_status_id" : 106867636746461184,
  "created_at" : "2011-08-25 23:34:25 +0000",
  "in_reply_to_screen_name" : "mbleigh",
  "in_reply_to_user_id_str" : "12025282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Bleigh",
      "screen_name" : "mbleigh",
      "indices" : [ 0, 8 ],
      "id_str" : "12025282",
      "id" : 12025282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106866566024536064",
  "geo" : { },
  "id_str" : "106867296680673280",
  "in_reply_to_user_id" : 12025282,
  "text" : "@mbleigh whyyyyyyy",
  "id" : 106867296680673280,
  "in_reply_to_status_id" : 106866566024536064,
  "created_at" : "2011-08-25 23:15:23 +0000",
  "in_reply_to_screen_name" : "mbleigh",
  "in_reply_to_user_id_str" : "12025282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rubits (sponge)",
      "screen_name" : "mikerubits",
      "indices" : [ 3, 14 ],
      "id_str" : "18455656",
      "id" : 18455656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106847788926648320",
  "text" : "RT @mikerubits: Dang that's a lot of threat in the Northeast for the hurricane.: http:\/\/j.mp\/qePgEg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "106847446684020736",
    "text" : "Dang that's a lot of threat in the Northeast for the hurricane.: http:\/\/j.mp\/qePgEg",
    "id" : 106847446684020736,
    "created_at" : "2011-08-25 21:56:31 +0000",
    "user" : {
      "name" : "Mike Rubits (sponge)",
      "screen_name" : "mikerubits",
      "protected" : false,
      "id_str" : "18455656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2714227684\/4ec100b01543d734ceb55d1e752625f1_normal.jpeg",
      "id" : 18455656,
      "verified" : false
    }
  },
  "id" : 106847788926648320,
  "created_at" : "2011-08-25 21:57:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/qa3Ykya",
      "expanded_url" : "http:\/\/www.aboutmcdonalds.com\/etc\/medialib\/aboutMcDonalds\/image_library\/products\/core_menu.Par.41578.File.dat\/mcdonalds_bigmac.jpg",
      "display_url" : "aboutmcdonalds.com\/etc\/medialib\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "106781315403231234",
  "text" : "Current status: http:\/\/t.co\/qa3Ykya",
  "id" : 106781315403231234,
  "created_at" : "2011-08-25 17:33:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 0, 5 ],
      "id_str" : "20941662",
      "id" : 20941662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106720053516443649",
  "geo" : { },
  "id_str" : "106723009880002560",
  "in_reply_to_user_id" : 20941662,
  "text" : "@JEG2 I disagree. If they were serious\/important errors ruby should raise\/error\/fail. I'd rather the interpreter be more strict by default",
  "id" : 106723009880002560,
  "in_reply_to_status_id" : 106720053516443649,
  "created_at" : "2011-08-25 13:42:03 +0000",
  "in_reply_to_screen_name" : "JEG2",
  "in_reply_to_user_id_str" : "20941662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106537697652387840",
  "geo" : { },
  "id_str" : "106539650675519488",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg haha oops",
  "id" : 106539650675519488,
  "in_reply_to_status_id" : 106537697652387840,
  "created_at" : "2011-08-25 01:33:26 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nap.tld, ltd.",
      "screen_name" : "zapnap",
      "indices" : [ 0, 7 ],
      "id_str" : "1566201",
      "id" : 1566201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106535443515973632",
  "geo" : { },
  "id_str" : "106535559106801664",
  "in_reply_to_user_id" : 1566201,
  "text" : "@zapnap CRAAAAAAAAWWWWWLING IN YOUR SKKIIIIINNNNNNNNNNN",
  "id" : 106535559106801664,
  "in_reply_to_status_id" : 106535443515973632,
  "created_at" : "2011-08-25 01:17:11 +0000",
  "in_reply_to_screen_name" : "zapnap",
  "in_reply_to_user_id_str" : "1566201",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 8, 19 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 22, 28 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 55 ],
      "url" : "http:\/\/t.co\/Bq71qSO",
      "expanded_url" : "http:\/\/images.memegenerator.net\/instances\/500x\/9559175.jpg",
      "display_url" : "images.memegenerator.net\/instances\/500x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "106535401195450371",
  "text" : "Current @tenderlove \/ @raggi status http:\/\/t.co\/Bq71qSO",
  "id" : 106535401195450371,
  "created_at" : "2011-08-25 01:16:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106533591978221568",
  "geo" : { },
  "id_str" : "106534359133192193",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw DELICIOUS",
  "id" : 106534359133192193,
  "in_reply_to_status_id" : 106533591978221568,
  "created_at" : "2011-08-25 01:12:25 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 40, 51 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 52, 58 ],
      "id_str" : "15359408",
      "id" : 15359408
    }, {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 59, 71 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106533711754952704",
  "text" : "Sorry, my twittergument alarm went off. @tenderlove @raggi @jamesgolick &lt;3 JS is silly, -w should be on all the time. Yay!",
  "id" : 106533711754952704,
  "created_at" : "2011-08-25 01:09:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106533227182829569",
  "text" : "AWWOOOOOOGGA AWOOOOOGA TWITTER THE ARGUMENT PLATFORM SO EASY TO TRACK THREADS AND GIVE MEANINGFUL RESPONSES",
  "id" : 106533227182829569,
  "created_at" : "2011-08-25 01:07:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106533085092384768",
  "text" : "WHUPPPP WHUPPPPP WHUPPPP TWITTER ARGUMENT ALERT",
  "id" : 106533085092384768,
  "created_at" : "2011-08-25 01:07:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106533014959439872",
  "text" : "WARNING TWITTER ARGUMENT ALERT",
  "id" : 106533014959439872,
  "created_at" : "2011-08-25 01:07:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106532946445479936",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick correction. I agree with you. this is the internets, after all",
  "id" : 106532946445479936,
  "created_at" : "2011-08-25 01:06:48 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106532211892826112",
  "geo" : { },
  "id_str" : "106532790211837953",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick dude i dont think anyone is disagreeing with you. the main problem is that we all have to deal with its bullshit",
  "id" : 106532790211837953,
  "in_reply_to_status_id" : 106532211892826112,
  "created_at" : "2011-08-25 01:06:11 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 12, 18 ],
      "id_str" : "15359408",
      "id" : 15359408
    }, {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 47, 54 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106532020955512832",
  "geo" : { },
  "id_str" : "106532642039660545",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove @raggi these are both non-answers, @lsegal is correct. if it was important it wouldn't be such a widespread issue",
  "id" : 106532642039660545,
  "in_reply_to_status_id" : 106532020955512832,
  "created_at" : "2011-08-25 01:05:35 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106529806484639744",
  "geo" : { },
  "id_str" : "106530209129447424",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove not trolling. but why should we care about -w after all of this time of it not having any effect?",
  "id" : 106530209129447424,
  "in_reply_to_status_id" : 106529806484639744,
  "created_at" : "2011-08-25 00:55:55 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106514290642661377",
  "text" : "PUPPY, CHOPSTICKS ARE NOT FOOD",
  "id" : 106514290642661377,
  "created_at" : "2011-08-24 23:52:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106506106913820672",
  "geo" : { },
  "id_str" : "106506253798354944",
  "in_reply_to_user_id" : 5744442,
  "text" : "@ablissfulgal LOL i said you would kill me",
  "id" : 106506253798354944,
  "in_reply_to_status_id" : 106506106913820672,
  "created_at" : "2011-08-24 23:20:44 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106505881394483200",
  "text" : "Random lady offered me $1000 for Geddy today on the walk. And asked if I paid $10k for him. WTF?",
  "id" : 106505881394483200,
  "created_at" : "2011-08-24 23:19:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106488510432813056",
  "text" : "Forgot about C extensions...derp. thanks twitter!",
  "id" : 106488510432813056,
  "created_at" : "2011-08-24 22:10:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 93, 103 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106460559414800384",
  "geo" : { },
  "id_str" : "106486042500153344",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi gems can't run arbitrary code on install. Believe me, I tried as an install vector for @gemcutter :)",
  "id" : 106486042500153344,
  "in_reply_to_status_id" : 106460559414800384,
  "created_at" : "2011-08-24 22:00:25 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 0, 13 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106403568868786176",
  "geo" : { },
  "id_str" : "106407223172935680",
  "in_reply_to_user_id" : 11587602,
  "text" : "@wayneeseguin perfect.",
  "id" : 106407223172935680,
  "in_reply_to_status_id" : 106403568868786176,
  "created_at" : "2011-08-24 16:47:13 +0000",
  "in_reply_to_screen_name" : "wayneeseguin",
  "in_reply_to_user_id_str" : "11587602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 0, 13 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106377163871232000",
  "geo" : { },
  "id_str" : "106379691396562944",
  "in_reply_to_user_id" : 11587602,
  "text" : "@wayneeseguin i'm all for it enabled, I just can't stand the amount of spew that comes out every time i jump into a directory with .rvmrc on",
  "id" : 106379691396562944,
  "in_reply_to_status_id" : 106377163871232000,
  "created_at" : "2011-08-24 14:57:49 +0000",
  "in_reply_to_screen_name" : "wayneeseguin",
  "in_reply_to_user_id_str" : "11587602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106128329907765248",
  "geo" : { },
  "id_str" : "106131129853161472",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh damn dude, that's awesome! Walking the pups more?",
  "id" : 106131129853161472,
  "in_reply_to_status_id" : 106128329907765248,
  "created_at" : "2011-08-23 22:30:07 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "indices" : [ 0, 8 ],
      "id_str" : "19041990",
      "id" : 19041990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106087445120028672",
  "geo" : { },
  "id_str" : "106091420695277568",
  "in_reply_to_user_id" : 19041990,
  "text" : "@kkuchta you can get tgz\/zip's in their 'downloads' section",
  "id" : 106091420695277568,
  "in_reply_to_status_id" : 106087445120028672,
  "created_at" : "2011-08-23 19:52:20 +0000",
  "in_reply_to_screen_name" : "kkuchta",
  "in_reply_to_user_id_str" : "19041990",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106088174622748673",
  "text" : "I really wish cucumber would just fail early if a step wasn't defined. Most times it's a typo\/mistake, and not done intentionally.",
  "id" : 106088174622748673,
  "created_at" : "2011-08-23 19:39:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Greene",
      "screen_name" : "techiferous",
      "indices" : [ 0, 12 ],
      "id_str" : "44238666",
      "id" : 44238666
    }, {
      "name" : "Kyle Fiedler",
      "screen_name" : "kylefiedler",
      "indices" : [ 29, 41 ],
      "id_str" : "14838050",
      "id" : 14838050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106062644875759617",
  "geo" : { },
  "id_str" : "106062987168718849",
  "in_reply_to_user_id" : 44238666,
  "text" : "@techiferous same, i thought @kylefiedler was pushing our table, and felt my chair shaking",
  "id" : 106062987168718849,
  "in_reply_to_status_id" : 106062644875759617,
  "created_at" : "2011-08-23 17:59:21 +0000",
  "in_reply_to_screen_name" : "techiferous",
  "in_reply_to_user_id_str" : "44238666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 38 ],
      "url" : "http:\/\/t.co\/sqFQPcd",
      "expanded_url" : "http:\/\/earthquake.usgs.gov\/earthquakes\/recenteqsus\/Maps\/US10\/32.42.-85.-75.php",
      "display_url" : "earthquake.usgs.gov\/earthquakes\/re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "106062397462151168",
  "text" : "Wow, it was in VA: http:\/\/t.co\/sqFQPcd",
  "id" : 106062397462151168,
  "created_at" : "2011-08-23 17:57:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106061959572619264",
  "text" : "Holy fuck earthquake!!?!! in Boston!?!",
  "id" : 106061959572619264,
  "created_at" : "2011-08-23 17:55:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Fecheyr",
      "screen_name" : "andruby",
      "indices" : [ 0, 8 ],
      "id_str" : "30254806",
      "id" : 30254806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106014270021570561",
  "geo" : { },
  "id_str" : "106025765262458880",
  "in_reply_to_user_id" : 30254806,
  "text" : "@andruby not happening here",
  "id" : 106025765262458880,
  "in_reply_to_status_id" : 106014270021570561,
  "created_at" : "2011-08-23 15:31:26 +0000",
  "in_reply_to_screen_name" : "andruby",
  "in_reply_to_user_id_str" : "30254806",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105958293377265664",
  "text" : "SCUMBAG PUPPY UP AT 5:30 WHINING\n\nTOO TIRED TO MAKE WITTY MEME ENDING",
  "id" : 105958293377265664,
  "created_at" : "2011-08-23 11:03:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105853547370909696",
  "text" : "Ooh tonight it's neighbor UNCE UNCE UNCE BADOOOOM UNCE UNCE UNCE night",
  "id" : 105853547370909696,
  "created_at" : "2011-08-23 04:07:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuri Tom\u00E1nek",
      "screen_name" : "yuritomanek",
      "indices" : [ 0, 12 ],
      "id_str" : "393280472",
      "id" : 393280472
    }, {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 27, 35 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105845740949086209",
  "text" : "@yuritomanek not sure, ask @ddollar!",
  "id" : 105845740949086209,
  "created_at" : "2011-08-23 03:36:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicol\u00E1s Hock Isaza",
      "screen_name" : "nhocki",
      "indices" : [ 0, 7 ],
      "id_str" : "85498700",
      "id" : 85498700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105836322660433921",
  "geo" : { },
  "id_str" : "105845675241115648",
  "in_reply_to_user_id" : 85498700,
  "text" : "@nhocki i dont really invoice anyone dude",
  "id" : 105845675241115648,
  "in_reply_to_status_id" : 105836322660433921,
  "created_at" : "2011-08-23 03:35:50 +0000",
  "in_reply_to_screen_name" : "nhocki",
  "in_reply_to_user_id_str" : "85498700",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 112 ],
      "url" : "http:\/\/t.co\/jJyrAva",
      "expanded_url" : "http:\/\/rubycraft.org\/map\/#\/149\/64\/154\/-2\/mcmapNormal",
      "display_url" : "rubycraft.org\/map\/#\/149\/64\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "105836122038484992",
  "text" : "So many awesome structures popping up on rubycraft.org. Slow growth but it's fun to explore! http:\/\/t.co\/jJyrAva",
  "id" : 105836122038484992,
  "created_at" : "2011-08-23 02:57:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 73 ],
      "url" : "http:\/\/t.co\/MivdoMj",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=7cqOEr_yfak",
      "display_url" : "youtube.com\/watch?v=7cqOEr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "105828613668089856",
  "text" : "HE GOT TO DO A LITTLE MEDITATIN' YOU KNOW HOW DOGS IS http:\/\/t.co\/MivdoMj",
  "id" : 105828613668089856,
  "created_at" : "2011-08-23 02:28:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 14, 20 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 55 ],
      "url" : "http:\/\/t.co\/yoCytGo",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=7cqOEr_yfak",
      "display_url" : "youtube.com\/watch?v=7cqOEr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "105814122179985408",
  "text" : "RT @bquarant: @qrush dog ownership? http:\/\/t.co\/yoCytGo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 41 ],
        "url" : "http:\/\/t.co\/yoCytGo",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=7cqOEr_yfak",
        "display_url" : "youtube.com\/watch?v=7cqOEr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "105765651771166721",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush dog ownership? http:\/\/t.co\/yoCytGo",
    "id" : 105765651771166721,
    "created_at" : "2011-08-22 22:17:51 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 105814122179985408,
  "created_at" : "2011-08-23 01:30:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rubits (sponge)",
      "screen_name" : "mikerubits",
      "indices" : [ 0, 11 ],
      "id_str" : "18455656",
      "id" : 18455656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105741175612383233",
  "geo" : { },
  "id_str" : "105741367405318144",
  "in_reply_to_user_id" : 18455656,
  "text" : "@mikerubits the husky one looks unreal",
  "id" : 105741367405318144,
  "in_reply_to_status_id" : 105741175612383233,
  "created_at" : "2011-08-22 20:41:21 +0000",
  "in_reply_to_screen_name" : "mikerubits",
  "in_reply_to_user_id_str" : "18455656",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Cambridge",
      "screen_name" : "kitcambridge",
      "indices" : [ 0, 13 ],
      "id_str" : "136077128",
      "id" : 136077128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105729126295552000",
  "geo" : { },
  "id_str" : "105736052186165248",
  "in_reply_to_user_id" : 136077128,
  "text" : "@kitcambridge that's just like, my opinion, man. twitter is not a good way to debate this, use the comments or write a post! :)",
  "id" : 105736052186165248,
  "in_reply_to_status_id" : 105729126295552000,
  "created_at" : "2011-08-22 20:20:13 +0000",
  "in_reply_to_screen_name" : "kitcambridge",
  "in_reply_to_user_id_str" : "136077128",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Redpath",
      "screen_name" : "lukeredpath",
      "indices" : [ 0, 12 ],
      "id_str" : "72573",
      "id" : 72573
    }, {
      "name" : "IRCCloud",
      "screen_name" : "IRCCloud",
      "indices" : [ 13, 22 ],
      "id_str" : "171845650",
      "id" : 171845650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105732494032244736",
  "geo" : { },
  "id_str" : "105733944112189440",
  "in_reply_to_user_id" : 72573,
  "text" : "@lukeredpath @irccloud. dm me your email and i'll invite you.",
  "id" : 105733944112189440,
  "in_reply_to_status_id" : 105732494032244736,
  "created_at" : "2011-08-22 20:11:51 +0000",
  "in_reply_to_screen_name" : "lukeredpath",
  "in_reply_to_user_id_str" : "72573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Ashkenas",
      "screen_name" : "jashkenas",
      "indices" : [ 0, 10 ],
      "id_str" : "123323498",
      "id" : 123323498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105719328183300098",
  "geo" : { },
  "id_str" : "105728516049477632",
  "in_reply_to_user_id" : 123323498,
  "text" : "@jashkenas hey thanks for the comments! and i have no problems with quirkiness, just was noting my thoughts on it. :)",
  "id" : 105728516049477632,
  "in_reply_to_status_id" : 105719328183300098,
  "created_at" : "2011-08-22 19:50:17 +0000",
  "in_reply_to_screen_name" : "jashkenas",
  "in_reply_to_user_id_str" : "123323498",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Cambridge",
      "screen_name" : "kitcambridge",
      "indices" : [ 0, 13 ],
      "id_str" : "136077128",
      "id" : 136077128
    }, {
      "name" : "Dion Almaer",
      "screen_name" : "dalmaer",
      "indices" : [ 118, 126 ],
      "id_str" : "4216361",
      "id" : 4216361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105725073331204097",
  "geo" : { },
  "id_str" : "105728156979310592",
  "in_reply_to_user_id" : 136077128,
  "text" : "@kitcambridge read the source to backbone.js or underscore.js sometime. properly written JS is very verbose, imo. \/cc @dalmaer",
  "id" : 105728156979310592,
  "in_reply_to_status_id" : 105725073331204097,
  "created_at" : "2011-08-22 19:48:51 +0000",
  "in_reply_to_screen_name" : "kitcambridge",
  "in_reply_to_user_id_str" : "136077128",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105708023292493825",
  "geo" : { },
  "id_str" : "105708234689626112",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt oh man!!!",
  "id" : 105708234689626112,
  "in_reply_to_status_id" : 105708023292493825,
  "created_at" : "2011-08-22 18:29:41 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105706547090440193",
  "geo" : { },
  "id_str" : "105707049010204672",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl i read this in the old spice guy voice.",
  "id" : 105707049010204672,
  "in_reply_to_status_id" : 105706547090440193,
  "created_at" : "2011-08-22 18:24:59 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105668434599215104",
  "geo" : { },
  "id_str" : "105670195821031424",
  "in_reply_to_user_id" : 308442670,
  "text" : "@AndiRodham this is what comments are for :) there's a lively discussion on HN as well...voice your opinion!",
  "id" : 105670195821031424,
  "in_reply_to_status_id" : 105668434599215104,
  "created_at" : "2011-08-22 15:58:32 +0000",
  "in_reply_to_screen_name" : "arodham",
  "in_reply_to_user_id_str" : "308442670",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105663910610350080",
  "text" : "Achievement unlocked: #1 on HN!",
  "id" : 105663910610350080,
  "created_at" : "2011-08-22 15:33:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105663778510737408",
  "text" : "@autotelicum historical facts besides, I think you're missing the point here :)",
  "id" : 105663778510737408,
  "created_at" : "2011-08-22 15:33:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 24 ],
      "url" : "http:\/\/t.co\/DG6R6By",
      "expanded_url" : "http:\/\/www.digitaljournal.com\/article\/310645",
      "display_url" : "digitaljournal.com\/article\/310645"
    } ]
  },
  "geo" : { },
  "id_str" : "105656109817282560",
  "text" : "wat: http:\/\/t.co\/DG6R6By",
  "id" : 105656109817282560,
  "created_at" : "2011-08-22 15:02:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Hodges",
      "screen_name" : "jmhodges",
      "indices" : [ 0, 9 ],
      "id_str" : "9267272",
      "id" : 9267272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105651116913594368",
  "geo" : { },
  "id_str" : "105651582451982336",
  "in_reply_to_user_id" : 9267272,
  "text" : "@jmhodges ahhh it's in Go! :)",
  "id" : 105651582451982336,
  "in_reply_to_status_id" : 105651116913594368,
  "created_at" : "2011-08-22 14:44:34 +0000",
  "in_reply_to_screen_name" : "jmhodges",
  "in_reply_to_user_id_str" : "9267272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Hodges",
      "screen_name" : "jmhodges",
      "indices" : [ 0, 9 ],
      "id_str" : "9267272",
      "id" : 9267272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105651116913594368",
  "geo" : { },
  "id_str" : "105651391552434179",
  "in_reply_to_user_id" : 9267272,
  "text" : "@jmhodges how is this different than prettify_json.rb ?",
  "id" : 105651391552434179,
  "in_reply_to_status_id" : 105651116913594368,
  "created_at" : "2011-08-22 14:43:49 +0000",
  "in_reply_to_screen_name" : "jmhodges",
  "in_reply_to_user_id_str" : "9267272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 61 ],
      "url" : "http:\/\/t.co\/nbQYzjC",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/9251081564\/coffeescript-spartan-javascript",
      "display_url" : "robots.thoughtbot.com\/post\/925108156\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "105645366195658753",
  "text" : "RT @thoughtbot: This...is...CoffeeScript! http:\/\/t.co\/nbQYzjC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 45 ],
        "url" : "http:\/\/t.co\/nbQYzjC",
        "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/9251081564\/coffeescript-spartan-javascript",
        "display_url" : "robots.thoughtbot.com\/post\/925108156\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "105645242300104704",
    "text" : "This...is...CoffeeScript! http:\/\/t.co\/nbQYzjC",
    "id" : 105645242300104704,
    "created_at" : "2011-08-22 14:19:23 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 105645366195658753,
  "created_at" : "2011-08-22 14:19:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nikki graziano",
      "screen_name" : "nikkigraziano",
      "indices" : [ 34, 48 ],
      "id_str" : "12914422",
      "id" : 12914422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 28 ],
      "url" : "http:\/\/t.co\/uYjncZt",
      "expanded_url" : "http:\/\/28.media.tumblr.com\/tumblr_lqb9nlVOUE1qz5t6ro1_500.png",
      "display_url" : "28.media.tumblr.com\/tumblr_lqb9nlV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "105637937089220609",
  "text" : "So true: http:\/\/t.co\/uYjncZt (via @nikkigraziano)",
  "id" : 105637937089220609,
  "created_at" : "2011-08-22 13:50:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105480033065385984",
  "geo" : { },
  "id_str" : "105610608124231680",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant awesome. let me know if you need help. railstutorial.org is good too",
  "id" : 105610608124231680,
  "in_reply_to_status_id" : 105480033065385984,
  "created_at" : "2011-08-22 12:01:45 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 40 ],
      "url" : "http:\/\/t.co\/WiuUmMX",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1gvMwCEdhCs",
      "display_url" : "youtube.com\/watch?v=1gvMwC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "105260573209530368",
  "text" : "Seriously woke up to http:\/\/t.co\/WiuUmMX in my head, in this guy's voice.",
  "id" : 105260573209530368,
  "created_at" : "2011-08-21 12:50:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http:\/\/t.co\/abBCbNE",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/Pets\/comments\/jp8b4\/how_my_10_month_old_husky_deals_with_me_talking\/",
      "display_url" : "reddit.com\/r\/Pets\/comment\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "105076255136825344",
  "geo" : { },
  "id_str" : "105257902595506176",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw you weren't the only one with this analysis http:\/\/t.co\/abBCbNE",
  "id" : 105257902595506176,
  "in_reply_to_status_id" : 105076255136825344,
  "created_at" : "2011-08-21 12:40:14 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 39 ],
      "url" : "http:\/\/t.co\/R8h1utw",
      "expanded_url" : "http:\/\/i.imgur.com\/wMMUM.jpg",
      "display_url" : "i.imgur.com\/wMMUM.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "105075549709402112",
  "text" : "Current dog status: http:\/\/t.co\/R8h1utw",
  "id" : 105075549709402112,
  "created_at" : "2011-08-21 00:35:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104999567442984960",
  "text" : "I don't have enough twitter\/ruby folk on xbox live. My handle is Doctor Q. Add me!",
  "id" : 104999567442984960,
  "created_at" : "2011-08-20 19:33:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conferenshish",
      "screen_name" : "tundal45",
      "indices" : [ 0, 9 ],
      "id_str" : "5573992",
      "id" : 5573992
    }, {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 10, 24 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 44 ],
      "url" : "http:\/\/t.co\/aSmG5Sl",
      "expanded_url" : "http:\/\/guides.rubygems.org",
      "display_url" : "guides.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "104727222060986368",
  "geo" : { },
  "id_str" : "104757606651920384",
  "in_reply_to_user_id" : 5573992,
  "text" : "@tundal45 @garybernhardt http:\/\/t.co\/aSmG5Sl",
  "id" : 104757606651920384,
  "in_reply_to_status_id" : 104727222060986368,
  "created_at" : "2011-08-20 03:32:14 +0000",
  "in_reply_to_screen_name" : "tundal45",
  "in_reply_to_user_id_str" : "5573992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 0, 10 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104686157840912384",
  "geo" : { },
  "id_str" : "104686506710540288",
  "in_reply_to_user_id" : 23830105,
  "text" : "@joedamato you've been outed, fuck ruby is the codesign of The Guild",
  "id" : 104686506710540288,
  "in_reply_to_status_id" : 104686157840912384,
  "created_at" : "2011-08-19 22:49:42 +0000",
  "in_reply_to_screen_name" : "joedamato",
  "in_reply_to_user_id_str" : "23830105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104681892875468800",
  "geo" : { },
  "id_str" : "104686034998136832",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal I fail at typing. SHMOWZOW!",
  "id" : 104686034998136832,
  "in_reply_to_status_id" : 104681892875468800,
  "created_at" : "2011-08-19 22:47:50 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104681892875468800",
  "geo" : { },
  "id_str" : "104685922905374720",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal RHOMBUS\u00DF",
  "id" : 104685922905374720,
  "in_reply_to_status_id" : 104681892875468800,
  "created_at" : "2011-08-19 22:47:23 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/Ub1JJ0V",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/tumblr_lq3tuw2IGe1qkecs9o1_500.gif",
      "display_url" : "24.media.tumblr.com\/tumblr_lq3tuw2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "104659393735426048",
  "text" : "Current status: http:\/\/t.co\/Ub1JJ0V",
  "id" : 104659393735426048,
  "created_at" : "2011-08-19 21:01:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104636311306121216",
  "text" : "Awesome hailstorm in downtown boston right now, hail around the size of M&M's!",
  "id" : 104636311306121216,
  "created_at" : "2011-08-19 19:30:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Tanksley",
      "screen_name" : "charlietanksley",
      "indices" : [ 0, 16 ],
      "id_str" : "124224684",
      "id" : 124224684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104609177393049601",
  "geo" : { },
  "id_str" : "104622027008258048",
  "in_reply_to_user_id" : 124224684,
  "text" : "@charlietanksley aghhh...can you make an issue on help.rubygems.org please?",
  "id" : 104622027008258048,
  "in_reply_to_status_id" : 104609177393049601,
  "created_at" : "2011-08-19 18:33:29 +0000",
  "in_reply_to_screen_name" : "charlietanksley",
  "in_reply_to_user_id_str" : "124224684",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104619525345001473",
  "text" : "What's even better is that he's listening to a TAPE DECK.",
  "id" : 104619525345001473,
  "created_at" : "2011-08-19 18:23:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 42 ],
      "url" : "http:\/\/t.co\/WiuUmMX",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1gvMwCEdhCs",
      "display_url" : "youtube.com\/watch?v=1gvMwC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "104618696303063041",
  "text" : "I WANNA TAKE YOU THERE http:\/\/t.co\/WiuUmMX",
  "id" : 104618696303063041,
  "created_at" : "2011-08-19 18:20:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 60 ],
      "url" : "http:\/\/t.co\/vXZjVOk",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ZffTZ-Qc-JU",
      "display_url" : "youtube.com\/watch?v=ZffTZ-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "104616767497846784",
  "text" : "PUT YOUR HANDS UP UHHHH NYUHHHHHHHHHHHHH http:\/\/t.co\/vXZjVOk",
  "id" : 104616767497846784,
  "created_at" : "2011-08-19 18:12:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dogs doing things",
      "screen_name" : "dogsdoingthings",
      "indices" : [ 14, 30 ],
      "id_str" : "124863907",
      "id" : 124863907
    }, {
      "name" : "bros",
      "screen_name" : "two_bros",
      "indices" : [ 35, 44 ],
      "id_str" : "316808468",
      "id" : 316808468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104570182634180608",
  "text" : "i really hope @dogsdoingthings and @two_bros are really just the same dude",
  "id" : 104570182634180608,
  "created_at" : "2011-08-19 15:07:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/wJ4rrLl",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=dM76zgOQDD8",
      "display_url" : "youtube.com\/watch?v=dM76zg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "104563989329084416",
  "text" : "Current status: http:\/\/t.co\/wJ4rrLl",
  "id" : 104563989329084416,
  "created_at" : "2011-08-19 14:42:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Norris",
      "screen_name" : "rsl",
      "indices" : [ 0, 4 ],
      "id_str" : "82863",
      "id" : 82863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104550337528070144",
  "geo" : { },
  "id_str" : "104551880239235073",
  "in_reply_to_user_id" : 82863,
  "text" : "@rsl seriously, i dont get it either",
  "id" : 104551880239235073,
  "in_reply_to_status_id" : 104550337528070144,
  "created_at" : "2011-08-19 13:54:45 +0000",
  "in_reply_to_screen_name" : "rsl",
  "in_reply_to_user_id_str" : "82863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104417254900375552",
  "text" : "Tonight's neighborly eurorussian dance party is brought to you by UNCE UNCE UNCE and COUGH HACK BLEHHHHHHH COUGH",
  "id" : 104417254900375552,
  "created_at" : "2011-08-19 04:59:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 24 ],
      "url" : "http:\/\/t.co\/C11QaDB",
      "expanded_url" : "https:\/\/rubygems.org\/gems\/happygirl",
      "display_url" : "rubygems.org\/gems\/happygirl"
    } ]
  },
  "geo" : { },
  "id_str" : "104264645203853312",
  "text" : "wat: http:\/\/t.co\/C11QaDB",
  "id" : 104264645203853312,
  "created_at" : "2011-08-18 18:53:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howland",
      "screen_name" : "backslash",
      "indices" : [ 0, 10 ],
      "id_str" : "8161622",
      "id" : 8161622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104223958110453760",
  "geo" : { },
  "id_str" : "104225542663966720",
  "in_reply_to_user_id" : 8161622,
  "text" : "@backslash just wait under endermen :X are you on rubycraft.org yet? :) rubycraft.org\/map",
  "id" : 104225542663966720,
  "in_reply_to_status_id" : 104223958110453760,
  "created_at" : "2011-08-18 16:18:00 +0000",
  "in_reply_to_screen_name" : "backslash",
  "in_reply_to_user_id_str" : "8161622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104171284384067585",
  "text" : "Apparently my dog thinks I'm made of peanut butter.",
  "id" : 104171284384067585,
  "created_at" : "2011-08-18 12:42:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104170769684246528",
  "geo" : { },
  "id_str" : "104171059997192192",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape i am incapable of feeling anger, captain",
  "id" : 104171059997192192,
  "in_reply_to_status_id" : 104170769684246528,
  "created_at" : "2011-08-18 12:41:30 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104059354562564096",
  "text" : "Meetings are \"fucking toxic\", but in TNG there's meetings every episode and it's fucking awesome. Meetings without Picard are fucking toxic.",
  "id" : 104059354562564096,
  "created_at" : "2011-08-18 05:17:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boom Haackalacka",
      "screen_name" : "haacked",
      "indices" : [ 0, 8 ],
      "id_str" : "768197",
      "id" : 768197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104054995174948864",
  "geo" : { },
  "id_str" : "104058560056532992",
  "in_reply_to_user_id" : 768197,
  "text" : "@haacked thanks :)",
  "id" : 104058560056532992,
  "in_reply_to_status_id" : 104054995174948864,
  "created_at" : "2011-08-18 05:14:28 +0000",
  "in_reply_to_screen_name" : "haacked",
  "in_reply_to_user_id_str" : "768197",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http:\/\/t.co\/zFSiCUr",
      "expanded_url" : "http:\/\/www.dotnetcurry.com\/ShowArticle.aspx?ID=747",
      "display_url" : "dotnetcurry.com\/ShowArticle.as\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "104040080020209664",
  "text" : "I don't care how slow Ruby is to start\/run or how big Rails' stack trace is, but thank fuck I don't do this anymore http:\/\/t.co\/zFSiCUr",
  "id" : 104040080020209664,
  "created_at" : "2011-08-18 04:01:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 61, 77 ],
      "id_str" : "46852648",
      "id" : 46852648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 55 ],
      "url" : "http:\/\/t.co\/0i7b8rc",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?NR=1&v=Y9Ajb4omtac",
      "display_url" : "youtube.com\/watch?NR=1&v=Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "104036588392161280",
  "text" : "OMG EVEN BETTER, WAIT FOR THE TRUCK http:\/\/t.co\/0i7b8rc (via @postmodern_mod3)",
  "id" : 104036588392161280,
  "created_at" : "2011-08-18 03:47:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 44 ],
      "url" : "http:\/\/t.co\/Ktsq1r8",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=RF7kwv9UaGU&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=RF7kwv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "104029826645622784",
  "text" : "I WANT TO PLAY THIS GAME http:\/\/t.co\/Ktsq1r8 (via @kcgeep)",
  "id" : 104029826645622784,
  "created_at" : "2011-08-18 03:20:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104015431475539968",
  "geo" : { },
  "id_str" : "104015990320406528",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu pfft, i'd rather use ubuntu than Lion right now. i see no reason to upgrade and suffer with broken apps",
  "id" : 104015990320406528,
  "in_reply_to_status_id" : 104015431475539968,
  "created_at" : "2011-08-18 02:25:19 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 51, 59 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104014546875858944",
  "geo" : { },
  "id_str" : "104015778835210240",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier find . | grep '.png' | xargs open (\/cc @sikachu)",
  "id" : 104015778835210240,
  "in_reply_to_status_id" : 104014546875858944,
  "created_at" : "2011-08-18 02:24:28 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104012222832967680",
  "geo" : { },
  "id_str" : "104013636435050496",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier find . | grep *.png ?",
  "id" : 104013636435050496,
  "in_reply_to_status_id" : 104012222832967680,
  "created_at" : "2011-08-18 02:15:58 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 39 ],
      "url" : "http:\/\/t.co\/E39fID2",
      "expanded_url" : "https:\/\/img.skitch.com\/20110818-kb6jr1rfijf4d8wr8wt3pc414m.png",
      "display_url" : "img.skitch.com\/20110818-kb6jr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "103996088196931584",
  "text" : "Current dog status: http:\/\/t.co\/E39fID2",
  "id" : 103996088196931584,
  "created_at" : "2011-08-18 01:06:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/slLQIjh",
      "expanded_url" : "http:\/\/i.i.com.com\/cnwk.1d\/i\/tim\/2010\/11\/03\/Jesse-Thornhill008.jpg",
      "display_url" : "i.i.com.com\/cnwk.1d\/i\/tim\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "103954264652656640",
  "text" : "Current status: http:\/\/t.co\/slLQIjh",
  "id" : 103954264652656640,
  "created_at" : "2011-08-17 22:20:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103948457999474688",
  "text" : "TESTS Y U NO PASS?",
  "id" : 103948457999474688,
  "created_at" : "2011-08-17 21:56:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/zPMwR37",
      "expanded_url" : "http:\/\/www.bestweekever.tv\/bwe\/images\/2010\/02\/CAPYBARA-READING-GLASSES.jpg",
      "display_url" : "bestweekever.tv\/bwe\/images\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "103933026114867200",
  "text" : "Current status: http:\/\/t.co\/zPMwR37",
  "id" : 103933026114867200,
  "created_at" : "2011-08-17 20:55:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Werner Vogels",
      "screen_name" : "Werner",
      "indices" : [ 0, 7 ],
      "id_str" : "113963",
      "id" : 113963
    }, {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 8, 16 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103927125345697792",
  "geo" : { },
  "id_str" : "103929008902774784",
  "in_reply_to_user_id" : 113963,
  "text" : "@Werner @mojombo that's awesome!! glad to see my haphazard design for jekyllrb.com appear somewhere else :)",
  "id" : 103929008902774784,
  "in_reply_to_status_id" : 103927125345697792,
  "created_at" : "2011-08-17 20:39:41 +0000",
  "in_reply_to_screen_name" : "Werner",
  "in_reply_to_user_id_str" : "113963",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BostonTweet",
      "screen_name" : "BostonTweet",
      "indices" : [ 0, 12 ],
      "id_str" : "17531205",
      "id" : 17531205
    }, {
      "name" : "Kate Peruzzini",
      "screen_name" : "KeightP",
      "indices" : [ 13, 21 ],
      "id_str" : "18247553",
      "id" : 18247553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103895606782738432",
  "geo" : { },
  "id_str" : "103921174471389185",
  "in_reply_to_user_id" : 17531205,
  "text" : "@BostonTweet @KeightP the redbones and clover trucks are *awesome* !",
  "id" : 103921174471389185,
  "in_reply_to_status_id" : 103895606782738432,
  "created_at" : "2011-08-17 20:08:33 +0000",
  "in_reply_to_screen_name" : "BostonTweet",
  "in_reply_to_user_id_str" : "17531205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 41, 46 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103878270176604160",
  "text" : "I am amazed that after all of this time, @woot does still not auto-refresh.",
  "id" : 103878270176604160,
  "created_at" : "2011-08-17 17:18:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Norris",
      "screen_name" : "rsl",
      "indices" : [ 0, 4 ],
      "id_str" : "82863",
      "id" : 82863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103843906227142656",
  "geo" : { },
  "id_str" : "103844652943286272",
  "in_reply_to_user_id" : 82863,
  "text" : "@rsl herp derp",
  "id" : 103844652943286272,
  "in_reply_to_status_id" : 103843906227142656,
  "created_at" : "2011-08-17 15:04:29 +0000",
  "in_reply_to_screen_name" : "rsl",
  "in_reply_to_user_id_str" : "82863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103838720238690305",
  "geo" : { },
  "id_str" : "103839104357249024",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant fucking smart!!",
  "id" : 103839104357249024,
  "in_reply_to_status_id" : 103838720238690305,
  "created_at" : "2011-08-17 14:42:26 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seana q.",
      "screen_name" : "ladysauce",
      "indices" : [ 0, 10 ],
      "id_str" : "14955094",
      "id" : 14955094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103834235625930752",
  "geo" : { },
  "id_str" : "103835144841994240",
  "in_reply_to_user_id" : 14955094,
  "text" : "@ladysauce everything is better cold",
  "id" : 103835144841994240,
  "in_reply_to_status_id" : 103834235625930752,
  "created_at" : "2011-08-17 14:26:42 +0000",
  "in_reply_to_screen_name" : "ladysauce",
  "in_reply_to_user_id_str" : "14955094",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103833360878682113",
  "text" : "why havent i put clif bars in the fridge yet?!?!?!?!",
  "id" : 103833360878682113,
  "created_at" : "2011-08-17 14:19:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 0, 7 ],
      "id_str" : "3928731",
      "id" : 3928731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103829171486203905",
  "geo" : { },
  "id_str" : "103832971815034880",
  "in_reply_to_user_id" : 3928731,
  "text" : "@cssboy clearly you havent played nethack or dwarf fortress yet...",
  "id" : 103832971815034880,
  "in_reply_to_status_id" : 103829171486203905,
  "created_at" : "2011-08-17 14:18:04 +0000",
  "in_reply_to_screen_name" : "cssboy",
  "in_reply_to_user_id_str" : "3928731",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103828144657666051",
  "text" : "Sad or awesome: I need a new phone soon, and considering now getting an Xperia so I can play Minecraft.",
  "id" : 103828144657666051,
  "created_at" : "2011-08-17 13:58:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/FAiRal5",
      "expanded_url" : "http:\/\/i.imgur.com\/UotrU.gif",
      "display_url" : "i.imgur.com\/UotrU.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "103827421823901697",
  "text" : "Current status: http:\/\/t.co\/FAiRal5",
  "id" : 103827421823901697,
  "created_at" : "2011-08-17 13:56:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 21, 33 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 54 ],
      "url" : "http:\/\/t.co\/BbxYuPO",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=gMnG3gOqigE",
      "display_url" : "youtube.com\/watch?v=gMnG3g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "103680454288343041",
  "text" : "This one goes out to @doctorzaius. http:\/\/t.co\/BbxYuPO",
  "id" : 103680454288343041,
  "created_at" : "2011-08-17 04:12:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http:\/\/t.co\/Iw881nE",
      "expanded_url" : "http:\/\/digi-6.com\/archives\/51754179.html",
      "display_url" : "digi-6.com\/archives\/51754\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "103585117217357824",
  "text" : "Cat how did you get here you are not good with paintings http:\/\/t.co\/Iw881nE",
  "id" : 103585117217357824,
  "created_at" : "2011-08-16 21:53:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 32 ],
      "url" : "http:\/\/t.co\/mEcmU04",
      "expanded_url" : "http:\/\/www.layoutlounge.com\/Images\/Thanks_For_The_Add\/images\/borat-sexy-time.jpg",
      "display_url" : "layoutlounge.com\/Images\/Thanks_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "103582241929699328",
  "geo" : { },
  "id_str" : "103584336674172929",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv http:\/\/t.co\/mEcmU04",
  "id" : 103584336674172929,
  "in_reply_to_status_id" : 103582241929699328,
  "created_at" : "2011-08-16 21:50:05 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103568948645199872",
  "text" : "coffeescript....feels good man",
  "id" : 103568948645199872,
  "created_at" : "2011-08-16 20:48:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103528158216728576",
  "text" : "Current vim status: :sp spec\/models\/ass",
  "id" : 103528158216728576,
  "created_at" : "2011-08-16 18:06:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/pjMj84X",
      "expanded_url" : "http:\/\/thechive.files.wordpress.com\/2010\/03\/steve-jobs-food-41-e1269449029590.jpg",
      "display_url" : "thechive.files.wordpress.com\/2010\/03\/steve-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "103519832686870530",
  "text" : "Current status: http:\/\/t.co\/pjMj84X",
  "id" : 103519832686870530,
  "created_at" : "2011-08-16 17:33:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103494809842491392",
  "text" : "GitHub merge button: killing git rebase -i one push at a time",
  "id" : 103494809842491392,
  "created_at" : "2011-08-16 15:54:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "indices" : [ 0, 8 ],
      "id_str" : "6532552",
      "id" : 6532552
    }, {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 19, 28 ],
      "id_str" : "6980232",
      "id" : 6980232
    }, {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 30, 41 ],
      "id_str" : "14555937",
      "id" : 14555937
    }, {
      "name" : "Kyle Fiedler",
      "screen_name" : "kylefiedler",
      "indices" : [ 47, 59 ],
      "id_str" : "14838050",
      "id" : 14838050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103482423270060034",
  "geo" : { },
  "id_str" : "103487862032441344",
  "in_reply_to_user_id" : 6532552,
  "text" : "@nkohari very sure @ubuwaits, @phillapier, and @kylefiedler painstakingly smelted together every pixel on their own :)",
  "id" : 103487862032441344,
  "in_reply_to_status_id" : 103482423270060034,
  "created_at" : "2011-08-16 15:26:43 +0000",
  "in_reply_to_screen_name" : "nkohari",
  "in_reply_to_user_id_str" : "6532552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Suggs",
      "screen_name" : "ktheory",
      "indices" : [ 0, 8 ],
      "id_str" : "1696",
      "id" : 1696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103460968847257600",
  "geo" : { },
  "id_str" : "103471591559659521",
  "in_reply_to_user_id" : 1696,
  "text" : "@ktheory we could toss it on the production.cf.rubygems.org bucket...at least to prove the speed improvements",
  "id" : 103471591559659521,
  "in_reply_to_status_id" : 103460968847257600,
  "created_at" : "2011-08-16 14:22:04 +0000",
  "in_reply_to_screen_name" : "ktheory",
  "in_reply_to_user_id_str" : "1696",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Pavoni",
      "screen_name" : "apeacox",
      "indices" : [ 0, 8 ],
      "id_str" : "83554278",
      "id" : 83554278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103464181491175425",
  "geo" : { },
  "id_str" : "103470564643053568",
  "in_reply_to_user_id" : 83554278,
  "text" : "@apeacox ha, @ablissfulgal has noted this but i'm not sure I believe her",
  "id" : 103470564643053568,
  "in_reply_to_status_id" : 103464181491175425,
  "created_at" : "2011-08-16 14:17:59 +0000",
  "in_reply_to_screen_name" : "apeacox",
  "in_reply_to_user_id_str" : "83554278",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Pavoni",
      "screen_name" : "apeacox",
      "indices" : [ 0, 8 ],
      "id_str" : "83554278",
      "id" : 83554278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103455090744102912",
  "geo" : { },
  "id_str" : "103461746160836610",
  "in_reply_to_user_id" : 83554278,
  "text" : "@apeacox heh, I have it covered bro. Usually do 30-40 min walks every morning.",
  "id" : 103461746160836610,
  "in_reply_to_status_id" : 103455090744102912,
  "created_at" : "2011-08-16 13:42:57 +0000",
  "in_reply_to_screen_name" : "apeacox",
  "in_reply_to_user_id_str" : "83554278",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seana q.",
      "screen_name" : "ladysauce",
      "indices" : [ 0, 10 ],
      "id_str" : "14955094",
      "id" : 14955094
    }, {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 11, 18 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103450567879311360",
  "geo" : { },
  "id_str" : "103453803365408768",
  "in_reply_to_user_id" : 14955094,
  "text" : "@ladysauce @jmazzi its a pencil, no idea where he got it from.",
  "id" : 103453803365408768,
  "in_reply_to_status_id" : 103450567879311360,
  "created_at" : "2011-08-16 13:11:23 +0000",
  "in_reply_to_screen_name" : "ladysauce",
  "in_reply_to_user_id_str" : "14955094",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Pavoni",
      "screen_name" : "apeacox",
      "indices" : [ 0, 8 ],
      "id_str" : "83554278",
      "id" : 83554278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103450969479712768",
  "geo" : { },
  "id_str" : "103453627066236928",
  "in_reply_to_user_id" : 83554278,
  "text" : "@apeacox he has plenty of toys...but they're all spread out. Going on a collection tonight.",
  "id" : 103453627066236928,
  "in_reply_to_status_id" : 103450969479712768,
  "created_at" : "2011-08-16 13:10:41 +0000",
  "in_reply_to_screen_name" : "apeacox",
  "in_reply_to_user_id_str" : "83554278",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 65 ],
      "url" : "http:\/\/t.co\/0B7FARd",
      "expanded_url" : "http:\/\/yfrog.com\/h3hu6lvj",
      "display_url" : "yfrog.com\/h3hu6lvj"
    } ]
  },
  "geo" : { },
  "id_str" : "103450084674514944",
  "text" : "Puppy terrorism is a threat to the homefront. http:\/\/t.co\/0B7FARd",
  "id" : 103450084674514944,
  "created_at" : "2011-08-16 12:56:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103322171568422912",
  "geo" : { },
  "id_str" : "103323266231439360",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil its funny how the use of git changes pre understanding rebase (and the DAG in general) and after",
  "id" : 103323266231439360,
  "in_reply_to_status_id" : 103322171568422912,
  "created_at" : "2011-08-16 04:32:40 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103322171568422912",
  "geo" : { },
  "id_str" : "103323101672128512",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil seriously. It's the magic chef's knife of git. Slice and dice them anyway you want, combine, reword...it's fantastic",
  "id" : 103323101672128512,
  "in_reply_to_status_id" : 103322171568422912,
  "created_at" : "2011-08-16 04:32:01 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 78 ],
      "url" : "http:\/\/t.co\/aHNJR9C",
      "expanded_url" : "https:\/\/img.skitch.com\/20110816-k7cj9nya8wa9q55td6mct6wwty.png",
      "display_url" : "img.skitch.com\/20110816-k7cj9\u2026"
    }, {
      "indices" : [ 79, 98 ],
      "url" : "http:\/\/t.co\/Pf20jmz",
      "expanded_url" : "http:\/\/rubycraft.org\/map\/#\/291\/64\/11\/-3\/mcmapNormal",
      "display_url" : "rubycraft.org\/map\/#\/291\/64\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "103277386992320512",
  "text" : "Lots of neat roads and structures added to rubycraft.org!  http:\/\/t.co\/aHNJR9C http:\/\/t.co\/Pf20jmz",
  "id" : 103277386992320512,
  "created_at" : "2011-08-16 01:30:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103224891905552384",
  "text" : "@daniel_amselem dude holy shit. watch your six",
  "id" : 103224891905552384,
  "created_at" : "2011-08-15 22:01:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Ridgeway",
      "screen_name" : "Ang3lFir3",
      "indices" : [ 0, 10 ],
      "id_str" : "7792122",
      "id" : 7792122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103204102317682688",
  "geo" : { },
  "id_str" : "103205851933847552",
  "in_reply_to_user_id" : 7792122,
  "text" : "@Ang3lFir3 thanks! :) needs updates whenever i figure out how to make the earth's rotation slow down",
  "id" : 103205851933847552,
  "in_reply_to_status_id" : 103204102317682688,
  "created_at" : "2011-08-15 20:46:07 +0000",
  "in_reply_to_screen_name" : "Ang3lFir3",
  "in_reply_to_user_id_str" : "7792122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Tann",
      "screen_name" : "egtann",
      "indices" : [ 0, 7 ],
      "id_str" : "2319552288",
      "id" : 2319552288
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 22, 33 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103203068883124224",
  "text" : "@egtann actually most @thoughtbot folks use vim, even the designers. surprise!",
  "id" : 103203068883124224,
  "created_at" : "2011-08-15 20:35:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103192151122382849",
  "geo" : { },
  "id_str" : "103193152495681536",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh haha seriously. but this is awesome for simple edits, especially for markdown",
  "id" : 103193152495681536,
  "in_reply_to_status_id" : 103192151122382849,
  "created_at" : "2011-08-15 19:55:39 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 54 ],
      "url" : "http:\/\/t.co\/HCZH8UV",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=hTRjIdoblAA",
      "display_url" : "youtube.com\/watch?v=hTRjId\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "103183442933596161",
  "text" : "Yep, it's dubstep. Dubstep lyrics. http:\/\/t.co\/HCZH8UV",
  "id" : 103183442933596161,
  "created_at" : "2011-08-15 19:17:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 17, 25 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http:\/\/t.co\/e86rxnO",
      "expanded_url" : "http:\/\/jettingrubyist.com\/",
      "display_url" : "jettingrubyist.com"
    } ]
  },
  "geo" : { },
  "id_str" : "103160170561019905",
  "text" : "This is awesome. @rubiety is a jetting rubyist! If you're in any of these cities, pair\/cowork with him! http:\/\/t.co\/e86rxnO",
  "id" : 103160170561019905,
  "created_at" : "2011-08-15 17:44:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Carmelo Briones",
      "screen_name" : "ryanbriones",
      "indices" : [ 0, 12 ],
      "id_str" : "6144652",
      "id" : 6144652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103136721197219840",
  "geo" : { },
  "id_str" : "103137492336775168",
  "in_reply_to_user_id" : 6144652,
  "text" : "@ryanbriones I'm in the Mensch district, and apparently so!",
  "id" : 103137492336775168,
  "in_reply_to_status_id" : 103136721197219840,
  "created_at" : "2011-08-15 16:14:29 +0000",
  "in_reply_to_screen_name" : "ryanbriones",
  "in_reply_to_user_id_str" : "6144652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 46 ],
      "url" : "http:\/\/t.co\/Lyn6813",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/8954362596\/font-battle-2011",
      "display_url" : "robots.thoughtbot.com\/post\/895436259\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "103135693601128448",
  "text" : "FONTDAY FONTDAY FONTDAY!!! http:\/\/t.co\/Lyn6813",
  "id" : 103135693601128448,
  "created_at" : "2011-08-15 16:07:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 3, 9 ],
      "id_str" : "35803",
      "id" : 35803
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 89, 102 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 103, 110 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 84 ],
      "url" : "http:\/\/t.co\/lH9LdYl",
      "expanded_url" : "http:\/\/mattt.me\/2011\/08\/empathy-and-open-source",
      "display_url" : "mattt.me\/2011\/08\/empath\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "103112714846609408",
  "text" : "RT @mattt: \"Because We're All Persons\": Empathy and Open Source: http:\/\/t.co\/lH9LdYl \/cc @steveklabnik @wycats",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Dream of the 90s",
        "screen_name" : "steveklabnik",
        "indices" : [ 78, 91 ],
        "id_str" : "22386062",
        "id" : 22386062
      }, {
        "name" : "Yehuda Katz",
        "screen_name" : "wycats",
        "indices" : [ 92, 99 ],
        "id_str" : "8526432",
        "id" : 8526432
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 73 ],
        "url" : "http:\/\/t.co\/lH9LdYl",
        "expanded_url" : "http:\/\/mattt.me\/2011\/08\/empathy-and-open-source",
        "display_url" : "mattt.me\/2011\/08\/empath\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "103111488356622336",
    "text" : "\"Because We're All Persons\": Empathy and Open Source: http:\/\/t.co\/lH9LdYl \/cc @steveklabnik @wycats",
    "id" : 103111488356622336,
    "created_at" : "2011-08-15 14:31:09 +0000",
    "user" : {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "protected" : false,
      "id_str" : "35803",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3573863306\/5333c08eae9005dd7a8cdd478202c818_normal.jpeg",
      "id" : 35803,
      "verified" : false
    }
  },
  "id" : 103112714846609408,
  "created_at" : "2011-08-15 14:36:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pennyarcade",
      "indices" : [ 20, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 52 ],
      "url" : "http:\/\/t.co\/fkdsci1",
      "expanded_url" : "http:\/\/penny-arcade.com\/comic\/2011\/08\/15",
      "display_url" : "penny-arcade.com\/comic\/2011\/08\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "103103810775433217",
  "text" : "Our Connected World #pennyarcade http:\/\/t.co\/fkdsci1",
  "id" : 103103810775433217,
  "created_at" : "2011-08-15 14:00:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 50 ],
      "url" : "http:\/\/t.co\/2HICWQG",
      "expanded_url" : "http:\/\/madebyevan.com\/webgl-water\/",
      "display_url" : "madebyevan.com\/webgl-water\/"
    } ]
  },
  "geo" : { },
  "id_str" : "102841604309651456",
  "text" : "Can flash be dead yet? Please? http:\/\/t.co\/2HICWQG",
  "id" : 102841604309651456,
  "created_at" : "2011-08-14 20:38:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102810899143864320",
  "geo" : { },
  "id_str" : "102825339704713216",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano not if the beers are $9 each",
  "id" : 102825339704713216,
  "in_reply_to_status_id" : 102810899143864320,
  "created_at" : "2011-08-14 19:34:06 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http:\/\/t.co\/E8iwy2K",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=bYwH4WrZhpY",
      "display_url" : "youtube.com\/watch?v=bYwH4W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "102814517431517184",
  "text" : "...how...how do people have time for this much minecraft http:\/\/t.co\/E8iwy2K",
  "id" : 102814517431517184,
  "created_at" : "2011-08-14 18:51:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 59 ],
      "url" : "http:\/\/t.co\/Uy1L21b",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Uo5Rhn8zuPA",
      "display_url" : "youtube.com\/watch?v=Uo5Rhn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "102565153182187520",
  "text" : "Possibly the best synopsis of DBZ ever: http:\/\/t.co\/Uy1L21b",
  "id" : 102565153182187520,
  "created_at" : "2011-08-14 02:20:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/YaQ0W0R",
      "expanded_url" : "http:\/\/i.imgur.com\/Ctgkv.gif",
      "display_url" : "i.imgur.com\/Ctgkv.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "102564190081916928",
  "text" : "Current status: http:\/\/t.co\/YaQ0W0R",
  "id" : 102564190081916928,
  "created_at" : "2011-08-14 02:16:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 105 ],
      "url" : "http:\/\/t.co\/nEPhmOc",
      "expanded_url" : "https:\/\/img.skitch.com\/20110813-n3c382tq6br47e1pf92qyw6yww.png",
      "display_url" : "img.skitch.com\/20110813-n3c38\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "102235094000992256",
  "text" : "Copied a minecraft youtube and made a cabinet thing with minecarts and powered track. http:\/\/t.co\/nEPhmOc",
  "id" : 102235094000992256,
  "created_at" : "2011-08-13 04:28:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102166487434936321",
  "geo" : { },
  "id_str" : "102176993327595520",
  "in_reply_to_user_id" : 14308987,
  "text" : "@deryldoucette I thought you were talking about factory girl. Derp",
  "id" : 102176993327595520,
  "in_reply_to_status_id" : 102166487434936321,
  "created_at" : "2011-08-13 00:37:48 +0000",
  "in_reply_to_screen_name" : "daviddwdowney",
  "in_reply_to_user_id_str" : "14308987",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    }, {
      "name" : "Eric Davis",
      "screen_name" : "edavis10",
      "indices" : [ 15, 24 ],
      "id_str" : "9695352",
      "id" : 9695352
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 33, 44 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102158786952826880",
  "geo" : { },
  "id_str" : "102163768540282880",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt @edavis10 I think @thoughtbot has a braintree fake somewhere...we've talked about a \"fakes\" gem",
  "id" : 102163768540282880,
  "in_reply_to_status_id" : 102158786952826880,
  "created_at" : "2011-08-12 23:45:15 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102134151947354112",
  "geo" : { },
  "id_str" : "102163475471667200",
  "in_reply_to_user_id" : 14308987,
  "text" : "@deryldoucette why? Obviously I'm biased, just trying to understand",
  "id" : 102163475471667200,
  "in_reply_to_status_id" : 102134151947354112,
  "created_at" : "2011-08-12 23:44:05 +0000",
  "in_reply_to_screen_name" : "daviddwdowney",
  "in_reply_to_user_id_str" : "14308987",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 0, 10 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102133338353041410",
  "in_reply_to_user_id" : 23830105,
  "text" : "@joedamato something something something ruby something something",
  "id" : 102133338353041410,
  "created_at" : "2011-08-12 21:44:20 +0000",
  "in_reply_to_screen_name" : "joedamato",
  "in_reply_to_user_id_str" : "23830105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102128156978319360",
  "geo" : { },
  "id_str" : "102128467147104256",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt that's going to cause internal GE damage at some point",
  "id" : 102128467147104256,
  "in_reply_to_status_id" : 102128156978319360,
  "created_at" : "2011-08-12 21:24:58 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 54 ],
      "url" : "http:\/\/t.co\/7CMh7hB",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/8835133151\/never-fear-traits-are-here",
      "display_url" : "robots.thoughtbot.com\/post\/883513315\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "102128373563789312",
  "text" : "FactoryGirl continues to kick ass. http:\/\/t.co\/7CMh7hB",
  "id" : 102128373563789312,
  "created_at" : "2011-08-12 21:24:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klondike Gold",
      "screen_name" : "Klondike",
      "indices" : [ 0, 9 ],
      "id_str" : "298070410",
      "id" : 298070410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102108381820628992",
  "geo" : { },
  "id_str" : "102108789003649024",
  "in_reply_to_user_id" : 5232171,
  "text" : "@Klondike making an AWESOME DECISION. wish i could go.",
  "id" : 102108789003649024,
  "in_reply_to_status_id" : 102108381820628992,
  "created_at" : "2011-08-12 20:06:47 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/xRlcKpX",
      "expanded_url" : "http:\/\/s3.amazonaws.com\/wootsaleimages\/Where_the_Wild_Parties_At_v8fDetail.png",
      "display_url" : "s3.amazonaws.com\/wootsaleimages\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "102085515829977088",
  "text" : "Current status: http:\/\/t.co\/xRlcKpX",
  "id" : 102085515829977088,
  "created_at" : "2011-08-12 18:34:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Wilson",
      "screen_name" : "hypomodern",
      "indices" : [ 0, 11 ],
      "id_str" : "13394402",
      "id" : 13394402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102048258481856513",
  "geo" : { },
  "id_str" : "102048843528536065",
  "in_reply_to_user_id" : 13394402,
  "text" : "@hypomodern the landing page once you sign in? and if you rm ~\/.gem\/credentials it will refetch the api token and ask you to sign in",
  "id" : 102048843528536065,
  "in_reply_to_status_id" : 102048258481856513,
  "created_at" : "2011-08-12 16:08:34 +0000",
  "in_reply_to_screen_name" : "hypomodern",
  "in_reply_to_user_id_str" : "13394402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Wilson",
      "screen_name" : "hypomodern",
      "indices" : [ 0, 11 ],
      "id_str" : "13394402",
      "id" : 13394402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101677764255547393",
  "geo" : { },
  "id_str" : "102047691156107264",
  "in_reply_to_user_id" : 13394402,
  "text" : "@hypomodern hi, no? how can we make this easier?",
  "id" : 102047691156107264,
  "in_reply_to_status_id" : 101677764255547393,
  "created_at" : "2011-08-12 16:04:00 +0000",
  "in_reply_to_screen_name" : "hypomodern",
  "in_reply_to_user_id_str" : "13394402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102045124724391936",
  "text" : "Like one Beatles song on pandora: SPEND WEEKS BANNING EVERY FUCKING BEATLES SONG FROM THE STATION",
  "id" : 102045124724391936,
  "created_at" : "2011-08-12 15:53:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102041914085359617",
  "geo" : { },
  "id_str" : "102042148534358016",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh this is bullshit though, why do i have to do that or hack git symbolic-ref HEAD to get something *EVERYONE USES IN THEIR SHELL*",
  "id" : 102042148534358016,
  "in_reply_to_status_id" : 102041914085359617,
  "created_at" : "2011-08-12 15:41:58 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 39 ],
      "url" : "http:\/\/t.co\/NuA5VSi",
      "expanded_url" : "http:\/\/malcolm816.com\/_sites\/youlaughyoulose\/wp-content\/uploads\/2011\/07\/pug-eyes-derp.jpg",
      "display_url" : "malcolm816.com\/_sites\/youlaug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "102041550921539585",
  "text" : "Actually more like: http:\/\/t.co\/NuA5VSi",
  "id" : 102041550921539585,
  "created_at" : "2011-08-12 15:39:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/0UcUuSZ",
      "expanded_url" : "http:\/\/chzderp.files.wordpress.com\/2010\/08\/89980bd4-6b9e-42e1-a59e-7736d3abe135.jpg",
      "display_url" : "chzderp.files.wordpress.com\/2010\/08\/89980b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "102041490691342337",
  "text" : "Current status: http:\/\/t.co\/0UcUuSZ",
  "id" : 102041490691342337,
  "created_at" : "2011-08-12 15:39:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102040604220993536",
  "geo" : { },
  "id_str" : "102041464883789824",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil oh. i meant in git. HERP DERP DERP",
  "id" : 102041464883789824,
  "in_reply_to_status_id" : 102040604220993536,
  "created_at" : "2011-08-12 15:39:15 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray Krueger",
      "screen_name" : "raykrueger",
      "indices" : [ 0, 11 ],
      "id_str" : "5778932",
      "id" : 5778932
    }, {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 12, 21 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102039664176791552",
  "geo" : { },
  "id_str" : "102040357361029121",
  "in_reply_to_user_id" : 5778932,
  "text" : "@raykrueger @marcweil wtf? i want something like git branch --current to work",
  "id" : 102040357361029121,
  "in_reply_to_status_id" : 102039664176791552,
  "created_at" : "2011-08-12 15:34:51 +0000",
  "in_reply_to_screen_name" : "raykrueger",
  "in_reply_to_user_id_str" : "5778932",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102038179632250880",
  "text" : "oh, and still tab aligning `git remote -v`. SOMEDAY",
  "id" : 102038179632250880,
  "created_at" : "2011-08-12 15:26:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102037997683343361",
  "text" : "Every single blog post\/code snippet to find the current branch in vim is a disgrace. This might be my first git patch to write.",
  "id" : 102037997683343361,
  "created_at" : "2011-08-12 15:25:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 68 ],
      "url" : "http:\/\/t.co\/VJE3VZ3",
      "expanded_url" : "http:\/\/gunshowcomic.com\/429",
      "display_url" : "gunshowcomic.com\/429"
    } ]
  },
  "geo" : { },
  "id_str" : "102037541926080513",
  "text" : "RT @kcgeep: rt: its a gunshow about today's nwes http:\/\/t.co\/VJE3VZ3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 56 ],
        "url" : "http:\/\/t.co\/VJE3VZ3",
        "expanded_url" : "http:\/\/gunshowcomic.com\/429",
        "display_url" : "gunshowcomic.com\/429"
      } ]
    },
    "geo" : { },
    "id_str" : "102035078993027072",
    "text" : "rt: its a gunshow about today's nwes http:\/\/t.co\/VJE3VZ3",
    "id" : 102035078993027072,
    "created_at" : "2011-08-12 15:13:53 +0000",
    "user" : {
      "name" : "kc gr\u0259\u0259n",
      "screen_name" : "kcgreenn",
      "protected" : false,
      "id_str" : "16522244",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573812132753620992\/Hmui3IXO_normal.jpeg",
      "id" : 16522244,
      "verified" : false
    }
  },
  "id" : 102037541926080513,
  "created_at" : "2011-08-12 15:23:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Savage",
      "screen_name" : "donttrythis",
      "indices" : [ 5, 17 ],
      "id_str" : "15661871",
      "id" : 15661871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 38 ],
      "url" : "http:\/\/t.co\/O2HqeWf",
      "expanded_url" : "http:\/\/i.imgur.com\/ACl35.jpg",
      "display_url" : "i.imgur.com\/ACl35.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "102032259619627008",
  "text" : "Poor @donttrythis! http:\/\/t.co\/O2HqeWf",
  "id" : 102032259619627008,
  "created_at" : "2011-08-12 15:02:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lsrc",
      "indices" : [ 10, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102027467434373120",
  "text" : "anyone at #lsrc know if there's a live feed of the talks?",
  "id" : 102027467434373120,
  "created_at" : "2011-08-12 14:43:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102027416268062720",
  "text" : "@lsrc hey is there a live feed?",
  "id" : 102027416268062720,
  "created_at" : "2011-08-12 14:43:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Giroir",
      "screen_name" : "kelsin5",
      "indices" : [ 0, 8 ],
      "id_str" : "62958126",
      "id" : 62958126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101997479075123202",
  "geo" : { },
  "id_str" : "102012942635122688",
  "in_reply_to_user_id" : 62958126,
  "text" : "@kelsin5 sign in and hit \"edit\" on your gem. this is shitty, but gem metadata has been in the works for like 2-3 years :\/",
  "id" : 102012942635122688,
  "in_reply_to_status_id" : 101997479075123202,
  "created_at" : "2011-08-12 13:45:55 +0000",
  "in_reply_to_screen_name" : "kelsin5",
  "in_reply_to_user_id_str" : "62958126",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Downie",
      "screen_name" : "richdownie",
      "indices" : [ 0, 11 ],
      "id_str" : "10774712",
      "id" : 10774712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101970452586577920",
  "geo" : { },
  "id_str" : "101981623637123072",
  "in_reply_to_user_id" : 10774712,
  "text" : "@richdownie this or YYZ might actually work",
  "id" : 101981623637123072,
  "in_reply_to_status_id" : 101970452586577920,
  "created_at" : "2011-08-12 11:41:28 +0000",
  "in_reply_to_screen_name" : "richdownie",
  "in_reply_to_user_id_str" : "10774712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 97, 116 ]
    }, {
      "text" : "suggestionswelcome",
      "indices" : [ 117, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101840222932828161",
  "text" : "Figured out our awesome entrance song for the reception, need another for the rest of the party. #firstworldproblems #suggestionswelcome",
  "id" : 101840222932828161,
  "created_at" : "2011-08-12 02:19:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101835595441115137",
  "geo" : { },
  "id_str" : "101839092949594113",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil just wait until you use god to kill unicorn",
  "id" : 101839092949594113,
  "in_reply_to_status_id" : 101835595441115137,
  "created_at" : "2011-08-12 02:15:06 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/KHd5jl7",
      "expanded_url" : "http:\/\/30.media.tumblr.com\/tumblr_lpow2aDTS51qz9bwro1_500.jpg",
      "display_url" : "30.media.tumblr.com\/tumblr_lpow2aD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "101838661519278080",
  "text" : "Current status: http:\/\/t.co\/KHd5jl7",
  "id" : 101838661519278080,
  "created_at" : "2011-08-12 02:13:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101778675204243456",
  "text" : "My photo booth experiment of Geddy crated all day resulted in 8 hours of sleeping dog footage. Will try to speed up and youtube for lulz.",
  "id" : 101778675204243456,
  "created_at" : "2011-08-11 22:15:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101774911370043392",
  "geo" : { },
  "id_str" : "101777107419545600",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius trying it from north station, will try to save you a seat!",
  "id" : 101777107419545600,
  "in_reply_to_status_id" : 101774911370043392,
  "created_at" : "2011-08-11 22:08:47 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101757165810888705",
  "geo" : { },
  "id_str" : "101757651498700800",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson what was wrong with rvm?",
  "id" : 101757651498700800,
  "in_reply_to_status_id" : 101757165810888705,
  "created_at" : "2011-08-11 20:51:29 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101490670426013696",
  "geo" : { },
  "id_str" : "101492271580577792",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant definitely! sorry bro",
  "id" : 101492271580577792,
  "in_reply_to_status_id" : 101490670426013696,
  "created_at" : "2011-08-11 03:16:57 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 31 ],
      "url" : "http:\/\/t.co\/wSwyiu3",
      "expanded_url" : "http:\/\/youtube.com\/user\/mkdevo",
      "display_url" : "youtube.com\/user\/mkdevo"
    } ]
  },
  "in_reply_to_status_id_str" : "101488583424221186",
  "geo" : { },
  "id_str" : "101490585784954880",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape http:\/\/t.co\/wSwyiu3",
  "id" : 101490585784954880,
  "in_reply_to_status_id" : 101488583424221186,
  "created_at" : "2011-08-11 03:10:15 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 44, 51 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 55, 66 ],
      "id_str" : "14555937",
      "id" : 14555937
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 67, 73 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 38 ],
      "url" : "http:\/\/t.co\/8da98Qo",
      "expanded_url" : "http:\/\/vimeo.com\/25949762",
      "display_url" : "vimeo.com\/25949762"
    } ]
  },
  "geo" : { },
  "id_str" : "101486482304405504",
  "text" : "BEACH BALL ATTACK! http:\/\/t.co\/8da98Qo (via @croaky) (+@phillapier @cmeik)",
  "id" : 101486482304405504,
  "created_at" : "2011-08-11 02:53:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Fiedler",
      "screen_name" : "kylefiedler",
      "indices" : [ 0, 12 ],
      "id_str" : "14838050",
      "id" : 14838050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101473834816913408",
  "geo" : { },
  "id_str" : "101480454120673282",
  "in_reply_to_user_id" : 14838050,
  "text" : "@kylefiedler gmail does this too",
  "id" : 101480454120673282,
  "in_reply_to_status_id" : 101473834816913408,
  "created_at" : "2011-08-11 02:30:00 +0000",
  "in_reply_to_screen_name" : "kylefiedler",
  "in_reply_to_user_id_str" : "14838050",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u277A\u27A0 David Copeland",
      "screen_name" : "davetron5000",
      "indices" : [ 0, 13 ],
      "id_str" : "5660222",
      "id" : 5660222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 33 ],
      "url" : "http:\/\/t.co\/wOCFEAl",
      "expanded_url" : "http:\/\/rubydoc.info",
      "display_url" : "rubydoc.info"
    } ]
  },
  "in_reply_to_status_id_str" : "101478992539942912",
  "geo" : { },
  "id_str" : "101480183877468160",
  "in_reply_to_user_id" : 5660222,
  "text" : "@davetron5000 http:\/\/t.co\/wOCFEAl",
  "id" : 101480183877468160,
  "in_reply_to_status_id" : 101478992539942912,
  "created_at" : "2011-08-11 02:28:55 +0000",
  "in_reply_to_screen_name" : "davetron5000",
  "in_reply_to_user_id_str" : "5660222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 58 ],
      "url" : "http:\/\/t.co\/7UWoeHb",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=9osaA68xMts",
      "display_url" : "youtube.com\/watch?v=9osaA6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "101480140629999616",
  "text" : "Well, found my next minecraft project: http:\/\/t.co\/7UWoeHb",
  "id" : 101480140629999616,
  "created_at" : "2011-08-11 02:28:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Rockstar Developer",
      "screen_name" : "cjno",
      "indices" : [ 55, 60 ],
      "id_str" : "17198807",
      "id" : 17198807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101421856380289024",
  "geo" : { },
  "id_str" : "101422143916609537",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi just started using it today, pretty dece. Thanks @cjno!",
  "id" : 101422143916609537,
  "in_reply_to_status_id" : 101421856380289024,
  "created_at" : "2011-08-10 22:38:18 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101421937489739776",
  "text" : "Heard someone speaking (that's real time conversation, fyi) about Heello on the red line. What is this universe we live in?",
  "id" : 101421937489739776,
  "created_at" : "2011-08-10 22:37:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101407079427866624",
  "geo" : { },
  "id_str" : "101407816534851584",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv there's a \"favorite\" button for a reason. or \"blowjob\", or whatever they've named it on heello",
  "id" : 101407816534851584,
  "in_reply_to_status_id" : 101407079427866624,
  "created_at" : "2011-08-10 21:41:22 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seaofclouds",
      "screen_name" : "seaofclouds",
      "indices" : [ 0, 12 ],
      "id_str" : "689983",
      "id" : 689983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101403067576094721",
  "geo" : { },
  "id_str" : "101403232600993792",
  "in_reply_to_user_id" : 689983,
  "text" : "@seaofclouds this is the best explanation yet",
  "id" : 101403232600993792,
  "in_reply_to_status_id" : 101403067576094721,
  "created_at" : "2011-08-10 21:23:09 +0000",
  "in_reply_to_screen_name" : "seaofclouds",
  "in_reply_to_user_id_str" : "689983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/Bqkf6nP",
      "expanded_url" : "http:\/\/heello.com\/live",
      "display_url" : "heello.com\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "101398784692584448",
  "text" : "http:\/\/t.co\/Bqkf6nP is kind of hilarious to watch, i'll give it that",
  "id" : 101398784692584448,
  "created_at" : "2011-08-10 21:05:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101398377379540992",
  "text" : "Ok, so they renamed \"retweet\" to \"echo\". $10 million in VC funding INCOMING",
  "id" : 101398377379540992,
  "created_at" : "2011-08-10 21:03:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/heello.com\" rel=\"nofollow\"\u003EHeello\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101397845864751104",
  "text" : "AM I DOING THIS RIGHT? http:\/\/heello.me\/3n1",
  "id" : 101397845864751104,
  "created_at" : "2011-08-10 21:01:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 95 ],
      "url" : "http:\/\/t.co\/uwOcGVq",
      "expanded_url" : "http:\/\/heello.com\/qrush\/4717",
      "display_url" : "heello.com\/qrush\/4717"
    } ]
  },
  "geo" : { },
  "id_str" : "101397144614875136",
  "text" : "I really, really, don't get this service. Why did they reimplement Twitter? http:\/\/t.co\/uwOcGVq",
  "id" : 101397144614875136,
  "created_at" : "2011-08-10 20:58:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 40 ],
      "url" : "http:\/\/t.co\/hr7qteZ",
      "expanded_url" : "http:\/\/www.phpied.com\/files\/location-location\/location-location.html",
      "display_url" : "phpied.com\/files\/location\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "101320691051274240",
  "text" : "FUCK YEAH JAVASCRIPT http:\/\/t.co\/hr7qteZ",
  "id" : 101320691051274240,
  "created_at" : "2011-08-10 15:55:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101304271550681088",
  "text" : "Someone at gnu.org needs to restart their fileserver, or make the tube bigger. downloads from ftp.gnu.org aren't working.",
  "id" : 101304271550681088,
  "created_at" : "2011-08-10 14:49:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxim Chernyak",
      "screen_name" : "hakunin",
      "indices" : [ 0, 8 ],
      "id_str" : "11622052",
      "id" : 11622052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101145692818505730",
  "geo" : { },
  "id_str" : "101289916536848384",
  "in_reply_to_user_id" : 11622052,
  "text" : "@hakunin sounds complicated and time-consuming, basically a curated gem source. surprise me!",
  "id" : 101289916536848384,
  "in_reply_to_status_id" : 101145692818505730,
  "created_at" : "2011-08-10 13:52:52 +0000",
  "in_reply_to_screen_name" : "hakunin",
  "in_reply_to_user_id_str" : "11622052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxim Chernyak",
      "screen_name" : "hakunin",
      "indices" : [ 0, 8 ],
      "id_str" : "11622052",
      "id" : 11622052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101080222241271808",
  "geo" : { },
  "id_str" : "101144743857238017",
  "in_reply_to_user_id" : 11622052,
  "text" : "@hakunin wha? How does that differ from now?",
  "id" : 101144743857238017,
  "in_reply_to_status_id" : 101080222241271808,
  "created_at" : "2011-08-10 04:16:00 +0000",
  "in_reply_to_screen_name" : "hakunin",
  "in_reply_to_user_id_str" : "11622052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 97 ],
      "url" : "http:\/\/t.co\/UCSFTWI",
      "expanded_url" : "https:\/\/img.skitch.com\/20110810-1x6q5bm84uxc1w3wrr47nkup4s.png",
      "display_url" : "img.skitch.com\/20110810-1x6q5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "101140776519598081",
  "text" : "Tonight's rubycraft.org project: start digging awesome holes around the keep! http:\/\/t.co\/UCSFTWI",
  "id" : 101140776519598081,
  "created_at" : "2011-08-10 04:00:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101121422147059713",
  "geo" : { },
  "id_str" : "101121708588666880",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits if you want to offer your services for a DESIGN REVIEW of said PROGRAM please DIRECT MESSAGE me",
  "id" : 101121708588666880,
  "in_reply_to_status_id" : 101121422147059713,
  "created_at" : "2011-08-10 02:44:28 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101120729545850880",
  "geo" : { },
  "id_str" : "101121385841168384",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape well that's just like, your opinion, man",
  "id" : 101121385841168384,
  "in_reply_to_status_id" : 101120729545850880,
  "created_at" : "2011-08-10 02:43:11 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The League",
      "screen_name" : "theleagueof",
      "indices" : [ 73, 85 ],
      "id_str" : "50412295",
      "id" : 50412295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101120603825774592",
  "text" : "This wedding program brought to you by Chunk Five and Linden Hill. &lt;3 @theleagueof",
  "id" : 101120603825774592,
  "created_at" : "2011-08-10 02:40:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101102243679436800",
  "geo" : { },
  "id_str" : "101120256008912896",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms YES THAT IS A COMPLETELY LEGITIMATE NAME. @ablissfulgal SHOULD BE IN AGREEMENT.",
  "id" : 101120256008912896,
  "in_reply_to_status_id" : 101102243679436800,
  "created_at" : "2011-08-10 02:38:42 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Calvin Hansen",
      "screen_name" : "SavageHands",
      "indices" : [ 3, 15 ],
      "id_str" : "961077037",
      "id" : 961077037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 44 ],
      "url" : "http:\/\/t.co\/PoJEq0Y",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=I-dCkEa4rGU",
      "display_url" : "youtube.com\/watch?v=I-dCkE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "101082386695069696",
  "text" : "RT @SavageHands: FINALLY http:\/\/t.co\/PoJEq0Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 27 ],
        "url" : "http:\/\/t.co\/PoJEq0Y",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=I-dCkEa4rGU",
        "display_url" : "youtube.com\/watch?v=I-dCkE\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "101069338655735808",
    "text" : "FINALLY http:\/\/t.co\/PoJEq0Y",
    "id" : 101069338655735808,
    "created_at" : "2011-08-09 23:16:22 +0000",
    "user" : {
      "name" : "ANCIENT SOVEREIGN ",
      "screen_name" : "heyitsmecalvin",
      "protected" : false,
      "id_str" : "16516351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568345745695076352\/LGkqTcN__normal.png",
      "id" : 16516351,
      "verified" : false
    }
  },
  "id" : 101082386695069696,
  "created_at" : "2011-08-10 00:08:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101077724004761600",
  "geo" : { },
  "id_str" : "101082075318329344",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms hell yeah we did. @ablissfulgal was in complete agreement. In unrelated news, my say in kid naming may be diminished",
  "id" : 101082075318329344,
  "in_reply_to_status_id" : 101077724004761600,
  "created_at" : "2011-08-10 00:06:59 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101076979293487104",
  "text" : "Another blurry Geddy pic, showcasing how terrible the droid is syncing flash with its camera shutter! http:\/\/yfrog.com\/h0qnoqrj",
  "id" : 101076979293487104,
  "created_at" : "2011-08-09 23:46:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101039351571550208",
  "geo" : { },
  "id_str" : "101039745513168896",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss at least it's still available to download! you should bundle pack everything anyway",
  "id" : 101039745513168896,
  "in_reply_to_status_id" : 101039351571550208,
  "created_at" : "2011-08-09 21:18:47 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101024989062496256",
  "geo" : { },
  "id_str" : "101036934243164161",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape it was you writing the VB in the original one, wasnt it",
  "id" : 101036934243164161,
  "in_reply_to_status_id" : 101024989062496256,
  "created_at" : "2011-08-09 21:07:36 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Newland",
      "screen_name" : "onewland",
      "indices" : [ 0, 9 ],
      "id_str" : "22040390",
      "id" : 22040390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101025010403119105",
  "geo" : { },
  "id_str" : "101025769437925376",
  "in_reply_to_user_id" : 22040390,
  "text" : "@onewland yep, it's basically the code equivalent of a bathroom wall",
  "id" : 101025769437925376,
  "in_reply_to_status_id" : 101025010403119105,
  "created_at" : "2011-08-09 20:23:15 +0000",
  "in_reply_to_screen_name" : "onewland",
  "in_reply_to_user_id_str" : "22040390",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 60 ],
      "url" : "http:\/\/t.co\/SyRUnsn",
      "expanded_url" : "http:\/\/stypi.com\/o3axkoso",
      "display_url" : "stypi.com\/o3axkoso"
    } ]
  },
  "geo" : { },
  "id_str" : "101024134233980928",
  "text" : "Ok, experiment #2: only write valid XML! http:\/\/t.co\/SyRUnsn",
  "id" : 101024134233980928,
  "created_at" : "2011-08-09 20:16:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 32 ],
      "url" : "http:\/\/t.co\/wSwyiu3",
      "expanded_url" : "http:\/\/youtube.com\/user\/mkdevo",
      "display_url" : "youtube.com\/user\/mkdevo"
    } ]
  },
  "in_reply_to_status_id_str" : "101022706555822080",
  "geo" : { },
  "id_str" : "101023505524588544",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik dude. http:\/\/t.co\/wSwyiu3",
  "id" : 101023505524588544,
  "in_reply_to_status_id" : 101022706555822080,
  "created_at" : "2011-08-09 20:14:15 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101017908418838528",
  "text" : "Ok, definitely broke it.",
  "id" : 101017908418838528,
  "created_at" : "2011-08-09 19:52:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 45 ],
      "url" : "http:\/\/t.co\/wWBSscq",
      "expanded_url" : "http:\/\/www.stypi.com\/ybeoxewx",
      "display_url" : "stypi.com\/ybeoxewx"
    } ]
  },
  "geo" : { },
  "id_str" : "101013328201134081",
  "text" : "OH GOD...WHAT HAVE I DONE http:\/\/t.co\/wWBSscq",
  "id" : 101013328201134081,
  "created_at" : "2011-08-09 19:33:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/wWBSscq",
      "expanded_url" : "http:\/\/www.stypi.com\/ybeoxewx",
      "display_url" : "stypi.com\/ybeoxewx"
    } ]
  },
  "geo" : { },
  "id_str" : "101011807916916736",
  "text" : "Well, under 5 minutes in and there's already a dingdong. This possibly couldn't get any worse. http:\/\/t.co\/wWBSscq",
  "id" : 101011807916916736,
  "created_at" : "2011-08-09 19:27:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101010523633614848",
  "text" : "Apparently Stypi doesn't remember syntax settings.",
  "id" : 101010523633614848,
  "created_at" : "2011-08-09 19:22:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http:\/\/t.co\/hPlpeLr",
      "expanded_url" : "http:\/\/stypi.com\/ybeoxewx",
      "display_url" : "stypi.com\/ybeoxewx"
    } ]
  },
  "geo" : { },
  "id_str" : "101010430390059009",
  "text" : "Let's have an experiment...RUBY SANDBOX 2011! Add code but don't remove any! http:\/\/t.co\/hPlpeLr",
  "id" : 101010430390059009,
  "created_at" : "2011-08-09 19:22:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100976325015244800",
  "geo" : { },
  "id_str" : "100977906989285376",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape play some cannibal corpse next",
  "id" : 100977906989285376,
  "in_reply_to_status_id" : 100976325015244800,
  "created_at" : "2011-08-09 17:13:03 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 50 ],
      "url" : "http:\/\/t.co\/wO7WIQj",
      "expanded_url" : "http:\/\/i.imgur.com\/G3HAx.jpg",
      "display_url" : "i.imgur.com\/G3HAx.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "100972782795501569",
  "text" : "Ahaha \"lead rioter identified\" http:\/\/t.co\/wO7WIQj",
  "id" : 100972782795501569,
  "created_at" : "2011-08-09 16:52:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Kane Parker",
      "screen_name" : "moonmaster9000",
      "indices" : [ 3, 18 ],
      "id_str" : "14391298",
      "id" : 14391298
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 20, 26 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100748200016752640",
  "text" : "RT @moonmaster9000: @qrush and mothers, sisters, daughters, and wives.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "100724970786787328",
    "geo" : { },
    "id_str" : "100730016656142337",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush and mothers, sisters, daughters, and wives.",
    "id" : 100730016656142337,
    "in_reply_to_status_id" : 100724970786787328,
    "created_at" : "2011-08-09 00:48:02 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Matthew Kane Parker",
      "screen_name" : "moonmaster9000",
      "protected" : false,
      "id_str" : "14391298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261567469295\/7aaefdfaa226cbe768f5dd475b3aa665_normal.jpeg",
      "id" : 14391298,
      "verified" : false
    }
  },
  "id" : 100748200016752640,
  "created_at" : "2011-08-09 02:00:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100724970786787328",
  "text" : "My thoughts are with firemen out late tonight in London, thanks to a few jerks. These firemen are fathers, brothers, sons, and husbands.",
  "id" : 100724970786787328,
  "created_at" : "2011-08-09 00:27:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100716405665710081",
  "text" : "Current status: http:\/\/yfrog.com\/h64dmjkj",
  "id" : 100716405665710081,
  "created_at" : "2011-08-08 23:53:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 30 ],
      "url" : "http:\/\/t.co\/HFw4fY8",
      "expanded_url" : "http:\/\/i.imgur.com\/pTY7k.jpg",
      "display_url" : "i.imgur.com\/pTY7k.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "100688948539559936",
  "text" : "AAAGGGLLK! http:\/\/t.co\/HFw4fY8",
  "id" : 100688948539559936,
  "created_at" : "2011-08-08 22:04:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Kreeftmeijer",
      "screen_name" : "jkreeftmeijer",
      "indices" : [ 0, 14 ],
      "id_str" : "8284992",
      "id" : 8284992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100631745212317696",
  "geo" : { },
  "id_str" : "100650704275914752",
  "in_reply_to_user_id" : 8284992,
  "text" : "@jkreeftmeijer ehhh... whats wrong with push? aliases are confusing enough. but feel free to submit a patch to github.com\/rubygems\/rubygems",
  "id" : 100650704275914752,
  "in_reply_to_status_id" : 100631745212317696,
  "created_at" : "2011-08-08 19:32:52 +0000",
  "in_reply_to_screen_name" : "jkreeftmeijer",
  "in_reply_to_user_id_str" : "8284992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/2QpA2Us",
      "expanded_url" : "http:\/\/images.cheezburger.com\/completestore\/2011\/1\/25\/576f4777-b9c3-4639-9f42-e20320677028.jpg",
      "display_url" : "images.cheezburger.com\/completestore\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "100629960330457088",
  "text" : "Current status: http:\/\/t.co\/2QpA2Us",
  "id" : 100629960330457088,
  "created_at" : "2011-08-08 18:10:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100610108022730752",
  "text" : "It's simple, if I mention said person CC'd in the email and actually CC'd them, REPLY TO ALL.",
  "id" : 100610108022730752,
  "created_at" : "2011-08-08 16:51:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100609787951190016",
  "text" : "Is it just me, or do all non-technical people not understand CC and BCC on emails?",
  "id" : 100609787951190016,
  "created_at" : "2011-08-08 16:50:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100600348837818368",
  "geo" : { },
  "id_str" : "100600629222842368",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove hit me with a thread, I will +1 it with the fury of 1000 suns",
  "id" : 100600629222842368,
  "in_reply_to_status_id" : 100600348837818368,
  "created_at" : "2011-08-08 16:13:53 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 0, 6 ],
      "id_str" : "15359408",
      "id" : 15359408
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 7, 18 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 19, 35 ],
      "id_str" : "16997374",
      "id" : 16997374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100599482948915200",
  "geo" : { },
  "id_str" : "100600003227156480",
  "in_reply_to_user_id" : 15359408,
  "text" : "@raggi @tenderlove @konstantinhaase YAY! I discussed this with Matz 2 RubyConfs ago, glad it's a thing! let's make it happen!",
  "id" : 100600003227156480,
  "in_reply_to_status_id" : 100599482948915200,
  "created_at" : "2011-08-08 16:11:24 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100598014137208832",
  "geo" : { },
  "id_str" : "100598824288002048",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox underscore",
  "id" : 100598824288002048,
  "in_reply_to_status_id" : 100598014137208832,
  "created_at" : "2011-08-08 16:06:43 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100595877676195841",
  "geo" : { },
  "id_str" : "100596608164569088",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek haha, who writes tests anymore anyway, thats so 2010",
  "id" : 100596608164569088,
  "in_reply_to_status_id" : 100595877676195841,
  "created_at" : "2011-08-08 15:57:55 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 44 ],
      "url" : "http:\/\/t.co\/3By9nGO",
      "expanded_url" : "http:\/\/breadpeople.tumblr.com\/",
      "display_url" : "breadpeople.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "100587090584154112",
  "text" : "My life is now complete. http:\/\/t.co\/3By9nGO",
  "id" : 100587090584154112,
  "created_at" : "2011-08-08 15:20:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/RdVtoe4",
      "expanded_url" : "http:\/\/resenhista.deviantart.com\/art\/How-to-get-into-Mordor-251356004",
      "display_url" : "resenhista.deviantart.com\/art\/How-to-get\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "100565267465240577",
  "text" : "Current status: http:\/\/t.co\/RdVtoe4",
  "id" : 100565267465240577,
  "created_at" : "2011-08-08 13:53:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100560719216513024",
  "geo" : { },
  "id_str" : "100562326687727617",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold ooh, ooh: put the fridge next to your boss' desk",
  "id" : 100562326687727617,
  "in_reply_to_status_id" : 100560719216513024,
  "created_at" : "2011-08-08 13:41:41 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100560719216513024",
  "geo" : { },
  "id_str" : "100562273738825729",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold move your desk? or destroy the fridge. or both.",
  "id" : 100562273738825729,
  "in_reply_to_status_id" : 100560719216513024,
  "created_at" : "2011-08-08 13:41:29 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 43 ],
      "url" : "http:\/\/t.co\/OR6Qgbx",
      "expanded_url" : "http:\/\/i.imgur.com\/lUtU4.jpg",
      "display_url" : "i.imgur.com\/lUtU4.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "100384634965204992",
  "text" : "WUP WUP WUP WUP WUP WUP http:\/\/t.co\/OR6Qgbx",
  "id" : 100384634965204992,
  "created_at" : "2011-08-08 01:55:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 24, 32 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100380740323246080",
  "text" : "Back in Boston from the @jayunit hoedown. Dog acquired along with a broken crate...dude's separation anxiety is destructive",
  "id" : 100380740323246080,
  "created_at" : "2011-08-08 01:40:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakan Ensari",
      "screen_name" : "hakanensari",
      "indices" : [ 0, 12 ],
      "id_str" : "15325245",
      "id" : 15325245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100367049133535232",
  "geo" : { },
  "id_str" : "100379326452744192",
  "in_reply_to_user_id" : 15325245,
  "text" : "@hakanensari no, yank the old versions and push the new one",
  "id" : 100379326452744192,
  "in_reply_to_status_id" : 100367049133535232,
  "created_at" : "2011-08-08 01:34:31 +0000",
  "in_reply_to_screen_name" : "hakanensari",
  "in_reply_to_user_id_str" : "15325245",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100206758928203776",
  "text" : "The massive scale of minecraft maps makes me wonder: does anyone actually use *all* the space?",
  "id" : 100206758928203776,
  "created_at" : "2011-08-07 14:08:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0646 alkema",
      "screen_name" : "alkema",
      "indices" : [ 0, 7 ],
      "id_str" : "14938996",
      "id" : 14938996
    }, {
      "name" : "Sir Scruggsalot",
      "screen_name" : "TechScruggs",
      "indices" : [ 8, 20 ],
      "id_str" : "88602172",
      "id" : 88602172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99523875188113408",
  "geo" : { },
  "id_str" : "100205901503410177",
  "in_reply_to_user_id" : 14938996,
  "text" : "@alkema @TechScruggs how exactly would we provide less volume? it's a real-time stream of every gem push",
  "id" : 100205901503410177,
  "in_reply_to_status_id" : 99523875188113408,
  "created_at" : "2011-08-07 14:05:23 +0000",
  "in_reply_to_screen_name" : "alkema",
  "in_reply_to_user_id_str" : "14938996",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Ledet",
      "screen_name" : "chrisledet",
      "indices" : [ 0, 11 ],
      "id_str" : "12523492",
      "id" : 12523492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 47 ],
      "url" : "http:\/\/t.co\/eWm4jIt",
      "expanded_url" : "http:\/\/www.rubyinside.com\/gemcutter-a-fast-and-easy-approach-to-ruby-gem-hosting-2281.html",
      "display_url" : "rubyinside.com\/gemcutter-a-fa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "99911163105648640",
  "geo" : { },
  "id_str" : "100205745601122305",
  "in_reply_to_user_id" : 12523492,
  "text" : "@chrisledet see comments on http:\/\/t.co\/eWm4jIt",
  "id" : 100205745601122305,
  "in_reply_to_status_id" : 99911163105648640,
  "created_at" : "2011-08-07 14:04:46 +0000",
  "in_reply_to_screen_name" : "chrisledet",
  "in_reply_to_user_id_str" : "12523492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 27 ],
      "url" : "http:\/\/t.co\/MAwsHfd",
      "expanded_url" : "http:\/\/rubycraft.org\/map",
      "display_url" : "rubycraft.org\/map"
    } ]
  },
  "geo" : { },
  "id_str" : "100204906820009984",
  "text" : "whoa!!! http:\/\/t.co\/MAwsHfd",
  "id" : 100204906820009984,
  "created_at" : "2011-08-07 14:01:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 0, 8 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99959862787706880",
  "geo" : { },
  "id_str" : "100204881792610304",
  "in_reply_to_user_id" : 839931,
  "text" : "@ddollar holy crap !",
  "id" : 100204881792610304,
  "in_reply_to_status_id" : 99959862787706880,
  "created_at" : "2011-08-07 14:01:20 +0000",
  "in_reply_to_screen_name" : "ddollar",
  "in_reply_to_user_id_str" : "839931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99656166820425728",
  "text" : "Holy crap, maybe we'll see the aurora on the drive tonight? Zomg! http:\/\/www.swpc.noaa.gov\/Aurora\/globeNW.html",
  "id" : 99656166820425728,
  "created_at" : "2011-08-06 01:40:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 27, 35 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99654792602845184",
  "text" : "Halfway to Buffalo for the @jayunit hoedown tomorrow!",
  "id" : 99654792602845184,
  "created_at" : "2011-08-06 01:35:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 0, 14 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99653184401838080",
  "geo" : { },
  "id_str" : "99654464784433153",
  "in_reply_to_user_id" : 16930130,
  "text" : "@PhilDarnowsky clusterfuck?",
  "id" : 99654464784433153,
  "in_reply_to_status_id" : 99653184401838080,
  "created_at" : "2011-08-06 01:34:10 +0000",
  "in_reply_to_screen_name" : "PhilDarnowsky",
  "in_reply_to_user_id_str" : "16930130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99651579921174529",
  "geo" : { },
  "id_str" : "99654243895619584",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil this is why plan 9's fs ideas are crazy. Maybe someday.",
  "id" : 99654243895619584,
  "in_reply_to_status_id" : 99651579921174529,
  "created_at" : "2011-08-06 01:33:17 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 3, 11 ],
      "id_str" : "28819745",
      "id" : 28819745
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 61, 72 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99563047412183041",
  "text" : "RT @sikachu: Today concludes my 3 months apprenticeship with @thoughtbot. However, I'll come back as a full time web developer in Octobe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "thoughtbot",
        "screen_name" : "thoughtbot",
        "indices" : [ 48, 59 ],
        "id_str" : "14114392",
        "id" : 14114392
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "99562468283662337",
    "text" : "Today concludes my 3 months apprenticeship with @thoughtbot. However, I'll come back as a full time web developer in October. :)",
    "id" : 99562468283662337,
    "created_at" : "2011-08-05 19:28:36 +0000",
    "user" : {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "protected" : false,
      "id_str" : "28819745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548464438928355328\/uUhXMR2__normal.png",
      "id" : 28819745,
      "verified" : false
    }
  },
  "id" : 99563047412183041,
  "created_at" : "2011-08-05 19:30:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 23, 30 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99502910412566528",
  "text" : "Still the problem with @tumblr: go there to write a post, get completely lost in timeline browsing.",
  "id" : 99502910412566528,
  "created_at" : "2011-08-05 15:31:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Han",
      "screen_name" : "knowtheory",
      "indices" : [ 0, 11 ],
      "id_str" : "14227842",
      "id" : 14227842
    }, {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 109, 117 ],
      "id_str" : "839931",
      "id" : 839931
    }, {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 118, 125 ],
      "id_str" : "3928731",
      "id" : 3928731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99478009995722752",
  "geo" : { },
  "id_str" : "99493914226069504",
  "in_reply_to_user_id" : 14227842,
  "text" : "@knowtheory someone who's promoted has to \/pex promote [your username]. i wont be on for a while though. \/cc @ddollar @cssboy",
  "id" : 99493914226069504,
  "in_reply_to_status_id" : 99478009995722752,
  "created_at" : "2011-08-05 14:56:12 +0000",
  "in_reply_to_screen_name" : "knowtheory",
  "in_reply_to_user_id_str" : "14227842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http:\/\/t.co\/XzYzuMv",
      "expanded_url" : "http:\/\/blog.teambox.com\/raised-by-the-valley",
      "display_url" : "blog.teambox.com\/raised-by-the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "99472441176363009",
  "text" : "Does anyone *not* feel this way about SF? I'm sick of the notion that tech businesses can't grow outside out of it. http:\/\/t.co\/XzYzuMv",
  "id" : 99472441176363009,
  "created_at" : "2011-08-05 13:30:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99244717669232640",
  "geo" : { },
  "id_str" : "99246591646502913",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi which ones? And yeah kinda, id rather see more docs",
  "id" : 99246591646502913,
  "in_reply_to_status_id" : 99244717669232640,
  "created_at" : "2011-08-04 22:33:26 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Helmkamp",
      "screen_name" : "brynary",
      "indices" : [ 0, 8 ],
      "id_str" : "2049071",
      "id" : 2049071
    }, {
      "name" : "Obie",
      "screen_name" : "obie",
      "indices" : [ 9, 14 ],
      "id_str" : "45603",
      "id" : 45603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 113 ],
      "url" : "http:\/\/t.co\/J8JLf4N",
      "expanded_url" : "https:\/\/lh6.googleusercontent.com\/-MQt9iGQVdYc\/TgGVyb-rhhI\/AAAAAAAACjY\/ve8GTSzwPnY\/Oprahs-Bees.gif",
      "display_url" : "lh6.googleusercontent.com\/-MQt9iGQVdYc\/T\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "99236289328582656",
  "geo" : { },
  "id_str" : "99237873265553408",
  "in_reply_to_user_id" : 2049071,
  "text" : "@brynary @obie YOU GET A CONSULTANCY, YOU GET A CONSULTANCY, EVERYBODY GETS CONSULTANCIES!!!! http:\/\/t.co\/J8JLf4N",
  "id" : 99237873265553408,
  "in_reply_to_status_id" : 99236289328582656,
  "created_at" : "2011-08-04 21:58:47 +0000",
  "in_reply_to_screen_name" : "brynary",
  "in_reply_to_user_id_str" : "2049071",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarod Luebbert",
      "screen_name" : "jarodl",
      "indices" : [ 0, 7 ],
      "id_str" : "14253292",
      "id" : 14253292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99164281228103680",
  "geo" : { },
  "id_str" : "99164694077652992",
  "in_reply_to_user_id" : 14253292,
  "text" : "@jarodl RHOMBUS!",
  "id" : 99164694077652992,
  "in_reply_to_status_id" : 99164281228103680,
  "created_at" : "2011-08-04 17:08:00 +0000",
  "in_reply_to_screen_name" : "jarodl",
  "in_reply_to_user_id_str" : "14253292",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98938635570786304",
  "text" : "wow, rubycraft.org grown immensely! the \/home plugin is great for checking out what other people have been building",
  "id" : 98938635570786304,
  "created_at" : "2011-08-04 02:09:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Dente",
      "screen_name" : "kevindente",
      "indices" : [ 0, 11 ],
      "id_str" : "778112",
      "id" : 778112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98898211263102976",
  "geo" : { },
  "id_str" : "98901801323069440",
  "in_reply_to_user_id" : 778112,
  "text" : "@kevindente :( it keeps history and you can enable desktop notifications w\/ chrome. as an irc desktop user for almost 9 years, its great",
  "id" : 98901801323069440,
  "in_reply_to_status_id" : 98898211263102976,
  "created_at" : "2011-08-03 23:43:21 +0000",
  "in_reply_to_screen_name" : "kevindente",
  "in_reply_to_user_id_str" : "778112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Dente",
      "screen_name" : "kevindente",
      "indices" : [ 0, 11 ],
      "id_str" : "778112",
      "id" : 778112
    }, {
      "name" : "IRCCloud",
      "screen_name" : "IRCCloud",
      "indices" : [ 20, 29 ],
      "id_str" : "171845650",
      "id" : 171845650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98896293304344576",
  "geo" : { },
  "id_str" : "98897879862743041",
  "in_reply_to_user_id" : 778112,
  "text" : "@kevindente want an @irccloud invite instead?",
  "id" : 98897879862743041,
  "in_reply_to_status_id" : 98896293304344576,
  "created_at" : "2011-08-03 23:27:46 +0000",
  "in_reply_to_screen_name" : "kevindente",
  "in_reply_to_user_id_str" : "778112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98873031518191616",
  "geo" : { },
  "id_str" : "98879921056784384",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius we have a staging server, email me and i can explain further",
  "id" : 98879921056784384,
  "in_reply_to_status_id" : 98873031518191616,
  "created_at" : "2011-08-03 22:16:24 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DevStructure",
      "screen_name" : "DevStructure",
      "indices" : [ 0, 13 ],
      "id_str" : "133775489",
      "id" : 133775489
    }, {
      "name" : "Matt Tanase",
      "screen_name" : "zenmatt",
      "indices" : [ 14, 22 ],
      "id_str" : "654773",
      "id" : 654773
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 101, 115 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98832435273404416",
  "geo" : { },
  "id_str" : "98854115681124352",
  "in_reply_to_user_id" : 133775489,
  "text" : "@DevStructure @zenmatt the fact this is named after a popular css library is still wildly confusing +@joshuaclayton",
  "id" : 98854115681124352,
  "in_reply_to_status_id" : 98832435273404416,
  "created_at" : "2011-08-03 20:33:52 +0000",
  "in_reply_to_screen_name" : "DevStructure",
  "in_reply_to_user_id_str" : "133775489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henrik Nyh",
      "screen_name" : "henrik",
      "indices" : [ 0, 7 ],
      "id_str" : "14208392",
      "id" : 14208392
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 74, 84 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 89, 98 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98844656426688512",
  "geo" : { },
  "id_str" : "98845127975518208",
  "in_reply_to_user_id" : 14208392,
  "text" : "@henrik i'm in a similar situation, locked out of my google analytics for @gemcutter and @gitready, and no google+ profiles for orgs :(",
  "id" : 98845127975518208,
  "in_reply_to_status_id" : 98844656426688512,
  "created_at" : "2011-08-03 19:58:09 +0000",
  "in_reply_to_screen_name" : "henrik",
  "in_reply_to_user_id_str" : "14208392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "Brian Ketelsen",
      "screen_name" : "bketelsen",
      "indices" : [ 9, 19 ],
      "id_str" : "13332232",
      "id" : 13332232
    }, {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 46, 53 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98844718917619713",
  "geo" : { },
  "id_str" : "98844972903694336",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius @bketelsen, heh, i deploy my ruby to @heroku. I don't even want to think of servers.",
  "id" : 98844972903694336,
  "in_reply_to_status_id" : 98844718917619713,
  "created_at" : "2011-08-03 19:57:32 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98842270337482752",
  "geo" : { },
  "id_str" : "98842545148280832",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius so zero? i just want to know the basis of that claim, esp for people w\/o java experience it makes little sense to deploy with, imo",
  "id" : 98842545148280832,
  "in_reply_to_status_id" : 98842270337482752,
  "created_at" : "2011-08-03 19:47:53 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98839785380134912",
  "geo" : { },
  "id_str" : "98841524946739201",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius really curious here, how many and what rails apps do you deploy on a daily basis?",
  "id" : 98841524946739201,
  "in_reply_to_status_id" : 98839785380134912,
  "created_at" : "2011-08-03 19:43:50 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/LMJfId8",
      "expanded_url" : "http:\/\/www.arkive.org\/capybara\/hydrochoerus-hydrochaeris\/video-09a.html",
      "display_url" : "arkive.org\/capybara\/hydro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98830074933035010",
  "text" : "Current status: http:\/\/t.co\/LMJfId8",
  "id" : 98830074933035010,
  "created_at" : "2011-08-03 18:58:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98775659232493568",
  "geo" : { },
  "id_str" : "98776672349859840",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie i mean, in your stream...not just yours, *everyone* you follow?",
  "id" : 98776672349859840,
  "in_reply_to_status_id" : 98775659232493568,
  "created_at" : "2011-08-03 15:26:08 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98774507862503424",
  "geo" : { },
  "id_str" : "98775227152080899",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie do you put *every* tweet in there?",
  "id" : 98775227152080899,
  "in_reply_to_status_id" : 98774507862503424,
  "created_at" : "2011-08-03 15:20:23 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    }, {
      "name" : "Chris Oliver",
      "screen_name" : "excid3",
      "indices" : [ 30, 37 ],
      "id_str" : "14057736",
      "id" : 14057736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98773707102760962",
  "geo" : { },
  "id_str" : "98775040841089024",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie beasically what @excid3 said...mentions. wasn't watching the repo.",
  "id" : 98775040841089024,
  "in_reply_to_status_id" : 98773707102760962,
  "created_at" : "2011-08-03 15:19:39 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98773481788944384",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie your tweets repo just email flooded me :(",
  "id" : 98773481788944384,
  "created_at" : "2011-08-03 15:13:27 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/W2Z1YqZ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ZS_6-IwMPjM",
      "display_url" : "youtube.com\/watch?v=ZS_6-I\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98770187649683457",
  "text" : "Current status: http:\/\/t.co\/W2Z1YqZ",
  "id" : 98770187649683457,
  "created_at" : "2011-08-03 15:00:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98220475641106432",
  "text" : "Hell yes, and by the same guy as the hastily made cleveland tourism videos.",
  "id" : 98220475641106432,
  "created_at" : "2011-08-02 02:36:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 45 ],
      "url" : "http:\/\/t.co\/9SaBoxZ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=qpl5mOAXNl4&feature=feedu",
      "display_url" : "youtube.com\/watch?v=qpl5mO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98220235324260352",
  "text" : "I'm a stupid fucking cat! http:\/\/t.co\/9SaBoxZ",
  "id" : 98220235324260352,
  "created_at" : "2011-08-02 02:35:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98128451818618881",
  "geo" : { },
  "id_str" : "98131448648843264",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx ladies dig it",
  "id" : 98131448648843264,
  "in_reply_to_status_id" : 98128451818618881,
  "created_at" : "2011-08-01 20:42:15 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/yt8B3tG",
      "expanded_url" : "http:\/\/i.imgur.com\/2M2mT.gif",
      "display_url" : "i.imgur.com\/2M2mT.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "98125817611165697",
  "text" : "Current status: http:\/\/t.co\/yt8B3tG",
  "id" : 98125817611165697,
  "created_at" : "2011-08-01 20:19:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 0, 11 ],
      "id_str" : "14086000",
      "id" : 14086000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98114086788800512",
  "geo" : { },
  "id_str" : "98114622418202626",
  "in_reply_to_user_id" : 14086000,
  "text" : "@timocratic afaik paperclip and FG are really good with docs...if you can find specific stuff we can cover I can make sure it gets done",
  "id" : 98114622418202626,
  "in_reply_to_status_id" : 98114086788800512,
  "created_at" : "2011-08-01 19:35:23 +0000",
  "in_reply_to_screen_name" : "timocratic",
  "in_reply_to_user_id_str" : "14086000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98114112063672320",
  "geo" : { },
  "id_str" : "98114445938663424",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant about time, welcome to the internet",
  "id" : 98114445938663424,
  "in_reply_to_status_id" : 98114112063672320,
  "created_at" : "2011-08-01 19:34:41 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 0, 11 ],
      "id_str" : "14086000",
      "id" : 14086000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98113561804546048",
  "geo" : { },
  "id_str" : "98113942563471360",
  "in_reply_to_user_id" : 14086000,
  "text" : "@timocratic what projects are you talking about?",
  "id" : 98113942563471360,
  "in_reply_to_status_id" : 98113561804546048,
  "created_at" : "2011-08-01 19:32:41 +0000",
  "in_reply_to_screen_name" : "timocratic",
  "in_reply_to_user_id_str" : "14086000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 83 ],
      "url" : "http:\/\/t.co\/UfhW5R5",
      "expanded_url" : "http:\/\/helablog.com\/2011\/07\/cremate-your-loved-ones-then-pack-them-into-bullets\/",
      "display_url" : "helablog.com\/2011\/07\/cremat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98100679259852800",
  "text" : "\"Cremate your loved ones then pack them into Bullets.\" BULLETS. http:\/\/t.co\/UfhW5R5",
  "id" : 98100679259852800,
  "created_at" : "2011-08-01 18:39:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98077210518360064",
  "geo" : { },
  "id_str" : "98085172729233408",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape IE 2.0 IS DESTROYING THE INTERNET, JUST SAY NO",
  "id" : 98085172729233408,
  "in_reply_to_status_id" : 98077210518360064,
  "created_at" : "2011-08-01 17:38:22 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 3, 14 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98085079200448512",
  "text" : "RT @shellscape: http:\/\/lockerz.com\/s\/125697419 ie 2.0 running on winnt 4.0 - thats what google.com looks like",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98077210518360064",
    "text" : "http:\/\/lockerz.com\/s\/125697419 ie 2.0 running on winnt 4.0 - thats what google.com looks like",
    "id" : 98077210518360064,
    "created_at" : "2011-08-01 17:06:43 +0000",
    "user" : {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "protected" : false,
      "id_str" : "16134710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552990084379578368\/tV6fOemg_normal.jpeg",
      "id" : 16134710,
      "verified" : false
    }
  },
  "id" : 98085079200448512,
  "created_at" : "2011-08-01 17:37:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/97fCm7z",
      "expanded_url" : "https:\/\/img.skitch.com\/20110801-n5sy32mfmw9ir4tw3h6c7y21bx.png",
      "display_url" : "img.skitch.com\/20110801-n5sy3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98063797566177280",
  "text" : "Current status: http:\/\/t.co\/97fCm7z",
  "id" : 98063797566177280,
  "created_at" : "2011-08-01 16:13:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jos\u00E9 Valim",
      "screen_name" : "josevalim",
      "indices" : [ 0, 10 ],
      "id_str" : "10230812",
      "id" : 10230812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98047828831645696",
  "in_reply_to_user_id" : 10230812,
  "text" : "@josevalim would you accept a pull request to rename it to something that doesn't sound like a 6 year old OSS web server?",
  "id" : 98047828831645696,
  "created_at" : "2011-08-01 15:09:58 +0000",
  "in_reply_to_screen_name" : "josevalim",
  "in_reply_to_user_id_str" : "10230812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jos\u00E9 Valim",
      "screen_name" : "josevalim",
      "indices" : [ 10, 20 ],
      "id_str" : "10230812",
      "id" : 10230812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 41 ],
      "url" : "http:\/\/t.co\/6WlmkeS",
      "expanded_url" : "https:\/\/github.com\/josevalim\/enginex",
      "display_url" : "github.com\/josevalim\/engi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98044184895823873",
  "text" : "Seriously @josevalim? http:\/\/t.co\/6WlmkeS? Did you pick this name just so you could get people confused?",
  "id" : 98044184895823873,
  "created_at" : "2011-08-01 14:55:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
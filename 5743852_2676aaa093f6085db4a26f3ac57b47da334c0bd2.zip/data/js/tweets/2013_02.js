Grailbird.data.tweets_2013_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Campbell",
      "screen_name" : "justincampbell",
      "indices" : [ 0, 15 ],
      "id_str" : "7387992",
      "id" : 7387992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307306205058043904",
  "geo" : { },
  "id_str" : "307322767479562240",
  "in_reply_to_user_id" : 7387992,
  "text" : "@justincampbell Yep! Intelligentsia.",
  "id" : 307322767479562240,
  "in_reply_to_status_id" : 307306205058043904,
  "created_at" : "2013-03-01 02:53:52 +0000",
  "in_reply_to_screen_name" : "justincampbell",
  "in_reply_to_user_id_str" : "7387992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/307312700839563264\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/XflMYP6QPo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEPLRfDCEAAvJQ6.jpg",
      "id_str" : "307312700843757568",
      "id" : 307312700843757568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEPLRfDCEAAvJQ6.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/XflMYP6QPo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307312700839563264",
  "text" : "I am Iron Man! http:\/\/t.co\/XflMYP6QPo",
  "id" : 307312700839563264,
  "created_at" : "2013-03-01 02:13:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 31, 42 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/307304047260626944\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/kJcpNe4UFi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEPDZx9CcAEbyTu.jpg",
      "id_str" : "307304047264821249",
      "id" : 307304047264821249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEPDZx9CcAEbyTu.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/kJcpNe4UFi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307304047260626944",
  "text" : "Just a normal coffee shop. \/cc @kevinpurdy http:\/\/t.co\/kJcpNe4UFi",
  "id" : 307304047260626944,
  "created_at" : "2013-03-01 01:39:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 38, 47 ],
      "id_str" : "16225196",
      "id" : 16225196
    }, {
      "name" : "travis jeffery",
      "screen_name" : "travisjeffery",
      "indices" : [ 52, 66 ],
      "id_str" : "679103",
      "id" : 679103
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/307283117071290368\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/YJLj1PblfZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEOwXe7CUAEoiVM.jpg",
      "id_str" : "307283117075484673",
      "id" : 307283117075484673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEOwXe7CUAEoiVM.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YJLj1PblfZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307283117071290368",
  "text" : "Just got murdered in King of Tokyo by @shildner and @travisjeffery at 19\/20 victory. (*\uFF40\u3078\u00B4*) http:\/\/t.co\/YJLj1PblfZ",
  "id" : 307283117071290368,
  "created_at" : "2013-03-01 00:16:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phred",
      "screen_name" : "fearphage",
      "indices" : [ 3, 13 ],
      "id_str" : "8749632",
      "id" : 8749632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/AyS7HtxUko",
      "expanded_url" : "http:\/\/a.yfrog.com\/img737\/1543\/5hqh.png",
      "display_url" : "a.yfrog.com\/img737\/1543\/5h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307259396407300097",
  "text" : "RT @fearphage: I find the best way to avoid SQL injection is to ask nicely http:\/\/t.co\/AyS7HtxUko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/streamie.org\" rel=\"nofollow\"\u003Estreamie\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/AyS7HtxUko",
        "expanded_url" : "http:\/\/a.yfrog.com\/img737\/1543\/5hqh.png",
        "display_url" : "a.yfrog.com\/img737\/1543\/5h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "307220363903897600",
    "text" : "I find the best way to avoid SQL injection is to ask nicely http:\/\/t.co\/AyS7HtxUko",
    "id" : 307220363903897600,
    "created_at" : "2013-02-28 20:06:57 +0000",
    "user" : {
      "name" : "Phred",
      "screen_name" : "fearphage",
      "protected" : false,
      "id_str" : "8749632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/24856922\/AIM-fearphage_normal.jpg",
      "id" : 8749632,
      "verified" : false
    }
  },
  "id" : 307259396407300097,
  "created_at" : "2013-02-28 22:42:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "indices" : [ 0, 13 ],
      "id_str" : "1341781",
      "id" : 1341781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307255563685879808",
  "geo" : { },
  "id_str" : "307256067937665025",
  "in_reply_to_user_id" : 1341781,
  "text" : "@gilesgoatboy !!FUN!!",
  "id" : 307256067937665025,
  "in_reply_to_status_id" : 307255563685879808,
  "created_at" : "2013-02-28 22:28:49 +0000",
  "in_reply_to_screen_name" : "gilesgoatboy",
  "in_reply_to_user_id_str" : "1341781",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "indices" : [ 3, 16 ],
      "id_str" : "1341781",
      "id" : 1341781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307256052662026240",
  "text" : "RT @gilesgoatboy: dwarf fortress as a service",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "307255563685879808",
    "text" : "dwarf fortress as a service",
    "id" : 307255563685879808,
    "created_at" : "2013-02-28 22:26:49 +0000",
    "user" : {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "protected" : false,
      "id_str" : "1341781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572276476137848832\/GmGo-zGF_normal.jpeg",
      "id" : 1341781,
      "verified" : false
    }
  },
  "id" : 307256052662026240,
  "created_at" : "2013-02-28 22:28:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/307240706890661888\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/HN8DW59fHg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEOJy4tCAAAn9yY.png",
      "id_str" : "307240706899050496",
      "id" : 307240706899050496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEOJy4tCAAAn9yY.png",
      "sizes" : [ {
        "h" : 308,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HN8DW59fHg"
    } ],
    "hashtags" : [ {
      "text" : "iosreviewtime",
      "indices" : [ 39, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/pAHsfTnA1n",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/basecamp\/id599139477",
      "display_url" : "itunes.apple.com\/us\/app\/basecam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307240706890661888",
  "text" : "New Basecamp version is out! 6 days of #iosreviewtime https:\/\/t.co\/pAHsfTnA1n http:\/\/t.co\/HN8DW59fHg",
  "id" : 307240706890661888,
  "created_at" : "2013-02-28 21:27:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Lutley",
      "screen_name" : "elutley",
      "indices" : [ 0, 8 ],
      "id_str" : "141385784",
      "id" : 141385784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/dd0Be9fiei",
      "expanded_url" : "http:\/\/apple.stackexchange.com\/questions\/55432\/keyboard-shortcut-for-restoring-applications-from-the-mac-os-x-dock",
      "display_url" : "apple.stackexchange.com\/questions\/5543\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "307221461192556544",
  "geo" : { },
  "id_str" : "307221814449414144",
  "in_reply_to_user_id" : 141385784,
  "text" : "@elutley http:\/\/t.co\/dd0Be9fiei",
  "id" : 307221814449414144,
  "in_reply_to_status_id" : 307221461192556544,
  "created_at" : "2013-02-28 20:12:43 +0000",
  "in_reply_to_screen_name" : "elutley",
  "in_reply_to_user_id_str" : "141385784",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307207432877256704",
  "geo" : { },
  "id_str" : "307207616059297793",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr agreed. \"at all costs\" is a little much though :)",
  "id" : 307207616059297793,
  "in_reply_to_status_id" : 307207432877256704,
  "created_at" : "2013-02-28 19:16:17 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307187321361555456",
  "text" : "Just discovered NSDictionary#valueForKeyPath. I wish this was in Ruby, so useful!",
  "id" : 307187321361555456,
  "created_at" : "2013-02-28 17:55:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katy Jackson",
      "screen_name" : "suninthecorner",
      "indices" : [ 36, 51 ],
      "id_str" : "24006502",
      "id" : 24006502
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 78, 92 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/isnK5Jyo0J",
      "expanded_url" : "http:\/\/makingspaceforothers.com\/Chapter2",
      "display_url" : "makingspaceforothers.com\/Chapter2"
    } ]
  },
  "geo" : { },
  "id_str" : "307169118161891328",
  "text" : "Making Space for Others - Thanks to @suninthecorner for interviewing me &amp; @coworkbuffalo ! http:\/\/t.co\/isnK5Jyo0J",
  "id" : 307169118161891328,
  "created_at" : "2013-02-28 16:43:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/307161023205502978\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/GbMwtWXo4i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BENBUr1CcAEhvsr.jpg",
      "id_str" : "307161023209697281",
      "id" : 307161023209697281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BENBUr1CcAEhvsr.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/GbMwtWXo4i"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307161023205502978",
  "text" : "Just a giant hunk of meat. http:\/\/t.co\/GbMwtWXo4i",
  "id" : 307161023205502978,
  "created_at" : "2013-02-28 16:11:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 61, 71 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307154129426468864",
  "text" : "Unexpected use of the Basecamp app: photo sharing during the @37signals meetup. Excited to see more use cases like this.",
  "id" : 307154129426468864,
  "created_at" : "2013-02-28 15:43:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "21Snap",
      "screen_name" : "_21Snap_",
      "indices" : [ 3, 12 ],
      "id_str" : "1046372095",
      "id" : 1046372095
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 42, 52 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "Basecamp News",
      "screen_name" : "basecampnews",
      "indices" : [ 53, 66 ],
      "id_str" : "47366813",
      "id" : 47366813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "projectmanagement",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ZMZlA9guZh",
      "expanded_url" : "http:\/\/bit.ly\/X9DSAe",
      "display_url" : "bit.ly\/X9DSAe"
    } ]
  },
  "geo" : { },
  "id_str" : "307150283153227778",
  "text" : "RT @_21Snap_: New blog post on why we use @37signals @basecampnews &amp; how it has revolutionised the way we work! http:\/\/t.co\/ZMZlA9gu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 28, 38 ],
        "id_str" : "11132462",
        "id" : 11132462
      }, {
        "name" : "Basecamp News",
        "screen_name" : "basecampnews",
        "indices" : [ 39, 52 ],
        "id_str" : "47366813",
        "id" : 47366813
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "projectmanagement",
        "indices" : [ 125, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/ZMZlA9guZh",
        "expanded_url" : "http:\/\/bit.ly\/X9DSAe",
        "display_url" : "bit.ly\/X9DSAe"
      } ]
    },
    "geo" : { },
    "id_str" : "307092019241684993",
    "text" : "New blog post on why we use @37signals @basecampnews &amp; how it has revolutionised the way we work! http:\/\/t.co\/ZMZlA9guZh #projectmanagement",
    "id" : 307092019241684993,
    "created_at" : "2013-02-28 11:36:57 +0000",
    "user" : {
      "name" : "21Snap",
      "screen_name" : "_21Snap_",
      "protected" : false,
      "id_str" : "1046372095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3184965996\/c465399caf89c56d14d2215d009ca97b_normal.jpeg",
      "id" : 1046372095,
      "verified" : false
    }
  },
  "id" : 307150283153227778,
  "created_at" : "2013-02-28 15:28:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 9, 19 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 30, 38 ],
      "id_str" : "234465384",
      "id" : 234465384
    }, {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 43, 54 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/306898143285497856\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/4XI5OaolXE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEJSPD1CUAA1BpK.jpg",
      "id_str" : "306898143293886464",
      "id" : 306898143293886464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEJSPD1CUAA1BpK.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/4XI5OaolXE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306898143285497856",
  "text" : "RealOps\u2122 @37signals thanks to @noahhlo and @themcgruff http:\/\/t.co\/4XI5OaolXE",
  "id" : 306898143285497856,
  "created_at" : "2013-02-27 22:46:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/TstHpADA9W",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/nightmaresfearfactory\/",
      "display_url" : "flickr.com\/photos\/nightma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306895454250102784",
  "text" : "These scare photos are still so funny: http:\/\/t.co\/TstHpADA9W",
  "id" : 306895454250102784,
  "created_at" : "2013-02-27 22:35:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u1D48\u02B3\u1D43\u1D4F\u1D4F\u02B0\u1D49\u207F",
      "screen_name" : "drakkhen",
      "indices" : [ 0, 9 ],
      "id_str" : "18176030",
      "id" : 18176030
    }, {
      "name" : "Stephen A. Ridley",
      "screen_name" : "s7ephen",
      "indices" : [ 10, 18 ],
      "id_str" : "5350322",
      "id" : 5350322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306817897391611904",
  "geo" : { },
  "id_str" : "306818247825690624",
  "in_reply_to_user_id" : 18176030,
  "text" : "@drakkhen @s7ephen What?",
  "id" : 306818247825690624,
  "in_reply_to_status_id" : 306817897391611904,
  "created_at" : "2013-02-27 17:29:05 +0000",
  "in_reply_to_screen_name" : "drakkhen",
  "in_reply_to_user_id_str" : "18176030",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 3, 16 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306783951425527808",
  "text" : "RT @lindseybieda: I\u2019m really sad that one of the common responses to teaching more people to code is, \u201CJust what we need, more shitty pr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306778067911733248",
    "text" : "I\u2019m really sad that one of the common responses to teaching more people to code is, \u201CJust what we need, more shitty programmers\u201D",
    "id" : 306778067911733248,
    "created_at" : "2013-02-27 14:49:25 +0000",
    "user" : {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "protected" : false,
      "id_str" : "14928483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569192760029089792\/zaGhTAHK_normal.jpeg",
      "id" : 14928483,
      "verified" : false
    }
  },
  "id" : 306783951425527808,
  "created_at" : "2013-02-27 15:12:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 0, 12 ],
      "id_str" : "8828952",
      "id" : 8828952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306562389640372224",
  "geo" : { },
  "id_str" : "306624639088599040",
  "in_reply_to_user_id" : 8828952,
  "text" : "@codeofficer it\u2019s just a normal archive, no API needed!",
  "id" : 306624639088599040,
  "in_reply_to_status_id" : 306562389640372224,
  "created_at" : "2013-02-27 04:39:45 +0000",
  "in_reply_to_screen_name" : "codeofficer",
  "in_reply_to_user_id_str" : "8828952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306559462922141697",
  "text" : "Poopin'",
  "id" : 306559462922141697,
  "created_at" : "2013-02-27 00:20:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306496373308678144",
  "text" : "57 results match \u2018OMG\u2019\n232 results match \u2018fuck\u2019\n136 results match \u2018shit\u2019\n172 results match \u2018WTF\u2019\n158 results match \u2018fail\u2019",
  "id" : 306496373308678144,
  "created_at" : "2013-02-26 20:10:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306491625989881856",
  "geo" : { },
  "id_str" : "306491841623244800",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik neato. I'd probably just request a new archive every month or few months.",
  "id" : 306491841623244800,
  "in_reply_to_status_id" : 306491625989881856,
  "created_at" : "2013-02-26 19:52:04 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frederic Jacobs",
      "screen_name" : "FredericJacobs",
      "indices" : [ 0, 15 ],
      "id_str" : "18018877",
      "id" : 18018877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306490443611398144",
  "geo" : { },
  "id_str" : "306490632090812416",
  "in_reply_to_user_id" : 18018877,
  "text" : "@FredericJacobs I think that was a terrible SE class I was in. a lot of word doc templates to fill out.",
  "id" : 306490632090812416,
  "in_reply_to_status_id" : 306490443611398144,
  "created_at" : "2013-02-26 19:47:15 +0000",
  "in_reply_to_screen_name" : "FredericJacobs",
  "in_reply_to_user_id_str" : "18018877",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    }, {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 8, 15 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306489955973214209",
  "geo" : { },
  "id_str" : "306490243798937600",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek @mwhuss this most likely will be accurate",
  "id" : 306490243798937600,
  "in_reply_to_status_id" : 306489955973214209,
  "created_at" : "2013-02-26 19:45:43 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/ZH2HMrCT2a",
      "expanded_url" : "http:\/\/quaran.to\/archive\/",
      "display_url" : "quaran.to\/archive\/"
    } ]
  },
  "geo" : { },
  "id_str" : "306490156414808064",
  "text" : "Published my twitter archive to github pages: http:\/\/t.co\/ZH2HMrCT2a",
  "id" : 306490156414808064,
  "created_at" : "2013-02-26 19:45:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/M01oJhuAxo",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/statuses\/58261582",
      "display_url" : "twitter.com\/qrush\/statuses\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306474973273407488",
  "text" : "Some things never change: https:\/\/t.co\/M01oJhuAxo",
  "id" : 306474973273407488,
  "created_at" : "2013-02-26 18:45:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 0, 11 ],
      "id_str" : "14620776",
      "id" : 14620776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306473906468974592",
  "geo" : { },
  "id_str" : "306474410485882880",
  "in_reply_to_user_id" : 14620776,
  "text" : "@ellenchisa i can't imagine it at a giant corporate place. *shudder*",
  "id" : 306474410485882880,
  "in_reply_to_status_id" : 306473906468974592,
  "created_at" : "2013-02-26 18:42:48 +0000",
  "in_reply_to_screen_name" : "ellenchisa",
  "in_reply_to_user_id_str" : "14620776",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 0, 11 ],
      "id_str" : "14620776",
      "id" : 14620776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306473274177646592",
  "geo" : { },
  "id_str" : "306473657125978112",
  "in_reply_to_user_id" : 14620776,
  "text" : "@ellenchisa you haven't really experienced remote work then :)",
  "id" : 306473657125978112,
  "in_reply_to_status_id" : 306473274177646592,
  "created_at" : "2013-02-26 18:39:48 +0000",
  "in_reply_to_screen_name" : "ellenchisa",
  "in_reply_to_user_id_str" : "14620776",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306472200796520448",
  "text" : "Interesting Rails 4 changes I've noticed so far: No more script\/ dir by default, test\/functionals is now test\/controllers.",
  "id" : 306472200796520448,
  "created_at" : "2013-02-26 18:34:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Sanders",
      "screen_name" : "isaacsanders",
      "indices" : [ 0, 13 ],
      "id_str" : "31571600",
      "id" : 31571600
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 20, 30 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Synacor",
      "screen_name" : "Synacor",
      "indices" : [ 66, 74 ],
      "id_str" : "19976046",
      "id" : 19976046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306452257224937473",
  "geo" : { },
  "id_str" : "306459282617020417",
  "in_reply_to_user_id" : 31571600,
  "text" : "@isaacsanders I bet @magnachef can help out, also I'm pretty sure @synacor is always looking!",
  "id" : 306459282617020417,
  "in_reply_to_status_id" : 306452257224937473,
  "created_at" : "2013-02-26 17:42:41 +0000",
  "in_reply_to_screen_name" : "isaacsanders",
  "in_reply_to_user_id_str" : "31571600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306450326788128770",
  "text" : "RT @aquaranto: Advice of the day: don't code angry. \n\nPfft.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306445774823239680",
    "text" : "Advice of the day: don't code angry. \n\nPfft.",
    "id" : 306445774823239680,
    "created_at" : "2013-02-26 16:49:00 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 306450326788128770,
  "created_at" : "2013-02-26 17:07:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Chan",
      "screen_name" : "chantastic",
      "indices" : [ 0, 11 ],
      "id_str" : "12745092",
      "id" : 12745092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306273279696588800",
  "geo" : { },
  "id_str" : "306449855591612418",
  "in_reply_to_user_id" : 12745092,
  "text" : "@chantastic it's just attached to the scrollView of UIWebView. No magic really!",
  "id" : 306449855591612418,
  "in_reply_to_status_id" : 306273279696588800,
  "created_at" : "2013-02-26 17:05:13 +0000",
  "in_reply_to_screen_name" : "chantastic",
  "in_reply_to_user_id_str" : "12745092",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 0, 13 ],
      "id_str" : "23820237",
      "id" : 23820237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306201829396582400",
  "geo" : { },
  "id_str" : "306203208928350209",
  "in_reply_to_user_id" : 23820237,
  "text" : "@IanCAnderson woot!!",
  "id" : 306203208928350209,
  "in_reply_to_status_id" : 306201829396582400,
  "created_at" : "2013-02-26 00:45:08 +0000",
  "in_reply_to_screen_name" : "IanCAnderson",
  "in_reply_to_user_id_str" : "23820237",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Petrie",
      "screen_name" : "geopet",
      "indices" : [ 0, 7 ],
      "id_str" : "14604055",
      "id" : 14604055
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 8, 19 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306099878734487553",
  "geo" : { },
  "id_str" : "306117215554502656",
  "in_reply_to_user_id" : 14604055,
  "text" : "@geopet @thoughtbot Thanks!",
  "id" : 306117215554502656,
  "in_reply_to_status_id" : 306099878734487553,
  "created_at" : "2013-02-25 19:03:26 +0000",
  "in_reply_to_screen_name" : "geopet",
  "in_reply_to_user_id_str" : "14604055",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 56, 66 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/306112954380742657\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/uZcIXdJ6rg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BD-IHDNCcAAhLPh.jpg",
      "id_str" : "306112954384936960",
      "id" : 306112954384936960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD-IHDNCcAAhLPh.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/uZcIXdJ6rg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306113416634982400",
  "text" : "RT @coworkbuffalo: A 3D printed Buffalo has appeared at @37signals! http:\/\/t.co\/uZcIXdJ6rg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 37, 47 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/306112954380742657\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/uZcIXdJ6rg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BD-IHDNCcAAhLPh.jpg",
        "id_str" : "306112954384936960",
        "id" : 306112954384936960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD-IHDNCcAAhLPh.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/uZcIXdJ6rg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306112954380742657",
    "text" : "A 3D printed Buffalo has appeared at @37signals! http:\/\/t.co\/uZcIXdJ6rg",
    "id" : 306112954380742657,
    "created_at" : "2013-02-25 18:46:30 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 306113416634982400,
  "created_at" : "2013-02-25 18:48:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hadfield",
      "screen_name" : "Cmdr_Hadfield",
      "indices" : [ 3, 17 ],
      "id_str" : "186154646",
      "id" : 186154646
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Cmdr_Hadfield\/status\/305797717861490688\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/uPF48QYly6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BD5pZ3rCYAEmUq9.jpg",
      "id_str" : "305797717869879297",
      "id" : 305797717869879297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD5pZ3rCYAEmUq9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/uPF48QYly6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306051341275504640",
  "text" : "RT @Cmdr_Hadfield: Niagara Falls in the night, and all the surrounding towns from St Catharines ON to Buffalo NY. http:\/\/t.co\/uPF48QYly6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Cmdr_Hadfield\/status\/305797717861490688\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/uPF48QYly6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BD5pZ3rCYAEmUq9.jpg",
        "id_str" : "305797717869879297",
        "id" : 305797717869879297,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD5pZ3rCYAEmUq9.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/uPF48QYly6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305797717861490688",
    "text" : "Niagara Falls in the night, and all the surrounding towns from St Catharines ON to Buffalo NY. http:\/\/t.co\/uPF48QYly6",
    "id" : 305797717861490688,
    "created_at" : "2013-02-24 21:53:52 +0000",
    "user" : {
      "name" : "Chris Hadfield",
      "screen_name" : "Cmdr_Hadfield",
      "protected" : false,
      "id_str" : "186154646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541256255679909889\/cmEdkkD4_normal.jpeg",
      "id" : 186154646,
      "verified" : true
    }
  },
  "id" : 306051341275504640,
  "created_at" : "2013-02-25 14:41:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 47, 57 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305875597207416833",
  "text" : "Hopefully going to unleash King of Tokyo on my @37signals coworkers this week. Expect rampaging.",
  "id" : 305875597207416833,
  "created_at" : "2013-02-25 03:03:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    }, {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 12, 18 ],
      "id_str" : "1679",
      "id" : 1679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305868958320443393",
  "geo" : { },
  "id_str" : "305875008524271617",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark @javan mind another? Looking for adventure. And food.",
  "id" : 305875008524271617,
  "in_reply_to_status_id" : 305868958320443393,
  "created_at" : "2013-02-25 03:00:59 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305852438324334593",
  "text" : "I think this plane is doing donuts in ORD for fun. Cruising around the runways at 30mph at least very far away from the gates.",
  "id" : 305852438324334593,
  "created_at" : "2013-02-25 01:31:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305851106305662977",
  "text" : "Hi Chicago!",
  "id" : 305851106305662977,
  "created_at" : "2013-02-25 01:26:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305842375354372099",
  "geo" : { },
  "id_str" : "305851055940456449",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k I think if you only have one Basecamp account visible in Launchpad this will happen.",
  "id" : 305851055940456449,
  "in_reply_to_status_id" : 305842375354372099,
  "created_at" : "2013-02-25 01:25:48 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rands",
      "screen_name" : "rands",
      "indices" : [ 132, 138 ],
      "id_str" : "30923",
      "id" : 30923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/9vEuKgGRh1",
      "expanded_url" : "http:\/\/www.randsinrepose.com\/archives\/2012\/11\/14\/stables_and_volatiles.html",
      "display_url" : "randsinrepose.com\/archives\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305816783544274944",
  "text" : "Stables and Volatiles should be required reading for any software developer: http:\/\/t.co\/9vEuKgGRh1 Thanks for this amazing insight @rands.",
  "id" : 305816783544274944,
  "created_at" : "2013-02-24 23:09:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305718918817935360",
  "text" : "Father, I will avenge you.",
  "id" : 305718918817935360,
  "created_at" : "2013-02-24 16:40:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/AL9gxbh2Nl",
      "expanded_url" : "http:\/\/www.ruby-lang.org\/en\/news\/2013\/02\/24\/ruby-2-0-0-p0-is-released\/",
      "display_url" : "ruby-lang.org\/en\/news\/2013\/0\u2026"
    }, {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/6ThLyD4YUw",
      "expanded_url" : "http:\/\/i.imgur.com\/KP0PMVl.gif",
      "display_url" : "i.imgur.com\/KP0PMVl.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "305675932595806208",
  "text" : "RUBY 2! http:\/\/t.co\/AL9gxbh2Nl VICTORY! http:\/\/t.co\/6ThLyD4YUw",
  "id" : 305675932595806208,
  "created_at" : "2013-02-24 13:49:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harley Inbody",
      "screen_name" : "hinbody",
      "indices" : [ 0, 8 ],
      "id_str" : "246389903",
      "id" : 246389903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305127715588149248",
  "geo" : { },
  "id_str" : "305674297748369408",
  "in_reply_to_user_id" : 246389903,
  "text" : "@hinbody hey there, could you open a github issue with the full trace of the error?",
  "id" : 305674297748369408,
  "in_reply_to_status_id" : 305127715588149248,
  "created_at" : "2013-02-24 13:43:26 +0000",
  "in_reply_to_screen_name" : "hinbody",
  "in_reply_to_user_id_str" : "246389903",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Chadwick",
      "screen_name" : "vertis",
      "indices" : [ 0, 7 ],
      "id_str" : "18786379",
      "id" : 18786379
    }, {
      "name" : "Mark Wolfe",
      "screen_name" : "wolfeidau",
      "indices" : [ 8, 18 ],
      "id_str" : "19803925",
      "id" : 19803925
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 19, 27 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305640214519480322",
  "geo" : { },
  "id_str" : "305673560020635648",
  "in_reply_to_user_id" : 18786379,
  "text" : "@vertis @wolfeidau @evanphx what\u2019s up? I\u2019m not on IRC constantly.",
  "id" : 305673560020635648,
  "in_reply_to_status_id" : 305640214519480322,
  "created_at" : "2013-02-24 13:40:30 +0000",
  "in_reply_to_screen_name" : "vertis",
  "in_reply_to_user_id_str" : "18786379",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305591731485810689",
  "geo" : { },
  "id_str" : "305673461781643264",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik thanks! Trials are free ;)",
  "id" : 305673461781643264,
  "in_reply_to_status_id" : 305591731485810689,
  "created_at" : "2013-02-24 13:40:07 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305414308634980352",
  "geo" : { },
  "id_str" : "305584365797253120",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik how is this hypermedia related?",
  "id" : 305584365797253120,
  "in_reply_to_status_id" : 305414308634980352,
  "created_at" : "2013-02-24 07:46:04 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Rusterholz",
      "screen_name" : "apeiros",
      "indices" : [ 0, 8 ],
      "id_str" : "69860704",
      "id" : 69860704
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 25, 33 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305408899907985408",
  "geo" : { },
  "id_str" : "305550519869509632",
  "in_reply_to_user_id" : 69860704,
  "text" : "@apeiros I think so? \/cc @drbrain",
  "id" : 305550519869509632,
  "in_reply_to_status_id" : 305408899907985408,
  "created_at" : "2013-02-24 05:31:35 +0000",
  "in_reply_to_screen_name" : "apeiros",
  "in_reply_to_user_id_str" : "69860704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Allen",
      "screen_name" : "jallen7usa",
      "indices" : [ 0, 11 ],
      "id_str" : "14083007",
      "id" : 14083007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305453652653527040",
  "geo" : { },
  "id_str" : "305550433118724097",
  "in_reply_to_user_id" : 14083007,
  "text" : "@jallen7usa awesome!",
  "id" : 305550433118724097,
  "in_reply_to_status_id" : 305453652653527040,
  "created_at" : "2013-02-24 05:31:14 +0000",
  "in_reply_to_screen_name" : "jallen7usa",
  "in_reply_to_user_id_str" : "14083007",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 0, 8 ],
      "id_str" : "5502392",
      "id" : 5502392
    }, {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 9, 15 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305542418202247168",
  "geo" : { },
  "id_str" : "305550288717238273",
  "in_reply_to_user_id" : 5502392,
  "text" : "@mojombo @parkr survey says yes. I\u2019m sick of YAML too but by sure of the way out of the maze",
  "id" : 305550288717238273,
  "in_reply_to_status_id" : 305542418202247168,
  "created_at" : "2013-02-24 05:30:40 +0000",
  "in_reply_to_screen_name" : "mojombo",
  "in_reply_to_user_id_str" : "5502392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 0, 8 ],
      "id_str" : "5502392",
      "id" : 5502392
    }, {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 46, 52 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305517551138533377",
  "geo" : { },
  "id_str" : "305536950306226176",
  "in_reply_to_user_id" : 5502392,
  "text" : "@mojombo is Jekyll going to move to this? \/cc @parkr",
  "id" : 305536950306226176,
  "in_reply_to_status_id" : 305517551138533377,
  "created_at" : "2013-02-24 04:37:40 +0000",
  "in_reply_to_screen_name" : "mojombo",
  "in_reply_to_user_id_str" : "5502392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Rusterholz",
      "screen_name" : "apeiros",
      "indices" : [ 0, 8 ],
      "id_str" : "69860704",
      "id" : 69860704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305257505095815168",
  "geo" : { },
  "id_str" : "305405679945003008",
  "in_reply_to_user_id" : 69860704,
  "text" : "@apeiros i have been holding out for RG 2.0's metadata",
  "id" : 305405679945003008,
  "in_reply_to_status_id" : 305257505095815168,
  "created_at" : "2013-02-23 19:56:02 +0000",
  "in_reply_to_screen_name" : "apeiros",
  "in_reply_to_user_id_str" : "69860704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/6YAi7mcKWp",
      "expanded_url" : "http:\/\/www.zdnet.com\/windows-azure-storage-issue-expired-https-certificate-possibly-at-fault-7000011705\/",
      "display_url" : "zdnet.com\/windows-azure-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305405361878339585",
  "text" : "Expired SSL cert causes worldwide outage for MS. For fuck's sake. http:\/\/t.co\/6YAi7mcKWp",
  "id" : 305405361878339585,
  "created_at" : "2013-02-23 19:54:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305145867453743104",
  "text" : "The best part of GTA3 is the opera radio station.",
  "id" : 305145867453743104,
  "created_at" : "2013-02-23 02:43:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305053092049727488",
  "geo" : { },
  "id_str" : "305053587816456193",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark not sure if positive, but you're welcome to visit here and see them!! (I know a certain dog who would be happy too)",
  "id" : 305053587816456193,
  "in_reply_to_status_id" : 305053092049727488,
  "created_at" : "2013-02-22 20:36:57 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305048076748476420",
  "text" : "Don't give the trolls food.",
  "id" : 305048076748476420,
  "created_at" : "2013-02-22 20:15:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    }, {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 14, 26 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305037616338849792",
  "geo" : { },
  "id_str" : "305038081243893763",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh Is @SteveStreza on this yet?",
  "id" : 305038081243893763,
  "in_reply_to_status_id" : 305037616338849792,
  "created_at" : "2013-02-22 19:35:20 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305012767700684802",
  "geo" : { },
  "id_str" : "305013608985808896",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo holy shit!",
  "id" : 305013608985808896,
  "in_reply_to_status_id" : 305012767700684802,
  "created_at" : "2013-02-22 17:58:05 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/6ThLyD4YUw",
      "expanded_url" : "http:\/\/i.imgur.com\/KP0PMVl.gif",
      "display_url" : "i.imgur.com\/KP0PMVl.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "304985850528296960",
  "text" : "Current status: http:\/\/t.co\/6ThLyD4YUw",
  "id" : 304985850528296960,
  "created_at" : "2013-02-22 16:07:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304385704450985984",
  "geo" : { },
  "id_str" : "304828848623726594",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant you could sell this",
  "id" : 304828848623726594,
  "in_reply_to_status_id" : 304385704450985984,
  "created_at" : "2013-02-22 05:43:55 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    }, {
      "name" : "Rigel St. Pierre",
      "screen_name" : "rigelstpierre",
      "indices" : [ 13, 27 ],
      "id_str" : "14143955",
      "id" : 14143955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304751008347734017",
  "geo" : { },
  "id_str" : "304821869276721152",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger @rigelstpierre yay!!",
  "id" : 304821869276721152,
  "in_reply_to_status_id" : 304751008347734017,
  "created_at" : "2013-02-22 05:16:11 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Tsujimoto",
      "screen_name" : "Tsuj10",
      "indices" : [ 0, 7 ],
      "id_str" : "61690399",
      "id" : 61690399
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 8, 19 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304644369976270849",
  "geo" : { },
  "id_str" : "304819560673079296",
  "in_reply_to_user_id" : 61690399,
  "text" : "@Tsuj10 @kevinpurdy yes! Thanks man.",
  "id" : 304819560673079296,
  "in_reply_to_status_id" : 304644369976270849,
  "created_at" : "2013-02-22 05:07:01 +0000",
  "in_reply_to_screen_name" : "Tsuj10",
  "in_reply_to_user_id_str" : "61690399",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304815604978810881",
  "geo" : { },
  "id_str" : "304816791601946624",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan wasn't taken as one - 'rebuilding' is too grandiose. thousands of small efforts add up and build momentum, and that is happening",
  "id" : 304816791601946624,
  "in_reply_to_status_id" : 304815604978810881,
  "created_at" : "2013-02-22 04:56:00 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304814056013975553",
  "geo" : { },
  "id_str" : "304815248064524289",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan sounds good - live elsewhere :)",
  "id" : 304815248064524289,
  "in_reply_to_status_id" : 304814056013975553,
  "created_at" : "2013-02-22 04:49:52 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304813051473973248",
  "text" : "I cannot wait to see my city revitalized: it's beginning, slowly. The signs are all there, it's just going to take time and positive people.",
  "id" : 304813051473973248,
  "created_at" : "2013-02-22 04:41:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/siPxUT1zHH",
      "expanded_url" : "https:\/\/sphotos-a.xx.fbcdn.net\/hphotos-ash3\/546387_432559246812852_1962638645_n.jpg",
      "display_url" : "sphotos-a.xx.fbcdn.net\/hphotos-ash3\/5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304812616113614848",
  "text" : "Aerial shot from the 70's, can't believe how bombed out Buffalo looks: https:\/\/t.co\/siPxUT1zHH",
  "id" : 304812616113614848,
  "created_at" : "2013-02-22 04:39:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/hCHLSOOyAU",
      "expanded_url" : "http:\/\/wnyheritagepress.org\/photos_week_2004\/shelton_square\/shelton_square.htm",
      "display_url" : "wnyheritagepress.org\/photos_week_20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304812472521617408",
  "text" : "So many decisions in the 70's still echo today in Buffalo...highways and destroying entire pedestrian squares :( http:\/\/t.co\/hCHLSOOyAU",
  "id" : 304812472521617408,
  "created_at" : "2013-02-22 04:38:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/VT6htSWqQU",
      "expanded_url" : "https:\/\/www.facebook.com\/pages\/The-Buffalo-History-Gazette\/167465306655582?sk=photos_stream",
      "display_url" : "facebook.com\/pages\/The-Buff\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304808146206072832",
  "text" : "Unbelievable to see the grandeur and decline of Buffalo over in photos...I'm beyond happy to help bring it back. https:\/\/t.co\/VT6htSWqQU",
  "id" : 304808146206072832,
  "created_at" : "2013-02-22 04:21:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304802541718339584",
  "geo" : { },
  "id_str" : "304804419264970752",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes i did the same thing -_-",
  "id" : 304804419264970752,
  "in_reply_to_status_id" : 304802541718339584,
  "created_at" : "2013-02-22 04:06:51 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 0, 6 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "(\u256F\u00B0\u25A1\u00B0)\u256F\uFE35(\u03DB\u3123\u0287lo\u0287s@)",
      "screen_name" : "stolt45",
      "indices" : [ 7, 15 ],
      "id_str" : "9483652",
      "id" : 9483652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304800360919355392",
  "geo" : { },
  "id_str" : "304800399607603200",
  "in_reply_to_user_id" : 5743852,
  "text" : "@qrush @stolt45 **original wing sauce",
  "id" : 304800399607603200,
  "in_reply_to_status_id" : 304800360919355392,
  "created_at" : "2013-02-22 03:50:52 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\u256F\u00B0\u25A1\u00B0)\u256F\uFE35(\u03DB\u3123\u0287lo\u0287s@)",
      "screen_name" : "stolt45",
      "indices" : [ 0, 8 ],
      "id_str" : "9483652",
      "id" : 9483652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ozD0MrjFu2",
      "expanded_url" : "http:\/\/food.quaran.to\/",
      "display_url" : "food.quaran.to"
    } ]
  },
  "in_reply_to_status_id_str" : "304800042592632834",
  "geo" : { },
  "id_str" : "304800360919355392",
  "in_reply_to_user_id" : 9483652,
  "text" : "@stolt45 It is the base for the original wing sound. buddy here mixes it with Tiger Sauce to create ANDY SAUCE: http:\/\/t.co\/ozD0MrjFu2",
  "id" : 304800360919355392,
  "in_reply_to_status_id" : 304800042592632834,
  "created_at" : "2013-02-22 03:50:43 +0000",
  "in_reply_to_screen_name" : "stolt45",
  "in_reply_to_user_id_str" : "9483652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304799547694120961",
  "text" : "Any githubbers around and available to help in #rubygems on freenode ? Need some help with the Code Search.",
  "id" : 304799547694120961,
  "created_at" : "2013-02-22 03:47:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\u256F\u00B0\u25A1\u00B0)\u256F\uFE35(\u03DB\u3123\u0287lo\u0287s@)",
      "screen_name" : "stolt45",
      "indices" : [ 0, 8 ],
      "id_str" : "9483652",
      "id" : 9483652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304799233318469632",
  "geo" : { },
  "id_str" : "304799435777515520",
  "in_reply_to_user_id" : 9483652,
  "text" : "@stolt45 I put that shit on everything\u2122",
  "id" : 304799435777515520,
  "in_reply_to_status_id" : 304799233318469632,
  "created_at" : "2013-02-22 03:47:03 +0000",
  "in_reply_to_screen_name" : "stolt45",
  "in_reply_to_user_id_str" : "9483652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304798822800953344",
  "text" : "PSA if you publish your dotfiles to github (or anywhere) PLEASE don't include your rubygems_api_key in your .gemrc!",
  "id" : 304798822800953344,
  "created_at" : "2013-02-22 03:44:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 0, 9 ],
      "id_str" : "14925480",
      "id" : 14925480
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 10, 18 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304796699371663361",
  "geo" : { },
  "id_str" : "304797443797700609",
  "in_reply_to_user_id" : 14925480,
  "text" : "@nirvdrum @evanphx this search isn\u2019t that good either\u2026would be nice to narrow down to just dotfiles",
  "id" : 304797443797700609,
  "in_reply_to_status_id" : 304796699371663361,
  "created_at" : "2013-02-22 03:39:08 +0000",
  "in_reply_to_screen_name" : "nirvdrum",
  "in_reply_to_user_id_str" : "14925480",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 0, 9 ],
      "id_str" : "14925480",
      "id" : 14925480
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 24, 32 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304794099658129409",
  "geo" : { },
  "id_str" : "304796216796000256",
  "in_reply_to_user_id" : 14925480,
  "text" : "@nirvdrum oh god :( \/cc @evanphx maybe we should just reset all of these keys?",
  "id" : 304796216796000256,
  "in_reply_to_status_id" : 304794099658129409,
  "created_at" : "2013-02-22 03:34:15 +0000",
  "in_reply_to_screen_name" : "nirvdrum",
  "in_reply_to_user_id_str" : "14925480",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 24, 32 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 36, 47 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304794042057773056",
  "geo" : { },
  "id_str" : "304794930738507777",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella lame. Ping @evanphx or @laserlemon any ideas?",
  "id" : 304794930738507777,
  "in_reply_to_status_id" : 304794042057773056,
  "created_at" : "2013-02-22 03:29:08 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Pike",
      "screen_name" : "adrianpike",
      "indices" : [ 0, 11 ],
      "id_str" : "12453752",
      "id" : 12453752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304773154293833730",
  "geo" : { },
  "id_str" : "304773844734984193",
  "in_reply_to_user_id" : 12453752,
  "text" : "@adrianpike MEEPLES! TONIGHT WE SCORE IN HELL!",
  "id" : 304773844734984193,
  "in_reply_to_status_id" : 304773154293833730,
  "created_at" : "2013-02-22 02:05:21 +0000",
  "in_reply_to_screen_name" : "adrianpike",
  "in_reply_to_user_id_str" : "12453752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304772489970597888",
  "text" : "I don\u2019t have nearly enough Carcassone games going on. I\u2019m quaranto on Game Center. Leave your meeples at the door.",
  "id" : 304772489970597888,
  "created_at" : "2013-02-22 01:59:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 117, 129 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304771163240939521",
  "text" : "Absolutely loving the humanity behind stories in The Magazine. These are real people and real words. Thanks for this @marcoarment.",
  "id" : 304771163240939521,
  "created_at" : "2013-02-22 01:54:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 24, 36 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/pKwG4ZXtOE",
      "expanded_url" : "https:\/\/www.facebook.com\/events\/607507745942007\/",
      "display_url" : "facebook.com\/events\/6075077\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304635030049783808",
  "text" : "Friends near DC, go see @AqueousBand tonight. You won't be disappointed: https:\/\/t.co\/pKwG4ZXtOE",
  "id" : 304635030049783808,
  "created_at" : "2013-02-21 16:53:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304630775473639424",
  "text" : "@juliepagano holy crap i'm getting $5\/week!?!?! &lt;3",
  "id" : 304630775473639424,
  "created_at" : "2013-02-21 16:36:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin T.A. Gray",
      "screen_name" : "colinta",
      "indices" : [ 16, 24 ],
      "id_str" : "270963272",
      "id" : 270963272
    }, {
      "name" : "joffrey jaffeux",
      "screen_name" : "joffreyjaffeux",
      "indices" : [ 30, 45 ],
      "id_str" : "19398736",
      "id" : 19398736
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 56, 67 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304623196047564800",
  "in_reply_to_user_id" : 19398736,
  "text" : "Big congrats to @colinta and \n@joffreyjaffeux ! Viva la @RubyMotion!",
  "id" : 304623196047564800,
  "created_at" : "2013-02-21 16:06:44 +0000",
  "in_reply_to_screen_name" : "joffreyjaffeux",
  "in_reply_to_user_id_str" : "19398736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Dot Com",
      "screen_name" : "BuffaloDotCom",
      "indices" : [ 14, 28 ],
      "id_str" : "25321479",
      "id" : 25321479
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 59, 73 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/BTYU9NUtL2",
      "expanded_url" : "http:\/\/ow.ly\/hTgmy",
      "display_url" : "ow.ly\/hTgmy"
    } ]
  },
  "geo" : { },
  "id_str" : "304600588014981121",
  "text" : "Big thanks to @BuffaloDotCom for doing a great write up on @coworkbuffalo: http:\/\/t.co\/BTYU9NUtL2",
  "id" : 304600588014981121,
  "created_at" : "2013-02-21 14:36:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Dot Com",
      "screen_name" : "BuffaloDotCom",
      "indices" : [ 3, 17 ],
      "id_str" : "25321479",
      "id" : 25321479
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 40, 54 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/gP8ZctsY",
      "expanded_url" : "http:\/\/ow.ly\/hTgmy",
      "display_url" : "ow.ly\/hTgmy"
    } ]
  },
  "geo" : { },
  "id_str" : "304600416371486721",
  "text" : "RT @BuffaloDotCom: Have you checked out @CoworkBuffalo's space? Cozy, slightly geeky, inspiring place to do work. Free this Friday: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 21, 35 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/gP8ZctsY",
        "expanded_url" : "http:\/\/ow.ly\/hTgmy",
        "display_url" : "ow.ly\/hTgmy"
      } ]
    },
    "geo" : { },
    "id_str" : "304283205140365312",
    "text" : "Have you checked out @CoworkBuffalo's space? Cozy, slightly geeky, inspiring place to do work. Free this Friday: http:\/\/t.co\/gP8ZctsY",
    "id" : 304283205140365312,
    "created_at" : "2013-02-20 17:35:44 +0000",
    "user" : {
      "name" : "Buffalo Dot Com",
      "screen_name" : "BuffaloDotCom",
      "protected" : false,
      "id_str" : "25321479",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467067080139759616\/zJQOtsXK_normal.jpeg",
      "id" : 25321479,
      "verified" : false
    }
  },
  "id" : 304600416371486721,
  "created_at" : "2013-02-21 14:36:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304461565699166208",
  "geo" : { },
  "id_str" : "304468253961510912",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff I remember pizza lunchables, and that tiny red stick to spread sauce with.",
  "id" : 304468253961510912,
  "in_reply_to_status_id" : 304461565699166208,
  "created_at" : "2013-02-21 05:51:03 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304424338046713856",
  "text" : "Apologize. Just fucking apologize.",
  "id" : 304424338046713856,
  "created_at" : "2013-02-21 02:56:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Jackson",
      "screen_name" : "peteonrails",
      "indices" : [ 0, 12 ],
      "id_str" : "15348650",
      "id" : 15348650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304421932902780928",
  "geo" : { },
  "id_str" : "304424233994420224",
  "in_reply_to_user_id" : 15348650,
  "text" : "@peteonrails I meant JFA. Oops.",
  "id" : 304424233994420224,
  "in_reply_to_status_id" : 304421932902780928,
  "created_at" : "2013-02-21 02:56:07 +0000",
  "in_reply_to_screen_name" : "peteonrails",
  "in_reply_to_user_id_str" : "15348650",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Eats",
      "screen_name" : "BuffaloEats",
      "indices" : [ 0, 12 ],
      "id_str" : "21758029",
      "id" : 21758029
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 36, 50 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304401913909223424",
  "geo" : { },
  "id_str" : "304418972282023939",
  "in_reply_to_user_id" : 21758029,
  "text" : "@BuffaloEats thanks for the link to @coworkbuffalo - mind fixing the name to \"CoworkBuffalo\" ? been trying to keep it consistent.",
  "id" : 304418972282023939,
  "in_reply_to_status_id" : 304401913909223424,
  "created_at" : "2013-02-21 02:35:13 +0000",
  "in_reply_to_screen_name" : "BuffaloEats",
  "in_reply_to_user_id_str" : "21758029",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 75, 81 ],
      "id_str" : "1438261",
      "id" : 1438261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/cRWD3UNmNy",
      "expanded_url" : "http:\/\/song-of-github.herokuapp.com\/?username=qrush",
      "display_url" : "song-of-github.herokuapp.com\/?username=qrush"
    } ]
  },
  "geo" : { },
  "id_str" : "304414332664557568",
  "text" : "Let me sing you the song of my contributions.\n http:\/\/t.co\/cRWD3UNmNy (via @atmos)",
  "id" : 304414332664557568,
  "created_at" : "2013-02-21 02:16:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304413610774503424",
  "text" : "Tweetbot for iPad is gorgeous. Thanks to anyone who suggested it.",
  "id" : 304413610774503424,
  "created_at" : "2013-02-21 02:13:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Refactor.tv",
      "screen_name" : "refactortv",
      "indices" : [ 0, 11 ],
      "id_str" : "734611236",
      "id" : 734611236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304340092556808192",
  "geo" : { },
  "id_str" : "304402003906400257",
  "in_reply_to_user_id" : 734611236,
  "text" : "@refactortv thanks for the shoutout!",
  "id" : 304402003906400257,
  "in_reply_to_status_id" : 304340092556808192,
  "created_at" : "2013-02-21 01:27:47 +0000",
  "in_reply_to_screen_name" : "refactortv",
  "in_reply_to_user_id_str" : "734611236",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 0, 6 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "synace",
      "screen_name" : "synacecom",
      "indices" : [ 7, 17 ],
      "id_str" : "75330669",
      "id" : 75330669
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 78, 92 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304378470174179328",
  "geo" : { },
  "id_str" : "304379915673931776",
  "in_reply_to_user_id" : 5743852,
  "text" : "@qrush @synacecom sorry, this sounds douchey: just let me know, or i'll be at @coworkbuffalo all day tomorrow and Friday.",
  "id" : 304379915673931776,
  "in_reply_to_status_id" : 304378470174179328,
  "created_at" : "2013-02-21 00:00:01 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "synace",
      "screen_name" : "synacecom",
      "indices" : [ 0, 10 ],
      "id_str" : "75330669",
      "id" : 75330669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304375410072883200",
  "geo" : { },
  "id_str" : "304378470174179328",
  "in_reply_to_user_id" : 75330669,
  "text" : "@synacecom really busy, i don't get why email isn't sufficient?",
  "id" : 304378470174179328,
  "in_reply_to_status_id" : 304375410072883200,
  "created_at" : "2013-02-20 23:54:17 +0000",
  "in_reply_to_screen_name" : "synacecom",
  "in_reply_to_user_id_str" : "75330669",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "synace",
      "screen_name" : "synacecom",
      "indices" : [ 0, 10 ],
      "id_str" : "75330669",
      "id" : 75330669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304362916042387457",
  "geo" : { },
  "id_str" : "304370107335974913",
  "in_reply_to_user_id" : 75330669,
  "text" : "@synacecom Email works? Unless if you\u2019re mushing my husky in this weather tonight :)",
  "id" : 304370107335974913,
  "in_reply_to_status_id" : 304362916042387457,
  "created_at" : "2013-02-20 23:21:03 +0000",
  "in_reply_to_screen_name" : "synacecom",
  "in_reply_to_user_id_str" : "75330669",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304360017136611328",
  "text" : "Sounds like Tweetbot is the answer. Any iPad specific apps I should check out? Finally have upgraded from the iPad 1.",
  "id" : 304360017136611328,
  "created_at" : "2013-02-20 22:40:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304352201130790912",
  "geo" : { },
  "id_str" : "304353649721749504",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench perfect corner for this photo",
  "id" : 304353649721749504,
  "in_reply_to_status_id" : 304352201130790912,
  "created_at" : "2013-02-20 22:15:39 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304334618780389377",
  "text" : "*Preparing for an onslaught* What's the best Twitter client for iPad?",
  "id" : 304334618780389377,
  "created_at" : "2013-02-20 21:00:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304325155461660672",
  "geo" : { },
  "id_str" : "304325357299974144",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo Dude.",
  "id" : 304325357299974144,
  "in_reply_to_status_id" : 304325155461660672,
  "created_at" : "2013-02-20 20:23:13 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304323798444945410",
  "text" : "About fucking time, Sabres.",
  "id" : 304323798444945410,
  "created_at" : "2013-02-20 20:17:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo News Food",
      "screen_name" : "BuffaloFood",
      "indices" : [ 0, 12 ],
      "id_str" : "173551074",
      "id" : 173551074
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 28, 42 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304272248137736192",
  "geo" : { },
  "id_str" : "304310286205210625",
  "in_reply_to_user_id" : 173551074,
  "text" : "@BuffaloFood Thanks for the @coworkbuffalo link!",
  "id" : 304310286205210625,
  "in_reply_to_status_id" : 304272248137736192,
  "created_at" : "2013-02-20 19:23:20 +0000",
  "in_reply_to_screen_name" : "BuffaloFood",
  "in_reply_to_user_id_str" : "173551074",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Penn",
      "screen_name" : "jonathanpenn",
      "indices" : [ 0, 13 ],
      "id_str" : "9896112",
      "id" : 9896112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/bSnrWzl1",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=0CizU8aB3c8",
      "display_url" : "youtube.com\/watch?v=0CizU8\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "304259875788181504",
  "geo" : { },
  "id_str" : "304261585537486849",
  "in_reply_to_user_id" : 9896112,
  "text" : "@jonathanpenn http:\/\/t.co\/bSnrWzl1 ?",
  "id" : 304261585537486849,
  "in_reply_to_status_id" : 304259875788181504,
  "created_at" : "2013-02-20 16:09:49 +0000",
  "in_reply_to_screen_name" : "jonathanpenn",
  "in_reply_to_user_id_str" : "9896112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304066410424958977",
  "geo" : { },
  "id_str" : "304067919732695041",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej once I unlocked the airport I stopped doing missions. Trying to avoid side quests for these run throughs",
  "id" : 304067919732695041,
  "in_reply_to_status_id" : 304066410424958977,
  "created_at" : "2013-02-20 03:20:16 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304066230833270785",
  "text" : "Been replaying GTA3. Still so good. I think Vice City might be next.",
  "id" : 304066230833270785,
  "created_at" : "2013-02-20 03:13:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304059460085751810",
  "geo" : { },
  "id_str" : "304063532431982592",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi yes, it\u2019s amazing. Marinated some steak in it too.",
  "id" : 304063532431982592,
  "in_reply_to_status_id" : 304059460085751810,
  "created_at" : "2013-02-20 03:02:50 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304059460085751810",
  "geo" : { },
  "id_str" : "304060416139620352",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi yes.",
  "id" : 304060416139620352,
  "in_reply_to_status_id" : 304059460085751810,
  "created_at" : "2013-02-20 02:50:27 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304058328491884544",
  "geo" : { },
  "id_str" : "304058958992265216",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi ha! try The Knot. So good.",
  "id" : 304058958992265216,
  "in_reply_to_status_id" : 304058328491884544,
  "created_at" : "2013-02-20 02:44:39 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Changelog",
      "screen_name" : "TheChangelog",
      "indices" : [ 3, 16 ],
      "id_str" : "90286855",
      "id" : 90286855
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 46, 55 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/yBT2W8Og",
      "expanded_url" : "http:\/\/thechangelog.com\/openhack-your-city\/",
      "display_url" : "thechangelog.com\/openhack-your-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304055984400248833",
  "text" : "RT @TheChangelog: A few weeks back we posted '@OpenHack your city' http:\/\/t.co\/yBT2W8Og",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 28, 37 ],
        "id_str" : "715440464",
        "id" : 715440464
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/yBT2W8Og",
        "expanded_url" : "http:\/\/thechangelog.com\/openhack-your-city\/",
        "display_url" : "thechangelog.com\/openhack-your-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304046042356252672",
    "text" : "A few weeks back we posted '@OpenHack your city' http:\/\/t.co\/yBT2W8Og",
    "id" : 304046042356252672,
    "created_at" : "2013-02-20 01:53:20 +0000",
    "user" : {
      "name" : "The Changelog",
      "screen_name" : "TheChangelog",
      "protected" : false,
      "id_str" : "90286855",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000420553878\/3ce7f958eb7d25c30ca97d2fc43cbf7d_normal.jpeg",
      "id" : 90286855,
      "verified" : false
    }
  },
  "id" : 304055984400248833,
  "created_at" : "2013-02-20 02:32:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Blitzer",
      "screen_name" : "ABBlitzer",
      "indices" : [ 0, 10 ],
      "id_str" : "213297524",
      "id" : 213297524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304032143657553921",
  "geo" : { },
  "id_str" : "304036860580200449",
  "in_reply_to_user_id" : 213297524,
  "text" : "@ABBlitzer it's a 1.0. Bound to disappoint some folks. Definitely just getting started.",
  "id" : 304036860580200449,
  "in_reply_to_status_id" : 304032143657553921,
  "created_at" : "2013-02-20 01:16:50 +0000",
  "in_reply_to_screen_name" : "ABBlitzer",
  "in_reply_to_user_id_str" : "213297524",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 11, 20 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 122 ],
      "url" : "https:\/\/t.co\/4l8DZEKs",
      "expanded_url" : "https:\/\/github.com\/OpenHack\/openhack.github.com\/issues\/104",
      "display_url" : "github.com\/OpenHack\/openh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304034694511611905",
  "text" : "Looks like @OpenHack is in almost 50 cities, but not SF yet. Who lives there and can make it happen? https:\/\/t.co\/4l8DZEKs",
  "id" : 304034694511611905,
  "created_at" : "2013-02-20 01:08:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 14, 24 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 40, 49 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 66, 80 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304025975669268480",
  "text" : "Big thanks to @37signals for sponsoring @OpenHack Buffalo tonight @coworkbuffalo. Code &amp; community...need more!",
  "id" : 304025975669268480,
  "created_at" : "2013-02-20 00:33:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damn you, Kakarot!",
      "screen_name" : "anima",
      "indices" : [ 0, 6 ],
      "id_str" : "6400032",
      "id" : 6400032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304015713755086848",
  "geo" : { },
  "id_str" : "304019932272803841",
  "in_reply_to_user_id" : 6400032,
  "text" : "@anima we've seen a few reports of this, not sure what's up yet. looking into it.",
  "id" : 304019932272803841,
  "in_reply_to_status_id" : 304015713755086848,
  "created_at" : "2013-02-20 00:09:34 +0000",
  "in_reply_to_screen_name" : "anima",
  "in_reply_to_user_id_str" : "6400032",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JC Grubbs",
      "screen_name" : "thegrubbsian",
      "indices" : [ 0, 13 ],
      "id_str" : "12521122",
      "id" : 12521122
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 35, 44 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304012234743492608",
  "in_reply_to_user_id" : 12521122,
  "text" : "@thegrubbsian hey, when's the next @openhack chicago? I'm going to be in town all week and would love to help out.",
  "id" : 304012234743492608,
  "created_at" : "2013-02-19 23:38:59 +0000",
  "in_reply_to_screen_name" : "thegrubbsian",
  "in_reply_to_user_id_str" : "12521122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Mytko",
      "screen_name" : "BryanMytko",
      "indices" : [ 3, 14 ],
      "id_str" : "76849153",
      "id" : 76849153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/4wr1KjkQ",
      "expanded_url" : "http:\/\/guysamericankitchenandbar.com",
      "display_url" : "guysamericankitchenandbar.com"
    } ]
  },
  "geo" : { },
  "id_str" : "304005712978272256",
  "text" : "RT @BryanMytko: Guy Fieri didn't register his restaurant's domain name, so I picked it up. I think this new menu look great\nhttp:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/4wr1KjkQ",
        "expanded_url" : "http:\/\/guysamericankitchenandbar.com",
        "display_url" : "guysamericankitchenandbar.com"
      } ]
    },
    "geo" : { },
    "id_str" : "303995825825128448",
    "text" : "Guy Fieri didn't register his restaurant's domain name, so I picked it up. I think this new menu look great\nhttp:\/\/t.co\/4wr1KjkQ",
    "id" : 303995825825128448,
    "created_at" : "2013-02-19 22:33:47 +0000",
    "user" : {
      "name" : "Bryan Mytko",
      "screen_name" : "BryanMytko",
      "protected" : false,
      "id_str" : "76849153",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000516075030\/94569b3fddc1de4814cb7c07fca7d389_normal.jpeg",
      "id" : 76849153,
      "verified" : false
    }
  },
  "id" : 304005712978272256,
  "created_at" : "2013-02-19 23:13:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304005305161904129",
  "text" : "\"Ranch hose optional, but recommended\"",
  "id" : 304005305161904129,
  "created_at" : "2013-02-19 23:11:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/5hlcudaX",
      "expanded_url" : "http:\/\/guysamericankitchenandbar.com\/",
      "display_url" : "guysamericankitchenandbar.com"
    } ]
  },
  "geo" : { },
  "id_str" : "304004744865800193",
  "text" : "GO BIG OR GO HOME http:\/\/t.co\/5hlcudaX",
  "id" : 304004744865800193,
  "created_at" : "2013-02-19 23:09:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304003588471013377",
  "geo" : { },
  "id_str" : "304004040440832000",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten Oh, is that upstate?",
  "id" : 304004040440832000,
  "in_reply_to_status_id" : 304003588471013377,
  "created_at" : "2013-02-19 23:06:26 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Yun",
      "screen_name" : "dougyun",
      "indices" : [ 0, 8 ],
      "id_str" : "324160285",
      "id" : 324160285
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 9, 18 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 41, 46 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303990848280985600",
  "geo" : { },
  "id_str" : "303991493188804608",
  "in_reply_to_user_id" : 324160285,
  "text" : "@DougYun @bquarant I think you just made @r00k's day, possibly week",
  "id" : 303991493188804608,
  "in_reply_to_status_id" : 303990848280985600,
  "created_at" : "2013-02-19 22:16:34 +0000",
  "in_reply_to_screen_name" : "dougyun",
  "in_reply_to_user_id_str" : "324160285",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303985418687352832",
  "text" : "Read more code.",
  "id" : 303985418687352832,
  "created_at" : "2013-02-19 21:52:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Yun",
      "screen_name" : "dougyun",
      "indices" : [ 0, 8 ],
      "id_str" : "324160285",
      "id" : 324160285
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 9, 18 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303964277428068352",
  "geo" : { },
  "id_str" : "303964613832237056",
  "in_reply_to_user_id" : 324160285,
  "text" : "@DougYun @bquarant let the normal mode flow through you",
  "id" : 303964613832237056,
  "in_reply_to_status_id" : 303964277428068352,
  "created_at" : "2013-02-19 20:29:45 +0000",
  "in_reply_to_screen_name" : "dougyun",
  "in_reply_to_user_id_str" : "324160285",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David T. Harris",
      "screen_name" : "DavidTCHarris",
      "indices" : [ 0, 14 ],
      "id_str" : "14993443",
      "id" : 14993443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303934432853782528",
  "geo" : { },
  "id_str" : "303944414689112065",
  "in_reply_to_user_id" : 14993443,
  "text" : "@DavidTCHarris Thanks!",
  "id" : 303944414689112065,
  "in_reply_to_status_id" : 303934432853782528,
  "created_at" : "2013-02-19 19:09:30 +0000",
  "in_reply_to_screen_name" : "DavidTCHarris",
  "in_reply_to_user_id_str" : "14993443",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damn you, Kakarot!",
      "screen_name" : "anima",
      "indices" : [ 0, 6 ],
      "id_str" : "6400032",
      "id" : 6400032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303892118374596608",
  "geo" : { },
  "id_str" : "303916949979672576",
  "in_reply_to_user_id" : 6400032,
  "text" : "@anima hey there, what are you running into?",
  "id" : 303916949979672576,
  "in_reply_to_status_id" : 303892118374596608,
  "created_at" : "2013-02-19 17:20:22 +0000",
  "in_reply_to_screen_name" : "anima",
  "in_reply_to_user_id_str" : "6400032",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arnold",
      "screen_name" : "tonyarnold",
      "indices" : [ 0, 11 ],
      "id_str" : "640903",
      "id" : 640903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303672338426245120",
  "geo" : { },
  "id_str" : "303737103706116096",
  "in_reply_to_user_id" : 640903,
  "text" : "@tonyarnold you should post to the RM google group about this! At least so it shows up when googling for others.",
  "id" : 303737103706116096,
  "in_reply_to_status_id" : 303672338426245120,
  "created_at" : "2013-02-19 05:25:43 +0000",
  "in_reply_to_screen_name" : "tonyarnold",
  "in_reply_to_user_id_str" : "640903",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Reeder",
      "screen_name" : "treeder",
      "indices" : [ 0, 8 ],
      "id_str" : "14134156",
      "id" : 14134156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303634130653020161",
  "geo" : { },
  "id_str" : "303641799006748673",
  "in_reply_to_user_id" : 14134156,
  "text" : "@treeder also how important is the name of this thing if you've waited so long? why not just ship it?",
  "id" : 303641799006748673,
  "in_reply_to_status_id" : 303634130653020161,
  "created_at" : "2013-02-18 23:07:00 +0000",
  "in_reply_to_screen_name" : "treeder",
  "in_reply_to_user_id_str" : "14134156",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Reeder",
      "screen_name" : "treeder",
      "indices" : [ 0, 8 ],
      "id_str" : "14134156",
      "id" : 14134156
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 39, 47 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/NJdqWZAL",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "303634130653020161",
  "geo" : { },
  "id_str" : "303641708443348992",
  "in_reply_to_user_id" : 14134156,
  "text" : "@treeder I'm not sure if anyone beyond @evanphx has both access to deploy (for console access) and access to http:\/\/t.co\/NJdqWZAL.",
  "id" : 303641708443348992,
  "in_reply_to_status_id" : 303634130653020161,
  "created_at" : "2013-02-18 23:06:39 +0000",
  "in_reply_to_screen_name" : "treeder",
  "in_reply_to_user_id_str" : "14134156",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303627902749134849",
  "text" : "Prediction for next GitHubber: Weird Al Yankovic. New album: OCTOPUS MERGE featuring new hit single \"Rebase Paradise\"",
  "id" : 303627902749134849,
  "created_at" : "2013-02-18 22:11:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Reeder",
      "screen_name" : "treeder",
      "indices" : [ 0, 8 ],
      "id_str" : "14134156",
      "id" : 14134156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303615906121150464",
  "geo" : { },
  "id_str" : "303616282555711489",
  "in_reply_to_user_id" : 14134156,
  "text" : "@treeder I'm not the only one who can fix this, sadly, but not many others have free time. This is just the nature of a volunteer service.",
  "id" : 303616282555711489,
  "in_reply_to_status_id" : 303615906121150464,
  "created_at" : "2013-02-18 21:25:37 +0000",
  "in_reply_to_screen_name" : "treeder",
  "in_reply_to_user_id_str" : "14134156",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Reeder",
      "screen_name" : "treeder",
      "indices" : [ 0, 8 ],
      "id_str" : "14134156",
      "id" : 14134156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303615906121150464",
  "geo" : { },
  "id_str" : "303616069959024641",
  "in_reply_to_user_id" : 14134156,
  "text" : "@treeder Nope. Still don't have deploy hooked up yet. And I'm oncall this week at 37.",
  "id" : 303616069959024641,
  "in_reply_to_status_id" : 303615906121150464,
  "created_at" : "2013-02-18 21:24:46 +0000",
  "in_reply_to_screen_name" : "treeder",
  "in_reply_to_user_id_str" : "14134156",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/hAdsHIf7",
      "expanded_url" : "http:\/\/vimeo.com\/53749151",
      "display_url" : "vimeo.com\/53749151"
    } ]
  },
  "geo" : { },
  "id_str" : "303604138237886465",
  "text" : "LIAM. NEESONS. http:\/\/t.co\/hAdsHIf7",
  "id" : 303604138237886465,
  "created_at" : "2013-02-18 20:36:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303593934737797120",
  "text" : "Had some homemade DYI ~90% dark chocolate after a week on keto, and holy shit, it's amazing.",
  "id" : 303593934737797120,
  "created_at" : "2013-02-18 19:56:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 29, 43 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/S8GhCCHt",
      "expanded_url" : "http:\/\/www.buffalorising.com\/2013\/02\/coworkbuffalo-open-house.html",
      "display_url" : "buffalorising.com\/2013\/02\/cowork\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303593372046733312",
  "text" : "RT @coworkbuffalo: Thanks to @BuffaloRising and Jessica Edwards for writing about our space, its people, and its coffee. http:\/\/t.co\/S8G ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buffalo Rising",
        "screen_name" : "BuffaloRising",
        "indices" : [ 10, 24 ],
        "id_str" : "5896952",
        "id" : 5896952
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/S8GhCCHt",
        "expanded_url" : "http:\/\/www.buffalorising.com\/2013\/02\/coworkbuffalo-open-house.html",
        "display_url" : "buffalorising.com\/2013\/02\/cowork\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "303593257206706176",
    "text" : "Thanks to @BuffaloRising and Jessica Edwards for writing about our space, its people, and its coffee. http:\/\/t.co\/S8GhCCHt",
    "id" : 303593257206706176,
    "created_at" : "2013-02-18 19:54:07 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 303593372046733312,
  "created_at" : "2013-02-18 19:54:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 3, 9 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 117, 127 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303591519082905602",
  "text" : "RT @parkr: Writing commands for \u2018sub\u2019 is such an amazing experience. Write them in any language with ease. Thank you @37signals!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 106, 116 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303591291747434496",
    "text" : "Writing commands for \u2018sub\u2019 is such an amazing experience. Write them in any language with ease. Thank you @37signals!",
    "id" : 303591291747434496,
    "created_at" : "2013-02-18 19:46:19 +0000",
    "user" : {
      "name" : "Parker",
      "screen_name" : "parkr",
      "protected" : false,
      "id_str" : "1928021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518473290554146816\/vMQWizt5_normal.jpeg",
      "id" : 1928021,
      "verified" : false
    }
  },
  "id" : 303591519082905602,
  "created_at" : "2013-02-18 19:47:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 34, 48 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/1dRG57WF",
      "expanded_url" : "http:\/\/www.buffalorising.com\/2013\/02\/coworkbuffalo-open-house.html",
      "display_url" : "buffalorising.com\/2013\/02\/cowork\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303586819163955200",
  "text" : "Finally getting some coverage for @coworkbuffalo! http:\/\/t.co\/1dRG57WF",
  "id" : 303586819163955200,
  "created_at" : "2013-02-18 19:28:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Lunny",
      "screen_name" : "alunny",
      "indices" : [ 3, 10 ],
      "id_str" : "15990366",
      "id" : 15990366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303581609280561152",
  "text" : "RT @alunny: Every iOS app attempts to expand until it can browse the web.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303580817077194752",
    "text" : "Every iOS app attempts to expand until it can browse the web.",
    "id" : 303580817077194752,
    "created_at" : "2013-02-18 19:04:41 +0000",
    "user" : {
      "name" : "Andrew Lunny",
      "screen_name" : "alunny",
      "protected" : false,
      "id_str" : "15990366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477901729107697666\/rIOQlhQ-_normal.jpeg",
      "id" : 15990366,
      "verified" : false
    }
  },
  "id" : 303581609280561152,
  "created_at" : "2013-02-18 19:07:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 72, 79 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/WyD8xmUL",
      "expanded_url" : "http:\/\/www.youtubedoubler.com\/?video1=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D4vqnSwTXAAc%26feature%3Dyoutube_gdata_player&start1=&video2=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D4vqnSwTXAAc%26feature%3Dyoutube_gdata_player&start2=&authorName=qrush",
      "display_url" : "youtubedoubler.com\/?video1=https%\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303576842160459776",
  "text" : "DO DO THE THE HARLEM HARLEM SHAKE SHAKE http:\/\/t.co\/WyD8xmUL (thanks to @jmazzi)",
  "id" : 303576842160459776,
  "created_at" : "2013-02-18 18:48:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 41 ],
      "url" : "https:\/\/t.co\/keeVSURL",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=4vqnSwTXAAc&feature=youtube_gdata_player",
      "display_url" : "youtube.com\/watch?v=4vqnSw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303573269569757186",
  "text" : "DO THE HARLEM SHAKE https:\/\/t.co\/keeVSURL",
  "id" : 303573269569757186,
  "created_at" : "2013-02-18 18:34:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "indices" : [ 3, 11 ],
      "id_str" : "6532552",
      "id" : 6532552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303552828285263872",
  "text" : "RT @nkohari: I mean, seriously, is Hacker News and \/r\/programming the best we can do?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303552322091495424",
    "text" : "I mean, seriously, is Hacker News and \/r\/programming the best we can do?",
    "id" : 303552322091495424,
    "created_at" : "2013-02-18 17:11:27 +0000",
    "user" : {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "protected" : false,
      "id_str" : "6532552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486557242955534337\/o_ehcxEA_normal.jpeg",
      "id" : 6532552,
      "verified" : false
    }
  },
  "id" : 303552828285263872,
  "created_at" : "2013-02-18 17:13:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alli Suriani ",
      "screen_name" : "AlliBuffaloEats",
      "indices" : [ 0, 16 ],
      "id_str" : "17737129",
      "id" : 17737129
    }, {
      "name" : "Buffalo Eats",
      "screen_name" : "BuffaloEats",
      "indices" : [ 17, 29 ],
      "id_str" : "21758029",
      "id" : 21758029
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 30, 44 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303548634803343360",
  "geo" : { },
  "id_str" : "303550481811263488",
  "in_reply_to_user_id" : 17737129,
  "text" : "@AlliBuffaloEats @BuffaloEats @coworkbuffalo Just a normal day :)",
  "id" : 303550481811263488,
  "in_reply_to_status_id" : 303548634803343360,
  "created_at" : "2013-02-18 17:04:09 +0000",
  "in_reply_to_screen_name" : "AlliBuffaloEats",
  "in_reply_to_user_id_str" : "17737129",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/ZuuitR7w",
      "expanded_url" : "http:\/\/news.ycombinator.com",
      "display_url" : "news.ycombinator.com"
    } ]
  },
  "geo" : { },
  "id_str" : "303545331885420544",
  "text" : "Feels good, man: 127.0.0.1 http:\/\/t.co\/ZuuitR7w",
  "id" : 303545331885420544,
  "created_at" : "2013-02-18 16:43:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "12 Grain",
      "screen_name" : "12grainstudio",
      "indices" : [ 0, 14 ],
      "id_str" : "15650314",
      "id" : 15650314
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 32, 41 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "BfloFRED",
      "screen_name" : "BfloFRED",
      "indices" : [ 68, 77 ],
      "id_str" : "876930312",
      "id" : 876930312
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 99, 113 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303541182267527168",
  "geo" : { },
  "id_str" : "303541644966371328",
  "in_reply_to_user_id" : 15650314,
  "text" : "@12grainstudio I think starting @OpenHack gives us a heads up. Also @BfloFRED meets regularly here @coworkbuffalo. We aren't behind!",
  "id" : 303541644966371328,
  "in_reply_to_status_id" : 303541182267527168,
  "created_at" : "2013-02-18 16:29:02 +0000",
  "in_reply_to_screen_name" : "12grainstudio",
  "in_reply_to_user_id_str" : "15650314",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 61, 72 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/2EdPqvoX",
      "expanded_url" : "http:\/\/37svn.com\/3444",
      "display_url" : "37svn.com\/3444"
    } ]
  },
  "geo" : { },
  "id_str" : "303540534142722049",
  "text" : "\"We used Xcode for nothing\" - http:\/\/t.co\/2EdPqvoX Thanks to @thoughtbot for a fun interview!",
  "id" : 303540534142722049,
  "created_at" : "2013-02-18 16:24:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 11, 22 ],
      "id_str" : "14188391",
      "id" : 14188391
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 45, 59 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303532802119458818",
  "geo" : { },
  "id_str" : "303533141698695169",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @benjaminws Sure dude! Come up to @coworkbuffalo.",
  "id" : 303533141698695169,
  "in_reply_to_status_id" : 303532802119458818,
  "created_at" : "2013-02-18 15:55:15 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 32, 38 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/X4r7Ubeg",
      "expanded_url" : "http:\/\/bit.ly\/Xcd3O6",
      "display_url" : "bit.ly\/Xcd3O6"
    } ]
  },
  "geo" : { },
  "id_str" : "303522525063835649",
  "text" : "RT @thoughtbot: We're joined by @qrush on the podcast this week to talk about Basecamp for iOS, RubyMotion, and the RubyGems hacking htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 16, 22 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/X4r7Ubeg",
        "expanded_url" : "http:\/\/bit.ly\/Xcd3O6",
        "display_url" : "bit.ly\/Xcd3O6"
      } ]
    },
    "geo" : { },
    "id_str" : "303414078838292480",
    "text" : "We're joined by @qrush on the podcast this week to talk about Basecamp for iOS, RubyMotion, and the RubyGems hacking http:\/\/t.co\/X4r7Ubeg",
    "id" : 303414078838292480,
    "created_at" : "2013-02-18 08:02:08 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 303522525063835649,
  "created_at" : "2013-02-18 15:13:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303417232116031488",
  "geo" : { },
  "id_str" : "303516706070986754",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr yep! Tweet stalking :)",
  "id" : 303516706070986754,
  "in_reply_to_status_id" : 303417232116031488,
  "created_at" : "2013-02-18 14:49:56 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "coderjoe",
      "screen_name" : "coderjoe",
      "indices" : [ 0, 9 ],
      "id_str" : "15494948",
      "id" : 15494948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303370597533102081",
  "geo" : { },
  "id_str" : "303498883751895040",
  "in_reply_to_user_id" : 15494948,
  "text" : "@coderjoe I have played nothing like it. It\u2019s a visual memory brainfuck.",
  "id" : 303498883751895040,
  "in_reply_to_status_id" : 303370597533102081,
  "created_at" : "2013-02-18 13:39:07 +0000",
  "in_reply_to_screen_name" : "coderjoe",
  "in_reply_to_user_id_str" : "15494948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/vdkidheC",
      "expanded_url" : "http:\/\/flic.kr\/p\/dVMcGb",
      "display_url" : "flic.kr\/p\/dVMcGb"
    } ]
  },
  "geo" : { },
  "id_str" : "303360558613282816",
  "text" : "Pants Factory Fun! 65 in bonuses but didn't win \u00B4\u0434` ; http:\/\/t.co\/vdkidheC",
  "id" : 303360558613282816,
  "created_at" : "2013-02-18 04:29:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303353100792627200",
  "text" : "OH \u201CI have a huge fetish for Asians\u201D",
  "id" : 303353100792627200,
  "created_at" : "2013-02-18 03:59:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    }, {
      "name" : "Tweet Historian",
      "screen_name" : "thistorian",
      "indices" : [ 28, 39 ],
      "id_str" : "1031730690",
      "id" : 1031730690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303336950688002049",
  "geo" : { },
  "id_str" : "303342187813433344",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine you\u2019re sounding like @thistorian. Don\u2019t treat twitter like RSS.",
  "id" : 303342187813433344,
  "in_reply_to_status_id" : 303336950688002049,
  "created_at" : "2013-02-18 03:16:28 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Swicegood",
      "screen_name" : "tswicegood",
      "indices" : [ 0, 11 ],
      "id_str" : "9478892",
      "id" : 9478892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303267804327591937",
  "geo" : { },
  "id_str" : "303336730189246464",
  "in_reply_to_user_id" : 9478892,
  "text" : "@tswicegood wooot!! \uFF3C(^o^)\uFF0F",
  "id" : 303336730189246464,
  "in_reply_to_status_id" : 303267804327591937,
  "created_at" : "2013-02-18 02:54:46 +0000",
  "in_reply_to_screen_name" : "tswicegood",
  "in_reply_to_user_id_str" : "9478892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303254068321734656",
  "geo" : { },
  "id_str" : "303254828505759744",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit # FIXME: Who cares?",
  "id" : 303254828505759744,
  "in_reply_to_status_id" : 303254068321734656,
  "created_at" : "2013-02-17 21:29:19 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "husky",
      "indices" : [ 10, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/yfrkQusQ",
      "expanded_url" : "http:\/\/vine.co\/v\/brV55AtKM3a",
      "display_url" : "vine.co\/v\/brV55AtKM3a"
    } ]
  },
  "geo" : { },
  "id_str" : "303229674820104194",
  "text" : "Impromptu #husky meetup. http:\/\/t.co\/yfrkQusQ",
  "id" : 303229674820104194,
  "created_at" : "2013-02-17 19:49:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 0, 8 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303191634743545856",
  "geo" : { },
  "id_str" : "303204727301230593",
  "in_reply_to_user_id" : 20844341,
  "text" : "@patio11 this is a great idea. Going to adopt this as well!",
  "id" : 303204727301230593,
  "in_reply_to_status_id" : 303191634743545856,
  "created_at" : "2013-02-17 18:10:14 +0000",
  "in_reply_to_screen_name" : "patio11",
  "in_reply_to_user_id_str" : "20844341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Upton",
      "screen_name" : "boxofrad",
      "indices" : [ 0, 9 ],
      "id_str" : "160223256",
      "id" : 160223256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303124230160134145",
  "geo" : { },
  "id_str" : "303161540855623681",
  "in_reply_to_user_id" : 160223256,
  "text" : "@boxofrad thanks, i\u2019ll take a look into it. And woot RubyMotion!!",
  "id" : 303161540855623681,
  "in_reply_to_status_id" : 303124230160134145,
  "created_at" : "2013-02-17 15:18:38 +0000",
  "in_reply_to_screen_name" : "boxofrad",
  "in_reply_to_user_id_str" : "160223256",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "loop",
      "indices" : [ 12, 17 ]
    }, {
      "text" : "boardgames",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/XwvICOpk",
      "expanded_url" : "http:\/\/vine.co\/v\/brUVtUMnZdZ",
      "display_url" : "vine.co\/v\/brUVtUMnZdZ"
    } ]
  },
  "geo" : { },
  "id_str" : "302982042260500481",
  "text" : "Carcassone! #loop #boardgames http:\/\/t.co\/XwvICOpk",
  "id" : 302982042260500481,
  "created_at" : "2013-02-17 03:25:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Upton",
      "screen_name" : "boxofrad",
      "indices" : [ 0, 9 ],
      "id_str" : "160223256",
      "id" : 160223256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302493851954860032",
  "geo" : { },
  "id_str" : "302909672199946240",
  "in_reply_to_user_id" : 160223256,
  "text" : "@boxofrad oof! any ideas\/steps on how that happened? haven't seen that before.",
  "id" : 302909672199946240,
  "in_reply_to_status_id" : 302493851954860032,
  "created_at" : "2013-02-16 22:37:48 +0000",
  "in_reply_to_screen_name" : "boxofrad",
  "in_reply_to_user_id_str" : "160223256",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302879572838449152",
  "geo" : { },
  "id_str" : "302880056454299648",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt you will love it.",
  "id" : 302880056454299648,
  "in_reply_to_status_id" : 302879572838449152,
  "created_at" : "2013-02-16 20:40:07 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302878630894256128",
  "text" : "\"Must a be a shortfall of aptitude in the development team\" GREAT REVIEW!",
  "id" : 302878630894256128,
  "created_at" : "2013-02-16 20:34:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 3, 10 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302874018866921472",
  "text" : "RT @jmazzi: RubyMotion is pretty great. No Xcode or Interface Builder, I interact with my app via rake and I get to use Vim.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302833055113039873",
    "text" : "RubyMotion is pretty great. No Xcode or Interface Builder, I interact with my app via rake and I get to use Vim.",
    "id" : 302833055113039873,
    "created_at" : "2013-02-16 17:33:21 +0000",
    "user" : {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "protected" : false,
      "id_str" : "15395778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413712456620322816\/Ki1bebJu_normal.jpeg",
      "id" : 15395778,
      "verified" : false
    }
  },
  "id" : 302874018866921472,
  "created_at" : "2013-02-16 20:16:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "boyd bettis",
      "screen_name" : "boydbettis",
      "indices" : [ 0, 11 ],
      "id_str" : "16527580",
      "id" : 16527580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302871004219310080",
  "geo" : { },
  "id_str" : "302873469962563585",
  "in_reply_to_user_id" : 16527580,
  "text" : "@boydbettis woot!!",
  "id" : 302873469962563585,
  "in_reply_to_status_id" : 302871004219310080,
  "created_at" : "2013-02-16 20:13:57 +0000",
  "in_reply_to_screen_name" : "boydbettis",
  "in_reply_to_user_id_str" : "16527580",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sutter",
      "screen_name" : "chris_sutter",
      "indices" : [ 0, 13 ],
      "id_str" : "205846189",
      "id" : 205846189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302837598039203840",
  "geo" : { },
  "id_str" : "302873178542317568",
  "in_reply_to_user_id" : 205846189,
  "text" : "@chris_sutter really? Spent months of poring over Apple docs and shipped an app. Have you tried RM or read about it further?",
  "id" : 302873178542317568,
  "in_reply_to_status_id" : 302837598039203840,
  "created_at" : "2013-02-16 20:12:47 +0000",
  "in_reply_to_screen_name" : "chris_sutter",
  "in_reply_to_user_id_str" : "205846189",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 66, 76 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302862112617820161",
  "text" : "Seriously impressed by the Jawbone\u2019s form factor. Hard to believe @aquaranto is wearing a computer as a bracelet.",
  "id" : 302862112617820161,
  "created_at" : "2013-02-16 19:28:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sutton",
      "screen_name" : "KellySutton",
      "indices" : [ 0, 12 ],
      "id_str" : "2232241",
      "id" : 2232241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302860476780515328",
  "geo" : { },
  "id_str" : "302861752146747392",
  "in_reply_to_user_id" : 2232241,
  "text" : "@KellySutton thanks! I wish it was easier.",
  "id" : 302861752146747392,
  "in_reply_to_status_id" : 302860476780515328,
  "created_at" : "2013-02-16 19:27:23 +0000",
  "in_reply_to_screen_name" : "KellySutton",
  "in_reply_to_user_id_str" : "2232241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/ma9lkqU2",
      "expanded_url" : "http:\/\/pcottle.github.com\/learnGitBranching\/",
      "display_url" : "pcottle.github.com\/learnGitBranch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302861251128725505",
  "text" : "This is fantastic, visual way to learn about git branches, merging, and rebasing: http:\/\/t.co\/ma9lkqU2",
  "id" : 302861251128725505,
  "created_at" : "2013-02-16 19:25:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 7, 19 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302836314263404544",
  "text" : "Missed @AqueousBand band rickrolling the crowd last night during the encore: \"Triangle-&gt;Never gonna give you up-&gt;Axis(bold as love)\"",
  "id" : 302836314263404544,
  "created_at" : "2013-02-16 17:46:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "martin van Nijnatten",
      "screen_name" : "fietske",
      "indices" : [ 0, 8 ],
      "id_str" : "817623",
      "id" : 817623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302800166707134464",
  "geo" : { },
  "id_str" : "302808766976520192",
  "in_reply_to_user_id" : 817623,
  "text" : "@fietske thanks!",
  "id" : 302808766976520192,
  "in_reply_to_status_id" : 302800166707134464,
  "created_at" : "2013-02-16 15:56:50 +0000",
  "in_reply_to_screen_name" : "fietske",
  "in_reply_to_user_id_str" : "817623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "leif hanack",
      "screen_name" : "leifhanack",
      "indices" : [ 0, 11 ],
      "id_str" : "113887212",
      "id" : 113887212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302718943326527488",
  "geo" : { },
  "id_str" : "302807640994635776",
  "in_reply_to_user_id" : 113887212,
  "text" : "@leifhanack lots of manual testing :( this is something I need to work on.",
  "id" : 302807640994635776,
  "in_reply_to_status_id" : 302718943326527488,
  "created_at" : "2013-02-16 15:52:22 +0000",
  "in_reply_to_screen_name" : "leifhanack",
  "in_reply_to_user_id_str" : "113887212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302655647181312000",
  "geo" : { },
  "id_str" : "302656784596885505",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog blown away. Wish they had 2 sets.",
  "id" : 302656784596885505,
  "in_reply_to_status_id" : 302655647181312000,
  "created_at" : "2013-02-16 05:52:55 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Lindeman",
      "screen_name" : "alindeman",
      "indices" : [ 0, 10 ],
      "id_str" : "13235612",
      "id" : 13235612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302603432538292225",
  "geo" : { },
  "id_str" : "302654718189117440",
  "in_reply_to_user_id" : 13235612,
  "text" : "@alindeman Carcassone hands down. I\u2019m quaranto on Game Center. Bring it!",
  "id" : 302654718189117440,
  "in_reply_to_status_id" : 302603432538292225,
  "created_at" : "2013-02-16 05:44:42 +0000",
  "in_reply_to_screen_name" : "alindeman",
  "in_reply_to_user_id_str" : "13235612",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302643326434287616",
  "text" : "OH \u201CEveryone came out. Everyone is either straight or gay.\u201D",
  "id" : 302643326434287616,
  "created_at" : "2013-02-16 04:59:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phish",
      "indices" : [ 68, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302639247045840896",
  "text" : "RT @UnclePhilsBlog: YEM metamorphosis by Pigeons Playing Ping Pong. #phish Sick.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "phish",
        "indices" : [ 48, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302638827888066560",
    "text" : "YEM metamorphosis by Pigeons Playing Ping Pong. #phish Sick.",
    "id" : 302638827888066560,
    "created_at" : "2013-02-16 04:41:33 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 302639247045840896,
  "created_at" : "2013-02-16 04:43:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302629377433300994",
  "geo" : { },
  "id_str" : "302630467784544257",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes completin\u2019 todos ain\u2019t easy",
  "id" : 302630467784544257,
  "in_reply_to_status_id" : 302629377433300994,
  "created_at" : "2013-02-16 04:08:20 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Hart",
      "screen_name" : "onyxraven",
      "indices" : [ 0, 10 ],
      "id_str" : "14319947",
      "id" : 14319947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302618864393543680",
  "geo" : { },
  "id_str" : "302620698638159873",
  "in_reply_to_user_id" : 14319947,
  "text" : "@onyxraven lead singer too! Maybe it\u2019s a shtick.",
  "id" : 302620698638159873,
  "in_reply_to_status_id" : 302618864393543680,
  "created_at" : "2013-02-16 03:29:31 +0000",
  "in_reply_to_screen_name" : "onyxraven",
  "in_reply_to_user_id_str" : "14319947",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302618130096746498",
  "text" : "Guitarist for this opener band is wearing PJ pants. Right now.",
  "id" : 302618130096746498,
  "created_at" : "2013-02-16 03:19:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 32, 44 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302614291364839424",
  "text" : "Balcony spot acquired early for @AqueousBand. Fuck yes!",
  "id" : 302614291364839424,
  "created_at" : "2013-02-16 03:04:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Lash",
      "screen_name" : "danlash",
      "indices" : [ 0, 8 ],
      "id_str" : "14729552",
      "id" : 14729552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302612900860817408",
  "geo" : { },
  "id_str" : "302613592476364801",
  "in_reply_to_user_id" : 14729552,
  "text" : "@danlash oh that is the WORST. Fuck those bastards.",
  "id" : 302613592476364801,
  "in_reply_to_status_id" : 302612900860817408,
  "created_at" : "2013-02-16 03:01:17 +0000",
  "in_reply_to_screen_name" : "danlash",
  "in_reply_to_user_id_str" : "14729552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Hatcher",
      "screen_name" : "xeenon",
      "indices" : [ 14, 21 ],
      "id_str" : "15400531",
      "id" : 15400531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302604232907976705",
  "geo" : { },
  "id_str" : "302609421903749120",
  "in_reply_to_user_id" : 1159494277,
  "text" : "@doctype_walt @xeenon seriously so much help.",
  "id" : 302609421903749120,
  "in_reply_to_status_id" : 302604232907976705,
  "created_at" : "2013-02-16 02:44:43 +0000",
  "in_reply_to_screen_name" : "doctype_jon",
  "in_reply_to_user_id_str" : "1159494277",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 0, 10 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302607721440612352",
  "geo" : { },
  "id_str" : "302609309857116162",
  "in_reply_to_user_id" : 5744442,
  "text" : "@aquaranto eheheheehhe impact.",
  "id" : 302609309857116162,
  "in_reply_to_status_id" : 302607721440612352,
  "created_at" : "2013-02-16 02:44:16 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iosreviewtime",
      "indices" : [ 76, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302581309107220481",
  "text" : "Took another 7 days to review a patch release. So beyond spoiled with gems. #iosreviewtime",
  "id" : 302581309107220481,
  "created_at" : "2013-02-16 00:53:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Carrey",
      "screen_name" : "JimCarrey",
      "indices" : [ 25, 35 ],
      "id_str" : "52551600",
      "id" : 52551600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302546060008648705",
  "text" : "And today I learned that @JimCarrey uses twitter like a 10 year old using an AOL chatroom for the first time.",
  "id" : 302546060008648705,
  "created_at" : "2013-02-15 22:32:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henry Moran",
      "screen_name" : "iamhenrym",
      "indices" : [ 0, 10 ],
      "id_str" : "18741333",
      "id" : 18741333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302545384381759488",
  "geo" : { },
  "id_str" : "302545664011821058",
  "in_reply_to_user_id" : 18741333,
  "text" : "@iamhenrym derp. It's just the iOS simulator + ScreenFlow to record + Phosphor to export.",
  "id" : 302545664011821058,
  "in_reply_to_status_id" : 302545384381759488,
  "created_at" : "2013-02-15 22:31:21 +0000",
  "in_reply_to_screen_name" : "iamhenrym",
  "in_reply_to_user_id_str" : "18741333",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Staple",
      "screen_name" : "AndyStaple",
      "indices" : [ 0, 11 ],
      "id_str" : "34352961",
      "id" : 34352961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/h0SuGFq7",
      "expanded_url" : "http:\/\/37svn.com\/3442",
      "display_url" : "37svn.com\/3442"
    } ]
  },
  "in_reply_to_status_id_str" : "302543862461771777",
  "geo" : { },
  "id_str" : "302544454974337024",
  "in_reply_to_user_id" : 34352961,
  "text" : "@AndyStaple Thanks! Not sure if you saw http:\/\/t.co\/h0SuGFq7, but related!",
  "id" : 302544454974337024,
  "in_reply_to_status_id" : 302543862461771777,
  "created_at" : "2013-02-15 22:26:33 +0000",
  "in_reply_to_screen_name" : "AndyStaple",
  "in_reply_to_user_id_str" : "34352961",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henry Moran",
      "screen_name" : "iamhenrym",
      "indices" : [ 0, 10 ],
      "id_str" : "18741333",
      "id" : 18741333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 50 ],
      "url" : "https:\/\/t.co\/4bir2tiw",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/phosphor\/id589654268",
      "display_url" : "itunes.apple.com\/us\/app\/phospho\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "302528246908583936",
  "geo" : { },
  "id_str" : "302544137180291073",
  "in_reply_to_user_id" : 18741333,
  "text" : "@iamhenrym we used Phosphor: https:\/\/t.co\/4bir2tiw",
  "id" : 302544137180291073,
  "in_reply_to_status_id" : 302528246908583936,
  "created_at" : "2013-02-15 22:25:17 +0000",
  "in_reply_to_screen_name" : "iamhenrym",
  "in_reply_to_user_id_str" : "18741333",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Reeder",
      "screen_name" : "treeder",
      "indices" : [ 0, 8 ],
      "id_str" : "14134156",
      "id" : 14134156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302534825351467009",
  "geo" : { },
  "id_str" : "302540869859438592",
  "in_reply_to_user_id" : 14134156,
  "text" : "@treeder sorry man, been super busy :( might be able to this weekend, i need to get setup on the new AWS infrastructure first.",
  "id" : 302540869859438592,
  "in_reply_to_status_id" : 302534825351467009,
  "created_at" : "2013-02-15 22:12:18 +0000",
  "in_reply_to_screen_name" : "treeder",
  "in_reply_to_user_id_str" : "14134156",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302522272244187136",
  "geo" : { },
  "id_str" : "302522644065026048",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo haha well aware. think they'll still play 2 sets?",
  "id" : 302522644065026048,
  "in_reply_to_status_id" : 302522272244187136,
  "created_at" : "2013-02-15 20:59:53 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302521376961605632",
  "geo" : { },
  "id_str" : "302521524282347521",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo Guh, good to know. I sound old, but why so friggin late?!",
  "id" : 302521524282347521,
  "in_reply_to_status_id" : 302521376961605632,
  "created_at" : "2013-02-15 20:55:26 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302520737082793985",
  "geo" : { },
  "id_str" : "302521145821917184",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo Midnight? Site said 10, I was going to get there early at 8. WTF?",
  "id" : 302521145821917184,
  "in_reply_to_status_id" : 302520737082793985,
  "created_at" : "2013-02-15 20:53:56 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myke Menio",
      "screen_name" : "MemoCuse44",
      "indices" : [ 0, 11 ],
      "id_str" : "218559728",
      "id" : 218559728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302520743990788096",
  "geo" : { },
  "id_str" : "302521065870086144",
  "in_reply_to_user_id" : 218559728,
  "text" : "@MemoCuse44 Yes!!!",
  "id" : 302521065870086144,
  "in_reply_to_status_id" : 302520743990788096,
  "created_at" : "2013-02-15 20:53:37 +0000",
  "in_reply_to_screen_name" : "MemoCuse44",
  "in_reply_to_user_id_str" : "218559728",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marty Haught",
      "screen_name" : "mghaught",
      "indices" : [ 0, 9 ],
      "id_str" : "17875219",
      "id" : 17875219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302513763943325696",
  "geo" : { },
  "id_str" : "302515913964539904",
  "in_reply_to_user_id" : 17875219,
  "text" : "@mghaught Not crossed yet, still need to book it. Getting close though.",
  "id" : 302515913964539904,
  "in_reply_to_status_id" : 302513763943325696,
  "created_at" : "2013-02-15 20:33:09 +0000",
  "in_reply_to_screen_name" : "mghaught",
  "in_reply_to_user_id_str" : "17875219",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miguel",
      "screen_name" : "guelo",
      "indices" : [ 0, 6 ],
      "id_str" : "2930371",
      "id" : 2930371
    }, {
      "name" : "Tim Bray",
      "screen_name" : "timbray",
      "indices" : [ 7, 15 ],
      "id_str" : "1235521",
      "id" : 1235521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302505362114879490",
  "geo" : { },
  "id_str" : "302508431913410561",
  "in_reply_to_user_id" : 2930371,
  "text" : "@guelo @timbray the approval delay is a small concern\/negative compared to the other benefits",
  "id" : 302508431913410561,
  "in_reply_to_status_id" : 302505362114879490,
  "created_at" : "2013-02-15 20:03:25 +0000",
  "in_reply_to_screen_name" : "guelo",
  "in_reply_to_user_id_str" : "2930371",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Bray",
      "screen_name" : "timbray",
      "indices" : [ 0, 8 ],
      "id_str" : "1235521",
      "id" : 1235521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302493426367217664",
  "geo" : { },
  "id_str" : "302494924727787520",
  "in_reply_to_user_id" : 1235521,
  "text" : "@timbray Thanks!",
  "id" : 302494924727787520,
  "in_reply_to_status_id" : 302493426367217664,
  "created_at" : "2013-02-15 19:09:44 +0000",
  "in_reply_to_screen_name" : "timbray",
  "in_reply_to_user_id_str" : "1235521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/wBxG5fbo",
      "expanded_url" : "http:\/\/i.imgur.com\/3lCHFVV.jpg",
      "display_url" : "i.imgur.com\/3lCHFVV.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "302489229638905858",
  "text" : "RT @aquaranto: Summary of my day: http:\/\/t.co\/wBxG5fbo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 39 ],
        "url" : "http:\/\/t.co\/wBxG5fbo",
        "expanded_url" : "http:\/\/i.imgur.com\/3lCHFVV.jpg",
        "display_url" : "i.imgur.com\/3lCHFVV.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "302489095400194048",
    "text" : "Summary of my day: http:\/\/t.co\/wBxG5fbo",
    "id" : 302489095400194048,
    "created_at" : "2013-02-15 18:46:34 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 302489229638905858,
  "created_at" : "2013-02-15 18:47:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rundle",
      "screen_name" : "flyosity",
      "indices" : [ 0, 9 ],
      "id_str" : "10545",
      "id" : 10545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302487564638642178",
  "geo" : { },
  "id_str" : "302488587667116034",
  "in_reply_to_user_id" : 10545,
  "text" : "@flyosity bingo",
  "id" : 302488587667116034,
  "in_reply_to_status_id" : 302487564638642178,
  "created_at" : "2013-02-15 18:44:33 +0000",
  "in_reply_to_screen_name" : "flyosity",
  "in_reply_to_user_id_str" : "10545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rundle",
      "screen_name" : "flyosity",
      "indices" : [ 0, 9 ],
      "id_str" : "10545",
      "id" : 10545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302485608301989888",
  "geo" : { },
  "id_str" : "302487194726187008",
  "in_reply_to_user_id" : 10545,
  "text" : "@flyosity no, there\u2019s only one on screen at a time. Lots of taking screenshot magic!",
  "id" : 302487194726187008,
  "in_reply_to_status_id" : 302485608301989888,
  "created_at" : "2013-02-15 18:39:01 +0000",
  "in_reply_to_screen_name" : "flyosity",
  "in_reply_to_user_id_str" : "10545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302482792674119680",
  "text" : "I think I may have just found the perfect venue for a Buffalo ruby conference. Time to make it happen!",
  "id" : 302482792674119680,
  "created_at" : "2013-02-15 18:21:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Pickett",
      "screen_name" : "dpickett",
      "indices" : [ 0, 9 ],
      "id_str" : "1364461",
      "id" : 1364461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302479154018930688",
  "geo" : { },
  "id_str" : "302482353949913088",
  "in_reply_to_user_id" : 1364461,
  "text" : "@dpickett thanks!",
  "id" : 302482353949913088,
  "in_reply_to_status_id" : 302479154018930688,
  "created_at" : "2013-02-15 18:19:47 +0000",
  "in_reply_to_screen_name" : "dpickett",
  "in_reply_to_user_id_str" : "1364461",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 0, 15 ],
      "id_str" : "13639982",
      "id" : 13639982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302458918683176960",
  "geo" : { },
  "id_str" : "302474662011625472",
  "in_reply_to_user_id" : 13639982,
  "text" : "@MarkVillacampa Yeah, it's a little janky. Hoping to improve it in future releases.",
  "id" : 302474662011625472,
  "in_reply_to_status_id" : 302458918683176960,
  "created_at" : "2013-02-15 17:49:13 +0000",
  "in_reply_to_screen_name" : "MarkVillacampa",
  "in_reply_to_user_id_str" : "13639982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302474394838654977",
  "geo" : { },
  "id_str" : "302474589454336000",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza Yep! That's exactly what we had to do. Took forever to figure out why :(",
  "id" : 302474589454336000,
  "in_reply_to_status_id" : 302474394838654977,
  "created_at" : "2013-02-15 17:48:56 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/rztdMgIF",
      "expanded_url" : "http:\/\/37svn.com\/3438",
      "display_url" : "37svn.com\/3438"
    } ]
  },
  "geo" : { },
  "id_str" : "302473908706238465",
  "text" : "Drawing the native\/web line in Basecamp for iPhone: http:\/\/t.co\/rztdMgIF",
  "id" : 302473908706238465,
  "created_at" : "2013-02-15 17:46:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Redpath",
      "screen_name" : "lukeredpath",
      "indices" : [ 0, 12 ],
      "id_str" : "72573",
      "id" : 72573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302449586809749505",
  "geo" : { },
  "id_str" : "302450583439306752",
  "in_reply_to_user_id" : 72573,
  "text" : "@lukeredpath Yes? wtf?",
  "id" : 302450583439306752,
  "in_reply_to_status_id" : 302449586809749505,
  "created_at" : "2013-02-15 16:13:33 +0000",
  "in_reply_to_screen_name" : "lukeredpath",
  "in_reply_to_user_id_str" : "72573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Lainez",
      "screen_name" : "mlainez",
      "indices" : [ 3, 11 ],
      "id_str" : "18801056",
      "id" : 18801056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302446829159710723",
  "text" : "RT @mlainez: Yesterday: Xcode =&gt; nothing good came out of it.\nToday: Rubymotion =&gt; almost finished an app.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302444036772478977",
    "text" : "Yesterday: Xcode =&gt; nothing good came out of it.\nToday: Rubymotion =&gt; almost finished an app.",
    "id" : 302444036772478977,
    "created_at" : "2013-02-15 15:47:32 +0000",
    "user" : {
      "name" : "Marc Lainez",
      "screen_name" : "mlainez",
      "protected" : false,
      "id_str" : "18801056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1385570415\/Screen_shot_2010-11-21_at_22.13.26_normal.png",
      "id" : 18801056,
      "verified" : false
    }
  },
  "id" : 302446829159710723,
  "created_at" : "2013-02-15 15:58:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/JQfDX8ku",
      "expanded_url" : "http:\/\/37svn.com\/3439",
      "display_url" : "37svn.com\/3439"
    } ]
  },
  "geo" : { },
  "id_str" : "302430347923181568",
  "text" : "Much iteration and trying out designs on an actual device drove many decisions with Basecamp for iPhone: http:\/\/t.co\/JQfDX8ku",
  "id" : 302430347923181568,
  "created_at" : "2013-02-15 14:53:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 7, 19 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302425952502308865",
  "text" : "Seeing @AqueousBand tonight!! Still beyond excited to see them and support a hometown band.",
  "id" : 302425952502308865,
  "created_at" : "2013-02-15 14:35:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Binder",
      "screen_name" : "MattBinder",
      "indices" : [ 0, 11 ],
      "id_str" : "14931637",
      "id" : 14931637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302301989721747456",
  "geo" : { },
  "id_str" : "302302738463723520",
  "in_reply_to_user_id" : 14931637,
  "text" : "@MattBinder public shame trigger on \u201Ccommies\u201D right now",
  "id" : 302302738463723520,
  "in_reply_to_status_id" : 302301989721747456,
  "created_at" : "2013-02-15 06:26:04 +0000",
  "in_reply_to_screen_name" : "MattBinder",
  "in_reply_to_user_id_str" : "14931637",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    }, {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 8, 15 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302282230812794880",
  "geo" : { },
  "id_str" : "302285161830162432",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes @maddox the certificate gauntlet alone is proof of this. Talk about barriers to entry :(",
  "id" : 302285161830162432,
  "in_reply_to_status_id" : 302282230812794880,
  "created_at" : "2013-02-15 05:16:13 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302281750485299201",
  "text" : "GRAMMAR TRAIN WOOP WOOOOOP CRASH BOOOOOOOM",
  "id" : 302281750485299201,
  "created_at" : "2013-02-15 05:02:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Tufte",
      "screen_name" : "EdwardTufte",
      "indices" : [ 3, 15 ],
      "id_str" : "152862026",
      "id" : 152862026
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 102, 105 ]
    }, {
      "text" : "UI",
      "indices" : [ 106, 109 ]
    }, {
      "text" : "teaching",
      "indices" : [ 110, 119 ]
    }, {
      "text" : "webdesign",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/3Ukgs9il",
      "expanded_url" : "http:\/\/imgs.xkcd.com\/comics\/university_website.png",
      "display_url" : "imgs.xkcd.com\/comics\/univers\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302281323660337155",
  "text" : "RT @EdwardTufte: Devastating critique of nearly all university websites by xkcd http:\/\/t.co\/3Ukgs9il \n#UX #UI #teaching #webdesign",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 85, 88 ]
      }, {
        "text" : "UI",
        "indices" : [ 89, 92 ]
      }, {
        "text" : "teaching",
        "indices" : [ 93, 102 ]
      }, {
        "text" : "webdesign",
        "indices" : [ 103, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/3Ukgs9il",
        "expanded_url" : "http:\/\/imgs.xkcd.com\/comics\/university_website.png",
        "display_url" : "imgs.xkcd.com\/comics\/univers\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "302280861024411648",
    "text" : "Devastating critique of nearly all university websites by xkcd http:\/\/t.co\/3Ukgs9il \n#UX #UI #teaching #webdesign",
    "id" : 302280861024411648,
    "created_at" : "2013-02-15 04:59:08 +0000",
    "user" : {
      "name" : "Edward Tufte",
      "screen_name" : "EdwardTufte",
      "protected" : false,
      "id_str" : "152862026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458847900957556736\/uArnnoBy_normal.png",
      "id" : 152862026,
      "verified" : false
    }
  },
  "id" : 302281323660337155,
  "created_at" : "2013-02-15 05:00:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302261495520174080",
  "text" : "Ok, the King\u2019s Speech was really good.",
  "id" : 302261495520174080,
  "created_at" : "2013-02-15 03:42:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin John Gomez",
      "screen_name" : "kevinjohngomez",
      "indices" : [ 0, 15 ],
      "id_str" : "26253666",
      "id" : 26253666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302234099786084352",
  "geo" : { },
  "id_str" : "302234933525635072",
  "in_reply_to_user_id" : 26253666,
  "text" : "@kevinjohngomez dude! Go get a growler of Frank.",
  "id" : 302234933525635072,
  "in_reply_to_status_id" : 302234099786084352,
  "created_at" : "2013-02-15 01:56:38 +0000",
  "in_reply_to_screen_name" : "kevinjohngomez",
  "in_reply_to_user_id_str" : "26253666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Kantrowitz",
      "screen_name" : "kantrn",
      "indices" : [ 0, 7 ],
      "id_str" : "1841791",
      "id" : 1841791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302234414350467072",
  "geo" : { },
  "id_str" : "302234712087334914",
  "in_reply_to_user_id" : 1841791,
  "text" : "@kantrn great to hear! Not a burn against Python- just against trolls.",
  "id" : 302234712087334914,
  "in_reply_to_status_id" : 302234414350467072,
  "created_at" : "2013-02-15 01:55:45 +0000",
  "in_reply_to_screen_name" : "kantrn",
  "in_reply_to_user_id_str" : "1841791",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302227320280862722",
  "text" : "Just got a PyPi security email. Loved seeing the hubris of those suggesting Django\/Python instead of Ruby\/Rails to avoid security issues.",
  "id" : 302227320280862722,
  "created_at" : "2013-02-15 01:26:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hoang",
      "screen_name" : "davidhoang",
      "indices" : [ 0, 11 ],
      "id_str" : "14338572",
      "id" : 14338572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/EjCUekYz",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=oavMtUWDBTM",
      "display_url" : "youtube.com\/watch?v=oavMtU\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "302220433695055872",
  "geo" : { },
  "id_str" : "302220742886576128",
  "in_reply_to_user_id" : 14338572,
  "text" : "@davidhoang http:\/\/t.co\/EjCUekYz",
  "id" : 302220742886576128,
  "in_reply_to_status_id" : 302220433695055872,
  "created_at" : "2013-02-15 01:00:14 +0000",
  "in_reply_to_screen_name" : "davidhoang",
  "in_reply_to_user_id_str" : "14338572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arnold",
      "screen_name" : "tonyarnold",
      "indices" : [ 0, 11 ],
      "id_str" : "640903",
      "id" : 640903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302219322699419648",
  "geo" : { },
  "id_str" : "302220368490422273",
  "in_reply_to_user_id" : 640903,
  "text" : "@tonyarnold thanks! Would love to see  more experienced iOS devs at least try it out. Also you can use IB, xibs with it.",
  "id" : 302220368490422273,
  "in_reply_to_status_id" : 302219322699419648,
  "created_at" : "2013-02-15 00:58:45 +0000",
  "in_reply_to_screen_name" : "tonyarnold",
  "in_reply_to_user_id_str" : "640903",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arnold",
      "screen_name" : "tonyarnold",
      "indices" : [ 0, 11 ],
      "id_str" : "640903",
      "id" : 640903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302219031627317248",
  "geo" : { },
  "id_str" : "302219592686788608",
  "in_reply_to_user_id" : 640903,
  "text" : "@tonyarnold I couldn\u2019t stand being in Xcode daily. The amount of drag and drop magic in IB just didn\u2019t feel right.",
  "id" : 302219592686788608,
  "in_reply_to_status_id" : 302219031627317248,
  "created_at" : "2013-02-15 00:55:40 +0000",
  "in_reply_to_screen_name" : "tonyarnold",
  "in_reply_to_user_id_str" : "640903",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arnold",
      "screen_name" : "tonyarnold",
      "indices" : [ 0, 11 ],
      "id_str" : "640903",
      "id" : 640903
    }, {
      "name" : "Michael James",
      "screen_name" : "mj1531",
      "indices" : [ 12, 19 ],
      "id_str" : "5546322",
      "id" : 5546322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302168476292890624",
  "geo" : { },
  "id_str" : "302218880376512513",
  "in_reply_to_user_id" : 640903,
  "text" : "@tonyarnold @mj1531 if you have more specific questions I\u2019d love to dispel the hand waving :)",
  "id" : 302218880376512513,
  "in_reply_to_status_id" : 302168476292890624,
  "created_at" : "2013-02-15 00:52:50 +0000",
  "in_reply_to_screen_name" : "tonyarnold",
  "in_reply_to_user_id_str" : "640903",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302218188324741120",
  "geo" : { },
  "id_str" : "302218576914415617",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza agreed. We had external urls opening in Chrome via googlechrome:\/\/ but violating defaults felt wrong",
  "id" : 302218576914415617,
  "in_reply_to_status_id" : 302218188324741120,
  "created_at" : "2013-02-15 00:51:38 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/302209509001138176\/photo\/1",
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/nN19IKCU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDGp8oBCEAAYklW.png",
      "id_str" : "302209509009526784",
      "id" : 302209509009526784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDGp8oBCEAAYklW.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/nN19IKCU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/RlgjkaZ8",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=WGOohBytKTU",
      "display_url" : "youtube.com\/watch?v=WGOohB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302209509001138176",
  "text" : "It\u2019s business time for Basecamp! Just for Valentine\u2019s Day: http:\/\/t.co\/RlgjkaZ8 http:\/\/t.co\/nN19IKCU",
  "id" : 302209509001138176,
  "created_at" : "2013-02-15 00:15:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/0tHU4uR5",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=t_3VZDb7pj4",
      "display_url" : "youtube.com\/watch?v=t_3VZD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302184661843595264",
  "text" : "AAAAAAAAAAAAAAAAAAAAAAAAAAAAHHHHHHHHHHHHHHHHH http:\/\/t.co\/0tHU4uR5",
  "id" : 302184661843595264,
  "created_at" : "2013-02-14 22:36:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 0, 11 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302061959539458050",
  "geo" : { },
  "id_str" : "302064536859590656",
  "in_reply_to_user_id" : 48431692,
  "text" : "@laserlemon yep, I hear you. I didn\u2019t let that stop me. I\u2019d love to learn more about it though.",
  "id" : 302064536859590656,
  "in_reply_to_status_id" : 302061959539458050,
  "created_at" : "2013-02-14 14:39:32 +0000",
  "in_reply_to_screen_name" : "laserlemon",
  "in_reply_to_user_id_str" : "48431692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barnaby",
      "screen_name" : "barnabymalet",
      "indices" : [ 0, 13 ],
      "id_str" : "139184720",
      "id" : 139184720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302063937208348674",
  "geo" : { },
  "id_str" : "302064260610154497",
  "in_reply_to_user_id" : 139184720,
  "text" : "@barnabymalet bridge? We do use SDURLCache. All of the OSS libs we use are attributed in Settings.app.",
  "id" : 302064260610154497,
  "in_reply_to_status_id" : 302063937208348674,
  "created_at" : "2013-02-14 14:38:26 +0000",
  "in_reply_to_screen_name" : "barnabymalet",
  "in_reply_to_user_id_str" : "139184720",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 0, 11 ],
      "id_str" : "14086000",
      "id" : 14086000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301934313975451648",
  "geo" : { },
  "id_str" : "302060691764936705",
  "in_reply_to_user_id" : 14086000,
  "text" : "@timocratic wat",
  "id" : 302060691764936705,
  "in_reply_to_status_id" : 301934313975451648,
  "created_at" : "2013-02-14 14:24:15 +0000",
  "in_reply_to_screen_name" : "timocratic",
  "in_reply_to_user_id_str" : "14086000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barnaby",
      "screen_name" : "barnabymalet",
      "indices" : [ 0, 13 ],
      "id_str" : "139184720",
      "id" : 139184720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302006348625879040",
  "geo" : { },
  "id_str" : "302060646059606017",
  "in_reply_to_user_id" : 139184720,
  "text" : "@barnabymalet they\u2019re the same views we use on the mobile web! Maybe I\u2019ll post about this today so it makes more sense.",
  "id" : 302060646059606017,
  "in_reply_to_status_id" : 302006348625879040,
  "created_at" : "2013-02-14 14:24:04 +0000",
  "in_reply_to_screen_name" : "barnabymalet",
  "in_reply_to_user_id_str" : "139184720",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 0, 11 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302060074153689088",
  "geo" : { },
  "id_str" : "302060437195870210",
  "in_reply_to_user_id" : 48431692,
  "text" : "@laserlemon the app really is just a dumb browser. All of the logic for views is on the Rails side.",
  "id" : 302060437195870210,
  "in_reply_to_status_id" : 302060074153689088,
  "created_at" : "2013-02-14 14:23:14 +0000",
  "in_reply_to_screen_name" : "laserlemon",
  "in_reply_to_user_id_str" : "48431692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 0, 11 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302060074153689088",
  "geo" : { },
  "id_str" : "302060321537945601",
  "in_reply_to_user_id" : 48431692,
  "text" : "@laserlemon no :( RM\u2019s test stuff only really handles one controller at a time. I didn\u2019t look into any integration testing.",
  "id" : 302060321537945601,
  "in_reply_to_status_id" : 302060074153689088,
  "created_at" : "2013-02-14 14:22:47 +0000",
  "in_reply_to_screen_name" : "laserlemon",
  "in_reply_to_user_id_str" : "48431692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Meeker",
      "screen_name" : "CuriousCurmudge",
      "indices" : [ 0, 16 ],
      "id_str" : "87356793",
      "id" : 87356793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301929225143857152",
  "geo" : { },
  "id_str" : "301930887971479552",
  "in_reply_to_user_id" : 87356793,
  "text" : "@CuriousCurmudge no.",
  "id" : 301930887971479552,
  "in_reply_to_status_id" : 301929225143857152,
  "created_at" : "2013-02-14 05:48:27 +0000",
  "in_reply_to_screen_name" : "CuriousCurmudge",
  "in_reply_to_user_id_str" : "87356793",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301923692760420352",
  "geo" : { },
  "id_str" : "301926846088499200",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule it\u2019ll work great if Weird Al gets involved.",
  "id" : 301926846088499200,
  "in_reply_to_status_id" : 301923692760420352,
  "created_at" : "2013-02-14 05:32:24 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curtis Duhn",
      "screen_name" : "cduhn",
      "indices" : [ 0, 6 ],
      "id_str" : "3947081",
      "id" : 3947081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301899321643786241",
  "geo" : { },
  "id_str" : "301923932620091392",
  "in_reply_to_user_id" : 3947081,
  "text" : "@cduhn multiple initializers hurt my head. :(",
  "id" : 301923932620091392,
  "in_reply_to_status_id" : 301899321643786241,
  "created_at" : "2013-02-14 05:20:49 +0000",
  "in_reply_to_screen_name" : "cduhn",
  "in_reply_to_user_id_str" : "3947081",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 3, 12 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/6cytZfq7",
      "expanded_url" : "https:\/\/groups.google.com\/d\/msg\/ruby-bundler\/pQ0NmMIPwWs\/wAXAOCaexi4J",
      "display_url" : "groups.google.com\/d\/msg\/ruby-bun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301921339630034944",
  "text" : "RT @indirect: zomg you guys, Bundler 1.2.4 is out with bugfixes and HTTP Error removal code! `gem install bundler`, then read https:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 133 ],
        "url" : "https:\/\/t.co\/6cytZfq7",
        "expanded_url" : "https:\/\/groups.google.com\/d\/msg\/ruby-bundler\/pQ0NmMIPwWs\/wAXAOCaexi4J",
        "display_url" : "groups.google.com\/d\/msg\/ruby-bun\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301921025787043840",
    "text" : "zomg you guys, Bundler 1.2.4 is out with bugfixes and HTTP Error removal code! `gem install bundler`, then read https:\/\/t.co\/6cytZfq7",
    "id" : 301921025787043840,
    "created_at" : "2013-02-14 05:09:16 +0000",
    "user" : {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "protected" : false,
      "id_str" : "5674672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518132954120204288\/yVvIdVOH_normal.jpeg",
      "id" : 5674672,
      "verified" : false
    }
  },
  "id" : 301921339630034944,
  "created_at" : "2013-02-14 05:10:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/301889970447208448\/photo\/1",
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/uEf8FzlP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDCHVCJCUAAthTf.png",
      "id_str" : "301889970455597056",
      "id" : 301889970455597056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDCHVCJCUAAthTf.png",
      "sizes" : [ {
        "h" : 236,
        "resize" : "fit",
        "w" : 297
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 297
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 297
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 297
      } ],
      "display_url" : "pic.twitter.com\/uEf8FzlP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301889970447208448",
  "text" : "What did I do to deserve this ad on YouTube? http:\/\/t.co\/uEf8FzlP",
  "id" : 301889970447208448,
  "created_at" : "2013-02-14 03:05:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301885878815571968",
  "text" : "Just deleted photoshop-1.0.1 \"you may not transfer [...] or otherwise distribute the Software or Derivative Works to any third party\" :(",
  "id" : 301885878815571968,
  "created_at" : "2013-02-14 02:49:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barnaby",
      "screen_name" : "barnabymalet",
      "indices" : [ 0, 13 ],
      "id_str" : "139184720",
      "id" : 139184720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301866829566050305",
  "geo" : { },
  "id_str" : "301881429560807424",
  "in_reply_to_user_id" : 139184720,
  "text" : "@barnabymalet thanks! All of the content inside of projects is HTML5.  Been thinking about doing a post on the hybrid split.",
  "id" : 301881429560807424,
  "in_reply_to_status_id" : 301866829566050305,
  "created_at" : "2013-02-14 02:31:56 +0000",
  "in_reply_to_screen_name" : "barnabymalet",
  "in_reply_to_user_id_str" : "139184720",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Miller",
      "screen_name" : "bensie",
      "indices" : [ 0, 7 ],
      "id_str" : "15394959",
      "id" : 15394959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301842219189547008",
  "geo" : { },
  "id_str" : "301842882199969792",
  "in_reply_to_user_id" : 15394959,
  "text" : "@bensie I just followed the NSLayoutConstraint docs. That\u2019s pretty much it. Hoping to cut a gem with a DSL to help soon.",
  "id" : 301842882199969792,
  "in_reply_to_status_id" : 301842219189547008,
  "created_at" : "2013-02-13 23:58:45 +0000",
  "in_reply_to_screen_name" : "bensie",
  "in_reply_to_user_id_str" : "15394959",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amro Mousa",
      "screen_name" : "amdev",
      "indices" : [ 0, 6 ],
      "id_str" : "14335093",
      "id" : 14335093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301829560708788224",
  "geo" : { },
  "id_str" : "301841655877734400",
  "in_reply_to_user_id" : 14335093,
  "text" : "@amdev the visual designer in VS was always a wreck to use.",
  "id" : 301841655877734400,
  "in_reply_to_status_id" : 301829560708788224,
  "created_at" : "2013-02-13 23:53:53 +0000",
  "in_reply_to_screen_name" : "amdev",
  "in_reply_to_user_id_str" : "14335093",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301835475247841280",
  "geo" : { },
  "id_str" : "301838217060159489",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench congrats!",
  "id" : 301838217060159489,
  "in_reply_to_status_id" : 301835475247841280,
  "created_at" : "2013-02-13 23:40:13 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Ludlam",
      "screen_name" : "nickludlam",
      "indices" : [ 0, 11 ],
      "id_str" : "10178942",
      "id" : 10178942
    }, {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 12, 16 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/gPiCqF6z",
      "expanded_url" : "http:\/\/alt.org\/nethack\/player-stats.php?player=DoctorNick",
      "display_url" : "alt.org\/nethack\/player\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "301833170603610113",
  "geo" : { },
  "id_str" : "301833535143153664",
  "in_reply_to_user_id" : 10178942,
  "text" : "@nickludlam @lrz This must be why I like it! http:\/\/t.co\/gPiCqF6z",
  "id" : 301833535143153664,
  "in_reply_to_status_id" : 301833170603610113,
  "created_at" : "2013-02-13 23:21:37 +0000",
  "in_reply_to_screen_name" : "nickludlam",
  "in_reply_to_user_id_str" : "10178942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Burkett",
      "screen_name" : "stevburkett",
      "indices" : [ 0, 12 ],
      "id_str" : "258857740",
      "id" : 258857740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/XNyCKca0",
      "expanded_url" : "http:\/\/ruboto.org\/",
      "display_url" : "ruboto.org"
    } ]
  },
  "in_reply_to_status_id_str" : "301830682689286144",
  "geo" : { },
  "id_str" : "301831557658853376",
  "in_reply_to_user_id" : 258857740,
  "text" : "@stevburkett I was just using Java forever ago when I tried out Android dev, but I've heard decent things about http:\/\/t.co\/XNyCKca0",
  "id" : 301831557658853376,
  "in_reply_to_status_id" : 301830682689286144,
  "created_at" : "2013-02-13 23:13:45 +0000",
  "in_reply_to_screen_name" : "stevburkett",
  "in_reply_to_user_id_str" : "258857740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Remsik",
      "screen_name" : "jremsikjr",
      "indices" : [ 0, 10 ],
      "id_str" : "1942",
      "id" : 1942
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 11, 22 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301821544605306880",
  "geo" : { },
  "id_str" : "301822640178491392",
  "in_reply_to_user_id" : 1942,
  "text" : "@jremsikjr @tenderlove why didn't you write this in Node? Rails is legacy, man.",
  "id" : 301822640178491392,
  "in_reply_to_status_id" : 301821544605306880,
  "created_at" : "2013-02-13 22:38:19 +0000",
  "in_reply_to_screen_name" : "jremsikjr",
  "in_reply_to_user_id_str" : "1942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathew",
      "screen_name" : "permakittens",
      "indices" : [ 0, 13 ],
      "id_str" : "1119708565",
      "id" : 1119708565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301818156312326145",
  "geo" : { },
  "id_str" : "301819216561049600",
  "in_reply_to_user_id" : 1119708565,
  "text" : "@permakittens Loving it. The API is a little verbose though, and I'll be publishing a DSL to help with it soon once I can polish it",
  "id" : 301819216561049600,
  "in_reply_to_status_id" : 301818156312326145,
  "created_at" : "2013-02-13 22:24:43 +0000",
  "in_reply_to_screen_name" : "permakittens",
  "in_reply_to_user_id_str" : "1119708565",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00D8rta",
      "screen_name" : "orta",
      "indices" : [ 0, 5 ],
      "id_str" : "2569881",
      "id" : 2569881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301815314365177856",
  "geo" : { },
  "id_str" : "301816641140969473",
  "in_reply_to_user_id" : 2569881,
  "text" : "@orta CocoaPods doesn't deal with dependency management or updating. Bundler has this down.",
  "id" : 301816641140969473,
  "in_reply_to_status_id" : 301815314365177856,
  "created_at" : "2013-02-13 22:14:29 +0000",
  "in_reply_to_screen_name" : "orta",
  "in_reply_to_user_id_str" : "2569881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Pilkington",
      "screen_name" : "pilky",
      "indices" : [ 0, 6 ],
      "id_str" : "14237896",
      "id" : 14237896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301808311043518464",
  "geo" : { },
  "id_str" : "301809659617091586",
  "in_reply_to_user_id" : 14237896,
  "text" : "@pilky cool, but some classes need alloc.initWithABunchOfCrap :( It doesn't bother me either way.",
  "id" : 301809659617091586,
  "in_reply_to_status_id" : 301808311043518464,
  "created_at" : "2013-02-13 21:46:44 +0000",
  "in_reply_to_screen_name" : "pilky",
  "in_reply_to_user_id_str" : "14237896",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "756161",
      "id" : 756161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301806692314796032",
  "geo" : { },
  "id_str" : "301807433586712577",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer Yes!",
  "id" : 301807433586712577,
  "in_reply_to_status_id" : 301806692314796032,
  "created_at" : "2013-02-13 21:37:54 +0000",
  "in_reply_to_screen_name" : "zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 57 ],
      "url" : "https:\/\/t.co\/s4mc4KYv",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/status\/205046717509419008",
      "display_url" : "twitter.com\/qrush\/status\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301806582482751488",
  "text" : "Your here's your daily reminder to: https:\/\/t.co\/s4mc4KYv",
  "id" : 301806582482751488,
  "created_at" : "2013-02-13 21:34:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Fuchs",
      "screen_name" : "thomasfuchs",
      "indices" : [ 0, 12 ],
      "id_str" : "6927562",
      "id" : 6927562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301805634188369920",
  "geo" : { },
  "id_str" : "301805931640008704",
  "in_reply_to_user_id" : 6927562,
  "text" : "@thomasfuchs Awesome! Really excited to see who starts writing apps now.",
  "id" : 301805931640008704,
  "in_reply_to_status_id" : 301805634188369920,
  "created_at" : "2013-02-13 21:31:56 +0000",
  "in_reply_to_screen_name" : "thomasfuchs",
  "in_reply_to_user_id_str" : "6927562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Pilkington",
      "screen_name" : "pilky",
      "indices" : [ 0, 6 ],
      "id_str" : "14237896",
      "id" : 14237896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301803621786472448",
  "geo" : { },
  "id_str" : "301804508315537408",
  "in_reply_to_user_id" : 14237896,
  "text" : "@pilky Yeah, it doesn't seem consistent though. alloc.init tends to be more consistent across the different iOS APIs and external libs.",
  "id" : 301804508315537408,
  "in_reply_to_status_id" : 301803621786472448,
  "created_at" : "2013-02-13 21:26:16 +0000",
  "in_reply_to_screen_name" : "pilky",
  "in_reply_to_user_id_str" : "14237896",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kareem Kouddous",
      "screen_name" : "kareemk",
      "indices" : [ 0, 8 ],
      "id_str" : "8859412",
      "id" : 8859412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301795135560228864",
  "geo" : { },
  "id_str" : "301802685244518402",
  "in_reply_to_user_id" : 8859412,
  "text" : "@kareemk nope",
  "id" : 301802685244518402,
  "in_reply_to_status_id" : 301795135560228864,
  "created_at" : "2013-02-13 21:19:02 +0000",
  "in_reply_to_screen_name" : "kareemk",
  "in_reply_to_user_id_str" : "8859412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/ovoObXny",
      "expanded_url" : "http:\/\/37svn.com\/3432",
      "display_url" : "37svn.com\/3432"
    } ]
  },
  "geo" : { },
  "id_str" : "301799498533969920",
  "text" : "Why I loved building Basecamp for iPhone in RubyMotion: http:\/\/t.co\/ovoObXny",
  "id" : 301799498533969920,
  "created_at" : "2013-02-13 21:06:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 58 ],
      "url" : "https:\/\/t.co\/fjhU5qHX",
      "expanded_url" : "https:\/\/github.com\/qrush\/unix",
      "display_url" : "github.com\/qrush\/unix"
    } ]
  },
  "in_reply_to_status_id_str" : "301786292709126144",
  "geo" : { },
  "id_str" : "301786467284418560",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef There's certainly none in https:\/\/t.co\/fjhU5qHX",
  "id" : 301786467284418560,
  "in_reply_to_status_id" : 301786292709126144,
  "created_at" : "2013-02-13 20:14:35 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 38 ],
      "url" : "https:\/\/t.co\/FyKnmnoO",
      "expanded_url" : "https:\/\/github.com\/qrush\/photoshop-1.0.1\/blob\/master\/Tables.p#L211",
      "display_url" : "github.com\/qrush\/photosho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301785720018837504",
  "text" : "Metaprogramming? https:\/\/t.co\/FyKnmnoO",
  "id" : 301785720018837504,
  "created_at" : "2013-02-13 20:11:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 58 ],
      "url" : "https:\/\/t.co\/4qCF7SuI",
      "expanded_url" : "https:\/\/github.com\/qrush\/photoshop-1.0.1",
      "display_url" : "github.com\/qrush\/photosho\u2026"
    }, {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/ZpXCLlQT",
      "expanded_url" : "http:\/\/computerhistory.org\/atchm\/adobe-photoshop-source-code\/",
      "display_url" : "computerhistory.org\/atchm\/adobe-ph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301785086867681280",
  "text" : "Dumped Photoshop v1.0.1 into GitHub: https:\/\/t.co\/4qCF7SuI via http:\/\/t.co\/ZpXCLlQT",
  "id" : 301785086867681280,
  "created_at" : "2013-02-13 20:09:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basil",
      "screen_name" : "basil",
      "indices" : [ 0, 6 ],
      "id_str" : "9102",
      "id" : 9102
    }, {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 76, 83 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301739528123719680",
  "geo" : { },
  "id_str" : "301773944002854913",
  "in_reply_to_user_id" : 9102,
  "text" : "@basil ha! We did use SSPullToRefresh but ditched it when we went iOS6+ \/cc @soffes",
  "id" : 301773944002854913,
  "in_reply_to_status_id" : 301739528123719680,
  "created_at" : "2013-02-13 19:24:49 +0000",
  "in_reply_to_screen_name" : "basil",
  "in_reply_to_user_id_str" : "9102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 23, 29 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301744989019467776",
  "geo" : { },
  "id_str" : "301773602238369795",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit have you read @raggi\u2019s security proposal on rubygems-developers ML?",
  "id" : 301773602238369795,
  "in_reply_to_status_id" : 301744989019467776,
  "created_at" : "2013-02-13 19:23:28 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301744989019467776",
  "geo" : { },
  "id_str" : "301773484076449792",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit I\u2019d hope gem certs would prevent audits from happening again\u2026but who knows :(",
  "id" : 301773484076449792,
  "in_reply_to_status_id" : 301744989019467776,
  "created_at" : "2013-02-13 19:22:59 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tomek Kopczuk",
      "screen_name" : "tkopczuk",
      "indices" : [ 0, 9 ],
      "id_str" : "254953234",
      "id" : 254953234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301755375030525953",
  "geo" : { },
  "id_str" : "301773225086558209",
  "in_reply_to_user_id" : 254953234,
  "text" : "@tkopczuk thanks! It\u2019s definitely a start, and we\u2019re loving it so far. More!",
  "id" : 301773225086558209,
  "in_reply_to_status_id" : 301755375030525953,
  "created_at" : "2013-02-13 19:21:58 +0000",
  "in_reply_to_screen_name" : "tkopczuk",
  "in_reply_to_user_id_str" : "254953234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tomek Kopczuk",
      "screen_name" : "tkopczuk",
      "indices" : [ 0, 9 ],
      "id_str" : "254953234",
      "id" : 254953234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301742990056124418",
  "geo" : { },
  "id_str" : "301751118852149250",
  "in_reply_to_user_id" : 254953234,
  "text" : "@tkopczuk the content is *all* web views, so that's why. we definitely are going to look into optimizing the pages more.",
  "id" : 301751118852149250,
  "in_reply_to_status_id" : 301742990056124418,
  "created_at" : "2013-02-13 17:54:07 +0000",
  "in_reply_to_screen_name" : "tkopczuk",
  "in_reply_to_user_id_str" : "254953234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301563234186575873",
  "geo" : { },
  "id_str" : "301563717626232832",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub shy hoo lood!",
  "id" : 301563717626232832,
  "in_reply_to_status_id" : 301563234186575873,
  "created_at" : "2013-02-13 05:29:27 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Coates",
      "screen_name" : "coates",
      "indices" : [ 0, 7 ],
      "id_str" : "14249124",
      "id" : 14249124
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 116, 124 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/VkGM9FsF",
      "expanded_url" : "http:\/\/guides.rubygems.org",
      "display_url" : "guides.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "301555417446748160",
  "geo" : { },
  "id_str" : "301563543420026880",
  "in_reply_to_user_id" : 14249124,
  "text" : "@coates the docs site is mega out of date. http:\/\/t.co\/VkGM9FsF is the latest stuff. We need to redirect those! \/cc @drbrain",
  "id" : 301563543420026880,
  "in_reply_to_status_id" : 301555417446748160,
  "created_at" : "2013-02-13 05:28:46 +0000",
  "in_reply_to_screen_name" : "coates",
  "in_reply_to_user_id_str" : "14249124",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301547923429265409",
  "geo" : { },
  "id_str" : "301548069772746753",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox are you in Boston again?",
  "id" : 301548069772746753,
  "in_reply_to_status_id" : 301547923429265409,
  "created_at" : "2013-02-13 04:27:16 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 5, 14 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 15, 22 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 23, 34 ],
      "id_str" : "2355631",
      "id" : 2355631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301547039722979329",
  "text" : "Ping @indirect @hone02 @lmarburger got a moment to get on #rubygems IRC ?",
  "id" : 301547039722979329,
  "created_at" : "2013-02-13 04:23:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 14, 28 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Jake Goulding",
      "screen_name" : "JakeGoulding",
      "indices" : [ 33, 46 ],
      "id_str" : "197769225",
      "id" : 197769225
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 84, 92 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301493786155048960",
  "text" : "Big thanks to @Carols10cents and @JakeGoulding for coming up to Buffalo to speak at @wnyruby!",
  "id" : 301493786155048960,
  "created_at" : "2013-02-13 00:51:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 0, 9 ],
      "id_str" : "14925480",
      "id" : 14925480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 104 ],
      "url" : "https:\/\/t.co\/jo1edsYv",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/issues\/424",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "301443610774220800",
  "geo" : { },
  "id_str" : "301444003986042880",
  "in_reply_to_user_id" : 14925480,
  "text" : "@nirvdrum it is both. i would love to have zero permadeletion\/yank problems. more: https:\/\/t.co\/jo1edsYv",
  "id" : 301444003986042880,
  "in_reply_to_status_id" : 301443610774220800,
  "created_at" : "2013-02-12 21:33:45 +0000",
  "in_reply_to_screen_name" : "nirvdrum",
  "in_reply_to_user_id_str" : "14925480",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 0, 9 ],
      "id_str" : "14925480",
      "id" : 14925480
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 10, 22 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 53, 62 ],
      "id_str" : "14925480",
      "id" : 14925480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301442541625159680",
  "geo" : { },
  "id_str" : "301443225078620160",
  "in_reply_to_user_id" : 14925480,
  "text" : "@nirvdrum @bcardarella was it a recent upgrade? also @nirvdrum you have complained about it for years but no contributions :(",
  "id" : 301443225078620160,
  "in_reply_to_status_id" : 301442541625159680,
  "created_at" : "2013-02-12 21:30:40 +0000",
  "in_reply_to_screen_name" : "nirvdrum",
  "in_reply_to_user_id_str" : "14925480",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darin Swanson",
      "screen_name" : "darinrs",
      "indices" : [ 0, 8 ],
      "id_str" : "14241311",
      "id" : 14241311
    }, {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 9, 15 ],
      "id_str" : "18673",
      "id" : 18673
    }, {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 16, 25 ],
      "id_str" : "14925480",
      "id" : 14925480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301439416520548352",
  "geo" : { },
  "id_str" : "301443015036243968",
  "in_reply_to_user_id" : 14241311,
  "text" : "@darinrs @aeden @nirvdrum you guys automate gem releases? that sounds really dangerous",
  "id" : 301443015036243968,
  "in_reply_to_status_id" : 301439416520548352,
  "created_at" : "2013-02-12 21:29:49 +0000",
  "in_reply_to_screen_name" : "darinrs",
  "in_reply_to_user_id_str" : "14241311",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Elliott",
      "screen_name" : "p_elliott",
      "indices" : [ 0, 10 ],
      "id_str" : "18047782",
      "id" : 18047782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 32 ],
      "url" : "https:\/\/t.co\/dvtlBPcK",
      "expanded_url" : "https:\/\/github.com\/qrush\/dotfiles\/blob\/master\/aliases#L1",
      "display_url" : "github.com\/qrush\/dotfiles\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "301442540496900096",
  "geo" : { },
  "id_str" : "301442930739142656",
  "in_reply_to_user_id" : 18047782,
  "text" : "@p_elliott https:\/\/t.co\/dvtlBPcK",
  "id" : 301442930739142656,
  "in_reply_to_status_id" : 301442540496900096,
  "created_at" : "2013-02-12 21:29:29 +0000",
  "in_reply_to_screen_name" : "p_elliott",
  "in_reply_to_user_id_str" : "18047782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tomek Kopczuk",
      "screen_name" : "tkopczuk",
      "indices" : [ 0, 9 ],
      "id_str" : "254953234",
      "id" : 254953234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301432438582824960",
  "geo" : { },
  "id_str" : "301442737696280576",
  "in_reply_to_user_id" : 254953234,
  "text" : "@tkopczuk hey! what is sluggish exactly? we have a release waiting for review that should help with caching.",
  "id" : 301442737696280576,
  "in_reply_to_status_id" : 301432438582824960,
  "created_at" : "2013-02-12 21:28:43 +0000",
  "in_reply_to_screen_name" : "tkopczuk",
  "in_reply_to_user_id_str" : "254953234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 0, 9 ],
      "id_str" : "14925480",
      "id" : 14925480
    }, {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 10, 16 ],
      "id_str" : "18673",
      "id" : 18673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301432324086702080",
  "geo" : { },
  "id_str" : "301437486838722560",
  "in_reply_to_user_id" : 14925480,
  "text" : "@nirvdrum @aeden yeah i dont know what to do about this. we still get several requests\/week for permadeletion. :(",
  "id" : 301437486838722560,
  "in_reply_to_status_id" : 301432324086702080,
  "created_at" : "2013-02-12 21:07:51 +0000",
  "in_reply_to_screen_name" : "nirvdrum",
  "in_reply_to_user_id_str" : "14925480",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 0, 6 ],
      "id_str" : "18673",
      "id" : 18673
    }, {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 7, 16 ],
      "id_str" : "14925480",
      "id" : 14925480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301427742375829504",
  "geo" : { },
  "id_str" : "301430880113664001",
  "in_reply_to_user_id" : 18673,
  "text" : "@aeden @nirvdrum just saw two of these. what got yanked?",
  "id" : 301430880113664001,
  "in_reply_to_status_id" : 301427742375829504,
  "created_at" : "2013-02-12 20:41:36 +0000",
  "in_reply_to_screen_name" : "aeden",
  "in_reply_to_user_id_str" : "18673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/6aAzzEND",
      "expanded_url" : "http:\/\/www.w3.org\/TR\/2010\/WD-emotionml-20100729\/",
      "display_url" : "w3.org\/TR\/2010\/WD-emo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301417012138217473",
  "text" : "&lt;EMOTION&gt;&lt;DIMENSION NAME=\"EXTREME SADNESS\"&gt; http:\/\/t.co\/6aAzzEND",
  "id" : 301417012138217473,
  "created_at" : "2013-02-12 19:46:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301400444217982976",
  "text" : "lmao if your supercomputer isn't also a bench",
  "id" : 301400444217982976,
  "created_at" : "2013-02-12 18:40:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Babrou",
      "screen_name" : "ibobrik",
      "indices" : [ 0, 8 ],
      "id_str" : "15795956",
      "id" : 15795956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301390601541271552",
  "geo" : { },
  "id_str" : "301399264221876224",
  "in_reply_to_user_id" : 15795956,
  "text" : "@ibobrik yikes. we're on it.",
  "id" : 301399264221876224,
  "in_reply_to_status_id" : 301390601541271552,
  "created_at" : "2013-02-12 18:35:58 +0000",
  "in_reply_to_screen_name" : "ibobrik",
  "in_reply_to_user_id_str" : "15795956",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/3i7ouPrI",
      "expanded_url" : "http:\/\/mattnt.files.wordpress.com\/2011\/12\/cray.png",
      "display_url" : "mattnt.files.wordpress.com\/2011\/12\/cray.p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301398211514494977",
  "text" : "That shit cray. http:\/\/t.co\/3i7ouPrI",
  "id" : 301398211514494977,
  "created_at" : "2013-02-12 18:31:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kognate",
      "screen_name" : "kognate",
      "indices" : [ 0, 8 ],
      "id_str" : "14923238",
      "id" : 14923238
    }, {
      "name" : "Jonathan Penn",
      "screen_name" : "jonathanpenn",
      "indices" : [ 9, 22 ],
      "id_str" : "9896112",
      "id" : 9896112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301392927907803136",
  "geo" : { },
  "id_str" : "301393205289705472",
  "in_reply_to_user_id" : 14923238,
  "text" : "@kognate @jonathanpenn Truth.",
  "id" : 301393205289705472,
  "in_reply_to_status_id" : 301392927907803136,
  "created_at" : "2013-02-12 18:11:54 +0000",
  "in_reply_to_screen_name" : "kognate",
  "in_reply_to_user_id_str" : "14923238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "756161",
      "id" : 756161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301391872281169920",
  "geo" : { },
  "id_str" : "301392234987790336",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer oh, 98 things *depend on* carrierwave. why not paperclip?",
  "id" : 301392234987790336,
  "in_reply_to_status_id" : 301391872281169920,
  "created_at" : "2013-02-12 18:08:03 +0000",
  "in_reply_to_screen_name" : "zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "756161",
      "id" : 756161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301390888599420928",
  "geo" : { },
  "id_str" : "301391501970272256",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer 95!!?! wtf!?",
  "id" : 301391501970272256,
  "in_reply_to_status_id" : 301390888599420928,
  "created_at" : "2013-02-12 18:05:08 +0000",
  "in_reply_to_screen_name" : "zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Thomas",
      "screen_name" : "adrianthomas",
      "indices" : [ 0, 13 ],
      "id_str" : "12464072",
      "id" : 12464072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301381674623713280",
  "geo" : { },
  "id_str" : "301382390046134272",
  "in_reply_to_user_id" : 12464072,
  "text" : "@adrianthomas however none of that has to do with Xcode being used or not...that's just a tradeoff for the hybrid approach :)",
  "id" : 301382390046134272,
  "in_reply_to_status_id" : 301381674623713280,
  "created_at" : "2013-02-12 17:28:55 +0000",
  "in_reply_to_screen_name" : "adrianthomas",
  "in_reply_to_user_id_str" : "12464072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Thomas",
      "screen_name" : "adrianthomas",
      "indices" : [ 0, 13 ],
      "id_str" : "12464072",
      "id" : 12464072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301381674623713280",
  "geo" : { },
  "id_str" : "301382124823515137",
  "in_reply_to_user_id" : 12464072,
  "text" : "@adrianthomas yep, it is: All of the content in the app is HTML. Caching will be improved in the next release, so that should help.",
  "id" : 301382124823515137,
  "in_reply_to_status_id" : 301381674623713280,
  "created_at" : "2013-02-12 17:27:52 +0000",
  "in_reply_to_screen_name" : "adrianthomas",
  "in_reply_to_user_id_str" : "12464072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Thomas",
      "screen_name" : "adrianthomas",
      "indices" : [ 0, 13 ],
      "id_str" : "12464072",
      "id" : 12464072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301375221506654208",
  "geo" : { },
  "id_str" : "301380662408134657",
  "in_reply_to_user_id" : 12464072,
  "text" : "@adrianthomas would love to hear about what's \"delayed\" in the app. it's definitely a v1 though! :)",
  "id" : 301380662408134657,
  "in_reply_to_status_id" : 301375221506654208,
  "created_at" : "2013-02-12 17:22:03 +0000",
  "in_reply_to_screen_name" : "adrianthomas",
  "in_reply_to_user_id_str" : "12464072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kognate",
      "screen_name" : "kognate",
      "indices" : [ 0, 8 ],
      "id_str" : "14923238",
      "id" : 14923238
    }, {
      "name" : "Jonathan Penn",
      "screen_name" : "jonathanpenn",
      "indices" : [ 9, 22 ],
      "id_str" : "9896112",
      "id" : 9896112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301373440273809409",
  "geo" : { },
  "id_str" : "301374109345009664",
  "in_reply_to_user_id" : 14923238,
  "text" : "@kognate @jonathanpenn Madness!",
  "id" : 301374109345009664,
  "in_reply_to_status_id" : 301373440273809409,
  "created_at" : "2013-02-12 16:56:01 +0000",
  "in_reply_to_screen_name" : "kognate",
  "in_reply_to_user_id_str" : "14923238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/8awttAN9",
      "expanded_url" : "http:\/\/turntable.fm\/jam_bands_no_lames_1up1down",
      "display_url" : "turntable.fm\/jam_bands_no_l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301369612010930176",
  "text" : "Now playing Rush - 12\/16\/1974: Working Man \u266B\u266A #turntablefm http:\/\/t.co\/8awttAN9",
  "id" : 301369612010930176,
  "created_at" : "2013-02-12 16:38:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nico H\u00E4m\u00E4l\u00E4inen",
      "screen_name" : "Clooth",
      "indices" : [ 0, 7 ],
      "id_str" : "14439156",
      "id" : 14439156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301352565784846336",
  "geo" : { },
  "id_str" : "301357836120776704",
  "in_reply_to_user_id" : 14439156,
  "text" : "@Clooth yep, trying to think about what to cover...lots of content. :)",
  "id" : 301357836120776704,
  "in_reply_to_status_id" : 301352565784846336,
  "created_at" : "2013-02-12 15:51:21 +0000",
  "in_reply_to_screen_name" : "Clooth",
  "in_reply_to_user_id_str" : "14439156",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rey Bango",
      "screen_name" : "reybango",
      "indices" : [ 0, 9 ],
      "id_str" : "1589691",
      "id" : 1589691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301355697491300352",
  "geo" : { },
  "id_str" : "301357732135575552",
  "in_reply_to_user_id" : 1589691,
  "text" : "@reybango thanks!",
  "id" : 301357732135575552,
  "in_reply_to_status_id" : 301355697491300352,
  "created_at" : "2013-02-12 15:50:56 +0000",
  "in_reply_to_screen_name" : "reybango",
  "in_reply_to_user_id_str" : "1589691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301357038867472384",
  "text" : "RT @dhh: Funny how the Facebook \"HTML5 was a big mistake\" was all blamed on how slow their old hybrid app was. Basecamp iOS is a hybrid, ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301356798097641472",
    "text" : "Funny how the Facebook \"HTML5 was a big mistake\" was all blamed on how slow their old hybrid app was. Basecamp iOS is a hybrid, super fast.",
    "id" : 301356798097641472,
    "created_at" : "2013-02-12 15:47:14 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 301357038867472384,
  "created_at" : "2013-02-12 15:48:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 75, 86 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/NzKQ2xir",
      "expanded_url" : "http:\/\/37svn.com\/3430",
      "display_url" : "37svn.com\/3430"
    } ]
  },
  "geo" : { },
  "id_str" : "301353122717122560",
  "text" : "LAUNCH! The official Basecamp iPhone app, all done in house, completely in @RubyMotion, and with minimal XCode usage. http:\/\/t.co\/NzKQ2xir",
  "id" : 301353122717122560,
  "created_at" : "2013-02-12 15:32:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/Eobl9ayF",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3430-launch-the-official-basecamp-iphone-app",
      "display_url" : "37signals.com\/svn\/posts\/3430\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301351172806176768",
  "text" : "RT @37signals: LAUNCH: The official Basecamp iPhone app - http:\/\/t.co\/Eobl9ayF. (Did someone say \"finally\"?)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/Eobl9ayF",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3430-launch-the-official-basecamp-iphone-app",
        "display_url" : "37signals.com\/svn\/posts\/3430\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301350826159505408",
    "text" : "LAUNCH: The official Basecamp iPhone app - http:\/\/t.co\/Eobl9ayF. (Did someone say \"finally\"?)",
    "id" : 301350826159505408,
    "created_at" : "2013-02-12 15:23:30 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 301351172806176768,
  "created_at" : "2013-02-12 15:24:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/TwGCxlkL",
      "expanded_url" : "http:\/\/37signals.com\/remote",
      "display_url" : "37signals.com\/remote"
    } ]
  },
  "geo" : { },
  "id_str" : "301192916896976898",
  "text" : "RT @jasonfried: We're working on a new book called REMOTE: Office Not Required. Some early details: http:\/\/t.co\/TwGCxlkL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/TwGCxlkL",
        "expanded_url" : "http:\/\/37signals.com\/remote",
        "display_url" : "37signals.com\/remote"
      } ]
    },
    "geo" : { },
    "id_str" : "301192692644331520",
    "text" : "We're working on a new book called REMOTE: Office Not Required. Some early details: http:\/\/t.co\/TwGCxlkL",
    "id" : 301192692644331520,
    "created_at" : "2013-02-12 04:55:08 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 301192916896976898,
  "created_at" : "2013-02-12 04:56:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/dxiJ175t",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Put_Me_Off_at_Buffalo",
      "display_url" : "en.wikipedia.org\/wiki\/Put_Me_Of\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301187149439578114",
  "text" : "Nothing like some good 'ol racist tunes about Buffalo. http:\/\/t.co\/dxiJ175t",
  "id" : 301187149439578114,
  "created_at" : "2013-02-12 04:33:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 0, 7 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301180124408209408",
  "geo" : { },
  "id_str" : "301180467925889024",
  "in_reply_to_user_id" : 5452072,
  "text" : "@nb3004 or to charge at all? FFS.",
  "id" : 301180467925889024,
  "in_reply_to_status_id" : 301180124408209408,
  "created_at" : "2013-02-12 04:06:33 +0000",
  "in_reply_to_screen_name" : "nb3004",
  "in_reply_to_user_id_str" : "5452072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Armstrong",
      "screen_name" : "cgarmstrong",
      "indices" : [ 0, 12 ],
      "id_str" : "21790885",
      "id" : 21790885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301132605045211136",
  "geo" : { },
  "id_str" : "301139227855437824",
  "in_reply_to_user_id" : 21790885,
  "text" : "@cgarmstrong yep, it\u2019s definitely a v1. Thanks for the review.",
  "id" : 301139227855437824,
  "in_reply_to_status_id" : 301132605045211136,
  "created_at" : "2013-02-12 01:22:41 +0000",
  "in_reply_to_screen_name" : "cgarmstrong",
  "in_reply_to_user_id_str" : "21790885",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301131819250769921",
  "geo" : { },
  "id_str" : "301139031767519232",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes thanks man.",
  "id" : 301139031767519232,
  "in_reply_to_status_id" : 301131819250769921,
  "created_at" : "2013-02-12 01:21:54 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    }, {
      "name" : "Steve Derico",
      "screen_name" : "stevederico",
      "indices" : [ 8, 20 ],
      "id_str" : "14655968",
      "id" : 14655968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301111183652577280",
  "geo" : { },
  "id_str" : "301130865877057536",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes @stevederico sure is!",
  "id" : 301130865877057536,
  "in_reply_to_status_id" : 301111183652577280,
  "created_at" : "2013-02-12 00:49:27 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301068912039165952",
  "text" : "I am Syck of this YAML nonsense.",
  "id" : 301068912039165952,
  "created_at" : "2013-02-11 20:43:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/LHaiK2Rv",
      "expanded_url" : "http:\/\/rubygems.org\/",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 110, 131 ],
      "url" : "https:\/\/t.co\/JYQaVx9k",
      "expanded_url" : "https:\/\/groups.google.com\/group\/rubyonrails-security",
      "display_url" : "groups.google.com\/group\/rubyonra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301042486787330050",
  "text" : "Just upgraded http:\/\/t.co\/LHaiK2Rv to Rails 3.2.12. Upgrade your apps too, lots of new security issues today: https:\/\/t.co\/JYQaVx9k",
  "id" : 301042486787330050,
  "created_at" : "2013-02-11 18:58:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "BfloFRED",
      "screen_name" : "BfloFRED",
      "indices" : [ 16, 25 ],
      "id_str" : "876930312",
      "id" : 876930312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301030710972645376",
  "geo" : { },
  "id_str" : "301031414453903360",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten @BfloFRED oh man please keep this unstyled. so good.",
  "id" : 301031414453903360,
  "in_reply_to_status_id" : 301030710972645376,
  "created_at" : "2013-02-11 18:14:16 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Azizi Khalid",
      "screen_name" : "azizikhalid",
      "indices" : [ 0, 12 ],
      "id_str" : "12148212",
      "id" : 12148212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301009691515965440",
  "geo" : { },
  "id_str" : "301016062374322177",
  "in_reply_to_user_id" : 12148212,
  "text" : "@azizikhalid it\u2019s definitely a v1. If something is buggy let me know.",
  "id" : 301016062374322177,
  "in_reply_to_status_id" : 301009691515965440,
  "created_at" : "2013-02-11 17:13:16 +0000",
  "in_reply_to_screen_name" : "azizikhalid",
  "in_reply_to_user_id_str" : "12148212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301008588669845504",
  "text" : "Yes, that's the only car related gif I have. My gifs folder is saddened by this announcement.",
  "id" : 301008588669845504,
  "created_at" : "2013-02-11 16:43:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 10, 21 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 47, 52 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/WoIAt79d",
      "expanded_url" : "http:\/\/i.imgur.com\/tsJSTQw.gif",
      "display_url" : "i.imgur.com\/tsJSTQw.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "301008466967945217",
  "text" : "Wrapped a @thoughtbot morning zoo podcast with @r00k. TRAFFIC AND WEATHER! BRAKE LIGHTS! JACK-KNIFED BOBCAT ON 495! http:\/\/t.co\/WoIAt79d",
  "id" : 301008466967945217,
  "created_at" : "2013-02-11 16:43:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NSHipster",
      "screen_name" : "NSHipster",
      "indices" : [ 0, 10 ],
      "id_str" : "629523445",
      "id" : 629523445
    }, {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 11, 17 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301006246935416834",
  "geo" : { },
  "id_str" : "301006435536470017",
  "in_reply_to_user_id" : 629523445,
  "text" : "@NSHipster @mattt Not from what I saw, but I could be wrong :)",
  "id" : 301006435536470017,
  "in_reply_to_status_id" : 301006246935416834,
  "created_at" : "2013-02-11 16:35:01 +0000",
  "in_reply_to_screen_name" : "NSHipster",
  "in_reply_to_user_id_str" : "629523445",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NSHipster",
      "screen_name" : "NSHipster",
      "indices" : [ 0, 10 ],
      "id_str" : "629523445",
      "id" : 629523445
    }, {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 11, 17 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300892558505177089",
  "geo" : { },
  "id_str" : "300983698621337600",
  "in_reply_to_user_id" : 629523445,
  "text" : "@NSHipster @mattt this should mention it doesn\u2019t cache any HTTPS data. Cue\/SDURLCache does though!",
  "id" : 300983698621337600,
  "in_reply_to_status_id" : 300892558505177089,
  "created_at" : "2013-02-11 15:04:40 +0000",
  "in_reply_to_screen_name" : "NSHipster",
  "in_reply_to_user_id_str" : "629523445",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Hardy",
      "screen_name" : "packagethief",
      "indices" : [ 0, 13 ],
      "id_str" : "12089482",
      "id" : 12089482
    }, {
      "name" : "Andrea LaRowe",
      "screen_name" : "alarowe",
      "indices" : [ 14, 22 ],
      "id_str" : "270917610",
      "id" : 270917610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300981397219332096",
  "geo" : { },
  "id_str" : "300981709959221249",
  "in_reply_to_user_id" : 12089482,
  "text" : "@packagethief @alarowe SHE KNOWS",
  "id" : 300981709959221249,
  "in_reply_to_status_id" : 300981397219332096,
  "created_at" : "2013-02-11 14:56:46 +0000",
  "in_reply_to_screen_name" : "packagethief",
  "in_reply_to_user_id_str" : "12089482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aanand Prasad",
      "screen_name" : "aanand",
      "indices" : [ 0, 7 ],
      "id_str" : "14149919",
      "id" : 14149919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300981376046493697",
  "geo" : { },
  "id_str" : "300981545597022210",
  "in_reply_to_user_id" : 14149919,
  "text" : "@aanand used testflightapp for Basecamp iOS and it worked great!",
  "id" : 300981545597022210,
  "in_reply_to_status_id" : 300981376046493697,
  "created_at" : "2013-02-11 14:56:07 +0000",
  "in_reply_to_screen_name" : "aanand",
  "in_reply_to_user_id_str" : "14149919",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    }, {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 7, 19 ],
      "id_str" : "5744132",
      "id" : 5744132
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 26, 36 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300825919134777344",
  "geo" : { },
  "id_str" : "300826421612396545",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d @singheyjude Derp. @aquaranto found out they have a lot of full length concerts on YouTube that are great.",
  "id" : 300826421612396545,
  "in_reply_to_status_id" : 300825919134777344,
  "created_at" : "2013-02-11 04:39:42 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Wroblewski",
      "screen_name" : "Domness",
      "indices" : [ 0, 8 ],
      "id_str" : "15513690",
      "id" : 15513690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300765517310996481",
  "geo" : { },
  "id_str" : "300826269057171456",
  "in_reply_to_user_id" : 15513690,
  "text" : "@Domness yikes! We have a new version with some fixes waiting for review right now.",
  "id" : 300826269057171456,
  "in_reply_to_status_id" : 300765517310996481,
  "created_at" : "2013-02-11 04:39:06 +0000",
  "in_reply_to_screen_name" : "Domness",
  "in_reply_to_user_id_str" : "15513690",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300821489085726721",
  "geo" : { },
  "id_str" : "300824296744423424",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d I hope this is sarcasm",
  "id" : 300824296744423424,
  "in_reply_to_status_id" : 300821489085726721,
  "created_at" : "2013-02-11 04:31:16 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    }, {
      "name" : "Kiki Aardsma",
      "screen_name" : "kikiaards",
      "indices" : [ 17, 27 ],
      "id_str" : "355473809",
      "id" : 355473809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300762065986019328",
  "geo" : { },
  "id_str" : "300763959395491840",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw it\u2019s all @kikiaards\u2019 fault",
  "id" : 300763959395491840,
  "in_reply_to_status_id" : 300762065986019328,
  "created_at" : "2013-02-11 00:31:30 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300731547395452928",
  "geo" : { },
  "id_str" : "300754103468978176",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene don\u2019t pick the Dwarves!",
  "id" : 300754103468978176,
  "in_reply_to_status_id" : 300731547395452928,
  "created_at" : "2013-02-10 23:52:20 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin O'Neill",
      "screen_name" : "kevonil",
      "indices" : [ 0, 8 ],
      "id_str" : "12163342",
      "id" : 12163342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300751188352192514",
  "geo" : { },
  "id_str" : "300754004160434177",
  "in_reply_to_user_id" : 12163342,
  "text" : "@kevonil thanks man.",
  "id" : 300754004160434177,
  "in_reply_to_status_id" : 300751188352192514,
  "created_at" : "2013-02-10 23:51:56 +0000",
  "in_reply_to_screen_name" : "kevonil",
  "in_reply_to_user_id_str" : "12163342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin O'Neill",
      "screen_name" : "kevonil",
      "indices" : [ 0, 8 ],
      "id_str" : "12163342",
      "id" : 12163342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300664867159937024",
  "geo" : { },
  "id_str" : "300673303452999680",
  "in_reply_to_user_id" : 12163342,
  "text" : "@kevonil actually, that's completely wrong...most of the content in the app is HTML5. We'll be posting more about this soon.",
  "id" : 300673303452999680,
  "in_reply_to_status_id" : 300664867159937024,
  "created_at" : "2013-02-10 18:31:16 +0000",
  "in_reply_to_screen_name" : "kevonil",
  "in_reply_to_user_id_str" : "12163342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300433517588934656",
  "geo" : { },
  "id_str" : "300437463191678976",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr this happens for any popular, public project. Issues get conflated with  support.",
  "id" : 300437463191678976,
  "in_reply_to_status_id" : 300433517588934656,
  "created_at" : "2013-02-10 02:54:07 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300387377493471233",
  "geo" : { },
  "id_str" : "300388669477507072",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu thanks (^\u25C7^;)",
  "id" : 300388669477507072,
  "in_reply_to_status_id" : 300387377493471233,
  "created_at" : "2013-02-09 23:40:14 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Mongeau",
      "screen_name" : "halogenandtoast",
      "indices" : [ 0, 16 ],
      "id_str" : "15428948",
      "id" : 15428948
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 17, 25 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300353665963786242",
  "geo" : { },
  "id_str" : "300354262263808000",
  "in_reply_to_user_id" : 15428948,
  "text" : "@halogenandtoast @sikachu EPIC GRIND!",
  "id" : 300354262263808000,
  "in_reply_to_status_id" : 300353665963786242,
  "created_at" : "2013-02-09 21:23:31 +0000",
  "in_reply_to_screen_name" : "halogenandtoast",
  "in_reply_to_user_id_str" : "15428948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jaki Levy",
      "screen_name" : "jackomo",
      "indices" : [ 0, 8 ],
      "id_str" : "6462982",
      "id" : 6462982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300325347205984258",
  "geo" : { },
  "id_str" : "300338373627875328",
  "in_reply_to_user_id" : 6462982,
  "text" : "@jackomo yes!",
  "id" : 300338373627875328,
  "in_reply_to_status_id" : 300325347205984258,
  "created_at" : "2013-02-09 20:20:22 +0000",
  "in_reply_to_screen_name" : "jackomo",
  "in_reply_to_user_id_str" : "6462982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300098281088901120",
  "text" : "Victory drinks tonight brought to you by The Knot. \uD83C\uDF40",
  "id" : 300098281088901120,
  "created_at" : "2013-02-09 04:26:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan deLevie",
      "screen_name" : "adelevie",
      "indices" : [ 0, 9 ],
      "id_str" : "12855662",
      "id" : 12855662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300096786096349184",
  "geo" : { },
  "id_str" : "300097632326537217",
  "in_reply_to_user_id" : 12855662,
  "text" : "@adelevie not yet. I tried to learn iOS before and nothing stuck. RM stuck. I will write more about it!",
  "id" : 300097632326537217,
  "in_reply_to_status_id" : 300096786096349184,
  "created_at" : "2013-02-09 04:23:45 +0000",
  "in_reply_to_screen_name" : "adelevie",
  "in_reply_to_user_id_str" : "12855662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Riley",
      "screen_name" : "timriley",
      "indices" : [ 0, 9 ],
      "id_str" : "12341",
      "id" : 12341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300094751984721921",
  "geo" : { },
  "id_str" : "300096629099356160",
  "in_reply_to_user_id" : 12341,
  "text" : "@timriley thanks man.",
  "id" : 300096629099356160,
  "in_reply_to_status_id" : 300094751984721921,
  "created_at" : "2013-02-09 04:19:46 +0000",
  "in_reply_to_screen_name" : "timriley",
  "in_reply_to_user_id_str" : "12341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Dorsey",
      "screen_name" : "adamthebig",
      "indices" : [ 0, 11 ],
      "id_str" : "151292532",
      "id" : 151292532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300060639810965504",
  "geo" : { },
  "id_str" : "300061938178748417",
  "in_reply_to_user_id" : 151292532,
  "text" : "@adamthebig and thanks!",
  "id" : 300061938178748417,
  "in_reply_to_status_id" : 300060639810965504,
  "created_at" : "2013-02-09 02:01:55 +0000",
  "in_reply_to_screen_name" : "adamthebig",
  "in_reply_to_user_id_str" : "151292532",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Dorsey",
      "screen_name" : "adamthebig",
      "indices" : [ 0, 11 ],
      "id_str" : "151292532",
      "id" : 151292532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300060639810965504",
  "geo" : { },
  "id_str" : "300061886752374786",
  "in_reply_to_user_id" : 151292532,
  "text" : "@adamthebig RubyMotion!",
  "id" : 300061886752374786,
  "in_reply_to_status_id" : 300060639810965504,
  "created_at" : "2013-02-09 02:01:43 +0000",
  "in_reply_to_screen_name" : "adamthebig",
  "in_reply_to_user_id_str" : "151292532",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300043012334039041",
  "text" : "OH \u201CI get tongue from my mother\u201D",
  "id" : 300043012334039041,
  "created_at" : "2013-02-09 00:46:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00E9r\u00E9mie F.",
      "screen_name" : "SkyNebula",
      "indices" : [ 0, 10 ],
      "id_str" : "15248516",
      "id" : 15248516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300025735832276994",
  "geo" : { },
  "id_str" : "300026377866997761",
  "in_reply_to_user_id" : 15248516,
  "text" : "@SkyNebula agreed, v1! There will be more updates soon. Just pushed 1.0.1 today.",
  "id" : 300026377866997761,
  "in_reply_to_status_id" : 300025735832276994,
  "created_at" : "2013-02-08 23:40:37 +0000",
  "in_reply_to_screen_name" : "SkyNebula",
  "in_reply_to_user_id_str" : "15248516",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00E9r\u00E9mie F.",
      "screen_name" : "SkyNebula",
      "indices" : [ 0, 10 ],
      "id_str" : "15248516",
      "id" : 15248516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300022494717419521",
  "geo" : { },
  "id_str" : "300024710656311296",
  "in_reply_to_user_id" : 15248516,
  "text" : "@SkyNebula it\u2019s there if you tap on your avatar or go off the People screen in any project. Way too hard though!",
  "id" : 300024710656311296,
  "in_reply_to_status_id" : 300022494717419521,
  "created_at" : "2013-02-08 23:33:59 +0000",
  "in_reply_to_screen_name" : "SkyNebula",
  "in_reply_to_user_id_str" : "15248516",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elias Klughammer",
      "screen_name" : "eliaskg",
      "indices" : [ 0, 8 ],
      "id_str" : "15266337",
      "id" : 15266337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300021156973510656",
  "geo" : { },
  "id_str" : "300023247024553984",
  "in_reply_to_user_id" : 15266337,
  "text" : "@eliaskg yep, we\u2019re working on it. Already have made a few changes to help with that.",
  "id" : 300023247024553984,
  "in_reply_to_status_id" : 300021156973510656,
  "created_at" : "2013-02-08 23:28:10 +0000",
  "in_reply_to_screen_name" : "eliaskg",
  "in_reply_to_user_id_str" : "15266337",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Braxton Colagross",
      "screen_name" : "brax4444",
      "indices" : [ 0, 9 ],
      "id_str" : "17797196",
      "id" : 17797196
    }, {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 10, 21 ],
      "id_str" : "2355631",
      "id" : 2355631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300019714476879872",
  "geo" : { },
  "id_str" : "300022659188662272",
  "in_reply_to_user_id" : 17797196,
  "text" : "@brax4444 @lmarburger yes, that makes the files that gem looks at",
  "id" : 300022659188662272,
  "in_reply_to_status_id" : 300019714476879872,
  "created_at" : "2013-02-08 23:25:50 +0000",
  "in_reply_to_screen_name" : "brax4444",
  "in_reply_to_user_id_str" : "17797196",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 67, 71 ],
      "id_str" : "10079052",
      "id" : 10079052
    }, {
      "name" : "Michael Berger",
      "screen_name" : "bergatron",
      "indices" : [ 72, 82 ],
      "id_str" : "15517749",
      "id" : 15517749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/DszJKSG7",
      "expanded_url" : "http:\/\/appstore.com\/basecamp",
      "display_url" : "appstore.com\/basecamp"
    } ]
  },
  "geo" : { },
  "id_str" : "300017310264086528",
  "text" : "Very proud that http:\/\/t.co\/DszJKSG7 is out, and big thanks to @JZ @rjs @bergatron for helping it ship. (Also, XCode was barely used!)",
  "id" : 300017310264086528,
  "created_at" : "2013-02-08 23:04:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 0, 9 ],
      "id_str" : "57753",
      "id" : 57753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300015953012457472",
  "geo" : { },
  "id_str" : "300016343053373440",
  "in_reply_to_user_id" : 57753,
  "text" : "@blowmage yes! i'm going to write more about it, but basically: Avoid XCode\/IB like the plague and ship.",
  "id" : 300016343053373440,
  "in_reply_to_status_id" : 300015953012457472,
  "created_at" : "2013-02-08 23:00:44 +0000",
  "in_reply_to_screen_name" : "blowmage",
  "in_reply_to_user_id_str" : "57753",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iosreviewtime",
      "indices" : [ 80, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/CyLL5Dh3",
      "expanded_url" : "http:\/\/reviewtimes.shinydevelopment.com\/",
      "display_url" : "reviewtimes.shinydevelopment.com"
    } ]
  },
  "geo" : { },
  "id_str" : "300006946331828224",
  "text" : "Waiting for review took 7 days. Review took under an hour. http:\/\/t.co\/CyLL5Dh3 #iosreviewtime",
  "id" : 300006946331828224,
  "created_at" : "2013-02-08 22:23:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "follow @mattetti",
      "screen_name" : "merbist",
      "indices" : [ 0, 8 ],
      "id_str" : "1549117117",
      "id" : 1549117117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300001966011060224",
  "geo" : { },
  "id_str" : "300002079634751488",
  "in_reply_to_user_id" : 16476741,
  "text" : "@merbist it sure is!",
  "id" : 300002079634751488,
  "in_reply_to_status_id" : 300001966011060224,
  "created_at" : "2013-02-08 22:04:04 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer MacDonald",
      "screen_name" : "ObjColumnist",
      "indices" : [ 0, 13 ],
      "id_str" : "17534569",
      "id" : 17534569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299990729479032832",
  "geo" : { },
  "id_str" : "299999158180384768",
  "in_reply_to_user_id" : 17534569,
  "text" : "@ObjColumnist yes, much! a lot of blog posts will be coming about this.",
  "id" : 299999158180384768,
  "in_reply_to_status_id" : 299990729479032832,
  "created_at" : "2013-02-08 21:52:27 +0000",
  "in_reply_to_screen_name" : "ObjColumnist",
  "in_reply_to_user_id_str" : "17534569",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Milewski",
      "screen_name" : "tmilewski",
      "indices" : [ 0, 10 ],
      "id_str" : "9761452",
      "id" : 9761452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299991425737687040",
  "geo" : { },
  "id_str" : "299993919633100800",
  "in_reply_to_user_id" : 9761452,
  "text" : "@tmilewski I used BubbleWrap a lot, no UI DSLs though. Autolayout was enough.",
  "id" : 299993919633100800,
  "in_reply_to_status_id" : 299991425737687040,
  "created_at" : "2013-02-08 21:31:38 +0000",
  "in_reply_to_screen_name" : "tmilewski",
  "in_reply_to_user_id_str" : "9761452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299990967807778816",
  "geo" : { },
  "id_str" : "299991110439288832",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y yay!",
  "id" : 299991110439288832,
  "in_reply_to_status_id" : 299990967807778816,
  "created_at" : "2013-02-08 21:20:28 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299988219410399232",
  "geo" : { },
  "id_str" : "299988845263482882",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz &lt;3 keep shipping awesome stuff!",
  "id" : 299988845263482882,
  "in_reply_to_status_id" : 299988219410399232,
  "created_at" : "2013-02-08 21:11:28 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299987715590590464",
  "geo" : { },
  "id_str" : "299987842166304770",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza Why was I expecting ponies?",
  "id" : 299987842166304770,
  "in_reply_to_status_id" : 299987715590590464,
  "created_at" : "2013-02-08 21:07:29 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin T.A. Gray",
      "screen_name" : "colinta",
      "indices" : [ 0, 8 ],
      "id_str" : "270963272",
      "id" : 270963272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299987184398770176",
  "geo" : { },
  "id_str" : "299987504923308032",
  "in_reply_to_user_id" : 270963272,
  "text" : "@colinta have been almost since Day 1..glad I can start talking about it more! :D",
  "id" : 299987504923308032,
  "in_reply_to_status_id" : 299987184398770176,
  "created_at" : "2013-02-08 21:06:09 +0000",
  "in_reply_to_screen_name" : "colinta",
  "in_reply_to_user_id_str" : "270963272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 0, 15 ],
      "id_str" : "13639982",
      "id" : 13639982
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 16, 27 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/x1Giowr4",
      "expanded_url" : "http:\/\/www.rubymotion.com\/conference\/",
      "display_url" : "rubymotion.com\/conference\/"
    } ]
  },
  "in_reply_to_status_id_str" : "299986743413846016",
  "geo" : { },
  "id_str" : "299987050596278272",
  "in_reply_to_user_id" : 13639982,
  "text" : "@MarkVillacampa @RubyMotion that's the plan, and at http:\/\/t.co\/x1Giowr4 !",
  "id" : 299987050596278272,
  "in_reply_to_status_id" : 299986743413846016,
  "created_at" : "2013-02-08 21:04:21 +0000",
  "in_reply_to_screen_name" : "MarkVillacampa",
  "in_reply_to_user_id_str" : "13639982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 24, 35 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 62 ],
      "url" : "https:\/\/t.co\/NCu56N0G",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/id599139477",
      "display_url" : "itunes.apple.com\/us\/app\/id59913\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299984920066002944",
  "text" : "Say hello to the newest @RubyMotion app: https:\/\/t.co\/NCu56N0G",
  "id" : 299984920066002944,
  "created_at" : "2013-02-08 20:55:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 64 ],
      "url" : "https:\/\/t.co\/qvOLkIc8",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/id599139477",
      "display_url" : "itunes.apple.com\/us\/app\/id59913\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299983971301867521",
  "text" : "RT @rjs: Something just hit the app store. https:\/\/t.co\/qvOLkIc8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 55 ],
        "url" : "https:\/\/t.co\/qvOLkIc8",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/id599139477",
        "display_url" : "itunes.apple.com\/us\/app\/id59913\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "299983640757166082",
    "text" : "Something just hit the app store. https:\/\/t.co\/qvOLkIc8",
    "id" : 299983640757166082,
    "created_at" : "2013-02-08 20:50:48 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 299983971301867521,
  "created_at" : "2013-02-08 20:52:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299965458428334080",
  "text" : "@withloudhands *since 6 months.",
  "id" : 299965458428334080,
  "created_at" : "2013-02-08 19:38:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299962006071566336",
  "text" : "@withloudhands not to our knowledge! Had him 6 months, he\u2019s been 50 lbs and cream with a touch of sable since.",
  "id" : 299962006071566336,
  "created_at" : "2013-02-08 19:24:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "coderjoe",
      "screen_name" : "coderjoe",
      "indices" : [ 0, 9 ],
      "id_str" : "15494948",
      "id" : 15494948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299949129671516161",
  "geo" : { },
  "id_str" : "299949533348114433",
  "in_reply_to_user_id" : 15494948,
  "text" : "@coderjoe I am in the jam room.",
  "id" : 299949533348114433,
  "in_reply_to_status_id" : 299949129671516161,
  "created_at" : "2013-02-08 18:35:16 +0000",
  "in_reply_to_screen_name" : "coderjoe",
  "in_reply_to_user_id_str" : "15494948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Thomson",
      "screen_name" : "Braxo",
      "indices" : [ 3, 9 ],
      "id_str" : "15477591",
      "id" : 15477591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nemo",
      "indices" : [ 11, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/tjROgn1b",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=i6zaVYWLTkU",
      "display_url" : "youtube.com\/watch?v=i6zaVY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299946112507322369",
  "text" : "RT @Braxo: #Nemo is a coming. Better get the ingredients to make French Toast. http:\/\/t.co\/tjROgn1b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nemo",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/tjROgn1b",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=i6zaVYWLTkU",
        "display_url" : "youtube.com\/watch?v=i6zaVY\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "299945209884717057",
    "text" : "#Nemo is a coming. Better get the ingredients to make French Toast. http:\/\/t.co\/tjROgn1b",
    "id" : 299945209884717057,
    "created_at" : "2013-02-08 18:18:05 +0000",
    "user" : {
      "name" : "Jesse Thomson",
      "screen_name" : "Braxo",
      "protected" : false,
      "id_str" : "15477591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2929946571\/9ff8217b64a06a9ce2e6ea3373ed1f0a_normal.jpeg",
      "id" : 15477591,
      "verified" : false
    }
  },
  "id" : 299946112507322369,
  "created_at" : "2013-02-08 18:21:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/zhbaeC7T",
      "expanded_url" : "http:\/\/turntable.fm",
      "display_url" : "turntable.fm"
    } ]
  },
  "geo" : { },
  "id_str" : "299944038889570304",
  "text" : "Playlists on http:\/\/t.co\/zhbaeC7T ! YES!",
  "id" : 299944038889570304,
  "created_at" : "2013-02-08 18:13:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299939214714343424",
  "geo" : { },
  "id_str" : "299939641405100032",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza actually dealing with the problem of code reuse\/packaging, dependency management, etc",
  "id" : 299939641405100032,
  "in_reply_to_status_id" : 299939214714343424,
  "created_at" : "2013-02-08 17:55:57 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 3, 9 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299938260036251648",
  "text" : "RT @ahuj9: So, Ladies! (YEAH) Ladies! (YEAH) Do you ride sandworms like Atreides? (YEAH!)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296628473269727235",
    "text" : "So, Ladies! (YEAH) Ladies! (YEAH) Do you ride sandworms like Atreides? (YEAH!)",
    "id" : 296628473269727235,
    "created_at" : "2013-01-30 14:38:33 +0000",
    "user" : {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "protected" : false,
      "id_str" : "205281746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2438738477\/m3tcrt9kvs9x0ff84b31_normal.jpeg",
      "id" : 205281746,
      "verified" : false
    }
  },
  "id" : 299938260036251648,
  "created_at" : "2013-02-08 17:50:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299933740593991683",
  "text" : "@withloudhands he's just over 2 now.",
  "id" : 299933740593991683,
  "created_at" : "2013-02-08 17:32:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/hCIiybKI",
      "expanded_url" : "http:\/\/flic.kr\/p\/dTbwdV",
      "display_url" : "flic.kr\/p\/dTbwdV"
    } ]
  },
  "geo" : { },
  "id_str" : "299930661161148416",
  "text" : "Historic snowfall? Pfft. http:\/\/t.co\/hCIiybKI",
  "id" : 299930661161148416,
  "created_at" : "2013-02-08 17:20:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "John",
      "screen_name" : "tuke",
      "indices" : [ 9, 14 ],
      "id_str" : "12960232",
      "id" : 12960232
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 15, 20 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299916425638842368",
  "geo" : { },
  "id_str" : "299916938132455425",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @tuke @r00k i'll bring the Timbits.",
  "id" : 299916938132455425,
  "in_reply_to_status_id" : 299916425638842368,
  "created_at" : "2013-02-08 16:25:44 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 0, 11 ],
      "id_str" : "14188391",
      "id" : 14188391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299903697377435650",
  "geo" : { },
  "id_str" : "299904696972353536",
  "in_reply_to_user_id" : 14188391,
  "text" : "@benjaminws huskies fly, or at least mine does. terrifyingly fast ;)",
  "id" : 299904696972353536,
  "in_reply_to_status_id" : 299903697377435650,
  "created_at" : "2013-02-08 15:37:06 +0000",
  "in_reply_to_screen_name" : "benjaminws",
  "in_reply_to_user_id_str" : "14188391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "steve corona",
      "screen_name" : "stevencorona",
      "indices" : [ 0, 13 ],
      "id_str" : "65739266",
      "id" : 65739266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299896917800939520",
  "geo" : { },
  "id_str" : "299898888284938241",
  "in_reply_to_user_id" : 65739266,
  "text" : "@stevencorona  i'm glad you made it out ok, but most don't. for the value the RIT coop program has provided me, it's sad to see it shit on.",
  "id" : 299898888284938241,
  "in_reply_to_status_id" : 299896917800939520,
  "created_at" : "2013-02-08 15:14:01 +0000",
  "in_reply_to_screen_name" : "stevencorona",
  "in_reply_to_user_id_str" : "65739266",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299898205208993792",
  "text" : "Never miss an opportunity to \/play horn.",
  "id" : 299898205208993792,
  "created_at" : "2013-02-08 15:11:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scheirman",
      "screen_name" : "subdigital",
      "indices" : [ 0, 11 ],
      "id_str" : "14133001",
      "id" : 14133001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299888852942848000",
  "geo" : { },
  "id_str" : "299896818068770816",
  "in_reply_to_user_id" : 14133001,
  "text" : "@subdigital yeah they've just been a pita to use with rubymotion, and it doesn't handle dependency resolution. :\/",
  "id" : 299896818068770816,
  "in_reply_to_status_id" : 299888852942848000,
  "created_at" : "2013-02-08 15:05:47 +0000",
  "in_reply_to_screen_name" : "subdigital",
  "in_reply_to_user_id_str" : "14133001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 0, 6 ],
      "id_str" : "35803",
      "id" : 35803
    }, {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 7, 19 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299887893504212992",
  "geo" : { },
  "id_str" : "299888501728616449",
  "in_reply_to_user_id" : 35803,
  "text" : "@mattt @SteveStreza +1. when do you think iOS\/Cocoa will move beyond \"all you need to do is drop *.\u007Bh,m\u007D into your project\" ?",
  "id" : 299888501728616449,
  "in_reply_to_status_id" : 299887893504212992,
  "created_at" : "2013-02-08 14:32:45 +0000",
  "in_reply_to_screen_name" : "mattt",
  "in_reply_to_user_id_str" : "35803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "indices" : [ 3, 15 ],
      "id_str" : "66666549",
      "id" : 66666549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299887692672536576",
  "text" : "RT @TweetsofOld: Storm coming. Get your coal. NY1900",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299887588234371072",
    "text" : "Storm coming. Get your coal. NY1900",
    "id" : 299887588234371072,
    "created_at" : "2013-02-08 14:29:07 +0000",
    "user" : {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "protected" : false,
      "id_str" : "66666549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488101282473721856\/ddsWSyyl_normal.jpeg",
      "id" : 66666549,
      "verified" : false
    }
  },
  "id" : 299887692672536576,
  "created_at" : "2013-02-08 14:29:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    }, {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/Dz7Z7Nkk",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=7HgXbXO5MI4",
      "display_url" : "youtube.com\/watch?v=7HgXbX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299886854801612800",
  "text" : "Yesterday's http:\/\/t.co\/t7WATcFT ops hangout is on YouTube if you want to watch it...transparency is awesome! http:\/\/t.co\/Dz7Z7Nkk",
  "id" : 299886854801612800,
  "created_at" : "2013-02-08 14:26:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Redpath",
      "screen_name" : "lukeredpath",
      "indices" : [ 0, 12 ],
      "id_str" : "72573",
      "id" : 72573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 64 ],
      "url" : "https:\/\/t.co\/NMTqPJYB",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/m\/?fromgroups#!searchin\/rubymotion\/Uiappearance\/rubymotion\/mMXB_X564TA",
      "display_url" : "groups.google.com\/forum\/m\/?fromg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "299874815710461952",
  "geo" : { },
  "id_str" : "299878849863368704",
  "in_reply_to_user_id" : 72573,
  "text" : "@lukeredpath I was talking about this API: https:\/\/t.co\/NMTqPJYB",
  "id" : 299878849863368704,
  "in_reply_to_status_id" : 299874815710461952,
  "created_at" : "2013-02-08 13:54:23 +0000",
  "in_reply_to_screen_name" : "lukeredpath",
  "in_reply_to_user_id_str" : "72573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Redpath",
      "screen_name" : "lukeredpath",
      "indices" : [ 0, 12 ],
      "id_str" : "72573",
      "id" : 72573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299874815710461952",
  "geo" : { },
  "id_str" : "299878358492278784",
  "in_reply_to_user_id" : 72573,
  "text" : "@lukeredpath haha, sure :) I try to avoid Xcode as much as possible. Has worked for 7 months now!",
  "id" : 299878358492278784,
  "in_reply_to_status_id" : 299874815710461952,
  "created_at" : "2013-02-08 13:52:26 +0000",
  "in_reply_to_screen_name" : "lukeredpath",
  "in_reply_to_user_id_str" : "72573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Redpath",
      "screen_name" : "lukeredpath",
      "indices" : [ 0, 12 ],
      "id_str" : "72573",
      "id" : 72573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299873072960389121",
  "geo" : { },
  "id_str" : "299873819739447296",
  "in_reply_to_user_id" : 72573,
  "text" : "@lukeredpath that API is really obtuse. Also doesn\u2019t always work right for navbar\/barbuttonitem :(",
  "id" : 299873819739447296,
  "in_reply_to_status_id" : 299873072960389121,
  "created_at" : "2013-02-08 13:34:24 +0000",
  "in_reply_to_screen_name" : "lukeredpath",
  "in_reply_to_user_id_str" : "72573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299675041837248512",
  "geo" : { },
  "id_str" : "299735633277108224",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella thanks man",
  "id" : 299735633277108224,
  "in_reply_to_status_id" : 299675041837248512,
  "created_at" : "2013-02-08 04:25:18 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/Dz7Z7Nkk",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=7HgXbXO5MI4",
      "display_url" : "youtube.com\/watch?v=7HgXbX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299662019823542272",
  "text" : "Refresh if you were watching the hangout. Sorry, my internets suck. http:\/\/t.co\/Dz7Z7Nkk",
  "id" : 299662019823542272,
  "created_at" : "2013-02-07 23:32:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/QvQlaYlq",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=7HgXbXO5MI4&feature=plcp",
      "display_url" : "youtube.com\/watch?v=7HgXbX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299655816053678081",
  "text" : "Talking about http:\/\/t.co\/bdjsRgTW ops\/infrastructure right...now! http:\/\/t.co\/QvQlaYlq",
  "id" : 299655816053678081,
  "created_at" : "2013-02-07 23:08:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hoskings",
      "screen_name" : "ben_h",
      "indices" : [ 0, 6 ],
      "id_str" : "8046732",
      "id" : 8046732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299635374760816640",
  "geo" : { },
  "id_str" : "299642366044807168",
  "in_reply_to_user_id" : 8046732,
  "text" : "@ben_h that is in 45 minutes.",
  "id" : 299642366044807168,
  "in_reply_to_status_id" : 299635374760816640,
  "created_at" : "2013-02-07 22:14:41 +0000",
  "in_reply_to_screen_name" : "ben_h",
  "in_reply_to_user_id_str" : "8046732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 53, 64 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/z22PZQI7",
      "expanded_url" : "http:\/\/2.bp.blogspot.com\/-Dr1aT2UQzPc\/URQPuatnMoI\/AAAAAAAAbv0\/PZ260P7RHKI\/s1600\/1.gif",
      "display_url" : "2.bp.blogspot.com\/-Dr1aT2UQzPc\/U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299642307009978373",
  "text" : "Just your normal Rake user: http:\/\/t.co\/z22PZQI7 \/cc @jimweirich",
  "id" : 299642307009978373,
  "created_at" : "2013-02-07 22:14:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "299632687747063808",
  "text" : "Reminder: http:\/\/t.co\/t7WATcFT ops\/infrastructure hangout will be at 6PM EST. Streaming link will be provided!",
  "id" : 299632687747063808,
  "created_at" : "2013-02-07 21:36:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Lavena",
      "screen_name" : "luislavena",
      "indices" : [ 0, 11 ],
      "id_str" : "16891327",
      "id" : 16891327
    }, {
      "name" : "follow @mattetti",
      "screen_name" : "merbist",
      "indices" : [ 12, 20 ],
      "id_str" : "1549117117",
      "id" : 1549117117
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 21, 29 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299496653717635072",
  "geo" : { },
  "id_str" : "299501640677986304",
  "in_reply_to_user_id" : 16891327,
  "text" : "@luislavena @merbist @drbrain I am not sure how to handle this. We could build aliases in for popular gems.",
  "id" : 299501640677986304,
  "in_reply_to_status_id" : 299496653717635072,
  "created_at" : "2013-02-07 12:55:30 +0000",
  "in_reply_to_screen_name" : "luislavena",
  "in_reply_to_user_id_str" : "16891327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/oENc44ZK",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=fgOaT4xzdvo",
      "display_url" : "youtube.com\/watch?v=fgOaT4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299308383985623040",
  "text" : "In case you don't want to sleep tonight: http:\/\/t.co\/oENc44ZK",
  "id" : 299308383985623040,
  "created_at" : "2013-02-07 00:07:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299273906265673728",
  "text" : "`gem push` has spoiled me on every other way of deployment.",
  "id" : 299273906265673728,
  "created_at" : "2013-02-06 21:50:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Mongeau",
      "screen_name" : "halogenandtoast",
      "indices" : [ 3, 19 ],
      "id_str" : "15428948",
      "id" : 15428948
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 25, 36 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 100 ],
      "url" : "https:\/\/t.co\/JuPATct9",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/fanboat\/id592162965?mt=8&ls=1",
      "display_url" : "itunes.apple.com\/us\/app\/fanboat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299272025279692801",
  "text" : "RT @halogenandtoast: The @RubyMotion app I wrote just hit the app store today. https:\/\/t.co\/JuPATct9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyMotion",
        "screen_name" : "RubyMotion",
        "indices" : [ 4, 15 ],
        "id_str" : "381521407",
        "id" : 381521407
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 79 ],
        "url" : "https:\/\/t.co\/JuPATct9",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/fanboat\/id592162965?mt=8&ls=1",
        "display_url" : "itunes.apple.com\/us\/app\/fanboat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "299271937681653760",
    "text" : "The @RubyMotion app I wrote just hit the app store today. https:\/\/t.co\/JuPATct9",
    "id" : 299271937681653760,
    "created_at" : "2013-02-06 21:42:44 +0000",
    "user" : {
      "name" : "Matthew Mongeau",
      "screen_name" : "halogenandtoast",
      "protected" : false,
      "id_str" : "15428948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/248851406\/Photo_2_normal.jpg",
      "id" : 15428948,
      "verified" : false
    }
  },
  "id" : 299272025279692801,
  "created_at" : "2013-02-06 21:43:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 0, 6 ],
      "id_str" : "1438261",
      "id" : 1438261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299269106618732545",
  "geo" : { },
  "id_str" : "299269343181668352",
  "in_reply_to_user_id" : 1438261,
  "text" : "@atmos we had to run the gauntlet lately too. not fun but pushes you to keep everything updated.",
  "id" : 299269343181668352,
  "in_reply_to_status_id" : 299269106618732545,
  "created_at" : "2013-02-06 21:32:26 +0000",
  "in_reply_to_screen_name" : "atmos",
  "in_reply_to_user_id_str" : "1438261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 0, 6 ],
      "id_str" : "1438261",
      "id" : 1438261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299268665130508288",
  "geo" : { },
  "id_str" : "299268845724647425",
  "in_reply_to_user_id" : 1438261,
  "text" : "@atmos wat?",
  "id" : 299268845724647425,
  "in_reply_to_status_id" : 299268665130508288,
  "created_at" : "2013-02-06 21:30:27 +0000",
  "in_reply_to_screen_name" : "atmos",
  "in_reply_to_user_id_str" : "1438261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alexrothenberg",
      "screen_name" : "alexrothenberg",
      "indices" : [ 0, 15 ],
      "id_str" : "17340043",
      "id" : 17340043
    }, {
      "name" : "Clay Allsopp",
      "screen_name" : "clayallsopp",
      "indices" : [ 16, 28 ],
      "id_str" : "48464282",
      "id" : 48464282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/cfLvADiH",
      "expanded_url" : "http:\/\/rubymotion-wrappers.com\/",
      "display_url" : "rubymotion-wrappers.com"
    } ]
  },
  "in_reply_to_status_id_str" : "299242102322253824",
  "geo" : { },
  "id_str" : "299265592618283009",
  "in_reply_to_user_id" : 17340043,
  "text" : "@alexrothenberg @clayallsopp the http:\/\/t.co\/cfLvADiH link is broken at the bottom",
  "id" : 299265592618283009,
  "in_reply_to_status_id" : 299242102322253824,
  "created_at" : "2013-02-06 21:17:32 +0000",
  "in_reply_to_screen_name" : "alexrothenberg",
  "in_reply_to_user_id_str" : "17340043",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 12, 20 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299252836200505344",
  "geo" : { },
  "id_str" : "299253073409359873",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @fending I didn't have one, you evil bastard.",
  "id" : 299253073409359873,
  "in_reply_to_status_id" : 299252836200505344,
  "created_at" : "2013-02-06 20:27:47 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299248010284646401",
  "geo" : { },
  "id_str" : "299249403523366912",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv oh without a doubt. some of these are hilarious though. i wonder if people know these are posted.",
  "id" : 299249403523366912,
  "in_reply_to_status_id" : 299248010284646401,
  "created_at" : "2013-02-06 20:13:12 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 99 ],
      "url" : "https:\/\/t.co\/VixUpIDZ",
      "expanded_url" : "https:\/\/iamexec.com\/feed",
      "display_url" : "iamexec.com\/feed"
    } ]
  },
  "geo" : { },
  "id_str" : "299247066192957441",
  "text" : "Stunned by what people will pay Exec to do, and that they show this publicly: https:\/\/t.co\/VixUpIDZ",
  "id" : 299247066192957441,
  "created_at" : "2013-02-06 20:03:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 3, 15 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299244913076363264",
  "text" : "RT @alanstevens: Anyone have a lead on a Rails gig? I need a break from yelling at Visual Studio. Please.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299244837817946112",
    "text" : "Anyone have a lead on a Rails gig? I need a break from yelling at Visual Studio. Please.",
    "id" : 299244837817946112,
    "created_at" : "2013-02-06 19:55:03 +0000",
    "user" : {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "protected" : false,
      "id_str" : "9700652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571783104387530753\/1gEyur2X_normal.jpeg",
      "id" : 9700652,
      "verified" : false
    }
  },
  "id" : 299244913076363264,
  "created_at" : "2013-02-06 19:55:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Cade",
      "screen_name" : "cadeparade",
      "indices" : [ 0, 11 ],
      "id_str" : "426455861",
      "id" : 426455861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299235107569557505",
  "geo" : { },
  "id_str" : "299235198715953152",
  "in_reply_to_user_id" : 426455861,
  "text" : "@cadeparade this kind of learning never ends",
  "id" : 299235198715953152,
  "in_reply_to_status_id" : 299235107569557505,
  "created_at" : "2013-02-06 19:16:45 +0000",
  "in_reply_to_screen_name" : "cadeparade",
  "in_reply_to_user_id_str" : "426455861",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Graves",
      "screen_name" : "aarongraves",
      "indices" : [ 0, 12 ],
      "id_str" : "24400574",
      "id" : 24400574
    }, {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 13, 22 ],
      "id_str" : "57753",
      "id" : 57753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299230932500623360",
  "in_reply_to_user_id" : 24400574,
  "text" : "@aarongraves @blowmage that being said, it's very much a beta\/1.0. Now that it's OSS, if the community cares, they can fix it.",
  "id" : 299230932500623360,
  "created_at" : "2013-02-06 18:59:48 +0000",
  "in_reply_to_screen_name" : "aarongraves",
  "in_reply_to_user_id_str" : "24400574",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Graves",
      "screen_name" : "aarongraves",
      "indices" : [ 0, 12 ],
      "id_str" : "24400574",
      "id" : 24400574
    }, {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 13, 22 ],
      "id_str" : "57753",
      "id" : 57753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 87 ],
      "url" : "https:\/\/t.co\/3zFD7ybh",
      "expanded_url" : "https:\/\/github.com\/discourse\/discourse\/blob\/master\/app\/models\/user_action.rb",
      "display_url" : "github.com\/discourse\/disc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "299225888338370560",
  "geo" : { },
  "id_str" : "299230699846778881",
  "in_reply_to_user_id" : 24400574,
  "text" : "@aarongraves @blowmage there's a lot of terrifying code in there. https:\/\/t.co\/3zFD7ybh",
  "id" : 299230699846778881,
  "in_reply_to_status_id" : 299225888338370560,
  "created_at" : "2013-02-06 18:58:52 +0000",
  "in_reply_to_screen_name" : "aarongraves",
  "in_reply_to_user_id_str" : "24400574",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/DA4Ljtbk",
      "expanded_url" : "http:\/\/thingsfittingperfectlyintothings.tumblr.com\/",
      "display_url" : "\u2026fittingperfectlyintothings.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "299219037798400000",
  "text" : "\"Things fitting perfectly into other things\" http:\/\/t.co\/DA4Ljtbk",
  "id" : 299219037798400000,
  "created_at" : "2013-02-06 18:12:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299199237596536832",
  "geo" : { },
  "id_str" : "299201028128133121",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 this is a huge reason i have still not given any money to kickstarter projects.",
  "id" : 299201028128133121,
  "in_reply_to_status_id" : 299199237596536832,
  "created_at" : "2013-02-06 17:00:58 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 13, 23 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 24, 35 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/WAXMASW5",
      "expanded_url" : "http:\/\/gitready.com\/",
      "display_url" : "gitready.com"
    } ]
  },
  "in_reply_to_status_id_str" : "299186688205398017",
  "geo" : { },
  "id_str" : "299187730636750848",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench @aquaranto @Jonplussed awesome. lots of helpful stuff here ;) http:\/\/t.co\/WAXMASW5",
  "id" : 299187730636750848,
  "in_reply_to_status_id" : 299186688205398017,
  "created_at" : "2013-02-06 16:08:08 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 27, 37 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299185800258650113",
  "geo" : { },
  "id_str" : "299186167784546304",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench Fuck yes! \/cc @aquaranto",
  "id" : 299186167784546304,
  "in_reply_to_status_id" : 299185800258650113,
  "created_at" : "2013-02-06 16:01:55 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/EHjUhvxj",
      "expanded_url" : "http:\/\/37svn.com\/3421",
      "display_url" : "37svn.com\/3421"
    } ]
  },
  "geo" : { },
  "id_str" : "299183873248591872",
  "text" : "Anyone who uses, writes, or even has heard of open source should watch this video: http:\/\/t.co\/EHjUhvxj",
  "id" : 299183873248591872,
  "created_at" : "2013-02-06 15:52:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299182338695385088",
  "geo" : { },
  "id_str" : "299182589909024768",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale I'm really not interested in this comparison, you've already beat it into the ground. Focus on positives if you want Ember to win.",
  "id" : 299182589909024768,
  "in_reply_to_status_id" : 299182338695385088,
  "created_at" : "2013-02-06 15:47:42 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Lash",
      "screen_name" : "danlash",
      "indices" : [ 0, 8 ],
      "id_str" : "14729552",
      "id" : 14729552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299179927113170944",
  "geo" : { },
  "id_str" : "299180453238280192",
  "in_reply_to_user_id" : 14729552,
  "text" : "@danlash I really hate these kinds of posts. Also \"art of manliness\" ffs.",
  "id" : 299180453238280192,
  "in_reply_to_status_id" : 299179927113170944,
  "created_at" : "2013-02-06 15:39:13 +0000",
  "in_reply_to_screen_name" : "danlash",
  "in_reply_to_user_id_str" : "14729552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299178954147901441",
  "geo" : { },
  "id_str" : "299179826240176129",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale if we were having beers right now the conversation wouldn't sound this mean, at least in my head. :(",
  "id" : 299179826240176129,
  "in_reply_to_status_id" : 299178954147901441,
  "created_at" : "2013-02-06 15:36:43 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    }, {
      "name" : "Make Millions",
      "screen_name" : "evil_trout",
      "indices" : [ 9, 20 ],
      "id_str" : "2494449480",
      "id" : 2494449480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299174931252531201",
  "geo" : { },
  "id_str" : "299175701590986754",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale @evil_trout I see that you're trying to set up the \"Ember\" stack as the antihero here though. Fight on brother! :)",
  "id" : 299175701590986754,
  "in_reply_to_status_id" : 299174931252531201,
  "created_at" : "2013-02-06 15:20:20 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    }, {
      "name" : "Make Millions",
      "screen_name" : "evil_trout",
      "indices" : [ 9, 20 ],
      "id_str" : "2494449480",
      "id" : 2494449480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299174931252531201",
  "geo" : { },
  "id_str" : "299175463539068928",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale @evil_trout but the problem domains are not the same, doesn't seem fair to compare. maybe if both were productivity\/PM apps.",
  "id" : 299175463539068928,
  "in_reply_to_status_id" : 299174931252531201,
  "created_at" : "2013-02-06 15:19:23 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/edRq59bf",
      "expanded_url" : "http:\/\/butthug.com\/post\/42416198426\/koopalings",
      "display_url" : "butthug.com\/post\/424161984\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299172952610570240",
  "text" : "I always loved the Koopalings. Now they're in awesome GIF form. http:\/\/t.co\/edRq59bf",
  "id" : 299172952610570240,
  "created_at" : "2013-02-06 15:09:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    }, {
      "name" : "Make Millions",
      "screen_name" : "evil_trout",
      "indices" : [ 9, 20 ],
      "id_str" : "2494449480",
      "id" : 2494449480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299053147232538624",
  "geo" : { },
  "id_str" : "299167779083390978",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale @evil_trout I don\u2019t see how the Basecamp comparison makes sense. The domains are completely different.",
  "id" : 299167779083390978,
  "in_reply_to_status_id" : 299053147232538624,
  "created_at" : "2013-02-06 14:48:51 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/299025374568935424\/photo\/1",
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/djqqKz7q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCZZ_m6CcAABcFE.jpg",
      "id_str" : "299025374577324032",
      "id" : 299025374577324032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCZZ_m6CcAABcFE.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/djqqKz7q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299025374568935424",
  "text" : "I want to go to sleep but Ged is doing a better job of it on my feet. http:\/\/t.co\/djqqKz7q",
  "id" : 299025374568935424,
  "created_at" : "2013-02-06 05:22:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Dahlby",
      "screen_name" : "dahlbyk",
      "indices" : [ 0, 8 ],
      "id_str" : "16943737",
      "id" : 16943737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/bMAebWz0",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2008\/09\/18\/switching-to-rails\/",
      "display_url" : "quaran.to\/blog\/2008\/09\/1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "299018078845542400",
  "geo" : { },
  "id_str" : "299025005512114177",
  "in_reply_to_user_id" : 16943737,
  "text" : "@dahlbyk Not saying that is an indicator, but I felt extremely similar while I was using .NET, from 2008: http:\/\/t.co\/bMAebWz0",
  "id" : 299025005512114177,
  "in_reply_to_status_id" : 299018078845542400,
  "created_at" : "2013-02-06 05:21:31 +0000",
  "in_reply_to_screen_name" : "dahlbyk",
  "in_reply_to_user_id_str" : "16943737",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Dahlby",
      "screen_name" : "dahlbyk",
      "indices" : [ 0, 8 ],
      "id_str" : "16943737",
      "id" : 16943737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299018078845542400",
  "geo" : { },
  "id_str" : "299024651106017281",
  "in_reply_to_user_id" : 16943737,
  "text" : "@dahlbyk have you worked outside of .NET in any orgs that use mainly open source based tools?",
  "id" : 299024651106017281,
  "in_reply_to_status_id" : 299018078845542400,
  "created_at" : "2013-02-06 05:20:07 +0000",
  "in_reply_to_screen_name" : "dahlbyk",
  "in_reply_to_user_id_str" : "16943737",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 56, 65 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/YnwItS4R",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Xe1TZaElTAs",
      "display_url" : "youtube.com\/watch?v=Xe1TZa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299024425397932032",
  "text" : "Love makes open source work.  http:\/\/t.co\/YnwItS4R (via @tbranyen)",
  "id" : 299024425397932032,
  "created_at" : "2013-02-06 05:19:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Dahlby",
      "screen_name" : "dahlbyk",
      "indices" : [ 0, 8 ],
      "id_str" : "16943737",
      "id" : 16943737
    }, {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 9, 22 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299014083104083969",
  "geo" : { },
  "id_str" : "299014822945751040",
  "in_reply_to_user_id" : 16943737,
  "text" : "@dahlbyk @ferventcoder yep. Avoid or push people like that. Don\u2019t settle.",
  "id" : 299014822945751040,
  "in_reply_to_status_id" : 299014083104083969,
  "created_at" : "2013-02-06 04:41:03 +0000",
  "in_reply_to_screen_name" : "dahlbyk",
  "in_reply_to_user_id_str" : "16943737",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Dahlby",
      "screen_name" : "dahlbyk",
      "indices" : [ 0, 8 ],
      "id_str" : "16943737",
      "id" : 16943737
    }, {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 9, 22 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299011617646063616",
  "geo" : { },
  "id_str" : "299012742680035328",
  "in_reply_to_user_id" : 16943737,
  "text" : "@dahlbyk @ferventcoder why is this \u201Cimagine\u201D ?",
  "id" : 299012742680035328,
  "in_reply_to_status_id" : 299011617646063616,
  "created_at" : "2013-02-06 04:32:47 +0000",
  "in_reply_to_screen_name" : "dahlbyk",
  "in_reply_to_user_id_str" : "16943737",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298996746648948737",
  "text" : "Pretty sure I just assigned my wife todos on a github issue. I bet your night can't get more exciting than this.",
  "id" : 298996746648948737,
  "created_at" : "2013-02-06 03:29:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    }, {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 14, 17 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298982346751877121",
  "geo" : { },
  "id_str" : "298982605863415809",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie @jm Lame. i can just do `git log --oneline | wc -l` :\/",
  "id" : 298982605863415809,
  "in_reply_to_status_id" : 298982346751877121,
  "created_at" : "2013-02-06 02:33:02 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    }, {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 101, 104 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298975812663783424",
  "geo" : { },
  "id_str" : "298982134444593152",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie why is it even in the API then? i'm looking for \"number of commits in this branch\" \/cc @jm",
  "id" : 298982134444593152,
  "in_reply_to_status_id" : 298975812663783424,
  "created_at" : "2013-02-06 02:31:10 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 73 ],
      "url" : "https:\/\/t.co\/y4WJKgWZ",
      "expanded_url" : "https:\/\/github.com\/discourse\/discourse\/pull\/3",
      "display_url" : "github.com\/discourse\/disc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298981022517821442",
  "text" : "Sweet! First pull request merged into discourse! :D https:\/\/t.co\/y4WJKgWZ",
  "id" : 298981022517821442,
  "created_at" : "2013-02-06 02:26:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 4, 17 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/vxKg49O9",
      "expanded_url" : "http:\/\/developer.github.com\/v3\/repos",
      "display_url" : "developer.github.com\/v3\/repos"
    } ]
  },
  "geo" : { },
  "id_str" : "298973425031061504",
  "text" : "hey @technoweenie or other github people, what is \"size\" on a repo? http:\/\/t.co\/vxKg49O9",
  "id" : 298973425031061504,
  "created_at" : "2013-02-06 01:56:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298973121233436672",
  "text" : "Octokit and the v3 GitHub API feel really complicated and are being extremely difficult for me right now :\/",
  "id" : 298973121233436672,
  "created_at" : "2013-02-06 01:55:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Bates",
      "screen_name" : "markbates",
      "indices" : [ 0, 10 ],
      "id_str" : "17388421",
      "id" : 17388421
    }, {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 11, 18 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298955764255584256",
  "geo" : { },
  "id_str" : "298962061881397248",
  "in_reply_to_user_id" : 17388421,
  "text" : "@markbates @jayroh yeah, i got the sarcasm. just noting i have never found it helpful to say this to anyone.",
  "id" : 298962061881397248,
  "in_reply_to_status_id" : 298955764255584256,
  "created_at" : "2013-02-06 01:11:24 +0000",
  "in_reply_to_screen_name" : "markbates",
  "in_reply_to_user_id_str" : "17388421",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Mark Bates",
      "screen_name" : "markbates",
      "indices" : [ 13, 23 ],
      "id_str" : "17388421",
      "id" : 17388421
    }, {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 24, 31 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298957086203707393",
  "geo" : { },
  "id_str" : "298961919686111232",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @markbates @jayroh lmao if you live in a non-major tech city and make an influence on the tech world",
  "id" : 298961919686111232,
  "in_reply_to_status_id" : 298957086203707393,
  "created_at" : "2013-02-06 01:10:50 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298952670855720961",
  "geo" : { },
  "id_str" : "298953312957521921",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh people who aren't developers?",
  "id" : 298953312957521921,
  "in_reply_to_status_id" : 298952670855720961,
  "created_at" : "2013-02-06 00:36:38 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Bates",
      "screen_name" : "markbates",
      "indices" : [ 0, 10 ],
      "id_str" : "17388421",
      "id" : 17388421
    }, {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 11, 18 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298938819334533120",
  "geo" : { },
  "id_str" : "298952250397712386",
  "in_reply_to_user_id" : 17388421,
  "text" : "@markbates @jayroh i've learned this is douchey to say to people who are unemployed and struggling. learning programming is not easy.",
  "id" : 298952250397712386,
  "in_reply_to_status_id" : 298938819334533120,
  "created_at" : "2013-02-06 00:32:25 +0000",
  "in_reply_to_screen_name" : "markbates",
  "in_reply_to_user_id_str" : "17388421",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 81, 90 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/dBxP29F1",
      "expanded_url" : "http:\/\/openhack.discourse.org",
      "display_url" : "openhack.discourse.org"
    } ]
  },
  "geo" : { },
  "id_str" : "298944553044570112",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror hey, I'd love to get http:\/\/t.co\/dBxP29F1 to help organize\/discuss @OpenHack events globally...could we get some love?",
  "id" : 298944553044570112,
  "created_at" : "2013-02-06 00:01:50 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/VxtOLKTX",
      "expanded_url" : "http:\/\/www.wivb.com\/dpp\/news\/crime\/cops-arrest-man-dressed-as-joker",
      "display_url" : "wivb.com\/dpp\/news\/crime\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298929149219856385",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan http:\/\/t.co\/VxtOLKTX",
  "id" : 298929149219856385,
  "created_at" : "2013-02-05 23:00:37 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298913370646642689",
  "geo" : { },
  "id_str" : "298913613568151552",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror there should be an achievement for this.",
  "id" : 298913613568151552,
  "in_reply_to_status_id" : 298913370646642689,
  "created_at" : "2013-02-05 21:58:53 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Delmont",
      "screen_name" : "sd",
      "indices" : [ 0, 3 ],
      "id_str" : "755241",
      "id" : 755241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298908809378816000",
  "geo" : { },
  "id_str" : "298909028686376961",
  "in_reply_to_user_id" : 755241,
  "text" : "@sd I hope that's the business they're getting into.",
  "id" : 298909028686376961,
  "in_reply_to_status_id" : 298908809378816000,
  "created_at" : "2013-02-05 21:40:40 +0000",
  "in_reply_to_screen_name" : "sd",
  "in_reply_to_user_id_str" : "755241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Delmont",
      "screen_name" : "sd",
      "indices" : [ 0, 3 ],
      "id_str" : "755241",
      "id" : 755241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298906840610254851",
  "geo" : { },
  "id_str" : "298907950985121792",
  "in_reply_to_user_id" : 755241,
  "text" : "@sd I bet an installer like GitHub Enterprise's can help with that.",
  "id" : 298907950985121792,
  "in_reply_to_status_id" : 298906840610254851,
  "created_at" : "2013-02-05 21:36:23 +0000",
  "in_reply_to_screen_name" : "sd",
  "in_reply_to_user_id_str" : "755241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/DytONfHp",
      "expanded_url" : "http:\/\/try.discourse.org\/t\/super-glad-this-is-built-in-ruby-and-its-open-source-\/466",
      "display_url" : "try.discourse.org\/t\/super-glad-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298897354143182848",
  "text" : "I hope to see Discourse destroy other forum software. It happened with StackOverflow. It's time now. http:\/\/t.co\/DytONfHp",
  "id" : 298897354143182848,
  "created_at" : "2013-02-05 20:54:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 62 ],
      "url" : "https:\/\/t.co\/XhkIO80S",
      "expanded_url" : "https:\/\/github.com\/discourse\/core\/pull\/3",
      "display_url" : "github.com\/discourse\/core\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298891002004008961",
  "text" : "Just submitted a quick PR for Discourse: https:\/\/t.co\/XhkIO80S Excited to see where this goes and very happy it's on Rails.",
  "id" : 298891002004008961,
  "created_at" : "2013-02-05 20:29:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/AeODtl3M",
      "expanded_url" : "http:\/\/Rubygems.org",
      "display_url" : "Rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "298858077858459649",
  "text" : "Had to bump the http:\/\/t.co\/AeODtl3M ops discussion to Thursday at 6PM EST! Sorry everyone.",
  "id" : 298858077858459649,
  "created_at" : "2013-02-05 18:18:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298855992450510848",
  "geo" : { },
  "id_str" : "298856503467708416",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn Chemex.",
  "id" : 298856503467708416,
  "in_reply_to_status_id" : 298855992450510848,
  "created_at" : "2013-02-05 18:11:57 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/EhnAAFcN",
      "expanded_url" : "http:\/\/vine.co\/v\/bnqTqhPpw0q",
      "display_url" : "vine.co\/v\/bnqTqhPpw0q"
    } ]
  },
  "geo" : { },
  "id_str" : "298853683226103808",
  "text" : "It's \u2615 time. http:\/\/t.co\/EhnAAFcN",
  "id" : 298853683226103808,
  "created_at" : "2013-02-05 18:00:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 88, 97 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "BfloFRED",
      "screen_name" : "BfloFRED",
      "indices" : [ 139, 140 ],
      "id_str" : "876930312",
      "id" : 876930312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298845564035010561",
  "text" : "RT @coworkbuffalo: 8 events planned so far for Feb in our space: Buffalo Learn to Code, @openhack, Cracking the Code, Open Philosophy, @ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 69, 78 ],
        "id_str" : "715440464",
        "id" : 715440464
      }, {
        "name" : "BfloFRED",
        "screen_name" : "BfloFRED",
        "indices" : [ 116, 125 ],
        "id_str" : "876930312",
        "id" : 876930312
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298845513422356480",
    "text" : "8 events planned so far for Feb in our space: Buffalo Learn to Code, @openhack, Cracking the Code, Open Philosophy, @BfloFRED, Perl Mongers!",
    "id" : 298845513422356480,
    "created_at" : "2013-02-05 17:28:17 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 298845564035010561,
  "created_at" : "2013-02-05 17:28:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298829332489580544",
  "geo" : { },
  "id_str" : "298843060920545280",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k (regarding testing constants, not polling)",
  "id" : 298843060920545280,
  "in_reply_to_status_id" : 298829332489580544,
  "created_at" : "2013-02-05 17:18:32 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298829332489580544",
  "geo" : { },
  "id_str" : "298842999746617344",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k there have to be more fun ways to waste your time :)",
  "id" : 298842999746617344,
  "in_reply_to_status_id" : 298829332489580544,
  "created_at" : "2013-02-05 17:18:18 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    }, {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/1rpBXFDw",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=z73uiWKdJhw",
      "display_url" : "youtube.com\/watch?v=z73uiW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298833728959025152",
  "text" : "We're going to have a http:\/\/t.co\/t7WATcFT ops G+ hangout at 4PM EST. It will be recorded too like http:\/\/t.co\/1rpBXFDw",
  "id" : 298833728959025152,
  "created_at" : "2013-02-05 16:41:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298822363364073472",
  "geo" : { },
  "id_str" : "298827596186124288",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k you must be joking.",
  "id" : 298827596186124288,
  "in_reply_to_status_id" : 298822363364073472,
  "created_at" : "2013-02-05 16:17:05 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 29, 38 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298804921854210048",
  "text" : "Very excited to see multiple @OpenHack events running every week. It\u2019s working, I think!",
  "id" : 298804921854210048,
  "created_at" : "2013-02-05 14:46:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 3, 12 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 71, 85 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/yarGWXHh",
      "expanded_url" : "http:\/\/openhack.github.com\/buffalo",
      "display_url" : "openhack.github.com\/buffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "298804631306399744",
  "text" : "RT @openhack: OpenHack Buffalo is tonight! Starting earlier: 6:30PM at @coworkbuffalo. http:\/\/t.co\/yarGWXHh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 57, 71 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/yarGWXHh",
        "expanded_url" : "http:\/\/openhack.github.com\/buffalo",
        "display_url" : "openhack.github.com\/buffalo"
      } ]
    },
    "geo" : { },
    "id_str" : "298804565971714048",
    "text" : "OpenHack Buffalo is tonight! Starting earlier: 6:30PM at @coworkbuffalo. http:\/\/t.co\/yarGWXHh",
    "id" : 298804565971714048,
    "created_at" : "2013-02-05 14:45:34 +0000",
    "user" : {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "protected" : false,
      "id_str" : "715440464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2820837518\/4b1be1b9600913604bed891a097a141e_normal.png",
      "id" : 715440464,
      "verified" : false
    }
  },
  "id" : 298804631306399744,
  "created_at" : "2013-02-05 14:45:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Fuchs",
      "screen_name" : "thomasfuchs",
      "indices" : [ 3, 15 ],
      "id_str" : "6927562",
      "id" : 6927562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298803078990270465",
  "text" : "RT @thomasfuchs: It\u2019s time to take your petty programming bullshit less seriously and start building delightful apps to make people happier.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298791948309913601",
    "text" : "It\u2019s time to take your petty programming bullshit less seriously and start building delightful apps to make people happier.",
    "id" : 298791948309913601,
    "created_at" : "2013-02-05 13:55:26 +0000",
    "user" : {
      "name" : "Thomas Fuchs",
      "screen_name" : "thomasfuchs",
      "protected" : false,
      "id_str" : "6927562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528509543119343616\/bDhQei1L_normal.jpeg",
      "id" : 6927562,
      "verified" : false
    }
  },
  "id" : 298803078990270465,
  "created_at" : "2013-02-05 14:39:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    }, {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 13, 20 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298510610226872320",
  "geo" : { },
  "id_str" : "298690137238413312",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger @soffes oh duh, yes :) BubbleWrap has a great way to include external gem code too.",
  "id" : 298690137238413312,
  "in_reply_to_status_id" : 298510610226872320,
  "created_at" : "2013-02-05 07:10:52 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Hipster Hacker",
      "screen_name" : "hipsterhacker",
      "indices" : [ 39, 53 ],
      "id_str" : "261546340",
      "id" : 261546340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298672706671480832",
  "geo" : { },
  "id_str" : "298673396756144128",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents realized I'm channeling @hipsterhacker with that latest one.",
  "id" : 298673396756144128,
  "in_reply_to_status_id" : 298672706671480832,
  "created_at" : "2013-02-05 06:04:21 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Andy Maleh",
      "screen_name" : "AndyMaleh",
      "indices" : [ 6, 16 ],
      "id_str" : "16437273",
      "id" : 16437273
    }, {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 17, 28 ],
      "id_str" : "2355631",
      "id" : 2355631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298655773284790272",
  "geo" : { },
  "id_str" : "298656621851193345",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi @AndyMaleh @lmarburger that term makes this rubyist gak up his latest meal a little",
  "id" : 298656621851193345,
  "in_reply_to_status_id" : 298655773284790272,
  "created_at" : "2013-02-05 04:57:42 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 0, 6 ],
      "id_str" : "24425454",
      "id" : 24425454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298650500121911297",
  "geo" : { },
  "id_str" : "298650843463446529",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgmnz it's always fun to see the complex\/simple reaction waves of software...so obvious here.",
  "id" : 298650843463446529,
  "in_reply_to_status_id" : 298650500121911297,
  "created_at" : "2013-02-05 04:34:44 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 0, 6 ],
      "id_str" : "24425454",
      "id" : 24425454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 59 ],
      "url" : "https:\/\/t.co\/FH09AS0v",
      "expanded_url" : "https:\/\/github.com\/sstephenson\/eco",
      "display_url" : "github.com\/sstephenson\/eco"
    } ]
  },
  "in_reply_to_status_id_str" : "298649662246772736",
  "geo" : { },
  "id_str" : "298650328960745472",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgmnz Seriously. Have you tried eco? https:\/\/t.co\/FH09AS0v",
  "id" : 298650328960745472,
  "in_reply_to_status_id" : 298649662246772736,
  "created_at" : "2013-02-05 04:32:41 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Penn",
      "screen_name" : "jonathanpenn",
      "indices" : [ 0, 13 ],
      "id_str" : "9896112",
      "id" : 9896112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298649476975955968",
  "geo" : { },
  "id_str" : "298649565983289344",
  "in_reply_to_user_id" : 9896112,
  "text" : "@jonathanpenn Here Hadoop! Come!",
  "id" : 298649565983289344,
  "in_reply_to_status_id" : 298649476975955968,
  "created_at" : "2013-02-05 04:29:39 +0000",
  "in_reply_to_screen_name" : "jonathanpenn",
  "in_reply_to_user_id_str" : "9896112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Penn",
      "screen_name" : "jonathanpenn",
      "indices" : [ 0, 13 ],
      "id_str" : "9896112",
      "id" : 9896112
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/298649269718622208\/photo\/1",
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/kr6p46M9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCUD7bJCIAAFTxx.jpg",
      "id_str" : "298649269722816512",
      "id" : 298649269722816512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCUD7bJCIAAFTxx.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/kr6p46M9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298647133131788290",
  "geo" : { },
  "id_str" : "298649269718622208",
  "in_reply_to_user_id" : 9896112,
  "text" : "@jonathanpenn Agreed. http:\/\/t.co\/kr6p46M9",
  "id" : 298649269718622208,
  "in_reply_to_status_id" : 298647133131788290,
  "created_at" : "2013-02-05 04:28:29 +0000",
  "in_reply_to_screen_name" : "jonathanpenn",
  "in_reply_to_user_id_str" : "9896112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298607924543119360",
  "geo" : { },
  "id_str" : "298609410111066113",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule I mean, I guess GPGTools made it stupid easy, it just feels like a lot.",
  "id" : 298609410111066113,
  "in_reply_to_status_id" : 298607924543119360,
  "created_at" : "2013-02-05 01:50:05 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298606874578800640",
  "text" : "Reading about PGP and it feels extremely, overly complicated. Stuff like this is what I don't like about computing.",
  "id" : 298606874578800640,
  "created_at" : "2013-02-05 01:40:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 35, 46 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/Agmda8RH",
      "expanded_url" : "http:\/\/ilikegiving.com\/story\/i-like-adoption",
      "display_url" : "ilikegiving.com\/story\/i-like-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298601682718302208",
  "text" : "Floored. http:\/\/t.co\/Agmda8RH (via @phillapier)",
  "id" : 298601682718302208,
  "created_at" : "2013-02-05 01:19:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morten Primdahl",
      "screen_name" : "primdahl",
      "indices" : [ 0, 9 ],
      "id_str" : "14853852",
      "id" : 14853852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298559827716734977",
  "geo" : { },
  "id_str" : "298564180884201472",
  "in_reply_to_user_id" : 14853852,
  "text" : "@primdahl folks have been kicking ass on it. very happy the community is now invested in the infrastructure.",
  "id" : 298564180884201472,
  "in_reply_to_status_id" : 298559827716734977,
  "created_at" : "2013-02-04 22:50:22 +0000",
  "in_reply_to_screen_name" : "primdahl",
  "in_reply_to_user_id_str" : "14853852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    }, {
      "name" : "Coby Chapple",
      "screen_name" : "cobyism",
      "indices" : [ 14, 22 ],
      "id_str" : "15966431",
      "id" : 15966431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298540724377493504",
  "geo" : { },
  "id_str" : "298555949810065409",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie @cobyism thanks, using ScreenFlow + GIFBrewery and this shit is awesome.",
  "id" : 298555949810065409,
  "in_reply_to_status_id" : 298540724377493504,
  "created_at" : "2013-02-04 22:17:39 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298542510131781632",
  "geo" : { },
  "id_str" : "298543703864250370",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 it's listed as 12am... it sounds reasonable.",
  "id" : 298543703864250370,
  "in_reply_to_status_id" : 298542510131781632,
  "created_at" : "2013-02-04 21:29:00 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rich rines",
      "screen_name" : "richrines",
      "indices" : [ 0, 10 ],
      "id_str" : "123329223",
      "id" : 123329223
    }, {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 11, 18 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298507256755011585",
  "geo" : { },
  "id_str" : "298541622117949441",
  "in_reply_to_user_id" : 123329223,
  "text" : "@richrines @soffes I've been using it for 7 months and have been loving it. I wouldn't have picked up iOS without it.",
  "id" : 298541622117949441,
  "in_reply_to_status_id" : 298507256755011585,
  "created_at" : "2013-02-04 21:20:44 +0000",
  "in_reply_to_screen_name" : "richrines",
  "in_reply_to_user_id_str" : "123329223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298506693229301760",
  "geo" : { },
  "id_str" : "298541477112471553",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes I haven't needed too many, but I have dumped at least one into lib\/. This process needs to be fixed, and it's kind of unacceptable.",
  "id" : 298541477112471553,
  "in_reply_to_status_id" : 298506693229301760,
  "created_at" : "2013-02-04 21:20:09 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coby Chapple",
      "screen_name" : "cobyism",
      "indices" : [ 70, 78 ],
      "id_str" : "15966431",
      "id" : 15966431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298540228736602112",
  "text" : "Anyone know what GitHub uses to create gifs for their blog posts? \/cc @cobyism",
  "id" : 298540228736602112,
  "created_at" : "2013-02-04 21:15:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 8, 19 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298505851763834880",
  "geo" : { },
  "id_str" : "298506408763211776",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes @RubyMotion YES!",
  "id" : 298506408763211776,
  "in_reply_to_status_id" : 298505851763834880,
  "created_at" : "2013-02-04 19:00:48 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan L. Walls",
      "screen_name" : "base10",
      "indices" : [ 0, 7 ],
      "id_str" : "1888981",
      "id" : 1888981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298498080309927937",
  "geo" : { },
  "id_str" : "298498744096268288",
  "in_reply_to_user_id" : 1888981,
  "text" : "@base10 have taken BOS &lt;=&gt; NYC and Montreal =&gt; Quebec City. Love trains. Time to try an overnight trip!",
  "id" : 298498744096268288,
  "in_reply_to_status_id" : 298498080309927937,
  "created_at" : "2013-02-04 18:30:21 +0000",
  "in_reply_to_screen_name" : "base10",
  "in_reply_to_user_id_str" : "1888981",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298491857380442112",
  "geo" : { },
  "id_str" : "298492402644185088",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn yeah, it's direct.",
  "id" : 298492402644185088,
  "in_reply_to_status_id" : 298491857380442112,
  "created_at" : "2013-02-04 18:05:09 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amtrak",
      "screen_name" : "Amtrak",
      "indices" : [ 3, 10 ],
      "id_str" : "119166791",
      "id" : 119166791
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 12, 18 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/pDnheTYg",
      "expanded_url" : "http:\/\/ow.ly\/hpf8i",
      "display_url" : "ow.ly\/hpf8i"
    } ]
  },
  "geo" : { },
  "id_str" : "298490475730579456",
  "text" : "RT @Amtrak: @qrush We vote train! It's always good to try something different. Visit our Lake Shore Limited page (the route to CHI) http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/pDnheTYg",
        "expanded_url" : "http:\/\/ow.ly\/hpf8i",
        "display_url" : "ow.ly\/hpf8i"
      } ]
    },
    "in_reply_to_status_id_str" : "298488195534970880",
    "geo" : { },
    "id_str" : "298489864909889536",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush We vote train! It's always good to try something different. Visit our Lake Shore Limited page (the route to CHI) http:\/\/t.co\/pDnheTYg",
    "id" : 298489864909889536,
    "in_reply_to_status_id" : 298488195534970880,
    "created_at" : "2013-02-04 17:55:04 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Amtrak",
      "screen_name" : "Amtrak",
      "protected" : false,
      "id_str" : "119166791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460870025516048384\/qb-Dz6jD_normal.jpeg",
      "id" : 119166791,
      "verified" : true
    }
  },
  "id" : 298490475730579456,
  "created_at" : "2013-02-04 17:57:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298488745089433602",
  "geo" : { },
  "id_str" : "298489037545697281",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik 10h, 30m.",
  "id" : 298489037545697281,
  "in_reply_to_status_id" : 298488745089433602,
  "created_at" : "2013-02-04 17:51:46 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298488195534970880",
  "text" : "Considering taking Amtrak from Buffalo to Chicago - is this stupid when I could fly instead? Power, wifi, and less stress seems better.",
  "id" : 298488195534970880,
  "created_at" : "2013-02-04 17:48:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/half-inch-heist\/id559787622?mt=8&uo=4\" rel=\"nofollow\"\u003EHalf-Inch Heist on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "halfinchheist",
      "indices" : [ 22, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/iq2Cy2R5",
      "expanded_url" : "http:\/\/halfinchheist.com",
      "display_url" : "halfinchheist.com"
    } ]
  },
  "geo" : { },
  "id_str" : "298324173875462144",
  "text" : "I just scored 2321 on #halfinchheist BEAT THAT! http:\/\/t.co\/iq2Cy2R5",
  "id" : 298324173875462144,
  "created_at" : "2013-02-04 06:56:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kieran P",
      "screen_name" : "k776",
      "indices" : [ 0, 5 ],
      "id_str" : "12099752",
      "id" : 12099752
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 29, 37 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298303839981957121",
  "geo" : { },
  "id_str" : "298321913908973568",
  "in_reply_to_user_id" : 12099752,
  "text" : "@k776 works here! Also maybe @evanphx could make an offer\u2026",
  "id" : 298321913908973568,
  "in_reply_to_status_id" : 298303839981957121,
  "created_at" : "2013-02-04 06:47:41 +0000",
  "in_reply_to_screen_name" : "k776",
  "in_reply_to_user_id_str" : "12099752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 3, 15 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298321670056337408",
  "text" : "RT @ginatrapani: Shipping is such sweet sorrow.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298321492230434816",
    "text" : "Shipping is such sweet sorrow.",
    "id" : 298321492230434816,
    "created_at" : "2013-02-04 06:46:00 +0000",
    "user" : {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "protected" : false,
      "id_str" : "930061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550825678673682432\/YRqb4FJE_normal.png",
      "id" : 930061,
      "verified" : true
    }
  },
  "id" : 298321670056337408,
  "created_at" : "2013-02-04 06:46:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/UsA7MsXy",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/MURICA\/comments\/17tmdo\/thats_right_britain\/c88wgke",
      "display_url" : "reddit.com\/r\/MURICA\/comme\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298316560408399873",
  "text" : "\"THOSE SCOTLAND EAGLES ARE DAMN COMMIE EAGLES. WE WON'T HAVE THEM TAINTING OUR EAGLES OF FREEDOM\" http:\/\/t.co\/UsA7MsXy",
  "id" : 298316560408399873,
  "created_at" : "2013-02-04 06:26:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298316109189369856",
  "text" : "\"It really gets my maple syrup boiling in the morning when some hoser is in the [Tim Hortons] drive-thru making a huge order.\"",
  "id" : 298316109189369856,
  "created_at" : "2013-02-04 06:24:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/TBaPM4G4",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/murica",
      "display_url" : "reddit.com\/r\/murica"
    }, {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/lHriMJox",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/Straya",
      "display_url" : "reddit.com\/r\/Straya"
    }, {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/3SXwgMFV",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/Canadia",
      "display_url" : "reddit.com\/r\/Canadia"
    } ]
  },
  "geo" : { },
  "id_str" : "298315958571909122",
  "text" : "'MURICA http:\/\/t.co\/TBaPM4G4 STRAYA http:\/\/t.co\/lHriMJox CANADIA http:\/\/t.co\/3SXwgMFV",
  "id" : 298315958571909122,
  "created_at" : "2013-02-04 06:24:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/zl7reA5m",
      "expanded_url" : "http:\/\/blog.pushbullet.com\/2013\/02\/03\/from-0-to-15000-users-in-2-weeks\/",
      "display_url" : "blog.pushbullet.com\/2013\/02\/03\/fro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298299042390220800",
  "text" : "\"For less than $3, I served this entire blog and all of the static assets [...] for almost 100,000 visits\" http:\/\/t.co\/zl7reA5m",
  "id" : 298299042390220800,
  "created_at" : "2013-02-04 05:16:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298291975436775425",
  "text" : "@withloudhands thanks man.",
  "id" : 298291975436775425,
  "created_at" : "2013-02-04 04:48:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298276530549837825",
  "text" : "My dad just did a Gangham Style dance because he won $5k on his grid. \u30FD(\uFF1B\u25BD\uFF1B)\u30CE",
  "id" : 298276530549837825,
  "created_at" : "2013-02-04 03:47:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "298251549740769282",
  "geo" : { },
  "id_str" : "298252092634697728",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella http:\/\/t.co\/t7WATcFT does\u2026",
  "id" : 298252092634697728,
  "in_reply_to_status_id" : 298251549740769282,
  "created_at" : "2013-02-04 02:10:14 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 48 ],
      "url" : "https:\/\/t.co\/QJBIR3x1",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/status\/298220135586603008",
      "display_url" : "twitter.com\/qrush\/status\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298250769579257856",
  "text" : "MOM! C\u2019MON! I WAS WINNING! https:\/\/t.co\/QJBIR3x1",
  "id" : 298250769579257856,
  "created_at" : "2013-02-04 02:04:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ParisLemon",
      "screen_name" : "parislemon",
      "indices" : [ 3, 14 ],
      "id_str" : "134665872",
      "id" : 134665872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298245168119820292",
  "text" : "RT @parislemon: Citizens of Gotham...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298244426835320832",
    "text" : "Citizens of Gotham...",
    "id" : 298244426835320832,
    "created_at" : "2013-02-04 01:39:47 +0000",
    "user" : {
      "name" : "M.G. Siegler",
      "screen_name" : "mgsiegler",
      "protected" : false,
      "id_str" : "652193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549896815181459457\/w8nw4Ehf_normal.jpeg",
      "id" : 652193,
      "verified" : true
    }
  },
  "id" : 298245168119820292,
  "created_at" : "2013-02-04 01:42:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Brandom",
      "screen_name" : "russellbrandom",
      "indices" : [ 3, 18 ],
      "id_str" : "182086979",
      "id" : 182086979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298244348838031360",
  "text" : "RT @russellbrandom: This is when Bane comes out.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298243912865312768",
    "text" : "This is when Bane comes out.",
    "id" : 298243912865312768,
    "created_at" : "2013-02-04 01:37:44 +0000",
    "user" : {
      "name" : "Russell Brandom",
      "screen_name" : "russellbrandom",
      "protected" : false,
      "id_str" : "182086979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521752579064078336\/TvMMotdp_normal.png",
      "id" : 182086979,
      "verified" : true
    }
  },
  "id" : 298244348838031360,
  "created_at" : "2013-02-04 01:39:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Onion Sports Network",
      "screen_name" : "OnionSports",
      "indices" : [ 3, 15 ],
      "id_str" : "159894847",
      "id" : 159894847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SuperBowl",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298244267573387265",
  "text" : "RT @OnionSports: Superdome management has determined that the game is over #SuperBowl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SuperBowl",
        "indices" : [ 58, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298244138271395842",
    "text" : "Superdome management has determined that the game is over #SuperBowl",
    "id" : 298244138271395842,
    "created_at" : "2013-02-04 01:38:38 +0000",
    "user" : {
      "name" : "Onion Sports Network",
      "screen_name" : "OnionSports",
      "protected" : false,
      "id_str" : "159894847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1132666818\/osn_small_normal.jpg",
      "id" : 159894847,
      "verified" : true
    }
  },
  "id" : 298244267573387265,
  "created_at" : "2013-02-04 01:39:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jon hendren",
      "screen_name" : "fart",
      "indices" : [ 3, 8 ],
      "id_str" : "14166714",
      "id" : 14166714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298242781023969281",
  "text" : "RT @fart: congrats to one collection of men not actually from the city they represent on dominating another similarly disconnected group ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298242737222860800",
    "text" : "congrats to one collection of men not actually from the city they represent on dominating another similarly disconnected group of men",
    "id" : 298242737222860800,
    "created_at" : "2013-02-04 01:33:04 +0000",
    "user" : {
      "name" : "jon hendren",
      "screen_name" : "fart",
      "protected" : false,
      "id_str" : "14166714",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524567386729775104\/eaE_S9Rq_normal.jpeg",
      "id" : 14166714,
      "verified" : false
    }
  },
  "id" : 298242781023969281,
  "created_at" : "2013-02-04 01:33:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298237997810331648",
  "text" : "Not enough Gangham Style or Space Jam. NOT A MASHUP",
  "id" : 298237997810331648,
  "created_at" : "2013-02-04 01:14:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Picard",
      "screen_name" : "__rlp",
      "indices" : [ 0, 6 ],
      "id_str" : "855194221",
      "id" : 855194221
    }, {
      "name" : "Adam Lowe",
      "screen_name" : "adam_lowe",
      "indices" : [ 7, 17 ],
      "id_str" : "15525994",
      "id" : 15525994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298235347995852801",
  "geo" : { },
  "id_str" : "298236099791310848",
  "in_reply_to_user_id" : 855194221,
  "text" : "@__rlp @adam_lowe basically gives you a banner and framework to run under- keeps things alive and moving and helps intro new people",
  "id" : 298236099791310848,
  "in_reply_to_status_id" : 298235347995852801,
  "created_at" : "2013-02-04 01:06:41 +0000",
  "in_reply_to_screen_name" : "__rlp",
  "in_reply_to_user_id_str" : "855194221",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "superbowl",
      "indices" : [ 24, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298220135586603008",
  "text" : "2 brothers coaching the #superbowl is like 2 brothers playing a video game. It\u2019s going to end up with yelling and Mom shutting off the TV.",
  "id" : 298220135586603008,
  "created_at" : "2013-02-04 00:03:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "indices" : [ 3, 15 ],
      "id_str" : "66666549",
      "id" : 66666549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298219457988419584",
  "text" : "RT @TweetsofOld: Richard White, 24 years of age, has gone insane over football. He imagines he is the champion football player of the wo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298218292764626944",
    "text" : "Richard White, 24 years of age, has gone insane over football. He imagines he is the champion football player of the world. CA1901",
    "id" : 298218292764626944,
    "created_at" : "2013-02-03 23:55:56 +0000",
    "user" : {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "protected" : false,
      "id_str" : "66666549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488101282473721856\/ddsWSyyl_normal.jpeg",
      "id" : 66666549,
      "verified" : false
    }
  },
  "id" : 298219457988419584,
  "created_at" : "2013-02-04 00:00:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michal Papis",
      "screen_name" : "mpapis",
      "indices" : [ 0, 7 ],
      "id_str" : "108799541",
      "id" : 108799541
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 8, 17 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297838323492335616",
  "geo" : { },
  "id_str" : "298198575429611520",
  "in_reply_to_user_id" : 108799541,
  "text" : "@mpapis @rubygems is a bot. Do you mean for pushing gems?",
  "id" : 298198575429611520,
  "in_reply_to_status_id" : 297838323492335616,
  "created_at" : "2013-02-03 22:37:35 +0000",
  "in_reply_to_screen_name" : "mpapis",
  "in_reply_to_user_id_str" : "108799541",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Jarvis",
      "screen_name" : "lee_jarvis",
      "indices" : [ 0, 11 ],
      "id_str" : "137640366",
      "id" : 137640366
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 27, 35 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298193427433136129",
  "geo" : { },
  "id_str" : "298197841673859073",
  "in_reply_to_user_id" : 137640366,
  "text" : "@lee_jarvis not sure\u2026maybe @evanphx or someone in #rubygems knows?",
  "id" : 298197841673859073,
  "in_reply_to_status_id" : 298193427433136129,
  "created_at" : "2013-02-03 22:34:40 +0000",
  "in_reply_to_screen_name" : "lee_jarvis",
  "in_reply_to_user_id_str" : "137640366",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Manitou",
      "screen_name" : "ActualPerson084",
      "indices" : [ 3, 19 ],
      "id_str" : "318339237",
      "id" : 318339237
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SUPERBOWL",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298153706740924416",
  "text" : "RT @ActualPerson084: SOMEWHERE BEYOND THE HORIZON, THE SUPERB OWL SHRIEKS. INSECTS FALL FROM THE AIR. WINDOWS SHATTER. IT IS COMING. #SU ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SUPERBOWL",
        "indices" : [ 112, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298151151357026304",
    "text" : "SOMEWHERE BEYOND THE HORIZON, THE SUPERB OWL SHRIEKS. INSECTS FALL FROM THE AIR. WINDOWS SHATTER. IT IS COMING. #SUPERBOWL",
    "id" : 298151151357026304,
    "created_at" : "2013-02-03 19:29:08 +0000",
    "user" : {
      "name" : "Daniel Manitou",
      "screen_name" : "ActualPerson084",
      "protected" : false,
      "id_str" : "318339237",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3280995244\/4414b6cd72c26211b2704410b3ff6cb0_normal.gif",
      "id" : 318339237,
      "verified" : false
    }
  },
  "id" : 298153706740924416,
  "created_at" : "2013-02-03 19:39:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298145280375783424",
  "geo" : { },
  "id_str" : "298146684947554304",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel i lost a few without realizing it to him! maybe it was the banana i was attacking him with :P",
  "id" : 298146684947554304,
  "in_reply_to_status_id" : 298145280375783424,
  "created_at" : "2013-02-03 19:11:23 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298143997149462528",
  "geo" : { },
  "id_str" : "298144899658829824",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel the quest and sanctum are sometimes rough depending on your situation - i've had terrible times in the sanctum.",
  "id" : 298144899658829824,
  "in_reply_to_status_id" : 298143997149462528,
  "created_at" : "2013-02-03 19:04:18 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 71, 82 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 66 ],
      "url" : "https:\/\/t.co\/4VYdPUXl",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wsjd_3F-3KM",
      "display_url" : "youtube.com\/watch?v=wsjd_3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298133369731026944",
  "text" : "GRAB A RANDOM TOY AND JUST FLAT OUT RUN MOVE https:\/\/t.co\/4VYdPUXl \/cc @joanofdark",
  "id" : 298133369731026944,
  "created_at" : "2013-02-03 18:18:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Tyrrell",
      "screen_name" : "timtyrrell",
      "indices" : [ 0, 11 ],
      "id_str" : "15012484",
      "id" : 15012484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298129787191435264",
  "geo" : { },
  "id_str" : "298130042100264960",
  "in_reply_to_user_id" : 15012484,
  "text" : "@timtyrrell His name is Geddy :)",
  "id" : 298130042100264960,
  "in_reply_to_status_id" : 298129787191435264,
  "created_at" : "2013-02-03 18:05:15 +0000",
  "in_reply_to_screen_name" : "timtyrrell",
  "in_reply_to_user_id_str" : "15012484",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/W94p967T",
      "expanded_url" : "http:\/\/flic.kr\/p\/dS1axU",
      "display_url" : "flic.kr\/p\/dS1axU"
    } ]
  },
  "geo" : { },
  "id_str" : "298129261661917184",
  "text" : "Snow dog. http:\/\/t.co\/W94p967T",
  "id" : 298129261661917184,
  "created_at" : "2013-02-03 18:02:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298116000975577088",
  "geo" : { },
  "id_str" : "298124321493241856",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr he's only 50 pounds, but yes - he's a runner.",
  "id" : 298124321493241856,
  "in_reply_to_status_id" : 298116000975577088,
  "created_at" : "2013-02-03 17:42:31 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297987263051214848",
  "geo" : { },
  "id_str" : "297996710452535296",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik end of most YEM recordings gets super jarring and unfun - I wish they didn\u2019t do the yelling bits.",
  "id" : 297996710452535296,
  "in_reply_to_status_id" : 297987263051214848,
  "created_at" : "2013-02-03 09:15:26 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 9, 15 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297988280132177920",
  "geo" : { },
  "id_str" : "297995856131551232",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule @cmeik rubyist phish show- let\u2019s make it happen.",
  "id" : 297995856131551232,
  "in_reply_to_status_id" : 297988280132177920,
  "created_at" : "2013-02-03 09:12:03 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297982821069361153",
  "geo" : { },
  "id_str" : "297995626149457920",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel agreed - the extra hp is worth it. Gehennom in general is boring.",
  "id" : 297995626149457920,
  "in_reply_to_status_id" : 297982821069361153,
  "created_at" : "2013-02-03 09:11:08 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297923401799045120",
  "text" : "Consistently humbled by the folks who spend the time to teach and listen with software- both in person and online. Thank you.",
  "id" : 297923401799045120,
  "created_at" : "2013-02-03 04:24:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297921261894504448",
  "geo" : { },
  "id_str" : "297923092246847488",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d set your avatar!!!",
  "id" : 297923092246847488,
  "in_reply_to_status_id" : 297921261894504448,
  "created_at" : "2013-02-03 04:22:54 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297917226248462336",
  "text" : "I guess Mike A\u2019s comes close too- just super impressed by the vibe here.",
  "id" : 297917226248462336,
  "created_at" : "2013-02-03 03:59:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297917054709809154",
  "text" : "Statler\u2019s Lobby Bar is easily the classiest bar in Buffalo. Our city needs more of these.",
  "id" : 297917054709809154,
  "created_at" : "2013-02-03 03:58:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/qUpXCqCH",
      "expanded_url" : "http:\/\/vine.co\/v\/b1jnJbP09HL",
      "display_url" : "vine.co\/v\/b1jnJbP09HL"
    } ]
  },
  "geo" : { },
  "id_str" : "297914454966931456",
  "text" : "Shuffleboard, like bowling or curling just more sandy. http:\/\/t.co\/qUpXCqCH",
  "id" : 297914454966931456,
  "created_at" : "2013-02-03 03:48:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BarCampBUF",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297912326135365632",
  "text" : "Big thanks to everyone that came to #BarCampBUF near and far- more tech events in Buffalo are coming!",
  "id" : 297912326135365632,
  "created_at" : "2013-02-03 03:40:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Societal Obstacle",
      "screen_name" : "laurenvoswinkel",
      "indices" : [ 0, 16 ],
      "id_str" : "19539935",
      "id" : 19539935
    }, {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 17, 25 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297886951208529920",
  "geo" : { },
  "id_str" : "297891751228751872",
  "in_reply_to_user_id" : 19539935,
  "text" : "@laurenvoswinkel @whit537 thanks for coming up!!! Why can\u2019t PGH\/CLE be closer?! :(",
  "id" : 297891751228751872,
  "in_reply_to_status_id" : 297886951208529920,
  "created_at" : "2013-02-03 02:18:22 +0000",
  "in_reply_to_screen_name" : "laurenvoswinkel",
  "in_reply_to_user_id_str" : "19539935",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Reese",
      "screen_name" : "justinxreese",
      "indices" : [ 3, 16 ],
      "id_str" : "14255877",
      "id" : 14255877
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 22, 28 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 62, 71 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297836314303291392",
  "text" : "RT @justinxreese: Hey @qrush, I just merged a pull request to @OpenHack that added its 10th country. You created something awesome.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 4, 10 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 44, 53 ],
        "id_str" : "715440464",
        "id" : 715440464
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297836225744744448",
    "text" : "Hey @qrush, I just merged a pull request to @OpenHack that added its 10th country. You created something awesome.",
    "id" : 297836225744744448,
    "created_at" : "2013-02-02 22:37:44 +0000",
    "user" : {
      "name" : "Justin Reese",
      "screen_name" : "justinxreese",
      "protected" : false,
      "id_str" : "14255877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000717365875\/a5fc587859d80f9415092095a619b378_normal.jpeg",
      "id" : 14255877,
      "verified" : false
    }
  },
  "id" : 297836314303291392,
  "created_at" : "2013-02-02 22:38:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Reese",
      "screen_name" : "justinxreese",
      "indices" : [ 0, 13 ],
      "id_str" : "14255877",
      "id" : 14255877
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 14, 23 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297836225744744448",
  "geo" : { },
  "id_str" : "297836298532691968",
  "in_reply_to_user_id" : 14255877,
  "text" : "@justinxreese @openhack whoa!!",
  "id" : 297836298532691968,
  "in_reply_to_status_id" : 297836225744744448,
  "created_at" : "2013-02-02 22:38:01 +0000",
  "in_reply_to_screen_name" : "justinxreese",
  "in_reply_to_user_id_str" : "14255877",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BarcampBUF",
      "indices" : [ 35, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/U9Y90d8P",
      "expanded_url" : "http:\/\/goo.gl\/maps\/JoUov",
      "display_url" : "goo.gl\/maps\/JoUov"
    } ]
  },
  "geo" : { },
  "id_str" : "297816958051684352",
  "text" : "Heading to Pan-American Grill post-#BarcampBUF - http:\/\/t.co\/U9Y90d8P - who's going?",
  "id" : 297816958051684352,
  "created_at" : "2013-02-02 21:21:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Chan",
      "screen_name" : "jtcchan",
      "indices" : [ 0, 8 ],
      "id_str" : "12653762",
      "id" : 12653762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297778947347857409",
  "geo" : { },
  "id_str" : "297779389238751232",
  "in_reply_to_user_id" : 12653762,
  "text" : "@jtcchan Talk to the humans behind projects more - I didn't really \"get it\" until talking to more at confs, meetups, etc.",
  "id" : 297779389238751232,
  "in_reply_to_status_id" : 297778947347857409,
  "created_at" : "2013-02-02 18:51:53 +0000",
  "in_reply_to_screen_name" : "jtcchan",
  "in_reply_to_user_id_str" : "12653762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxim Chernyak",
      "screen_name" : "hakunin",
      "indices" : [ 0, 8 ],
      "id_str" : "11622052",
      "id" : 11622052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297778865437306880",
  "geo" : { },
  "id_str" : "297778948002156545",
  "in_reply_to_user_id" : 11622052,
  "text" : "@hakunin I just submitted my first iOS app, so yes? :)",
  "id" : 297778948002156545,
  "in_reply_to_status_id" : 297778865437306880,
  "created_at" : "2013-02-02 18:50:08 +0000",
  "in_reply_to_screen_name" : "hakunin",
  "in_reply_to_user_id_str" : "11622052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297774252231389184",
  "geo" : { },
  "id_str" : "297778235457019904",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen I don't remember the *first* commit but the first project I made a meaningful difference was Jekyll.",
  "id" : 297778235457019904,
  "in_reply_to_status_id" : 297774252231389184,
  "created_at" : "2013-02-02 18:47:18 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297774252231389184",
  "geo" : { },
  "id_str" : "297778055571730432",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen i got pretty stuck with rubinius - all of the fun ruby stuff was done and I didn't know C++.",
  "id" : 297778055571730432,
  "in_reply_to_status_id" : 297774252231389184,
  "created_at" : "2013-02-02 18:46:35 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/iciwQnDC",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/programming\/comments\/6nc1h\/im_in_college_and_i_want_to_contribute_to_an_oss\/",
      "display_url" : "reddit.com\/r\/programming\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297773992499105792",
  "text" : "4 years ago - \"I'm in college, and I want to contribute to an OSS project. Any suggestions?\" http:\/\/t.co\/iciwQnDC",
  "id" : 297773992499105792,
  "created_at" : "2013-02-02 18:30:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 40, 49 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/297764374326677504\/photo\/1",
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/AXKszUim",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCHfHu7CEAAJ2Ng.jpg",
      "id_str" : "297764374330871808",
      "id" : 297764374330871808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCHfHu7CEAAJ2Ng.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/AXKszUim"
    } ],
    "hashtags" : [ {
      "text" : "BarcampBUF",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297764374326677504",
  "text" : "These are amazing- actual Vim keys from @sabiddle #BarcampBUF http:\/\/t.co\/AXKszUim",
  "id" : 297764374326677504,
  "created_at" : "2013-02-02 17:52:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297758722372026369",
  "text" : "It's satisfying to follow a troll comment to a history of trolling, hate, apathy, ignorance, negativity - proves how worthless it is.",
  "id" : 297758722372026369,
  "created_at" : "2013-02-02 17:29:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garrett Murphey",
      "screen_name" : "gmurphey",
      "indices" : [ 0, 9 ],
      "id_str" : "822220",
      "id" : 822220
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297758203595354115",
  "geo" : { },
  "id_str" : "297758345408966658",
  "in_reply_to_user_id" : 822220,
  "text" : "@gmurphey Y U NO AT BARCAMP?",
  "id" : 297758345408966658,
  "in_reply_to_status_id" : 297758203595354115,
  "created_at" : "2013-02-02 17:28:16 +0000",
  "in_reply_to_screen_name" : "gmurphey",
  "in_reply_to_user_id_str" : "822220",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Krioni",
      "screen_name" : "krioni",
      "indices" : [ 0, 7 ],
      "id_str" : "20042684",
      "id" : 20042684
    }, {
      "name" : "Jay Sanders",
      "screen_name" : "mindtonic",
      "indices" : [ 8, 18 ],
      "id_str" : "19267251",
      "id" : 19267251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297749687539212288",
  "geo" : { },
  "id_str" : "297750562332610561",
  "in_reply_to_user_id" : 20042684,
  "text" : "@krioni @mindtonic I am not interested in working on any open source fulltime - I think rubygems\/rubygems.org should stay all volunteer",
  "id" : 297750562332610561,
  "in_reply_to_status_id" : 297749687539212288,
  "created_at" : "2013-02-02 16:57:20 +0000",
  "in_reply_to_screen_name" : "krioni",
  "in_reply_to_user_id_str" : "20042684",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markov Twain",
      "screen_name" : "markov_twain",
      "indices" : [ 3, 16 ],
      "id_str" : "237957577",
      "id" : 237957577
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 18, 24 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297749158117400577",
  "text" : "RT @markov_twain: @qrush It\u2019s surprising that the Ruby community, having such a variety and given its size, still continue to be nice to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "297742514771877889",
    "geo" : { },
    "id_str" : "297747155731505153",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush It\u2019s surprising that the Ruby community, having such a variety and given its size, still continue to be nice to each other -matz 2001",
    "id" : 297747155731505153,
    "in_reply_to_status_id" : 297742514771877889,
    "created_at" : "2013-02-02 16:43:48 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Markov Twain",
      "screen_name" : "markov_twain",
      "protected" : false,
      "id_str" : "237957577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1901369054\/huck-robot_normal.jpg",
      "id" : 237957577,
      "verified" : false
    }
  },
  "id" : 297749158117400577,
  "created_at" : "2013-02-02 16:51:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Krioni",
      "screen_name" : "krioni",
      "indices" : [ 0, 7 ],
      "id_str" : "20042684",
      "id" : 20042684
    }, {
      "name" : "Jay Sanders",
      "screen_name" : "mindtonic",
      "indices" : [ 8, 18 ],
      "id_str" : "19267251",
      "id" : 19267251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297742722809339904",
  "geo" : { },
  "id_str" : "297743201157144577",
  "in_reply_to_user_id" : 20042684,
  "text" : "@krioni @mindtonic I don't know what the solution is - I'm not a security expert. It's time for the community to rise up and fix this.",
  "id" : 297743201157144577,
  "in_reply_to_status_id" : 297742722809339904,
  "created_at" : "2013-02-02 16:28:05 +0000",
  "in_reply_to_screen_name" : "krioni",
  "in_reply_to_user_id_str" : "20042684",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297742514771877889",
  "text" : "The entire RubyGems system thus far has been built on personal trust - this isn't enough anymore at the size of the Ruby\/Rails community.",
  "id" : 297742514771877889,
  "created_at" : "2013-02-02 16:25:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297742002890633217",
  "geo" : { },
  "id_str" : "297742292385665024",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn Y U NO AT BARCAMP",
  "id" : 297742292385665024,
  "in_reply_to_status_id" : 297742002890633217,
  "created_at" : "2013-02-02 16:24:28 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristiano Betta",
      "screen_name" : "cbetta",
      "indices" : [ 0, 7 ],
      "id_str" : "5737",
      "id" : 5737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297739747873402881",
  "geo" : { },
  "id_str" : "297741518020689920",
  "in_reply_to_user_id" : 5737,
  "text" : "@cbetta that being said, thanks for writing about this - sorry that the tone is bothering me. these issues have been around for *years*",
  "id" : 297741518020689920,
  "in_reply_to_status_id" : 297739747873402881,
  "created_at" : "2013-02-02 16:21:24 +0000",
  "in_reply_to_screen_name" : "cbetta",
  "in_reply_to_user_id_str" : "5737",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristiano Betta",
      "screen_name" : "cbetta",
      "indices" : [ 0, 7 ],
      "id_str" : "5737",
      "id" : 5737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297739747873402881",
  "geo" : { },
  "id_str" : "297741239871234048",
  "in_reply_to_user_id" : 5737,
  "text" : "@cbetta we should be energizing the community to take action and get involved - exposing the issues is good but inspiring fear is :(",
  "id" : 297741239871234048,
  "in_reply_to_status_id" : 297739747873402881,
  "created_at" : "2013-02-02 16:20:18 +0000",
  "in_reply_to_screen_name" : "cbetta",
  "in_reply_to_user_id_str" : "5737",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297740919006957568",
  "text" : "OH \" if you really want to make a difference, write a blog post or tweet and post it on hn\"",
  "id" : 297740919006957568,
  "created_at" : "2013-02-02 16:19:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristiano Betta",
      "screen_name" : "cbetta",
      "indices" : [ 0, 7 ],
      "id_str" : "5737",
      "id" : 5737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297713575303196672",
  "geo" : { },
  "id_str" : "297739369656221696",
  "in_reply_to_user_id" : 5737,
  "text" : "@cbetta this is total linkbait - if you want to solve these problems please get involved...the call to action here isn't strong enough.",
  "id" : 297739369656221696,
  "in_reply_to_status_id" : 297713575303196672,
  "created_at" : "2013-02-02 16:12:52 +0000",
  "in_reply_to_screen_name" : "cbetta",
  "in_reply_to_user_id_str" : "5737",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BfloFRED",
      "screen_name" : "BfloFRED",
      "indices" : [ 0, 9 ],
      "id_str" : "876930312",
      "id" : 876930312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297734499947659264",
  "geo" : { },
  "id_str" : "297735318751301632",
  "in_reply_to_user_id" : 876930312,
  "text" : "@BfloFRED Go fix it!",
  "id" : 297735318751301632,
  "in_reply_to_status_id" : 297734499947659264,
  "created_at" : "2013-02-02 15:56:46 +0000",
  "in_reply_to_screen_name" : "BfloFRED",
  "in_reply_to_user_id_str" : "876930312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BarCampBUF",
      "indices" : [ 24, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/949OBlpc",
      "expanded_url" : "http:\/\/barcampbuffalo.org\/",
      "display_url" : "barcampbuffalo.org"
    } ]
  },
  "geo" : { },
  "id_str" : "297727223618740224",
  "text" : "Starting to publish the #BarCampBUF talk schedule on http:\/\/t.co\/949OBlpc ! So happy we have multiple tracks.",
  "id" : 297727223618740224,
  "created_at" : "2013-02-02 15:24:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/297722166949064704\/photo\/1",
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/nipCnw03",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCG4u8NCMAAouZ9.jpg",
      "id_str" : "297722166957453312",
      "id" : 297722166957453312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCG4u8NCMAAouZ9.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/nipCnw03"
    } ],
    "hashtags" : [ {
      "text" : "BarCampBUF",
      "indices" : [ 27, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297722166949064704",
  "text" : "Talks are coming together! #BarCampBUF http:\/\/t.co\/nipCnw03",
  "id" : 297722166949064704,
  "created_at" : "2013-02-02 15:04:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/297718201314316288\/photo\/1",
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/MvMkykgH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCG1IHDCEAACw6s.jpg",
      "id_str" : "297718201318510592",
      "id" : 297718201318510592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCG1IHDCEAACw6s.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MvMkykgH"
    } ],
    "hashtags" : [ {
      "text" : "BarCampBUF",
      "indices" : [ 6, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297718201314316288",
  "text" : "Woot! #BarCampBUF is starting off! http:\/\/t.co\/MvMkykgH",
  "id" : 297718201314316288,
  "created_at" : "2013-02-02 14:48:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Swicegood",
      "screen_name" : "tswicegood",
      "indices" : [ 0, 11 ],
      "id_str" : "9478892",
      "id" : 9478892
    }, {
      "name" : "HTML5.tx",
      "screen_name" : "HTML5TX",
      "indices" : [ 12, 20 ],
      "id_str" : "314582811",
      "id" : 314582811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297714590060527616",
  "geo" : { },
  "id_str" : "297715237140955136",
  "in_reply_to_user_id" : 9478892,
  "text" : "@tswicegood @HTML5TX ...",
  "id" : 297715237140955136,
  "in_reply_to_status_id" : 297714590060527616,
  "created_at" : "2013-02-02 14:36:58 +0000",
  "in_reply_to_screen_name" : "tswicegood",
  "in_reply_to_user_id_str" : "9478892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/297707653755437056\/photo\/1",
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/GOWD2C3R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCGriKVCAAIcEUx.jpg",
      "id_str" : "297707653759631362",
      "id" : 297707653759631362,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCGriKVCAAIcEUx.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/GOWD2C3R"
    } ],
    "hashtags" : [ {
      "text" : "BarCampBUF",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297707653755437056",
  "text" : "A real talk grid for #BarCampBUF ! http:\/\/t.co\/GOWD2C3R",
  "id" : 297707653755437056,
  "created_at" : "2013-02-02 14:06:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/297707262556905472\/photo\/1",
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/wXYoUHNW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCGrLZACIAI-93k.jpg",
      "id_str" : "297707262561099778",
      "id" : 297707262561099778,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCGrLZACIAI-93k.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wXYoUHNW"
    } ],
    "hashtags" : [ {
      "text" : "BarCampBUF",
      "indices" : [ 11, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297707262556905472",
  "text" : "Looks like #BarCampBUF has come together ! Shirts! http:\/\/t.co\/wXYoUHNW",
  "id" : 297707262556905472,
  "created_at" : "2013-02-02 14:05:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BarCamp Buffalo",
      "screen_name" : "BarCampBuffalo",
      "indices" : [ 3, 18 ],
      "id_str" : "19735370",
      "id" : 19735370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297698429562388480",
  "text" : "RT @BarCampBuffalo: To give everyone a moment this morning to make snow angels, we'll start Intro's 9:45 and talks @ 10am. Drive safe!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297686641584250880",
    "text" : "To give everyone a moment this morning to make snow angels, we'll start Intro's 9:45 and talks @ 10am. Drive safe!",
    "id" : 297686641584250880,
    "created_at" : "2013-02-02 12:43:20 +0000",
    "user" : {
      "name" : "BarCamp Buffalo",
      "screen_name" : "BarCampBuffalo",
      "protected" : false,
      "id_str" : "19735370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444567584692645888\/A81UVOcA_normal.png",
      "id" : 19735370,
      "verified" : false
    }
  },
  "id" : 297698429562388480,
  "created_at" : "2013-02-02 13:30:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Societal Obstacle",
      "screen_name" : "laurenvoswinkel",
      "indices" : [ 0, 16 ],
      "id_str" : "19539935",
      "id" : 19539935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297696565081030656",
  "geo" : { },
  "id_str" : "297696799605530624",
  "in_reply_to_user_id" : 19539935,
  "text" : "@laurenvoswinkel I am the opposite.",
  "id" : 297696799605530624,
  "in_reply_to_status_id" : 297696565081030656,
  "created_at" : "2013-02-02 13:23:42 +0000",
  "in_reply_to_screen_name" : "laurenvoswinkel",
  "in_reply_to_user_id_str" : "19539935",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Societal Obstacle",
      "screen_name" : "laurenvoswinkel",
      "indices" : [ 0, 16 ],
      "id_str" : "19539935",
      "id" : 19539935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297695436901335040",
  "geo" : { },
  "id_str" : "297695857153814529",
  "in_reply_to_user_id" : 19539935,
  "text" : "@laurenvoswinkel roads are terrible- please drive careful",
  "id" : 297695857153814529,
  "in_reply_to_status_id" : 297695436901335040,
  "created_at" : "2013-02-02 13:19:57 +0000",
  "in_reply_to_screen_name" : "laurenvoswinkel",
  "in_reply_to_user_id_str" : "19539935",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Sieg",
      "screen_name" : "calmyournerves",
      "indices" : [ 0, 15 ],
      "id_str" : "101258359",
      "id" : 101258359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297682961137020928",
  "geo" : { },
  "id_str" : "297687011014365184",
  "in_reply_to_user_id" : 101258359,
  "text" : "@calmyournerves oh- do you mean mine? Confused",
  "id" : 297687011014365184,
  "in_reply_to_status_id" : 297682961137020928,
  "created_at" : "2013-02-02 12:44:48 +0000",
  "in_reply_to_screen_name" : "calmyournerves",
  "in_reply_to_user_id_str" : "101258359",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Sieg",
      "screen_name" : "calmyournerves",
      "indices" : [ 0, 15 ],
      "id_str" : "101258359",
      "id" : 101258359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 16, 25 ]
    }, {
      "text" : "rubygems",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297682961137020928",
  "geo" : { },
  "id_str" : "297686917930184704",
  "in_reply_to_user_id" : 101258359,
  "text" : "@calmyournerves #rubygems and the new ops work has been in #rubygems-aws",
  "id" : 297686917930184704,
  "in_reply_to_status_id" : 297682961137020928,
  "created_at" : "2013-02-02 12:44:26 +0000",
  "in_reply_to_screen_name" : "calmyournerves",
  "in_reply_to_user_id_str" : "101258359",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297684015647973377",
  "text" : "RT @rubygems_status: Push has been restored!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297610518292738048",
    "text" : "Push has been restored!",
    "id" : 297610518292738048,
    "created_at" : "2013-02-02 07:40:51 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 297684015647973377,
  "created_at" : "2013-02-02 12:32:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BarCamp Buffalo",
      "screen_name" : "BarCampBuffalo",
      "indices" : [ 25, 40 ],
      "id_str" : "19735370",
      "id" : 19735370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/TDackTdy",
      "expanded_url" : "http:\/\/www.thruway.ny.gov\/travelers\/map\/index.html?layer=wta",
      "display_url" : "thruway.ny.gov\/travelers\/map\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297676153060220928",
  "text" : "If you\u2019re driving far to @BarCampBuffalo today please be careful. http:\/\/t.co\/TDackTdy \uD83D\uDE26\u2744",
  "id" : 297676153060220928,
  "created_at" : "2013-02-02 12:01:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 5, 14 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297674124954828801",
  "text" : "Yay! @rubygems is back! *\uFF65\u309C\uFF9F\uFF65*:.\uFF61..\uFF61.:*\uFF65'(*\uFF9F\u25BD\uFF9F*)'\uFF65*:.\uFF61. .\uFF61.:*\uFF65\u309C\uFF9F\uFF65*",
  "id" : 297674124954828801,
  "created_at" : "2013-02-02 11:53:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Lyon",
      "screen_name" : "mattly",
      "indices" : [ 0, 7 ],
      "id_str" : "1768041",
      "id" : 1768041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297571529997295616",
  "geo" : { },
  "id_str" : "297571922558996480",
  "in_reply_to_user_id" : 1768041,
  "text" : "@mattly it is worth it.",
  "id" : 297571922558996480,
  "in_reply_to_status_id" : 297571529997295616,
  "created_at" : "2013-02-02 05:07:29 +0000",
  "in_reply_to_screen_name" : "mattly",
  "in_reply_to_user_id_str" : "1768041",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Coyne",
      "screen_name" : "j_coyne",
      "indices" : [ 0, 8 ],
      "id_str" : "44382779",
      "id" : 44382779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297564632946733056",
  "geo" : { },
  "id_str" : "297565049680183296",
  "in_reply_to_user_id" : 44382779,
  "text" : "@j_coyne current goings on are #rubygems-aws on freenode. hoping to restore in the next few hours it seems",
  "id" : 297565049680183296,
  "in_reply_to_status_id" : 297564632946733056,
  "created_at" : "2013-02-02 04:40:10 +0000",
  "in_reply_to_screen_name" : "j_coyne",
  "in_reply_to_user_id_str" : "44382779",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Busigin",
      "screen_name" : "mbusigin",
      "indices" : [ 0, 9 ],
      "id_str" : "19111917",
      "id" : 19111917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/QpYBdQPC",
      "expanded_url" : "http:\/\/barcampbuffalo.org",
      "display_url" : "barcampbuffalo.org"
    } ]
  },
  "in_reply_to_status_id_str" : "297560666330509312",
  "geo" : { },
  "id_str" : "297564324782804993",
  "in_reply_to_user_id" : 19111917,
  "text" : "@mbusigin are you coming to http:\/\/t.co\/QpYBdQPC to explain WTF all of these mean?",
  "id" : 297564324782804993,
  "in_reply_to_status_id" : 297560666330509312,
  "created_at" : "2013-02-02 04:37:18 +0000",
  "in_reply_to_screen_name" : "mbusigin",
  "in_reply_to_user_id_str" : "19111917",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297564057626636288",
  "text" : "The wins from this incident - many new contributors and faces who care about rubygems security, infrastructure and ops. Please stick around.",
  "id" : 297564057626636288,
  "created_at" : "2013-02-02 04:36:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 0, 12 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297553303741538304",
  "geo" : { },
  "id_str" : "297558503986458624",
  "in_reply_to_user_id" : 10035582,
  "text" : "@rocketslide bacon-dance.gif has been archived",
  "id" : 297558503986458624,
  "in_reply_to_status_id" : 297553303741538304,
  "created_at" : "2013-02-02 04:14:10 +0000",
  "in_reply_to_screen_name" : "rocketslide",
  "in_reply_to_user_id_str" : "10035582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/q81qnxr9",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=5154648",
      "display_url" : "news.ycombinator.com\/item?id=5154648"
    } ]
  },
  "geo" : { },
  "id_str" : "297541214025158657",
  "text" : "If you're on Mountain Lion, typing \"File:\/\/\/\" into any textbox crashes the program - http:\/\/t.co\/q81qnxr9",
  "id" : 297541214025158657,
  "created_at" : "2013-02-02 03:05:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 3, 11 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/n9y8tn0r",
      "expanded_url" : "http:\/\/bit.ly\/11vwxvK",
      "display_url" : "bit.ly\/11vwxvK"
    } ]
  },
  "geo" : { },
  "id_str" : "297532338122928128",
  "text" : "RT @drbrain: If you are a security person and want to help with gem signing check out http:\/\/t.co\/n9y8tn0r and irc:\/\/chat.freenode.net\/# ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubygems",
        "indices" : [ 122, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/n9y8tn0r",
        "expanded_url" : "http:\/\/bit.ly\/11vwxvK",
        "display_url" : "bit.ly\/11vwxvK"
      } ]
    },
    "geo" : { },
    "id_str" : "297517330903212033",
    "text" : "If you are a security person and want to help with gem signing check out http:\/\/t.co\/n9y8tn0r and irc:\/\/chat.freenode.net\/#rubygems-trust",
    "id" : 297517330903212033,
    "created_at" : "2013-02-02 01:30:33 +0000",
    "user" : {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "protected" : false,
      "id_str" : "670283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472446327373053952\/oJXOO4GL_normal.jpeg",
      "id" : 670283,
      "verified" : false
    }
  },
  "id" : 297532338122928128,
  "created_at" : "2013-02-02 02:30:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/297528462783156225\/photo\/1",
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/pDCmfB6K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCEIj38CEAEGaRY.png",
      "id_str" : "297528462787350529",
      "id" : 297528462787350529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCEIj38CEAEGaRY.png",
      "sizes" : [ {
        "h" : 94,
        "resize" : "fit",
        "w" : 192
      }, {
        "h" : 94,
        "resize" : "fit",
        "w" : 192
      }, {
        "h" : 94,
        "resize" : "fit",
        "w" : 192
      }, {
        "h" : 94,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 94,
        "resize" : "fit",
        "w" : 192
      } ],
      "display_url" : "pic.twitter.com\/pDCmfB6K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297528462783156225",
  "text" : "One todo left...and DONE! http:\/\/t.co\/pDCmfB6K",
  "id" : 297528462783156225,
  "created_at" : "2013-02-02 02:14:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/E0Wd39Cj",
      "expanded_url" : "http:\/\/yfrog.com\/h37yucp",
      "display_url" : "yfrog.com\/h37yucp"
    } ]
  },
  "geo" : { },
  "id_str" : "297484165086060547",
  "text" : "RT @rjs: Only one thing left to do\u2026  http:\/\/t.co\/E0Wd39Cj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/E0Wd39Cj",
        "expanded_url" : "http:\/\/yfrog.com\/h37yucp",
        "display_url" : "yfrog.com\/h37yucp"
      } ]
    },
    "geo" : { },
    "id_str" : "297483507159166976",
    "text" : "Only one thing left to do\u2026  http:\/\/t.co\/E0Wd39Cj",
    "id" : 297483507159166976,
    "created_at" : "2013-02-01 23:16:09 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 297484165086060547,
  "created_at" : "2013-02-01 23:18:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 93 ],
      "url" : "https:\/\/t.co\/7avVqWpS",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Canadian_football",
      "display_url" : "en.wikipedia.org\/wiki\/Canadian_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297462629126000640",
  "text" : "This is sports - \"attempting to advance a pointed prolate spheroidball\" https:\/\/t.co\/7avVqWpS",
  "id" : 297462629126000640,
  "created_at" : "2013-02-01 21:53:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Holman",
      "screen_name" : "zenom_",
      "indices" : [ 0, 7 ],
      "id_str" : "59183674",
      "id" : 59183674
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 56, 64 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 69, 77 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297431564818731008",
  "geo" : { },
  "id_str" : "297453281897230337",
  "in_reply_to_user_id" : 59183674,
  "text" : "@zenom_ we have yanked a bunch that we couldn\u2019t verify- @evanphx and @drbrain can confirm this",
  "id" : 297453281897230337,
  "in_reply_to_status_id" : 297431564818731008,
  "created_at" : "2013-02-01 21:16:03 +0000",
  "in_reply_to_screen_name" : "zenom_",
  "in_reply_to_user_id_str" : "59183674",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 0, 8 ],
      "id_str" : "670283",
      "id" : 670283
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 9, 17 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "indices" : [ 18, 31 ],
      "id_str" : "9887162",
      "id" : 9887162
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 32, 38 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297416588355829760",
  "geo" : { },
  "id_str" : "297420608738824192",
  "in_reply_to_user_id" : 670283,
  "text" : "@drbrain @evanphx @markimbriaco @raggi Yes!!! You guys are awesome. Thanks for being patient and fixing shit.",
  "id" : 297420608738824192,
  "in_reply_to_status_id" : 297416588355829760,
  "created_at" : "2013-02-01 19:06:13 +0000",
  "in_reply_to_screen_name" : "drbrain",
  "in_reply_to_user_id_str" : "670283",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 14, 22 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 23, 31 ],
      "id_str" : "670283",
      "id" : 670283
    }, {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "indices" : [ 32, 45 ],
      "id_str" : "9887162",
      "id" : 9887162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/SmeubFeu",
      "expanded_url" : "http:\/\/blog.rubygems.org\/2013\/01\/31\/data-verification.html",
      "display_url" : "blog.rubygems.org\/2013\/01\/31\/dat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297412343128797184",
  "text" : "Big thanks to @evanphx @drbrain @markimbriaco for this - http:\/\/t.co\/SmeubFeu",
  "id" : 297412343128797184,
  "created_at" : "2013-02-01 18:33:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/NXkXYi7y",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/14651551\/my-kids-yell-a-lot-when-playing-games-on-computer",
      "display_url" : "stackoverflow.com\/questions\/1465\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297397325972779008",
  "text" : "World's Greatest Dad mug today goes to: http:\/\/t.co\/NXkXYi7y",
  "id" : 297397325972779008,
  "created_at" : "2013-02-01 17:33:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabe",
      "screen_name" : "cwgabriel",
      "indices" : [ 4, 14 ],
      "id_str" : "14464369",
      "id" : 14464369
    }, {
      "name" : "Tycho Brahe",
      "screen_name" : "TychoBrahe",
      "indices" : [ 15, 26 ],
      "id_str" : "14303746",
      "id" : 14303746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297395601761525760",
  "text" : "Hey @cwgabriel @TychoBrahe - The high-rez comics are gorgeous - please keep them.",
  "id" : 297395601761525760,
  "created_at" : "2013-02-01 17:26:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 3, 11 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/j66GDsn5",
      "expanded_url" : "http:\/\/tonyarcieri.com\/lets-figure-out-a-way-to-start-signing-rubygems",
      "display_url" : "tonyarcieri.com\/lets-figure-ou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297394837370589184",
  "text" : "RT @bascule: Let's figure out a way to start signing RubyGems: http:\/\/t.co\/j66GDsn5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/j66GDsn5",
        "expanded_url" : "http:\/\/tonyarcieri.com\/lets-figure-out-a-way-to-start-signing-rubygems",
        "display_url" : "tonyarcieri.com\/lets-figure-ou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "297392417374617601",
    "text" : "Let's figure out a way to start signing RubyGems: http:\/\/t.co\/j66GDsn5",
    "id" : 297392417374617601,
    "created_at" : "2013-02-01 17:14:12 +0000",
    "user" : {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "protected" : false,
      "id_str" : "6083342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450061818606522368\/pjDTHFB9_normal.jpeg",
      "id" : 6083342,
      "verified" : false
    }
  },
  "id" : 297394837370589184,
  "created_at" : "2013-02-01 17:23:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    }, {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 71, 77 ],
      "id_str" : "12459132",
      "id" : 12459132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297228089765818369",
  "geo" : { },
  "id_str" : "297228713500758016",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes time for cocoacutter ! Mostly serious. Know an gem server. \/cc @alloy",
  "id" : 297228713500758016,
  "in_reply_to_status_id" : 297228089765818369,
  "created_at" : "2013-02-01 06:23:42 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297227291040309248",
  "geo" : { },
  "id_str" : "297227654292205568",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes I won\u2019t harp on the answer here ;) people who care about this need to push forward without Apple.",
  "id" : 297227654292205568,
  "in_reply_to_status_id" : 297227291040309248,
  "created_at" : "2013-02-01 06:19:29 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nat Welch",
      "screen_name" : "icco",
      "indices" : [ 0, 5 ],
      "id_str" : "3576561",
      "id" : 3576561
    }, {
      "name" : "Bob Aman",
      "screen_name" : "sporkmonger",
      "indices" : [ 17, 29 ],
      "id_str" : "787741",
      "id" : 787741
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 33, 45 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 61, 69 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297198597823426563",
  "geo" : { },
  "id_str" : "297224342062895104",
  "in_reply_to_user_id" : 3576561,
  "text" : "@icco yes! Maybe @sporkmonger or @juliepagano can help? Ping @evanphx about getting set up.",
  "id" : 297224342062895104,
  "in_reply_to_status_id" : 297198597823426563,
  "created_at" : "2013-02-01 06:06:19 +0000",
  "in_reply_to_screen_name" : "icco",
  "in_reply_to_user_id_str" : "3576561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack Rochester",
      "screen_name" : "OpenHackROC",
      "indices" : [ 3, 15 ],
      "id_str" : "995641087",
      "id" : 995641087
    }, {
      "name" : "OpenHack Rochester",
      "screen_name" : "OpenHackROC",
      "indices" : [ 65, 77 ],
      "id_str" : "995641087",
      "id" : 995641087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/AY1ULv7F",
      "expanded_url" : "http:\/\/nextplex.com\/rochester-ny\/calendar\/events\/3432-openhack-rochester",
      "display_url" : "nextplex.com\/rochester-ny\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297223447497564161",
  "text" : "RT @OpenHackROC: We had a great turnout last night for the first @OpenHackROC! The next one is Wed Feb 27th at 7pm. Info &amp; RSVPs her ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack Rochester",
        "screen_name" : "OpenHackROC",
        "indices" : [ 48, 60 ],
        "id_str" : "995641087",
        "id" : 995641087
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 142 ],
        "url" : "http:\/\/t.co\/AY1ULv7F",
        "expanded_url" : "http:\/\/nextplex.com\/rochester-ny\/calendar\/events\/3432-openhack-rochester",
        "display_url" : "nextplex.com\/rochester-ny\/c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "297085801731330048",
    "text" : "We had a great turnout last night for the first @OpenHackROC! The next one is Wed Feb 27th at 7pm. Info &amp; RSVPs here: http:\/\/t.co\/AY1ULv7F",
    "id" : 297085801731330048,
    "created_at" : "2013-01-31 20:55:49 +0000",
    "user" : {
      "name" : "OpenHack Rochester",
      "screen_name" : "OpenHackROC",
      "protected" : false,
      "id_str" : "995641087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2944655998\/17e71fa7b6d4114ea34ae4b918efdd4b_normal.png",
      "id" : 995641087,
      "verified" : false
    }
  },
  "id" : 297223447497564161,
  "created_at" : "2013-02-01 06:02:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHackD8N",
      "screen_name" : "OpenHackD8N",
      "indices" : [ 3, 15 ],
      "id_str" : "1093158055",
      "id" : 1093158055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/XkHN74J2",
      "expanded_url" : "http:\/\/www.meetup.com\/daytonrb\/events\/99451752\/",
      "display_url" : "meetup.com\/daytonrb\/event\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297223424793784321",
  "text" : "RT @OpenHackD8N: Only one week until Dayton's first OpenHack! Be sure to reserve your seat! http:\/\/t.co\/XkHN74J2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/XkHN74J2",
        "expanded_url" : "http:\/\/www.meetup.com\/daytonrb\/events\/99451752\/",
        "display_url" : "meetup.com\/daytonrb\/event\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "297100242615169025",
    "text" : "Only one week until Dayton's first OpenHack! Be sure to reserve your seat! http:\/\/t.co\/XkHN74J2",
    "id" : 297100242615169025,
    "created_at" : "2013-01-31 21:53:12 +0000",
    "user" : {
      "name" : "OpenHackD8N",
      "screen_name" : "OpenHackD8N",
      "protected" : false,
      "id_str" : "1093158055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3113776332\/4b1be1b9600913604bed891a097a141e_normal.png",
      "id" : 1093158055,
      "verified" : false
    }
  },
  "id" : 297223424793784321,
  "created_at" : "2013-02-01 06:02:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DockYard",
      "screen_name" : "DockYard",
      "indices" : [ 3, 12 ],
      "id_str" : "18545770",
      "id" : 18545770
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 35, 44 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DockYard\/status\/297135882941632512\/photo\/1",
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/GG5nLChH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BB-jguECEAMNBzQ.jpg",
      "id_str" : "297135882945826819",
      "id" : 297135882945826819,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BB-jguECEAMNBzQ.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/GG5nLChH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297223171248103424",
  "text" : "RT @DockYard: Full house at Boston @OpenHack! http:\/\/t.co\/GG5nLChH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 21, 30 ],
        "id_str" : "715440464",
        "id" : 715440464
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DockYard\/status\/297135882941632512\/photo\/1",
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/GG5nLChH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BB-jguECEAMNBzQ.jpg",
        "id_str" : "297135882945826819",
        "id" : 297135882945826819,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BB-jguECEAMNBzQ.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/GG5nLChH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297135882941632512",
    "text" : "Full house at Boston @OpenHack! http:\/\/t.co\/GG5nLChH",
    "id" : 297135882941632512,
    "created_at" : "2013-02-01 00:14:49 +0000",
    "user" : {
      "name" : "DockYard",
      "screen_name" : "DockYard",
      "protected" : false,
      "id_str" : "18545770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000606125141\/c367193b2bf7b32dad02e39c9db058f5_normal.jpeg",
      "id" : 18545770,
      "verified" : false
    }
  },
  "id" : 297223171248103424,
  "created_at" : "2013-02-01 06:01:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 3, 15 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 24, 33 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297223159692816384",
  "text" : "RT @bcardarella: Boston @OpenHack 4.0 is coming to a close. Lots of good coding done tonight",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 7, 16 ],
        "id_str" : "715440464",
        "id" : 715440464
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297172955685863424",
    "text" : "Boston @OpenHack 4.0 is coming to a close. Lots of good coding done tonight",
    "id" : 297172955685863424,
    "created_at" : "2013-02-01 02:42:08 +0000",
    "user" : {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "protected" : false,
      "id_str" : "18787589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000553511645\/21a9348ff9f9ff11f9278695b8afa76d_normal.jpeg",
      "id" : 18787589,
      "verified" : false
    }
  },
  "id" : 297223159692816384,
  "created_at" : "2013-02-01 06:01:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Youngman",
      "screen_name" : "nathany",
      "indices" : [ 0, 8 ],
      "id_str" : "7145962",
      "id" : 7145962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297221719373000704",
  "geo" : { },
  "id_str" : "297222179244883970",
  "in_reply_to_user_id" : 7145962,
  "text" : "@nathany haven\u2019t read those. This is part of the problem- there should be a place we can point to as a community.",
  "id" : 297222179244883970,
  "in_reply_to_status_id" : 297221719373000704,
  "created_at" : "2013-02-01 05:57:44 +0000",
  "in_reply_to_screen_name" : "nathany",
  "in_reply_to_user_id_str" : "7145962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297220909876510720",
  "geo" : { },
  "id_str" : "297221538057449473",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald \u201C$DEITY help whoever must maintain his code\u201D is what I\u2019m contemplating",
  "id" : 297221538057449473,
  "in_reply_to_status_id" : 297220909876510720,
  "created_at" : "2013-02-01 05:55:11 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297216699336376320",
  "geo" : { },
  "id_str" : "297219984579518464",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald I love posts like this. Such hubris that is now immortalized.",
  "id" : 297219984579518464,
  "in_reply_to_status_id" : 297216699336376320,
  "created_at" : "2013-02-01 05:49:01 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297219184675397632",
  "geo" : { },
  "id_str" : "297219472920563712",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded I wish these were official - all of his songs are great.",
  "id" : 297219472920563712,
  "in_reply_to_status_id" : 297219184675397632,
  "created_at" : "2013-02-01 05:46:59 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Steinberger",
      "screen_name" : "steipete",
      "indices" : [ 0, 9 ],
      "id_str" : "25401953",
      "id" : 25401953
    }, {
      "name" : "Kevin",
      "screen_name" : "kvnsmth",
      "indices" : [ 10, 18 ],
      "id_str" : "6796662",
      "id" : 6796662
    }, {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 19, 26 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297216038976761857",
  "geo" : { },
  "id_str" : "297219220914188288",
  "in_reply_to_user_id" : 25401953,
  "text" : "@steipete @kvnsmth @soffes this doesn\u2019t solve dependency resolution - one step forward, two back.",
  "id" : 297219220914188288,
  "in_reply_to_status_id" : 297216038976761857,
  "created_at" : "2013-02-01 05:45:58 +0000",
  "in_reply_to_screen_name" : "steipete",
  "in_reply_to_user_id_str" : "25401953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
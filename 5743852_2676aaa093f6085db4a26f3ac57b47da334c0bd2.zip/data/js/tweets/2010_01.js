Grailbird.data.tweets_2010_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8487268352",
  "text" : "Video: 10 minute rush jam with billy sheehan. http:\/\/tumblr.com\/x17612svu",
  "id" : 8487268352,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8508912897",
  "text" : "This is my new favorite comic. http:\/\/axecop.com",
  "id" : 8508912897,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    }, {
      "name" : "Tender",
      "screen_name" : "tenderapp",
      "indices" : [ 17, 27 ],
      "id_str" : "17351175",
      "id" : 17351175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8509633951",
  "geo" : { },
  "id_str" : "8509674059",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y looks like @tenderapp marked it as spam, i've let it through.",
  "id" : 8509674059,
  "in_reply_to_status_id" : 8509633951,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 0, 3 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8515656899",
  "geo" : { },
  "id_str" : "8516116241",
  "in_reply_to_user_id" : 937561,
  "text" : "@jm sudo gem update --system didn't work?",
  "id" : 8516116241,
  "in_reply_to_status_id" : 8515656899,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "jm",
  "in_reply_to_user_id_str" : "937561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 0, 3 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8516146858",
  "geo" : { },
  "id_str" : "8516459182",
  "in_reply_to_user_id" : 937561,
  "text" : "@jm this is the kind of stuff we need on http:\/\/help.rubygems.org. think you could gist the commands you ran?",
  "id" : 8516459182,
  "in_reply_to_status_id" : 8516146858,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "jm",
  "in_reply_to_user_id_str" : "937561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anlek Consulting",
      "screen_name" : "anlek",
      "indices" : [ 0, 6 ],
      "id_str" : "51178003",
      "id" : 51178003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8516265306",
  "geo" : { },
  "id_str" : "8517632146",
  "in_reply_to_user_id" : 51178003,
  "text" : "@anlek upgrade your rubygems!",
  "id" : 8517632146,
  "in_reply_to_status_id" : 8516265306,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "anlek",
  "in_reply_to_user_id_str" : "51178003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "indices" : [ 0, 8 ],
      "id_str" : "6532552",
      "id" : 6532552
    }, {
      "name" : "Sean Chambers",
      "screen_name" : "schambers",
      "indices" : [ 9, 19 ],
      "id_str" : "8372122",
      "id" : 8372122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8474036477",
  "in_reply_to_user_id" : 6532552,
  "text" : "@nkohari @schambers does fluentmigrator work with sqlserver? having a hell of a time with connection strings.",
  "id" : 8474036477,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "nkohari",
  "in_reply_to_user_id_str" : "6532552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 55, 65 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8475397862",
  "text" : "Gathering some stats for the January '10 changelog for @gemcutter. 4,097,716 downloads for the month of January. Wow.",
  "id" : 8475397862,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 22, 32 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8477118509",
  "text" : "January changelog for @gemcutter, with juicy stats and a screencast! http:\/\/is.gd\/7rKSy",
  "id" : 8477118509,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 0, 3 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8483808873",
  "geo" : { },
  "id_str" : "8484105996",
  "in_reply_to_user_id" : 937561,
  "text" : "@jm Just seems to about without any output for `rake test`. wtf?",
  "id" : 8484105996,
  "in_reply_to_status_id" : 8483808873,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "jm",
  "in_reply_to_user_id_str" : "937561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8486338894",
  "text" : "Major yak shaving to get CLIM setup on my machine. So glad rubygems\/gemcutter makes this trivial for ruby.",
  "id" : 8486338894,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8440474158",
  "text" : "Current status: http:\/\/twitgoo.com\/cqeft",
  "id" : 8440474158,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Bloch",
      "screen_name" : "matthewbloch",
      "indices" : [ 0, 13 ],
      "id_str" : "32070959",
      "id" : 32070959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8441197291",
  "geo" : { },
  "id_str" : "8443403360",
  "in_reply_to_user_id" : 32070959,
  "text" : "@matthewbloch s3 lets us publish gems instantly, not sure how going back to relying on mirrors would help. what's the problem you're fixing?",
  "id" : 8443403360,
  "in_reply_to_status_id" : 8441197291,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "matthewbloch",
  "in_reply_to_user_id_str" : "32070959",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Bloch",
      "screen_name" : "matthewbloch",
      "indices" : [ 0, 13 ],
      "id_str" : "32070959",
      "id" : 32070959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8451838302",
  "geo" : { },
  "id_str" : "8454932102",
  "in_reply_to_user_id" : 32070959,
  "text" : "@matthewbloch `gem mirror` runs hit the site daily, don't worry about it. maybe consider using a gem webhook? http:\/\/is.gd\/7pUFX",
  "id" : 8454932102,
  "in_reply_to_status_id" : 8451838302,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "matthewbloch",
  "in_reply_to_user_id_str" : "32070959",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8467977307",
  "text" : "Connecting to a development database on another server...ugh.",
  "id" : 8467977307,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8396665277",
  "text" : "Avatar was a visual feast, but my head hurts from being out of focus so much with the 3D.",
  "id" : 8396665277,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 16, 26 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8397128754",
  "text" : "So many awesome @gemcutter patches to merge this weekend. Going to be busy.",
  "id" : 8397128754,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "actsasflinn",
      "screen_name" : "actsasflinn",
      "indices" : [ 3, 15 ],
      "id_str" : "16051211",
      "id" : 16051211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8401948090",
  "text" : "RT @actsasflinn: MessagePack for Ruby benchmark vs similar data interchange\/serialization utilities: http:\/\/gist.github.com\/290425",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8400535445",
    "text" : "MessagePack for Ruby benchmark vs similar data interchange\/serialization utilities: http:\/\/gist.github.com\/290425",
    "id" : 8400535445,
    "created_at" : "2010-01-30 05:14:20 +0000",
    "user" : {
      "name" : "actsasflinn",
      "screen_name" : "actsasflinn",
      "protected" : false,
      "id_str" : "16051211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636980253\/bender_normal.png",
      "id" : 16051211,
      "verified" : false
    }
  },
  "id" : 8401948090,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8418030214",
  "text" : "GitX is such an essential tool for dealing with tons of remotes + branches. How was this even possible before git?",
  "id" : 8418030214,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sepic",
      "screen_name" : "csepic",
      "indices" : [ 0, 7 ],
      "id_str" : "14493875",
      "id" : 14493875
    }, {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 16, 23 ],
      "id_str" : "3928731",
      "id" : 3928731
    }, {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 28, 37 ],
      "id_str" : "21431343",
      "id" : 21431343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8417435510",
  "geo" : { },
  "id_str" : "8418160982",
  "in_reply_to_user_id" : 14493875,
  "text" : "@csepic i blame @cssboy and @bostonrb. best feature of the site.",
  "id" : 8418160982,
  "in_reply_to_status_id" : 8417435510,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "csepic",
  "in_reply_to_user_id_str" : "14493875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Smick",
      "screen_name" : "sprsquish",
      "indices" : [ 0, 10 ],
      "id_str" : "2296675008",
      "id" : 2296675008
    }, {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 11, 18 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8418148481",
  "geo" : { },
  "id_str" : "8420055895",
  "in_reply_to_user_id" : 3732061,
  "text" : "@sprsquish @tekkub I just use it for viewing commits, not for actually committing\/fetching etc. Can't beat cmdline for that.",
  "id" : 8420055895,
  "in_reply_to_status_id" : 8418148481,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrsprsquish",
  "in_reply_to_user_id_str" : "3732061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gareth Rushgrove",
      "screen_name" : "garethr",
      "indices" : [ 0, 8 ],
      "id_str" : "80703",
      "id" : 80703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8420340828",
  "geo" : { },
  "id_str" : "8420462703",
  "in_reply_to_user_id" : 80703,
  "text" : "@garethr that's the CloudFront endpoint, so it won't show anything. what's the problem?",
  "id" : 8420462703,
  "in_reply_to_status_id" : 8420340828,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "garethr",
  "in_reply_to_user_id_str" : "80703",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gareth Rushgrove",
      "screen_name" : "garethr",
      "indices" : [ 0, 8 ],
      "id_str" : "80703",
      "id" : 80703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8420826795",
  "geo" : { },
  "id_str" : "8420936869",
  "in_reply_to_user_id" : 80703,
  "text" : "@garethr It's definitely working here. http:\/\/gist.github.com\/290672 Maybe the europe CF edge is being stupid?",
  "id" : 8420936869,
  "in_reply_to_status_id" : 8420826795,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "garethr",
  "in_reply_to_user_id_str" : "80703",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew France",
      "screen_name" : "Odaeus",
      "indices" : [ 0, 7 ],
      "id_str" : "2143331",
      "id" : 2143331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8344709807",
  "geo" : { },
  "id_str" : "8345759686",
  "in_reply_to_user_id" : 2143331,
  "text" : "@Odaeus i find ~&gt; confusing as well...could definitely patch up RubyGems to make it more clear. I'll see why you can't comment, that sucks.",
  "id" : 8345759686,
  "in_reply_to_status_id" : 8344709807,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "Odaeus",
  "in_reply_to_user_id_str" : "2143331",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8353994834",
  "text" : "OH: You're not a general purpose language without Array#flatten.",
  "id" : 8353994834,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "Ryan Carmelo Briones",
      "screen_name" : "ryanbriones",
      "indices" : [ 13, 25 ],
      "id_str" : "6144652",
      "id" : 6144652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8373474229",
  "geo" : { },
  "id_str" : "8373545841",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines @ryanbriones where exactly is that going to be located? great lakes of erie and ontario would like to know :)",
  "id" : 8373545841,
  "in_reply_to_status_id" : 8373474229,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Carmelo Briones",
      "screen_name" : "ryanbriones",
      "indices" : [ 0, 12 ],
      "id_str" : "6144652",
      "id" : 6144652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8373570922",
  "geo" : { },
  "id_str" : "8373871049",
  "in_reply_to_user_id" : 6144652,
  "text" : "@ryanbriones should just call it michigan ruby bash... 6.5 hours from here. http:\/\/is.gd\/7isaT",
  "id" : 8373871049,
  "in_reply_to_status_id" : 8373570922,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryanbriones",
  "in_reply_to_user_id_str" : "6144652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Carmelo Briones",
      "screen_name" : "ryanbriones",
      "indices" : [ 0, 12 ],
      "id_str" : "6144652",
      "id" : 6144652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8374066058",
  "geo" : { },
  "id_str" : "8374335661",
  "in_reply_to_user_id" : 6144652,
  "text" : "@ryanbriones duly noted, but still way out of the way for NY'ers...and we definitely have some great lakes here :)",
  "id" : 8374335661,
  "in_reply_to_status_id" : 8374066058,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryanbriones",
  "in_reply_to_user_id_str" : "6144652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Tran",
      "screen_name" : "mqt",
      "indices" : [ 0, 4 ],
      "id_str" : "3667221",
      "id" : 3667221
    }, {
      "name" : "Kevin Burg",
      "screen_name" : "kevinburg",
      "indices" : [ 47, 57 ],
      "id_str" : "10852412",
      "id" : 10852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8379916663",
  "geo" : { },
  "id_str" : "8380458090",
  "in_reply_to_user_id" : 3667221,
  "text" : "@mqt Which version are you looking for? before @kevinburg made it awesome with the redesign or with the READY SET GO stuff?",
  "id" : 8380458090,
  "in_reply_to_status_id" : 8379916663,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "mqt",
  "in_reply_to_user_id_str" : "3667221",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8387363652",
  "text" : "Who brings 17 people to a chain restaurant without calling ahead at dinner rush? THAT guy.",
  "id" : 8387363652,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8301739777",
  "text" : "Facebook accidentally its whole layout.",
  "id" : 8301739777,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIT",
      "indices" : [ 12, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8305811828",
  "text" : "wifi in the #RIT laundry rooms ftw!",
  "id" : 8305811828,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew France",
      "screen_name" : "Odaeus",
      "indices" : [ 0, 7 ],
      "id_str" : "2143331",
      "id" : 2143331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8306044316",
  "geo" : { },
  "id_str" : "8306478169",
  "in_reply_to_user_id" : 2143331,
  "text" : "@Odaeus what's wrong with it? post an issue at http:\/\/help.rubygems.org and we'll get it figured out.",
  "id" : 8306478169,
  "in_reply_to_status_id" : 8306044316,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Odaeus",
  "in_reply_to_user_id_str" : "2143331",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8308395850",
  "text" : "RT @thoughtbot: we're hiring a designer & developer: http:\/\/thoughtbot.com\/jobs if you consider a move to boston, an oldie: http:\/\/bit.l ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8045208109",
    "text" : "we're hiring a designer & developer: http:\/\/thoughtbot.com\/jobs if you consider a move to boston, an oldie: http:\/\/bit.ly\/7XFOHF",
    "id" : 8045208109,
    "created_at" : "2010-01-21 22:58:44 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 8308395850,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8327446115",
  "text" : "\"Here you go. It\u2019s five hundred dollars. If you pay me that, I will give you this magical thing that can do anything.\" http:\/\/is.gd\/7dXfZ",
  "id" : 8327446115,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Mayer",
      "screen_name" : "danmayer",
      "indices" : [ 0, 9 ],
      "id_str" : "14630648",
      "id" : 14630648
    }, {
      "name" : "nap.tld, ltd.",
      "screen_name" : "zapnap",
      "indices" : [ 75, 82 ],
      "id_str" : "1566201",
      "id" : 1566201
    }, {
      "name" : "Jeff Rafter",
      "screen_name" : "jeffrafter",
      "indices" : [ 85, 96 ],
      "id_str" : "4176991",
      "id" : 4176991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8327942956",
  "geo" : { },
  "id_str" : "8328108031",
  "in_reply_to_user_id" : 14630648,
  "text" : "@danmayer nice! now we just need to get rdoc.info up to speed... \/me pokes @zapnap & @jeffrafter",
  "id" : 8328108031,
  "in_reply_to_status_id" : 8327942956,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "danmayer",
  "in_reply_to_user_id_str" : "14630648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Mayer",
      "screen_name" : "danmayer",
      "indices" : [ 0, 9 ],
      "id_str" : "14630648",
      "id" : 14630648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8329424494",
  "geo" : { },
  "id_str" : "8331354389",
  "in_reply_to_user_id" : 14630648,
  "text" : "@danmayer hoping to this weekend. Plenty of patches that need to be merged.",
  "id" : 8331354389,
  "in_reply_to_status_id" : 8329424494,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "danmayer",
  "in_reply_to_user_id_str" : "14630648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francisco ruiz",
      "screen_name" : "Paco36",
      "indices" : [ 36, 43 ],
      "id_str" : "2460224676",
      "id" : 2460224676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8342120580",
  "text" : "Google App Engine talk tonight from @paco36!",
  "id" : 8342120580,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew France",
      "screen_name" : "Odaeus",
      "indices" : [ 0, 7 ],
      "id_str" : "2143331",
      "id" : 2143331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8343354403",
  "geo" : { },
  "id_str" : "8343917509",
  "in_reply_to_user_id" : 2143331,
  "text" : "@Odaeus what issue? been in classes most of the day and generally aloof to email",
  "id" : 8343917509,
  "in_reply_to_status_id" : 8343354403,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Odaeus",
  "in_reply_to_user_id_str" : "2143331",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8261435537",
  "geo" : { },
  "id_str" : "8261555736",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan it makes me depressed to. at least PostBacks and ViewState have been taken out behind the shed and shot.",
  "id" : 8261555736,
  "in_reply_to_status_id" : 8261435537,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8264732168",
  "text" : "I love writing infinite loops in web apps. http:\/\/gist.github.com\/287521",
  "id" : 8264732168,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan",
      "screen_name" : "evan",
      "indices" : [ 0, 5 ],
      "id_str" : "761613",
      "id" : 761613
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 42, 53 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8264878321",
  "geo" : { },
  "id_str" : "8265006022",
  "in_reply_to_user_id" : 761613,
  "text" : "@evan oh man, jealous. my SNES was at the @thoughtbot office while I was in boston...intense tetris attack matches will return!",
  "id" : 8265006022,
  "in_reply_to_status_id" : 8264878321,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "evan",
  "in_reply_to_user_id_str" : "761613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8268619857",
  "text" : "Very tempted to take a class that teaches Go (http:\/\/golang.org\/) in the Computer Science department next quarter...",
  "id" : 8268619857,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8274988266",
  "text" : "Registering for classes for THE LAST TIME EVER.",
  "id" : 8274988266,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hyett",
      "screen_name" : "pjhyett",
      "indices" : [ 0, 8 ],
      "id_str" : "717233",
      "id" : 717233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8267847729",
  "geo" : { },
  "id_str" : "8284939679",
  "in_reply_to_user_id" : 717233,
  "text" : "@pjhyett think we can get it in the IRC notifier too? i'd switch away from CIA.vc in a heartbeat.",
  "id" : 8284939679,
  "in_reply_to_status_id" : 8267847729,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "pjhyett",
  "in_reply_to_user_id_str" : "717233",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8288160026",
  "text" : "OH MY GOD ITS A GIANT IPHONE. Go back to work.",
  "id" : 8288160026,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8290828410",
  "text" : "Apple fanboys in Java's have officially freaked out. Calling friends. Skipping work. Shouting loudly. This is the end of days.",
  "id" : 8290828410,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/screenr.com\" rel=\"nofollow\"\u003EScreenr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8213208082",
  "text" : "gem sing rake http:\/\/screenr.com\/G91",
  "id" : 8213208082,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Harris",
      "screen_name" : "haruki_zaemon",
      "indices" : [ 0, 14 ],
      "id_str" : "14439858",
      "id" : 14439858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8214165097",
  "geo" : { },
  "id_str" : "8214582918",
  "in_reply_to_user_id" : 14439858,
  "text" : "@haruki_zaemon I'm using screen with _why's old config. http:\/\/gist.github.com\/286431",
  "id" : 8214582918,
  "in_reply_to_status_id" : 8214165097,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "haruki_zaemon",
  "in_reply_to_user_id_str" : "14439858",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8239726310",
  "text" : "woot-off means it's going to be a longgg day.",
  "id" : 8239726310,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8242152599",
  "text" : "Does anyone else hate the saying \"I'll code up some $language\" ?",
  "id" : 8242152599,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8246427269",
  "text" : "I really wish Pivotal Tracker would let you manually set iteration start\/end dates. It's just too confusing and opinionated for new projects",
  "id" : 8246427269,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8246440257",
  "text" : "For example, we have 5 iterations in the tool but we're just wrapping up our first. wtf.",
  "id" : 8246440257,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8246446341",
  "text" : "I can't even modify the dates or merge them into the same one.",
  "id" : 8246446341,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8247839505",
  "text" : "Fixed Tracker for the most part by adjusting the iteration start weekday and when the project started. Thanks, folks.",
  "id" : 8247839505,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hinegardner",
      "screen_name" : "copiousfreetime",
      "indices" : [ 80, 96 ],
      "id_str" : "14601522",
      "id" : 14601522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8212715445",
  "text" : "Oh this is hilarious. gem install rubygems-sing; gem sing [installed gem]. (via @copiousfreetime)",
  "id" : 8212715445,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Cooke",
      "screen_name" : "jc00ke",
      "indices" : [ 0, 7 ],
      "id_str" : "14425908",
      "id" : 14425908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8176954394",
  "geo" : { },
  "id_str" : "8178034651",
  "in_reply_to_user_id" : 14425908,
  "text" : "@jc00ke the key in ~\/.gemrc has been deprecated, we store it in ~\/.gem\/credentials now. and yes, anyone can push your gems with that key.",
  "id" : 8178034651,
  "in_reply_to_status_id" : 8176954394,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "jc00ke",
  "in_reply_to_user_id_str" : "14425908",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Cooke",
      "screen_name" : "jc00ke",
      "indices" : [ 0, 7 ],
      "id_str" : "14425908",
      "id" : 14425908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8178143191",
  "geo" : { },
  "id_str" : "8178262637",
  "in_reply_to_user_id" : 14425908,
  "text" : "@jc00ke no problem. that's how the gemcutter gem talks to the api: http:\/\/gemcutter.org\/pages\/api_docs",
  "id" : 8178262637,
  "in_reply_to_status_id" : 8178143191,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "jc00ke",
  "in_reply_to_user_id_str" : "14425908",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Chambers",
      "screen_name" : "schambers",
      "indices" : [ 0, 10 ],
      "id_str" : "8372122",
      "id" : 8372122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8178271735",
  "geo" : { },
  "id_str" : "8178353616",
  "in_reply_to_user_id" : 8372122,
  "text" : "@schambers i think what's more important is understanding message passing as a concept. It's not magic, it's programming. http:\/\/is.gd\/6Yqv3",
  "id" : 8178353616,
  "in_reply_to_status_id" : 8178271735,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "schambers",
  "in_reply_to_user_id_str" : "8372122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Assaf",
      "screen_name" : "assaf",
      "indices" : [ 29, 35 ],
      "id_str" : "2367111",
      "id" : 2367111
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8195571649",
  "text" : "GitHub Rebase #35: featuring @assaf's vanity! Also, ptex is crazy and I wish I could grok it. http:\/\/github.com\/blog\/593-github-rebase-35",
  "id" : 8195571649,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 0, 8 ],
      "id_str" : "9337082",
      "id" : 9337082
    }, {
      "name" : "Kevin Burg",
      "screen_name" : "kevinburg",
      "indices" : [ 44, 54 ],
      "id_str" : "10852412",
      "id" : 10852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8202259861",
  "geo" : { },
  "id_str" : "8202476992",
  "in_reply_to_user_id" : 9337082,
  "text" : "@godfoca i suck at colors, there's a reason @kevinburg designed the site. i'll switch it to grey.",
  "id" : 8202476992,
  "in_reply_to_status_id" : 8202259861,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "godfoca",
  "in_reply_to_user_id_str" : "9337082",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Behrens",
      "screen_name" : "AskedRelic",
      "indices" : [ 0, 11 ],
      "id_str" : "5539522",
      "id" : 5539522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8203207562",
  "geo" : { },
  "id_str" : "8211626788",
  "in_reply_to_user_id" : 5539522,
  "text" : "@AskedRelic seems to cause bus errors on OSX. :[",
  "id" : 8211626788,
  "in_reply_to_status_id" : 8203207562,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "AskedRelic",
  "in_reply_to_user_id_str" : "5539522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8130984149",
  "text" : "Invention of Lying is blowing my mind right now. Filmed in Lawrence, MA and one scene is on the bridge I walked across daily to the T.",
  "id" : 8130984149,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 21, 30 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 71, 81 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8135125589",
  "text" : "Now this is awesome: @rubygems is reporting the latest gem pushes from @gemcutter.",
  "id" : 8135125589,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8138584472",
  "text" : "Huge party going on next door. Great.",
  "id" : 8138584472,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8138992758",
  "text" : "They're turning people away, staircase is full with people waiting. wtf.",
  "id" : 8138992758,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gabriele renzi",
      "screen_name" : "riffraff",
      "indices" : [ 0, 9 ],
      "id_str" : "446303",
      "id" : 446303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8153979023",
  "geo" : { },
  "id_str" : "8157846505",
  "in_reply_to_user_id" : 446303,
  "text" : "@riffraff check out http:\/\/railscasts.com\/episodes\/183-gemcutter-jeweler, just change the name in the gemspec.",
  "id" : 8157846505,
  "in_reply_to_status_id" : 8153979023,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "riffraff",
  "in_reply_to_user_id_str" : "446303",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "guillaume gentil",
      "screen_name" : "GuillaumeGentil",
      "indices" : [ 0, 16 ],
      "id_str" : "700308696",
      "id" : 700308696
    }, {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 44, 56 ],
      "id_str" : "6556972",
      "id" : 6556972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8160844441",
  "geo" : { },
  "id_str" : "8161768363",
  "in_reply_to_user_id" : 4629071,
  "text" : "@guillaumegentil sounds awesome, let me and @techpickles know how it goes!",
  "id" : 8161768363,
  "in_reply_to_status_id" : 8160844441,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "thibaudgg",
  "in_reply_to_user_id_str" : "4629071",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8165457805",
  "text" : "github rebase #35 nailed down, and my head decides it's time for bed at 5pm. great.",
  "id" : 8165457805,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8097944239",
  "text" : "OH: I'm kinda flying at half mast right now",
  "id" : 8097944239,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "entp",
      "screen_name" : "entp",
      "indices" : [ 101, 106 ],
      "id_str" : "14080083",
      "id" : 14080083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8116459532",
  "text" : "RT @rubygemcutter: Need help with RubyGems or Gemcutter? Head here: http:\/\/help.rubygems.org (Thanks @entp!)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "entp",
        "screen_name" : "entp",
        "indices" : [ 82, 87 ],
        "id_str" : "14080083",
        "id" : 14080083
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8116440645",
    "text" : "Need help with RubyGems or Gemcutter? Head here: http:\/\/help.rubygems.org (Thanks @entp!)",
    "id" : 8116440645,
    "created_at" : "2010-01-23 16:57:08 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 8116459532,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "indices" : [ 0, 8 ],
      "id_str" : "713263",
      "id" : 713263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8124121867",
  "geo" : { },
  "id_str" : "8124445126",
  "in_reply_to_user_id" : 713263,
  "text" : "@defunkt we should totally redesign the site that way for april fools' YE OLDE AWESOME GEM HOSTER",
  "id" : 8124445126,
  "in_reply_to_status_id" : 8124121867,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "defunkt",
  "in_reply_to_user_id_str" : "713263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8127771405",
  "text" : "Photo: US states redrawn to have equal populations. http:\/\/tumblr.com\/x175s750q",
  "id" : 8127771405,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Lyon",
      "screen_name" : "mattly",
      "indices" : [ 0, 7 ],
      "id_str" : "1768041",
      "id" : 1768041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8128090841",
  "geo" : { },
  "id_str" : "8128139405",
  "in_reply_to_user_id" : 1768041,
  "text" : "@mattly 302 is used constantly by rails and sinatra. proof: gem list -rV rails",
  "id" : 8128139405,
  "in_reply_to_status_id" : 8128090841,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mattly",
  "in_reply_to_user_id_str" : "1768041",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "Ophanin",
      "indices" : [ 0, 8 ],
      "id_str" : "15144555",
      "id" : 15144555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8052319452",
  "geo" : { },
  "id_str" : "8052431515",
  "in_reply_to_user_id" : 15144555,
  "text" : "@Ophanin I will end you.",
  "id" : 8052431515,
  "in_reply_to_status_id" : 8052319452,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Ophanin",
  "in_reply_to_user_id_str" : "15144555",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hyett",
      "screen_name" : "pjhyett",
      "indices" : [ 0, 8 ],
      "id_str" : "717233",
      "id" : 717233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8057323997",
  "geo" : { },
  "id_str" : "8057621515",
  "in_reply_to_user_id" : 717233,
  "text" : "@pjhyett it's just too much chaos for his .nets to handle. visual studio can't octopus merge!",
  "id" : 8057621515,
  "in_reply_to_status_id" : 8057323997,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "pjhyett",
  "in_reply_to_user_id_str" : "717233",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8070326640",
  "geo" : { },
  "id_str" : "8070693098",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn it doesn't really matter...we'll be moving the primary gem source to  http:\/\/rubygem.org soon",
  "id" : 8070693098,
  "in_reply_to_status_id" : 8070326640,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8070326640",
  "geo" : { },
  "id_str" : "8070697936",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn ahem, http:\/\/rubygems.org",
  "id" : 8070697936,
  "in_reply_to_status_id" : 8070326640,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8067878417",
  "geo" : { },
  "id_str" : "8070733691",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger which gem? can you gem install -V and watch what slows down? maybe we need a pingdom-style fetcher for fetch\/install...",
  "id" : 8070733691,
  "in_reply_to_status_id" : 8067878417,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8070747716",
  "geo" : { },
  "id_str" : "8070806920",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn it should just be as simple as adding another vhost, and replacing the logo. just waiting on a new rubygems release :)",
  "id" : 8070806920,
  "in_reply_to_status_id" : 8070747716,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8081155269",
  "text" : "YEAHHHHHHHHHHHHHHHHHH http:\/\/ingresstech.com\/~bernard\/instantCSI\/",
  "id" : 8081155269,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8008920738",
  "geo" : { },
  "id_str" : "8008973264",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps asp.net mvc 2? finally starting my project in it.",
  "id" : 8008973264,
  "in_reply_to_status_id" : 8008920738,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 3, 15 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8011705843",
  "text" : "RT @SaraJChipps: http:\/\/tinychat.com\/superwanparty We are declaring a National Javascript Holiday",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8011635138",
    "text" : "http:\/\/tinychat.com\/superwanparty We are declaring a National Javascript Holiday",
    "id" : 8011635138,
    "created_at" : "2010-01-21 02:53:37 +0000",
    "user" : {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "protected" : false,
      "id_str" : "15524875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475386075997683712\/TOSOGa0K_normal.png",
      "id" : 15524875,
      "verified" : false
    }
  },
  "id" : 8011705843,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8019456593",
  "text" : "You know when a good time to have a party is? 2:30am on a Wednesday night! OH WAIT WORST APARTMENT EVER.",
  "id" : 8019456593,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Tagua",
      "screen_name" : "miloops",
      "indices" : [ 0, 8 ],
      "id_str" : "14994463",
      "id" : 14994463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8027500301",
  "geo" : { },
  "id_str" : "8027978852",
  "in_reply_to_user_id" : 14994463,
  "text" : "@miloops lame...what's timing out exactly?",
  "id" : 8027978852,
  "in_reply_to_status_id" : 8027500301,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "miloops",
  "in_reply_to_user_id_str" : "14994463",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Landau",
      "screen_name" : "brianjlandau",
      "indices" : [ 0, 13 ],
      "id_str" : "2145",
      "id" : 2145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8030422935",
  "geo" : { },
  "id_str" : "8033229028",
  "in_reply_to_user_id" : 2145,
  "text" : "@brianjlandau for what gem exactly? Maybe tack -V on and watch the output.",
  "id" : 8033229028,
  "in_reply_to_status_id" : 8030422935,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "brianjlandau",
  "in_reply_to_user_id_str" : "2145",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8045073099",
  "text" : "Figured out how to use AppCmd.exe to automatically start\/stop IIS sites. That + SSH = senior project easymode.",
  "id" : 8045073099,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8046745004",
  "text" : "Deploys via BitTorrent? Holy crap. http:\/\/github.com\/lg\/murder",
  "id" : 8046745004,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tender",
      "screen_name" : "tenderapp",
      "indices" : [ 13, 23 ],
      "id_str" : "17351175",
      "id" : 17351175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7968603912",
  "text" : "Setting up a @tenderapp site for RubyGems and Gemcutter...if you have any good links\/tutorials\/FAQs pass them along!",
  "id" : 7968603912,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 58, 69 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7974298977",
  "geo" : { },
  "id_str" : "7974403414",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson I predict this is going to cause a ruckus at @thoughtbot tomorrow.",
  "id" : 7974403414,
  "in_reply_to_status_id" : 7974298977,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordi",
      "screen_name" : "jordibunster",
      "indices" : [ 0, 13 ],
      "id_str" : "1230538363",
      "id" : 1230538363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7974478820",
  "geo" : { },
  "id_str" : "7974697632",
  "in_reply_to_user_id" : 11457022,
  "text" : "@jordibunster the gem index updates all the time, cloudfront can only do once in 24 hours. it's a big problem for .gem downloads now.",
  "id" : 7974697632,
  "in_reply_to_status_id" : 7974478820,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "notlaforge",
  "in_reply_to_user_id_str" : "11457022",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordi",
      "screen_name" : "jordibunster",
      "indices" : [ 0, 13 ],
      "id_str" : "1230538363",
      "id" : 1230538363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7975107926",
  "geo" : { },
  "id_str" : "7975188179",
  "in_reply_to_user_id" : 11457022,
  "text" : "@jordibunster been wanting it for a while: http:\/\/github.com\/qrush\/gemcutter\/issues#issue\/50",
  "id" : 7975188179,
  "in_reply_to_status_id" : 7975107926,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "notlaforge",
  "in_reply_to_user_id_str" : "11457022",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Pohorecki",
      "screen_name" : "apohorecki",
      "indices" : [ 0, 11 ],
      "id_str" : "18032144",
      "id" : 18032144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7981868446",
  "geo" : { },
  "id_str" : "7989014106",
  "in_reply_to_user_id" : 18032144,
  "text" : "@apohorecki awesome, that's how it always should have worked :)",
  "id" : 7989014106,
  "in_reply_to_status_id" : 7981868446,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "apohorecki",
  "in_reply_to_user_id_str" : "18032144",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7989585096",
  "text" : "Seeing new gems off http:\/\/gemwhisperer.heroku.com available for download within a minute from Gemcutter. Great success!",
  "id" : 7989585096,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nikki graziano",
      "screen_name" : "nikkigraziano",
      "indices" : [ 0, 14 ],
      "id_str" : "12914422",
      "id" : 12914422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7991522119",
  "geo" : { },
  "id_str" : "7991604245",
  "in_reply_to_user_id" : 12914422,
  "text" : "@nikkigraziano I'm tempted to check in since I just settled in, but I'll let you have it for a few days :)",
  "id" : 7991604245,
  "in_reply_to_status_id" : 7991522119,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "nikkigraziano",
  "in_reply_to_user_id_str" : "12914422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7994030738",
  "text" : "This is awesome. http:\/\/wutangvsthebeatles.bandcamp.com\/",
  "id" : 7994030738,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7997127854",
  "text" : "Video: FOOTBALL. and jesus. and making out with his guy friends. and chevy trucks. http:\/\/tumblr.com\/x175p7lei",
  "id" : 7997127854,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UNKNOWN",
      "screen_name" : "RipTheJacker",
      "indices" : [ 0, 13 ],
      "id_str" : "16551273",
      "id" : 16551273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7997614479",
  "geo" : { },
  "id_str" : "7998255868",
  "in_reply_to_user_id" : 16551273,
  "text" : "@RipTheJacker you don't need to tell users to have gemcutter as a gem source... have you been to http:\/\/gems.rubyforge.org lately? :)",
  "id" : 7998255868,
  "in_reply_to_status_id" : 7997614479,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "RipTheJacker",
  "in_reply_to_user_id_str" : "16551273",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howland",
      "screen_name" : "backslash",
      "indices" : [ 0, 10 ],
      "id_str" : "8161622",
      "id" : 8161622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8001898506",
  "geo" : { },
  "id_str" : "8002080475",
  "in_reply_to_user_id" : 8161622,
  "text" : "@backslash good, good. let the blocks flow through you. soon you will know the dark side of the ruby.",
  "id" : 8002080475,
  "in_reply_to_status_id" : 8001898506,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "backslash",
  "in_reply_to_user_id_str" : "8161622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8002092397",
  "geo" : { },
  "id_str" : "8002102195",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety http:\/\/thefuckingweather.com",
  "id" : 8002102195,
  "in_reply_to_status_id" : 8002092397,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7954193050",
  "geo" : { },
  "id_str" : "7954373526",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror yes, and it's the present. What problems are you having?",
  "id" : 7954373526,
  "in_reply_to_status_id" : 7954193050,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7956083050",
  "text" : ".NET folks: is it worth it to start a project using ASP.NET MVC 2 that isn't finalized yet or just use the first release?",
  "id" : 7956083050,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7956900119",
  "text" : "I miss migrations already. Designing the DB all in VS' visual editor just seems wrong now.",
  "id" : 7956900119,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Norris",
      "screen_name" : "rsl",
      "indices" : [ 0, 4 ],
      "id_str" : "82863",
      "id" : 82863
    }, {
      "name" : "Michael Letterle",
      "screen_name" : "mletterle",
      "indices" : [ 24, 34 ],
      "id_str" : "458173",
      "id" : 458173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7957086357",
  "geo" : { },
  "id_str" : "7957253393",
  "in_reply_to_user_id" : 82863,
  "text" : "@rsl school. and thanks @mletterle \/ @edminstond, i'll look into it.",
  "id" : 7957253393,
  "in_reply_to_status_id" : 7957086357,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "rsl",
  "in_reply_to_user_id_str" : "82863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7957388405",
  "text" : "Coding in C# again makes me so happy that Ruby has implicit syntax.",
  "id" : 7957388405,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francisco Viramontes",
      "screen_name" : "kidpollo",
      "indices" : [ 0, 9 ],
      "id_str" : "12470832",
      "id" : 12470832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7957904126",
  "geo" : { },
  "id_str" : "7958160808",
  "in_reply_to_user_id" : 12470832,
  "text" : "@kidpollo Not at all, school project is demanding it.",
  "id" : 7958160808,
  "in_reply_to_status_id" : 7957904126,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "kidpollo",
  "in_reply_to_user_id_str" : "12470832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 114, 123 ],
      "id_str" : "9267332",
      "id" : 9267332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7924203546",
  "geo" : { },
  "id_str" : "7925591616",
  "in_reply_to_user_id" : 15359408,
  "text" : "@ra66i well if we do a redirect for the indexes like the gems instead of a 200, we'd lose HTTP caching right? \/cc @rtomayko",
  "id" : 7925591616,
  "in_reply_to_status_id" : 7924203546,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Richards",
      "screen_name" : "noahsmark",
      "indices" : [ 0, 10 ],
      "id_str" : "14198565",
      "id" : 14198565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7926849676",
  "geo" : { },
  "id_str" : "7927021900",
  "in_reply_to_user_id" : 14198565,
  "text" : "@noahsmark I agree, it should be there, just a leftover problem from the blog's design.",
  "id" : 7927021900,
  "in_reply_to_status_id" : 7926849676,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "noahsmark",
  "in_reply_to_user_id_str" : "14198565",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7928566742",
  "geo" : { },
  "id_str" : "7928588602",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense beware of hobos!",
  "id" : 7928588602,
  "in_reply_to_status_id" : 7928566742,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Burg",
      "screen_name" : "kevinburg",
      "indices" : [ 21, 31 ],
      "id_str" : "10852412",
      "id" : 10852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7931887502",
  "text" : "Loving that coworker @kevinburg's AT-AT photo is #4 on Reddit right now. http:\/\/img.skitch.com\/20100119-92mkxwiqkd1njrws65g7dw6jb.jpg",
  "id" : 7931887502,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Eppstein",
      "screen_name" : "chriseppstein",
      "indices" : [ 0, 14 ],
      "id_str" : "14148091",
      "id" : 14148091
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 49, 57 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7931002779",
  "geo" : { },
  "id_str" : "7932873545",
  "in_reply_to_user_id" : 14148091,
  "text" : "@chriseppstein several, the main one to blame is @drbrain :)",
  "id" : 7932873545,
  "in_reply_to_status_id" : 7931002779,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "chriseppstein",
  "in_reply_to_user_id_str" : "14148091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones ",
      "screen_name" : "yaychris",
      "indices" : [ 0, 9 ],
      "id_str" : "14361913",
      "id" : 14361913
    }, {
      "name" : "Guillermo Rauch",
      "screen_name" : "rauchg",
      "indices" : [ 10, 17 ],
      "id_str" : "15540222",
      "id" : 15540222
    }, {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 91, 98 ],
      "id_str" : "3928731",
      "id" : 3928731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7933025192",
  "geo" : { },
  "id_str" : "7933274598",
  "in_reply_to_user_id" : 14361913,
  "text" : "@yaychris @rauchg you could blame me, but i'd rather blame http:\/\/bostonrb.org\/sign_in and @cssboy instead",
  "id" : 7933274598,
  "in_reply_to_status_id" : 7933025192,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "yaychris",
  "in_reply_to_user_id_str" : "14361913",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 72, 86 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7933562141",
  "geo" : { },
  "id_str" : "7933858776",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything http:\/\/960.gs has always been good to me. i'm wondering when @joshuaclayton will prove this otherwise.",
  "id" : 7933858776,
  "in_reply_to_status_id" : 7933562141,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7933883204",
  "geo" : { },
  "id_str" : "7934093882",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything http:\/\/gitready.com is pretty standard 960.js...a bit conforming but it's better when you're someone with no design skills",
  "id" : 7934093882,
  "in_reply_to_status_id" : 7933883204,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrei Maxim",
      "screen_name" : "xhr",
      "indices" : [ 0, 4 ],
      "id_str" : "638793",
      "id" : 638793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7939123376",
  "geo" : { },
  "id_str" : "7950205924",
  "in_reply_to_user_id" : 638793,
  "text" : "@xhr no problem, shoot me an email at nick@gemcutter.org and we'll figure it out.",
  "id" : 7950205924,
  "in_reply_to_status_id" : 7939123376,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "xhr",
  "in_reply_to_user_id_str" : "638793",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simone Rinzivillo",
      "screen_name" : "srinzivillo",
      "indices" : [ 0, 12 ],
      "id_str" : "37885021",
      "id" : 37885021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7948170225",
  "geo" : { },
  "id_str" : "7950249623",
  "in_reply_to_user_id" : 37885021,
  "text" : "@srinzivillo oh yeah, good point. I guess we could check for robots before kicking off the Download DJ. Also, there's gem mirrors too.",
  "id" : 7950249623,
  "in_reply_to_status_id" : 7948170225,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "srinzivillo",
  "in_reply_to_user_id_str" : "37885021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7952074907",
  "geo" : { },
  "id_str" : "7952159526",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh sure, you can explain why people like hg. In class until 2 though.",
  "id" : 7952159526,
  "in_reply_to_status_id" : 7952074907,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Morearty",
      "screen_name" : "BMorearty",
      "indices" : [ 0, 10 ],
      "id_str" : "18021896",
      "id" : 18021896
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 11, 25 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7885496724",
  "geo" : { },
  "id_str" : "7887244888",
  "in_reply_to_user_id" : 18021896,
  "text" : "@BMorearty @joshuaclayton should be fixed on the next gem push, going to fix this once and for all",
  "id" : 7887244888,
  "in_reply_to_status_id" : 7885496724,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "BMorearty",
  "in_reply_to_user_id_str" : "18021896",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Sinclair",
      "screen_name" : "anathematic",
      "indices" : [ 0, 12 ],
      "id_str" : "14610920",
      "id" : 14610920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7888842096",
  "geo" : { },
  "id_str" : "7889480135",
  "in_reply_to_user_id" : 14610920,
  "text" : "@anathematic you could stick http:\/\/gemwhisperer.heroku.com in a dashboard widget. I check it on my droid all the time.",
  "id" : 7889480135,
  "in_reply_to_status_id" : 7888842096,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "anathematic",
  "in_reply_to_user_id_str" : "14610920",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Sinclair",
      "screen_name" : "anathematic",
      "indices" : [ 0, 12 ],
      "id_str" : "14610920",
      "id" : 14610920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7889539825",
  "geo" : { },
  "id_str" : "7889683743",
  "in_reply_to_user_id" : 14610920,
  "text" : "@anathematic using gem webhooks you could do that. (the whisperer runs off a global hook) http:\/\/gemcutter.org\/pages\/gem_docs#webhook",
  "id" : 7889683743,
  "in_reply_to_status_id" : 7889539825,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "anathematic",
  "in_reply_to_user_id_str" : "14610920",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7890324697",
  "text" : "Watching the ASP.NET MVC 80 minute video. Oh boy.",
  "id" : 7890324697,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7890508725",
  "geo" : { },
  "id_str" : "7890572091",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini senior project. 10 minutes in and we haven't done any coding yet! drag, drop, drag, drop....argh.",
  "id" : 7890572091,
  "in_reply_to_status_id" : 7890508725,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7891097186",
  "text" : "I'm going postal if this screencast guy says \"groovy!\" one more time.",
  "id" : 7891097186,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7891229351",
  "geo" : { },
  "id_str" : "7891284210",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan it's like going back to rails 1.2.6. and using 100 dialog boxes to configure your app instead.",
  "id" : 7891284210,
  "in_reply_to_status_id" : 7891229351,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Chambers",
      "screen_name" : "schambers",
      "indices" : [ 0, 10 ],
      "id_str" : "8372122",
      "id" : 8372122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7891345102",
  "geo" : { },
  "id_str" : "7891431061",
  "in_reply_to_user_id" : 8372122,
  "text" : "@schambers ruby view options are awesome. check out mustache and effigy too.",
  "id" : 7891431061,
  "in_reply_to_status_id" : 7891345102,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "schambers",
  "in_reply_to_user_id_str" : "8372122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7892030829",
  "text" : "And the after the fifth \"groovy\" I'm done with that tutorial.",
  "id" : 7892030829,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7892615705",
  "geo" : { },
  "id_str" : "7892759801",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek I made it halfway through, don't I get some credit for that? I mean, they started talking about ViewModels and my brain melted.",
  "id" : 7892759801,
  "in_reply_to_status_id" : 7892615705,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Bleigh",
      "screen_name" : "mbleigh",
      "indices" : [ 0, 8 ],
      "id_str" : "12025282",
      "id" : 12025282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7904349015",
  "geo" : { },
  "id_str" : "7905419303",
  "in_reply_to_user_id" : 12025282,
  "text" : "@mbleigh all gems. Maybe the docs should be clearer about that...",
  "id" : 7905419303,
  "in_reply_to_status_id" : 7904349015,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "mbleigh",
  "in_reply_to_user_id_str" : "12025282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Pohorecki",
      "screen_name" : "apohorecki",
      "indices" : [ 0, 11 ],
      "id_str" : "18032144",
      "id" : 18032144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7898037945",
  "geo" : { },
  "id_str" : "7906715612",
  "in_reply_to_user_id" : 18032144,
  "text" : "@apohorecki i'm going to look into it today, i'm not sure why it's taking so long either.",
  "id" : 7906715612,
  "in_reply_to_status_id" : 7898037945,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "apohorecki",
  "in_reply_to_user_id_str" : "18032144",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Pohorecki",
      "screen_name" : "apohorecki",
      "indices" : [ 0, 11 ],
      "id_str" : "18032144",
      "id" : 18032144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7898037945",
  "geo" : { },
  "id_str" : "7908927446",
  "in_reply_to_user_id" : 18032144,
  "text" : "@apohorecki when did you push your gem and when could you download it? my tests show it's less than a minute to update the index on staging",
  "id" : 7908927446,
  "in_reply_to_status_id" : 7898037945,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "apohorecki",
  "in_reply_to_user_id_str" : "18032144",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7909972732",
  "text" : "Does anyone know if S3 has a limit on how often a key can be updated? This is one theory for Gemcutter's indexing delays.",
  "id" : 7909972732,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7912694387",
  "geo" : { },
  "id_str" : "7913001487",
  "in_reply_to_user_id" : 15359408,
  "text" : "@ra66i then we go back to mirroring hell and lose CDNs all over the globe. serving gems is working fine, indexing is a different problem",
  "id" : 7913001487,
  "in_reply_to_status_id" : 7912694387,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Timewell",
      "screen_name" : "idlefingers",
      "indices" : [ 0, 12 ],
      "id_str" : "13718882",
      "id" : 13718882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7911630859",
  "geo" : { },
  "id_str" : "7913563004",
  "in_reply_to_user_id" : 13718882,
  "text" : "@idlefingers old habits die hard, i guess. i need to use gem search more often :)",
  "id" : 7913563004,
  "in_reply_to_status_id" : 7911630859,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "idlefingers",
  "in_reply_to_user_id_str" : "13718882",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7913279282",
  "geo" : { },
  "id_str" : "7913593404",
  "in_reply_to_user_id" : 15359408,
  "text" : "@ra66i what's the delay in? I bet it's in downloading craploads of gemspecs  and not fetching the gem from CloudFront's europe CDN",
  "id" : 7913593404,
  "in_reply_to_status_id" : 7913279282,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7913325886",
  "geo" : { },
  "id_str" : "7913603579",
  "in_reply_to_user_id" : 15359408,
  "text" : "@ra66i seriously, try doing gem install -V cucumber and watch all of the gemspecs it downloads.",
  "id" : 7913603579,
  "in_reply_to_status_id" : 7913325886,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7913963875",
  "geo" : { },
  "id_str" : "7914190785",
  "in_reply_to_user_id" : 15359408,
  "text" : "@ra66i yeah, specs.4.8.gz runs out to s3 and serves it in the request, it sucks. iirc rubygems isn't smart enough to redirect that",
  "id" : 7914190785,
  "in_reply_to_status_id" : 7913963875,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7917012226",
  "geo" : { },
  "id_str" : "7917595491",
  "in_reply_to_user_id" : 15359408,
  "text" : "@ra66i if you can nail down when\/where and for what the resets happen i'd love to fix that too. I haven't seen any lately on my end.",
  "id" : 7917595491,
  "in_reply_to_status_id" : 7917012226,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Demaree",
      "screen_name" : "ddemaree",
      "indices" : [ 0, 9 ],
      "id_str" : "16683",
      "id" : 16683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7920554225",
  "geo" : { },
  "id_str" : "7921029077",
  "in_reply_to_user_id" : 16683,
  "text" : "@ddemaree we use highlight.js http:\/\/softwaremaniacs.org\/soft\/highlight\/en\/",
  "id" : 7921029077,
  "in_reply_to_status_id" : 7920554225,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ddemaree",
  "in_reply_to_user_id_str" : "16683",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KMAN",
      "screen_name" : "kblake",
      "indices" : [ 0, 7 ],
      "id_str" : "946471",
      "id" : 946471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7842369587",
  "geo" : { },
  "id_str" : "7846618231",
  "in_reply_to_user_id" : 946471,
  "text" : "@kblake you shouldn't need to add gemcutter as a source, have you been to http:\/\/gems.rubyforge.org lately? :)",
  "id" : 7846618231,
  "in_reply_to_status_id" : 7842369587,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "kblake",
  "in_reply_to_user_id_str" : "946471",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Smick",
      "screen_name" : "sprsquish",
      "indices" : [ 0, 10 ],
      "id_str" : "2296675008",
      "id" : 2296675008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7846359391",
  "geo" : { },
  "id_str" : "7846698438",
  "in_reply_to_user_id" : 3732061,
  "text" : "@sprsquish shoot me an email (nick@gemcutter.org) and i'll get you hooked up.",
  "id" : 7846698438,
  "in_reply_to_status_id" : 7846359391,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrsprsquish",
  "in_reply_to_user_id_str" : "3732061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7846775581",
  "text" : "Worms is way too addictive. When did it get to be 8pm?",
  "id" : 7846775581,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7846897658",
  "text" : "Spammers on FreeNode are ruining it for everyone. Either that, or people have bad clients that don't reject multiple CTCP requests.",
  "id" : 7846897658,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7849102156",
  "text" : "Every time I watch a Sabres game, it goes to a shootout. Wtf.",
  "id" : 7849102156,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 50, 61 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7850499527",
  "text" : "I just became the mayor of Wegmans - Hylan Dr. on @foursquare! http:\/\/4sq.com\/74kvOb",
  "id" : 7850499527,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7851009944",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox I need to investigate indexing time, seems to have gotten way slower",
  "id" : 7851009944,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7850554508",
  "geo" : { },
  "id_str" : "7851034683",
  "in_reply_to_user_id" : 16892522,
  "text" : "@wolfz0rz I wish! But not for beer...",
  "id" : 7851034683,
  "in_reply_to_status_id" : 7850554508,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "cregatron",
  "in_reply_to_user_id_str" : "16892522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Chambers",
      "screen_name" : "schambers",
      "indices" : [ 50, 60 ],
      "id_str" : "8372122",
      "id" : 8372122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7868478881",
  "text" : "Downloading and installing VS2008. Also, I'm with @schambers, it's hard to believe the prices of VS2010. http:\/\/is.gd\/6se69",
  "id" : 7868478881,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7868809370",
  "text" : "Excuuuuuuuuuuuuuuuuuuuse me princess! http:\/\/www.hulu.com\/the-legend-of-zelda",
  "id" : 7868809370,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7871686330",
  "text" : "Photo: MYTHBUSTERS. http:\/\/tumblr.com\/x175m393y",
  "id" : 7871686330,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7878058294",
  "text" : "Can anyone read this? It's all Russian to me. http:\/\/vvk.pp.ru\/misc-pics\/git.jpg",
  "id" : 7878058294,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Behrens",
      "screen_name" : "AskedRelic",
      "indices" : [ 49, 60 ],
      "id_str" : "5539522",
      "id" : 5539522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7878715691",
  "text" : "Survey says: \"Learn git\", \"Learn git bitch!\" And @AskedRelic, most likely waaaaay wrong :)",
  "id" : 7878715691,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7820543126",
  "text" : "strangest thing tonight: not discovering Human Giant, not the bachelorette \/strip club party, but a car outside of a nearby apartment at 3am",
  "id" : 7820543126,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 0, 8 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7820065677",
  "geo" : { },
  "id_str" : "7820573798",
  "in_reply_to_user_id" : 5502392,
  "text" : "@mojombo http:\/\/raraahahahromaromamagagaoohlala.com\/",
  "id" : 7820573798,
  "in_reply_to_status_id" : 7820065677,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "mojombo",
  "in_reply_to_user_id_str" : "5502392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 0, 3 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsbridge",
      "indices" : [ 56, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7830254274",
  "geo" : { },
  "id_str" : "7830600097",
  "in_reply_to_user_id" : 937561,
  "text" : "@jm I'll definitely help out with paperclip, and I'm in #railsbridge. I plan on hitting some of the thoughtbot plugins as well",
  "id" : 7830600097,
  "in_reply_to_status_id" : 7830254274,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "jm",
  "in_reply_to_user_id_str" : "937561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Smick",
      "screen_name" : "sprsquish",
      "indices" : [ 0, 10 ],
      "id_str" : "2296675008",
      "id" : 2296675008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7833968882",
  "geo" : { },
  "id_str" : "7835570673",
  "in_reply_to_user_id" : 3732061,
  "text" : "@sprsquish patches are welcome, all of the data is there! :) I can get you sql dumps if you need it.",
  "id" : 7835570673,
  "in_reply_to_status_id" : 7833968882,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrsprsquish",
  "in_reply_to_user_id_str" : "3732061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7837808122",
  "geo" : { },
  "id_str" : "7837937715",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort fakeweb is nice, webmock is nicer. i've heard sham_rack is decent too.",
  "id" : 7837937715,
  "in_reply_to_status_id" : 7837808122,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 62, 73 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7807578651",
  "text" : "I just became the mayor of Mac Gregor's Grill and Tap Room on @foursquare! http:\/\/4sq.com\/6hNKyN",
  "id" : 7807578651,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "revans",
      "screen_name" : "revans",
      "indices" : [ 0, 7 ],
      "id_str" : "723873",
      "id" : 723873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7766669022",
  "geo" : { },
  "id_str" : "7769098941",
  "in_reply_to_user_id" : 723873,
  "text" : "@revans seems to be fine now :\/ what were you doing that was slow?",
  "id" : 7769098941,
  "in_reply_to_status_id" : 7766669022,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "revans",
  "in_reply_to_user_id_str" : "723873",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MongoDB",
      "screen_name" : "MongoDB",
      "indices" : [ 19, 27 ],
      "id_str" : "18080585",
      "id" : 18080585
    }, {
      "name" : "Adam Lindsay",
      "screen_name" : "adamlindsay",
      "indices" : [ 33, 45 ],
      "id_str" : "49763",
      "id" : 49763
    }, {
      "name" : "Coworking Rochester",
      "screen_name" : "coworkingroc",
      "indices" : [ 49, 62 ],
      "id_str" : "19386993",
      "id" : 19386993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7769317823",
  "text" : "Hearing about some @mongodb from @adamlindsay at @coworkingroc !",
  "id" : 7769317823,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7774099537",
  "text" : "setup.rb is reborn: http:\/\/proutils.github.com\/setup\/",
  "id" : 7774099537,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 0, 7 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7790032908",
  "geo" : { },
  "id_str" : "7791270986",
  "in_reply_to_user_id" : 8864512,
  "text" : "@marick what problems are you having? http:\/\/gemcutter.org\/pages\/gem_docs",
  "id" : 7791270986,
  "in_reply_to_status_id" : 7790032908,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "marick",
  "in_reply_to_user_id_str" : "8864512",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 0, 7 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7792720036",
  "geo" : { },
  "id_str" : "7792812352",
  "in_reply_to_user_id" : 8864512,
  "text" : "@marick add him as an owner, remove yourself should work",
  "id" : 7792812352,
  "in_reply_to_status_id" : 7792720036,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "marick",
  "in_reply_to_user_id_str" : "8864512",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juvenn Woo",
      "screen_name" : "juvenn",
      "indices" : [ 0, 7 ],
      "id_str" : "12910432",
      "id" : 12910432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7793757690",
  "geo" : { },
  "id_str" : "7794210731",
  "in_reply_to_user_id" : 12910432,
  "text" : "@juvenn i'm just the chronic rebaser ;)",
  "id" : 7794210731,
  "in_reply_to_status_id" : 7793757690,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "juvenn",
  "in_reply_to_user_id_str" : "12910432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7796318085",
  "text" : "Floored by git-goggles. This should replace git branch -a. http:\/\/github.com\/nowells\/git-goggles",
  "id" : 7796318085,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7796564931",
  "geo" : { },
  "id_str" : "7796800077",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie maybe you need a git gc? it worked fine on hoptoad's",
  "id" : 7796800077,
  "in_reply_to_status_id" : 7796564931,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hank",
      "screen_name" : "Hankers",
      "indices" : [ 0, 8 ],
      "id_str" : "17735910",
      "id" : 17735910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7798058570",
  "geo" : { },
  "id_str" : "7798325243",
  "in_reply_to_user_id" : 17735910,
  "text" : "@Hankers awesome but what horrible editing\/camera work. you can see one of the camera guys clearly in one shot.",
  "id" : 7798325243,
  "in_reply_to_status_id" : 7798058570,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Hankers",
  "in_reply_to_user_id_str" : "17735910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 23, 33 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7799558677",
  "text" : "Video: TECHNOJEEP. via @bleything http:\/\/tumblr.com\/x175k5f0q",
  "id" : 7799558677,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Albacore Build",
      "screen_name" : "albacorebuild",
      "indices" : [ 0, 14 ],
      "id_str" : "92769674",
      "id" : 92769674
    }, {
      "name" : "Luke Smith",
      "screen_name" : "lukesmith",
      "indices" : [ 15, 25 ],
      "id_str" : "2751391",
      "id" : 2751391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7803438404",
  "geo" : { },
  "id_str" : "7803621732",
  "in_reply_to_user_id" : 92769674,
  "text" : "@albacorebuild @lukesmith Seems to be a bug with indexing gems after push, it should be coming back into the index momentarily.",
  "id" : 7803621732,
  "in_reply_to_status_id" : 7803438404,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "albacorebuild",
  "in_reply_to_user_id_str" : "92769674",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7728998380",
  "text" : "Does anyone actually use the OSX dashboard\/widget thing?",
  "id" : 7728998380,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7729248901",
  "text" : "And if you do use the Dashboard, tell me your widgets of choice, I'm aware humans *do* use it in some fashion.",
  "id" : 7729248901,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 28, 41 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7735130723",
  "text" : "Video: HEAVY METAL DOG. via @codinghorror http:\/\/tumblr.com\/x175ijpfr",
  "id" : 7735130723,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7736633254",
  "text" : "Audio: RIT\u2019s president singing some folk rock from the 70s. Epic. http:\/\/tumblr.com\/x175ileij",
  "id" : 7736633254,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nikki graziano",
      "screen_name" : "nikkigraziano",
      "indices" : [ 14, 28 ],
      "id_str" : "12914422",
      "id" : 12914422
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 61, 72 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7753284540",
  "text" : "I just ousted @nikkigraziano as the mayor of Java Wally's on @foursquare! http:\/\/4sq.com\/6pTb3i",
  "id" : 7753284540,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIT",
      "indices" : [ 64, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7755808220",
  "text" : "Rochester.rb is tonight, talking about MongoDB and more. If any #RIT people want a ride let me know.",
  "id" : 7755808220,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7760089549",
  "text" : "Please tell me there's a better way to deploy ASP.NET sites than FTP'ing DLLs or the \"Copy Web Site\" tool. It's 2010 people.",
  "id" : 7760089549,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7691303471",
  "geo" : { },
  "id_str" : "7691404366",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie should be within a minute. not seeing that?",
  "id" : 7691404366,
  "in_reply_to_status_id" : 7691303471,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7691517988",
  "geo" : { },
  "id_str" : "7691587961",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie hmm, i bet we're missing some indexes and getting close to 10k gems and &gt; 40k versions takes a while to load...time for redis!",
  "id" : 7691587961,
  "in_reply_to_status_id" : 7691517988,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7691590155",
  "geo" : { },
  "id_str" : "7691645927",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything just fork jekyll, shouldn't be too hard to add that stuff in",
  "id" : 7691645927,
  "in_reply_to_status_id" : 7691590155,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7691812197",
  "geo" : { },
  "id_str" : "7692067375",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything good luck writing your own or something does what you want then :)",
  "id" : 7692067375,
  "in_reply_to_status_id" : 7691812197,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Brinckerhoff",
      "screen_name" : "bbrinck",
      "indices" : [ 3, 11 ],
      "id_str" : "17238404",
      "id" : 17238404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7694922187",
  "text" : "RT @bbrinck: The Conservative Case for Gay Marriage by Ted Olsen, the conservative lawyer arguing to overturn Prop 8 http:\/\/bit.ly\/4rcPD ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7694649050",
    "text" : "The Conservative Case for Gay Marriage by Ted Olsen, the conservative lawyer arguing to overturn Prop 8 http:\/\/bit.ly\/4rcPDk. Great read.",
    "id" : 7694649050,
    "created_at" : "2010-01-13 03:01:03 +0000",
    "user" : {
      "name" : "Ben Brinckerhoff",
      "screen_name" : "bbrinck",
      "protected" : false,
      "id_str" : "17238404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487384745764868096\/qq7iQKUr_normal.jpeg",
      "id" : 17238404,
      "verified" : false
    }
  },
  "id" : 7694922187,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wegmans Food Markets",
      "screen_name" : "Wegmans",
      "indices" : [ 101, 109 ],
      "id_str" : "66482863",
      "id" : 66482863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7695488360",
  "text" : "After years, I've finally found a yogurt flavor I can eat without gagging! (Vanilla SUPERYOGURT from @Wegmans)",
  "id" : 7695488360,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7696436339",
  "text" : "Video: unreleased not fade away cover by rush http:\/\/tumblr.com\/x175hi3ei",
  "id" : 7696436339,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7713806847",
  "text" : "My phone just butt-emailed my entire class \"Zzzzzpm\"",
  "id" : 7713806847,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howland",
      "screen_name" : "backslash",
      "indices" : [ 0, 10 ],
      "id_str" : "8161622",
      "id" : 8161622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7721738794",
  "geo" : { },
  "id_str" : "7721770304",
  "in_reply_to_user_id" : 8161622,
  "text" : "@backslash quit now.",
  "id" : 7721770304,
  "in_reply_to_status_id" : 7721738794,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "backslash",
  "in_reply_to_user_id_str" : "8161622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Norris",
      "screen_name" : "rsl",
      "indices" : [ 0, 4 ],
      "id_str" : "82863",
      "id" : 82863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7722840780",
  "geo" : { },
  "id_str" : "7723099378",
  "in_reply_to_user_id" : 82863,
  "text" : "@rsl fixed, i forgot a \/? in the RewriteRule.",
  "id" : 7723099378,
  "in_reply_to_status_id" : 7722840780,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "rsl",
  "in_reply_to_user_id_str" : "82863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Robertson",
      "screen_name" : "krobertson",
      "indices" : [ 0, 11 ],
      "id_str" : "3043421",
      "id" : 3043421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7723928744",
  "geo" : { },
  "id_str" : "7724273098",
  "in_reply_to_user_id" : 3043421,
  "text" : "@krobertson bring me out to codemash next year and i'll gladly get that set up :)",
  "id" : 7724273098,
  "in_reply_to_status_id" : 7723928744,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "krobertson",
  "in_reply_to_user_id_str" : "3043421",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7726827401",
  "geo" : { },
  "id_str" : "7727218317",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg commits in Git don't have any idea what branch they're on. that's by design, not a bug",
  "id" : 7727218317,
  "in_reply_to_status_id" : 7726827401,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Chambers",
      "screen_name" : "schambers",
      "indices" : [ 41, 51 ],
      "id_str" : "8372122",
      "id" : 8372122
    }, {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 52, 64 ],
      "id_str" : "15524875",
      "id" : 15524875
    }, {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 65, 77 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7649487610",
  "text" : ".NET people: what do you use for CI? \/cc @schambers @SaraJChipps @jongalloway",
  "id" : 7649487610,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Chambers",
      "screen_name" : "schambers",
      "indices" : [ 0, 10 ],
      "id_str" : "8372122",
      "id" : 8372122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7650036661",
  "geo" : { },
  "id_str" : "7650376440",
  "in_reply_to_user_id" : 8372122,
  "text" : "@schambers rvm installs RubyGems for you. Then you can use rvm gem install to install a gem across all rubies",
  "id" : 7650376440,
  "in_reply_to_status_id" : 7650036661,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "schambers",
  "in_reply_to_user_id_str" : "8372122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7658507545",
  "text" : "Most embarrassing nethack death ever. http:\/\/alt.org\/nethack\/userdata\/DoctorNick\/dumplog\/1263185487.nh343.txt",
  "id" : 7658507545,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Moore",
      "screen_name" : "sartak",
      "indices" : [ 0, 7 ],
      "id_str" : "6753782",
      "id" : 6753782
    }, {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 34, 47 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7658588111",
  "geo" : { },
  "id_str" : "7658748663",
  "in_reply_to_user_id" : 6753782,
  "text" : "@sartak ah, that was it! and yes, @jordansissel, finding 3 bones files will do that to you :[",
  "id" : 7658748663,
  "in_reply_to_status_id" : 7658588111,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "sartak",
  "in_reply_to_user_id_str" : "6753782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Redpath",
      "screen_name" : "lukeredpath",
      "indices" : [ 0, 12 ],
      "id_str" : "72573",
      "id" : 72573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7669014678",
  "geo" : { },
  "id_str" : "7669918328",
  "in_reply_to_user_id" : 72573,
  "text" : "@lukeredpath email me at nick@gemcutter.org, we'll figure it out. It's probably under your RubyForge account.",
  "id" : 7669918328,
  "in_reply_to_status_id" : 7669014678,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "lukeredpath",
  "in_reply_to_user_id_str" : "72573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7670194351",
  "text" : "Photo: who ate the damn pizza rolls? http:\/\/tumblr.com\/x175gtula",
  "id" : 7670194351,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Parsons",
      "screen_name" : "chrismdp",
      "indices" : [ 0, 9 ],
      "id_str" : "14784701",
      "id" : 14784701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7680686316",
  "geo" : { },
  "id_str" : "7680841679",
  "in_reply_to_user_id" : 14784701,
  "text" : "@chrismdp not yet, it's on my list though! feel free to give it a shot.",
  "id" : 7680841679,
  "in_reply_to_status_id" : 7680686316,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "chrismdp",
  "in_reply_to_user_id_str" : "14784701",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 26, 38 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7687525252",
  "text" : "Photo: i\u2019m with coco. via @SteveStreza http:\/\/tumblr.com\/x175h8fm5",
  "id" : 7687525252,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7628418937",
  "geo" : { },
  "id_str" : "7631775749",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen just treat it like a rails app, passenger should pick up the config.ru...sinatra-activerecord is nice if you need rake tasks",
  "id" : 7631775749,
  "in_reply_to_status_id" : 7628418937,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7632315164",
  "text" : "First GitHub Rebase of 2010! http:\/\/github.com\/blog\/575-github-rebase-33",
  "id" : 7632315164,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ches Martin \u265E",
      "screen_name" : "ches",
      "indices" : [ 0, 5 ],
      "id_str" : "790104",
      "id" : 790104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7633405453",
  "geo" : { },
  "id_str" : "7634385816",
  "in_reply_to_user_id" : 790104,
  "text" : "@ches ah crap, i'll fix that today",
  "id" : 7634385816,
  "in_reply_to_status_id" : 7633405453,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ches",
  "in_reply_to_user_id_str" : "790104",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ches Martin \u265E",
      "screen_name" : "ches",
      "indices" : [ 0, 5 ],
      "id_str" : "790104",
      "id" : 790104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7634571561",
  "geo" : { },
  "id_str" : "7635770097",
  "in_reply_to_user_id" : 790104,
  "text" : "@ches fixed! http:\/\/gemcutter.org\/gems\/enforcer",
  "id" : 7635770097,
  "in_reply_to_status_id" : 7634571561,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ches",
  "in_reply_to_user_id_str" : "790104",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Townsend",
      "screen_name" : "RyanTownsend",
      "indices" : [ 0, 13 ],
      "id_str" : "2202971",
      "id" : 2202971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7643765578",
  "geo" : { },
  "id_str" : "7643798797",
  "in_reply_to_user_id" : 2202971,
  "text" : "@RyanTownsend what rubygems version are you on? seems to be working fine here",
  "id" : 7643798797,
  "in_reply_to_status_id" : 7643765578,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "RyanTownsend",
  "in_reply_to_user_id_str" : "2202971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Townsend",
      "screen_name" : "RyanTownsend",
      "indices" : [ 0, 13 ],
      "id_str" : "2202971",
      "id" : 2202971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7643959921",
  "geo" : { },
  "id_str" : "7644080200",
  "in_reply_to_user_id" : 2202971,
  "text" : "@RyanTownsend we just switched to CloudFront recently...but everything should work fine. what gem?",
  "id" : 7644080200,
  "in_reply_to_status_id" : 7643959921,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "RyanTownsend",
  "in_reply_to_user_id_str" : "2202971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 3, 13 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7646092347",
  "text" : "RT @bleything: An actual photo of actual Mars, from Discover Magazine: http:\/\/bit.ly\/7CO2IH ... do read the article, the author is VERY  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7646004843",
    "text" : "An actual photo of actual Mars, from Discover Magazine: http:\/\/bit.ly\/7CO2IH ... do read the article, the author is VERY excited.  So cool.",
    "id" : 7646004843,
    "created_at" : "2010-01-11 22:45:49 +0000",
    "user" : {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "protected" : false,
      "id_str" : "823615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1260090298\/foo_normal.png",
      "id" : 823615,
      "verified" : false
    }
  },
  "id" : 7646092347,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ara T. Howard",
      "screen_name" : "drawohara",
      "indices" : [ 0, 10 ],
      "id_str" : "17058191",
      "id" : 17058191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7646918021",
  "geo" : { },
  "id_str" : "7647170374",
  "in_reply_to_user_id" : 17058191,
  "text" : "@drawohara it's all on http:\/\/update.gemcutter.org ...what problems are you having?",
  "id" : 7647170374,
  "in_reply_to_status_id" : 7646918021,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "drawohara",
  "in_reply_to_user_id_str" : "17058191",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7647088287",
  "geo" : { },
  "id_str" : "7647341152",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything what would you have done differently?",
  "id" : 7647341152,
  "in_reply_to_status_id" : 7647088287,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7647088287",
  "geo" : { },
  "id_str" : "7647349121",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything please don't take that as confrontational, i'm trying to learn here :)",
  "id" : 7647349121,
  "in_reply_to_status_id" : 7647088287,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7647427867",
  "geo" : { },
  "id_str" : "7647490705",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything rubygems.org has been ready to go, waiting for a new rubygems release. and publishing to rubyforge *should* work still afaik",
  "id" : 7647490705,
  "in_reply_to_status_id" : 7647427867,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Chambers",
      "screen_name" : "schambers",
      "indices" : [ 0, 10 ],
      "id_str" : "8372122",
      "id" : 8372122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7614543391",
  "geo" : { },
  "id_str" : "7614570960",
  "in_reply_to_user_id" : 8372122,
  "text" : "@schambers Delayed::Job is your friend. I've heard great things about Resque, too.",
  "id" : 7614570960,
  "in_reply_to_status_id" : 7614543391,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "schambers",
  "in_reply_to_user_id_str" : "8372122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yardboy",
      "screen_name" : "Yardboy",
      "indices" : [ 0, 8 ],
      "id_str" : "7939892",
      "id" : 7939892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7615142464",
  "geo" : { },
  "id_str" : "7615576261",
  "in_reply_to_user_id" : 7939892,
  "text" : "@Yardboy it's just turrible",
  "id" : 7615576261,
  "in_reply_to_status_id" : 7615142464,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "Yardboy",
  "in_reply_to_user_id_str" : "7939892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7618659003",
  "text" : "GitHub Rebase #33 all queued up for tomorrow! Now to back to attempting to get nethack ascension #6",
  "id" : 7618659003,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe deed",
      "screen_name" : "Hunt3131",
      "indices" : [ 0, 9 ],
      "id_str" : "1236722168",
      "id" : 1236722168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7625081397",
  "geo" : { },
  "id_str" : "7630281239",
  "in_reply_to_user_id" : 17432847,
  "text" : "@hunt3131 nope...subscribers has been a mostly rss thing only. no emails have been exposed yet anywhere as well",
  "id" : 7630281239,
  "in_reply_to_status_id" : 7625081397,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "hgillane",
  "in_reply_to_user_id_str" : "17432847",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niclas Nilsson",
      "screen_name" : "niclasnilsson",
      "indices" : [ 0, 14 ],
      "id_str" : "14995974",
      "id" : 14995974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7587922551",
  "geo" : { },
  "id_str" : "7595966641",
  "in_reply_to_user_id" : 14995974,
  "text" : "@niclasnilsson it's a bit more complicated than that. if you want to help contribute, let me know :)",
  "id" : 7595966641,
  "in_reply_to_status_id" : 7587922551,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "niclasnilsson",
  "in_reply_to_user_id_str" : "14995974",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 0, 7 ],
      "id_str" : "728173",
      "id" : 728173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7596052068",
  "geo" : { },
  "id_str" : "7596307701",
  "in_reply_to_user_id" : 728173,
  "text" : "@MikeG1 why is this a pdf and not html?",
  "id" : 7596307701,
  "in_reply_to_status_id" : 7596052068,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "MikeG1",
  "in_reply_to_user_id_str" : "728173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7596453611",
  "text" : "Can we just use gems instead? Please? http:\/\/github.com\/grosser\/tracked_plugins",
  "id" : 7596453611,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niclas Nilsson",
      "screen_name" : "niclasnilsson",
      "indices" : [ 0, 14 ],
      "id_str" : "14995974",
      "id" : 14995974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7600525894",
  "geo" : { },
  "id_str" : "7601438440",
  "in_reply_to_user_id" : 14995974,
  "text" : "@niclasnilsson yep, that's it so far :\/",
  "id" : 7601438440,
  "in_reply_to_status_id" : 7600525894,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "niclasnilsson",
  "in_reply_to_user_id_str" : "14995974",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7606799857",
  "text" : "one of these days i'll learn SVG and figure out how this is possible: http:\/\/simulacrum.dorm.duke.edu\/allyourgoogle.svg",
  "id" : 7606799857,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nethack.alt.org bot",
      "screen_name" : "nethackaltorg",
      "indices" : [ 3, 17 ],
      "id_str" : "88474436",
      "id" : 88474436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7608343809",
  "text" : "RT @nethackaltorg DoctorNick (Kni Hum Mal Law), 84 points, slipped while mounting a saddled pony called Silver Bullet (wow, embarrassing)",
  "id" : 7608343809,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 0, 10 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7543142359",
  "geo" : { },
  "id_str" : "7543438839",
  "in_reply_to_user_id" : 5965482,
  "text" : "@jankowski no way. you got some http:\/\/crystalheadvodka.com\/ ?",
  "id" : 7543438839,
  "in_reply_to_status_id" : 7543142359,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "jankowski",
  "in_reply_to_user_id_str" : "5965482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7546337677",
  "geo" : { },
  "id_str" : "7546381932",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything no, it's removed. i'll take it off the wiki. http:\/\/github.com\/mojombo\/jekyll\/commit\/921aee23d39852d0d09107d140bc5cebaf180ee6",
  "id" : 7546381932,
  "in_reply_to_status_id" : 7546337677,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7550398508",
  "text" : "Upgrading plugins\/gems to Rails 3 is going to be a lot of work. It's time to start.",
  "id" : 7550398508,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7550504620",
  "geo" : { },
  "id_str" : "7550524746",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates nothing at all...starting to upgrade Gemcutter and running into a lot of roadblocks :[",
  "id" : 7550524746,
  "in_reply_to_status_id" : 7550504620,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Mendoza",
      "screen_name" : "jaymendoza",
      "indices" : [ 0, 11 ],
      "id_str" : "9750302",
      "id" : 9750302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7550522942",
  "geo" : { },
  "id_str" : "7550548718",
  "in_reply_to_user_id" : 9750302,
  "text" : "@jaymendoza that's way too hard to generalize. people just need to start upgrading once the beta\/release candidates come out",
  "id" : 7550548718,
  "in_reply_to_status_id" : 7550522942,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "jaymendoza",
  "in_reply_to_user_id_str" : "9750302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2B50 Daniel Lucraft",
      "screen_name" : "danlucraft",
      "indices" : [ 0, 11 ],
      "id_str" : "13094142",
      "id" : 13094142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7553624807",
  "geo" : { },
  "id_str" : "7561838702",
  "in_reply_to_user_id" : 13094142,
  "text" : "@danlucraft should be within a minute...upload to S3 is done as you push, indexing is given to delayed job. Not seeing that?",
  "id" : 7561838702,
  "in_reply_to_status_id" : 7553624807,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "danlucraft",
  "in_reply_to_user_id_str" : "13094142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lar Van Der Jagt",
      "screen_name" : "supaspoida",
      "indices" : [ 0, 11 ],
      "id_str" : "14205289",
      "id" : 14205289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7562295329",
  "geo" : { },
  "id_str" : "7562310138",
  "in_reply_to_user_id" : 14205289,
  "text" : "@supaspoida http:\/\/rvm.beginrescueend.com\/",
  "id" : 7562310138,
  "in_reply_to_status_id" : 7562295329,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "supaspoida",
  "in_reply_to_user_id_str" : "14205289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7562340243",
  "text" : "For those interested in the Rails 3 progress for Gemcutter: http:\/\/github.com\/qrush\/gemcutter\/tree\/rails3 (no where near booting yet)",
  "id" : 7562340243,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lar Van Der Jagt",
      "screen_name" : "supaspoida",
      "indices" : [ 0, 11 ],
      "id_str" : "14205289",
      "id" : 14205289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7562664037",
  "geo" : { },
  "id_str" : "7562885929",
  "in_reply_to_user_id" : 14205289,
  "text" : "@supaspoida yeah, you have to reinstall stuff, but `rvm gem install` will install it across all rubies you have",
  "id" : 7562885929,
  "in_reply_to_status_id" : 7562664037,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "supaspoida",
  "in_reply_to_user_id_str" : "14205289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Sharp",
      "screen_name" : "ajsharp",
      "indices" : [ 0, 8 ],
      "id_str" : "18071073",
      "id" : 18071073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7571512270",
  "geo" : { },
  "id_str" : "7572305682",
  "in_reply_to_user_id" : 18071073,
  "text" : "@ajsharp which gem? and how long did you have to wait?",
  "id" : 7572305682,
  "in_reply_to_status_id" : 7571512270,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "ajsharp",
  "in_reply_to_user_id_str" : "18071073",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 49, 60 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7573057447",
  "text" : "I just became the mayor of Frank Ritter Arena on @foursquare! http:\/\/4sq.com\/6IjpwD",
  "id" : 7573057447,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7499433223",
  "text" : "New idea for CS\/SE graduation requirements: a major contribution to an open source project of your choice.",
  "id" : 7499433223,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7502450707",
  "text" : "Copying gems over to CloudFront for Gemcutter, hopefully will be ready to go by tomorrow! http:\/\/bit.ly\/76YvAb",
  "id" : 7502450707,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "objo",
      "screen_name" : "objo",
      "indices" : [ 0, 5 ],
      "id_str" : "2190330632",
      "id" : 2190330632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7521948297",
  "text" : "@objo what system are you using?",
  "id" : 7521948297,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 74, 81 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7523375600",
  "text" : "I love sites with support services that respond nearly instantly. Thanks, @tumblr!",
  "id" : 7523375600,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 102, 115 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7524284026",
  "text" : "rvm + screen is an awesome combination. running jruby + 1.8.6 in separate projects simultaneously. +1 @wayneeseguin",
  "id" : 7524284026,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\u256F\u00B0\u25A1\u00B0\uFF09\u256F\uFE35 \u253B\u2501\u253B",
      "screen_name" : "CesarioGW",
      "indices" : [ 0, 10 ],
      "id_str" : "451327214",
      "id" : 451327214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7524569768",
  "geo" : { },
  "id_str" : "7524676039",
  "in_reply_to_user_id" : 48102727,
  "text" : "@CesarioGW yeah i haven't thought of a good way around that yet... patches welcome",
  "id" : 7524676039,
  "in_reply_to_status_id" : 7524569768,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "franckverrot",
  "in_reply_to_user_id_str" : "48102727",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7527387823",
  "text" : "I want to port this to a git hook... http:\/\/andialbrecht.wordpress.com\/2009\/05\/09\/when-merging-fails\/",
  "id" : 7527387823,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan",
      "screen_name" : "evan",
      "indices" : [ 0, 5 ],
      "id_str" : "761613",
      "id" : 761613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7527592608",
  "geo" : { },
  "id_str" : "7527651496",
  "in_reply_to_user_id" : 761613,
  "text" : "@evan it would be really easy to push that to twitter via the new webhook api :)",
  "id" : 7527651496,
  "in_reply_to_status_id" : 7527592608,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "evan",
  "in_reply_to_user_id_str" : "761613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan",
      "screen_name" : "evan",
      "indices" : [ 0, 5 ],
      "id_str" : "761613",
      "id" : 761613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7527592608",
  "geo" : { },
  "id_str" : "7527680290",
  "in_reply_to_user_id" : 761613,
  "text" : "@evan I guess I want to keep @rubygemcutter for service status updates and not litter it with tons of pushes http:\/\/gemwhisperer.heroku.com\/",
  "id" : 7527680290,
  "in_reply_to_status_id" : 7527592608,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "evan",
  "in_reply_to_user_id_str" : "761613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Mayer",
      "screen_name" : "danmayer",
      "indices" : [ 0, 9 ],
      "id_str" : "14630648",
      "id" : 14630648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7530286649",
  "geo" : { },
  "id_str" : "7530728192",
  "in_reply_to_user_id" : 14630648,
  "text" : "@danmayer what's the invitation code?",
  "id" : 7530728192,
  "in_reply_to_status_id" : 7530286649,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "danmayer",
  "in_reply_to_user_id_str" : "14630648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7536196194",
  "text" : "RT @thoughtbot: we're hiring another web designer in boston! http:\/\/bit.ly\/5t5jGk",
  "id" : 7536196194,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7459894614",
  "geo" : { },
  "id_str" : "7460108364",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps I'd love to hear if anyone's done .net on ec2...going to need to do some for my senior project soon",
  "id" : 7460108364,
  "in_reply_to_status_id" : 7459894614,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7460905918",
  "geo" : { },
  "id_str" : "7460964186",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu oh mean, jealous. i haven't been to holiday valley in ages. watching the sabres game instead :)",
  "id" : 7460964186,
  "in_reply_to_status_id" : 7460905918,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan",
      "screen_name" : "ryanb",
      "indices" : [ 41, 47 ],
      "id_str" : "7405122",
      "id" : 7405122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7461466046",
  "text" : "Gemcutter is on Railscasts again. Thanks @ryanb! http:\/\/railscasts.com\/episodes\/195-my-favorite-web-apps-in-2009",
  "id" : 7461466046,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan",
      "screen_name" : "ryanb",
      "indices" : [ 0, 6 ],
      "id_str" : "7405122",
      "id" : 7405122
    }, {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 25, 32 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7461537283",
  "geo" : { },
  "id_str" : "7461585225",
  "in_reply_to_user_id" : 7405122,
  "text" : "@ryanb crap, yes. thanks @rbates!",
  "id" : 7461585225,
  "in_reply_to_status_id" : 7461537283,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryanb",
  "in_reply_to_user_id_str" : "7405122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7462628671",
  "geo" : { },
  "id_str" : "7462819596",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything not really...main problem has always been github pages can't run user code",
  "id" : 7462819596,
  "in_reply_to_status_id" : 7462628671,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7464453265",
  "text" : "My favorite hobby has started once again: count the number of times \"sex\" is said while @ablissfulgal watches Secret Life.",
  "id" : 7464453265,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7466420678",
  "text" : "There's a gap between \"awesome home office\" and \"out of your damn mind\" http:\/\/www.biscade.com\/office\/",
  "id" : 7466420678,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7466978894",
  "geo" : { },
  "id_str" : "7467073348",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv maybe i can write a auto backup git script for ya or something. that sucks.",
  "id" : 7467073348,
  "in_reply_to_status_id" : 7466978894,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7484491008",
  "text" : "I'm at Java Wally's (90 Lomb Memorial Drive, Rochester). http:\/\/4sq.com\/6pTb3i",
  "id" : 7484491008,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7486397954",
  "text" : "This kid has talked out of turn over a dozen times, and class is only half over.",
  "id" : 7486397954,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7487656063",
  "text" : "I'm at Saunders College of Business (105 Lomb Memorial Dr, Rochester). http:\/\/4sq.com\/7ngngr",
  "id" : 7487656063,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7488417616",
  "text" : "I'm at GCCIS (Rochester Institute of Technology, Rochester). http:\/\/4sq.com\/4xyDea",
  "id" : 7488417616,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7488607708",
  "text" : "I really wish you could edit the map directly for foursquare...addresses just aren't enough to pinpoint places.",
  "id" : 7488607708,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klondike Gold",
      "screen_name" : "Klondike",
      "indices" : [ 59, 68 ],
      "id_str" : "298070410",
      "id" : 298070410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7491342103",
  "text" : "Wrote my first real line of Java code in years, hacking on @Klondike's campfyre android app. http:\/\/github.com\/qrush\/campyre",
  "id" : 7491342103,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klondike Gold",
      "screen_name" : "Klondike",
      "indices" : [ 0, 9 ],
      "id_str" : "298070410",
      "id" : 298070410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7491507328",
  "geo" : { },
  "id_str" : "7491561020",
  "in_reply_to_user_id" : 5232171,
  "text" : "@Klondike DROOOOOOOOOOOOOOOOOOOOOOOOOID",
  "id" : 7491561020,
  "in_reply_to_status_id" : 7491507328,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\u256F\u00B0\u25A1\u00B0\uFF09\u256F\uFE35 \u253B\u2501\u253B",
      "screen_name" : "CesarioGW",
      "indices" : [ 3, 13 ],
      "id_str" : "451327214",
      "id" : 451327214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gemcutter",
      "indices" : [ 37, 47 ]
    }, {
      "text" : "webhooks",
      "indices" : [ 48, 57 ]
    }, {
      "text" : "appengine",
      "indices" : [ 58, 68 ]
    }, {
      "text" : "wave",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7491728804",
  "text" : "RT @CesarioGW: Part 1 of the post on #Gemcutter+#webhooks+#appengine+#wave online. Part 2 will focus on the Wave gadget design. http:\/\/b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gemcutter",
        "indices" : [ 22, 32 ]
      }, {
        "text" : "webhooks",
        "indices" : [ 33, 42 ]
      }, {
        "text" : "appengine",
        "indices" : [ 43, 53 ]
      }, {
        "text" : "wave",
        "indices" : [ 54, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7491613900",
    "text" : "Part 1 of the post on #Gemcutter+#webhooks+#appengine+#wave online. Part 2 will focus on the Wave gadget design. http:\/\/bit.ly\/5VYShN",
    "id" : 7491613900,
    "created_at" : "2010-01-07 20:48:40 +0000",
    "user" : {
      "name" : "Franck Verrot",
      "screen_name" : "franckverrot",
      "protected" : false,
      "id_str" : "48102727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1415995852\/me_normal.png",
      "id" : 48102727,
      "verified" : false
    }
  },
  "id" : 7491728804,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7449016522",
  "text" : "Ok, 4square's android app is so much easier than using the gowalla web interface. And you can make venues here too. See ya gowalla!",
  "id" : 7449016522,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7458507025",
  "geo" : { },
  "id_str" : "7458701854",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson what problems are you having with the bundler specifically?",
  "id" : 7458701854,
  "in_reply_to_status_id" : 7458507025,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 0, 16 ],
      "id_str" : "46852648",
      "id" : 46852648
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gemcutter",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7418933416",
  "geo" : { },
  "id_str" : "7423969740",
  "in_reply_to_user_id" : 46852648,
  "text" : "@postmodern_mod3 Thanks! feel free to hop in #gemcutter if you have questions or ideas for apps you want to build.",
  "id" : 7423969740,
  "in_reply_to_status_id" : 7418933416,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "postmodern_mod3",
  "in_reply_to_user_id_str" : "46852648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uAE40\uACBD\uD654",
      "screen_name" : "stick84",
      "indices" : [ 3, 11 ],
      "id_str" : "271947407",
      "id" : 271947407
    }, {
      "name" : "openSUSE",
      "screen_name" : "openSUSE",
      "indices" : [ 32, 41 ],
      "id_str" : "15134408",
      "id" : 15134408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7444483563",
  "text" : "RT @stick84: @rubygemcutter and @opensuse Build Service cooperation (idea) http:\/\/wp.me\/pggPv-gl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSUSE",
        "screen_name" : "openSUSE",
        "indices" : [ 19, 28 ],
        "id_str" : "15134408",
        "id" : 15134408
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7442499327",
    "in_reply_to_user_id" : 42259749,
    "text" : "@rubygemcutter and @opensuse Build Service cooperation (idea) http:\/\/wp.me\/pggPv-gl",
    "id" : 7442499327,
    "created_at" : "2010-01-06 14:41:10 +0000",
    "in_reply_to_screen_name" : "gemcutter",
    "in_reply_to_user_id_str" : "42259749",
    "user" : {
      "name" : "Pavol Rusnak",
      "screen_name" : "pavolrusnak",
      "protected" : false,
      "id_str" : "15168247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538483252495802369\/dVuxHjDS_normal.jpeg",
      "id" : 15168247,
      "verified" : false
    }
  },
  "id" : 7444483563,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 38, 49 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7448962227",
  "text" : "I just unlocked the \"Newbie\" badge on @foursquare! http:\/\/4sq.com\/4RlOKb",
  "id" : 7448962227,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7448962565",
  "text" : "I'm at Java Wally's (90 Lomb Memorial Drive, Rochester). http:\/\/4sq.com\/6pTb3i",
  "id" : 7448962565,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7385653328",
  "text" : "Hopefully will be using Cuke4Nuke for my senior project. So glad it exists. http:\/\/wiki.github.com\/richardlawrence\/Cuke4Nuke",
  "id" : 7385653328,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 47, 58 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7385996947",
  "text" : "Oh yeah, thanks for all of the well wishes re: @thoughtbot, folks. Should be fun :)",
  "id" : 7385996947,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7385911488",
  "geo" : { },
  "id_str" : "7386015708",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh it could be worse...much worse compared to what some of the other teams are doing. not my choice.",
  "id" : 7386015708,
  "in_reply_to_status_id" : 7385911488,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7385780053",
  "geo" : { },
  "id_str" : "7386030829",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan will do. it'll be my first trek back into .NET after ~2 years of being free of its chains :[",
  "id" : 7386030829,
  "in_reply_to_status_id" : 7385780053,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Beck",
      "screen_name" : "_frommetoyou",
      "indices" : [ 22, 35 ],
      "id_str" : "1378382443",
      "id" : 1378382443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7386141688",
  "text" : "New picture thanks to @_FromMeToYou! I need a camera like hers, once I win the lottery.",
  "id" : 7386141688,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    }, {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 13, 21 ],
      "id_str" : "22682102",
      "id" : 22682102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7386485445",
  "geo" : { },
  "id_str" : "7386520768",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil if @dmansen is explaining this, i have beer and i want to be there",
  "id" : 7386520768,
  "in_reply_to_status_id" : 7386485445,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7386579019",
  "text" : "Trying this out in vim... underlining the current line as you move: autocmd CursorMoved,CursorMovedI * set cul",
  "id" : 7386579019,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7386578806",
  "geo" : { },
  "id_str" : "7386625051",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil i disagree, it's a great idea. table this conversation and move it to perkins asap",
  "id" : 7386625051,
  "in_reply_to_status_id" : 7386578806,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Beck",
      "screen_name" : "_frommetoyou",
      "indices" : [ 0, 13 ],
      "id_str" : "1378382443",
      "id" : 1378382443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7386524984",
  "geo" : { },
  "id_str" : "7386671801",
  "in_reply_to_user_id" : 25283065,
  "text" : "@_FromMeToYou maybe, if I can get a picture with a real whale. held up by birds.",
  "id" : 7386671801,
  "in_reply_to_status_id" : 7386524984,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnnStreetStudio",
  "in_reply_to_user_id_str" : "25283065",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7388506373",
  "text" : "Why I have never heard of Retrospectiva? http:\/\/retrospectiva.org\/overview",
  "id" : 7388506373,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 0, 6 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7388583105",
  "geo" : { },
  "id_str" : "7388642055",
  "in_reply_to_user_id" : 8000842,
  "text" : "@tpope o rly...it wasn't working otherwise for me. I'll give it a shot.",
  "id" : 7388642055,
  "in_reply_to_status_id" : 7388583105,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "tpope",
  "in_reply_to_user_id_str" : "8000842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7389296349",
  "text" : "I want a different coding font than Monaco for OSX. Any suggestions?",
  "id" : 7389296349,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Stoner",
      "screen_name" : "maslowbeer",
      "indices" : [ 0, 11 ],
      "id_str" : "13749072",
      "id" : 13749072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7403449733",
  "geo" : { },
  "id_str" : "7404722198",
  "in_reply_to_user_id" : 13749072,
  "text" : "@maslowbeer it just pulls down the latest info..does it show up in your accounts\/sync page in settings?",
  "id" : 7404722198,
  "in_reply_to_status_id" : 7403449733,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "maslowbeer",
  "in_reply_to_user_id_str" : "13749072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nap.tld, ltd.",
      "screen_name" : "zapnap",
      "indices" : [ 44, 51 ],
      "id_str" : "1566201",
      "id" : 1566201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7404753237",
  "text" : "Liking Droid Sans Mono so far, suggested by @zapnap. Thanks for all of the suggestions!",
  "id" : 7404753237,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sven Fuchs",
      "screen_name" : "svenfuchs",
      "indices" : [ 0, 10 ],
      "id_str" : "9459332",
      "id" : 9459332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7398389185",
  "geo" : { },
  "id_str" : "7405236698",
  "in_reply_to_user_id" : 9459332,
  "text" : "@svenfuchs contributions are welcome!",
  "id" : 7405236698,
  "in_reply_to_status_id" : 7398389185,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "svenfuchs",
  "in_reply_to_user_id_str" : "9459332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7407061046",
  "text" : "RT @rubygemcutter: Say hello to gem webhooks! Docs: http:\/\/is.gd\/5MUgq Example app: http:\/\/is.gd\/5MUha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7407035885",
    "text" : "Say hello to gem webhooks! Docs: http:\/\/is.gd\/5MUgq Example app: http:\/\/is.gd\/5MUha",
    "id" : 7407035885,
    "created_at" : "2010-01-05 16:01:20 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 7407061046,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7409134839",
  "text" : "I'm not sure which frustrates me more, the kid arguing a 1 point question on an exam or the shirt with Comic Sans on the back.",
  "id" : 7409134839,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7411474589",
  "text" : "NexusOne updates sound awesome...so glad the OS is open source and all Android phones can benefit.",
  "id" : 7411474589,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7414455988",
  "text" : "Fixed up THE GEM WHISPERER with some iUI magic! http:\/\/gemwhisperer.heroku.com\/",
  "id" : 7414455988,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7414626304",
  "geo" : { },
  "id_str" : "7415344491",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv it's more like @ablissfulgal was watching the dog whisperer when I started the site",
  "id" : 7415344491,
  "in_reply_to_status_id" : 7414626304,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u044D\u0440\u0438 \u0441\u0430\u0430\u043A\u044F\u043D",
      "screen_name" : "ArmMer",
      "indices" : [ 0, 7 ],
      "id_str" : "369604063",
      "id" : 369604063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7419023692",
  "text" : "@armmer noooo use a real dependency manager, or subtree merging. Submodules suck.",
  "id" : 7419023692,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7347641435",
  "geo" : { },
  "id_str" : "7348133404",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats either sounds good",
  "id" : 7348133404,
  "in_reply_to_status_id" : 7347641435,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7358568846",
  "text" : "Found the source to my old raytracer for Computer Graphics 2, with pictures of how it progressed. (Also, I don't miss C#) http:\/\/is.gd\/5LufP",
  "id" : 7358568846,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7366979792",
  "geo" : { },
  "id_str" : "7367004272",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn I've stuck with zshkit, it's quite nice",
  "id" : 7367004272,
  "in_reply_to_status_id" : 7366979792,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7367793857",
  "text" : "Found my answer, and it was screen's fault. http:\/\/www.thomaskeller.biz\/blog\/2009\/12\/18\/tip-ctrl-r-with-zsh-in-gnu-screen\/",
  "id" : 7367793857,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7370824569",
  "text" : "Looking through tutorials for deploying ASP.NET apps to EC2...amazing how none of this is automated.",
  "id" : 7370824569,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7370839235",
  "text" : "This seems promising though: http:\/\/ec2bootstrapper.codeplex.com\/ and I'll certainly be tearing it apart.",
  "id" : 7370839235,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7371750235",
  "text" : "Checked out revision 36496.",
  "id" : 7371750235,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7372496780",
  "text" : "I wish the 'post to twitter' button on Gowalla was checked by default.",
  "id" : 7372496780,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7373554017",
  "text" : "OH: \"I would be married right now if I was sexually attracted to women\"",
  "id" : 7373554017,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gowalla",
      "screen_name" : "gowalla",
      "indices" : [ 0, 8 ],
      "id_str" : "18695316",
      "id" : 18695316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7372683676",
  "geo" : { },
  "id_str" : "7373572483",
  "in_reply_to_user_id" : 18695316,
  "text" : "@gowalla i'm using the mobile interface via Android, I'll see if that works.",
  "id" : 7373572483,
  "in_reply_to_status_id" : 7372683676,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "gowalla",
  "in_reply_to_user_id_str" : "18695316",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7375665171",
  "geo" : { },
  "id_str" : "7375706625",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety wtf is ^A? you mean ^R ? http:\/\/github.com\/jferris\/config_files\/blob\/master\/zshrc",
  "id" : 7375706625,
  "in_reply_to_status_id" : 7375665171,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7375797818",
  "text" : "Ok, the secret is out, I'm back at Thoughtbot (and going back to Boston once school's done) http:\/\/thoughtbot.com\/about\/ :)",
  "id" : 7375797818,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Smith",
      "screen_name" : "smithk14",
      "indices" : [ 0, 9 ],
      "id_str" : "189184554",
      "id" : 189184554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7377514632",
  "geo" : { },
  "id_str" : "7377613757",
  "in_reply_to_user_id" : 6796662,
  "text" : "@smithk14 we've been having this discussion too... http:\/\/bit.ly\/7yUAo6",
  "id" : 7377613757,
  "in_reply_to_status_id" : 7377514632,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "kvnsmth",
  "in_reply_to_user_id_str" : "6796662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7379060033",
  "text" : "the deal is... BASTING IN GRAVY http:\/\/www.nopuorg.com\/",
  "id" : 7379060033,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7379837169",
  "text" : "I'm at Crossroads in Rochester, NY http:\/\/gowal.la\/s\/2EBh",
  "id" : 7379837169,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7333039762",
  "text" : "Great discussion about the motivation behind 'working for free' on OSS: http:\/\/bit.ly\/5i8enX",
  "id" : 7333039762,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7333142754",
  "text" : "Getting ready to trek back to Rochester via Erie and Buffalo, and it's real snowy out. :(",
  "id" : 7333142754,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7334195810",
  "text" : "Filling up! \u2014 at Flying J http:\/\/gowal.la\/s\/2Cyo",
  "id" : 7334195810,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7340618904",
  "text" : "I'm at Angola Rest Stop in Angola, NY http:\/\/gowal.la\/s\/2h7D",
  "id" : 7340618904,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7347400258",
  "text" : "Back at RIT, finally.",
  "id" : 7347400258,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "davidbrenner",
      "screen_name" : "davidbrenner",
      "indices" : [ 0, 13 ],
      "id_str" : "14312099",
      "id" : 14312099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7341259977",
  "geo" : { },
  "id_str" : "7347414449",
  "in_reply_to_user_id" : 14312099,
  "text" : "@davidbrenner I didn't, but @ablissfulgal got some real gross coffee",
  "id" : 7347414449,
  "in_reply_to_status_id" : 7341259977,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "davidbrenner",
  "in_reply_to_user_id_str" : "14312099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7346917080",
  "geo" : { },
  "id_str" : "7347559091",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats upgrading apps to rails 3? :)",
  "id" : 7347559091,
  "in_reply_to_status_id" : 7346917080,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7309994955",
  "text" : "Gowalla's mobile site sucks, and there's no droid app yet. Sadface.",
  "id" : 7309994955,
  "created_at" : "2010-01-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.swift-app.com\/\" rel=\"nofollow\"\u003ESwift\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7310319516",
  "geo" : { },
  "id_str" : "7312527138",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej foursquare is only in big towns it seems",
  "id" : 7312527138,
  "in_reply_to_status_id" : 7310319516,
  "created_at" : "2010-01-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
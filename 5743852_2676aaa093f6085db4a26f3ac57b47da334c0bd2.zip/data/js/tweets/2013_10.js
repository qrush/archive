Grailbird.data.tweets_2013_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connors",
      "screen_name" : "Sean_Connors",
      "indices" : [ 0, 13 ],
      "id_str" : "140621692",
      "id" : 140621692
    }, {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 14, 25 ],
      "id_str" : "137891464",
      "id" : 137891464
    }, {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 26, 39 ],
      "id_str" : "5911122",
      "id" : 5911122
    }, {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 40, 46 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396075428302950401",
  "geo" : { },
  "id_str" : "396075855312461824",
  "in_reply_to_user_id" : 140621692,
  "text" : "@Sean_Connors @nickelcity @ChrisSmithAV @phish aww, they did that in 98. Oops.",
  "id" : 396075855312461824,
  "in_reply_to_status_id" : 396075428302950401,
  "created_at" : "2013-11-01 00:46:57 +0000",
  "in_reply_to_screen_name" : "Sean_Connors",
  "in_reply_to_user_id_str" : "140621692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connors",
      "screen_name" : "Sean_Connors",
      "indices" : [ 0, 13 ],
      "id_str" : "140621692",
      "id" : 140621692
    }, {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 14, 25 ],
      "id_str" : "137891464",
      "id" : 137891464
    }, {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 26, 39 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396075428302950401",
  "geo" : { },
  "id_str" : "396075638345326593",
  "in_reply_to_user_id" : 140621692,
  "text" : "@Sean_Connors @nickelcity @ChrisSmithAV hoping Loaded\u2026",
  "id" : 396075638345326593,
  "in_reply_to_status_id" : 396075428302950401,
  "created_at" : "2013-11-01 00:46:05 +0000",
  "in_reply_to_screen_name" : "Sean_Connors",
  "in_reply_to_user_id_str" : "140621692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/395955321354469377\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/xk4136sC72",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX63RDsCcAAh9JX.jpg",
      "id_str" : "395955320930856960",
      "id" : 395955320930856960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX63RDsCcAAh9JX.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/xk4136sC72"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395955528406278144",
  "text" : "RT @coworkbuffalo: Sidewalks soon, but our new space will have benches outside! Awesome! http:\/\/t.co\/xk4136sC72",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/395955321354469377\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/xk4136sC72",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BX63RDsCcAAh9JX.jpg",
        "id_str" : "395955320930856960",
        "id" : 395955320930856960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX63RDsCcAAh9JX.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/xk4136sC72"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395955321354469377",
    "text" : "Sidewalks soon, but our new space will have benches outside! Awesome! http:\/\/t.co\/xk4136sC72",
    "id" : 395955321354469377,
    "created_at" : "2013-10-31 16:47:59 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 395955528406278144,
  "created_at" : "2013-10-31 16:48:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395939086780751872",
  "geo" : { },
  "id_str" : "395939414473314304",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending hey did you get that email about that thing?",
  "id" : 395939414473314304,
  "in_reply_to_status_id" : 395939086780751872,
  "created_at" : "2013-10-31 15:44:47 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 0, 6 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395926620864659457",
  "geo" : { },
  "id_str" : "395926720458407936",
  "in_reply_to_user_id" : 205281746,
  "text" : "@ahuj9 i bet you say \"soda\" too",
  "id" : 395926720458407936,
  "in_reply_to_status_id" : 395926620864659457,
  "created_at" : "2013-10-31 14:54:20 +0000",
  "in_reply_to_screen_name" : "ahuj9",
  "in_reply_to_user_id_str" : "205281746",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 0, 6 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395926426274115584",
  "geo" : { },
  "id_str" : "395926548353531905",
  "in_reply_to_user_id" : 205281746,
  "text" : "@ahuj9 uh you mean \"the 90\"? i thought you were from buffalo.",
  "id" : 395926548353531905,
  "in_reply_to_status_id" : 395926426274115584,
  "created_at" : "2013-10-31 14:53:39 +0000",
  "in_reply_to_screen_name" : "ahuj9",
  "in_reply_to_user_id_str" : "205281746",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/395907979343454210\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/yeq810Qa2f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX6MNZYCUAA436o.jpg",
      "id_str" : "395907979033071616",
      "id" : 395907979033071616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX6MNZYCUAA436o.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/yeq810Qa2f"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395907979343454210",
  "text" : "Now we\u2019re getting ads for gems? http:\/\/t.co\/yeq810Qa2f",
  "id" : 395907979343454210,
  "created_at" : "2013-10-31 13:39:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395730510674419712",
  "text" : "Just discovered shake to undo on iOS. It\u2019s on every text field\/view. No idea how I didn\u2019t know about this before.",
  "id" : 395730510674419712,
  "created_at" : "2013-10-31 01:54:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 0, 11 ],
      "id_str" : "2355631",
      "id" : 2355631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/twdFAM6rfW",
      "expanded_url" : "https:\/\/github.com\/JugglerShu\/XVim",
      "display_url" : "github.com\/JugglerShu\/XVim"
    } ]
  },
  "in_reply_to_status_id_str" : "395575227415281664",
  "geo" : { },
  "id_str" : "395577534818947073",
  "in_reply_to_user_id" : 2355631,
  "text" : "@lmarburger a lot of patience and https:\/\/t.co\/twdFAM6rfW",
  "id" : 395577534818947073,
  "in_reply_to_status_id" : 395575227415281664,
  "created_at" : "2013-10-30 15:46:48 +0000",
  "in_reply_to_screen_name" : "lmarburger",
  "in_reply_to_user_id_str" : "2355631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Warshak",
      "screen_name" : "iwarshak",
      "indices" : [ 0, 9 ],
      "id_str" : "892371",
      "id" : 892371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395571732762726402",
  "geo" : { },
  "id_str" : "395573002022047744",
  "in_reply_to_user_id" : 892371,
  "text" : "@iwarshak that is a busier stretch of road that I live &lt; 5 minutes from, but I agree...it's fucked up.",
  "id" : 395573002022047744,
  "in_reply_to_status_id" : 395571732762726402,
  "created_at" : "2013-10-30 15:28:47 +0000",
  "in_reply_to_screen_name" : "iwarshak",
  "in_reply_to_user_id_str" : "892371",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/LgTb3sXsD9",
      "expanded_url" : "http:\/\/www.cnn.com\/video\/data\/2.0\/video\/bestoftv\/2013\/10\/29\/dnt-bus-driver-saves-woman-from-jumping-off-ledge.wivb.html",
      "display_url" : "cnn.com\/video\/data\/2.0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395569470954946560",
  "text" : "Holy shit, bus driver on my bus line on Buffalo saved a woman from jumping off an overpass (with video of it!): http:\/\/t.co\/LgTb3sXsD9",
  "id" : 395569470954946560,
  "created_at" : "2013-10-30 15:14:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clay Johnson",
      "screen_name" : "cjoh",
      "indices" : [ 3, 8 ],
      "id_str" : "3364",
      "id" : 3364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395548127102394369",
  "text" : "RT @cjoh: The new digital divide isn't between rich and poor, it's between government and us. And it's just as dangerous.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395546999371857920",
    "text" : "The new digital divide isn't between rich and poor, it's between government and us. And it's just as dangerous.",
    "id" : 395546999371857920,
    "created_at" : "2013-10-30 13:45:28 +0000",
    "user" : {
      "name" : "Clay Johnson",
      "screen_name" : "cjoh",
      "protected" : false,
      "id_str" : "3364",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000681085924\/1e889c21e483e36bd67798eef968375e_normal.jpeg",
      "id" : 3364,
      "verified" : false
    }
  },
  "id" : 395548127102394369,
  "created_at" : "2013-10-30 13:49:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/395249760732323840\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/1HtsJQ92YI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXw1kDKCIAARJcu.png",
      "id_str" : "395249760740712448",
      "id" : 395249760740712448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXw1kDKCIAARJcu.png",
      "sizes" : [ {
        "h" : 417,
        "resize" : "fit",
        "w" : 578
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 417,
        "resize" : "fit",
        "w" : 578
      }, {
        "h" : 417,
        "resize" : "fit",
        "w" : 578
      } ],
      "display_url" : "pic.twitter.com\/1HtsJQ92YI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395249760732323840",
  "text" : "Current status: http:\/\/t.co\/1HtsJQ92YI",
  "id" : 395249760732323840,
  "created_at" : "2013-10-29 18:04:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Lynn Kwon-Dzikiy",
      "screen_name" : "NForestKorean",
      "indices" : [ 12, 26 ],
      "id_str" : "148401790",
      "id" : 148401790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394933935878053888",
  "geo" : { },
  "id_str" : "395047042881306624",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @NForestKorean thanks for the cookies!!",
  "id" : 395047042881306624,
  "in_reply_to_status_id" : 394933935878053888,
  "created_at" : "2013-10-29 04:38:49 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 17, 31 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394853752919715840",
  "geo" : { },
  "id_str" : "395035157759266816",
  "in_reply_to_user_id" : 358178745,
  "text" : "@TonyFrydBologna @coworkbuffalo thanks! Found it in DeviantART somewhere...",
  "id" : 395035157759266816,
  "in_reply_to_status_id" : 394853752919715840,
  "created_at" : "2013-10-29 03:51:35 +0000",
  "in_reply_to_screen_name" : "TechGarden_Tony",
  "in_reply_to_user_id_str" : "358178745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/Z8iX4wTB1R",
      "expanded_url" : "http:\/\/flic.kr\/p\/h5aw1p",
      "display_url" : "flic.kr\/p\/h5aw1p"
    } ]
  },
  "geo" : { },
  "id_str" : "395024240942256128",
  "text" : "Sssh!  http:\/\/t.co\/Z8iX4wTB1R",
  "id" : 395024240942256128,
  "created_at" : "2013-10-29 03:08:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    }, {
      "name" : "Caryn",
      "screen_name" : "Caryn1420",
      "indices" : [ 6, 16 ],
      "id_str" : "133676678",
      "id" : 133676678
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 23, 33 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394990259643379712",
  "geo" : { },
  "id_str" : "394993833890824192",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo @Caryn1420 whelp @aquaranto cried too.",
  "id" : 394993833890824192,
  "in_reply_to_status_id" : 394990259643379712,
  "created_at" : "2013-10-29 01:07:23 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 0, 12 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394941834704982017",
  "geo" : { },
  "id_str" : "394941985363992576",
  "in_reply_to_user_id" : 14231571,
  "text" : "@marcoarment it's very janky on iOS7. animations are very choppy.",
  "id" : 394941985363992576,
  "in_reply_to_status_id" : 394941834704982017,
  "created_at" : "2013-10-28 21:41:21 +0000",
  "in_reply_to_screen_name" : "marcoarment",
  "in_reply_to_user_id_str" : "14231571",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394921175869960192",
  "geo" : { },
  "id_str" : "394921418057449472",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove \u00E6roplane",
  "id" : 394921418057449472,
  "in_reply_to_status_id" : 394921175869960192,
  "created_at" : "2013-10-28 20:19:38 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Redpath",
      "screen_name" : "lukeredpath",
      "indices" : [ 0, 12 ],
      "id_str" : "72573",
      "id" : 72573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394909840252084224",
  "geo" : { },
  "id_str" : "394910329475317760",
  "in_reply_to_user_id" : 72573,
  "text" : "@lukeredpath the majority of that work has been contributors after us! lots of wiki edits in the past though :)",
  "id" : 394910329475317760,
  "in_reply_to_status_id" : 394909840252084224,
  "created_at" : "2013-10-28 19:35:34 +0000",
  "in_reply_to_screen_name" : "lukeredpath",
  "in_reply_to_user_id_str" : "72573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason",
      "screen_name" : "peregrine",
      "indices" : [ 0, 10 ],
      "id_str" : "896131",
      "id" : 896131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394888311841374208",
  "geo" : { },
  "id_str" : "394891136721887232",
  "in_reply_to_user_id" : 896131,
  "text" : "@peregrine I would have happily used a glitch to skip the water temple.",
  "id" : 394891136721887232,
  "in_reply_to_status_id" : 394888311841374208,
  "created_at" : "2013-10-28 18:19:18 +0000",
  "in_reply_to_screen_name" : "peregrine",
  "in_reply_to_user_id_str" : "896131",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Weston Platter",
      "screen_name" : "westonplatter",
      "indices" : [ 0, 14 ],
      "id_str" : "114336396",
      "id" : 114336396
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 64, 71 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 72, 78 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 79, 86 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394886017267675136",
  "geo" : { },
  "id_str" : "394886773953675264",
  "in_reply_to_user_id" : 114336396,
  "text" : "@westonplatter maybe someone from the team can help though! \/cc @sferik @cmeik @lsegal have some time to help with rails4?",
  "id" : 394886773953675264,
  "in_reply_to_status_id" : 394886017267675136,
  "created_at" : "2013-10-28 18:01:58 +0000",
  "in_reply_to_screen_name" : "westonplatter",
  "in_reply_to_user_id_str" : "114336396",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Weston Platter",
      "screen_name" : "westonplatter",
      "indices" : [ 0, 14 ],
      "id_str" : "114336396",
      "id" : 114336396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394886017267675136",
  "geo" : { },
  "id_str" : "394886572484472832",
  "in_reply_to_user_id" : 114336396,
  "text" : "@westonplatter cool. i had a branch from a while back (last railsconf!) but didn't get a chance to look into it and most likely will not.",
  "id" : 394886572484472832,
  "in_reply_to_status_id" : 394886017267675136,
  "created_at" : "2013-10-28 18:01:10 +0000",
  "in_reply_to_screen_name" : "westonplatter",
  "in_reply_to_user_id_str" : "114336396",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394885835478552577",
  "geo" : { },
  "id_str" : "394886493862260736",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss yeah, back up a few seconds from that start point to see it in action. Ridiculous.",
  "id" : 394886493862260736,
  "in_reply_to_status_id" : 394885835478552577,
  "created_at" : "2013-10-28 18:00:51 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/RYPtaZkDgg",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=0M7IINwTFVw&t=16m2s",
      "display_url" : "youtube.com\/watch?v=0M7IIN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394881583611531264",
  "text" : "Insane walkthrough and speed run of Ocarina of Time using (extremely involved) glitches: http:\/\/t.co\/RYPtaZkDgg",
  "id" : 394881583611531264,
  "created_at" : "2013-10-28 17:41:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394866095095435264",
  "text" : "OH \"Have you been experimenting with emoji again?\"",
  "id" : 394866095095435264,
  "created_at" : "2013-10-28 16:39:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Lindeman",
      "screen_name" : "alindeman",
      "indices" : [ 0, 10 ],
      "id_str" : "13235612",
      "id" : 13235612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394861179736055808",
  "geo" : { },
  "id_str" : "394862377583136768",
  "in_reply_to_user_id" : 13235612,
  "text" : "@alindeman did you find the timezone that's off by 00:15 yet? It's Ultra-Fun\u2122 !",
  "id" : 394862377583136768,
  "in_reply_to_status_id" : 394861179736055808,
  "created_at" : "2013-10-28 16:25:01 +0000",
  "in_reply_to_screen_name" : "alindeman",
  "in_reply_to_user_id_str" : "13235612",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 0, 6 ],
      "id_str" : "18673",
      "id" : 18673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394831284285243392",
  "geo" : { },
  "id_str" : "394831805578498048",
  "in_reply_to_user_id" : 18673,
  "text" : "@aeden easy drive...given the snow isn't bad :)",
  "id" : 394831805578498048,
  "in_reply_to_status_id" : 394831284285243392,
  "created_at" : "2013-10-28 14:23:32 +0000",
  "in_reply_to_screen_name" : "aeden",
  "in_reply_to_user_id_str" : "18673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish: From The Road",
      "screen_name" : "Phish_FTR",
      "indices" : [ 3, 13 ],
      "id_str" : "153850397",
      "id" : 153850397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394652798245408768",
  "text" : "RT @Phish_FTR: SET ONE: Rock &amp; Roll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.phish.com\/\" rel=\"nofollow\"\u003EPhish From the Road\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "394617036329852929",
    "text" : "SET ONE: Rock &amp; Roll",
    "id" : 394617036329852929,
    "created_at" : "2013-10-28 00:10:07 +0000",
    "user" : {
      "name" : "Phish: From The Road",
      "screen_name" : "Phish_FTR",
      "protected" : false,
      "id_str" : "153850397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000065818163\/de7aca9d2eb0c2005f7df69ad86aafa4_normal.jpeg",
      "id" : 153850397,
      "verified" : false
    }
  },
  "id" : 394652798245408768,
  "created_at" : "2013-10-28 02:32:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 44, 50 ],
      "id_str" : "5877822",
      "id" : 5877822
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 51, 59 ],
      "id_str" : "670283",
      "id" : 670283
    }, {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 60, 69 ],
      "id_str" : "756161",
      "id" : 756161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/hs1Ea18Cpg",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ozPFRRBah2E",
      "display_url" : "youtube.com\/watch?v=ozPFRR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394567337551990785",
  "text" : "KSP motorcycles! http:\/\/t.co\/hs1Ea18Cpg \/cc @jamis @drbrain @zspencer",
  "id" : 394567337551990785,
  "created_at" : "2013-10-27 20:52:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/pZpcuTAAG8",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=-NwKZ9ZsgGA",
      "display_url" : "youtube.com\/watch?v=-NwKZ9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394554827859963904",
  "text" : "Actually just listen to the whole thing: http:\/\/t.co\/pZpcuTAAG8",
  "id" : 394554827859963904,
  "created_at" : "2013-10-27 20:02:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/lq8A5FN8Zg",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=2duFNff_ArY",
      "display_url" : "youtube.com\/watch?v=2duFNf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394553721448722433",
  "text" : ":( http:\/\/t.co\/lq8A5FN8Zg",
  "id" : 394553721448722433,
  "created_at" : "2013-10-27 19:58:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Worthington",
      "screen_name" : "cew821",
      "indices" : [ 0, 7 ],
      "id_str" : "6068502",
      "id" : 6068502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394541079816855552",
  "geo" : { },
  "id_str" : "394552396287721472",
  "in_reply_to_user_id" : 6068502,
  "text" : "@cew821 nice!",
  "id" : 394552396287721472,
  "in_reply_to_status_id" : 394541079816855552,
  "created_at" : "2013-10-27 19:53:16 +0000",
  "in_reply_to_screen_name" : "cew821",
  "in_reply_to_user_id_str" : "6068502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/u2Wa9t3iq7",
      "expanded_url" : "http:\/\/flic.kr\/p\/h2wBEZ",
      "display_url" : "flic.kr\/p\/h2wBEZ"
    } ]
  },
  "geo" : { },
  "id_str" : "394536049160224768",
  "text" : "Pumpkins! http:\/\/t.co\/u2Wa9t3iq7",
  "id" : 394536049160224768,
  "created_at" : "2013-10-27 18:48:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/pUC7tdWiOE",
      "expanded_url" : "http:\/\/flic.kr\/p\/h2oSHa",
      "display_url" : "flic.kr\/p\/h2oSHa"
    } ]
  },
  "geo" : { },
  "id_str" : "394517781057896448",
  "text" : "Caught a cat in the tree, very confused. http:\/\/t.co\/pUC7tdWiOE",
  "id" : 394517781057896448,
  "created_at" : "2013-10-27 17:35:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "756161",
      "id" : 756161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394516492189855746",
  "geo" : { },
  "id_str" : "394516690781753344",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer tried for hours yesterday to get a mini SSTO into orbit. Not easy.",
  "id" : 394516690781753344,
  "in_reply_to_status_id" : 394516492189855746,
  "created_at" : "2013-10-27 17:31:23 +0000",
  "in_reply_to_screen_name" : "zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/AQFjeniZmz",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush\/2960047774\/",
      "display_url" : "flickr.com\/photos\/qrush\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394507621501128706",
  "text" : "My Octocat pumpkin was a long time ago: http:\/\/t.co\/AQFjeniZmz",
  "id" : 394507621501128706,
  "created_at" : "2013-10-27 16:55:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394498790478336000",
  "geo" : { },
  "id_str" : "394499066366672898",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats you're hacked bro",
  "id" : 394499066366672898,
  "in_reply_to_status_id" : 394498790478336000,
  "created_at" : "2013-10-27 16:21:21 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logan Serman",
      "screen_name" : "loganserman",
      "indices" : [ 0, 12 ],
      "id_str" : "17856146",
      "id" : 17856146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394290003108315137",
  "geo" : { },
  "id_str" : "394295328683220993",
  "in_reply_to_user_id" : 17856146,
  "text" : "@loganserman haven't heard any issues. yep!",
  "id" : 394295328683220993,
  "in_reply_to_status_id" : 394290003108315137,
  "created_at" : "2013-10-27 02:51:46 +0000",
  "in_reply_to_screen_name" : "loganserman",
  "in_reply_to_user_id_str" : "17856146",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish: From The Road",
      "screen_name" : "Phish_FTR",
      "indices" : [ 21, 31 ],
      "id_str" : "153850397",
      "id" : 153850397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394260509140082688",
  "text" : "Hailing outside, and @Phish_FTR streaming inside. Fall.",
  "id" : 394260509140082688,
  "created_at" : "2013-10-27 00:33:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Gtz9faWcox",
      "expanded_url" : "http:\/\/phish.com\/",
      "display_url" : "phish.com"
    }, {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/DuRchlk1QD",
      "expanded_url" : "http:\/\/phish.com\/tours\/fall-2013\/",
      "display_url" : "phish.com\/tours\/fall-201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394257450724892673",
  "text" : "http:\/\/t.co\/Gtz9faWcox got a great responsive redesign. http:\/\/t.co\/DuRchlk1QD looks fantastic. What other band does this?",
  "id" : 394257450724892673,
  "created_at" : "2013-10-27 00:21:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394240576700166144",
  "text" : "Remember the Harlem Shake?",
  "id" : 394240576700166144,
  "created_at" : "2013-10-26 23:14:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logan Serman",
      "screen_name" : "loganserman",
      "indices" : [ 0, 12 ],
      "id_str" : "17856146",
      "id" : 17856146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394127032591740928",
  "geo" : { },
  "id_str" : "394153618188009473",
  "in_reply_to_user_id" : 17856146,
  "text" : "@loganserman the only pure native view is the list of projects. Everything else is web.",
  "id" : 394153618188009473,
  "in_reply_to_status_id" : 394127032591740928,
  "created_at" : "2013-10-26 17:28:40 +0000",
  "in_reply_to_screen_name" : "loganserman",
  "in_reply_to_user_id_str" : "17856146",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394087298687852544",
  "geo" : { },
  "id_str" : "394088934126264321",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos no seriously I'll be down soon.",
  "id" : 394088934126264321,
  "in_reply_to_status_id" : 394087298687852544,
  "created_at" : "2013-10-26 13:11:38 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394087298687852544",
  "geo" : { },
  "id_str" : "394088869055832064",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos I guess so.",
  "id" : 394088869055832064,
  "in_reply_to_status_id" : 394087298687852544,
  "created_at" : "2013-10-26 13:11:22 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iRoller",
      "screen_name" : "iroller",
      "indices" : [ 0, 8 ],
      "id_str" : "185605018",
      "id" : 185605018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394055952942764032",
  "geo" : { },
  "id_str" : "394086606811828224",
  "in_reply_to_user_id" : 185605018,
  "text" : "@iroller congrats!!!",
  "id" : 394086606811828224,
  "in_reply_to_status_id" : 394055952942764032,
  "created_at" : "2013-10-26 13:02:23 +0000",
  "in_reply_to_screen_name" : "iroller",
  "in_reply_to_user_id_str" : "185605018",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 3, 10 ],
      "id_str" : "14432203",
      "id" : 14432203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/kIwVOOmpTO",
      "expanded_url" : "http:\/\/gawker.com\/how-to-change-your-twitter-name-for-halloween-1452369567",
      "display_url" : "gawker.com\/how-to-change-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393938072607281152",
  "text" : "RT @will_j: How to change your twitter name for halloween: http:\/\/t.co\/kIwVOOmpTO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/kIwVOOmpTO",
        "expanded_url" : "http:\/\/gawker.com\/how-to-change-your-twitter-name-for-halloween-1452369567",
        "display_url" : "gawker.com\/how-to-change-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "393867892791713792",
    "text" : "How to change your twitter name for halloween: http:\/\/t.co\/kIwVOOmpTO",
    "id" : 393867892791713792,
    "created_at" : "2013-10-25 22:33:18 +0000",
    "user" : {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "protected" : false,
      "id_str" : "14432203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552528808104820736\/Dt-wRY80_normal.jpeg",
      "id" : 14432203,
      "verified" : false
    }
  },
  "id" : 393938072607281152,
  "created_at" : "2013-10-26 03:12:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/YNIa1fKYKT",
      "expanded_url" : "http:\/\/flic.kr\/p\/g8fPw7",
      "display_url" : "flic.kr\/p\/g8fPw7"
    } ]
  },
  "geo" : { },
  "id_str" : "393936661408522240",
  "text" : "Geddy turned 3 today. ~2.5 years of being a Husky wrangler. I wouldn't have it any other way. http:\/\/t.co\/YNIa1fKYKT",
  "id" : 393936661408522240,
  "created_at" : "2013-10-26 03:06:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 11, 25 ],
      "id_str" : "5795572",
      "id" : 5795572
    }, {
      "name" : "Nate Benson",
      "screen_name" : "natebenson",
      "indices" : [ 26, 37 ],
      "id_str" : "25678101",
      "id" : 25678101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/qce9rJP2op",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=i6zaVYWLTkU",
      "display_url" : "youtube.com\/watch?v=i6zaVY\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "393842380714938369",
  "geo" : { },
  "id_str" : "393844160580448256",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef @buffalopundit @natebenson http:\/\/t.co\/qce9rJP2op",
  "id" : 393844160580448256,
  "in_reply_to_status_id" : 393842380714938369,
  "created_at" : "2013-10-25 20:58:59 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393719904039608320",
  "geo" : { },
  "id_str" : "393720119781625856",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej there's cell phone networks within range of this?!?",
  "id" : 393720119781625856,
  "in_reply_to_status_id" : 393719904039608320,
  "created_at" : "2013-10-25 12:46:06 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Dot Com",
      "screen_name" : "BuffaloDotCom",
      "indices" : [ 3, 17 ],
      "id_str" : "25321479",
      "id" : 25321479
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 75, 89 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/R6T3sDqXAj",
      "expanded_url" : "http:\/\/www.buffalo.com\/news\/blog\/coworkbuffalo-to-swing-to-main-street\/53014",
      "display_url" : "buffalo.com\/news\/blog\/cowo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393481073339817984",
  "text" : "RT @BuffaloDotCom: Traffic's coming to the 600 block of Main Street? Welp, @CoworkBuffalo is hitchin' a ride. Details on the move: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 56, 70 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/R6T3sDqXAj",
        "expanded_url" : "http:\/\/www.buffalo.com\/news\/blog\/coworkbuffalo-to-swing-to-main-street\/53014",
        "display_url" : "buffalo.com\/news\/blog\/cowo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "393445799860109312",
    "text" : "Traffic's coming to the 600 block of Main Street? Welp, @CoworkBuffalo is hitchin' a ride. Details on the move: http:\/\/t.co\/R6T3sDqXAj",
    "id" : 393445799860109312,
    "created_at" : "2013-10-24 18:36:03 +0000",
    "user" : {
      "name" : "Buffalo Dot Com",
      "screen_name" : "BuffaloDotCom",
      "protected" : false,
      "id_str" : "25321479",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467067080139759616\/zJQOtsXK_normal.jpeg",
      "id" : 25321479,
      "verified" : false
    }
  },
  "id" : 393481073339817984,
  "created_at" : "2013-10-24 20:56:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 0, 11 ],
      "id_str" : "38408851",
      "id" : 38408851
    }, {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 12, 19 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 20, 35 ],
      "id_str" : "155998525",
      "id" : 155998525
    }, {
      "name" : "Bill Chapman",
      "screen_name" : "byllc",
      "indices" : [ 36, 42 ],
      "id_str" : "34287352",
      "id" : 34287352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393131232914968576",
  "geo" : { },
  "id_str" : "393474115631214592",
  "in_reply_to_user_id" : 38408851,
  "text" : "@Jonplussed @zobar2 @1ofyourmeteors @byllc &lt;3",
  "id" : 393474115631214592,
  "in_reply_to_status_id" : 393131232914968576,
  "created_at" : "2013-10-24 20:28:34 +0000",
  "in_reply_to_screen_name" : "Jonplussed",
  "in_reply_to_user_id_str" : "38408851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/2PapqUgSwL",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=IY2j_GPIqRA",
      "display_url" : "youtube.com\/watch?v=IY2j_G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393471731282632704",
  "text" : "Current status: https:\/\/t.co\/2PapqUgSwL",
  "id" : 393471731282632704,
  "created_at" : "2013-10-24 20:19:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 85, 93 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/S6lDzM79Kn",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2013\/06\/healthcaregov-code-developed-by-the-people-and-for-the-people-released-back-to-the-people\/277295\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393434472864964608",
  "text" : "It's getting super weird to see Jekyll in the Atlantic... http:\/\/t.co\/S6lDzM79Kn \/cc @mojombo",
  "id" : 393434472864964608,
  "created_at" : "2013-10-24 17:51:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric S",
      "screen_name" : "MutualArising",
      "indices" : [ 0, 14 ],
      "id_str" : "15913837",
      "id" : 15913837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393419455948017664",
  "geo" : { },
  "id_str" : "393419969200783360",
  "in_reply_to_user_id" : 15913837,
  "text" : "@MutualArising it was pretty ridiculous. Maze was my favorite, Page was on fire.",
  "id" : 393419969200783360,
  "in_reply_to_status_id" : 393419455948017664,
  "created_at" : "2013-10-24 16:53:24 +0000",
  "in_reply_to_screen_name" : "MutualArising",
  "in_reply_to_user_id_str" : "15913837",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeseph Meyers",
      "screen_name" : "jesephm",
      "indices" : [ 0, 8 ],
      "id_str" : "277334498",
      "id" : 277334498
    }, {
      "name" : "Forged In Buffalo",
      "screen_name" : "ForgedBuffalo",
      "indices" : [ 9, 23 ],
      "id_str" : "1686786337",
      "id" : 1686786337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393419179409149952",
  "geo" : { },
  "id_str" : "393419783900647424",
  "in_reply_to_user_id" : 277334498,
  "text" : "@jesephm @ForgedBuffalo It's pathetic.",
  "id" : 393419783900647424,
  "in_reply_to_status_id" : 393419179409149952,
  "created_at" : "2013-10-24 16:52:40 +0000",
  "in_reply_to_screen_name" : "jesephm",
  "in_reply_to_user_id_str" : "277334498",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393417692612268032",
  "text" : "Narrowed down the twitter bio to the bare essentials.",
  "id" : 393417692612268032,
  "created_at" : "2013-10-24 16:44:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i aint even Bill Nye",
      "screen_name" : "Bill_Nye_tho",
      "indices" : [ 3, 16 ],
      "id_str" : "700374013",
      "id" : 700374013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393127681102843904",
  "text" : "RT @Bill_Nye_tho: straight up i won't read a graph if it ain't a pie graph. Just put that shit in a circle b keep it neat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393123079121289216",
    "text" : "straight up i won't read a graph if it ain't a pie graph. Just put that shit in a circle b keep it neat",
    "id" : 393123079121289216,
    "created_at" : "2013-10-23 21:13:40 +0000",
    "user" : {
      "name" : "i aint even Bill Nye",
      "screen_name" : "Bill_Nye_tho",
      "protected" : false,
      "id_str" : "700374013",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2404907709\/lonbhslatqgxk1p9z26p_normal.png",
      "id" : 700374013,
      "verified" : false
    }
  },
  "id" : 393127681102843904,
  "created_at" : "2013-10-23 21:31:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "Lucas Gardner",
      "screen_name" : "Lucas_Gardner",
      "indices" : [ 16, 30 ],
      "id_str" : "127359951",
      "id" : 127359951
    }, {
      "name" : "i aint even Bill Nye",
      "screen_name" : "Bill_Nye_tho",
      "indices" : [ 31, 44 ],
      "id_str" : "700374013",
      "id" : 700374013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393127198502424576",
  "geo" : { },
  "id_str" : "393127617391382528",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten @Lucas_Gardner @Bill_Nye_tho YES!!",
  "id" : 393127617391382528,
  "in_reply_to_status_id" : 393127198502424576,
  "created_at" : "2013-10-23 21:31:42 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tricia Marcolini",
      "screen_name" : "triciamarcolini",
      "indices" : [ 0, 16 ],
      "id_str" : "24007592",
      "id" : 24007592
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 17, 31 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393126493569966080",
  "geo" : { },
  "id_str" : "393126858914418689",
  "in_reply_to_user_id" : 24007592,
  "text" : "@triciamarcolini @coworkbuffalo basically the same as the existing space.",
  "id" : 393126858914418689,
  "in_reply_to_status_id" : 393126493569966080,
  "created_at" : "2013-10-23 21:28:41 +0000",
  "in_reply_to_screen_name" : "triciamarcolini",
  "in_reply_to_user_id_str" : "24007592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 0, 11 ],
      "id_str" : "38408851",
      "id" : 38408851
    }, {
      "name" : "Bendyworks",
      "screen_name" : "bendyworks",
      "indices" : [ 12, 23 ],
      "id_str" : "31920143",
      "id" : 31920143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393123390426333184",
  "geo" : { },
  "id_str" : "393125147806138368",
  "in_reply_to_user_id" : 38408851,
  "text" : "@Jonplussed @bendyworks called it",
  "id" : 393125147806138368,
  "in_reply_to_status_id" : 393123390426333184,
  "created_at" : "2013-10-23 21:21:53 +0000",
  "in_reply_to_screen_name" : "Jonplussed",
  "in_reply_to_user_id_str" : "38408851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    }, {
      "name" : "Jon Leighton",
      "screen_name" : "jonleighton",
      "indices" : [ 7, 19 ],
      "id_str" : "14330565",
      "id" : 14330565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393120662794928128",
  "geo" : { },
  "id_str" : "393121858846875648",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz @jonleighton we're having an ops meeting about this tomorrow. not sure about the short term fix",
  "id" : 393121858846875648,
  "in_reply_to_status_id" : 393120662794928128,
  "created_at" : "2013-10-23 21:08:49 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 12, 22 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Beardo",
      "screen_name" : "Mechaphil",
      "indices" : [ 23, 33 ],
      "id_str" : "250785234",
      "id" : 250785234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/jdEanKlPPc",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food",
      "display_url" : "coworkbuffalo.com\/food"
    } ]
  },
  "in_reply_to_status_id_str" : "393091706964303873",
  "geo" : { },
  "id_str" : "393091909154906113",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @magnachef @Mechaphil http:\/\/t.co\/jdEanKlPPc will work on any device.",
  "id" : 393091909154906113,
  "in_reply_to_status_id" : 393091706964303873,
  "created_at" : "2013-10-23 19:09:49 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/twdFAM6rfW",
      "expanded_url" : "https:\/\/github.com\/JugglerShu\/XVim",
      "display_url" : "github.com\/JugglerShu\/XVim"
    } ]
  },
  "geo" : { },
  "id_str" : "393073872477495296",
  "text" : "Nothing has made me feel more \"at home\" in Xcode than XVim. Give it a shot. https:\/\/t.co\/twdFAM6rfW",
  "id" : 393073872477495296,
  "created_at" : "2013-10-23 17:58:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    }, {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 21, 28 ],
      "id_str" : "14432203",
      "id" : 14432203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393015858592628738",
  "geo" : { },
  "id_str" : "393044684194316288",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff maybe if @will_j narrated a cricket match. or something else extremely British.",
  "id" : 393044684194316288,
  "in_reply_to_status_id" : 393015858592628738,
  "created_at" : "2013-10-23 16:02:09 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 26, 40 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/5YUwQb4X28",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/newsletter\/2013\/10\/21\/hey-coworkbuffalo-has-some-pretty-big-news.html",
      "display_url" : "coworkbuffalo.com\/newsletter\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393023174108909568",
  "text" : "Super excited about this: @coworkbuffalo is moving! (a few blocks!) Bigger and better things for Buffalo's future. http:\/\/t.co\/5YUwQb4X28",
  "id" : 393023174108909568,
  "created_at" : "2013-10-23 14:36:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00E9r\u00E9my Lecour",
      "screen_name" : "jlecour",
      "indices" : [ 0, 8 ],
      "id_str" : "14587814",
      "id" : 14587814
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 27, 38 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392939288796876800",
  "geo" : { },
  "id_str" : "393017197972299776",
  "in_reply_to_user_id" : 14587814,
  "text" : "@jlecour i've been bugging @kevinpurdy for a while about this. I think we should do one.",
  "id" : 393017197972299776,
  "in_reply_to_status_id" : 392939288796876800,
  "created_at" : "2013-10-23 14:12:56 +0000",
  "in_reply_to_screen_name" : "jlecour",
  "in_reply_to_user_id_str" : "14587814",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392991508124540928",
  "geo" : { },
  "id_str" : "392999845188739072",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff this is the most British thing I have ever watched",
  "id" : 392999845188739072,
  "in_reply_to_status_id" : 392991508124540928,
  "created_at" : "2013-10-23 13:03:59 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "indices" : [ 0, 13 ],
      "id_str" : "35943",
      "id" : 35943
    }, {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "indices" : [ 14, 19 ],
      "id_str" : "12534",
      "id" : 12534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392736824697049088",
  "geo" : { },
  "id_str" : "392738965620400128",
  "in_reply_to_user_id" : 35943,
  "text" : "@karenmcgrane @beep 1) FIREWORKS!",
  "id" : 392738965620400128,
  "in_reply_to_status_id" : 392736824697049088,
  "created_at" : "2013-10-22 19:47:20 +0000",
  "in_reply_to_screen_name" : "karenmcgrane",
  "in_reply_to_user_id_str" : "35943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emojisaurus",
      "screen_name" : "emojisaurus",
      "indices" : [ 58, 70 ],
      "id_str" : "1972089373",
      "id" : 1972089373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/xzU5ynhR6T",
      "expanded_url" : "http:\/\/emojisaurus.com\/phrases\/233-golf-clap#emojigram_193",
      "display_url" : "emojisaurus.com\/phrases\/233-go\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392731939318149120",
  "text" : "Cool emojigram for \"Golf clap\" http:\/\/t.co\/xzU5ynhR6T via @emojisaurus",
  "id" : 392731939318149120,
  "created_at" : "2013-10-22 19:19:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 0, 5 ],
      "id_str" : "20941662",
      "id" : 20941662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392698783613452288",
  "geo" : { },
  "id_str" : "392698885262434304",
  "in_reply_to_user_id" : 20941662,
  "text" : "@JEG2 @JZ you guys need to get out more",
  "id" : 392698885262434304,
  "in_reply_to_status_id" : 392698783613452288,
  "created_at" : "2013-10-22 17:08:04 +0000",
  "in_reply_to_screen_name" : "JEG2",
  "in_reply_to_user_id_str" : "20941662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 22, 32 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/zzt7eugql7",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3657-37signals-works-remotely",
      "display_url" : "37signals.com\/svn\/posts\/3657\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392668434602807297",
  "text" : "Proud to be a part of @37signals and working REMOTE: http:\/\/t.co\/zzt7eugql7",
  "id" : 392668434602807297,
  "created_at" : "2013-10-22 15:07:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 3, 12 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/N9RBShFsNY",
      "expanded_url" : "http:\/\/37signals.com\/remote\/video",
      "display_url" : "37signals.com\/remote\/video"
    } ]
  },
  "geo" : { },
  "id_str" : "392667822121160704",
  "text" : "RT @shildner: Want to know why working remotely kicks ass?  Dogs.  Lots of dogs.  http:\/\/t.co\/N9RBShFsNY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/N9RBShFsNY",
        "expanded_url" : "http:\/\/37signals.com\/remote\/video",
        "display_url" : "37signals.com\/remote\/video"
      } ]
    },
    "geo" : { },
    "id_str" : "392667538275831808",
    "text" : "Want to know why working remotely kicks ass?  Dogs.  Lots of dogs.  http:\/\/t.co\/N9RBShFsNY",
    "id" : 392667538275831808,
    "created_at" : "2013-10-22 15:03:31 +0000",
    "user" : {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "protected" : false,
      "id_str" : "16225196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440887180529897472\/Hp3eZzzI_normal.jpeg",
      "id" : 16225196,
      "verified" : false
    }
  },
  "id" : 392667822121160704,
  "created_at" : "2013-10-22 15:04:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Austin",
      "screen_name" : "sjaustin",
      "indices" : [ 0, 9 ],
      "id_str" : "1798581",
      "id" : 1798581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392643495468339200",
  "in_reply_to_user_id" : 1798581,
  "text" : "@sjaustin did you find one yet? I have one open again.",
  "id" : 392643495468339200,
  "created_at" : "2013-10-22 13:27:58 +0000",
  "in_reply_to_screen_name" : "sjaustin",
  "in_reply_to_user_id_str" : "1798581",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Kim Jong Will ",
      "screen_name" : "williamjdix",
      "indices" : [ 14, 26 ],
      "id_str" : "14522995",
      "id" : 14522995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392490687280582656",
  "geo" : { },
  "id_str" : "392491338760867840",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @williamjdix you forgot about the odor of most shops where drafts\/tournaments occur \uD83D\uDC43\uD83D\uDE4A",
  "id" : 392491338760867840,
  "in_reply_to_status_id" : 392490687280582656,
  "created_at" : "2013-10-22 03:23:21 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 14, 25 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392488945457434624",
  "geo" : { },
  "id_str" : "392489264090324992",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @tenderlove agreed but usually you can ask about new stuff. Usually prebuilt decks are massively unfair.",
  "id" : 392489264090324992,
  "in_reply_to_status_id" : 392488945457434624,
  "created_at" : "2013-10-22 03:15:07 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coda Hale (cont.)",
      "screen_name" : "coda",
      "indices" : [ 3, 8 ],
      "id_str" : "637533",
      "id" : 637533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/7gQBpRkGJg",
      "expanded_url" : "http:\/\/www.imaginaryfutures.net\/2007\/04\/17\/the-californian-ideology-2",
      "display_url" : "imaginaryfutures.net\/2007\/04\/17\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392487528063709184",
  "text" : "RT @coda: If you haven't read The Californian Ideology yet, you probably should: http:\/\/t.co\/7gQBpRkGJg.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/7gQBpRkGJg",
        "expanded_url" : "http:\/\/www.imaginaryfutures.net\/2007\/04\/17\/the-californian-ideology-2",
        "display_url" : "imaginaryfutures.net\/2007\/04\/17\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "392173876978806784",
    "text" : "If you haven't read The Californian Ideology yet, you probably should: http:\/\/t.co\/7gQBpRkGJg.",
    "id" : 392173876978806784,
    "created_at" : "2013-10-21 06:21:53 +0000",
    "user" : {
      "name" : "Coda Hale (cont.)",
      "screen_name" : "coda",
      "protected" : false,
      "id_str" : "637533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530569133880926208\/HVC_bWBj_normal.jpeg",
      "id" : 637533,
      "verified" : false
    }
  },
  "id" : 392487528063709184,
  "created_at" : "2013-10-22 03:08:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the daniel",
      "screen_name" : "thedaniel",
      "indices" : [ 3, 13 ],
      "id_str" : "2631",
      "id" : 2631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392479520302702592",
  "text" : "RT @thedaniel: \u201CThere is no escape \u2014 we pay for the violence of our ancestors.\u201D - Paul Muad\u2019Dib on technical debt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392450392673382400",
    "text" : "\u201CThere is no escape \u2014 we pay for the violence of our ancestors.\u201D - Paul Muad\u2019Dib on technical debt",
    "id" : 392450392673382400,
    "created_at" : "2013-10-22 00:40:39 +0000",
    "user" : {
      "name" : "the daniel",
      "screen_name" : "thedaniel",
      "protected" : false,
      "id_str" : "2631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2664085908\/12deafe74bced7f1a8fcd6772771bfe4_normal.png",
      "id" : 2631,
      "verified" : false
    }
  },
  "id" : 392479520302702592,
  "created_at" : "2013-10-22 02:36:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gustin",
      "screen_name" : "gustin",
      "indices" : [ 0, 7 ],
      "id_str" : "14381877",
      "id" : 14381877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392474062238527489",
  "geo" : { },
  "id_str" : "392478895980945408",
  "in_reply_to_user_id" : 14381877,
  "text" : "@gustin thanks! Really hoping Mike gets better. So raspy!",
  "id" : 392478895980945408,
  "in_reply_to_status_id" : 392474062238527489,
  "created_at" : "2013-10-22 02:33:55 +0000",
  "in_reply_to_screen_name" : "gustin",
  "in_reply_to_user_id_str" : "14381877",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/DXbQPMq5qx",
      "expanded_url" : "http:\/\/volcano.r13.railsrumble.com\/",
      "display_url" : "volcano.r13.railsrumble.com"
    }, {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/nXLYPw7JUB",
      "expanded_url" : "http:\/\/www.korsgaardscommentary.com\/wp-content\/uploads\/blogger\/-kb1tTKFW_m4\/TpKtIyESIaI\/AAAAAAAAAg4\/ehepFsWNTF8\/s1600\/planet%2Bof%2Bthe%2Bapes.jpg",
      "display_url" : "korsgaardscommentary.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392445217833369600",
  "text" : "Whelp, someone finally did it: http:\/\/t.co\/DXbQPMq5qx http:\/\/t.co\/nXLYPw7JUB",
  "id" : 392445217833369600,
  "created_at" : "2013-10-22 00:20:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emojisaurus",
      "screen_name" : "emojisaurus",
      "indices" : [ 70, 82 ],
      "id_str" : "1972089373",
      "id" : 1972089373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/XCKFA8ZGvW",
      "expanded_url" : "http:\/\/emojisaurus.com\/phrases\/192-coffee-is-for#emojigram_146",
      "display_url" : "emojisaurus.com\/phrases\/192-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392440582460555264",
  "text" : "Cool emojigram for \"Coffee is for closers\" http:\/\/t.co\/XCKFA8ZGvW via @emojisaurus",
  "id" : 392440582460555264,
  "created_at" : "2013-10-22 00:01:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 82, 88 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392403559683080192",
  "text" : "Last night's Piper &gt; Takin' Care of Business is something else. Can't wait for @phish in Rochester tomorrow!",
  "id" : 392403559683080192,
  "created_at" : "2013-10-21 21:34:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392380456181964800",
  "geo" : { },
  "id_str" : "392391968413609984",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss after 10 losses I may had one pack? idk, just isn't my type of game.",
  "id" : 392391968413609984,
  "in_reply_to_status_id" : 392380456181964800,
  "created_at" : "2013-10-21 20:48:30 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Austin",
      "screen_name" : "sjaustin",
      "indices" : [ 0, 9 ],
      "id_str" : "1798581",
      "id" : 1798581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392302106272464896",
  "geo" : { },
  "id_str" : "392305773071851520",
  "in_reply_to_user_id" : 1798581,
  "text" : "@sjaustin maybe post on \/r\/phish or \/r\/Rochester ?",
  "id" : 392305773071851520,
  "in_reply_to_status_id" : 392302106272464896,
  "created_at" : "2013-10-21 15:05:59 +0000",
  "in_reply_to_screen_name" : "sjaustin",
  "in_reply_to_user_id_str" : "1798581",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Austin",
      "screen_name" : "sjaustin",
      "indices" : [ 0, 9 ],
      "id_str" : "1798581",
      "id" : 1798581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392299544240611328",
  "geo" : { },
  "id_str" : "392300381683728385",
  "in_reply_to_user_id" : 1798581,
  "text" : "@sjaustin Just sold my last ticket! Sorry dude. Doesn't seem sold out though.",
  "id" : 392300381683728385,
  "in_reply_to_status_id" : 392299544240611328,
  "created_at" : "2013-10-21 14:44:34 +0000",
  "in_reply_to_screen_name" : "sjaustin",
  "in_reply_to_user_id_str" : "1798581",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392289096766599168",
  "text" : "Broke my glasses and dog is eating leaves already. Monday.",
  "id" : 392289096766599168,
  "created_at" : "2013-10-21 13:59:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "indices" : [ 0, 8 ],
      "id_str" : "304067888",
      "id" : 304067888
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 9, 20 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392141805166551040",
  "geo" : { },
  "id_str" : "392142224823033856",
  "in_reply_to_user_id" : 304067888,
  "text" : "@ag_dubs @ashedryden \"build vertical spaces so devs can view the entire room when a new hire enters\"",
  "id" : 392142224823033856,
  "in_reply_to_status_id" : 392141805166551040,
  "created_at" : "2013-10-21 04:16:06 +0000",
  "in_reply_to_screen_name" : "ag_dubs",
  "in_reply_to_user_id_str" : "304067888",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "indices" : [ 0, 8 ],
      "id_str" : "304067888",
      "id" : 304067888
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 9, 20 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392140950744862720",
  "geo" : { },
  "id_str" : "392141618754494464",
  "in_reply_to_user_id" : 304067888,
  "text" : "@ag_dubs @ashedryden first conference to get him to talk and play guitar wins",
  "id" : 392141618754494464,
  "in_reply_to_status_id" : 392140950744862720,
  "created_at" : "2013-10-21 04:13:42 +0000",
  "in_reply_to_screen_name" : "ag_dubs",
  "in_reply_to_user_id_str" : "304067888",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "indices" : [ 0, 8 ],
      "id_str" : "304067888",
      "id" : 304067888
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 9, 20 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392140703801049088",
  "geo" : { },
  "id_str" : "392140845182222339",
  "in_reply_to_user_id" : 304067888,
  "text" : "@ag_dubs @ashedryden I wonder what his hourly rate is.",
  "id" : 392140845182222339,
  "in_reply_to_status_id" : 392140703801049088,
  "created_at" : "2013-10-21 04:10:37 +0000",
  "in_reply_to_screen_name" : "ag_dubs",
  "in_reply_to_user_id_str" : "304067888",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "indices" : [ 12, 20 ],
      "id_str" : "304067888",
      "id" : 304067888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392139231302131712",
  "geo" : { },
  "id_str" : "392140540461862913",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @ag_dubs I tried Jackson Galaxy's glasses move when meeting a cat this weekend. Couldn't do the blink though. Hilarious dude.",
  "id" : 392140540461862913,
  "in_reply_to_status_id" : 392139231302131712,
  "created_at" : "2013-10-21 04:09:25 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392122658508120064",
  "geo" : { },
  "id_str" : "392122779283103744",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo TUESDAY!!!",
  "id" : 392122779283103744,
  "in_reply_to_status_id" : 392122658508120064,
  "created_at" : "2013-10-21 02:58:50 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 29, 35 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392122573384732673",
  "text" : "BTO and Jimi covers for this @phish show? Loving it.",
  "id" : 392122573384732673,
  "created_at" : "2013-10-21 02:58:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Steinberg",
      "screen_name" : "zzyzx",
      "indices" : [ 0, 6 ],
      "id_str" : "6073352",
      "id" : 6073352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392084079102795776",
  "geo" : { },
  "id_str" : "392084410553470976",
  "in_reply_to_user_id" : 6073352,
  "text" : "@zzyzx ouch. I hope he gets better before Tuesday.",
  "id" : 392084410553470976,
  "in_reply_to_status_id" : 392084079102795776,
  "created_at" : "2013-10-21 00:26:22 +0000",
  "in_reply_to_screen_name" : "zzyzx",
  "in_reply_to_user_id_str" : "6073352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392079337291542528",
  "geo" : { },
  "id_str" : "392080151439474688",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy yeah it's been driving me nuts.",
  "id" : 392080151439474688,
  "in_reply_to_status_id" : 392079337291542528,
  "created_at" : "2013-10-21 00:09:27 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 0, 10 ],
      "id_str" : "5965482",
      "id" : 5965482
    }, {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 11, 18 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392076054116192256",
  "geo" : { },
  "id_str" : "392077324767993856",
  "in_reply_to_user_id" : 5965482,
  "text" : "@jankowski @gabebw what if they sold free range, locally sourced nitrous?",
  "id" : 392077324767993856,
  "in_reply_to_status_id" : 392076054116192256,
  "created_at" : "2013-10-20 23:58:13 +0000",
  "in_reply_to_screen_name" : "jankowski",
  "in_reply_to_user_id_str" : "5965482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/392076215471046656\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/H5WBQkvv9O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXDvPZOIMAAe4Jp.jpg",
      "id_str" : "392076215328452608",
      "id" : 392076215328452608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXDvPZOIMAAe4Jp.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/H5WBQkvv9O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392076215471046656",
  "text" : "For some reason this combo goes well together. http:\/\/t.co\/H5WBQkvv9O",
  "id" : 392076215471046656,
  "created_at" : "2013-10-20 23:53:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 0, 11 ],
      "id_str" : "137891464",
      "id" : 137891464
    }, {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 12, 25 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392059068153479169",
  "geo" : { },
  "id_str" : "392059703053660160",
  "in_reply_to_user_id" : 137891464,
  "text" : "@nickelcity @ChrisSmithAV ...also prepared to turn around at any point.",
  "id" : 392059703053660160,
  "in_reply_to_status_id" : 392059068153479169,
  "created_at" : "2013-10-20 22:48:11 +0000",
  "in_reply_to_screen_name" : "nickelcity",
  "in_reply_to_user_id_str" : "137891464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 0, 11 ],
      "id_str" : "137891464",
      "id" : 137891464
    }, {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 12, 25 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392059068153479169",
  "geo" : { },
  "id_str" : "392059651715391489",
  "in_reply_to_user_id" : 137891464,
  "text" : "@nickelcity @ChrisSmithAV T minus 3 weeks until baby Q is due, so getting these shows in while I can :)",
  "id" : 392059651715391489,
  "in_reply_to_status_id" : 392059068153479169,
  "created_at" : "2013-10-20 22:47:59 +0000",
  "in_reply_to_screen_name" : "nickelcity",
  "in_reply_to_user_id_str" : "137891464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Bissonnette",
      "screen_name" : "stevey",
      "indices" : [ 0, 7 ],
      "id_str" : "818363",
      "id" : 818363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392054633042313216",
  "geo" : { },
  "id_str" : "392055221133656066",
  "in_reply_to_user_id" : 818363,
  "text" : "@stevey ugh! I was there too in the lot. Was able to get to the makeup date though. Bummer.",
  "id" : 392055221133656066,
  "in_reply_to_status_id" : 392054633042313216,
  "created_at" : "2013-10-20 22:30:23 +0000",
  "in_reply_to_screen_name" : "stevey",
  "in_reply_to_user_id_str" : "818363",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 33, 39 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392054169659383808",
  "text" : "I still have one more ticket for @phish in Rochester tomorrow. Who's in?",
  "id" : 392054169659383808,
  "created_at" : "2013-10-20 22:26:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/juhRhB9uQb",
      "expanded_url" : "http:\/\/emojisaurus.com\/phrases\/5",
      "display_url" : "emojisaurus.com\/phrases\/5"
    } ]
  },
  "geo" : { },
  "id_str" : "392049964483751936",
  "text" : "There's more than one emoji translation for \"Bathroom emergency\" http:\/\/t.co\/juhRhB9uQb",
  "id" : 392049964483751936,
  "created_at" : "2013-10-20 22:09:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Kim",
      "screen_name" : "dankim",
      "indices" : [ 0, 7 ],
      "id_str" : "7979212",
      "id" : 7979212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392045428448841728",
  "geo" : { },
  "id_str" : "392049791384825856",
  "in_reply_to_user_id" : 7979212,
  "text" : "@dankim yep.",
  "id" : 392049791384825856,
  "in_reply_to_status_id" : 392045428448841728,
  "created_at" : "2013-10-20 22:08:48 +0000",
  "in_reply_to_screen_name" : "dankim",
  "in_reply_to_user_id_str" : "7979212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emojisaurus",
      "screen_name" : "emojisaurus",
      "indices" : [ 74, 86 ],
      "id_str" : "1972089373",
      "id" : 1972089373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/e3FVaWz5hD",
      "expanded_url" : "http:\/\/emojisaurus.com\/phrases\/21#emojigram_18",
      "display_url" : "emojisaurus.com\/phrases\/21#emo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392047898717720576",
  "text" : "Cool emojigram for \"Fuck it, let's go bowling\" http:\/\/t.co\/e3FVaWz5hD via @emojisaurus",
  "id" : 392047898717720576,
  "created_at" : "2013-10-20 22:01:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392024050090131457",
  "text" : "Does anyone else hate warning labels that are permanently fixed to things? I can't be alone in this.",
  "id" : 392024050090131457,
  "created_at" : "2013-10-20 20:26:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 25, 40 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Bridget",
      "screen_name" : "dragonladyB17",
      "indices" : [ 49, 63 ],
      "id_str" : "158443907",
      "id" : 158443907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/dtTMb5WOPi",
      "expanded_url" : "http:\/\/flic.kr\/s\/aHsjKZicqN",
      "display_url" : "flic.kr\/s\/aHsjKZicqN"
    } ]
  },
  "geo" : { },
  "id_str" : "391399558141722624",
  "text" : "So many great shots from @nickelcityruby. Thanks @dragonladyB17! http:\/\/t.co\/dtTMb5WOPi",
  "id" : 391399558141722624,
  "created_at" : "2013-10-19 03:05:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dirkjan Bussink",
      "screen_name" : "dbussink",
      "indices" : [ 0, 9 ],
      "id_str" : "5838492",
      "id" : 5838492
    }, {
      "name" : "Willem van Bergen",
      "screen_name" : "wvanbergen",
      "indices" : [ 10, 21 ],
      "id_str" : "116877599",
      "id" : 116877599
    }, {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 22, 28 ],
      "id_str" : "12459132",
      "id" : 12459132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/9hCtYdEoy5",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/19150017\/ssl-error-when-installing-rubygems-unable-to-pull-data-from-https-rubygems-o\/19151697#19151697",
      "display_url" : "stackoverflow.com\/questions\/1915\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "391207101235990528",
  "geo" : { },
  "id_str" : "391229106647351296",
  "in_reply_to_user_id" : 5838492,
  "text" : "@dbussink @wvanbergen @alloy does http:\/\/t.co\/9hCtYdEoy5 help?",
  "id" : 391229106647351296,
  "in_reply_to_status_id" : 391207101235990528,
  "created_at" : "2013-10-18 15:47:42 +0000",
  "in_reply_to_screen_name" : "dbussink",
  "in_reply_to_user_id_str" : "5838492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391210162650107904",
  "geo" : { },
  "id_str" : "391228947368652800",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier you're taking Wegmans and Yuengling now? Cmon man.",
  "id" : 391228947368652800,
  "in_reply_to_status_id" : 391210162650107904,
  "created_at" : "2013-10-18 15:47:04 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/3sdEhDPFs0",
      "expanded_url" : "http:\/\/www.technet.pnnl.gov\/sensors\/macro\/projects\/images\/macro69.jpg",
      "display_url" : "technet.pnnl.gov\/sensors\/macro\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391042431254151170",
  "text" : "Current status: http:\/\/t.co\/3sdEhDPFs0",
  "id" : 391042431254151170,
  "created_at" : "2013-10-18 03:25:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390920171822383104",
  "geo" : { },
  "id_str" : "390920382972047360",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc Not at all - I lost 10+ lbs, plateaued for at least a month. Just felt I needed to take a break from it. Not easy to stick with it!",
  "id" : 390920382972047360,
  "in_reply_to_status_id" : 390920171822383104,
  "created_at" : "2013-10-17 19:20:56 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Campbell",
      "screen_name" : "paulca",
      "indices" : [ 0, 7 ],
      "id_str" : "815973",
      "id" : 815973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390915823885623296",
  "geo" : { },
  "id_str" : "390919792032366592",
  "in_reply_to_user_id" : 815973,
  "text" : "@paulca if you haven't tried Keto before...it's amazing. I miss it, months later (after a few months of being on it). Want to go back on it.",
  "id" : 390919792032366592,
  "in_reply_to_status_id" : 390915823885623296,
  "created_at" : "2013-10-17 19:18:36 +0000",
  "in_reply_to_screen_name" : "paulca",
  "in_reply_to_user_id_str" : "815973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Thompson",
      "screen_name" : "keiththomps",
      "indices" : [ 0, 12 ],
      "id_str" : "142860206",
      "id" : 142860206
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 53, 61 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 62, 73 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390895771135918080",
  "geo" : { },
  "id_str" : "390896079337578496",
  "in_reply_to_user_id" : 142860206,
  "text" : "@keiththomps not sure...maybe some AWS issues :( \/cc @evanphx @samkottler",
  "id" : 390896079337578496,
  "in_reply_to_status_id" : 390895771135918080,
  "created_at" : "2013-10-17 17:44:22 +0000",
  "in_reply_to_screen_name" : "keiththomps",
  "in_reply_to_user_id_str" : "142860206",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Redpath",
      "screen_name" : "lukeredpath",
      "indices" : [ 0, 12 ],
      "id_str" : "72573",
      "id" : 72573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390885567669751808",
  "geo" : { },
  "id_str" : "390885944511180800",
  "in_reply_to_user_id" : 72573,
  "text" : "@lukeredpath it's very jumpy and feels rushed. We used one for the latest Basecamp release...not smooth all the time :(",
  "id" : 390885944511180800,
  "in_reply_to_status_id" : 390885567669751808,
  "created_at" : "2013-10-17 17:04:06 +0000",
  "in_reply_to_screen_name" : "lukeredpath",
  "in_reply_to_user_id_str" : "72573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/p4xMueRS2R",
      "expanded_url" : "http:\/\/phish.net\/setlists\/?d=1987-08-21",
      "display_url" : "phish.net\/setlists\/?d=19\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390865135813664768",
  "text" : "Listening to 8\/21\/87 today. Lots of dogs barking. Solid. http:\/\/t.co\/p4xMueRS2R",
  "id" : 390865135813664768,
  "created_at" : "2013-10-17 15:41:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390860371898028033",
  "text" : "I still find it ironic that UnRarX comes in a zip.",
  "id" : 390860371898028033,
  "created_at" : "2013-10-17 15:22:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FallyMac",
      "screen_name" : "FallyMac716",
      "indices" : [ 6, 18 ],
      "id_str" : "1332335143",
      "id" : 1332335143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/RRguAXnDfs",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food\/",
      "display_url" : "coworkbuffalo.com\/food\/"
    } ]
  },
  "geo" : { },
  "id_str" : "390860205375774720",
  "text" : "Added @FallyMac716 to http:\/\/t.co\/RRguAXnDfs, welcome to Buffalo and good luck!",
  "id" : 390860205375774720,
  "created_at" : "2013-10-17 15:21:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FallyMac",
      "screen_name" : "FallyMac716",
      "indices" : [ 3, 15 ],
      "id_str" : "1332335143",
      "id" : 1332335143
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FallyMac716\/status\/390586599265669120\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/tc19O4RVxe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWukcUgCEAAk7d8.jpg",
      "id_str" : "390586599144034304",
      "id" : 390586599144034304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWukcUgCEAAk7d8.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/tc19O4RVxe"
    } ],
    "hashtags" : [ {
      "text" : "fallymac",
      "indices" : [ 59, 68 ]
    }, {
      "text" : "BuffTrucks",
      "indices" : [ 69, 80 ]
    }, {
      "text" : "comingsoon",
      "indices" : [ 81, 92 ]
    }, {
      "text" : "macandcheese",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390856519215902720",
  "text" : "RT @FallyMac716: Say hello to buffalo food truck number 15 #fallymac #BuffTrucks #comingsoon #macandcheese http:\/\/t.co\/tc19O4RVxe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FallyMac716\/status\/390586599265669120\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/tc19O4RVxe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BWukcUgCEAAk7d8.jpg",
        "id_str" : "390586599144034304",
        "id" : 390586599144034304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWukcUgCEAAk7d8.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/tc19O4RVxe"
      } ],
      "hashtags" : [ {
        "text" : "fallymac",
        "indices" : [ 42, 51 ]
      }, {
        "text" : "BuffTrucks",
        "indices" : [ 52, 63 ]
      }, {
        "text" : "comingsoon",
        "indices" : [ 64, 75 ]
      }, {
        "text" : "macandcheese",
        "indices" : [ 76, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "390586599265669120",
    "text" : "Say hello to buffalo food truck number 15 #fallymac #BuffTrucks #comingsoon #macandcheese http:\/\/t.co\/tc19O4RVxe",
    "id" : 390586599265669120,
    "created_at" : "2013-10-16 21:14:36 +0000",
    "user" : {
      "name" : "FallyMac",
      "screen_name" : "FallyMac716",
      "protected" : false,
      "id_str" : "1332335143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000638814944\/4b2ab92dfde608f158354cc8489b94fa_normal.jpeg",
      "id" : 1332335143,
      "verified" : false
    }
  },
  "id" : 390856519215902720,
  "created_at" : "2013-10-17 15:07:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390855983573917696",
  "geo" : { },
  "id_str" : "390856185382846464",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden um, what a jerk :|",
  "id" : 390856185382846464,
  "in_reply_to_status_id" : 390855983573917696,
  "created_at" : "2013-10-17 15:05:51 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    }, {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 129, 136 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390834488965492736",
  "geo" : { },
  "id_str" : "390842822502256640",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier yeah, I just needed a break from it. Not really appealing now. Animation and style of the game were great though. \/cc @mwhuss",
  "id" : 390842822502256640,
  "in_reply_to_status_id" : 390834488965492736,
  "created_at" : "2013-10-17 14:12:45 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "indices" : [ 0, 8 ],
      "id_str" : "304067888",
      "id" : 304067888
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 9, 20 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "zzak\u3048\u30B6\u30C3\u30AF",
      "screen_name" : "_zzak",
      "indices" : [ 21, 27 ],
      "id_str" : "920539489",
      "id" : 920539489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390692795461414912",
  "geo" : { },
  "id_str" : "390693963751260160",
  "in_reply_to_user_id" : 304067888,
  "text" : "@ag_dubs @ashedryden @_zzak I have a feeling there's not enough pups in this equation.",
  "id" : 390693963751260160,
  "in_reply_to_status_id" : 390692795461414912,
  "created_at" : "2013-10-17 04:21:14 +0000",
  "in_reply_to_screen_name" : "ag_dubs",
  "in_reply_to_user_id_str" : "304067888",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/390693524695711744\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/WF2oPNpU0H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWwFsMmIUAEESfH.jpg",
      "id_str" : "390693524527927297",
      "id" : 390693524527927297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWwFsMmIUAEESfH.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/WF2oPNpU0H"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390693524695711744",
  "text" : "Forgot to post this: wet Husky nose with spots! http:\/\/t.co\/WF2oPNpU0H",
  "id" : 390693524695711744,
  "created_at" : "2013-10-17 04:19:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390689827458273280",
  "geo" : { },
  "id_str" : "390689967174725632",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt Vruntstarter.",
  "id" : 390689967174725632,
  "in_reply_to_status_id" : 390689827458273280,
  "created_at" : "2013-10-17 04:05:21 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 74, 88 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390689086920327168",
  "geo" : { },
  "id_str" : "390689386255618050",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt no shit I was thinking of this today, but for fresh brewed coffee  @coworkbuffalo.",
  "id" : 390689386255618050,
  "in_reply_to_status_id" : 390689086920327168,
  "created_at" : "2013-10-17 04:03:03 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390663074153107456",
  "geo" : { },
  "id_str" : "390663343532277762",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub yeah, it would rule on iPad if async. Games don't take long anyway (I'd lose within 5 minutes usually!)",
  "id" : 390663343532277762,
  "in_reply_to_status_id" : 390663074153107456,
  "created_at" : "2013-10-17 02:19:33 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390662510249922560",
  "geo" : { },
  "id_str" : "390663085817466880",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad nah...I seem to be allergic to \"competitive\" gaming like this. Prefer open ended stuff like KSP, Dwarf Fortress, etc",
  "id" : 390663085817466880,
  "in_reply_to_status_id" : 390662510249922560,
  "created_at" : "2013-10-17 02:18:32 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390662459737911296",
  "geo" : { },
  "id_str" : "390662843856465920",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub yes, yes. There's little \"ding\" animations for revealing each card in the pack...distilled down WoW addiction moves :)",
  "id" : 390662843856465920,
  "in_reply_to_status_id" : 390662459737911296,
  "created_at" : "2013-10-17 02:17:34 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390662418298580992",
  "geo" : { },
  "id_str" : "390662641720365056",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier Just deleted it. I'd be more than happy to talk! :)",
  "id" : 390662641720365056,
  "in_reply_to_status_id" : 390662418298580992,
  "created_at" : "2013-10-17 02:16:46 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390662086021615616",
  "geo" : { },
  "id_str" : "390662317500674048",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub Without a doubt. You can pay for more packs of cards, which give you more &amp; better options.",
  "id" : 390662317500674048,
  "in_reply_to_status_id" : 390662086021615616,
  "created_at" : "2013-10-17 02:15:29 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390661885827100673",
  "text" : "So in order to play the \"fair\" arena mode you can pay Blizzard $1.99 (or in game-cash). I think I'm done with Hearthstone for a while.",
  "id" : 390661885827100673,
  "created_at" : "2013-10-17 02:13:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390661679849021440",
  "text" : "Correction: 3 normal, 1 arena. Arena feels more \"fair\" since it's not prebuilt, but is not the normal mode of play. :(",
  "id" : 390661679849021440,
  "created_at" : "2013-10-17 02:12:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390661431424585728",
  "text" : "Pretty sure I have won maybe 2 games out of 10 thus far in the normal \"play\" mode. 1 in the Arena.",
  "id" : 390661431424585728,
  "created_at" : "2013-10-17 02:11:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390660940267417600",
  "text" : "0-4 on Hearthstone tonight. Unranked matches, too. Pretty sure I don't get this game.",
  "id" : 390660940267417600,
  "created_at" : "2013-10-17 02:10:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Austin",
      "screen_name" : "sjaustin",
      "indices" : [ 0, 9 ],
      "id_str" : "1798581",
      "id" : 1798581
    }, {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 20, 26 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390576985204092928",
  "geo" : { },
  "id_str" : "390577189533413376",
  "in_reply_to_user_id" : 1798581,
  "text" : "@sjaustin There's a @phish joke in here somewhere.",
  "id" : 390577189533413376,
  "in_reply_to_status_id" : 390576985204092928,
  "created_at" : "2013-10-16 20:37:13 +0000",
  "in_reply_to_screen_name" : "sjaustin",
  "in_reply_to_user_id_str" : "1798581",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 66, 77 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390557135941414912",
  "geo" : { },
  "id_str" : "390557645792235520",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps something something writing drunk, editing sober \/cc @kevinpurdy",
  "id" : 390557645792235520,
  "in_reply_to_status_id" : 390557135941414912,
  "created_at" : "2013-10-16 19:19:33 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    }, {
      "name" : "Andy Mangold",
      "screen_name" : "andymangold",
      "indices" : [ 11, 23 ],
      "id_str" : "14144438",
      "id" : 14144438
    }, {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 90, 93 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390556578262175744",
  "geo" : { },
  "id_str" : "390557084346892289",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier @andymangold I am not sure actually! I don't remember mentioning minecraft \/cc @j3",
  "id" : 390557084346892289,
  "in_reply_to_status_id" : 390556578262175744,
  "created_at" : "2013-10-16 19:17:19 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390554151878262784",
  "text" : "Also I'm sorry for the creeper look at the beginning of that video. At least I didn't break the 4th wall.",
  "id" : 390554151878262784,
  "created_at" : "2013-10-16 19:05:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 12, 27 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 56, 68 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/mjT7IOXacG",
      "expanded_url" : "http:\/\/confreaks.com\/videos\/2694-nickelcityruby2013-learning-together",
      "display_url" : "confreaks.com\/videos\/2694-ni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390552870606487553",
  "text" : "Pumped that @nickelcityruby videos are going up. Here's @SaraJChipps' keynote: http:\/\/t.co\/mjT7IOXacG",
  "id" : 390552870606487553,
  "created_at" : "2013-10-16 19:00:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 3, 6 ],
      "id_str" : "1133971",
      "id" : 1133971
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 38, 53 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/w3UaYVRBMu",
      "expanded_url" : "http:\/\/confreaks.com\/videos\/2686-nickelcityruby2013-why-developers-quit-building-teams-careers",
      "display_url" : "confreaks.com\/videos\/2686-ni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390539187029438465",
  "text" : "RT @j3: Very proud of my keynote from @nickelcityruby, \"Just Be Fucking Awesome\", and would love your feedback and critique: http:\/\/t.co\/w3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 30, 45 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/w3UaYVRBMu",
        "expanded_url" : "http:\/\/confreaks.com\/videos\/2686-nickelcityruby2013-why-developers-quit-building-teams-careers",
        "display_url" : "confreaks.com\/videos\/2686-ni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "390537947507728384",
    "text" : "Very proud of my keynote from @nickelcityruby, \"Just Be Fucking Awesome\", and would love your feedback and critique: http:\/\/t.co\/w3UaYVRBMu",
    "id" : 390537947507728384,
    "created_at" : "2013-10-16 18:01:17 +0000",
    "user" : {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "protected" : false,
      "id_str" : "1133971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000543599975\/c63a58ff323b22a9e9ad52ffbbfb7f0a_normal.jpeg",
      "id" : 1133971,
      "verified" : false
    }
  },
  "id" : 390539187029438465,
  "created_at" : "2013-10-16 18:06:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 0, 11 ],
      "id_str" : "137891464",
      "id" : 137891464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390497733103988736",
  "geo" : { },
  "id_str" : "390500590901407745",
  "in_reply_to_user_id" : 137891464,
  "text" : "@nickelcity this is a big reason of why I deleted my instagram account and now only publish on Flickr under proper CC licensing.",
  "id" : 390500590901407745,
  "in_reply_to_status_id" : 390497733103988736,
  "created_at" : "2013-10-16 15:32:50 +0000",
  "in_reply_to_screen_name" : "nickelcity",
  "in_reply_to_user_id_str" : "137891464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    }, {
      "name" : "Elijah Miller",
      "screen_name" : "jqr",
      "indices" : [ 7, 11 ],
      "id_str" : "14351457",
      "id" : 14351457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390494287651033088",
  "geo" : { },
  "id_str" : "390497407214960641",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine @jqr thanks!! Also, highly recommend renting before buying anything.",
  "id" : 390497407214960641,
  "in_reply_to_status_id" : 390494287651033088,
  "created_at" : "2013-10-16 15:20:11 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390493558530387969",
  "geo" : { },
  "id_str" : "390493751191171073",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow That'll do :)",
  "id" : 390493751191171073,
  "in_reply_to_status_id" : 390493558530387969,
  "created_at" : "2013-10-16 15:05:39 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390491177385873408",
  "geo" : { },
  "id_str" : "390493151183392768",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow i would pay for this. Why can't I pay you for this!?",
  "id" : 390493151183392768,
  "in_reply_to_status_id" : 390491177385873408,
  "created_at" : "2013-10-16 15:03:16 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 35, 47 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/TMM5QtPwjq",
      "expanded_url" : "http:\/\/news.wbfo.org\/post\/local-food-truck-business-finds-success-burmese-hires",
      "display_url" : "news.wbfo.org\/post\/local-foo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390484967110606848",
  "text" : "I didn't think it was possible for @whereslloyd to be any more awesome, and this happens: http:\/\/t.co\/TMM5QtPwjq",
  "id" : 390484967110606848,
  "created_at" : "2013-10-16 14:30:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Barlow",
      "screen_name" : "alexrbarlow",
      "indices" : [ 0, 12 ],
      "id_str" : "214885889",
      "id" : 214885889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390483536266137601",
  "geo" : { },
  "id_str" : "390483782609813504",
  "in_reply_to_user_id" : 214885889,
  "text" : "@alexrbarlow yeah, need to fool around with it more. Still learning the manual settings.",
  "id" : 390483782609813504,
  "in_reply_to_status_id" : 390483536266137601,
  "created_at" : "2013-10-16 14:26:03 +0000",
  "in_reply_to_screen_name" : "alexrbarlow",
  "in_reply_to_user_id_str" : "214885889",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/zjlKaXcMA0",
      "expanded_url" : "http:\/\/flic.kr\/p\/gH8X1V",
      "display_url" : "flic.kr\/p\/gH8X1V"
    } ]
  },
  "geo" : { },
  "id_str" : "390482708901937152",
  "text" : "Continually impressed with the X100S. Took some fooling around but got it to work under bonfire light last night: http:\/\/t.co\/zjlKaXcMA0",
  "id" : 390482708901937152,
  "created_at" : "2013-10-16 14:21:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bridget",
      "screen_name" : "dragonladyB17",
      "indices" : [ 0, 14 ],
      "id_str" : "158443907",
      "id" : 158443907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390318175356612608",
  "geo" : { },
  "id_str" : "390318647819771904",
  "in_reply_to_user_id" : 158443907,
  "text" : "@dragonladyB17 i may have misspoke. Long ass day. Playing with community Lightroom presets helps.",
  "id" : 390318647819771904,
  "in_reply_to_status_id" : 390318175356612608,
  "created_at" : "2013-10-16 03:29:52 +0000",
  "in_reply_to_screen_name" : "dragonladyB17",
  "in_reply_to_user_id_str" : "158443907",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEDxBuffalo",
      "screen_name" : "TEDxBuffalo",
      "indices" : [ 18, 30 ],
      "id_str" : "140515765",
      "id" : 140515765
    }, {
      "name" : "Canisius College",
      "screen_name" : "CanisiusCollege",
      "indices" : [ 62, 78 ],
      "id_str" : "20600913",
      "id" : 20600913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/8ShUlpYDxO",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush\/10299345303\/in\/photostream\/",
      "display_url" : "flickr.com\/photos\/qrush\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390236857646067712",
  "text" : "Big thanks to the @TEDxBuffalo organizers for months of work. @CanisiusCollege's Montante Center was a neat venue: http:\/\/t.co\/8ShUlpYDxO",
  "id" : 390236857646067712,
  "created_at" : "2013-10-15 22:04:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEDxBuffalo",
      "screen_name" : "TEDxBuffalo",
      "indices" : [ 31, 43 ],
      "id_str" : "140515765",
      "id" : 140515765
    }, {
      "name" : "Danimal\/Armcannon",
      "screen_name" : "armcannon",
      "indices" : [ 51, 61 ],
      "id_str" : "86775045",
      "id" : 86775045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/8X0sZI1CfM",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush\/10299206166\/in\/set-72157636599227213\/",
      "display_url" : "flickr.com\/photos\/qrush\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390236020156821504",
  "text" : "Easily my favorite moment from @TEDxBuffalo today, @armcannon shredding it! http:\/\/t.co\/8X0sZI1CfM",
  "id" : 390236020156821504,
  "created_at" : "2013-10-15 22:01:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390233157955354624",
  "geo" : { },
  "id_str" : "390233715101560833",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 something something free time something",
  "id" : 390233715101560833,
  "in_reply_to_status_id" : 390233157955354624,
  "created_at" : "2013-10-15 21:52:22 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 0, 16 ],
      "id_str" : "16997374",
      "id" : 16997374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390231435363512320",
  "geo" : { },
  "id_str" : "390232464884379648",
  "in_reply_to_user_id" : 16997374,
  "text" : "@konstantinhaase yeah I don't get RAW yet. Still just trying to understand ISO triangle and actually being able to configure settings.",
  "id" : 390232464884379648,
  "in_reply_to_status_id" : 390231435363512320,
  "created_at" : "2013-10-15 21:47:24 +0000",
  "in_reply_to_screen_name" : "konstantinhaase",
  "in_reply_to_user_id_str" : "16997374",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390230807832317953",
  "text" : "Overexposure is the enemy.",
  "id" : 390230807832317953,
  "created_at" : "2013-10-15 21:40:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 5, 14 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 31, 45 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/6FXZlR9hTz",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/11790-openhack-october",
      "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390230292318810112",
  "text" : "Hey, @openhack is happening at @coworkbuffalo tonight. You should go! http:\/\/t.co\/6FXZlR9hTz",
  "id" : 390230292318810112,
  "created_at" : "2013-10-15 21:38:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 34, 43 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390169375057010688",
  "geo" : { },
  "id_str" : "390183090024611840",
  "in_reply_to_user_id" : 65247837,
  "text" : "@DanAlfano fine unless if you get @bquarant started on bananas",
  "id" : 390183090024611840,
  "in_reply_to_status_id" : 390169375057010688,
  "created_at" : "2013-10-15 18:31:12 +0000",
  "in_reply_to_screen_name" : "Hoonidan",
  "in_reply_to_user_id_str" : "65247837",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "Threadless",
      "screen_name" : "threadless",
      "indices" : [ 12, 23 ],
      "id_str" : "5380672",
      "id" : 5380672
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 41, 51 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 61, 70 ],
      "id_str" : "1051521",
      "id" : 1051521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390125340749996032",
  "geo" : { },
  "id_str" : "390125747903684608",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante @threadless you are close to @37signals HQ! (And @migreyes used to work there)",
  "id" : 390125747903684608,
  "in_reply_to_status_id" : 390125340749996032,
  "created_at" : "2013-10-15 14:43:21 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390122368611262464",
  "geo" : { },
  "id_str" : "390122488019316736",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant eat enough bacon and anything can happen",
  "id" : 390122488019316736,
  "in_reply_to_status_id" : 390122368611262464,
  "created_at" : "2013-10-15 14:30:23 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 0, 6 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390096738172022784",
  "geo" : { },
  "id_str" : "390100110312747008",
  "in_reply_to_user_id" : 205281746,
  "text" : "@ahuj9 are you from buffalo? Worlds colliding.",
  "id" : 390100110312747008,
  "in_reply_to_status_id" : 390096738172022784,
  "created_at" : "2013-10-15 13:01:28 +0000",
  "in_reply_to_screen_name" : "ahuj9",
  "in_reply_to_user_id_str" : "205281746",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 3, 11 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/JQQ5iqKo9Q",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    }, {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/crIlGGV5qp",
      "expanded_url" : "http:\/\/blog.rubygems.org\/2013\/10\/14\/gittip.html",
      "display_url" : "blog.rubygems.org\/2013\/10\/14\/git\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389974997894045696",
  "text" : "RT @drbrain: http:\/\/t.co\/JQQ5iqKo9Q now supports Gittip links on your profile page: http:\/\/t.co\/crIlGGV5qp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/JQQ5iqKo9Q",
        "expanded_url" : "http:\/\/RubyGems.org",
        "display_url" : "RubyGems.org"
      }, {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/crIlGGV5qp",
        "expanded_url" : "http:\/\/blog.rubygems.org\/2013\/10\/14\/gittip.html",
        "display_url" : "blog.rubygems.org\/2013\/10\/14\/git\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "389970963892146176",
    "text" : "http:\/\/t.co\/JQQ5iqKo9Q now supports Gittip links on your profile page: http:\/\/t.co\/crIlGGV5qp",
    "id" : 389970963892146176,
    "created_at" : "2013-10-15 04:28:17 +0000",
    "user" : {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "protected" : false,
      "id_str" : "670283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472446327373053952\/oJXOO4GL_normal.jpeg",
      "id" : 670283,
      "verified" : false
    }
  },
  "id" : 389974997894045696,
  "created_at" : "2013-10-15 04:44:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "keeran",
      "screen_name" : "keeran",
      "indices" : [ 0, 7 ],
      "id_str" : "10075872",
      "id" : 10075872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389974181409861633",
  "geo" : { },
  "id_str" : "389974463522934784",
  "in_reply_to_user_id" : 10075872,
  "text" : "@keeran This is what happens when you ignore outbreaks. And the yellow region.",
  "id" : 389974463522934784,
  "in_reply_to_status_id" : 389974181409861633,
  "created_at" : "2013-10-15 04:42:12 +0000",
  "in_reply_to_screen_name" : "keeran",
  "in_reply_to_user_id_str" : "10075872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beth Giobbe",
      "screen_name" : "bgiobbe",
      "indices" : [ 0, 8 ],
      "id_str" : "79629358",
      "id" : 79629358
    }, {
      "name" : "Luke Chadwick",
      "screen_name" : "vertis",
      "indices" : [ 26, 33 ],
      "id_str" : "18786379",
      "id" : 18786379
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 34, 46 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389957139189346304",
  "geo" : { },
  "id_str" : "389962093325058048",
  "in_reply_to_user_id" : 79629358,
  "text" : "@bgiobbe That's not good. @vertis @dwradcliffe still up?",
  "id" : 389962093325058048,
  "in_reply_to_status_id" : 389957139189346304,
  "created_at" : "2013-10-15 03:53:02 +0000",
  "in_reply_to_screen_name" : "bgiobbe",
  "in_reply_to_user_id_str" : "79629358",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Chadwick",
      "screen_name" : "vertis",
      "indices" : [ 50, 57 ],
      "id_str" : "18786379",
      "id" : 18786379
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 62, 74 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "389949415240134656",
  "text" : "And http:\/\/t.co\/2bA9BVLhWr is back up. Big ups to @vertis and @dwradcliffe for staying calm and collected.",
  "id" : 389949415240134656,
  "created_at" : "2013-10-15 03:02:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michael lewis",
      "screen_name" : "mlewis",
      "indices" : [ 0, 7 ],
      "id_str" : "10100322",
      "id" : 10100322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/xfwWRG6vdv",
      "expanded_url" : "http:\/\/rubycentral.org",
      "display_url" : "rubycentral.org"
    } ]
  },
  "in_reply_to_status_id_str" : "389946013844111360",
  "geo" : { },
  "id_str" : "389946469962088448",
  "in_reply_to_user_id" : 10100322,
  "text" : "@mlewis Ruby Central does. http:\/\/t.co\/xfwWRG6vdv",
  "id" : 389946469962088448,
  "in_reply_to_status_id" : 389946013844111360,
  "created_at" : "2013-10-15 02:50:57 +0000",
  "in_reply_to_screen_name" : "mlewis",
  "in_reply_to_user_id_str" : "10100322",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 0, 6 ],
      "id_str" : "24425454",
      "id" : 24425454
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389943706431680512",
  "geo" : { },
  "id_str" : "389944003287732224",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgmnz yeah, jump in #rubygems",
  "id" : 389944003287732224,
  "in_reply_to_status_id" : 389943706431680512,
  "created_at" : "2013-10-15 02:41:09 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "389938009820258305",
  "text" : "We've got http:\/\/t.co\/2bA9BVLhWr in maintenance mode. Enjoy some Hocus Pocus while we figure this out.",
  "id" : 389938009820258305,
  "created_at" : "2013-10-15 02:17:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "markcatley",
      "indices" : [ 0, 11 ],
      "id_str" : "14794653",
      "id" : 14794653
    }, {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 12, 28 ],
      "id_str" : "529540581",
      "id" : 529540581
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 29, 38 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389932283265703936",
  "geo" : { },
  "id_str" : "389933346664374272",
  "in_reply_to_user_id" : 14794653,
  "text" : "@markcatley @rubygems_status @rubygems having some DB issues. stay tuned.",
  "id" : 389933346664374272,
  "in_reply_to_status_id" : 389932283265703936,
  "created_at" : "2013-10-15 01:58:49 +0000",
  "in_reply_to_screen_name" : "markcatley",
  "in_reply_to_user_id_str" : "14794653",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "389933078270836737",
  "text" : "We're dealing with some http:\/\/t.co\/2bA9BVLhWr DB issues tonight, sorry everyone. All the gems are safe, pg is unhappy.",
  "id" : 389933078270836737,
  "created_at" : "2013-10-15 01:57:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Ahearn",
      "screen_name" : "rcahearn",
      "indices" : [ 0, 9 ],
      "id_str" : "18756131",
      "id" : 18756131
    }, {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 10, 26 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389928392386420736",
  "geo" : { },
  "id_str" : "389929675985653760",
  "in_reply_to_user_id" : 18756131,
  "text" : "@rcahearn @rubygems_status yes, sorry. I don't have the status PW right now. CF errors not related.",
  "id" : 389929675985653760,
  "in_reply_to_status_id" : 389928392386420736,
  "created_at" : "2013-10-15 01:44:13 +0000",
  "in_reply_to_screen_name" : "rcahearn",
  "in_reply_to_user_id_str" : "18756131",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/lbLbURrECG",
      "expanded_url" : "http:\/\/webcache.googleusercontent.com\/search?q=cache:9B0gPcY0l48J:rubygems.org\/gems\/rape-me+&cd=1&hl=en&ct=clnk&gl=us",
      "display_url" : "webcache.googleusercontent.com\/search?q=cache\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "389925107621453824",
  "geo" : { },
  "id_str" : "389926194902081536",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella http:\/\/t.co\/lbLbURrECG",
  "id" : 389926194902081536,
  "in_reply_to_status_id" : 389925107621453824,
  "created_at" : "2013-10-15 01:30:24 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uos\u029E\u0254\u0250\u027E u\u0250\u0265\u0287\u0250uo\u027E",
      "screen_name" : "rondale_sc",
      "indices" : [ 0, 11 ],
      "id_str" : "156327472",
      "id" : 156327472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/C2z83kxPvy",
      "expanded_url" : "https:\/\/github.com\/qrush\/archive",
      "display_url" : "github.com\/qrush\/archive"
    } ]
  },
  "in_reply_to_status_id_str" : "389923104111079424",
  "geo" : { },
  "id_str" : "389924322963247104",
  "in_reply_to_user_id" : 156327472,
  "text" : "@rondale_sc Yep! just copied it in and pushed. https:\/\/t.co\/C2z83kxPvy",
  "id" : 389924322963247104,
  "in_reply_to_status_id" : 389923104111079424,
  "created_at" : "2013-10-15 01:22:57 +0000",
  "in_reply_to_screen_name" : "rondale_sc",
  "in_reply_to_user_id_str" : "156327472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uos\u029E\u0254\u0250\u027E u\u0250\u0265\u0287\u0250uo\u027E",
      "screen_name" : "rondale_sc",
      "indices" : [ 0, 11 ],
      "id_str" : "156327472",
      "id" : 156327472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389922588157153281",
  "geo" : { },
  "id_str" : "389922715303288832",
  "in_reply_to_user_id" : 156327472,
  "text" : "@rondale_sc I just request another zip. I feel automation of it would waste more time than you'd ever earn back :)",
  "id" : 389922715303288832,
  "in_reply_to_status_id" : 389922588157153281,
  "created_at" : "2013-10-15 01:16:34 +0000",
  "in_reply_to_screen_name" : "rondale_sc",
  "in_reply_to_user_id_str" : "156327472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Green",
      "screen_name" : "hotgazpacho",
      "indices" : [ 0, 12 ],
      "id_str" : "10687942",
      "id" : 10687942
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 13, 18 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Andy Lindeman",
      "screen_name" : "alindeman",
      "indices" : [ 19, 29 ],
      "id_str" : "13235612",
      "id" : 13235612
    }, {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 69, 77 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/x9ZdxN5A6M",
      "expanded_url" : "http:\/\/rubyforge.org\/pipermail\/rubygems-developers\/2013-September\/007025.html",
      "display_url" : "rubyforge.org\/pipermail\/ruby\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "389921218784018432",
  "geo" : { },
  "id_str" : "389922574907355137",
  "in_reply_to_user_id" : 10687942,
  "text" : "@hotgazpacho @avdi @alindeman I have barely seen any movement on it. @bascule's post here is promising though: http:\/\/t.co\/x9ZdxN5A6M",
  "id" : 389922574907355137,
  "in_reply_to_status_id" : 389921218784018432,
  "created_at" : "2013-10-15 01:16:00 +0000",
  "in_reply_to_screen_name" : "hotgazpacho",
  "in_reply_to_user_id_str" : "10687942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/5bCmLMGE26",
      "expanded_url" : "http:\/\/quaran.to\/archive\/",
      "display_url" : "quaran.to\/archive\/"
    } ]
  },
  "geo" : { },
  "id_str" : "389921594623025152",
  "text" : "Yet another night my twitter archive proves useful. You should download yours, too: http:\/\/t.co\/5bCmLMGE26",
  "id" : 389921594623025152,
  "created_at" : "2013-10-15 01:12:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Andy Lindeman",
      "screen_name" : "alindeman",
      "indices" : [ 6, 16 ],
      "id_str" : "13235612",
      "id" : 13235612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/A0sRXaQeCo",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/statuses\/297742514771877889",
      "display_url" : "twitter.com\/qrush\/statuses\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "389918282209181697",
  "geo" : { },
  "id_str" : "389920732819361792",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi @alindeman I don't think it is, but I have felt like this since February: https:\/\/t.co\/A0sRXaQeCo",
  "id" : 389920732819361792,
  "in_reply_to_status_id" : 389918282209181697,
  "created_at" : "2013-10-15 01:08:41 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Letterle",
      "screen_name" : "mletterle",
      "indices" : [ 0, 10 ],
      "id_str" : "458173",
      "id" : 458173
    }, {
      "name" : "Clarence Klopfstein",
      "screen_name" : "ckincincy",
      "indices" : [ 11, 21 ],
      "id_str" : "13965682",
      "id" : 13965682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389914824144326656",
  "geo" : { },
  "id_str" : "389915025227280384",
  "in_reply_to_user_id" : 458173,
  "text" : "@mletterle @ckincincy no, didn't even bother to look.",
  "id" : 389915025227280384,
  "in_reply_to_status_id" : 389914824144326656,
  "created_at" : "2013-10-15 00:46:00 +0000",
  "in_reply_to_screen_name" : "mletterle",
  "in_reply_to_user_id_str" : "458173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clarence Klopfstein",
      "screen_name" : "ckincincy",
      "indices" : [ 0, 10 ],
      "id_str" : "13965682",
      "id" : 13965682
    }, {
      "name" : "Michael Letterle",
      "screen_name" : "mletterle",
      "indices" : [ 11, 21 ],
      "id_str" : "458173",
      "id" : 458173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/7GSbYB3KCa",
      "expanded_url" : "http:\/\/blog.rubygems.org\/2013\/01\/31\/data-verification.html",
      "display_url" : "blog.rubygems.org\/2013\/01\/31\/dat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "389913707200790528",
  "geo" : { },
  "id_str" : "389914540311203840",
  "in_reply_to_user_id" : 13965682,
  "text" : "@ckincincy @mletterle exploit was a while back. http:\/\/t.co\/7GSbYB3KCa other gem I just deleted.",
  "id" : 389914540311203840,
  "in_reply_to_status_id" : 389913707200790528,
  "created_at" : "2013-10-15 00:44:05 +0000",
  "in_reply_to_screen_name" : "ckincincy",
  "in_reply_to_user_id_str" : "13965682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389909308869058560",
  "text" : "One thing the \"exploit\" and \"rape-me\" gems have taught me: Ruby is very much beyond the \"[...] so we're nice\" phase.",
  "id" : 389909308869058560,
  "created_at" : "2013-10-15 00:23:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Ingram",
      "screen_name" : "pjammer",
      "indices" : [ 0, 8 ],
      "id_str" : "15266123",
      "id" : 15266123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/lTjLQdATgr",
      "expanded_url" : "http:\/\/github.com\/rubygems.org\/meg",
      "display_url" : "github.com\/rubygems.org\/m\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "389907225764167680",
  "geo" : { },
  "id_str" : "389908253368262657",
  "in_reply_to_user_id" : 15266123,
  "text" : "@pjammer http:\/\/t.co\/lTjLQdATgr",
  "id" : 389908253368262657,
  "in_reply_to_status_id" : 389907225764167680,
  "created_at" : "2013-10-15 00:19:06 +0000",
  "in_reply_to_screen_name" : "pjammer",
  "in_reply_to_user_id_str" : "15266123",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gh33da",
      "screen_name" : "gh33da",
      "indices" : [ 0, 7 ],
      "id_str" : "16468950",
      "id" : 16468950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389905680658071552",
  "geo" : { },
  "id_str" : "389905977090117632",
  "in_reply_to_user_id" : 16468950,
  "text" : "@gh33da ?",
  "id" : 389905977090117632,
  "in_reply_to_status_id" : 389905680658071552,
  "created_at" : "2013-10-15 00:10:03 +0000",
  "in_reply_to_screen_name" : "gh33da",
  "in_reply_to_user_id_str" : "16468950",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389904599844286464",
  "text" : "I'm disgusted that I even have to do this. We can do better than this as a community.",
  "id" : 389904599844286464,
  "created_at" : "2013-10-15 00:04:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389904509536710657",
  "text" : "Something I never thought I'd have to do when I started gemcutter in 2009: `meg script permadelete rape-me`",
  "id" : 389904509536710657,
  "created_at" : "2013-10-15 00:04:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 5, 13 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 14, 25 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "Luke Chadwick",
      "screen_name" : "vertis",
      "indices" : [ 26, 33 ],
      "id_str" : "18786379",
      "id" : 18786379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389896428505407488",
  "text" : "ping @evanphx @samkottler @vertis, can you jump into rubygems IRC?",
  "id" : 389896428505407488,
  "created_at" : "2013-10-14 23:32:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389680304098521088",
  "geo" : { },
  "id_str" : "389896007908986880",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH Didn't see this at the top of the thread. I don't have shell access ATM but this will get deleted.",
  "id" : 389896007908986880,
  "in_reply_to_status_id" : 389680304098521088,
  "created_at" : "2013-10-14 23:30:26 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Lobato",
      "screen_name" : "eLobatoss",
      "indices" : [ 0, 10 ],
      "id_str" : "97482220",
      "id" : 97482220
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 11, 19 ],
      "id_str" : "670283",
      "id" : 670283
    }, {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 20, 26 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/HsNhGlTez1",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "389695771877965824",
  "geo" : { },
  "id_str" : "389895338359656448",
  "in_reply_to_user_id" : 97482220,
  "text" : "@eLobatoss @drbrain @ReinH I think a \"report abuse\" link that opens a new case on http:\/\/t.co\/HsNhGlTez1 should be a good start.",
  "id" : 389895338359656448,
  "in_reply_to_status_id" : 389695771877965824,
  "created_at" : "2013-10-14 23:27:47 +0000",
  "in_reply_to_screen_name" : "eLobatoss",
  "in_reply_to_user_id_str" : "97482220",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Fiedler",
      "screen_name" : "kylefiedler",
      "indices" : [ 0, 12 ],
      "id_str" : "14838050",
      "id" : 14838050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389808336541331457",
  "geo" : { },
  "id_str" : "389809844456144896",
  "in_reply_to_user_id" : 14838050,
  "text" : "@kylefiedler congrats!!!",
  "id" : 389809844456144896,
  "in_reply_to_status_id" : 389808336541331457,
  "created_at" : "2013-10-14 17:48:03 +0000",
  "in_reply_to_screen_name" : "kylefiedler",
  "in_reply_to_user_id_str" : "14838050",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 23, 32 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 66, 80 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "NextPlex \/ Buffalo",
      "screen_name" : "nplexBUF",
      "indices" : [ 103, 112 ],
      "id_str" : "1154760426",
      "id" : 1154760426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389794848351334400",
  "text" : "RT @zobar2: Hey nerds! @openhack starts up again tomorrow, 7pm at @coworkbuffalo. Deets forthcoming on @nplexBUF.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 11, 20 ],
        "id_str" : "715440464",
        "id" : 715440464
      }, {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 54, 68 ],
        "id_str" : "491801330",
        "id" : 491801330
      }, {
        "name" : "NextPlex \/ Buffalo",
        "screen_name" : "nplexBUF",
        "indices" : [ 91, 100 ],
        "id_str" : "1154760426",
        "id" : 1154760426
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389794496767991808",
    "text" : "Hey nerds! @openhack starts up again tomorrow, 7pm at @coworkbuffalo. Deets forthcoming on @nplexBUF.",
    "id" : 389794496767991808,
    "created_at" : "2013-10-14 16:47:04 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 389794848351334400,
  "created_at" : "2013-10-14 16:48:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    }, {
      "name" : "The Sweethome",
      "screen_name" : "homesweethome",
      "indices" : [ 15, 29 ],
      "id_str" : "1099960304",
      "id" : 1099960304
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 30, 41 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389751576774320128",
  "geo" : { },
  "id_str" : "389779204004274176",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit @homesweethome @kevinpurdy GOLD IS BEST. BEST BEST BEST",
  "id" : 389779204004274176,
  "in_reply_to_status_id" : 389751576774320128,
  "created_at" : "2013-10-14 15:46:18 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389762417171120128",
  "geo" : { },
  "id_str" : "389764415727226881",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella noooo",
  "id" : 389764415727226881,
  "in_reply_to_status_id" : 389762417171120128,
  "created_at" : "2013-10-14 14:47:32 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEDxBuffalo",
      "screen_name" : "TEDxBuffalo",
      "indices" : [ 3, 15 ],
      "id_str" : "140515765",
      "id" : 140515765
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/389761524291489792\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Xo24yL8pME",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWi2CoQCQAMbHe9.jpg",
      "id_str" : "389761524048216067",
      "id" : 389761524048216067,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWi2CoQCQAMbHe9.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/Xo24yL8pME"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389761524291489792",
  "text" : "My @TEDxBuffalo badge is highly accurate. http:\/\/t.co\/Xo24yL8pME",
  "id" : 389761524291489792,
  "created_at" : "2013-10-14 14:36:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sadvil",
      "screen_name" : "crylenol",
      "indices" : [ 3, 12 ],
      "id_str" : "65433646",
      "id" : 65433646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389579185422733313",
  "text" : "RT @crylenol: Commercial for Twitter dot com:\n\n*man yells nonsense out his window*\n\nNarrator: Don't you wish there were a better way?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344561543150727168",
    "text" : "Commercial for Twitter dot com:\n\n*man yells nonsense out his window*\n\nNarrator: Don't you wish there were a better way?",
    "id" : 344561543150727168,
    "created_at" : "2013-06-11 21:07:28 +0000",
    "user" : {
      "name" : "sadvil",
      "screen_name" : "crylenol",
      "protected" : false,
      "id_str" : "65433646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548664026050199552\/zHvu3Wlg_normal.png",
      "id" : 65433646,
      "verified" : false
    }
  },
  "id" : 389579185422733313,
  "created_at" : "2013-10-14 02:31:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389563552765198337",
  "text" : "Hearthstone is really meant for a touch UI. I could see it dominating the App Store...forever.",
  "id" : 389563552765198337,
  "created_at" : "2013-10-14 01:29:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389512272093380608",
  "text" : "Gravity was alright. Maybe my expectations were off...I was hoping something of 2001 proportions.",
  "id" : 389512272093380608,
  "created_at" : "2013-10-13 22:05:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389448770913456128",
  "text" : "@AlMehltretter ...wat (also, you're working at\/running a kennel?)",
  "id" : 389448770913456128,
  "created_at" : "2013-10-13 17:53:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renata Avila",
      "screen_name" : "avilarenata",
      "indices" : [ 3, 15 ],
      "id_str" : "25014406",
      "id" : 25014406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/xhnQVRQCnV",
      "expanded_url" : "http:\/\/www.internetgovernance.org\/2013\/10\/11\/the-core-internet-institutions-abandon-the-us-government\/",
      "display_url" : "internetgovernance.org\/2013\/10\/11\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389391836005294080",
  "text" : "RT @avilarenata: The core Internet institutions abandon the US Government http:\/\/t.co\/xhnQVRQCnV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/xhnQVRQCnV",
        "expanded_url" : "http:\/\/www.internetgovernance.org\/2013\/10\/11\/the-core-internet-institutions-abandon-the-us-government\/",
        "display_url" : "internetgovernance.org\/2013\/10\/11\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "388998262113312768",
    "text" : "The core Internet institutions abandon the US Government http:\/\/t.co\/xhnQVRQCnV",
    "id" : 388998262113312768,
    "created_at" : "2013-10-12 12:03:07 +0000",
    "user" : {
      "name" : "Renata Avila",
      "screen_name" : "avilarenata",
      "protected" : false,
      "id_str" : "25014406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572061912708296704\/_XWDgMZa_normal.jpeg",
      "id" : 25014406,
      "verified" : false
    }
  },
  "id" : 389391836005294080,
  "created_at" : "2013-10-13 14:07:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/389361576387416065\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/YDF5wgbjM0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWdKSmlCUAAor8A.png",
      "id_str" : "389361576244826112",
      "id" : 389361576244826112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWdKSmlCUAAor8A.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YDF5wgbjM0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389361576387416065",
  "text" : "Siri apparently can detect sarcasm when asking about sportsball. http:\/\/t.co\/YDF5wgbjM0",
  "id" : 389361576387416065,
  "created_at" : "2013-10-13 12:06:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenneth Reitz",
      "screen_name" : "kennethreitz",
      "indices" : [ 0, 13 ],
      "id_str" : "50478950",
      "id" : 50478950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389267619288973312",
  "geo" : { },
  "id_str" : "389267857747349504",
  "in_reply_to_user_id" : 50478950,
  "text" : "@kennethreitz oh man the originals are there? Agh.",
  "id" : 389267857747349504,
  "in_reply_to_status_id" : 389267619288973312,
  "created_at" : "2013-10-13 05:54:24 +0000",
  "in_reply_to_screen_name" : "kennethreitz",
  "in_reply_to_user_id_str" : "50478950",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 10, 16 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389247819191951360",
  "geo" : { },
  "id_str" : "389251564218511360",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn @jamis just following YouTube tutorials is easy. Once you figure out things on your own...it's hard to stop.",
  "id" : 389251564218511360,
  "in_reply_to_status_id" : 389247819191951360,
  "created_at" : "2013-10-13 04:49:39 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389247268714336257",
  "geo" : { },
  "id_str" : "389251203252486145",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis awesome! A little hot there :)",
  "id" : 389251203252486145,
  "in_reply_to_status_id" : 389247268714336257,
  "created_at" : "2013-10-13 04:48:13 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389233638841143296",
  "text" : "Sabres: We're number 8! We're number 8!",
  "id" : 389233638841143296,
  "created_at" : "2013-10-13 03:38:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "indices" : [ 0, 13 ],
      "id_str" : "38450774",
      "id" : 38450774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389072707717177345",
  "geo" : { },
  "id_str" : "389077281651834880",
  "in_reply_to_user_id" : 38450774,
  "text" : "@robertromito nope!",
  "id" : 389077281651834880,
  "in_reply_to_status_id" : 389072707717177345,
  "created_at" : "2013-10-12 17:17:07 +0000",
  "in_reply_to_screen_name" : "robertromito",
  "in_reply_to_user_id_str" : "38450774",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388853482046119936",
  "geo" : { },
  "id_str" : "388853900377202688",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh Emoji.",
  "id" : 388853900377202688,
  "in_reply_to_status_id" : 388853482046119936,
  "created_at" : "2013-10-12 02:29:29 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388835331635564544",
  "geo" : { },
  "id_str" : "388835590424121344",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo TOP SCORE",
  "id" : 388835590424121344,
  "in_reply_to_status_id" : 388835331635564544,
  "created_at" : "2013-10-12 01:16:43 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/EUyH3WAqzA",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=21OH0wlkfbc",
      "display_url" : "youtube.com\/watch?v=21OH0w\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "388769733610201088",
  "geo" : { },
  "id_str" : "388771721748045824",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh http:\/\/t.co\/EUyH3WAqzA",
  "id" : 388771721748045824,
  "in_reply_to_status_id" : 388769733610201088,
  "created_at" : "2013-10-11 21:02:56 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 0, 6 ],
      "id_str" : "24425454",
      "id" : 24425454
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/388743071203987456\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/xCgESIHoBM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWUXw3yCEAA_Oy8.png",
      "id_str" : "388743071212376064",
      "id" : 388743071212376064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWUXw3yCEAA_Oy8.png",
      "sizes" : [ {
        "h" : 364,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 756,
        "resize" : "fit",
        "w" : 1246
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 621,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xCgESIHoBM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388742665447014400",
  "geo" : { },
  "id_str" : "388743071203987456",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgmnz If I actually knew how to play, maybe :) Pretty wild that you can just feed it music. http:\/\/t.co\/xCgESIHoBM",
  "id" : 388743071203987456,
  "in_reply_to_status_id" : 388742665447014400,
  "created_at" : "2013-10-11 19:09:05 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/aG0pxG7hzI",
      "expanded_url" : "http:\/\/supermegaultragroovy.com\/products\/Capo\/",
      "display_url" : "supermegaultragroovy.com\/products\/Capo\/"
    } ]
  },
  "geo" : { },
  "id_str" : "388742264500916224",
  "text" : "Had a fun little detour with Capo: http:\/\/t.co\/aG0pxG7hzI Stunning UI design, and it makes tabs out of just files.",
  "id" : 388742264500916224,
  "created_at" : "2013-10-11 19:05:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 0, 12 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388526664298561536",
  "geo" : { },
  "id_str" : "388527043295453184",
  "in_reply_to_user_id" : 14231571,
  "text" : "@marcoarment now you just need to be a therapist.",
  "id" : 388527043295453184,
  "in_reply_to_status_id" : 388526664298561536,
  "created_at" : "2013-10-11 04:50:40 +0000",
  "in_reply_to_screen_name" : "marcoarment",
  "in_reply_to_user_id_str" : "14231571",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Austin",
      "screen_name" : "sjaustin",
      "indices" : [ 0, 9 ],
      "id_str" : "1798581",
      "id" : 1798581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388497412014505984",
  "geo" : { },
  "id_str" : "388499161928065024",
  "in_reply_to_user_id" : 1798581,
  "text" : "@sjaustin bummer. OK!",
  "id" : 388499161928065024,
  "in_reply_to_status_id" : 388497412014505984,
  "created_at" : "2013-10-11 02:59:52 +0000",
  "in_reply_to_screen_name" : "sjaustin",
  "in_reply_to_user_id_str" : "1798581",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Austin",
      "screen_name" : "sjaustin",
      "indices" : [ 0, 9 ],
      "id_str" : "1798581",
      "id" : 1798581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388484458074349569",
  "geo" : { },
  "id_str" : "388487319852175360",
  "in_reply_to_user_id" : 1798581,
  "text" : "@sjaustin nope! Will sell at face value. DM me.",
  "id" : 388487319852175360,
  "in_reply_to_status_id" : 388484458074349569,
  "created_at" : "2013-10-11 02:12:49 +0000",
  "in_reply_to_screen_name" : "sjaustin",
  "in_reply_to_user_id_str" : "1798581",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388479854493982720",
  "text" : "It's a Glenlivet 18 kind of night.",
  "id" : 388479854493982720,
  "created_at" : "2013-10-11 01:43:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388465744310071296",
  "text" : "I'm qrush#1208 on Hearthstone if you want a friend.",
  "id" : 388465744310071296,
  "created_at" : "2013-10-11 00:47:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388442966978600961",
  "text" : "I hear by dub thee \"Pizza Moon\", go forth and crush yonder hunger.",
  "id" : 388442966978600961,
  "created_at" : "2013-10-10 23:16:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/388442780978008064\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/IwROnYCIos",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWQGpqDCUAA4jwU.jpg",
      "id_str" : "388442780592132096",
      "id" : 388442780592132096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWQGpqDCUAA4jwU.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/IwROnYCIos"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388442780978008064",
  "text" : "First attempt at pizza off a stone in maybe a year came out at least smelling like a pizza. Circular not so much. http:\/\/t.co\/IwROnYCIos",
  "id" : 388442780978008064,
  "created_at" : "2013-10-10 23:15:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 20, 30 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388423159222775808",
  "text" : "Most pregnant thing @aquaranto has done: made ice cream sandwiches out of halloween sugar cookies. (They're delicious)",
  "id" : 388423159222775808,
  "created_at" : "2013-10-10 21:57:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388395998239657984",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald a\u035D\u035D \u0489\u0336b\u0358\u0327\u035Fu\u0361n\u0328\u0322c\u0360\u035Dh\u0322\u0340 \u0340\u0489\u0335o\u0321\u0358\u035Df\u0327 \u0360H\u0315T\u035C\u0321M\u0327\u0358\u0362L\u0322 \u0335r\u0335\u0361e\u035C\u0361g\u031B\u0361\u0362e\u0361x\u035Dp\u0336\u035C \u0321\u0321p\u0336\u0340a\u035D\u0338r\u0337\u0341\u0341s\u0362er\u0327\u035Es\u0362",
  "id" : 388395998239657984,
  "created_at" : "2013-10-10 20:09:56 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388391189042298880",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald a \uD834\uDD77\uD834\uDD77\uD834\uDD77\uD834\uDD77\uD834\uDD77\uD834\uDD77\uD834\uDD77\uD834\uDD77\uD834\uDD77\uD834\uDD77\uD834\uDD77\uD834\uDD77 of encoding errors",
  "id" : 388391189042298880,
  "created_at" : "2013-10-10 19:50:50 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 33, 39 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388390003279003649",
  "text" : "I still have one ticket left for @phish in Rochester on 10\/22. Anyone in Buffalo\/Rochester\/Toronto interested?",
  "id" : 388390003279003649,
  "created_at" : "2013-10-10 19:46:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DevFest Vienna",
      "screen_name" : "DevFestVienna",
      "indices" : [ 0, 14 ],
      "id_str" : "842344670",
      "id" : 842344670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388372771707035648",
  "geo" : { },
  "id_str" : "388374019126198272",
  "in_reply_to_user_id" : 842344670,
  "text" : "@DevFestVienna Will do. I'd appreciate a change of the name of the event on G+ if you're going to offer prizes and call it a \"hackathon\"",
  "id" : 388374019126198272,
  "in_reply_to_status_id" : 388372771707035648,
  "created_at" : "2013-10-10 18:42:36 +0000",
  "in_reply_to_screen_name" : "DevFestVienna",
  "in_reply_to_user_id_str" : "842344670",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DevFest Vienna",
      "screen_name" : "DevFestVienna",
      "indices" : [ 0, 14 ],
      "id_str" : "842344670",
      "id" : 842344670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388370208760791040",
  "geo" : { },
  "id_str" : "388371635184480256",
  "in_reply_to_user_id" : 842344670,
  "text" : "@DevFestVienna I've been meaning to write about this difference for a while, perhaps I will tonight. Please change it, and thanks.",
  "id" : 388371635184480256,
  "in_reply_to_status_id" : 388370208760791040,
  "created_at" : "2013-10-10 18:33:08 +0000",
  "in_reply_to_screen_name" : "DevFestVienna",
  "in_reply_to_user_id_str" : "842344670",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DevFest Vienna",
      "screen_name" : "DevFestVienna",
      "indices" : [ 0, 14 ],
      "id_str" : "842344670",
      "id" : 842344670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388299898086371328",
  "geo" : { },
  "id_str" : "388369299204624384",
  "in_reply_to_user_id" : 842344670,
  "text" : "@DevFestVienna Please don't call OpenHack a \"hackathon\" or offer prizes. The very point of OpenHack was to go against this kind of thing.",
  "id" : 388369299204624384,
  "in_reply_to_status_id" : 388299898086371328,
  "created_at" : "2013-10-10 18:23:51 +0000",
  "in_reply_to_screen_name" : "DevFestVienna",
  "in_reply_to_user_id_str" : "842344670",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388330620830494720",
  "geo" : { },
  "id_str" : "388339058872557569",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt Is This When It All Turns Around For Vrunt ? Watch Tonight at 8 to Find Out!",
  "id" : 388339058872557569,
  "in_reply_to_status_id" : 388330620830494720,
  "created_at" : "2013-10-10 16:23:41 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    }, {
      "name" : "Julia Burke",
      "screen_name" : "juliabwrites",
      "indices" : [ 100, 113 ],
      "id_str" : "72991857",
      "id" : 72991857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388315367044431873",
  "geo" : { },
  "id_str" : "388316543471206400",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit nowhere is perfect, but after Rochester and Boston I wouldn't move back. Excited for @juliabwrites but a rebuttal is due :)",
  "id" : 388316543471206400,
  "in_reply_to_status_id" : 388315367044431873,
  "created_at" : "2013-10-10 14:54:13 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pascal Rettig",
      "screen_name" : "cykod",
      "indices" : [ 0, 6 ],
      "id_str" : "18439491",
      "id" : 18439491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388313333641654272",
  "geo" : { },
  "id_str" : "388313556619243520",
  "in_reply_to_user_id" : 18439491,
  "text" : "@cykod :(",
  "id" : 388313556619243520,
  "in_reply_to_status_id" : 388313333641654272,
  "created_at" : "2013-10-10 14:42:21 +0000",
  "in_reply_to_screen_name" : "cykod",
  "in_reply_to_user_id_str" : "18439491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388120083450437632",
  "text" : "Enjoying Hearthstone more than Scrolls, the initial tutorial was a lot more engaging. It's strange how IAP feels on desktop games though.",
  "id" : 388120083450437632,
  "created_at" : "2013-10-10 01:53:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388109982542991360",
  "text" : "Trying out Hearthstone. My battletag is qrush. Have no idea what I'm doing yet.",
  "id" : 388109982542991360,
  "created_at" : "2013-10-10 01:13:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388083301426008064",
  "text" : "\"Welcome to the Hearthstone\u2122: Heroes of Warcraft\u2122 beta test for the Americas!\" Whelp, it was nice knowing everyone.",
  "id" : 388083301426008064,
  "created_at" : "2013-10-09 23:27:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Ben Balter",
      "screen_name" : "BenBalter",
      "indices" : [ 7, 17 ],
      "id_str" : "16211142",
      "id" : 16211142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388072826290180096",
  "geo" : { },
  "id_str" : "388072947434283008",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr @BenBalter s\/Jekyll\/everything\/g",
  "id" : 388072947434283008,
  "in_reply_to_status_id" : 388072826290180096,
  "created_at" : "2013-10-09 22:46:15 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388049550654840833",
  "geo" : { },
  "id_str" : "388049853143478273",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan wat?",
  "id" : 388049853143478273,
  "in_reply_to_status_id" : 388049550654840833,
  "created_at" : "2013-10-09 21:14:29 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 3, 9 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388046376543608832",
  "text" : "RT @vrunt: speed dating sucks. it takes way more than 7 minutes just to explain what an arduino is",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388045428320509952",
    "text" : "speed dating sucks. it takes way more than 7 minutes just to explain what an arduino is",
    "id" : 388045428320509952,
    "created_at" : "2013-10-09 20:56:54 +0000",
    "user" : {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "protected" : false,
      "id_str" : "15062828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566801374143586305\/yApDWRcm_normal.jpeg",
      "id" : 15062828,
      "verified" : false
    }
  },
  "id" : 388046376543608832,
  "created_at" : "2013-10-09 21:00:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Sternal-Johnson",
      "screen_name" : "ceejayoz",
      "indices" : [ 0, 9 ],
      "id_str" : "717973",
      "id" : 717973
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 39, 50 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/DV7GpNlnjm",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B00D21JCTO",
      "display_url" : "amazon.com\/dp\/B00D21JCTO"
    } ]
  },
  "in_reply_to_status_id_str" : "388040172224659456",
  "geo" : { },
  "id_str" : "388041364950118401",
  "in_reply_to_user_id" : 717973,
  "text" : "@ceejayoz clearly you're not following @kevinpurdy's amazon wish list http:\/\/t.co\/DV7GpNlnjm",
  "id" : 388041364950118401,
  "in_reply_to_status_id" : 388040172224659456,
  "created_at" : "2013-10-09 20:40:45 +0000",
  "in_reply_to_screen_name" : "ceejayoz",
  "in_reply_to_user_id_str" : "717973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evgeny Rahman",
      "screen_name" : "evgenyrahman",
      "indices" : [ 3, 16 ],
      "id_str" : "20728528",
      "id" : 20728528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388040773356101632",
  "text" : "RT @evgenyrahman: All we are is Cheeto dust in the wind.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385354770741207040",
    "text" : "All we are is Cheeto dust in the wind.",
    "id" : 385354770741207040,
    "created_at" : "2013-10-02 10:45:11 +0000",
    "user" : {
      "name" : "Evgeny Rahman",
      "screen_name" : "evgenyrahman",
      "protected" : false,
      "id_str" : "20728528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/125846240\/evgenywar_normal.PNG",
      "id" : 20728528,
      "verified" : false
    }
  },
  "id" : 388040773356101632,
  "created_at" : "2013-10-09 20:38:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388040056872509440",
  "text" : "Why Is There Anything?",
  "id" : 388040056872509440,
  "created_at" : "2013-10-09 20:35:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/evKPVw9lQn",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=rCwn1NTK-50",
      "display_url" : "youtube.com\/watch?v=rCwn1N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388012581744427008",
  "text" : "No kid's toy commerical will ever be better than CROSSFIRE: http:\/\/t.co\/evKPVw9lQn",
  "id" : 388012581744427008,
  "created_at" : "2013-10-09 18:46:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 12, 18 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387953653711003648",
  "text" : "RT @zobar2: @qrush Do not anger the Apple product images. The Apple product images startle easily. Play soothing music for the Apple produc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "387951852379054080",
    "geo" : { },
    "id_str" : "387953572693803008",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush Do not anger the Apple product images. The Apple product images startle easily. Play soothing music for the Apple product images.",
    "id" : 387953572693803008,
    "in_reply_to_status_id" : 387951852379054080,
    "created_at" : "2013-10-09 14:51:54 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 387953653711003648,
  "created_at" : "2013-10-09 14:52:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "w.d. radcliffe",
      "screen_name" : "squigiliwams",
      "indices" : [ 0, 13 ],
      "id_str" : "8938252",
      "id" : 8938252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387952235260686336",
  "geo" : { },
  "id_str" : "387952863126622208",
  "in_reply_to_user_id" : 8938252,
  "text" : "@squigiliwams \"Do not use Apple product images along with images of competitive products in your communications.\" almost everyone does this.",
  "id" : 387952863126622208,
  "in_reply_to_status_id" : 387952235260686336,
  "created_at" : "2013-10-09 14:49:05 +0000",
  "in_reply_to_screen_name" : "squigiliwams",
  "in_reply_to_user_id_str" : "8938252",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/9ZZRNj2l4g",
      "expanded_url" : "https:\/\/developer.apple.com\/app-store\/marketing\/guidelines",
      "display_url" : "developer.apple.com\/app-store\/mark\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387951852379054080",
  "text" : "Wat: \"Do not use Apple product images along with images of competitive products\" https:\/\/t.co\/9ZZRNj2l4g",
  "id" : 387951852379054080,
  "created_at" : "2013-10-09 14:45:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 0, 12 ],
      "id_str" : "158098704",
      "id" : 158098704
    }, {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 80, 85 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387748145717063680",
  "geo" : { },
  "id_str" : "387764149914468352",
  "in_reply_to_user_id" : 158098704,
  "text" : "@mikemikemac dude! Just saw this sorry. At last we saw a fight in the 300s with @popo",
  "id" : 387764149914468352,
  "in_reply_to_status_id" : 387748145717063680,
  "created_at" : "2013-10-09 02:19:12 +0000",
  "in_reply_to_screen_name" : "mikemikemac",
  "in_reply_to_user_id_str" : "158098704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387729950104891392",
  "text" : "Things would be a lot easier if some of Congress just donned hockey gear and proceeded to beat the snot out of each other. I missed hockey.",
  "id" : 387729950104891392,
  "created_at" : "2013-10-09 00:03:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387644837287047168",
  "text" : "RT @rubygems_status: We're currently testing fastly as our CDN. If you see any issues, please report them!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387643971779846146",
    "text" : "We're currently testing fastly as our CDN. If you see any issues, please report them!",
    "id" : 387643971779846146,
    "created_at" : "2013-10-08 18:21:39 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 387644837287047168,
  "created_at" : "2013-10-08 18:25:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Moore",
      "screen_name" : "sartak",
      "indices" : [ 0, 7 ],
      "id_str" : "6753782",
      "id" : 6753782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387634538006192128",
  "geo" : { },
  "id_str" : "387635352116002817",
  "in_reply_to_user_id" : 6753782,
  "text" : "@sartak You could say the same about Dwarf Fortress...or Kerbal Space Program...or....or.....",
  "id" : 387635352116002817,
  "in_reply_to_status_id" : 387634538006192128,
  "created_at" : "2013-10-08 17:47:24 +0000",
  "in_reply_to_screen_name" : "sartak",
  "in_reply_to_user_id_str" : "6753782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Moore",
      "screen_name" : "sartak",
      "indices" : [ 0, 7 ],
      "id_str" : "6753782",
      "id" : 6753782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387633521508225024",
  "geo" : { },
  "id_str" : "387634389456138240",
  "in_reply_to_user_id" : 6753782,
  "text" : "@sartak Don't kick the shop door. Don't touch the corpse without gloves. Don't zap that wand at the bridge. Don't kick that altar. Don't...",
  "id" : 387634389456138240,
  "in_reply_to_status_id" : 387633521508225024,
  "created_at" : "2013-10-08 17:43:35 +0000",
  "in_reply_to_screen_name" : "sartak",
  "in_reply_to_user_id_str" : "6753782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Moore",
      "screen_name" : "sartak",
      "indices" : [ 3, 10 ],
      "id_str" : "6753782",
      "id" : 6753782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387634074350673920",
  "text" : "RT @sartak: \"The first rule of NetHack is: don't\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387633521508225024",
    "text" : "\"The first rule of NetHack is: don't\"",
    "id" : 387633521508225024,
    "created_at" : "2013-10-08 17:40:08 +0000",
    "user" : {
      "name" : "Shawn Moore",
      "screen_name" : "sartak",
      "protected" : false,
      "id_str" : "6753782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528996643622776832\/MweVr4Vb_normal.jpeg",
      "id" : 6753782,
      "verified" : false
    }
  },
  "id" : 387634074350673920,
  "created_at" : "2013-10-08 17:42:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387610056101203969",
  "geo" : { },
  "id_str" : "387610472913977344",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik downloads. Could just be mirrors.",
  "id" : 387610472913977344,
  "in_reply_to_status_id" : 387610056101203969,
  "created_at" : "2013-10-08 16:08:32 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 22, 30 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 31, 39 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387609575916335104",
  "geo" : { },
  "id_str" : "387609698486079488",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik \u0CA0_\u0CA0 \/cc @evanphx @drbrain",
  "id" : 387609698486079488,
  "in_reply_to_status_id" : 387609575916335104,
  "created_at" : "2013-10-08 16:05:28 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/Pd8QKUNWVa",
      "expanded_url" : "http:\/\/www.blogcdn.com\/www.engadget.com\/media\/2012\/03\/jony-ive-10-20-09.jpg",
      "display_url" : "blogcdn.com\/www.engadget.c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "387605980860915712",
  "geo" : { },
  "id_str" : "387606325783322625",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow this must convey \"depth\" http:\/\/t.co\/Pd8QKUNWVa",
  "id" : 387606325783322625,
  "in_reply_to_status_id" : 387605980860915712,
  "created_at" : "2013-10-08 15:52:04 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Skyb\u00F8se",
      "screen_name" : "flogrammer",
      "indices" : [ 3, 14 ],
      "id_str" : "1692197828",
      "id" : 1692197828
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GIT",
      "indices" : [ 62, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387592803829559298",
  "text" : "RT @flogrammer: PREPARING TO OPEN SOURCE MY NEW code snippet, #GIT READY!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GIT",
        "indices" : [ 46, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370690225137139712",
    "text" : "PREPARING TO OPEN SOURCE MY NEW code snippet, #GIT READY!!!",
    "id" : 370690225137139712,
    "created_at" : "2013-08-22 23:33:31 +0000",
    "user" : {
      "name" : "Jim Skyb\u00F8se",
      "screen_name" : "flogrammer",
      "protected" : false,
      "id_str" : "1692197828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000341489620\/d8bc0e1c14d15f53d4ca30089380849e_normal.jpeg",
      "id" : 1692197828,
      "verified" : false
    }
  },
  "id" : 387592803829559298,
  "created_at" : "2013-10-08 14:58:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387570642221953025",
  "text" : "It's Hockey Night tonight! \uD83C\uDFB5",
  "id" : 387570642221953025,
  "created_at" : "2013-10-08 13:30:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Vermaas",
      "screen_name" : "stefanvermaas",
      "indices" : [ 0, 14 ],
      "id_str" : "128829110",
      "id" : 128829110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387499066570989568",
  "geo" : { },
  "id_str" : "387556115934093312",
  "in_reply_to_user_id" : 128829110,
  "text" : "@StefanVermaas just use AFNetworking like normal. No client side validation, none needed since the app mostly creates data via UIWebView's.",
  "id" : 387556115934093312,
  "in_reply_to_status_id" : 387499066570989568,
  "created_at" : "2013-10-08 12:32:33 +0000",
  "in_reply_to_screen_name" : "stefanvermaas",
  "in_reply_to_user_id_str" : "128829110",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    }, {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 53, 65 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387442550421729280",
  "geo" : { },
  "id_str" : "387446467012870144",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH this entire story is so good, the videos too. @starguarded should make more or publish it :)",
  "id" : 387446467012870144,
  "in_reply_to_status_id" : 387442550421729280,
  "created_at" : "2013-10-08 05:16:50 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Petrie",
      "screen_name" : "geopet",
      "indices" : [ 0, 7 ],
      "id_str" : "14604055",
      "id" : 14604055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387411678167457792",
  "geo" : { },
  "id_str" : "387412759748804608",
  "in_reply_to_user_id" : 14604055,
  "text" : "@geopet email works best",
  "id" : 387412759748804608,
  "in_reply_to_status_id" : 387411678167457792,
  "created_at" : "2013-10-08 03:02:54 +0000",
  "in_reply_to_screen_name" : "geopet",
  "in_reply_to_user_id_str" : "14604055",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387334759551995905",
  "geo" : { },
  "id_str" : "387334966788370432",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt Hakuna Maburrito",
  "id" : 387334966788370432,
  "in_reply_to_status_id" : 387334759551995905,
  "created_at" : "2013-10-07 21:53:47 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Marshall",
      "screen_name" : "danthat",
      "indices" : [ 3, 11 ],
      "id_str" : "19772827",
      "id" : 19772827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/qYpC6Bbuys",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=fI_xuFA18m4",
      "display_url" : "youtube.com\/watch?v=fI_xuF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387305708061868033",
  "text" : "RT @danthat: Oh look, it's the precise moment everything at Microsoft went awry: http:\/\/t.co\/qYpC6Bbuys (via everyone)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/qYpC6Bbuys",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=fI_xuFA18m4",
        "display_url" : "youtube.com\/watch?v=fI_xuF\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "387300791590993920",
    "text" : "Oh look, it's the precise moment everything at Microsoft went awry: http:\/\/t.co\/qYpC6Bbuys (via everyone)",
    "id" : 387300791590993920,
    "created_at" : "2013-10-07 19:37:59 +0000",
    "user" : {
      "name" : "Dan Marshall",
      "screen_name" : "danthat",
      "protected" : false,
      "id_str" : "19772827",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552047168106688514\/F3-4XT9N_normal.png",
      "id" : 19772827,
      "verified" : false
    }
  },
  "id" : 387305708061868033,
  "created_at" : "2013-10-07 19:57:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/GZlSFyeoKq",
      "expanded_url" : "http:\/\/terriblerealestateagentphotos.com\/",
      "display_url" : "terriblerealestateagentphotos.com"
    } ]
  },
  "geo" : { },
  "id_str" : "387299480908738560",
  "text" : "Prepare for cringing: http:\/\/t.co\/GZlSFyeoKq",
  "id" : 387299480908738560,
  "created_at" : "2013-10-07 19:32:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Societal Obstacle",
      "screen_name" : "laurenvoswinkel",
      "indices" : [ 0, 16 ],
      "id_str" : "19539935",
      "id" : 19539935
    }, {
      "name" : "Andrea Berzinsky",
      "screen_name" : "ABerzinsky",
      "indices" : [ 17, 28 ],
      "id_str" : "623359092",
      "id" : 623359092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387292426890530816",
  "geo" : { },
  "id_str" : "387292744093143040",
  "in_reply_to_user_id" : 19539935,
  "text" : "@laurenvoswinkel @ABerzinsky Literally the boonies? :P Congrats!",
  "id" : 387292744093143040,
  "in_reply_to_status_id" : 387292426890530816,
  "created_at" : "2013-10-07 19:06:00 +0000",
  "in_reply_to_screen_name" : "laurenvoswinkel",
  "in_reply_to_user_id_str" : "19539935",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387270507386511360",
  "geo" : { },
  "id_str" : "387270725716811779",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo I have one that's unclaimed. DM?",
  "id" : 387270725716811779,
  "in_reply_to_status_id" : 387270507386511360,
  "created_at" : "2013-10-07 17:38:30 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Barnett",
      "screen_name" : "andrewbbarnett",
      "indices" : [ 3, 18 ],
      "id_str" : "183064311",
      "id" : 183064311
    }, {
      "name" : "Museum of Modern Art",
      "screen_name" : "MuseumModernArt",
      "indices" : [ 47, 63 ],
      "id_str" : "15057943",
      "id" : 15057943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/lZ80nZVOpy",
      "expanded_url" : "http:\/\/www.collectorsweekly.com\/articles\/wp-content\/uploads\/2013\/10\/moma-and-ad.jpg",
      "display_url" : "collectorsweekly.com\/articles\/wp-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387241436699430912",
  "text" : "RT @andrewbbarnett: Chemex ad. The bulletin of @MuseumModernArt, December 1942 - January 1943 :http:\/\/t.co\/lZ80nZVOpy \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Museum of Modern Art",
        "screen_name" : "MuseumModernArt",
        "indices" : [ 27, 43 ],
        "id_str" : "15057943",
        "id" : 15057943
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/lZ80nZVOpy",
        "expanded_url" : "http:\/\/www.collectorsweekly.com\/articles\/wp-content\/uploads\/2013\/10\/moma-and-ad.jpg",
        "display_url" : "collectorsweekly.com\/articles\/wp-co\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "387172062554382337",
    "text" : "Chemex ad. The bulletin of @MuseumModernArt, December 1942 - January 1943 :http:\/\/t.co\/lZ80nZVOpy \u2026",
    "id" : 387172062554382337,
    "created_at" : "2013-10-07 11:06:27 +0000",
    "user" : {
      "name" : "Andrew Barnett",
      "screen_name" : "andrewbbarnett",
      "protected" : false,
      "id_str" : "183064311",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539471521777864705\/r2DJD0jM_normal.jpeg",
      "id" : 183064311,
      "verified" : false
    }
  },
  "id" : 387241436699430912,
  "created_at" : "2013-10-07 15:42:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 12, 18 ],
      "id_str" : "14503997",
      "id" : 14503997
    }, {
      "name" : "SoundCloud",
      "screen_name" : "SoundCloud",
      "indices" : [ 28, 39 ],
      "id_str" : "5943942",
      "id" : 5943942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/elvcfUjX8U",
      "expanded_url" : "https:\/\/soundcloud.com\/officialphish\/phish-niagara-falls-slave-to",
      "display_url" : "soundcloud.com\/officialphish\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387223526433751041",
  "text" : "I love that @phish is using @soundcloud: https:\/\/t.co\/elvcfUjX8U",
  "id" : 387223526433751041,
  "created_at" : "2013-10-07 14:30:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Millions",
      "screen_name" : "evil_trout",
      "indices" : [ 0, 11 ],
      "id_str" : "2494449480",
      "id" : 2494449480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387218064082620416",
  "in_reply_to_user_id" : 16712921,
  "text" : "@evil_trout you're not following me!",
  "id" : 387218064082620416,
  "created_at" : "2013-10-07 14:09:15 +0000",
  "in_reply_to_screen_name" : "eviltrout",
  "in_reply_to_user_id_str" : "16712921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 0, 9 ],
      "id_str" : "16225196",
      "id" : 16225196
    }, {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 10, 21 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387080282890719232",
  "geo" : { },
  "id_str" : "387082169513811968",
  "in_reply_to_user_id" : 16225196,
  "text" : "@shildner @joanofdark the only solution: create a new tumblr, fuckyeahbeardgifs.",
  "id" : 387082169513811968,
  "in_reply_to_status_id" : 387080282890719232,
  "created_at" : "2013-10-07 05:09:15 +0000",
  "in_reply_to_screen_name" : "shildner",
  "in_reply_to_user_id_str" : "16225196",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Coleman",
      "screen_name" : "ericcoleman",
      "indices" : [ 0, 12 ],
      "id_str" : "14715782",
      "id" : 14715782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387080261927989248",
  "geo" : { },
  "id_str" : "387080787838783488",
  "in_reply_to_user_id" : 14715782,
  "text" : "@ericcoleman congrats!",
  "id" : 387080787838783488,
  "in_reply_to_status_id" : 387080261927989248,
  "created_at" : "2013-10-07 05:03:46 +0000",
  "in_reply_to_screen_name" : "ericcoleman",
  "in_reply_to_user_id_str" : "14715782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387078181905113089",
  "geo" : { },
  "id_str" : "387080297809838080",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark really windy here and he is getting spooked. Usually is just heavy panting, loud enough to wake us up.",
  "id" : 387080297809838080,
  "in_reply_to_status_id" : 387078181905113089,
  "created_at" : "2013-10-07 05:01:49 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Coleman",
      "screen_name" : "ericcoleman",
      "indices" : [ 0, 12 ],
      "id_str" : "14715782",
      "id" : 14715782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387078658730758144",
  "geo" : { },
  "id_str" : "387080086546944000",
  "in_reply_to_user_id" : 14715782,
  "text" : "@ericcoleman T minus 4 weeks until that!",
  "id" : 387080086546944000,
  "in_reply_to_status_id" : 387078658730758144,
  "created_at" : "2013-10-07 05:00:58 +0000",
  "in_reply_to_screen_name" : "ericcoleman",
  "in_reply_to_user_id_str" : "14715782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387077693948186624",
  "text" : "It's a dog pant night, apparently. Never a good thing.",
  "id" : 387077693948186624,
  "created_at" : "2013-10-07 04:51:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386698487590445056",
  "text" : "Pocket Trains is essentially Cookie Clicker...on trains. My brain is permanently damaged by these games.",
  "id" : 386698487590445056,
  "created_at" : "2013-10-06 03:44:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386644633692147712",
  "geo" : { },
  "id_str" : "386672481865445376",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss it was an all day one.",
  "id" : 386672481865445376,
  "in_reply_to_status_id" : 386644633692147712,
  "created_at" : "2013-10-06 02:01:18 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David A. Meyer",
      "screen_name" : "dameyer",
      "indices" : [ 0, 8 ],
      "id_str" : "16847467",
      "id" : 16847467
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 9, 20 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386604685999607808",
  "geo" : { },
  "id_str" : "386615980488523776",
  "in_reply_to_user_id" : 16847467,
  "text" : "@dameyer @kevinpurdy yes. It's free!",
  "id" : 386615980488523776,
  "in_reply_to_status_id" : 386604685999607808,
  "created_at" : "2013-10-05 22:16:47 +0000",
  "in_reply_to_screen_name" : "dameyer",
  "in_reply_to_user_id_str" : "16847467",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386549936126697472",
  "geo" : { },
  "id_str" : "386607656896430080",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy this happened after one particularly loud bout, but continued anyway",
  "id" : 386607656896430080,
  "in_reply_to_status_id" : 386549936126697472,
  "created_at" : "2013-10-05 21:43:42 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386581359420248065",
  "text" : "Snoring continues at 4PM.",
  "id" : 386581359420248065,
  "created_at" : "2013-10-05 19:59:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386554941956845568",
  "geo" : { },
  "id_str" : "386555993536339968",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn what about a wumpus room?",
  "id" : 386555993536339968,
  "in_reply_to_status_id" : 386554941956845568,
  "created_at" : "2013-10-05 18:18:25 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386539130974633984",
  "text" : "Snoring continued unabated throughout lecture and videos. Made breathing exercises exceptionally awkward.",
  "id" : 386539130974633984,
  "created_at" : "2013-10-05 17:11:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386511494361260033",
  "geo" : { },
  "id_str" : "386511807630036992",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy nice!",
  "id" : 386511807630036992,
  "in_reply_to_status_id" : 386511494361260033,
  "created_at" : "2013-10-05 15:22:50 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Benson",
      "screen_name" : "natebenson",
      "indices" : [ 0, 11 ],
      "id_str" : "25678101",
      "id" : 25678101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386486611330232320",
  "geo" : { },
  "id_str" : "386490464033329153",
  "in_reply_to_user_id" : 25678101,
  "text" : "@natebenson yep!",
  "id" : 386490464033329153,
  "in_reply_to_status_id" : 386486611330232320,
  "created_at" : "2013-10-05 13:58:01 +0000",
  "in_reply_to_screen_name" : "natebenson",
  "in_reply_to_user_id_str" : "25678101",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386485568374603776",
  "text" : "Shoutout to the dad snoring through the birthing class. Going to be a long day.",
  "id" : 386485568374603776,
  "created_at" : "2013-10-05 13:38:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386447533016625152",
  "text" : "Newfound use for iPhone flashlight: flipped over on a surface, lights up a room during power outage. \uD83D\uDCA1",
  "id" : 386447533016625152,
  "created_at" : "2013-10-05 11:07:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Cichon",
      "screen_name" : "SteveBuffalo",
      "indices" : [ 0, 13 ],
      "id_str" : "235665553",
      "id" : 235665553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386437588720287744",
  "geo" : { },
  "id_str" : "386443156323303424",
  "in_reply_to_user_id" : 235665553,
  "text" : "@SteveBuffalo same in EV. Don't remember it flickering like that before.",
  "id" : 386443156323303424,
  "in_reply_to_status_id" : 386437588720287744,
  "created_at" : "2013-10-05 10:50:02 +0000",
  "in_reply_to_screen_name" : "SteveBuffalo",
  "in_reply_to_user_id_str" : "235665553",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 54, 64 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386319729272434688",
  "text" : "@juliepagano huge metal knitting needles. Not a joke. @aquaranto has some",
  "id" : 386319729272434688,
  "created_at" : "2013-10-05 02:39:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386317961771769856",
  "geo" : { },
  "id_str" : "386318533325357057",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy can help next week !",
  "id" : 386318533325357057,
  "in_reply_to_status_id" : 386317961771769856,
  "created_at" : "2013-10-05 02:34:50 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386318488270155776",
  "text" : "@juliepagano it's a kindergarten cot from the trainer we use for \"place\" ...he tends to scoot off dog beds during commands",
  "id" : 386318488270155776,
  "created_at" : "2013-10-05 02:34:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386317908948697088",
  "geo" : { },
  "id_str" : "386318136963633152",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape it's just bitter!",
  "id" : 386318136963633152,
  "in_reply_to_status_id" : 386317908948697088,
  "created_at" : "2013-10-05 02:33:15 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/386318076804726785\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/TRv216nn0H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVx6PmfCcAA2zhV.jpg",
      "id_str" : "386318076494376960",
      "id" : 386318076494376960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVx6PmfCcAA2zhV.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/TRv216nn0H"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386318076804726785",
  "text" : "@juliepagano here's Geddy on his place from earlier today. Sorry about what happened :( http:\/\/t.co\/TRv216nn0H",
  "id" : 386318076804726785,
  "created_at" : "2013-10-05 02:33:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 18, 33 ],
      "id_str" : "16393800",
      "id" : 16393800
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 44, 59 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/ctOpjuWlVk",
      "expanded_url" : "http:\/\/bit.ly\/17DcK42",
      "display_url" : "bit.ly\/17DcK42"
    } ]
  },
  "geo" : { },
  "id_str" : "386317795895439360",
  "text" : "Awesome post from @AustinSeraphin about his @nickelcityruby experience: http:\/\/t.co\/ctOpjuWlVk",
  "id" : 386317795895439360,
  "created_at" : "2013-10-05 02:31:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 0, 15 ],
      "id_str" : "16393800",
      "id" : 16393800
    }, {
      "name" : "Neomind Labs",
      "screen_name" : "NeomindLabs",
      "indices" : [ 16, 28 ],
      "id_str" : "605670059",
      "id" : 605670059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386287567026810880",
  "geo" : { },
  "id_str" : "386317623060746240",
  "in_reply_to_user_id" : 16393800,
  "text" : "@AustinSeraphin @NeomindLabs awesome! Also you fit a Cake concert in?!",
  "id" : 386317623060746240,
  "in_reply_to_status_id" : 386287567026810880,
  "created_at" : "2013-10-05 02:31:13 +0000",
  "in_reply_to_screen_name" : "AustinSeraphin",
  "in_reply_to_user_id_str" : "16393800",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 3, 18 ],
      "id_str" : "16393800",
      "id" : 16393800
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 81, 92 ],
      "id_str" : "381521407",
      "id" : 381521407
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 93, 108 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Neomind Labs",
      "screen_name" : "NeomindLabs",
      "indices" : [ 109, 121 ],
      "id_str" : "605670059",
      "id" : 605670059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/qXmTRMNjNY",
      "expanded_url" : "http:\/\/bit.ly\/17DcK42",
      "display_url" : "bit.ly\/17DcK42"
    } ]
  },
  "geo" : { },
  "id_str" : "386317493247021057",
  "text" : "RT @AustinSeraphin: Fear and Loathing in the Nickel City: http:\/\/t.co\/qXmTRMNjNY @rubymotion @nickelcityruby @neomindlabs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyMotion",
        "screen_name" : "RubyMotion",
        "indices" : [ 61, 72 ],
        "id_str" : "381521407",
        "id" : 381521407
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 73, 88 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Neomind Labs",
        "screen_name" : "NeomindLabs",
        "indices" : [ 89, 101 ],
        "id_str" : "605670059",
        "id" : 605670059
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/qXmTRMNjNY",
        "expanded_url" : "http:\/\/bit.ly\/17DcK42",
        "display_url" : "bit.ly\/17DcK42"
      } ]
    },
    "geo" : { },
    "id_str" : "386287567026810880",
    "text" : "Fear and Loathing in the Nickel City: http:\/\/t.co\/qXmTRMNjNY @rubymotion @nickelcityruby @neomindlabs",
    "id" : 386287567026810880,
    "created_at" : "2013-10-05 00:31:47 +0000",
    "user" : {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "protected" : false,
      "id_str" : "16393800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/382052821\/cib8blue_normal.jpg",
      "id" : 16393800,
      "verified" : false
    }
  },
  "id" : 386317493247021057,
  "created_at" : "2013-10-05 02:30:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386316190974353408",
  "text" : "It's Kraken and Cider season again. This is my favorite season.",
  "id" : 386316190974353408,
  "created_at" : "2013-10-05 02:25:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386315996866564096",
  "text" : "@juliepagano holy shit. Glad you're safe.",
  "id" : 386315996866564096,
  "created_at" : "2013-10-05 02:24:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/386260700664180736\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/ibhND7rSuw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVxGD3iIgAAl84k.png",
      "id_str" : "386260700307685376",
      "id" : 386260700307685376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVxGD3iIgAAl84k.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ibhND7rSuw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386260700664180736",
  "text" : "Not sure if new on iOS7: lock screen shows timer countdown. http:\/\/t.co\/ibhND7rSuw",
  "id" : 386260700664180736,
  "created_at" : "2013-10-04 22:45:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    }, {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 8, 19 ],
      "id_str" : "13984262",
      "id" : 13984262
    }, {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 20, 28 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386239996627542016",
  "geo" : { },
  "id_str" : "386245166006157312",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j @themcgruff @noahhlo ha! they used to base64 encode these...",
  "id" : 386245166006157312,
  "in_reply_to_status_id" : 386239996627542016,
  "created_at" : "2013-10-04 21:43:18 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 79, 93 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/dXDfUhQNk2",
      "expanded_url" : "https:\/\/twitter.com\/MascoFromABC2\/status\/386228009910288384",
      "display_url" : "twitter.com\/MascoFromABC2\/\u2026"
    }, {
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/F2rLm0R1gG",
      "expanded_url" : "http:\/\/1.usa.gov\/177j6oM",
      "display_url" : "1.usa.gov\/177j6oM"
    } ]
  },
  "geo" : { },
  "id_str" : "386242018378125312",
  "text" : "RT @zobar2: NICE. We were just talking about subliminal acrostics yesterday at @coworkbuffalo. https:\/\/t.co\/dXDfUhQNk2 http:\/\/t.co\/F2rLm0R1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 67, 81 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/dXDfUhQNk2",
        "expanded_url" : "https:\/\/twitter.com\/MascoFromABC2\/status\/386228009910288384",
        "display_url" : "twitter.com\/MascoFromABC2\/\u2026"
      }, {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/F2rLm0R1gG",
        "expanded_url" : "http:\/\/1.usa.gov\/177j6oM",
        "display_url" : "1.usa.gov\/177j6oM"
      } ]
    },
    "geo" : { },
    "id_str" : "386241844935270400",
    "text" : "NICE. We were just talking about subliminal acrostics yesterday at @coworkbuffalo. https:\/\/t.co\/dXDfUhQNk2 http:\/\/t.co\/F2rLm0R1gG",
    "id" : 386241844935270400,
    "created_at" : "2013-10-04 21:30:06 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 386242018378125312,
  "created_at" : "2013-10-04 21:30:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    }, {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 12, 20 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386234509017874433",
  "geo" : { },
  "id_str" : "386235391985983489",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff @noahhlo I love the flywheels. \"The owner has disabled downloading of their photos\" :(",
  "id" : 386235391985983489,
  "in_reply_to_status_id" : 386234509017874433,
  "created_at" : "2013-10-04 21:04:28 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386229457964380160",
  "geo" : { },
  "id_str" : "386231056417816576",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k :(",
  "id" : 386231056417816576,
  "in_reply_to_status_id" : 386229457964380160,
  "created_at" : "2013-10-04 20:47:14 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WickedGoodRuby",
      "screen_name" : "WickedGoodRuby",
      "indices" : [ 16, 31 ],
      "id_str" : "870817116",
      "id" : 870817116
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 86, 101 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386226396948733952",
  "text" : "Big congrats to @WickedGoodRuby for selling out. Next year more of you need to get to @nickelcityruby!",
  "id" : 386226396948733952,
  "created_at" : "2013-10-04 20:28:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Brady",
      "screen_name" : "dbrady",
      "indices" : [ 3, 10 ],
      "id_str" : "14253546",
      "id" : 14253546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386213617776857088",
  "text" : "RT @dbrady: BREAKING: US Government starting up again after Dems offer GOP a Groupon for 50% off 2014 Budget",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386213477981114368",
    "text" : "BREAKING: US Government starting up again after Dems offer GOP a Groupon for 50% off 2014 Budget",
    "id" : 386213477981114368,
    "created_at" : "2013-10-04 19:37:23 +0000",
    "user" : {
      "name" : "David Brady",
      "screen_name" : "dbrady",
      "protected" : false,
      "id_str" : "14253546",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1390374462\/kisskiss_normal.jpg",
      "id" : 14253546,
      "verified" : false
    }
  },
  "id" : 386213617776857088,
  "created_at" : "2013-10-04 19:37:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386201773049786369",
  "geo" : { },
  "id_str" : "386202344116854784",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden Just don't read them all. I treat twitter like IRC, not RSS (didn't really use that either though). It's just a stream.",
  "id" : 386202344116854784,
  "in_reply_to_status_id" : 386201773049786369,
  "created_at" : "2013-10-04 18:53:08 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Maggard",
      "screen_name" : "cmaggard",
      "indices" : [ 0, 9 ],
      "id_str" : "13643732",
      "id" : 13643732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386196188955160576",
  "geo" : { },
  "id_str" : "386198711778308096",
  "in_reply_to_user_id" : 13643732,
  "text" : "@cmaggard he's continually shipping games since. If you haven't played Le Havre or Ora et Labora you're missing out!",
  "id" : 386198711778308096,
  "in_reply_to_status_id" : 386196188955160576,
  "created_at" : "2013-10-04 18:38:42 +0000",
  "in_reply_to_screen_name" : "cmaggard",
  "in_reply_to_user_id_str" : "13643732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/PDOKy30aQf",
      "expanded_url" : "http:\/\/boardgamegeek.com\/boardgame\/102794\/caverna-the-cave-farmers",
      "display_url" : "boardgamegeek.com\/boardgame\/1027\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386194959197409280",
  "text" : "So you're telling me that the guy who made Agricola basically made a board game Dwarf Fortress!? http:\/\/t.co\/PDOKy30aQf",
  "id" : 386194959197409280,
  "created_at" : "2013-10-04 18:23:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386180048257970177",
  "text" : "TIL that Xcode has a Presentation font mode, and it is fantastic.",
  "id" : 386180048257970177,
  "created_at" : "2013-10-04 17:24:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 15, 30 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386129606404620289",
  "text" : "Wearing a blue @nickelcityruby shirt today...still blown away we made it happen!",
  "id" : 386129606404620289,
  "created_at" : "2013-10-04 14:04:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 9, 17 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386118073641496576",
  "geo" : { },
  "id_str" : "386127746226614272",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius @evanphx I am most likely of little help, but on IRC now",
  "id" : 386127746226614272,
  "in_reply_to_status_id" : 386118073641496576,
  "created_at" : "2013-10-04 13:56:43 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chase Clemons",
      "screen_name" : "chaseclemons",
      "indices" : [ 0, 13 ],
      "id_str" : "16159121",
      "id" : 16159121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386117363059286016",
  "geo" : { },
  "id_str" : "386120201353166848",
  "in_reply_to_user_id" : 16159121,
  "text" : "@chaseclemons THE CORE!",
  "id" : 386120201353166848,
  "in_reply_to_status_id" : 386117363059286016,
  "created_at" : "2013-10-04 13:26:44 +0000",
  "in_reply_to_screen_name" : "chaseclemons",
  "in_reply_to_user_id_str" : "16159121",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386001534716084225",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej man we were just in this area. After hiking through you could tell it was a tinderbox. Such a beautiful part of the country.",
  "id" : 386001534716084225,
  "created_at" : "2013-10-04 05:35:12 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Self Aware ROOMBA",
      "screen_name" : "SelfAwareROOMBA",
      "indices" : [ 19, 35 ],
      "id_str" : "620654544",
      "id" : 620654544
    }, {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "indices" : [ 44, 57 ],
      "id_str" : "174958347",
      "id" : 174958347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385962535725178880",
  "text" : "I can't wait until @SelfAwareROOMBA pulls a @Horse_ebooks. You mean it's not really a Roomba?!",
  "id" : 385962535725178880,
  "created_at" : "2013-10-04 03:00:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 0, 12 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/H1QVKqJPOP",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=aNHIFM0Y87c",
      "display_url" : "youtube.com\/watch?v=aNHIFM\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "385929923481059328",
  "geo" : { },
  "id_str" : "385934301973331969",
  "in_reply_to_user_id" : 14231571,
  "text" : "@marcoarment Hit them with some Bathtub Gin. Whoever can get through the start... http:\/\/t.co\/H1QVKqJPOP",
  "id" : 385934301973331969,
  "in_reply_to_status_id" : 385929923481059328,
  "created_at" : "2013-10-04 01:08:02 +0000",
  "in_reply_to_screen_name" : "marcoarment",
  "in_reply_to_user_id_str" : "14231571",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385839984202113024",
  "geo" : { },
  "id_str" : "385840367817342977",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik amazing show. Gordon's is hilarious at the end with a dude in the crowd shouting how excited he is.",
  "id" : 385840367817342977,
  "in_reply_to_status_id" : 385839984202113024,
  "created_at" : "2013-10-03 18:54:46 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/jnWv8oiOba",
      "expanded_url" : "http:\/\/archive.org\/details\/AQ2013-08-31",
      "display_url" : "archive.org\/details\/AQ2013\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "385838574462963713",
  "geo" : { },
  "id_str" : "385839850189905920",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik have you listened to this yet? http:\/\/t.co\/jnWv8oiOba",
  "id" : 385839850189905920,
  "in_reply_to_status_id" : 385838574462963713,
  "created_at" : "2013-10-03 18:52:43 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Hodges",
      "screen_name" : "jmhodges",
      "indices" : [ 0, 9 ],
      "id_str" : "9267272",
      "id" : 9267272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385833522218291200",
  "geo" : { },
  "id_str" : "385835210509541376",
  "in_reply_to_user_id" : 9267272,
  "text" : "@jmhodges the printing out of 4pt font SSL key was fucking hilarious.",
  "id" : 385835210509541376,
  "in_reply_to_status_id" : 385833522218291200,
  "created_at" : "2013-10-03 18:34:17 +0000",
  "in_reply_to_screen_name" : "jmhodges",
  "in_reply_to_user_id_str" : "9267272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/YvA92onH16",
      "expanded_url" : "https:\/\/washingtondc.craigslist.org\/doc\/sub\/4102714495.html",
      "display_url" : "washingtondc.craigslist.org\/doc\/sub\/410271\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385820656928952320",
  "text" : "\"It was built in like 1800 something.\" https:\/\/t.co\/YvA92onH16",
  "id" : 385820656928952320,
  "created_at" : "2013-10-03 17:36:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roy Tomeij",
      "screen_name" : "roy",
      "indices" : [ 0, 4 ],
      "id_str" : "8837982",
      "id" : 8837982
    }, {
      "name" : "New Relic",
      "screen_name" : "newrelic",
      "indices" : [ 15, 24 ],
      "id_str" : "15527007",
      "id" : 15527007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385798794639855616",
  "geo" : { },
  "id_str" : "385799451425513472",
  "in_reply_to_user_id" : 8837982,
  "text" : "@roy we've got @newrelic on hook already...thanks though.",
  "id" : 385799451425513472,
  "in_reply_to_status_id" : 385798794639855616,
  "created_at" : "2013-10-03 16:12:11 +0000",
  "in_reply_to_screen_name" : "roy",
  "in_reply_to_user_id_str" : "8837982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    }, {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 15, 29 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/LcN7ytyerl",
      "expanded_url" : "http:\/\/gifrific.com\/wp-content\/uploads\/2012\/06\/Boy-That-Escalated-Quickly-Anchorman.gif",
      "display_url" : "gifrific.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "385771682427723777",
  "geo" : { },
  "id_str" : "385772006924242944",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit @BuffaloRising http:\/\/t.co\/LcN7ytyerl",
  "id" : 385772006924242944,
  "in_reply_to_status_id" : 385771682427723777,
  "created_at" : "2013-10-03 14:23:08 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    }, {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 15, 29 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385770428523765760",
  "geo" : { },
  "id_str" : "385771504324980737",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit @BuffaloRising why is this a problem? Is there something to complain about for every positive thing done here?",
  "id" : 385771504324980737,
  "in_reply_to_status_id" : 385770428523765760,
  "created_at" : "2013-10-03 14:21:08 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Gemmell",
      "screen_name" : "mattgemmell",
      "indices" : [ 0, 12 ],
      "id_str" : "755859",
      "id" : 755859
    }, {
      "name" : "Mic Pringle",
      "screen_name" : "micpringle",
      "indices" : [ 13, 24 ],
      "id_str" : "154493778",
      "id" : 154493778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385738552489037824",
  "geo" : { },
  "id_str" : "385770736796704769",
  "in_reply_to_user_id" : 755859,
  "text" : "@mattgemmell @micpringle by \"volunteer\" you mean \"collude\" ?",
  "id" : 385770736796704769,
  "in_reply_to_status_id" : 385738552489037824,
  "created_at" : "2013-10-03 14:18:05 +0000",
  "in_reply_to_screen_name" : "mattgemmell",
  "in_reply_to_user_id_str" : "755859",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 87, 94 ],
      "id_str" : "6118872",
      "id" : 6118872
    }, {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 99, 108 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385533355803947008",
  "geo" : { },
  "id_str" : "385533638374207489",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn @JZ never was a 4X fan but I remember testing many busted betas of Sins with @zoomba and @mittense. Good times!",
  "id" : 385533638374207489,
  "in_reply_to_status_id" : 385533355803947008,
  "created_at" : "2013-10-02 22:35:56 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385525125245714432",
  "geo" : { },
  "id_str" : "385531946354225153",
  "in_reply_to_user_id" : 896641,
  "text" : "@JZ I used to be a mod on WinCustomize...forever ago :)",
  "id" : 385531946354225153,
  "in_reply_to_status_id" : 385525125245714432,
  "created_at" : "2013-10-02 22:29:13 +0000",
  "in_reply_to_screen_name" : "jasonzimdars",
  "in_reply_to_user_id_str" : "896641",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 4, 10 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385520378606387200",
  "text" : "Hey @mattt any plans to update AFOauth2Client for AFN2.0?",
  "id" : 385520378606387200,
  "created_at" : "2013-10-02 21:43:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 15, 26 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385509927487549440",
  "geo" : { },
  "id_str" : "385511174801870848",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents @tenderlove I WILL TRADE PIZZA FOR READING",
  "id" : 385511174801870848,
  "in_reply_to_status_id" : 385509927487549440,
  "created_at" : "2013-10-02 21:06:41 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/d6pObX5f6g",
      "expanded_url" : "http:\/\/www.flightquarters.com\/bird-diapers\/category\/fashion-hoodies.html",
      "display_url" : "flightquarters.com\/bird-diapers\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385489327746080769",
  "text" : "Current status: http:\/\/t.co\/d6pObX5f6g",
  "id" : 385489327746080769,
  "created_at" : "2013-10-02 19:39:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 0, 6 ],
      "id_str" : "1679",
      "id" : 1679
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 7, 11 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Cf0C7L5GfO",
      "expanded_url" : "http:\/\/www.space.com\/14823-sun-storms-northern-lights-auroras.html",
      "display_url" : "space.com\/14823-sun-stor\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "385469225147461634",
  "geo" : { },
  "id_str" : "385469874522189824",
  "in_reply_to_user_id" : 1679,
  "text" : "@javan @dhh Or huge solar flares (being cold is better than knocking out the power grid, etc) http:\/\/t.co\/Cf0C7L5GfO",
  "id" : 385469874522189824,
  "in_reply_to_status_id" : 385469225147461634,
  "created_at" : "2013-10-02 18:22:34 +0000",
  "in_reply_to_screen_name" : "javan",
  "in_reply_to_user_id_str" : "1679",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 0, 15 ],
      "id_str" : "16393800",
      "id" : 16393800
    }, {
      "name" : "Stardock",
      "screen_name" : "Stardock",
      "indices" : [ 16, 25 ],
      "id_str" : "14462781",
      "id" : 14462781
    }, {
      "name" : "Brad Wardell",
      "screen_name" : "draginol",
      "indices" : [ 69, 78 ],
      "id_str" : "13972382",
      "id" : 13972382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385462751201882112",
  "geo" : { },
  "id_str" : "385464047388200961",
  "in_reply_to_user_id" : 16393800,
  "text" : "@AustinSeraphin @Stardock Good question, I haven't tried it out yet. @draginol have you? Lost Cities does an awesome job with it.",
  "id" : 385464047388200961,
  "in_reply_to_status_id" : 385462751201882112,
  "created_at" : "2013-10-02 17:59:25 +0000",
  "in_reply_to_screen_name" : "AustinSeraphin",
  "in_reply_to_user_id_str" : "16393800",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    }, {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 16, 24 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/EfdsF1lQ51",
      "expanded_url" : "http:\/\/cow.org\/csi\/",
      "display_url" : "cow.org\/csi\/"
    } ]
  },
  "in_reply_to_status_id_str" : "385456463306436609",
  "geo" : { },
  "id_str" : "385457475341676544",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda @capotej http:\/\/t.co\/EfdsF1lQ51",
  "id" : 385457475341676544,
  "in_reply_to_status_id" : 385456463306436609,
  "created_at" : "2013-10-02 17:33:18 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stardock",
      "screen_name" : "Stardock",
      "indices" : [ 14, 23 ],
      "id_str" : "14462781",
      "id" : 14462781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/78W4KLeCNz",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/dead-mans-draw\/id584916423?mt=8&fb_action_ids=10202308134448128&fb_action_types=og.likes&fb_source=other_multiline&action_object_map=%7B%2210202308134448128%22%3A561071957263638%7D&action_type_map=%7B%2210202308134448128%22%3A%22og.likes%22%7D&action_ref_map=%5B%5D",
      "display_url" : "itunes.apple.com\/us\/app\/dead-ma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385452880196419584",
  "text" : "My friends at @Stardock have released their first iOS game! Congrats! https:\/\/t.co\/78W4KLeCNz",
  "id" : 385452880196419584,
  "created_at" : "2013-10-02 17:15:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/385452223917858816\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/mwYhcx38Xw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVlmwWUCIAEm3BQ.png",
      "id_str" : "385452223926247425",
      "id" : 385452223926247425,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVlmwWUCIAEm3BQ.png",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 681
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 681
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/mwYhcx38Xw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385452223917858816",
  "text" : "Apparently it costs between $80-300K to wack someone via the Silk Road complaint. Insane. http:\/\/t.co\/mwYhcx38Xw",
  "id" : 385452223917858816,
  "created_at" : "2013-10-02 17:12:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 3, 14 ],
      "id_str" : "13984262",
      "id" : 13984262
    }, {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 105, 112 ],
      "id_str" : "14432203",
      "id" : 14432203
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neveragain",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385445680115769345",
  "text" : "RT @themcgruff: It took us from April until today to get our data migrated from S3 into Glacier. Hat tip @will_j for sticking with it. #nev\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Will Jessop",
        "screen_name" : "will_j",
        "indices" : [ 89, 96 ],
        "id_str" : "14432203",
        "id" : 14432203
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "neveragain",
        "indices" : [ 119, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385445445566074880",
    "text" : "It took us from April until today to get our data migrated from S3 into Glacier. Hat tip @will_j for sticking with it. #neveragain",
    "id" : 385445445566074880,
    "created_at" : "2013-10-02 16:45:30 +0000",
    "user" : {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "protected" : false,
      "id_str" : "13984262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539946640417619968\/0wwEYfHi_normal.png",
      "id" : 13984262,
      "verified" : false
    }
  },
  "id" : 385445680115769345,
  "created_at" : "2013-10-02 16:46:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 143 ],
      "url" : "http:\/\/t.co\/hFFlZBcPKC",
      "expanded_url" : "http:\/\/37signals.com\/svn",
      "display_url" : "37signals.com\/svn"
    } ]
  },
  "geo" : { },
  "id_str" : "385427379872485376",
  "text" : "RT @wilderemily: Did your company transition from office -&gt; remote workforce? Get in touch; you could be featured in a new http:\/\/t.co\/hFFl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/hFFlZBcPKC",
        "expanded_url" : "http:\/\/37signals.com\/svn",
        "display_url" : "37signals.com\/svn"
      } ]
    },
    "geo" : { },
    "id_str" : "385426422547755008",
    "text" : "Did your company transition from office -&gt; remote workforce? Get in touch; you could be featured in a new http:\/\/t.co\/hFFlZBcPKC series!",
    "id" : 385426422547755008,
    "created_at" : "2013-10-02 15:29:54 +0000",
    "user" : {
      "name" : "Emily Triplett Lentz",
      "screen_name" : "emilytlentz",
      "protected" : false,
      "id_str" : "55330075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442792521177894913\/2s9xRuFD_normal.jpeg",
      "id" : 55330075,
      "verified" : false
    }
  },
  "id" : 385427379872485376,
  "created_at" : "2013-10-02 15:33:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobi L\u00FCtke",
      "screen_name" : "tobi",
      "indices" : [ 0, 5 ],
      "id_str" : "676573",
      "id" : 676573
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 6, 10 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/YXofQcZer8",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush",
      "display_url" : "flickr.com\/photos\/qrush"
    } ]
  },
  "in_reply_to_status_id_str" : "385413385380061184",
  "geo" : { },
  "id_str" : "385426209275785217",
  "in_reply_to_user_id" : 676573,
  "text" : "@tobi @dhh rent one first. So glad I did. Lots of stuff on http:\/\/t.co\/YXofQcZer8 from my recent trip via X100S",
  "id" : 385426209275785217,
  "in_reply_to_status_id" : 385413385380061184,
  "created_at" : "2013-10-02 15:29:03 +0000",
  "in_reply_to_screen_name" : "tobi",
  "in_reply_to_user_id_str" : "676573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glynnis Ritchie",
      "screen_name" : "glynnisritchie",
      "indices" : [ 0, 15 ],
      "id_str" : "34892956",
      "id" : 34892956
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 16, 27 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385419437295157250",
  "geo" : { },
  "id_str" : "385422555395284993",
  "in_reply_to_user_id" : 34892956,
  "text" : "@glynnisritchie @ashedryden Some just don't work. Haven't figured out why yet. Been too lazy to run them through ImageMagick to find out why",
  "id" : 385422555395284993,
  "in_reply_to_status_id" : 385419437295157250,
  "created_at" : "2013-10-02 15:14:32 +0000",
  "in_reply_to_screen_name" : "glynnisritchie",
  "in_reply_to_user_id_str" : "34892956",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Glynnis Ritchie",
      "screen_name" : "glynnisritchie",
      "indices" : [ 12, 27 ],
      "id_str" : "34892956",
      "id" : 34892956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/t7LiIo9oB4",
      "expanded_url" : "http:\/\/bukk.it\/",
      "display_url" : "bukk.it"
    } ]
  },
  "in_reply_to_status_id_str" : "385417861490941952",
  "geo" : { },
  "id_str" : "385420551855935489",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @glynnisritchie there's tons at http:\/\/t.co\/t7LiIo9oB4 (also I yank a lot from \/r\/gifs)",
  "id" : 385420551855935489,
  "in_reply_to_status_id" : 385417861490941952,
  "created_at" : "2013-10-02 15:06:35 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 0, 15 ],
      "id_str" : "18777886",
      "id" : 18777886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385409277164138496",
  "geo" : { },
  "id_str" : "385410934774038528",
  "in_reply_to_user_id" : 18777886,
  "text" : "@colindabkowski that one is awesome. I need to get some higher-rez shots of these for wallpapers.",
  "id" : 385410934774038528,
  "in_reply_to_status_id" : 385409277164138496,
  "created_at" : "2013-10-02 14:28:22 +0000",
  "in_reply_to_screen_name" : "colindabkowski",
  "in_reply_to_user_id_str" : "18777886",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SHAQ",
      "screen_name" : "SHAQ",
      "indices" : [ 3, 8 ],
      "id_str" : "17461978",
      "id" : 17461978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/xDQ81OvJzg",
      "expanded_url" : "http:\/\/instagram.com\/p\/ezvDRuwTwR\/",
      "display_url" : "instagram.com\/p\/ezvDRuwTwR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "385269248286679040",
  "text" : "RT @SHAQ: WHOEVER DID THIS PICTURE I HAVE ONE THING TO SAY. YOU ARE A GENIUS. SHAKILL O SEAL.  HILLARIOUS http:\/\/t.co\/xDQ81OvJzg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/xDQ81OvJzg",
        "expanded_url" : "http:\/\/instagram.com\/p\/ezvDRuwTwR\/",
        "display_url" : "instagram.com\/p\/ezvDRuwTwR\/"
      } ]
    },
    "geo" : { },
    "id_str" : "383969997342912512",
    "text" : "WHOEVER DID THIS PICTURE I HAVE ONE THING TO SAY. YOU ARE A GENIUS. SHAKILL O SEAL.  HILLARIOUS http:\/\/t.co\/xDQ81OvJzg",
    "id" : 383969997342912512,
    "created_at" : "2013-09-28 15:02:35 +0000",
    "user" : {
      "name" : "SHAQ",
      "screen_name" : "SHAQ",
      "protected" : false,
      "id_str" : "17461978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1673907275\/image_normal.jpg",
      "id" : 17461978,
      "verified" : true
    }
  },
  "id" : 385269248286679040,
  "created_at" : "2013-10-02 05:05:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/jOkMR5zFz1",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Secession_in_New_York",
      "display_url" : "en.m.wikipedia.org\/wiki\/Secession\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "385255084533104640",
  "geo" : { },
  "id_str" : "385256380296216576",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 this has been long running in NY. Many states have similar issues. http:\/\/t.co\/jOkMR5zFz1",
  "id" : 385256380296216576,
  "in_reply_to_status_id" : 385255084533104640,
  "created_at" : "2013-10-02 04:14:13 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Landers",
      "screen_name" : "bradleyland",
      "indices" : [ 0, 12 ],
      "id_str" : "18256709",
      "id" : 18256709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385231500226359296",
  "geo" : { },
  "id_str" : "385232043296047104",
  "in_reply_to_user_id" : 18256709,
  "text" : "@bradleyland I can guarantee you there was a lot of red (explosions)",
  "id" : 385232043296047104,
  "in_reply_to_status_id" : 385231500226359296,
  "created_at" : "2013-10-02 02:37:31 +0000",
  "in_reply_to_screen_name" : "bradleyland",
  "in_reply_to_user_id_str" : "18256709",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Maggard",
      "screen_name" : "cmaggard",
      "indices" : [ 0, 9 ],
      "id_str" : "13643732",
      "id" : 13643732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385229755643359232",
  "geo" : { },
  "id_str" : "385230231847460864",
  "in_reply_to_user_id" : 13643732,
  "text" : "@cmaggard well it kind of rocked around on the gears until it came to a stop. very surprised it didn't tip over.",
  "id" : 385230231847460864,
  "in_reply_to_status_id" : 385229755643359232,
  "created_at" : "2013-10-02 02:30:19 +0000",
  "in_reply_to_screen_name" : "cmaggard",
  "in_reply_to_user_id_str" : "13643732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/385227635418083328\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/bpDePPfZuU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BViafk9CMAARp-P.png",
      "id_str" : "385227635426471936",
      "id" : 385227635426471936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BViafk9CMAARp-P.png",
      "sizes" : [ {
        "h" : 222,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 914,
        "resize" : "fit",
        "w" : 1394
      } ],
      "display_url" : "pic.twitter.com\/bpDePPfZuU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385227635418083328",
  "text" : "First Mun landing with a self-built ship. Didn't test that the landing gear actually reached the ground... http:\/\/t.co\/bpDePPfZuU",
  "id" : 385227635418083328,
  "created_at" : "2013-10-02 02:20:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 99, 114 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/rBdVqXqVs9",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=sBsi5FGbY2Y",
      "display_url" : "youtube.com\/watch?v=sBsi5F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385201676186955776",
  "text" : "Some amazing scenes of life in Buffalo, and much of why I'm so happy I could bring people here for @nickelcityruby: http:\/\/t.co\/rBdVqXqVs9",
  "id" : 385201676186955776,
  "created_at" : "2013-10-02 00:36:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "indices" : [ 0, 8 ],
      "id_str" : "304067888",
      "id" : 304067888
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 9, 20 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385127992126881792",
  "geo" : { },
  "id_str" : "385138950894911490",
  "in_reply_to_user_id" : 304067888,
  "text" : "@ag_dubs @ashedryden it better include emoji",
  "id" : 385138950894911490,
  "in_reply_to_status_id" : 385127992126881792,
  "created_at" : "2013-10-01 20:27:36 +0000",
  "in_reply_to_screen_name" : "ag_dubs",
  "in_reply_to_user_id_str" : "304067888",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/wSdTIe8U8N",
      "expanded_url" : "http:\/\/time.gov\/",
      "display_url" : "time.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "385137055413448704",
  "text" : "LOL WHO NEEDS TO KEEP TRACK OF TIME ANYWAY http:\/\/t.co\/wSdTIe8U8N",
  "id" : 385137055413448704,
  "created_at" : "2013-10-01 20:20:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385131971497586688",
  "geo" : { },
  "id_str" : "385132072320249856",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy NSExtremelyHairyAndNeedsToBeShavedYak",
  "id" : 385132072320249856,
  "in_reply_to_status_id" : 385131971497586688,
  "created_at" : "2013-10-01 20:00:16 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385130980077359104",
  "text" : "Is there a \"Don't jump around like crazy\" when a build exits unexpectedly in Xcode? On *every* crash it jumps to main.m, very frustrating.",
  "id" : 385130980077359104,
  "created_at" : "2013-10-01 19:55:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henrik Nyh",
      "screen_name" : "henrik",
      "indices" : [ 0, 7 ],
      "id_str" : "14208392",
      "id" : 14208392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385118128155680768",
  "geo" : { },
  "id_str" : "385119000893472769",
  "in_reply_to_user_id" : 14208392,
  "text" : "@henrik it's the part of the description of every dwarf in Dwarf Fortress, literally from the moment they are born. Apt. :)",
  "id" : 385119000893472769,
  "in_reply_to_status_id" : 385118128155680768,
  "created_at" : "2013-10-01 19:08:19 +0000",
  "in_reply_to_screen_name" : "henrik",
  "in_reply_to_user_id_str" : "14208392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385114809777135616",
  "text" : "BTW I'll be taking 5% of all Govstarter\u2122 donations towards \"administration fees\".",
  "id" : 385114809777135616,
  "created_at" : "2013-10-01 18:51:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385112012813905920",
  "text" : "Hear me out here. Kickstarter...for the government.",
  "id" : 385112012813905920,
  "created_at" : "2013-10-01 18:40:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385082172463652864",
  "geo" : { },
  "id_str" : "385084127906504704",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety what in the actual fuck",
  "id" : 385084127906504704,
  "in_reply_to_status_id" : 385082172463652864,
  "created_at" : "2013-10-01 16:49:45 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Warren Wright",
      "screen_name" : "wrightling",
      "indices" : [ 0, 11 ],
      "id_str" : "48692317",
      "id" : 48692317
    }, {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 69, 75 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/Te2HtPPTOB",
      "expanded_url" : "https:\/\/nystateofhealth.ny.gov\/individual\/checkCookie",
      "display_url" : "nystateofhealth.ny.gov\/individual\/che\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "385065345054044160",
  "geo" : { },
  "id_str" : "385065685514080256",
  "in_reply_to_user_id" : 48692317,
  "text" : "@wrightling NY isn't doing much better: https:\/\/t.co\/Te2HtPPTOB (via @jfine)",
  "id" : 385065685514080256,
  "in_reply_to_status_id" : 385065345054044160,
  "created_at" : "2013-10-01 15:36:28 +0000",
  "in_reply_to_screen_name" : "wrightling",
  "in_reply_to_user_id_str" : "48692317",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/fvBsrpNQVj",
      "expanded_url" : "https:\/\/www.healthcare.gov\/",
      "display_url" : "healthcare.gov"
    }, {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/OhPVllwepU",
      "expanded_url" : "https:\/\/github.com\/CMSgov\/healthcare.gov",
      "display_url" : "github.com\/CMSgov\/healthc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385063582687195136",
  "text" : "Incredibly proud and happy that https:\/\/t.co\/fvBsrpNQVj uses Ruby, RubyGems, and Jekyll. It's open source too: https:\/\/t.co\/OhPVllwepU",
  "id" : 385063582687195136,
  "created_at" : "2013-10-01 15:28:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Rufo Sanchez",
      "screen_name" : "rufo",
      "indices" : [ 12, 17 ],
      "id_str" : "710683",
      "id" : 710683
    }, {
      "name" : "Dan Kim",
      "screen_name" : "dankim",
      "indices" : [ 100, 107 ],
      "id_str" : "7979212",
      "id" : 7979212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385060190480896000",
  "geo" : { },
  "id_str" : "385060755659169793",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @rufo I usually slam 300g of water to fill the cup, 18-20g beans. If you want espresso, @dankim has a pretty mean mix",
  "id" : 385060755659169793,
  "in_reply_to_status_id" : 385060190480896000,
  "created_at" : "2013-10-01 15:16:52 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Avery",
      "screen_name" : "averyj",
      "indices" : [ 60, 67 ],
      "id_str" : "6967822",
      "id" : 6967822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/nw9oougZjC",
      "expanded_url" : "http:\/\/usgovernment.statuspage.io\/",
      "display_url" : "usgovernment.statuspage.io"
    } ]
  },
  "geo" : { },
  "id_str" : "385058482237362176",
  "text" : "\"National Parks - Major Outage\" http:\/\/t.co\/nw9oougZjC (via @averyj)",
  "id" : 385058482237362176,
  "created_at" : "2013-10-01 15:07:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jessicard",
      "screen_name" : "jessicard",
      "indices" : [ 3, 13 ],
      "id_str" : "253464752",
      "id" : 253464752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384924002818330624",
  "text" : "RT @jessicard: brb we are all gonna get hit by an asteroid",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384920321351892992",
    "text" : "brb we are all gonna get hit by an asteroid",
    "id" : 384920321351892992,
    "created_at" : "2013-10-01 05:58:50 +0000",
    "user" : {
      "name" : "jessicard",
      "screen_name" : "jessicard",
      "protected" : false,
      "id_str" : "253464752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557025986223411201\/8ZXrxVdG_normal.jpeg",
      "id" : 253464752,
      "verified" : false
    }
  },
  "id" : 384924002818330624,
  "created_at" : "2013-10-01 06:13:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asteroid Watch",
      "screen_name" : "AsteroidWatch",
      "indices" : [ 3, 17 ],
      "id_str" : "23503181",
      "id" : 23503181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384923996942131200",
  "text" : "RT @AsteroidWatch: In the event of government shutdown, we will not be posting or responding from this account. We sincerely hope to resume\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384878343092314112",
    "text" : "In the event of government shutdown, we will not be posting or responding from this account. We sincerely hope to resume tweets soon.",
    "id" : 384878343092314112,
    "created_at" : "2013-10-01 03:12:02 +0000",
    "user" : {
      "name" : "Asteroid Watch",
      "screen_name" : "AsteroidWatch",
      "protected" : false,
      "id_str" : "23503181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509040235900964864\/EmVTcmUe_normal.jpeg",
      "id" : 23503181,
      "verified" : true
    }
  },
  "id" : 384923996942131200,
  "created_at" : "2013-10-01 06:13:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384895153661431809",
  "text" : "RT @CodyOrSomething: Has anyone tried unplugging, and plugging the government back in?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384892035204804609",
    "text" : "Has anyone tried unplugging, and plugging the government back in?",
    "id" : 384892035204804609,
    "created_at" : "2013-10-01 04:06:26 +0000",
    "user" : {
      "name" : "Dody Glaiel",
      "screen_name" : "HungryCody",
      "protected" : false,
      "id_str" : "633381796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567806365838475264\/zwig85EI_normal.jpeg",
      "id" : 633381796,
      "verified" : false
    }
  },
  "id" : 384895153661431809,
  "created_at" : "2013-10-01 04:18:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 0, 14 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384858301957025792",
  "geo" : { },
  "id_str" : "384894281019699200",
  "in_reply_to_user_id" : 16930130,
  "text" : "@PhilDarnowsky he's almost 3, so around 2.5 years.",
  "id" : 384894281019699200,
  "in_reply_to_status_id" : 384858301957025792,
  "created_at" : "2013-10-01 04:15:22 +0000",
  "in_reply_to_screen_name" : "PhilDarnowsky",
  "in_reply_to_user_id_str" : "16930130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
Grailbird.data.tweets_2012_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 3, 13 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164535263001980928",
  "text" : "RT @raganwald: Any sufficiently complicated Sinatra app contains an ad hoc, informally-specified, bug-ridden, slow implementation of hal ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164343866969952256",
    "text" : "Any sufficiently complicated Sinatra app contains an ad hoc, informally-specified, bug-ridden, slow implementation of half of Rails.",
    "id" : 164343866969952256,
    "created_at" : "2012-01-31 13:46:45 +0000",
    "user" : {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "protected" : false,
      "id_str" : "18137723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525649735856570368\/MvtI3PJj_normal.png",
      "id" : 18137723,
      "verified" : false
    }
  },
  "id" : 164535263001980928,
  "created_at" : "2012-02-01 02:27:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164420283300716545",
  "text" : "52 out in Buffalo today. Winter, ha!",
  "id" : 164420283300716545,
  "created_at" : "2012-01-31 18:50:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/AvSVTpXc",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=endscreen&NR=1&v=RdYlmamudFo",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "164388059553607680",
  "text" : "M\u035E\u031B\u0334C\u0340\u035E\u035FD\u035F\u0327O\u0335\u034F\u0340\u0358N\u0341\u0322\u0336\u0315A\u0340\u035F\u035F\u0358\u0335L\u0340\u0322\u00AD\u0358\u0362\u0489D\u0334\u0336\u0340'\u0327\u0340\u0340\u0321S\u0358\u035E\u034F\u0337\u0327 http:\/\/t.co\/AvSVTpXc",
  "id" : 164388059553607680,
  "created_at" : "2012-01-31 16:42:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164379690109386754",
  "geo" : { },
  "id_str" : "164380317543694336",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV haha, i think 0% of twitter is serious. just saying :)",
  "id" : 164380317543694336,
  "in_reply_to_status_id" : 164379690109386754,
  "created_at" : "2012-01-31 16:11:36 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164378568531509248",
  "geo" : { },
  "id_str" : "164378876842225664",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV Sep., 1992 ? cmon.",
  "id" : 164378876842225664,
  "in_reply_to_status_id" : 164378568531509248,
  "created_at" : "2012-01-31 16:05:52 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164377677149638656",
  "text" : "Finally hit up Buffalo Open Coffee Club, really glad to see and meet the tech community here in town!",
  "id" : 164377677149638656,
  "created_at" : "2012-01-31 16:01:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164377145957822464",
  "geo" : { },
  "id_str" : "164377542818676736",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef no but planning to hit Spot Elmwood later. we should have a post-OpenCoffee session next time, plan it on the list.",
  "id" : 164377542818676736,
  "in_reply_to_status_id" : 164377145957822464,
  "created_at" : "2012-01-31 16:00:34 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jgehtland",
      "screen_name" : "jgehtland",
      "indices" : [ 0, 10 ],
      "id_str" : "8384012",
      "id" : 8384012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164130884348428290",
  "geo" : { },
  "id_str" : "164162633908490240",
  "in_reply_to_user_id" : 8384012,
  "text" : "@jgehtland IT'S LIKE A FIGHTER JET MADE OUT OF BICEPS!",
  "id" : 164162633908490240,
  "in_reply_to_status_id" : 164130884348428290,
  "created_at" : "2012-01-31 01:46:36 +0000",
  "in_reply_to_screen_name" : "jgehtland",
  "in_reply_to_user_id_str" : "8384012",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164138595236589569",
  "geo" : { },
  "id_str" : "164153188721758209",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin and stickied music videos, constant political calls to action, stupid and self-serving AmAs, ...",
  "id" : 164153188721758209,
  "in_reply_to_status_id" : 164138595236589569,
  "created_at" : "2012-01-31 01:09:04 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164137484362596352",
  "text" : "Does anyone else remember when Reddit used to be just funny images and programming arguments?",
  "id" : 164137484362596352,
  "created_at" : "2012-01-31 00:06:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wtfpuppy",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163842826084421632",
  "text" : "Not only does our dog sleep in another room now, but he snores in there too. #wtfpuppy",
  "id" : 163842826084421632,
  "created_at" : "2012-01-30 04:35:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 15, 25 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/K61aeHeE",
      "expanded_url" : "http:\/\/instagr.am\/p\/mG6ds\/",
      "display_url" : "instagr.am\/p\/mG6ds\/"
    } ]
  },
  "geo" : { },
  "id_str" : "163827022240546818",
  "text" : "Prototype 1 of @aquaranto's grass\/dirt cube is done! OMG more Minecraft please.  http:\/\/t.co\/K61aeHeE",
  "id" : 163827022240546818,
  "created_at" : "2012-01-30 03:33:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Buryta",
      "screen_name" : "cburyta",
      "indices" : [ 0, 8 ],
      "id_str" : "5875982",
      "id" : 5875982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163779587027902464",
  "geo" : { },
  "id_str" : "163781256558034946",
  "in_reply_to_user_id" : 5875982,
  "text" : "@cburyta way too far for 2 hours. Man we need a real coworking space.",
  "id" : 163781256558034946,
  "in_reply_to_status_id" : 163779587027902464,
  "created_at" : "2012-01-30 00:31:09 +0000",
  "in_reply_to_screen_name" : "cburyta",
  "in_reply_to_user_id_str" : "5875982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 3, 10 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/B31OyAqq",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=igQlbesF0zA",
      "display_url" : "youtube.com\/watch?v=igQlbe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "163762649472057344",
  "text" : "RT @gabebw: \"I've got many fake books, since I'm a leprechaun farmer who's a gambler.\" http:\/\/t.co\/B31OyAqq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/B31OyAqq",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=igQlbesF0zA",
        "display_url" : "youtube.com\/watch?v=igQlbe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "163758723955826688",
    "text" : "\"I've got many fake books, since I'm a leprechaun farmer who's a gambler.\" http:\/\/t.co\/B31OyAqq",
    "id" : 163758723955826688,
    "created_at" : "2012-01-29 23:01:36 +0000",
    "user" : {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "protected" : false,
      "id_str" : "224887329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522042513951977472\/vthKCPDr_normal.jpeg",
      "id" : 224887329,
      "verified" : false
    }
  },
  "id" : 163762649472057344,
  "created_at" : "2012-01-29 23:17:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/r2g906pJ",
      "expanded_url" : "http:\/\/boston.io",
      "display_url" : "boston.io"
    } ]
  },
  "geo" : { },
  "id_str" : "163738144632614912",
  "text" : "Really excited for http:\/\/t.co\/r2g906pJ next weekend, and to see old friends and coworkers galore.",
  "id" : 163738144632614912,
  "created_at" : "2012-01-29 21:39:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 3, 12 ],
      "id_str" : "6980232",
      "id" : 6980232
    }, {
      "name" : "Google Fonts",
      "screen_name" : "googlefonts",
      "indices" : [ 14, 26 ],
      "id_str" : "234923843",
      "id" : 234923843
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/iAZi3A4B",
      "expanded_url" : "http:\/\/hellohappy.org\/beautiful-web-type\/",
      "display_url" : "hellohappy.org\/beautiful-web-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "163459124628168705",
  "text" : "RT @ubuwaits: @googlefonts I'm working on a project to showcase some of my favorite typefaces from your collection: http:\/\/t.co\/iAZi3A4B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Google Fonts",
        "screen_name" : "googlefonts",
        "indices" : [ 0, 12 ],
        "id_str" : "234923843",
        "id" : 234923843
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/iAZi3A4B",
        "expanded_url" : "http:\/\/hellohappy.org\/beautiful-web-type\/",
        "display_url" : "hellohappy.org\/beautiful-web-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162401099041611776",
    "in_reply_to_user_id" : 234923843,
    "text" : "@googlefonts I'm working on a project to showcase some of my favorite typefaces from your collection: http:\/\/t.co\/iAZi3A4B",
    "id" : 162401099041611776,
    "created_at" : "2012-01-26 05:06:53 +0000",
    "in_reply_to_screen_name" : "googlefonts",
    "in_reply_to_user_id_str" : "234923843",
    "user" : {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "protected" : false,
      "id_str" : "6980232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558939000488996864\/n0Z8lT5p_normal.jpeg",
      "id" : 6980232,
      "verified" : false
    }
  },
  "id" : 163459124628168705,
  "created_at" : "2012-01-29 03:11:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163407107947888641",
  "geo" : { },
  "id_str" : "163409677462417408",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove I'm convinced package maintainers live in a fantasy world each with their own special laws and regulations",
  "id" : 163409677462417408,
  "in_reply_to_status_id" : 163407107947888641,
  "created_at" : "2012-01-28 23:54:37 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 0, 6 ],
      "id_str" : "1438261",
      "id" : 1438261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163369605467877377",
  "geo" : { },
  "id_str" : "163408670632312832",
  "in_reply_to_user_id" : 1438261,
  "text" : "@atmos the default one works decent, at least for light usage",
  "id" : 163408670632312832,
  "in_reply_to_status_id" : 163369605467877377,
  "created_at" : "2012-01-28 23:50:37 +0000",
  "in_reply_to_screen_name" : "atmos",
  "in_reply_to_user_id_str" : "1438261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163408311687987201",
  "text" : "No playing enough Carcassone on iOS. My game center ID is Quaranto. Bring it on.",
  "id" : 163408311687987201,
  "created_at" : "2012-01-28 23:49:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 39, 52 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163392705970446336",
  "text" : "So far 15 tweets have disappeared from @herpderpedia's timeline...ended with 414. Kind of wish Twitter didn't allow deletion after 24 hours.",
  "id" : 163392705970446336,
  "created_at" : "2012-01-28 22:47:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/NEdMXi6R",
      "expanded_url" : "http:\/\/instagr.am\/p\/lhumI\/",
      "display_url" : "instagr.am\/p\/lhumI\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9911741022, -78.8110148907 ]
  },
  "id_str" : "163332674767958016",
  "text" : "First time at Brick House. Awesome fireplace.  @ Brickhouse Tavern and Tap http:\/\/t.co\/NEdMXi6R",
  "id" : 163332674767958016,
  "created_at" : "2012-01-28 18:48:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163298220322209792",
  "geo" : { },
  "id_str" : "163306888061128705",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh this is like a school project that was copied and they hoped the TA wouldn't google anything. Except someone gave them $1M.",
  "id" : 163306888061128705,
  "in_reply_to_status_id" : 163298220322209792,
  "created_at" : "2012-01-28 17:06:10 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Crawford",
      "screen_name" : "JonCrawford",
      "indices" : [ 0, 12 ],
      "id_str" : "618223",
      "id" : 618223
    }, {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 13, 25 ],
      "id_str" : "7114202",
      "id" : 7114202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163293805007745024",
  "geo" : { },
  "id_str" : "163306446040203264",
  "in_reply_to_user_id" : 618223,
  "text" : "@JonCrawford @jamesarosen this hurt my brain, my pride, and respect for those I know who work for twitter",
  "id" : 163306446040203264,
  "in_reply_to_status_id" : 163293805007745024,
  "created_at" : "2012-01-28 17:04:25 +0000",
  "in_reply_to_screen_name" : "JonCrawford",
  "in_reply_to_user_id_str" : "618223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 14, 21 ],
      "id_str" : "728173",
      "id" : 728173
    }, {
      "name" : "Robert P",
      "screen_name" : "rbxbx",
      "indices" : [ 22, 28 ],
      "id_str" : "23839885",
      "id" : 23839885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163002336338386945",
  "geo" : { },
  "id_str" : "163007374909636610",
  "in_reply_to_user_id" : 96235840,
  "text" : "@freeblankets @MikeG1 @rbxbx would you buy a cube version? I want a diamond block.",
  "id" : 163007374909636610,
  "in_reply_to_status_id" : 163002336338386945,
  "created_at" : "2012-01-27 21:16:01 +0000",
  "in_reply_to_screen_name" : "giantrobotbee",
  "in_reply_to_user_id_str" : "96235840",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 0, 7 ],
      "id_str" : "728173",
      "id" : 728173
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 37, 47 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163001866416955392",
  "geo" : { },
  "id_str" : "163001990782267392",
  "in_reply_to_user_id" : 728173,
  "text" : "@MikeG1 It's a work in progress! \/cc @aquaranto",
  "id" : 163001990782267392,
  "in_reply_to_status_id" : 163001866416955392,
  "created_at" : "2012-01-27 20:54:37 +0000",
  "in_reply_to_screen_name" : "MikeG1",
  "in_reply_to_user_id_str" : "728173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 8, 18 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/162999221681799168\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/wsRCAu2i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AkMW7bNCQAA2PhR.jpg",
      "id_str" : "162999221685993472",
      "id" : 162999221685993472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AkMW7bNCQAA2PhR.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/wsRCAu2i"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162999221681799168",
  "text" : "Oh man, @aquaranto is starting to crochet different minecraft blocks for awesome pieces to sell. First up, redstone! http:\/\/t.co\/wsRCAu2i",
  "id" : 162999221681799168,
  "created_at" : "2012-01-27 20:43:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THAT isaac",
      "screen_name" : "izs",
      "indices" : [ 3, 7 ],
      "id_str" : "8038312",
      "id" : 8038312
    }, {
      "name" : "philipn",
      "screen_name" : "philipn",
      "indices" : [ 56, 64 ],
      "id_str" : "10782142",
      "id" : 10782142
    }, {
      "name" : "=^._.^=",
      "screen_name" : "maxogden",
      "indices" : [ 65, 74 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/3A9LrX5w",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=8WZr6fvtEgk&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=8WZr6f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162991128172429313",
  "text" : "RT @izs: Shit programmers say http:\/\/t.co\/3A9LrX5w \/via @philipn @maxogden",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "philipn",
        "screen_name" : "philipn",
        "indices" : [ 47, 55 ],
        "id_str" : "10782142",
        "id" : 10782142
      }, {
        "name" : "=^._.^=",
        "screen_name" : "maxogden",
        "indices" : [ 56, 65 ],
        "id_str" : "12241752",
        "id" : 12241752
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http:\/\/t.co\/3A9LrX5w",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=8WZr6fvtEgk&feature=youtu.be",
        "display_url" : "youtube.com\/watch?v=8WZr6f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162989956661391361",
    "text" : "Shit programmers say http:\/\/t.co\/3A9LrX5w \/via @philipn @maxogden",
    "id" : 162989956661391361,
    "created_at" : "2012-01-27 20:06:48 +0000",
    "user" : {
      "name" : "THAT isaac",
      "screen_name" : "izs",
      "protected" : false,
      "id_str" : "8038312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563826348121001984\/1ZoTytsX_normal.jpeg",
      "id" : 8038312,
      "verified" : false
    }
  },
  "id" : 162991128172429313,
  "created_at" : "2012-01-27 20:11:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/rO9wHiKQ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=GsSya4K95jk",
      "display_url" : "youtube.com\/watch?v=GsSya4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162949883416948736",
  "text" : "Rage quit, my favorite new YouTubes. http:\/\/t.co\/rO9wHiKQ",
  "id" : 162949883416948736,
  "created_at" : "2012-01-27 17:27:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "smichm",
      "screen_name" : "smichm",
      "indices" : [ 0, 7 ],
      "id_str" : "1465666537",
      "id" : 1465666537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162574264657129473",
  "geo" : { },
  "id_str" : "162751055988396032",
  "in_reply_to_user_id" : 21119155,
  "text" : "@smichm what? Is this a conference?",
  "id" : 162751055988396032,
  "in_reply_to_status_id" : 162574264657129473,
  "created_at" : "2012-01-27 04:17:30 +0000",
  "in_reply_to_screen_name" : "melissaoliviac",
  "in_reply_to_user_id_str" : "21119155",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162750050664067072",
  "geo" : { },
  "id_str" : "162750766300405760",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis haha this is a riot...you'll have to show me how you found this.",
  "id" : 162750766300405760,
  "in_reply_to_status_id" : 162750050664067072,
  "created_at" : "2012-01-27 04:16:21 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162750541334720513",
  "text" : "After every day of getting email to ACT NOW TO STOP $INJUSTICE, I unsubscribed from DemandProgress with the message \"this is fucking stupid\"",
  "id" : 162750541334720513,
  "created_at" : "2012-01-27 04:15:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/hVT0Hq1g",
      "expanded_url" : "http:\/\/instagr.am\/p\/lAB9l\/",
      "display_url" : "instagr.am\/p\/lAB9l\/"
    } ]
  },
  "geo" : { },
  "id_str" : "162748109947027456",
  "text" : "OkCupid circa 1914 http:\/\/t.co\/hVT0Hq1g",
  "id" : 162748109947027456,
  "created_at" : "2012-01-27 04:05:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/hNcyEJHw",
      "expanded_url" : "http:\/\/instagr.am\/p\/lAAv7\/",
      "display_url" : "instagr.am\/p\/lAAv7\/"
    } ]
  },
  "geo" : { },
  "id_str" : "162747857655431170",
  "text" : "Old Buffalo postcard from 1914 we picked up on our honeymoon  http:\/\/t.co\/hNcyEJHw",
  "id" : 162747857655431170,
  "created_at" : "2012-01-27 04:04:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/30FvTpSA",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3087-basecamp-next-a-peek-at-early-iterations-of-the-projects-screen",
      "display_url" : "37signals.com\/svn\/posts\/3087\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162599125551034368",
  "text" : "RT @sstephenson: Footage from the 37signals cutting room floor: http:\/\/t.co\/30FvTpSA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/30FvTpSA",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3087-basecamp-next-a-peek-at-early-iterations-of-the-projects-screen",
        "display_url" : "37signals.com\/svn\/posts\/3087\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162599064674910208",
    "text" : "Footage from the 37signals cutting room floor: http:\/\/t.co\/30FvTpSA",
    "id" : 162599064674910208,
    "created_at" : "2012-01-26 18:13:32 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 162599125551034368,
  "created_at" : "2012-01-26 18:13:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162559242484719617",
  "text" : "New favorite twitter activity: Mark sponsored tweets that appear in my timeline as spam.",
  "id" : 162559242484719617,
  "created_at" : "2012-01-26 15:35:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 35, 42 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/69E5qpPd",
      "expanded_url" : "http:\/\/capitolcouture.pn\/",
      "display_url" : "capitolcouture.pn"
    } ]
  },
  "geo" : { },
  "id_str" : "162553213743153153",
  "text" : "Neat marketing for Hunger Games on @tumblr. http:\/\/t.co\/69E5qpPd",
  "id" : 162553213743153153,
  "created_at" : "2012-01-26 15:11:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Atzen",
      "screen_name" : "jacobat",
      "indices" : [ 0, 8 ],
      "id_str" : "14169810",
      "id" : 14169810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162482990172209153",
  "geo" : { },
  "id_str" : "162553081110863873",
  "in_reply_to_user_id" : 14169810,
  "text" : "@jacobat Nope.",
  "id" : 162553081110863873,
  "in_reply_to_status_id" : 162482990172209153,
  "created_at" : "2012-01-26 15:10:49 +0000",
  "in_reply_to_screen_name" : "jacobat",
  "in_reply_to_user_id_str" : "14169810",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/AfhA5MDs",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/oji5j\/what_is_the_best_prankpractical_joke_that_youve\/c3hvf7x",
      "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162376604310454272",
  "text" : "Internet troll of the day award goes to: http:\/\/t.co\/AfhA5MDs",
  "id" : 162376604310454272,
  "created_at" : "2012-01-26 03:29:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162356216880824320",
  "text" : "This YouTube video didn't stop at all, and didn't have to buffer! - No one, ever.",
  "id" : 162356216880824320,
  "created_at" : "2012-01-26 02:08:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162350628553752576",
  "text" : "Anyone remember that TDD \/ Testing blog post with neato blue graphs explaining different ways of testing? Would appreciate a link to it.",
  "id" : 162350628553752576,
  "created_at" : "2012-01-26 01:46:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162348309854420992",
  "text" : "How I Learned to Stop Worrying And Hate You For Choosing A Stupid Talk Title Like This.",
  "id" : 162348309854420992,
  "created_at" : "2012-01-26 01:37:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/K31r5Vqi",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=_-agl0pOQfs",
      "display_url" : "youtube.com\/watch?v=_-agl0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162289247288705025",
  "text" : "Current status: http:\/\/t.co\/K31r5Vqi",
  "id" : 162289247288705025,
  "created_at" : "2012-01-25 21:42:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162259425032286208",
  "geo" : { },
  "id_str" : "162260440477470721",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy when are we getting one? Seriously considering renting space.",
  "id" : 162260440477470721,
  "in_reply_to_status_id" : 162259425032286208,
  "created_at" : "2012-01-25 19:47:58 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "follow @mattetti",
      "screen_name" : "merbist",
      "indices" : [ 0, 8 ],
      "id_str" : "1549117117",
      "id" : 1549117117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/rApkTRgH",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5AEGW-Lin98&list=PL2A74B4DEE15C8625&feature=plpp_play_all",
      "display_url" : "youtube.com\/watch?v=5AEGW-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "162228913400066050",
  "geo" : { },
  "id_str" : "162260230556745730",
  "in_reply_to_user_id" : 16476741,
  "text" : "@merbist dude! Let me get you started. :) http:\/\/t.co\/rApkTRgH",
  "id" : 162260230556745730,
  "in_reply_to_status_id" : 162228913400066050,
  "created_at" : "2012-01-25 19:47:08 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 64, 70 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 71, 78 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 79, 90 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/WE9mjUlc",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=A3Z7I6A8-hY",
      "display_url" : "youtube.com\/watch?v=A3Z7I6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162194704107184128",
  "text" : "Page breaking out the keytar. Awesome. http:\/\/t.co\/WE9mjUlc \/cc @cmeik @Croaky @phillapier",
  "id" : 162194704107184128,
  "created_at" : "2012-01-25 15:26:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander",
      "screen_name" : "chebatron",
      "indices" : [ 0, 10 ],
      "id_str" : "14336828",
      "id" : 14336828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161879442589880320",
  "geo" : { },
  "id_str" : "161888953815932928",
  "in_reply_to_user_id" : 14336828,
  "text" : "@chebatron Not that big of a problem for me.",
  "id" : 161888953815932928,
  "in_reply_to_status_id" : 161879442589880320,
  "created_at" : "2012-01-24 19:11:48 +0000",
  "in_reply_to_screen_name" : "chebatron",
  "in_reply_to_user_id_str" : "14336828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/WOmfDbQH",
      "expanded_url" : "http:\/\/media.katu.com\/images\/061101_colbert_painting.jpg",
      "display_url" : "media.katu.com\/images\/061101_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "161882807860342784",
  "geo" : { },
  "id_str" : "161883183074394112",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier ahahah, or like: http:\/\/t.co\/WOmfDbQH",
  "id" : 161883183074394112,
  "in_reply_to_status_id" : 161882807860342784,
  "created_at" : "2012-01-24 18:48:53 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161880372626464768",
  "geo" : { },
  "id_str" : "161881300700102657",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier Agreed, need something awesome for the walls in here. Like my Rush albums. :)",
  "id" : 161881300700102657,
  "in_reply_to_status_id" : 161880372626464768,
  "created_at" : "2012-01-24 18:41:24 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/C6aOVpsa",
      "expanded_url" : "http:\/\/path.com\/p\/175K1G",
      "display_url" : "path.com\/p\/175K1G"
    } ]
  },
  "geo" : { },
  "id_str" : "161877203863343107",
  "text" : "Battlestation 2.0. Moved closer to the radiator, added a lamp. [pic] \u2014 http:\/\/t.co\/C6aOVpsa",
  "id" : 161877203863343107,
  "created_at" : "2012-01-24 18:25:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 37, 46 ],
      "id_str" : "1051521",
      "id" : 1051521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/lIfiZgq6",
      "expanded_url" : "http:\/\/migreyes.tumblr.com\/post\/16368304104\/on-the-move",
      "display_url" : "migreyes.tumblr.com\/post\/163683041\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "161830805008678912",
  "text" : "RT @jasonfried: Mig breaks the news: @migreyes is joining 37signals: http:\/\/t.co\/lIfiZgq6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mig Reyes",
        "screen_name" : "migreyes",
        "indices" : [ 21, 30 ],
        "id_str" : "1051521",
        "id" : 1051521
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/lIfiZgq6",
        "expanded_url" : "http:\/\/migreyes.tumblr.com\/post\/16368304104\/on-the-move",
        "display_url" : "migreyes.tumblr.com\/post\/163683041\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "161828140820348928",
    "text" : "Mig breaks the news: @migreyes is joining 37signals: http:\/\/t.co\/lIfiZgq6",
    "id" : 161828140820348928,
    "created_at" : "2012-01-24 15:10:10 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 161830805008678912,
  "created_at" : "2012-01-24 15:20:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/161678497608253440\/photo\/1",
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/rVdSGFKH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aj5lvKoCQAA8Hpf.jpg",
      "id_str" : "161678497612447744",
      "id" : 161678497612447744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aj5lvKoCQAA8Hpf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/rVdSGFKH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161678497608253440",
  "text" : "Current status http:\/\/t.co\/rVdSGFKH",
  "id" : 161678497608253440,
  "created_at" : "2012-01-24 05:15:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161643952225787904",
  "text" : "Back home in BUF. Feels good man.",
  "id" : 161643952225787904,
  "created_at" : "2012-01-24 02:58:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/zYnmXHep",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/16382750772\/apprentice-io-three-week-retrospective",
      "display_url" : "robots.thoughtbot.com\/post\/163827507\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "161643787859398656",
  "text" : "RT @thoughtbot: apprentice.io three week retrospective http:\/\/t.co\/zYnmXHep",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/zYnmXHep",
        "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/16382750772\/apprentice-io-three-week-retrospective",
        "display_url" : "robots.thoughtbot.com\/post\/163827507\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "161642541853323266",
    "text" : "apprentice.io three week retrospective http:\/\/t.co\/zYnmXHep",
    "id" : 161642541853323266,
    "created_at" : "2012-01-24 02:52:39 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 161643787859398656,
  "created_at" : "2012-01-24 02:57:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161601551872442368",
  "text" : "Woo en route again. Bye NYC! \u2708",
  "id" : 161601551872442368,
  "created_at" : "2012-01-24 00:09:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161596977283481601",
  "text" : "Yay stuck on the tarmac at JFK!",
  "id" : 161596977283481601,
  "created_at" : "2012-01-23 23:51:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/RUikikzA",
      "expanded_url" : "http:\/\/www.theatlanticcities.com\/commute\/2012\/01\/zen-and-art-snow-plow-maintenance\/1008\/",
      "display_url" : "theatlanticcities.com\/commute\/2012\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "161577667206975488",
  "text" : "Buffalo: #1 in something, at least! http:\/\/t.co\/RUikikzA",
  "id" : 161577667206975488,
  "created_at" : "2012-01-23 22:34:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/SLxVzbcn",
      "expanded_url" : "http:\/\/path.com\/p\/UClGf",
      "display_url" : "path.com\/p\/UClGf"
    } ]
  },
  "geo" : { },
  "id_str" : "161501171499024384",
  "text" : "You are looking at this. (with Amanda) [pic] \u2014 http:\/\/t.co\/SLxVzbcn",
  "id" : 161501171499024384,
  "created_at" : "2012-01-23 17:30:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161492410118053888",
  "geo" : { },
  "id_str" : "161493511080906755",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc sure, no problem",
  "id" : 161493511080906755,
  "in_reply_to_status_id" : 161492410118053888,
  "created_at" : "2012-01-23 17:00:28 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 11, 20 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161485078868926464",
  "geo" : { },
  "id_str" : "161493295174922241",
  "in_reply_to_user_id" : 372319943,
  "text" : "@A_R_Q_522 @bquarant there's a reason Q is the best nickname our family has",
  "id" : 161493295174922241,
  "in_reply_to_status_id" : 161485078868926464,
  "created_at" : "2012-01-23 16:59:36 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Annesley",
      "screen_name" : "pda",
      "indices" : [ 0, 4 ],
      "id_str" : "23883",
      "id" : 23883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161323136321716226",
  "geo" : { },
  "id_str" : "161442144404508672",
  "in_reply_to_user_id" : 23883,
  "text" : "@pda dependency info is locked up on the gem specs, this is why bundler 1.1 uses a new endpoint. Just the first of many steps I hope",
  "id" : 161442144404508672,
  "in_reply_to_status_id" : 161323136321716226,
  "created_at" : "2012-01-23 13:36:21 +0000",
  "in_reply_to_screen_name" : "pda",
  "in_reply_to_user_id_str" : "23883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161312528960454656",
  "text" : "Puzzle juice is awesome. It's word hunt + Tetris.",
  "id" : 161312528960454656,
  "created_at" : "2012-01-23 05:01:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/puzzlejuicegame.com\" rel=\"nofollow\"\u003EPuzzlejuice\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Puzzlejuice",
      "indices" : [ 47, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/oB1AGjGs",
      "expanded_url" : "http:\/\/bit.ly\/Puzzlejuice",
      "display_url" : "bit.ly\/Puzzlejuice"
    } ]
  },
  "geo" : { },
  "id_str" : "161312423087849474",
  "text" : "I just scored 1,289,065 points on Euro Mode in #Puzzlejuice! My sweetest word was  \"QUEER\" http:\/\/t.co\/oB1AGjGs",
  "id" : 161312423087849474,
  "created_at" : "2012-01-23 05:00:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/2jjsH25U",
      "expanded_url" : "http:\/\/path.com\/p\/OmKa4",
      "display_url" : "path.com\/p\/OmKa4"
    } ]
  },
  "geo" : { },
  "id_str" : "161181328463761408",
  "text" : "Dinner? (with Amanda at Museum Of Natural History) [pic] \u2014 http:\/\/t.co\/2jjsH25U",
  "id" : 161181328463761408,
  "created_at" : "2012-01-22 20:19:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 3, 17 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/JgkZnqw8",
      "expanded_url" : "http:\/\/www.buffalorising.com\/2012\/01\/inaugural-buffalo-winter-brewfest.html",
      "display_url" : "buffalorising.com\/2012\/01\/inaugu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "161168206533361664",
  "text" : "RT @BuffaloRising: Inaugural Buffalo Winter Brewfest: http:\/\/t.co\/JgkZnqw8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/JgkZnqw8",
        "expanded_url" : "http:\/\/www.buffalorising.com\/2012\/01\/inaugural-buffalo-winter-brewfest.html",
        "display_url" : "buffalorising.com\/2012\/01\/inaugu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "161147380610244608",
    "text" : "Inaugural Buffalo Winter Brewfest: http:\/\/t.co\/JgkZnqw8",
    "id" : 161147380610244608,
    "created_at" : "2012-01-22 18:05:04 +0000",
    "user" : {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "protected" : false,
      "id_str" : "5896952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749220504\/buffalorisingblue_normal.jpg",
      "id" : 5896952,
      "verified" : false
    }
  },
  "id" : 161168206533361664,
  "created_at" : "2012-01-22 19:27:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/7tfjwg8J",
      "expanded_url" : "http:\/\/path.com\/p\/NXu5j",
      "display_url" : "path.com\/p\/NXu5j"
    } ]
  },
  "geo" : { },
  "id_str" : "160912278550609920",
  "text" : "Awesome seats for Nick DiPaolo. (with Amanda) [pic] \u2014 http:\/\/t.co\/7tfjwg8J",
  "id" : 160912278550609920,
  "created_at" : "2012-01-22 02:30:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160865121554546688",
  "text" : "Looks like texting cancel does the job. Phew.",
  "id" : 160865121554546688,
  "created_at" : "2012-01-21 23:23:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160863498778329088",
  "geo" : { },
  "id_str" : "160864226427150337",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza figured there would be a schedule time to pickup screen, not IMMEDIATELY.",
  "id" : 160864226427150337,
  "in_reply_to_status_id" : 160863498778329088,
  "created_at" : "2012-01-21 23:19:54 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber",
      "screen_name" : "Uber",
      "indices" : [ 31, 36 ],
      "id_str" : "19103481",
      "id" : 19103481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160863765317955584",
  "text" : "Phone support does nothing for @uber. Seriously?",
  "id" : 160863765317955584,
  "created_at" : "2012-01-21 23:18:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160862223089152002",
  "geo" : { },
  "id_str" : "160863437512118273",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy seriously! Elmwood village is awesome.",
  "id" : 160863437512118273,
  "in_reply_to_status_id" : 160862223089152002,
  "created_at" : "2012-01-21 23:16:46 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber",
      "screen_name" : "Uber",
      "indices" : [ 10, 15 ],
      "id_str" : "19103481",
      "id" : 19103481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160863320776249345",
  "text" : "Fucked up @uber on my first time. Why isn't there a big THIS WILL HAPPEN RIGHT NOW warning?",
  "id" : 160863320776249345,
  "created_at" : "2012-01-21 23:16:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/2DvWgpUp",
      "expanded_url" : "http:\/\/path.com\/p\/1ezDiY",
      "display_url" : "path.com\/p\/1ezDiY"
    } ]
  },
  "geo" : { },
  "id_str" : "160845746151763968",
  "text" : "The most badass Game Boy. (with Amanda at Nintendo World) [pic] \u2014 http:\/\/t.co\/2DvWgpUp",
  "id" : 160845746151763968,
  "created_at" : "2012-01-21 22:06:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160845019547308032",
  "text" : "Nintendo World store has Link to the Past's overworked song playing throughout the store. Omg.",
  "id" : 160845019547308032,
  "created_at" : "2012-01-21 22:03:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/WB1D4wfl",
      "expanded_url" : "http:\/\/path.com\/p\/1yAHat",
      "display_url" : "path.com\/p\/1yAHat"
    } ]
  },
  "geo" : { },
  "id_str" : "160844384072515584",
  "text" : "I don't recognize any of these things. (with Amanda at Nintendo World) [pic] \u2014 http:\/\/t.co\/WB1D4wfl",
  "id" : 160844384072515584,
  "created_at" : "2012-01-21 22:01:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/RGXRffyl",
      "expanded_url" : "http:\/\/path.com\/p\/2Y4mBe",
      "display_url" : "path.com\/p\/2Y4mBe"
    } ]
  },
  "geo" : { },
  "id_str" : "160840101679730688",
  "text" : "The rock. (with Amanda) [pic] \u2014 http:\/\/t.co\/RGXRffyl",
  "id" : 160840101679730688,
  "created_at" : "2012-01-21 21:44:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/sdeEHRTs",
      "expanded_url" : "http:\/\/path.com\/p\/2bra0y",
      "display_url" : "path.com\/p\/2bra0y"
    } ]
  },
  "geo" : { },
  "id_str" : "160806132636594176",
  "text" : "I love that MoMA has a font gallery. (with Amanda) [pic] \u2014 http:\/\/t.co\/sdeEHRTs",
  "id" : 160806132636594176,
  "created_at" : "2012-01-21 19:29:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/H4GroHQp",
      "expanded_url" : "http:\/\/path.com\/p\/tgv8U",
      "display_url" : "path.com\/p\/tgv8U"
    } ]
  },
  "geo" : { },
  "id_str" : "160797244919001088",
  "text" : "Confusedfucious. (with Amanda) [pic] \u2014 http:\/\/t.co\/H4GroHQp",
  "id" : 160797244919001088,
  "created_at" : "2012-01-21 18:53:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Museum of Modern Art",
      "screen_name" : "MuseumModernArt",
      "indices" : [ 31, 47 ],
      "id_str" : "15057943",
      "id" : 15057943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/ppMU1VxV",
      "expanded_url" : "http:\/\/path.com\/p\/iQjnY",
      "display_url" : "path.com\/p\/iQjnY"
    } ]
  },
  "geo" : { },
  "id_str" : "160794022716252160",
  "text" : "Endless candy. (with Amanda at @MuseumModernArt) [pic] \u2014 http:\/\/t.co\/ppMU1VxV",
  "id" : 160794022716252160,
  "created_at" : "2012-01-21 18:40:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I'M TOO SCOTT",
      "screen_name" : "effseedee",
      "indices" : [ 3, 13 ],
      "id_str" : "28749754",
      "id" : 28749754
    }, {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 27, 40 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/j5kiNv9N",
      "expanded_url" : "http:\/\/youtu.be\/TlDuVXW-O74",
      "display_url" : "youtu.be\/TlDuVXW-O74"
    } ]
  },
  "geo" : { },
  "id_str" : "160751894086688768",
  "text" : "RT @effseedee: Readings of @herpderpedia: http:\/\/t.co\/j5kiNv9N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "herpderpedia",
        "screen_name" : "herpderpedia",
        "indices" : [ 12, 25 ],
        "id_str" : "467162656",
        "id" : 467162656
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http:\/\/t.co\/j5kiNv9N",
        "expanded_url" : "http:\/\/youtu.be\/TlDuVXW-O74",
        "display_url" : "youtu.be\/TlDuVXW-O74"
      } ]
    },
    "geo" : { },
    "id_str" : "160579763050786816",
    "text" : "Readings of @herpderpedia: http:\/\/t.co\/j5kiNv9N",
    "id" : 160579763050786816,
    "created_at" : "2012-01-21 04:29:33 +0000",
    "user" : {
      "name" : "I'M TOO SCOTT",
      "screen_name" : "effseedee",
      "protected" : false,
      "id_str" : "28749754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537839770668261377\/-GV3KDh6_normal.jpeg",
      "id" : 28749754,
      "verified" : false
    }
  },
  "id" : 160751894086688768,
  "created_at" : "2012-01-21 15:53:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160575135307411457",
  "geo" : { },
  "id_str" : "160580682882629632",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant yes, and harry potter will defeat lord voldemort, and then you'll get accepted into hogwarts",
  "id" : 160580682882629632,
  "in_reply_to_status_id" : 160575135307411457,
  "created_at" : "2012-01-21 04:33:12 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 11, 20 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/pqCELmUj",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Drake_equation",
      "display_url" : "en.wikipedia.org\/wiki\/Drake_equ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "160550613103558659",
  "geo" : { },
  "id_str" : "160551914323460097",
  "in_reply_to_user_id" : 372319943,
  "text" : "@A_R_Q_522 @bquarant http:\/\/t.co\/pqCELmUj",
  "id" : 160551914323460097,
  "in_reply_to_status_id" : 160550613103558659,
  "created_at" : "2012-01-21 02:38:53 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Kelly",
      "screen_name" : "amateurhuman",
      "indices" : [ 0, 13 ],
      "id_str" : "41456770",
      "id" : 41456770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160494848997208065",
  "geo" : { },
  "id_str" : "160518680415977472",
  "in_reply_to_user_id" : 41456770,
  "text" : "@amateurhuman already have it :)",
  "id" : 160518680415977472,
  "in_reply_to_status_id" : 160494848997208065,
  "created_at" : "2012-01-21 00:26:50 +0000",
  "in_reply_to_screen_name" : "amateurhuman",
  "in_reply_to_user_id_str" : "41456770",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/xS05IKY6",
      "expanded_url" : "http:\/\/path.com\/p\/2mgsWx",
      "display_url" : "path.com\/p\/2mgsWx"
    } ]
  },
  "geo" : { },
  "id_str" : "160491105526362112",
  "text" : "Is this real life? This store is awesome. (with Amanda at The Compleat Strategist) [pic] \u2014 http:\/\/t.co\/xS05IKY6",
  "id" : 160491105526362112,
  "created_at" : "2012-01-20 22:37:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GrandCentralTerminal",
      "screen_name" : "GrandCentralNYC",
      "indices" : [ 85, 101 ],
      "id_str" : "355737400",
      "id" : 355737400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/j4VG9ozZ",
      "expanded_url" : "http:\/\/path.com\/p\/3IFVYK",
      "display_url" : "path.com\/p\/3IFVYK"
    } ]
  },
  "geo" : { },
  "id_str" : "160470668784316416",
  "text" : "Squash tournament INSIDE  of GCT. Close as I could get, it's mobbed. (with Amanda at @GrandCentralNYC) [pic] \u2014 http:\/\/t.co\/j4VG9ozZ",
  "id" : 160470668784316416,
  "created_at" : "2012-01-20 21:16:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/XbrT3ay4",
      "expanded_url" : "http:\/\/path.com\/p\/2ejmDS",
      "display_url" : "path.com\/p\/2ejmDS"
    } ]
  },
  "geo" : { },
  "id_str" : "160468044483788801",
  "text" : "Classiest apple store ever. (with Amanda at Apple Store, Grand Central) [pic] \u2014 http:\/\/t.co\/XbrT3ay4",
  "id" : 160468044483788801,
  "created_at" : "2012-01-20 21:05:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "indices" : [ 0, 4 ],
      "id_str" : "5523",
      "id" : 5523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159879076805488640",
  "geo" : { },
  "id_str" : "160390956489781248",
  "in_reply_to_user_id" : 5523,
  "text" : "@pat considering the Sunday show...have you seen him?",
  "id" : 160390956489781248,
  "in_reply_to_status_id" : 159879076805488640,
  "created_at" : "2012-01-20 15:59:18 +0000",
  "in_reply_to_screen_name" : "pat",
  "in_reply_to_user_id_str" : "5523",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 84, 94 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160389696717979648",
  "geo" : { },
  "id_str" : "160390774566031360",
  "in_reply_to_user_id" : 65247837,
  "text" : "@DanAlfano airbnb'd a whole place! Thanks though. Just keeping this trip for me and @aquaranto to chill and have fun.",
  "id" : 160390774566031360,
  "in_reply_to_status_id" : 160389696717979648,
  "created_at" : "2012-01-20 15:58:35 +0000",
  "in_reply_to_screen_name" : "Hoonidan",
  "in_reply_to_user_id_str" : "65247837",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160358528282927104",
  "text" : "Hey NYC folks, last question, I promise: best way to get from JFK to manhattan? Cab? Subway? \u00DCber?",
  "id" : 160358528282927104,
  "created_at" : "2012-01-20 13:50:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160194884068839424",
  "geo" : { },
  "id_str" : "160195785819045888",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel awesome.",
  "id" : 160195785819045888,
  "in_reply_to_status_id" : 160194884068839424,
  "created_at" : "2012-01-20 03:03:46 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Robinson",
      "screen_name" : "recluce",
      "indices" : [ 0, 8 ],
      "id_str" : "39599503",
      "id" : 39599503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160169795034169345",
  "geo" : { },
  "id_str" : "160181588926271488",
  "in_reply_to_user_id" : 39599503,
  "text" : "@recluce cool thanks!",
  "id" : 160181588926271488,
  "in_reply_to_status_id" : 160169795034169345,
  "created_at" : "2012-01-20 02:07:21 +0000",
  "in_reply_to_screen_name" : "recluce",
  "in_reply_to_user_id_str" : "39599503",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Leeder",
      "screen_name" : "leederc",
      "indices" : [ 0, 8 ],
      "id_str" : "359807769",
      "id" : 359807769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160077308340862977",
  "geo" : { },
  "id_str" : "160077987595825153",
  "in_reply_to_user_id" : 359807769,
  "text" : "@leederc highlights the twitter searches I mainly used :)",
  "id" : 160077987595825153,
  "in_reply_to_status_id" : 160077308340862977,
  "created_at" : "2012-01-19 19:15:41 +0000",
  "in_reply_to_screen_name" : "leederc",
  "in_reply_to_user_id_str" : "359807769",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 67 ],
      "url" : "https:\/\/t.co\/cqHVP736",
      "expanded_url" : "https:\/\/gist.github.com\/1641705",
      "display_url" : "gist.github.com\/1641705"
    } ]
  },
  "geo" : { },
  "id_str" : "160077480521236480",
  "text" : "LOL, form letter for newly acquired startups: https:\/\/t.co\/cqHVP736",
  "id" : 160077480521236480,
  "created_at" : "2012-01-19 19:13:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 57, 71 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160065263914582016",
  "geo" : { },
  "id_str" : "160068243934027777",
  "in_reply_to_user_id" : 65247837,
  "text" : "@DanAlfano I was at his second rendition of said talk :) @garybernhardt you're e-famous!",
  "id" : 160068243934027777,
  "in_reply_to_status_id" : 160065263914582016,
  "created_at" : "2012-01-19 18:36:57 +0000",
  "in_reply_to_screen_name" : "Hoonidan",
  "in_reply_to_user_id_str" : "65247837",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 78, 84 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 85, 92 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 93, 104 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/sNE2lBJD",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=n8P_JlMAsMc",
      "display_url" : "youtube.com\/watch?v=n8P_Jl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "160067670140665856",
  "text" : "Loving this set when Trey breaks out the toy guitar. http:\/\/t.co\/sNE2lBJD \/cc @cmeik @Croaky @phillapier",
  "id" : 160067670140665856,
  "created_at" : "2012-01-19 18:34:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/pfLMoJKF",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=yRvJylbSg7o#",
      "display_url" : "youtube.com\/watch?v=yRvJyl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "160053492701081600",
  "text" : "Preparing for our NYC trip tomorrow. http:\/\/t.co\/pfLMoJKF!",
  "id" : 160053492701081600,
  "created_at" : "2012-01-19 17:38:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sonikkuso",
      "screen_name" : "sanitysama",
      "indices" : [ 0, 11 ],
      "id_str" : "87862080",
      "id" : 87862080
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159879515995258880",
  "geo" : { },
  "id_str" : "159879913829171200",
  "in_reply_to_user_id" : 87862080,
  "text" : "@sanitysama amazing.",
  "id" : 159879913829171200,
  "in_reply_to_status_id" : 159879515995258880,
  "created_at" : "2012-01-19 06:08:36 +0000",
  "in_reply_to_screen_name" : "sanitysama",
  "in_reply_to_user_id_str" : "87862080",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 10, 23 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159879012745875456",
  "text" : "Stages of @herpderpedia readers: Shock, Hilarity, Denial, Acceptance, Loss of Faith in Humanity, Expression of Desire to Leave Planet",
  "id" : 159879012745875456,
  "created_at" : "2012-01-19 06:05:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Peruzzini",
      "screen_name" : "KeightP",
      "indices" : [ 0, 8 ],
      "id_str" : "18247553",
      "id" : 18247553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159875361851703296",
  "geo" : { },
  "id_str" : "159875650293989376",
  "in_reply_to_user_id" : 18247553,
  "text" : "@KeightP many 711s have them.... No idea why.",
  "id" : 159875650293989376,
  "in_reply_to_status_id" : 159875361851703296,
  "created_at" : "2012-01-19 05:51:40 +0000",
  "in_reply_to_screen_name" : "KeightP",
  "in_reply_to_user_id_str" : "18247553",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 32, 45 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159863257052622849",
  "text" : "Dragged up some old ones to end @herpderpedia. Done!",
  "id" : 159863257052622849,
  "created_at" : "2012-01-19 05:02:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159861979815739392",
  "text" : "Haha, watching a twitter spam bot with multiple accounts in real time, just search for \"omg wikipedia\"",
  "id" : 159861979815739392,
  "created_at" : "2012-01-19 04:57:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Driscoll",
      "screen_name" : "Realspaceman",
      "indices" : [ 0, 13 ],
      "id_str" : "121875156",
      "id" : 121875156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159856958831202304",
  "geo" : { },
  "id_str" : "159857464630710272",
  "in_reply_to_user_id" : 121875156,
  "text" : "@Realspaceman The main page is still blacking out for me",
  "id" : 159857464630710272,
  "in_reply_to_status_id" : 159856958831202304,
  "created_at" : "2012-01-19 04:39:24 +0000",
  "in_reply_to_screen_name" : "Realspaceman",
  "in_reply_to_user_id_str" : "121875156",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 17, 30 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159856413332615168",
  "text" : "Final blowout of @herpderpedia. Going to stop at midnight EST.",
  "id" : 159856413332615168,
  "created_at" : "2012-01-19 04:35:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159854489149521921",
  "geo" : { },
  "id_str" : "159854700244631552",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits what does this even mean",
  "id" : 159854700244631552,
  "in_reply_to_status_id" : 159854489149521921,
  "created_at" : "2012-01-19 04:28:25 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/BfVBono7",
      "expanded_url" : "http:\/\/path.com\/p\/4dsYQ",
      "display_url" : "path.com\/p\/4dsYQ"
    } ]
  },
  "geo" : { },
  "id_str" : "159850198183587840",
  "text" : "Agricola! 42 points! (with Amanda) [pic] \u2014 http:\/\/t.co\/BfVBono7",
  "id" : 159850198183587840,
  "created_at" : "2012-01-19 04:10:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/qpQBNAy8",
      "expanded_url" : "http:\/\/www.kungfugrippe.com\/post\/511063886\/tweets-are-not-nothing",
      "display_url" : "kungfugrippe.com\/post\/511063886\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159824945914978304",
  "text" : "Apparently someone already tried to publish tweets in a book, so that's not gonna happen. http:\/\/t.co\/qpQBNAy8",
  "id" : 159824945914978304,
  "created_at" : "2012-01-19 02:30:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 17, 27 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 75, 88 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159822602397941760",
  "text" : "Real life viral: @aquaranto met some folks at her crochet meetup that read @herpderpedia.",
  "id" : 159822602397941760,
  "created_at" : "2012-01-19 02:20:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Hanke",
      "screen_name" : "hanke",
      "indices" : [ 0, 6 ],
      "id_str" : "1018421",
      "id" : 1018421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159820305211203584",
  "geo" : { },
  "id_str" : "159821293632503808",
  "in_reply_to_user_id" : 1018421,
  "text" : "@hanke it's meant to be satire.",
  "id" : 159821293632503808,
  "in_reply_to_status_id" : 159820305211203584,
  "created_at" : "2012-01-19 02:15:40 +0000",
  "in_reply_to_screen_name" : "hanke",
  "in_reply_to_user_id_str" : "1018421",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zefrank",
      "screen_name" : "zefrank",
      "indices" : [ 0, 8 ],
      "id_str" : "11340982",
      "id" : 11340982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159817590145941504",
  "geo" : { },
  "id_str" : "159818343283568641",
  "in_reply_to_user_id" : 11340982,
  "text" : "@zefrank yes!! my first zetweet! thanks dude.",
  "id" : 159818343283568641,
  "in_reply_to_status_id" : 159817590145941504,
  "created_at" : "2012-01-19 02:03:56 +0000",
  "in_reply_to_screen_name" : "zefrank",
  "in_reply_to_user_id_str" : "11340982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Hanke",
      "screen_name" : "hanke",
      "indices" : [ 0, 6 ],
      "id_str" : "1018421",
      "id" : 1018421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159817972179935233",
  "geo" : { },
  "id_str" : "159818243199086593",
  "in_reply_to_user_id" : 1018421,
  "text" : "@hanke you're missing the point.",
  "id" : 159818243199086593,
  "in_reply_to_status_id" : 159817972179935233,
  "created_at" : "2012-01-19 02:03:33 +0000",
  "in_reply_to_screen_name" : "hanke",
  "in_reply_to_user_id_str" : "1018421",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Williams",
      "screen_name" : "mwilliams",
      "indices" : [ 0, 10 ],
      "id_str" : "1259861",
      "id" : 1259861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159814267317661696",
  "geo" : { },
  "id_str" : "159814684835450880",
  "in_reply_to_user_id" : 1259861,
  "text" : "@mwilliams good, I need to catch up with the discussion...read up to Escher in the intro.",
  "id" : 159814684835450880,
  "in_reply_to_status_id" : 159814267317661696,
  "created_at" : "2012-01-19 01:49:24 +0000",
  "in_reply_to_screen_name" : "mwilliams",
  "in_reply_to_user_id_str" : "1259861",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Wunsch",
      "screen_name" : "markwunsch",
      "indices" : [ 0, 11 ],
      "id_str" : "15108584",
      "id" : 15108584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 70 ],
      "url" : "https:\/\/t.co\/SzI3vtal",
      "expanded_url" : "https:\/\/twitter.com\/#!\/qrush\/status\/159055769147420672",
      "display_url" : "twitter.com\/#!\/qrush\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "159811241039245313",
  "geo" : { },
  "id_str" : "159813214828367872",
  "in_reply_to_user_id" : 15108584,
  "text" : "@markwunsch I definitely predicted the Derpnado: https:\/\/t.co\/SzI3vtal",
  "id" : 159813214828367872,
  "in_reply_to_status_id" : 159811241039245313,
  "created_at" : "2012-01-19 01:43:34 +0000",
  "in_reply_to_screen_name" : "markwunsch",
  "in_reply_to_user_id_str" : "15108584",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Hartley",
      "screen_name" : "hillary",
      "indices" : [ 0, 8 ],
      "id_str" : "1821",
      "id" : 1821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159811525530484736",
  "geo" : { },
  "id_str" : "159812977242017793",
  "in_reply_to_user_id" : 1821,
  "text" : "@hillary There's much more hateful stuff I'm avoiding. This is just the tip of the iceberg.",
  "id" : 159812977242017793,
  "in_reply_to_status_id" : 159811525530484736,
  "created_at" : "2012-01-19 01:42:37 +0000",
  "in_reply_to_screen_name" : "hillary",
  "in_reply_to_user_id_str" : "1821",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 16, 24 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159809141249024001",
  "geo" : { },
  "id_str" : "159810104080871425",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda @mperham goldmine!",
  "id" : 159810104080871425,
  "in_reply_to_status_id" : 159809141249024001,
  "created_at" : "2012-01-19 01:31:12 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159806807433420800",
  "geo" : { },
  "id_str" : "159808142631378946",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham ehhh not so hot",
  "id" : 159808142631378946,
  "in_reply_to_status_id" : 159806807433420800,
  "created_at" : "2012-01-19 01:23:24 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159806807433420800",
  "geo" : { },
  "id_str" : "159807833771220993",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham oh genius",
  "id" : 159807833771220993,
  "in_reply_to_status_id" : 159806807433420800,
  "created_at" : "2012-01-19 01:22:11 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "conferenshish",
      "screen_name" : "tundal45",
      "indices" : [ 14, 23 ],
      "id_str" : "5573992",
      "id" : 5573992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159805275925254144",
  "geo" : { },
  "id_str" : "159805851694145537",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @tundal45 it's not a bot, it's just a lot of wading through the eternal derpness",
  "id" : 159805851694145537,
  "in_reply_to_status_id" : 159805275925254144,
  "created_at" : "2012-01-19 01:14:18 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Bodenner",
      "screen_name" : "ralphbod",
      "indices" : [ 0, 9 ],
      "id_str" : "89854263",
      "id" : 89854263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159804524654100480",
  "geo" : { },
  "id_str" : "159804929878405121",
  "in_reply_to_user_id" : 89854263,
  "text" : "@ralphbod thanks!",
  "id" : 159804929878405121,
  "in_reply_to_status_id" : 159804524654100480,
  "created_at" : "2012-01-19 01:10:38 +0000",
  "in_reply_to_screen_name" : "ralphbod",
  "in_reply_to_user_id_str" : "89854263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159800750401273856",
  "text" : "I think I've facepalmed today more than any day before.",
  "id" : 159800750401273856,
  "created_at" : "2012-01-19 00:54:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 43, 51 ],
      "id_str" : "2890961",
      "id" : 2890961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/UswA5nWR",
      "expanded_url" : "http:\/\/gizmo.do\/yaumSl",
      "display_url" : "gizmo.do\/yaumSl"
    } ]
  },
  "geo" : { },
  "id_str" : "159799889985937408",
  "text" : "Also, woo for the Buffalo reference! Also, @Gizmodo too: http:\/\/t.co\/UswA5nWR",
  "id" : 159799889985937408,
  "created_at" : "2012-01-19 00:50:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 12, 18 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/8OzlQ3cL",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/browbeat\/2012\/01\/18\/wikipedia_sopa_protest_the_funniest_confused_tweets.html",
      "display_url" : "slate.com\/blogs\/browbeat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159799764152627201",
  "text" : "Wow, I'm on @Slate. http:\/\/t.co\/8OzlQ3cL",
  "id" : 159799764152627201,
  "created_at" : "2012-01-19 00:50:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Wilcox",
      "screen_name" : "rwilcox",
      "indices" : [ 0, 8 ],
      "id_str" : "11766092",
      "id" : 11766092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159788811193290753",
  "geo" : { },
  "id_str" : "159789943101730818",
  "in_reply_to_user_id" : 11766092,
  "text" : "@rwilcox I'd donate to Wikipedia...sorry but I like selling software for money.",
  "id" : 159789943101730818,
  "in_reply_to_status_id" : 159788811193290753,
  "created_at" : "2012-01-19 00:11:05 +0000",
  "in_reply_to_screen_name" : "rwilcox",
  "in_reply_to_user_id_str" : "11766092",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159788038057238528",
  "text" : "I just can't handle the derpness on the racist comments. Even I can't sink that low.",
  "id" : 159788038057238528,
  "created_at" : "2012-01-19 00:03:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 51, 64 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159787453471920128",
  "text" : "I haven't really been retweeting racist things for @herpderpedia. There's much herp derping in that general direction.",
  "id" : 159787453471920128,
  "created_at" : "2012-01-19 00:01:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 0, 12 ],
      "id_str" : "248477732",
      "id" : 248477732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159783578346078208",
  "geo" : { },
  "id_str" : "159783849239388162",
  "in_reply_to_user_id" : 248477732,
  "text" : "@ecarlsen912 try the realtime feed, it's much, much worse.",
  "id" : 159783849239388162,
  "in_reply_to_status_id" : 159783578346078208,
  "created_at" : "2012-01-18 23:46:52 +0000",
  "in_reply_to_screen_name" : "ecarlsen912",
  "in_reply_to_user_id_str" : "248477732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159783210065199104",
  "geo" : { },
  "id_str" : "159783365120229377",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc Any links to help make one?",
  "id" : 159783365120229377,
  "in_reply_to_status_id" : 159783210065199104,
  "created_at" : "2012-01-18 23:44:57 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 61, 74 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159782855751380992",
  "text" : "I bet an ebook\/kindle pub of all of these hilariously stupid @herpderpedia tweets would sell wonderfully.",
  "id" : 159782855751380992,
  "created_at" : "2012-01-18 23:42:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel S. James",
      "screen_name" : "hypnobella",
      "indices" : [ 0, 11 ],
      "id_str" : "443260734",
      "id" : 443260734
    }, {
      "name" : "Snarklepony",
      "screen_name" : "whiskeypants",
      "indices" : [ 12, 25 ],
      "id_str" : "49811825",
      "id" : 49811825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159780245510164482",
  "geo" : { },
  "id_str" : "159780479384559617",
  "in_reply_to_user_id" : 443260734,
  "text" : "@hypnobella @whiskeypants yes, i basically find a search and retweet until my brain starts hurting from the dumb",
  "id" : 159780479384559617,
  "in_reply_to_status_id" : 159780245510164482,
  "created_at" : "2012-01-18 23:33:29 +0000",
  "in_reply_to_screen_name" : "hypnobella",
  "in_reply_to_user_id_str" : "443260734",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Lyon",
      "screen_name" : "mattly",
      "indices" : [ 0, 7 ],
      "id_str" : "1768041",
      "id" : 1768041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159763795277918208",
  "geo" : { },
  "id_str" : "159764085444059136",
  "in_reply_to_user_id" : 1768041,
  "text" : "@mattly curious in general, any reason why you haven't used a CC license for your photos?",
  "id" : 159764085444059136,
  "in_reply_to_status_id" : 159763795277918208,
  "created_at" : "2012-01-18 22:28:20 +0000",
  "in_reply_to_screen_name" : "mattly",
  "in_reply_to_user_id_str" : "1768041",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159763675929001984",
  "text" : "@joshuawentz \"force 10 derp\" lol!",
  "id" : 159763675929001984,
  "created_at" : "2012-01-18 22:26:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Herman",
      "screen_name" : "CLNS_Lee",
      "indices" : [ 0, 9 ],
      "id_str" : "94939603",
      "id" : 94939603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159746660430389248",
  "geo" : { },
  "id_str" : "159750159352336385",
  "in_reply_to_user_id" : 94939603,
  "text" : "@CLNS_Lee you're welcome!",
  "id" : 159750159352336385,
  "in_reply_to_status_id" : 159746660430389248,
  "created_at" : "2012-01-18 21:33:00 +0000",
  "in_reply_to_screen_name" : "CLNS_Lee",
  "in_reply_to_user_id_str" : "94939603",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kavassalis",
      "screen_name" : "sc_k",
      "indices" : [ 0, 5 ],
      "id_str" : "25749993",
      "id" : 25749993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159688590673199104",
  "geo" : { },
  "id_str" : "159688988431630337",
  "in_reply_to_user_id" : 25749993,
  "text" : "@sc_k Not a bot, very human :)",
  "id" : 159688988431630337,
  "in_reply_to_status_id" : 159688590673199104,
  "created_at" : "2012-01-18 17:29:56 +0000",
  "in_reply_to_screen_name" : "sc_k",
  "in_reply_to_user_id_str" : "25749993",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159686457894780928",
  "geo" : { },
  "id_str" : "159687998554910720",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik Pretty sure anyone using gems gets it.",
  "id" : 159687998554910720,
  "in_reply_to_status_id" : 159686457894780928,
  "created_at" : "2012-01-18 17:26:00 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159686265770475520",
  "geo" : { },
  "id_str" : "159686355029475329",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik no.",
  "id" : 159686355029475329,
  "in_reply_to_status_id" : 159686265770475520,
  "created_at" : "2012-01-18 17:19:28 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Angilly",
      "screen_name" : "angilly",
      "indices" : [ 0, 8 ],
      "id_str" : "16195791",
      "id" : 16195791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 130 ],
      "url" : "https:\/\/t.co\/SzI3vtal",
      "expanded_url" : "https:\/\/twitter.com\/#!\/qrush\/status\/159055769147420672",
      "display_url" : "twitter.com\/#!\/qrush\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "159683792708173824",
  "geo" : { },
  "id_str" : "159685110747238404",
  "in_reply_to_user_id" : 16195791,
  "text" : "@angilly Kind of struck me as I started looking at the tweets. Called it was going to happen a few days ago: https:\/\/t.co\/SzI3vtal",
  "id" : 159685110747238404,
  "in_reply_to_status_id" : 159683792708173824,
  "created_at" : "2012-01-18 17:14:31 +0000",
  "in_reply_to_screen_name" : "angilly",
  "in_reply_to_user_id_str" : "16195791",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159678413525884929",
  "text" : "RT @rjs: This blackout would be a good holiday. It's healthy for perspective. National \"remember how amazing the Internet is\" day.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "159678340226224128",
    "text" : "This blackout would be a good holiday. It's healthy for perspective. National \"remember how amazing the Internet is\" day.",
    "id" : 159678340226224128,
    "created_at" : "2012-01-18 16:47:37 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 159678413525884929,
  "created_at" : "2012-01-18 16:47:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Bodenner",
      "screen_name" : "ralphbod",
      "indices" : [ 0, 9 ],
      "id_str" : "89854263",
      "id" : 89854263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159534822723817472",
  "geo" : { },
  "id_str" : "159535344381984768",
  "in_reply_to_user_id" : 89854263,
  "text" : "@ralphbod hit the limit! need some sleep anyway :)",
  "id" : 159535344381984768,
  "in_reply_to_status_id" : 159534822723817472,
  "created_at" : "2012-01-18 07:19:24 +0000",
  "in_reply_to_screen_name" : "ralphbod",
  "in_reply_to_user_id_str" : "89854263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laughing Squid",
      "screen_name" : "LaughingSquid",
      "indices" : [ 31, 45 ],
      "id_str" : "2172",
      "id" : 2172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/bqYlUpPR",
      "expanded_url" : "http:\/\/laughingsquid.com\/herpderpedia-a-collection-of-tweets-by-people-freaking-out-about-wikipedias-sopa-pipa-blackout\/",
      "display_url" : "laughingsquid.com\/herpderpedia-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159534565965299712",
  "text" : "Well, this is my first time on @laughingsquid, fun! http:\/\/t.co\/bqYlUpPR",
  "id" : 159534565965299712,
  "created_at" : "2012-01-18 07:16:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u018E\u0245\u2C6F\u2C6D",
      "screen_name" : "davux",
      "indices" : [ 0, 6 ],
      "id_str" : "14261383",
      "id" : 14261383
    }, {
      "name" : "Barry Dorrans",
      "screen_name" : "blowdart",
      "indices" : [ 7, 16 ],
      "id_str" : "1847381",
      "id" : 1847381
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 84, 94 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159531792238514176",
  "geo" : { },
  "id_str" : "159533191089238016",
  "in_reply_to_user_id" : 14261383,
  "text" : "@davux @blowdart I actually had to leave the bedroom, afraid I was going to wake up @aquaranto from laughing too much.",
  "id" : 159533191089238016,
  "in_reply_to_status_id" : 159531792238514176,
  "created_at" : "2012-01-18 07:10:51 +0000",
  "in_reply_to_screen_name" : "davux",
  "in_reply_to_user_id_str" : "14261383",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 36, 49 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159532540116467712",
  "text" : "Alright, actually hit the limit for @herpderpedia now. Oh, the derpness I've seen today.",
  "id" : 159532540116467712,
  "created_at" : "2012-01-18 07:08:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159527771788414976",
  "text" : "I lost it on the \"soap Wikipedia\" search.",
  "id" : 159527771788414976,
  "created_at" : "2012-01-18 06:49:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 54, 67 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159525646505218050",
  "text" : "On that note, if you have suggestions for lulz worthy @herpderpedia tweets or searches, send them his way",
  "id" : 159525646505218050,
  "created_at" : "2012-01-18 06:40:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 32, 45 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159521128962981888",
  "text" : "I think I hit the API limit for @herpderpedia.",
  "id" : 159521128962981888,
  "created_at" : "2012-01-18 06:22:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laughing Squid",
      "screen_name" : "LaughingSquid",
      "indices" : [ 11, 25 ],
      "id_str" : "2172",
      "id" : 2172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159519656309293056",
  "text" : "Holy crap, @LaughingSquid tweeted! Thanks!!!",
  "id" : 159519656309293056,
  "created_at" : "2012-01-18 06:17:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 35, 48 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159519546854752256",
  "text" : "YESSS found the perfect avatar for @herpderpedia. I might be up all night now....",
  "id" : 159519546854752256,
  "created_at" : "2012-01-18 06:16:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 37, 50 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOPA",
      "indices" : [ 53, 58 ]
    }, {
      "text" : "PIPA",
      "indices" : [ 59, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159513222595092481",
  "text" : "This is actually therapeutic. Follow @herpderpedia ! #SOPA #PIPA",
  "id" : 159513222595092481,
  "created_at" : "2012-01-18 05:51:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 8, 21 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159511256083083264",
  "text" : "Started @herpderpedia to prove how smart we really all are.",
  "id" : 159511256083083264,
  "created_at" : "2012-01-18 05:43:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Bridget",
      "screen_name" : "dragonladyB17",
      "indices" : [ 11, 25 ],
      "id_str" : "158443907",
      "id" : 158443907
    }, {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 26, 41 ],
      "id_str" : "155998525",
      "id" : 155998525
    }, {
      "name" : "Allen Gaeddert",
      "screen_name" : "tidalknight",
      "indices" : [ 42, 54 ],
      "id_str" : "201510492",
      "id" : 201510492
    }, {
      "name" : "Con-Wan Kanobi",
      "screen_name" : "somethingconcon",
      "indices" : [ 55, 71 ],
      "id_str" : "37885397",
      "id" : 37885397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159500977018380288",
  "geo" : { },
  "id_str" : "159504712213868544",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @dragonladyB17 @1ofyourmeteors @tidalknight @somethingconcon thanks folks. Need to run more with the pup...",
  "id" : 159504712213868544,
  "in_reply_to_status_id" : 159500977018380288,
  "created_at" : "2012-01-18 05:17:41 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159501333521633280",
  "geo" : { },
  "id_str" : "159504265629540352",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic Geddy! And thanks, sorry about him being stupid",
  "id" : 159504265629540352,
  "in_reply_to_status_id" : 159501333521633280,
  "created_at" : "2012-01-18 05:15:55 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Letterle",
      "screen_name" : "mletterle",
      "indices" : [ 0, 10 ],
      "id_str" : "458173",
      "id" : 458173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159458229569593345",
  "geo" : { },
  "id_str" : "159458276856168448",
  "in_reply_to_user_id" : 458173,
  "text" : "@mletterle Yep!",
  "id" : 159458276856168448,
  "in_reply_to_status_id" : 159458229569593345,
  "created_at" : "2012-01-18 02:13:10 +0000",
  "in_reply_to_screen_name" : "mletterle",
  "in_reply_to_user_id_str" : "458173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/0zc0gQkZ",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/GEB\/comments\/oksrq\/lets_begin_details_inside\/",
      "display_url" : "reddit.com\/r\/GEB\/comments\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159457855957770241",
  "text" : "Started reading GEB. Who else is in? http:\/\/t.co\/0zc0gQkZ",
  "id" : 159457855957770241,
  "created_at" : "2012-01-18 02:11:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159402313218404352",
  "geo" : { },
  "id_str" : "159447130442956800",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic why do you pick the worst, grossest nights to do this?",
  "id" : 159447130442956800,
  "in_reply_to_status_id" : 159402313218404352,
  "created_at" : "2012-01-18 01:28:52 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159383433758515200",
  "geo" : { },
  "id_str" : "159383603774623744",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant sick flow",
  "id" : 159383603774623744,
  "in_reply_to_status_id" : 159383433758515200,
  "created_at" : "2012-01-17 21:16:27 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159383569863675904",
  "text" : "RT @bquarant: Rap lyrical dope rhyming flows are the only prose that go in my comment codes. Mic drop",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "159383433758515200",
    "text" : "Rap lyrical dope rhyming flows are the only prose that go in my comment codes. Mic drop",
    "id" : 159383433758515200,
    "created_at" : "2012-01-17 21:15:46 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 159383569863675904,
  "created_at" : "2012-01-17 21:16:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/30a0cRS2",
      "expanded_url" : "http:\/\/adage.com\/article\/news\/d-g-yuengling-son-america-s-largest-brewer\/232102\/",
      "display_url" : "adage.com\/article\/news\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159375564254359553",
  "text" : "Hell yeah Yuengling! http:\/\/t.co\/30a0cRS2",
  "id" : 159375564254359553,
  "created_at" : "2012-01-17 20:44:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    }, {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 10, 20 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159372526403854337",
  "geo" : { },
  "id_str" : "159373072581935104",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits @jankowski SHUT UP AND TAKE MY MONEY",
  "id" : 159373072581935104,
  "in_reply_to_status_id" : 159372526403854337,
  "created_at" : "2012-01-17 20:34:36 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159370909671636993",
  "text" : "Now accepting VC money for selling Bottled Moon Water. Just hand over your checks.",
  "id" : 159370909671636993,
  "created_at" : "2012-01-17 20:26:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/kzZ9Xugq",
      "expanded_url" : "http:\/\/boston.io\/",
      "display_url" : "boston.io"
    } ]
  },
  "in_reply_to_status_id_str" : "159300953655357440",
  "geo" : { },
  "id_str" : "159341755379097600",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant yes! http:\/\/t.co\/kzZ9Xugq",
  "id" : 159341755379097600,
  "in_reply_to_status_id" : 159300953655357440,
  "created_at" : "2012-01-17 18:30:09 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159321984637992961",
  "geo" : { },
  "id_str" : "159322086593142784",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh Yes, you have to run the python script differently but i'm sure you'll figure it out. check out the thread.",
  "id" : 159322086593142784,
  "in_reply_to_status_id" : 159321984637992961,
  "created_at" : "2012-01-17 17:12:00 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159321728554766336",
  "geo" : { },
  "id_str" : "159321879931396096",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh Followed the instructions in the powerline readme?",
  "id" : 159321879931396096,
  "in_reply_to_status_id" : 159321728554766336,
  "created_at" : "2012-01-17 17:11:10 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 11, 20 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159303547622666241",
  "geo" : { },
  "id_str" : "159308657539022849",
  "in_reply_to_user_id" : 372319943,
  "text" : "@A_R_Q_522 @bquarant JetBlue flights from BUF -&gt; BOS are under $50 this time of year dude",
  "id" : 159308657539022849,
  "in_reply_to_status_id" : 159303547622666241,
  "created_at" : "2012-01-17 16:18:38 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy J. Finucane",
      "screen_name" : "speljamr",
      "indices" : [ 0, 9 ],
      "id_str" : "2676261",
      "id" : 2676261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159152625772802050",
  "geo" : { },
  "id_str" : "159153488318832643",
  "in_reply_to_user_id" : 2676261,
  "text" : "@speljamr can you stop using this terrible service or don't include me in it?",
  "id" : 159153488318832643,
  "in_reply_to_status_id" : 159152625772802050,
  "created_at" : "2012-01-17 06:02:03 +0000",
  "in_reply_to_screen_name" : "speljamr",
  "in_reply_to_user_id_str" : "2676261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159146879702151171",
  "geo" : { },
  "id_str" : "159149227535118337",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel maybe it's a bad FM tuner",
  "id" : 159149227535118337,
  "in_reply_to_status_id" : 159146879702151171,
  "created_at" : "2012-01-17 05:45:07 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 38 ],
      "url" : "https:\/\/t.co\/h92Jir9k",
      "expanded_url" : "https:\/\/bitbucket.org\/iimarckus\/pokered\/src\/f7dc4c76e051\/text\/pokedex.asm",
      "display_url" : "bitbucket.org\/iimarckus\/poke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159129940837675008",
  "text" : "LOL the pokedex! https:\/\/t.co\/h92Jir9k",
  "id" : 159129940837675008,
  "created_at" : "2012-01-17 04:28:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 63 ],
      "url" : "https:\/\/t.co\/bH6DSMsT",
      "expanded_url" : "https:\/\/bitbucket.org\/iimarckus\/pokered\/src",
      "display_url" : "bitbucket.org\/iimarckus\/poke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159129696368476160",
  "text" : "This is epic. Disassembly of Pokemon Red: https:\/\/t.co\/bH6DSMsT",
  "id" : 159129696368476160,
  "created_at" : "2012-01-17 04:27:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gabegl\u00F6vesy\u00F6u",
      "screen_name" : "gabeglovesyou",
      "indices" : [ 0, 14 ],
      "id_str" : "14465929",
      "id" : 14465929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159120853525733376",
  "geo" : { },
  "id_str" : "159121359170052097",
  "in_reply_to_user_id" : 14465929,
  "text" : "@gabeglovesyou beautiful.",
  "id" : 159121359170052097,
  "in_reply_to_status_id" : 159120853525733376,
  "created_at" : "2012-01-17 03:54:23 +0000",
  "in_reply_to_screen_name" : "gabeglovesyou",
  "in_reply_to_user_id_str" : "14465929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159120657093894144",
  "text" : "Hey! You! What are some good examples of software documentation sites?",
  "id" : 159120657093894144,
  "created_at" : "2012-01-17 03:51:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "leon",
      "screen_name" : "rubybuddha",
      "indices" : [ 0, 11 ],
      "id_str" : "129873542",
      "id" : 129873542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159115800010178560",
  "geo" : { },
  "id_str" : "159117488209149953",
  "in_reply_to_user_id" : 129873542,
  "text" : "@rubybuddha awwwww yeah",
  "id" : 159117488209149953,
  "in_reply_to_status_id" : 159115800010178560,
  "created_at" : "2012-01-17 03:39:00 +0000",
  "in_reply_to_screen_name" : "rubybuddha",
  "in_reply_to_user_id_str" : "129873542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159109301321994240",
  "geo" : { },
  "id_str" : "159109797755621376",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove label your axes bro, no idea WTF they are",
  "id" : 159109797755621376,
  "in_reply_to_status_id" : 159109301321994240,
  "created_at" : "2012-01-17 03:08:26 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Pettit",
      "screen_name" : "nickrp",
      "indices" : [ 0, 7 ],
      "id_str" : "15349708",
      "id" : 15349708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159059347962474496",
  "geo" : { },
  "id_str" : "159059447430397952",
  "in_reply_to_user_id" : 15349708,
  "text" : "@nickrp Disney?",
  "id" : 159059447430397952,
  "in_reply_to_status_id" : 159059347962474496,
  "created_at" : "2012-01-16 23:48:22 +0000",
  "in_reply_to_screen_name" : "nickrp",
  "in_reply_to_user_id_str" : "15349708",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159058039008272386",
  "geo" : { },
  "id_str" : "159058213713608704",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack Rhombus!",
  "id" : 159058213713608704,
  "in_reply_to_status_id" : 159058039008272386,
  "created_at" : "2012-01-16 23:43:27 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159056815194243072",
  "geo" : { },
  "id_str" : "159057452946558976",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham Wow, isn't this heat and shelter and general availability of food for cheap great?",
  "id" : 159057452946558976,
  "in_reply_to_status_id" : 159056815194243072,
  "created_at" : "2012-01-16 23:40:26 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 0, 9 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/aiLFIi5W",
      "expanded_url" : "http:\/\/litanyagainstfear.com",
      "display_url" : "litanyagainstfear.com"
    } ]
  },
  "in_reply_to_status_id_str" : "159051860400021504",
  "geo" : { },
  "id_str" : "159056148920668162",
  "in_reply_to_user_id" : 16225196,
  "text" : "@shildner i also own http:\/\/t.co\/aiLFIi5W, so I might be biased.",
  "id" : 159056148920668162,
  "in_reply_to_status_id" : 159051860400021504,
  "created_at" : "2012-01-16 23:35:15 +0000",
  "in_reply_to_screen_name" : "shildner",
  "in_reply_to_user_id_str" : "16225196",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 0, 9 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159051860400021504",
  "geo" : { },
  "id_str" : "159055988866027520",
  "in_reply_to_user_id" : 16225196,
  "text" : "@shildner MUAD'DIB! MUAD'DIB!  MUAD'DIB!  MUAD'DIB!  MUAD'DIB!",
  "id" : 159055988866027520,
  "in_reply_to_status_id" : 159051860400021504,
  "created_at" : "2012-01-16 23:34:37 +0000",
  "in_reply_to_screen_name" : "shildner",
  "in_reply_to_user_id_str" : "16225196",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Helm",
      "screen_name" : "mattwdh",
      "indices" : [ 0, 8 ],
      "id_str" : "1104322178",
      "id" : 1104322178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159053901948125184",
  "geo" : { },
  "id_str" : "159055864035151872",
  "in_reply_to_user_id" : 14166206,
  "text" : "@mattwdh i'm just glad people are commenting on other things than pizza ;)",
  "id" : 159055864035151872,
  "in_reply_to_status_id" : 159053901948125184,
  "created_at" : "2012-01-16 23:34:07 +0000",
  "in_reply_to_screen_name" : "matthelm",
  "in_reply_to_user_id_str" : "14166206",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159055769147420672",
  "text" : "I'm really looking forward to all of the really confused Facebook and Twitter posts about Wikipedia being down.",
  "id" : 159055769147420672,
  "created_at" : "2012-01-16 23:33:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hamill",
      "screen_name" : "benhamill",
      "indices" : [ 0, 10 ],
      "id_str" : "15847711",
      "id" : 15847711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158803670346121216",
  "geo" : { },
  "id_str" : "158947000119861248",
  "in_reply_to_user_id" : 15847711,
  "text" : "@benhamill hell yeah, it can evolve over time. TBH i'd start with just a one pager of the entire changelog (usually entries are really tiny)",
  "id" : 158947000119861248,
  "in_reply_to_status_id" : 158803670346121216,
  "created_at" : "2012-01-16 16:21:32 +0000",
  "in_reply_to_screen_name" : "benhamill",
  "in_reply_to_user_id_str" : "15847711",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158764992236232704",
  "text" : "Super Troopers was released in 2001. Just soak that in a bit.",
  "id" : 158764992236232704,
  "created_at" : "2012-01-16 04:18:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wade Wegner",
      "screen_name" : "WadeWegner",
      "indices" : [ 0, 11 ],
      "id_str" : "14163697",
      "id" : 14163697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158591463666630656",
  "geo" : { },
  "id_str" : "158733692674650112",
  "in_reply_to_user_id" : 14163697,
  "text" : "@WadeWegner i haven't used linux in a while (2009ish?), but I'd go with Ubuntu.",
  "id" : 158733692674650112,
  "in_reply_to_status_id" : 158591463666630656,
  "created_at" : "2012-01-16 02:13:56 +0000",
  "in_reply_to_screen_name" : "WadeWegner",
  "in_reply_to_user_id_str" : "14163697",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Letters of Note",
      "screen_name" : "LettersOfNote",
      "indices" : [ 0, 14 ],
      "id_str" : "72831048",
      "id" : 72831048
    }, {
      "name" : "Assaf",
      "screen_name" : "assaf",
      "indices" : [ 15, 21 ],
      "id_str" : "2367111",
      "id" : 2367111
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158535989877411841",
  "geo" : { },
  "id_str" : "158678791437303808",
  "in_reply_to_user_id" : 72831048,
  "text" : "@LettersOfNote @assaf I love how there's a matching sign on the other side",
  "id" : 158678791437303808,
  "in_reply_to_status_id" : 158535989877411841,
  "created_at" : "2012-01-15 22:35:46 +0000",
  "in_reply_to_screen_name" : "LettersOfNote",
  "in_reply_to_user_id_str" : "72831048",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/4J0NwAiO",
      "expanded_url" : "http:\/\/path.com\/p\/2EWO9A",
      "display_url" : "path.com\/p\/2EWO9A"
    } ]
  },
  "geo" : { },
  "id_str" : "158569118965055488",
  "text" : "Snow! (at Elmwood Village) [pic] \u2014 http:\/\/t.co\/4J0NwAiO",
  "id" : 158569118965055488,
  "created_at" : "2012-01-15 15:19:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158409117168451586",
  "geo" : { },
  "id_str" : "158448525758308353",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit want me to ship you a DVD?",
  "id" : 158448525758308353,
  "in_reply_to_status_id" : 158409117168451586,
  "created_at" : "2012-01-15 07:20:47 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158423808603197440",
  "geo" : { },
  "id_str" : "158448450025959424",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin definitely on vacation, sorry dude.",
  "id" : 158448450025959424,
  "in_reply_to_status_id" : 158423808603197440,
  "created_at" : "2012-01-15 07:20:28 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158399587428728834",
  "geo" : { },
  "id_str" : "158399952396099585",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 both, sure!",
  "id" : 158399952396099585,
  "in_reply_to_status_id" : 158399587428728834,
  "created_at" : "2012-01-15 04:07:46 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158399918598402048",
  "text" : "I bought TF2 in 2007, still playing it every few months. Does anyone who bought it then still play?",
  "id" : 158399918598402048,
  "created_at" : "2012-01-15 04:07:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Chen",
      "screen_name" : "jcsalterego",
      "indices" : [ 0, 12 ],
      "id_str" : "14343561",
      "id" : 14343561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158394504108453888",
  "geo" : { },
  "id_str" : "158395623207473152",
  "in_reply_to_user_id" : 14343561,
  "text" : "@jcsalterego I've heard legends about the shack......",
  "id" : 158395623207473152,
  "in_reply_to_status_id" : 158394504108453888,
  "created_at" : "2012-01-15 03:50:34 +0000",
  "in_reply_to_screen_name" : "jcsalterego",
  "in_reply_to_user_id_str" : "14343561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adolfo Builes",
      "screen_name" : "abuiles",
      "indices" : [ 0, 8 ],
      "id_str" : "13977542",
      "id" : 13977542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158393123947548673",
  "geo" : { },
  "id_str" : "158395570610913281",
  "in_reply_to_user_id" : 13977542,
  "text" : "@abuiles Now I want pizza. Thanks.",
  "id" : 158395570610913281,
  "in_reply_to_status_id" : 158393123947548673,
  "created_at" : "2012-01-15 03:50:21 +0000",
  "in_reply_to_screen_name" : "abuiles",
  "in_reply_to_user_id_str" : "13977542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kareem Kouddous",
      "screen_name" : "kareemk",
      "indices" : [ 0, 8 ],
      "id_str" : "8859412",
      "id" : 8859412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158393016346877952",
  "geo" : { },
  "id_str" : "158395488645808128",
  "in_reply_to_user_id" : 8859412,
  "text" : "@kareemk ooh will check those out. Up for anything.",
  "id" : 158395488645808128,
  "in_reply_to_status_id" : 158393016346877952,
  "created_at" : "2012-01-15 03:50:01 +0000",
  "in_reply_to_screen_name" : "kareemk",
  "in_reply_to_user_id_str" : "8859412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Czarnecki",
      "screen_name" : "CzarneckiD",
      "indices" : [ 0, 11 ],
      "id_str" : "13393",
      "id" : 13393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158393307754541056",
  "geo" : { },
  "id_str" : "158395076341530625",
  "in_reply_to_user_id" : 13393,
  "text" : "@CzarneckiD how is that considered food? so tiny.",
  "id" : 158395076341530625,
  "in_reply_to_status_id" : 158393307754541056,
  "created_at" : "2012-01-15 03:48:23 +0000",
  "in_reply_to_screen_name" : "CzarneckiD",
  "in_reply_to_user_id_str" : "13393",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 0, 9 ],
      "id_str" : "729936824",
      "id" : 729936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158392145319960576",
  "geo" : { },
  "id_str" : "158392439990779904",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgimenez buy a boathouse!!",
  "id" : 158392439990779904,
  "in_reply_to_status_id" : 158392145319960576,
  "created_at" : "2012-01-15 03:37:55 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 7, 17 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158392322055356416",
  "text" : "Hey so @aquaranto and I are hitting NYC next weekend. Any suggestions for food\/awesome things to do? We have a few ideas, would love more.",
  "id" : 158392322055356416,
  "created_at" : "2012-01-15 03:37:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158389780692992000",
  "geo" : { },
  "id_str" : "158389943067099136",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella oh god yes. I've been jonesing to write a roguelike for a long time that's more accessible than NetHack.",
  "id" : 158389943067099136,
  "in_reply_to_status_id" : 158389780692992000,
  "created_at" : "2012-01-15 03:27:59 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158384766910078976",
  "geo" : { },
  "id_str" : "158385783781335041",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss I think you're skipping over...a lot :)",
  "id" : 158385783781335041,
  "in_reply_to_status_id" : 158384766910078976,
  "created_at" : "2012-01-15 03:11:28 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158385249703837697",
  "geo" : { },
  "id_str" : "158385550162788352",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv this reminds me of \"The Nintendo\"",
  "id" : 158385550162788352,
  "in_reply_to_status_id" : 158385249703837697,
  "created_at" : "2012-01-15 03:10:32 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158383245220782081",
  "geo" : { },
  "id_str" : "158384776133345280",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella yeah I was checking out cocos2d, seems nice...but I can't imagine myself in XCode for longer than 20 minutes at a time.",
  "id" : 158384776133345280,
  "in_reply_to_status_id" : 158383245220782081,
  "created_at" : "2012-01-15 03:07:27 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158379210547789825",
  "text" : "My problem with starting to learn how to write games: It feels way too much like work to write them!",
  "id" : 158379210547789825,
  "created_at" : "2012-01-15 02:45:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 72 ],
      "url" : "https:\/\/t.co\/vrHg5Ugq",
      "expanded_url" : "https:\/\/github.com\/search?type=Code&language=JavaScript&q=.lenght&repo=&langOverride=&x=0&y=0&start_value=1",
      "display_url" : "github.com\/search?type=Co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "158358063273873408",
  "text" : "This is awesome, searching for \"lenght\" on GitHub: https:\/\/t.co\/vrHg5Ugq",
  "id" : 158358063273873408,
  "created_at" : "2012-01-15 01:21:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 21, 31 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158347149292212225",
  "text" : "Back in Buffalo with @aquaranto. #codemash was awesome!",
  "id" : 158347149292212225,
  "created_at" : "2012-01-15 00:37:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brooke Kuhlmann",
      "screen_name" : "bkuhlmann",
      "indices" : [ 0, 10 ],
      "id_str" : "1060361",
      "id" : 1060361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158237360142827520",
  "geo" : { },
  "id_str" : "158346965271318528",
  "in_reply_to_user_id" : 1060361,
  "text" : "@bkuhlmann I don't think it's easy now esp with so many different platforms and gems. Travis-ci is changing the game though.",
  "id" : 158346965271318528,
  "in_reply_to_status_id" : 158237360142827520,
  "created_at" : "2012-01-15 00:37:13 +0000",
  "in_reply_to_screen_name" : "bkuhlmann",
  "in_reply_to_user_id_str" : "1060361",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexis Ohanian",
      "screen_name" : "kn0thing",
      "indices" : [ 0, 9 ],
      "id_str" : "103352755",
      "id" : 103352755
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 36, 43 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 31 ],
      "url" : "https:\/\/t.co\/vRERlNEG",
      "expanded_url" : "https:\/\/www.apprentice.io\/",
      "display_url" : "apprentice.io"
    } ]
  },
  "in_reply_to_status_id_str" : "158065106243170304",
  "geo" : { },
  "id_str" : "158071685847851009",
  "in_reply_to_user_id" : 811350,
  "text" : "@kn0thing https:\/\/t.co\/vRERlNEG \/cc @Croaky",
  "id" : 158071685847851009,
  "in_reply_to_status_id" : 158065106243170304,
  "created_at" : "2012-01-14 06:23:21 +0000",
  "in_reply_to_screen_name" : "alexisohanian",
  "in_reply_to_user_id_str" : "811350",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klondike Gold",
      "screen_name" : "Klondike",
      "indices" : [ 0, 9 ],
      "id_str" : "298070410",
      "id" : 298070410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157959264307130368",
  "geo" : { },
  "id_str" : "157959604733624320",
  "in_reply_to_user_id" : 5232171,
  "text" : "@Klondike ogre mages!!!",
  "id" : 157959604733624320,
  "in_reply_to_status_id" : 157959264307130368,
  "created_at" : "2012-01-13 22:57:59 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157926798250885120",
  "geo" : { },
  "id_str" : "157927809409490944",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh truth.",
  "id" : 157927809409490944,
  "in_reply_to_status_id" : 157926798250885120,
  "created_at" : "2012-01-13 20:51:38 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 16, 24 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/s71tCN7G",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=3462188",
      "display_url" : "news.ycombinator.com\/item?id=3462188"
    } ]
  },
  "geo" : { },
  "id_str" : "157926056786018305",
  "text" : "Absolutely love @patio11's response to this HN troll. Thanks for the backup. http:\/\/t.co\/s71tCN7G",
  "id" : 157926056786018305,
  "created_at" : "2012-01-13 20:44:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Hariharan",
      "screen_name" : "hkarthik",
      "indices" : [ 0, 9 ],
      "id_str" : "4514261",
      "id" : 4514261
    }, {
      "name" : "Joshua Flanagan",
      "screen_name" : "jflanagan",
      "indices" : [ 10, 20 ],
      "id_str" : "14440037",
      "id" : 14440037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157906556254552064",
  "geo" : { },
  "id_str" : "157925270786031616",
  "in_reply_to_user_id" : 4514261,
  "text" : "@hkarthik @jflanagan yes definitely state_machine. Perf is the last thing to worry about.",
  "id" : 157925270786031616,
  "in_reply_to_status_id" : 157906556254552064,
  "created_at" : "2012-01-13 20:41:33 +0000",
  "in_reply_to_screen_name" : "hkarthik",
  "in_reply_to_user_id_str" : "4514261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157918465875902464",
  "geo" : { },
  "id_str" : "157919605929680896",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie i almost thought this was a spam tweet.",
  "id" : 157919605929680896,
  "in_reply_to_status_id" : 157918465875902464,
  "created_at" : "2012-01-13 20:19:02 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 40, 50 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/o0shDU1v",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3077-kicking-the-tires-my-trial-month",
      "display_url" : "37signals.com\/svn\/posts\/3077\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "157911931641012224",
  "text" : "Wrote up a post about my trial month at @37signals: http:\/\/t.co\/o0shDU1v",
  "id" : 157911931641012224,
  "created_at" : "2012-01-13 19:48:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157895951397294080",
  "geo" : { },
  "id_str" : "157897078125760513",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant french press A++++",
  "id" : 157897078125760513,
  "in_reply_to_status_id" : 157895951397294080,
  "created_at" : "2012-01-13 18:49:31 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Flanagan",
      "screen_name" : "jflanagan",
      "indices" : [ 0, 10 ],
      "id_str" : "14440037",
      "id" : 14440037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157863724684808193",
  "geo" : { },
  "id_str" : "157864945701240833",
  "in_reply_to_user_id" : 14440037,
  "text" : "@jflanagan i haven't dealt with a \"magic integer\" in the database in a long, long time. sounds like a bad db design decision.",
  "id" : 157864945701240833,
  "in_reply_to_status_id" : 157863724684808193,
  "created_at" : "2012-01-13 16:41:50 +0000",
  "in_reply_to_screen_name" : "jflanagan",
  "in_reply_to_user_id_str" : "14440037",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157861530795393024",
  "geo" : { },
  "id_str" : "157863574839107584",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape RESPONSE DEFENDING FANBOYISM. RETORT ON HAVING OPINIONS. PASTING OF IMAGE WITH OVERUSED MEME. SOFT CHUCKLING ALONE AT MONITOR.",
  "id" : 157863574839107584,
  "in_reply_to_status_id" : 157861530795393024,
  "created_at" : "2012-01-13 16:36:23 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Flanagan",
      "screen_name" : "jflanagan",
      "indices" : [ 0, 10 ],
      "id_str" : "14440037",
      "id" : 14440037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157861590471942145",
  "geo" : { },
  "id_str" : "157862999242190849",
  "in_reply_to_user_id" : 14440037,
  "text" : "@jflanagan usually symbols do the job with this. depends on the code, show me some and I can comment on it :)",
  "id" : 157862999242190849,
  "in_reply_to_status_id" : 157861590471942145,
  "created_at" : "2012-01-13 16:34:06 +0000",
  "in_reply_to_screen_name" : "jflanagan",
  "in_reply_to_user_id_str" : "14440037",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157860956309950464",
  "text" : "You know what I've never missed in Ruby from Java\/C#? Enums. Not once, ever.",
  "id" : 157860956309950464,
  "created_at" : "2012-01-13 16:25:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Federico Holgado",
      "screen_name" : "fholgado",
      "indices" : [ 0, 9 ],
      "id_str" : "17629838",
      "id" : 17629838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157847785432035328",
  "geo" : { },
  "id_str" : "157850923702562816",
  "in_reply_to_user_id" : 17629838,
  "text" : "@fholgado it's backslash THEN space, you have that reversed",
  "id" : 157850923702562816,
  "in_reply_to_status_id" : 157847785432035328,
  "created_at" : "2012-01-13 15:46:07 +0000",
  "in_reply_to_screen_name" : "fholgado",
  "in_reply_to_user_id_str" : "17629838",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 13, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157844961688174592",
  "text" : "If anything, #codemash iOS talks have reminded me that platform specific development is the same crap & problems on different platforms.",
  "id" : 157844961688174592,
  "created_at" : "2012-01-13 15:22:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/8CoB4Sur",
      "expanded_url" : "http:\/\/is.gd\/0maElG",
      "display_url" : "is.gd\/0maElG"
    } ]
  },
  "geo" : { },
  "id_str" : "157837076849631232",
  "text" : "Definitely was not aware you could test iOS apps. Wonder if anyone actually *does* though. http:\/\/t.co\/8CoB4Sur #codemash",
  "id" : 157837076849631232,
  "created_at" : "2012-01-13 14:51:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/yktjDGd7",
      "expanded_url" : "http:\/\/code52.org\/",
      "display_url" : "code52.org"
    } ]
  },
  "geo" : { },
  "id_str" : "157833801400193024",
  "text" : "This is great, but I'd love to see it extended beyond Windows and .NET. http:\/\/t.co\/yktjDGd7",
  "id" : 157833801400193024,
  "created_at" : "2012-01-13 14:38:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF00FF",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157714607602012161",
  "text" : "Changed my Hacker News banner color to #FF00FF. Makes reading the comments much more bearable.",
  "id" : 157714607602012161,
  "created_at" : "2012-01-13 06:44:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/khc85cQQ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=F2WKhPxpc0k",
      "display_url" : "youtube.com\/watch?v=F2WKhP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "157711944642592768",
  "text" : "Current 10 hour status: http:\/\/t.co\/khc85cQQ",
  "id" : 157711944642592768,
  "created_at" : "2012-01-13 06:33:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157610898196930560",
  "geo" : { },
  "id_str" : "157700671355895808",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt let's do it. it'll be like the XM of conferences.",
  "id" : 157700671355895808,
  "in_reply_to_status_id" : 157610898196930560,
  "created_at" : "2012-01-13 05:49:04 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157666717630349312",
  "geo" : { },
  "id_str" : "157675537039491074",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin YES.\n\nNo.",
  "id" : 157675537039491074,
  "in_reply_to_status_id" : 157666717630349312,
  "created_at" : "2012-01-13 04:09:12 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/5Hy84AzJ",
      "expanded_url" : "http:\/\/path.com\/p\/40sZCh",
      "display_url" : "path.com\/p\/40sZCh"
    } ]
  },
  "geo" : { },
  "id_str" : "157666458799833088",
  "text" : "Playing Quarriors at #codemash, liking it muchly! (with Amanda at CodeMash 2.0.1.2) [pic] \u2014 http:\/\/t.co\/5Hy84AzJ",
  "id" : 157666458799833088,
  "created_at" : "2012-01-13 03:33:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Josh",
      "screen_name" : "joshkalderimis",
      "indices" : [ 0, 15 ],
      "id_str" : "628398860",
      "id" : 628398860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157636811500437504",
  "geo" : { },
  "id_str" : "157642818062532608",
  "in_reply_to_user_id" : 16601619,
  "text" : "@joshkalderimis not sure if it makes much of a difference. we need some patches to start tracking user agents.",
  "id" : 157642818062532608,
  "in_reply_to_status_id" : 157636811500437504,
  "created_at" : "2012-01-13 01:59:11 +0000",
  "in_reply_to_screen_name" : "j2h",
  "in_reply_to_user_id_str" : "16601619",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "codemash",
      "screen_name" : "codemash",
      "indices" : [ 48, 57 ],
      "id_str" : "7469772",
      "id" : 7469772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/hoAU7LEN",
      "expanded_url" : "http:\/\/groups.google.com\/group\/codemash\/browse_thread\/thread\/f58c5e37eea8e334",
      "display_url" : "groups.google.com\/group\/codemash\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "157574932606369793",
  "text" : "Some seriously stupid drama is about to hit the @CodeMash list in 3...2...1... http:\/\/t.co\/hoAU7LEN",
  "id" : 157574932606369793,
  "created_at" : "2012-01-12 21:29:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Len Smith",
      "screen_name" : "ignu",
      "indices" : [ 0, 5 ],
      "id_str" : "6649832",
      "id" : 6649832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157565232062005248",
  "geo" : { },
  "id_str" : "157565528284725248",
  "in_reply_to_user_id" : 6649832,
  "text" : "@ignu is your avatar...real?",
  "id" : 157565528284725248,
  "in_reply_to_status_id" : 157565232062005248,
  "created_at" : "2012-01-12 20:52:04 +0000",
  "in_reply_to_screen_name" : "ignu",
  "in_reply_to_user_id_str" : "6649832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 52, 61 ],
      "id_str" : "9267332",
      "id" : 9267332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/8EDS1oPn",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=3457890",
      "display_url" : "news.ycombinator.com\/item?id=3457890"
    } ]
  },
  "geo" : { },
  "id_str" : "157564821481586688",
  "text" : "Upvotes wanted! http:\/\/t.co\/8EDS1oPn also, props to @rtomayko, rocco is awesome.",
  "id" : 157564821481586688,
  "created_at" : "2012-01-12 20:49:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/hc4ZQzAM",
      "expanded_url" : "http:\/\/quaran.to\/m\/",
      "display_url" : "quaran.to\/m\/"
    } ]
  },
  "geo" : { },
  "id_str" : "157564045401133056",
  "text" : "Let's do this! Screw blog posts, I'd rather write documentation. Introducing m 1.0.0, a better test\/unit test runner. http:\/\/t.co\/hc4ZQzAM",
  "id" : 157564045401133056,
  "created_at" : "2012-01-12 20:46:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Roche",
      "screen_name" : "tedroche",
      "indices" : [ 0, 9 ],
      "id_str" : "14353681",
      "id" : 14353681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157561036382277632",
  "geo" : { },
  "id_str" : "157563242531659777",
  "in_reply_to_user_id" : 14353681,
  "text" : "@tedroche wonderful. this could be a whole lightning talk. i did my research in the wrong places, clearly.",
  "id" : 157563242531659777,
  "in_reply_to_status_id" : 157561036382277632,
  "created_at" : "2012-01-12 20:42:59 +0000",
  "in_reply_to_screen_name" : "tedroche",
  "in_reply_to_user_id_str" : "14353681",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 55, 66 ],
      "id_str" : "9070452",
      "id" : 9070452
    }, {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 67, 70 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157562914822299649",
  "text" : "Haha, 3 Ruby presentations, 3 references to Knuth. \/cc @jimweirich @j3",
  "id" : 157562914822299649,
  "created_at" : "2012-01-12 20:41:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/wchAeRpD",
      "expanded_url" : "http:\/\/speakerdeck.com\/u\/qrush\/p\/lapidary-the-art-of-gemcutting",
      "display_url" : "speakerdeck.com\/u\/qrush\/p\/lapi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "157557387174215680",
  "text" : "Some insane perspective: when I gave this talk, there were only 10 million gem downloads. Today, 430M. Wow. http:\/\/t.co\/wchAeRpD",
  "id" : 157557387174215680,
  "created_at" : "2012-01-12 20:19:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Venkat Kadiam",
      "screen_name" : "kadiamv",
      "indices" : [ 0, 8 ],
      "id_str" : "190299479",
      "id" : 190299479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157549288560406528",
  "geo" : { },
  "id_str" : "157552766913486852",
  "in_reply_to_user_id" : 190299479,
  "text" : "@kadiamv thanks for coming!",
  "id" : 157552766913486852,
  "in_reply_to_status_id" : 157549288560406528,
  "created_at" : "2012-01-12 20:01:21 +0000",
  "in_reply_to_screen_name" : "kadiamv",
  "in_reply_to_user_id_str" : "190299479",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Vida",
      "screen_name" : "andrewvida",
      "indices" : [ 0, 11 ],
      "id_str" : "17205028",
      "id" : 17205028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157552132898308096",
  "geo" : { },
  "id_str" : "157552720776138752",
  "in_reply_to_user_id" : 17205028,
  "text" : "@andrewvida awesome! let me know once you've published it!",
  "id" : 157552720776138752,
  "in_reply_to_status_id" : 157552132898308096,
  "created_at" : "2012-01-12 20:01:10 +0000",
  "in_reply_to_screen_name" : "andrewvida",
  "in_reply_to_user_id_str" : "17205028",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Cummings",
      "screen_name" : "rustoliumcoder",
      "indices" : [ 0, 15 ],
      "id_str" : "457725492",
      "id" : 457725492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157547541238517760",
  "geo" : { },
  "id_str" : "157548393105850368",
  "in_reply_to_user_id" : 457725492,
  "text" : "@rustoliumcoder thanks!",
  "id" : 157548393105850368,
  "in_reply_to_status_id" : 157547541238517760,
  "created_at" : "2012-01-12 19:43:58 +0000",
  "in_reply_to_screen_name" : "rustoliumcoder",
  "in_reply_to_user_id_str" : "457725492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speaker Deck",
      "screen_name" : "speakerdeck",
      "indices" : [ 15, 27 ],
      "id_str" : "144190968",
      "id" : 144190968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/SghX5IF6",
      "expanded_url" : "http:\/\/speakerdeck.com\/u\/qrush",
      "display_url" : "speakerdeck.com\/u\/qrush"
    } ]
  },
  "geo" : { },
  "id_str" : "157546682492534784",
  "text" : "I kind of wish @speakerdeck would show .gifs, but oh well. Just uploaded all my presentations there, so slick! http:\/\/t.co\/SghX5IF6",
  "id" : 157546682492534784,
  "created_at" : "2012-01-12 19:37:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CodeMash",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/tx7VeKDl",
      "expanded_url" : "http:\/\/speakerdeck.com\/u\/qrush\/p\/becoming-a-ruby-gemcutter",
      "display_url" : "speakerdeck.com\/u\/qrush\/p\/beco\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "157546334453383168",
  "text" : "Here's the slides for my #CodeMash talk, Becoming a Ruby Gemcutter! http:\/\/t.co\/tx7VeKDl Thanks for coming, folks.",
  "id" : 157546334453383168,
  "created_at" : "2012-01-12 19:35:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Glover",
      "screen_name" : "aglover",
      "indices" : [ 3, 11 ],
      "id_str" : "15520326",
      "id" : 15520326
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 29, 35 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CodeMash",
      "indices" : [ 98, 107 ]
    }, {
      "text" : "CI",
      "indices" : [ 108, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/7p16alHv",
      "expanded_url" : "http:\/\/bit.ly\/xaojSL",
      "display_url" : "bit.ly\/xaojSL"
    } ]
  },
  "geo" : { },
  "id_str" : "157533228100632577",
  "text" : "RT @aglover: Handy! Free CI! @qrush showed Travis CI (http:\/\/t.co\/7p16alHv) in his Gemcutter talk #CodeMash #CI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 16, 22 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CodeMash",
        "indices" : [ 85, 94 ]
      }, {
        "text" : "CI",
        "indices" : [ 95, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/7p16alHv",
        "expanded_url" : "http:\/\/bit.ly\/xaojSL",
        "display_url" : "bit.ly\/xaojSL"
      } ]
    },
    "geo" : { },
    "id_str" : "157521253979262976",
    "text" : "Handy! Free CI! @qrush showed Travis CI (http:\/\/t.co\/7p16alHv) in his Gemcutter talk #CodeMash #CI",
    "id" : 157521253979262976,
    "created_at" : "2012-01-12 17:56:08 +0000",
    "user" : {
      "name" : "Andrew Glover",
      "screen_name" : "aglover",
      "protected" : false,
      "id_str" : "15520326",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414308260\/IMG_9951_normal.jpg",
      "id" : 15520326,
      "verified" : false
    }
  },
  "id" : 157533228100632577,
  "created_at" : "2012-01-12 18:43:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Yoder",
      "screen_name" : "doug_yoder",
      "indices" : [ 0, 11 ],
      "id_str" : "14680570",
      "id" : 14680570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157492139004149761",
  "geo" : { },
  "id_str" : "157533173255913472",
  "in_reply_to_user_id" : 14680570,
  "text" : "@doug_yoder woot! :) hope you had fun.",
  "id" : 157533173255913472,
  "in_reply_to_status_id" : 157492139004149761,
  "created_at" : "2012-01-12 18:43:29 +0000",
  "in_reply_to_screen_name" : "doug_yoder",
  "in_reply_to_user_id_str" : "14680570",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Letterle",
      "screen_name" : "mletterle",
      "indices" : [ 0, 10 ],
      "id_str" : "458173",
      "id" : 458173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157492951059136512",
  "geo" : { },
  "id_str" : "157533116624420864",
  "in_reply_to_user_id" : 458173,
  "text" : "@mletterle why havent I said hi yet!!? Need to find you.",
  "id" : 157533116624420864,
  "in_reply_to_status_id" : 157492951059136512,
  "created_at" : "2012-01-12 18:43:16 +0000",
  "in_reply_to_screen_name" : "mletterle",
  "in_reply_to_user_id_str" : "458173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "_Zach McArtor",
      "screen_name" : "zmcartor",
      "indices" : [ 0, 9 ],
      "id_str" : "19977631",
      "id" : 19977631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157530006304727040",
  "geo" : { },
  "id_str" : "157530932130222080",
  "in_reply_to_user_id" : 19977631,
  "text" : "@zmcartor awesome! thanks for coming!",
  "id" : 157530932130222080,
  "in_reply_to_status_id" : 157530006304727040,
  "created_at" : "2012-01-12 18:34:35 +0000",
  "in_reply_to_screen_name" : "zmcartor",
  "in_reply_to_user_id_str" : "19977631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 13, 24 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Mark W. Schumann",
      "screen_name" : "MarkWSchumann",
      "indices" : [ 25, 39 ],
      "id_str" : "15704860",
      "id" : 15704860
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 77, 87 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157522465256521730",
  "text" : "@juliepagano @ashedryden @markwschumann glad we got this cleared up. I think @aquaranto (who was in the talk) would have yelled otherwise :)",
  "id" : 157522465256521730,
  "created_at" : "2012-01-12 18:00:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 65, 76 ],
      "id_str" : "4243",
      "id" : 4243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157521454618001408",
  "text" : "No github auth or SSL on signin for http:\/\/speakerdeckcom :( \/cc @jnunemaker",
  "id" : 157521454618001408,
  "created_at" : "2012-01-12 17:56:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gabegl\u00F6vesy\u00F6u",
      "screen_name" : "gabeglovesyou",
      "indices" : [ 0, 14 ],
      "id_str" : "14465929",
      "id" : 14465929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157511566437261313",
  "geo" : { },
  "id_str" : "157519965648470016",
  "in_reply_to_user_id" : 14465929,
  "text" : "@gabeglovesyou joking, but it was lulzworthy.",
  "id" : 157519965648470016,
  "in_reply_to_status_id" : 157511566437261313,
  "created_at" : "2012-01-12 17:51:01 +0000",
  "in_reply_to_screen_name" : "gabeglovesyou",
  "in_reply_to_user_id_str" : "14465929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    }, {
      "name" : "Scott Klein",
      "screen_name" : "kleinmatic",
      "indices" : [ 12, 23 ],
      "id_str" : "6183492",
      "id" : 6183492
    }, {
      "name" : "Jeremy Ashkenas",
      "screen_name" : "jashkenas",
      "indices" : [ 24, 34 ],
      "id_str" : "123323498",
      "id" : 123323498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157510814654398464",
  "geo" : { },
  "id_str" : "157519921423716353",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin @kleinmatic @jashkenas gem install bundler --pre, it's much faster.",
  "id" : 157519921423716353,
  "in_reply_to_status_id" : 157510814654398464,
  "created_at" : "2012-01-12 17:50:50 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 12, 24 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Mark W. Schumann",
      "screen_name" : "MarkWSchumann",
      "indices" : [ 25, 39 ],
      "id_str" : "15704860",
      "id" : 15704860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157500500290453504",
  "geo" : { },
  "id_str" : "157519726896095232",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @juliepagano @MarkWSchumann honestly was just meant as a harmless joke to wrap up that section. didn't mean to offend.",
  "id" : 157519726896095232,
  "in_reply_to_status_id" : 157500500290453504,
  "created_at" : "2012-01-12 17:50:04 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 12, 24 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Mark W. Schumann",
      "screen_name" : "MarkWSchumann",
      "indices" : [ 25, 39 ],
      "id_str" : "15704860",
      "id" : 15704860
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/157519494716194816\/photo\/1",
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/EStNWKvU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ai-fJVhCAAAIoZk.jpg",
      "id_str" : "157519494724583424",
      "id" : 157519494724583424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ai-fJVhCAAAIoZk.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EStNWKvU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157500500290453504",
  "geo" : { },
  "id_str" : "157519494716194816",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @juliepagano @MarkWSchumann hey folks, here's the slide. It was a wrapup to \"why make a gem\". http:\/\/t.co\/EStNWKvU",
  "id" : 157519494716194816,
  "in_reply_to_status_id" : 157500500290453504,
  "created_at" : "2012-01-12 17:49:09 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Beal",
      "screen_name" : "alanbeal",
      "indices" : [ 0, 9 ],
      "id_str" : "33199641",
      "id" : 33199641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157500338100899841",
  "geo" : { },
  "id_str" : "157519176414666752",
  "in_reply_to_user_id" : 33199641,
  "text" : "@alanbeal awesome, thank you. I'll include this next time I do the talk.",
  "id" : 157519176414666752,
  "in_reply_to_status_id" : 157500338100899841,
  "created_at" : "2012-01-12 17:47:52 +0000",
  "in_reply_to_screen_name" : "alanbeal",
  "in_reply_to_user_id_str" : "33199641",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter van Hardenberg",
      "screen_name" : "pvh",
      "indices" : [ 0, 4 ],
      "id_str" : "15532680",
      "id" : 15532680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157486801865547777",
  "geo" : { },
  "id_str" : "157487459041677314",
  "in_reply_to_user_id" : 15532680,
  "text" : "@pvh your account has been hacked.",
  "id" : 157487459041677314,
  "in_reply_to_status_id" : 157486801865547777,
  "created_at" : "2012-01-12 15:41:50 +0000",
  "in_reply_to_screen_name" : "pvh",
  "in_reply_to_user_id_str" : "15532680",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CodeMash",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157463286701498368",
  "text" : "That's 3 times I've heard \"hippy Ruby (shit)\" so far at the #CodeMash keynote. Far out.",
  "id" : 157463286701498368,
  "created_at" : "2012-01-12 14:05:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157304163410259968",
  "geo" : { },
  "id_str" : "157338325441720321",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense MITTENS! holy crap dude congrats!",
  "id" : 157338325441720321,
  "in_reply_to_status_id" : 157304163410259968,
  "created_at" : "2012-01-12 05:49:14 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/157295820734087169\/photo\/1",
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/rbwCcqNB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ai7Tty_CQAAi9tI.jpg",
      "id_str" : "157295820738281472",
      "id" : 157295820738281472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ai7Tty_CQAAi9tI.jpg",
      "sizes" : [ {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rbwCcqNB"
    } ],
    "hashtags" : [ {
      "text" : "munchkin",
      "indices" : [ 28, 37 ]
    }, {
      "text" : "codemash",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157295820734087169",
  "text" : "Level 20 Katrina, too soon? #munchkin #codemash http:\/\/t.co\/rbwCcqNB",
  "id" : 157295820734087169,
  "created_at" : "2012-01-12 03:00:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157270669342679041",
  "text" : "Heading down to the cash bar area with Settlers, Guillotine, Chrononauts, and Munchkin. Anyone else in? #codemash",
  "id" : 157270669342679041,
  "created_at" : "2012-01-12 01:20:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157255032201424896",
  "geo" : { },
  "id_str" : "157256937845698561",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant mercenaries?",
  "id" : 157256937845698561,
  "in_reply_to_status_id" : 157255032201424896,
  "created_at" : "2012-01-12 00:25:50 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "leon",
      "screen_name" : "rubybuddha",
      "indices" : [ 0, 11 ],
      "id_str" : "129873542",
      "id" : 129873542
    }, {
      "name" : "Dean Weber",
      "screen_name" : "DeanWeber",
      "indices" : [ 12, 22 ],
      "id_str" : "7307492",
      "id" : 7307492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157230177267625984",
  "geo" : { },
  "id_str" : "157233687824572417",
  "in_reply_to_user_id" : 129873542,
  "text" : "@rubybuddha @DeanWeber at the reserve if you're hungry.",
  "id" : 157233687824572417,
  "in_reply_to_status_id" : 157230177267625984,
  "created_at" : "2012-01-11 22:53:27 +0000",
  "in_reply_to_screen_name" : "rubybuddha",
  "in_reply_to_user_id_str" : "129873542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 0, 11 ],
      "id_str" : "9070452",
      "id" : 9070452
    }, {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 12, 23 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157229557873770496",
  "geo" : { },
  "id_str" : "157230000033107968",
  "in_reply_to_user_id" : 9070452,
  "text" : "@jimweirich @joshsusser please not 9.0",
  "id" : 157230000033107968,
  "in_reply_to_status_id" : 157229557873770496,
  "created_at" : "2012-01-11 22:38:47 +0000",
  "in_reply_to_screen_name" : "jimweirich",
  "in_reply_to_user_id_str" : "9070452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Weber",
      "screen_name" : "DeanWeber",
      "indices" : [ 0, 10 ],
      "id_str" : "7307492",
      "id" : 7307492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157229109406216192",
  "geo" : { },
  "id_str" : "157229572264435714",
  "in_reply_to_user_id" : 7307492,
  "text" : "@DeanWeber not yet",
  "id" : 157229572264435714,
  "in_reply_to_status_id" : 157229109406216192,
  "created_at" : "2012-01-11 22:37:05 +0000",
  "in_reply_to_screen_name" : "DeanWeber",
  "in_reply_to_user_id_str" : "7307492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/157228077053784064\/photo\/1",
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/zWJecrJq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ai6WGmHCMAA_LoL.jpg",
      "id_str" : "157228077057978368",
      "id" : 157228077057978368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ai6WGmHCMAA_LoL.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zWJecrJq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157228077053784064",
  "text" : "There's a huge arcade at this hotel. ZOMG. http:\/\/t.co\/zWJecrJq",
  "id" : 157228077053784064,
  "created_at" : "2012-01-11 22:31:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 55, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157227514073329664",
  "text" : "I feel like I'm walking through a game of Jambo in the #codemash hotel. When \/where is the game room anyway?",
  "id" : 157227514073329664,
  "created_at" : "2012-01-11 22:28:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 0, 6 ],
      "id_str" : "1679",
      "id" : 1679
    }, {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 7, 18 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157198389069611008",
  "geo" : { },
  "id_str" : "157209856506470400",
  "in_reply_to_user_id" : 1679,
  "text" : "@javan @trevorturk Hell yes.",
  "id" : 157209856506470400,
  "in_reply_to_status_id" : 157198389069611008,
  "created_at" : "2012-01-11 21:18:45 +0000",
  "in_reply_to_screen_name" : "javan",
  "in_reply_to_user_id_str" : "1679",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Lavena",
      "screen_name" : "luislavena",
      "indices" : [ 0, 11 ],
      "id_str" : "16891327",
      "id" : 16891327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157191510444613632",
  "geo" : { },
  "id_str" : "157196944798781440",
  "in_reply_to_user_id" : 16891327,
  "text" : "@luislavena haha i wonder what git gc --aggressive would do :)",
  "id" : 157196944798781440,
  "in_reply_to_status_id" : 157191510444613632,
  "created_at" : "2012-01-11 20:27:26 +0000",
  "in_reply_to_screen_name" : "luislavena",
  "in_reply_to_user_id_str" : "16891327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "leon",
      "screen_name" : "rubybuddha",
      "indices" : [ 73, 84 ],
      "id_str" : "129873542",
      "id" : 129873542
    }, {
      "name" : "Scott Walker",
      "screen_name" : "pragma_tech",
      "indices" : [ 89, 101 ],
      "id_str" : "13515052",
      "id" : 13515052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157193876870934529",
  "text" : "RT @aquaranto: Having a ton of fun at the talk 'People vs JavaScript' by @rubybuddha and @pragma_tech. Learning a lot and working on my  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "leon",
        "screen_name" : "rubybuddha",
        "indices" : [ 58, 69 ],
        "id_str" : "129873542",
        "id" : 129873542
      }, {
        "name" : "Scott Walker",
        "screen_name" : "pragma_tech",
        "indices" : [ 74, 86 ],
        "id_str" : "13515052",
        "id" : 13515052
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157192884741877760",
    "text" : "Having a ton of fun at the talk 'People vs JavaScript' by @rubybuddha and @pragma_tech. Learning a lot and working on my jsconsole skills :)",
    "id" : 157192884741877760,
    "created_at" : "2012-01-11 20:11:18 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 157193876870934529,
  "created_at" : "2012-01-11 20:15:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Liss",
      "screen_name" : "jo_liss",
      "indices" : [ 0, 8 ],
      "id_str" : "223422672",
      "id" : 223422672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/bdjxoR36",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "157191064095178752",
  "geo" : { },
  "id_str" : "157193811448180737",
  "in_reply_to_user_id" : 223422672,
  "text" : "@jo_liss yeah but everything has to go through http:\/\/t.co\/bdjxoR36 (not *.cf\/*.s3) first, so it's not 100% on a CDN. mostly correct :)",
  "id" : 157193811448180737,
  "in_reply_to_status_id" : 157191064095178752,
  "created_at" : "2012-01-11 20:14:59 +0000",
  "in_reply_to_screen_name" : "jo_liss",
  "in_reply_to_user_id_str" : "223422672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Liss",
      "screen_name" : "jo_liss",
      "indices" : [ 0, 8 ],
      "id_str" : "223422672",
      "id" : 223422672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157193691591745536",
  "in_reply_to_user_id" : 223422672,
  "text" : "@jo_liss It's more than that. much, much more. :) my stats are way off.",
  "id" : 157193691591745536,
  "created_at" : "2012-01-11 20:14:31 +0000",
  "in_reply_to_screen_name" : "jo_liss",
  "in_reply_to_user_id_str" : "223422672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Liss",
      "screen_name" : "jo_liss",
      "indices" : [ 0, 8 ],
      "id_str" : "223422672",
      "id" : 223422672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157176912584769536",
  "geo" : { },
  "id_str" : "157185141096202240",
  "in_reply_to_user_id" : 223422672,
  "text" : "@jo_liss it's pretty high, around 2TB+\/mo. you mean for the site frontend? make it all static?",
  "id" : 157185141096202240,
  "in_reply_to_status_id" : 157176912584769536,
  "created_at" : "2012-01-11 19:40:32 +0000",
  "in_reply_to_screen_name" : "jo_liss",
  "in_reply_to_user_id_str" : "223422672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 6, 13 ],
      "id_str" : "728173",
      "id" : 728173
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 72, 79 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/P8i5jEml",
      "expanded_url" : "http:\/\/github.com\/rubygems\/guides",
      "display_url" : "github.com\/rubygems\/guides"
    } ]
  },
  "geo" : { },
  "id_str" : "157175432096137218",
  "text" : "Whoa! @MikeG1 went postal on http:\/\/t.co\/P8i5jEml, thanks for the code! @sferik is merging away and getting it out there.",
  "id" : 157175432096137218,
  "created_at" : "2012-01-11 19:01:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/ahsFlSCp",
      "expanded_url" : "http:\/\/www.buffalorising.com\/2012\/01\/the-new-buffalo-brewing-company.html",
      "display_url" : "buffalorising.com\/2012\/01\/the-ne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "157151037780803584",
  "text" : "Loving these beer logos, excited to try some more Buffalo brews. http:\/\/t.co\/ahsFlSCp",
  "id" : 157151037780803584,
  "created_at" : "2012-01-11 17:25:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Hariharan",
      "screen_name" : "hkarthik",
      "indices" : [ 0, 9 ],
      "id_str" : "4514261",
      "id" : 4514261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157143823556952064",
  "geo" : { },
  "id_str" : "157144459283406848",
  "in_reply_to_user_id" : 4514261,
  "text" : "@hkarthik yeah...been spending downtime during this precompiler to figure out how to tweak it out. wondering if it's worth it.",
  "id" : 157144459283406848,
  "in_reply_to_status_id" : 157143823556952064,
  "created_at" : "2012-01-11 16:58:53 +0000",
  "in_reply_to_screen_name" : "hkarthik",
  "in_reply_to_user_id_str" : "4514261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/157143314452328450\/photo\/1",
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/zw5nqSZd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ai5JAw0CMAEH-1t.png",
      "id_str" : "157143314456522753",
      "id" : 157143314456522753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ai5JAw0CMAEH-1t.png",
      "sizes" : [ {
        "h" : 638,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 744,
        "resize" : "fit",
        "w" : 396
      }, {
        "h" : 744,
        "resize" : "fit",
        "w" : 396
      }, {
        "h" : 744,
        "resize" : "fit",
        "w" : 396
      } ],
      "display_url" : "pic.twitter.com\/zw5nqSZd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157143314452328450",
  "text" : "Despite all of my XCode bitching, this is pretty neat. http:\/\/t.co\/zw5nqSZd",
  "id" : 157143314452328450,
  "created_at" : "2012-01-11 16:54:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pragma",
      "indices" : [ 35, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157135890592960512",
  "text" : "Apparently \/\/MARK is equivalent to #pragma. Both are terrible, regardless.",
  "id" : 157135890592960512,
  "created_at" : "2012-01-11 16:24:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pragma",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157135596840689664",
  "text" : "#pragma this is a terrible way to organize code",
  "id" : 157135596840689664,
  "created_at" : "2012-01-11 16:23:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157121123652354048",
  "geo" : { },
  "id_str" : "157121375109255168",
  "in_reply_to_user_id" : 65247837,
  "text" : "@DanAlfano my apartment smells of rich mahogany, and I have many leather-bound books",
  "id" : 157121375109255168,
  "in_reply_to_status_id" : 157121123652354048,
  "created_at" : "2012-01-11 15:27:09 +0000",
  "in_reply_to_screen_name" : "Hoonidan",
  "in_reply_to_user_id_str" : "65247837",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157120628309245952",
  "geo" : { },
  "id_str" : "157120718868455425",
  "in_reply_to_user_id" : 65247837,
  "text" : "@DanAlfano No, he doesn't.",
  "id" : 157120718868455425,
  "in_reply_to_status_id" : 157120628309245952,
  "created_at" : "2012-01-11 15:24:33 +0000",
  "in_reply_to_screen_name" : "Hoonidan",
  "in_reply_to_user_id_str" : "65247837",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CodeMash",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157110209863618560",
  "text" : "Tweeting from #CodeMash iOS Session! Holy crap XCode is complicated. Also, why does it look like iTunes? Who thought that was a good idea?",
  "id" : 157110209863618560,
  "created_at" : "2012-01-11 14:42:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/157098015671328768\/photo\/1",
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/obgvoU4L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ai4f0BtCIAAwUzW.png",
      "id_str" : "157098015675523072",
      "id" : 157098015675523072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ai4f0BtCIAAwUzW.png",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1394
      } ],
      "display_url" : "pic.twitter.com\/obgvoU4L"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157098015671328768",
  "text" : "Forgot how absolutely overwhelming IDEs are. So many buttons, options, knobs, etc. http:\/\/t.co\/obgvoU4L",
  "id" : 157098015671328768,
  "created_at" : "2012-01-11 13:54:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hamill",
      "screen_name" : "benhamill",
      "indices" : [ 0, 10 ],
      "id_str" : "15847711",
      "id" : 15847711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 55 ],
      "url" : "https:\/\/t.co\/jerWI9Df",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/issues\/365",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "156982384259112960",
  "geo" : { },
  "id_str" : "157094013047025664",
  "in_reply_to_user_id" : 15847711,
  "text" : "@benhamill Check out this thread: https:\/\/t.co\/jerWI9Df",
  "id" : 157094013047025664,
  "in_reply_to_status_id" : 156982384259112960,
  "created_at" : "2012-01-11 13:38:26 +0000",
  "in_reply_to_screen_name" : "benhamill",
  "in_reply_to_user_id_str" : "15847711",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 43, 46 ],
      "id_str" : "1133971",
      "id" : 1133971
    }, {
      "name" : "Jim Remsik",
      "screen_name" : "jremsikjr",
      "indices" : [ 51, 61 ],
      "id_str" : "1942",
      "id" : 1942
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/157093081647300608\/photo\/1",
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/lpyBLIKr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ai4bU1DCQAAGVeb.jpg",
      "id_str" : "157093081655689216",
      "id" : 157093081655689216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ai4bU1DCQAAGVeb.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/lpyBLIKr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157093081647300608",
  "text" : "Awesome MadisonRuby shirt acquired, thanks @j3 and @jremsikjr ! http:\/\/t.co\/lpyBLIKr",
  "id" : 157093081647300608,
  "created_at" : "2012-01-11 13:34:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Martek",
      "screen_name" : "cregatron",
      "indices" : [ 0, 10 ],
      "id_str" : "16892522",
      "id" : 16892522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157082530800078848",
  "geo" : { },
  "id_str" : "157085639811153920",
  "in_reply_to_user_id" : 16892522,
  "text" : "@cregatron the five star guy is the best",
  "id" : 157085639811153920,
  "in_reply_to_status_id" : 157082530800078848,
  "created_at" : "2012-01-11 13:05:09 +0000",
  "in_reply_to_screen_name" : "cregatron",
  "in_reply_to_user_id_str" : "16892522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hamill",
      "screen_name" : "benhamill",
      "indices" : [ 0, 10 ],
      "id_str" : "15847711",
      "id" : 15847711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156982384259112960",
  "geo" : { },
  "id_str" : "157070450571223041",
  "in_reply_to_user_id" : 15847711,
  "text" : "@benhamill I think so but haven't heard much about it. Let me find the github issue.",
  "id" : 157070450571223041,
  "in_reply_to_status_id" : 156982384259112960,
  "created_at" : "2012-01-11 12:04:48 +0000",
  "in_reply_to_screen_name" : "benhamill",
  "in_reply_to_user_id_str" : "15847711",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157058673670230017",
  "geo" : { },
  "id_str" : "157070340063895553",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 get bananajour fired up and start cloning repos into it :)",
  "id" : 157070340063895553,
  "in_reply_to_status_id" : 157058673670230017,
  "created_at" : "2012-01-11 12:04:21 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/p6ixdSD9",
      "expanded_url" : "http:\/\/instagr.am\/p\/gIyqY\/",
      "display_url" : "instagr.am\/p\/gIyqY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "156942630104743936",
  "text" : "Staying at the... http:\/\/t.co\/p6ixdSD9",
  "id" : 156942630104743936,
  "created_at" : "2012-01-11 03:36:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Mosher",
      "screen_name" : "dmosher",
      "indices" : [ 0, 8 ],
      "id_str" : "3382151",
      "id" : 3382151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156941031290572801",
  "geo" : { },
  "id_str" : "156941653121306624",
  "in_reply_to_user_id" : 3382151,
  "text" : "@dmosher looks awesome! Haven't seen any of these.",
  "id" : 156941653121306624,
  "in_reply_to_status_id" : 156941031290572801,
  "created_at" : "2012-01-11 03:33:00 +0000",
  "in_reply_to_screen_name" : "dmosher",
  "in_reply_to_user_id_str" : "3382151",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 6, 16 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156759783586807808",
  "geo" : { },
  "id_str" : "156932958501076993",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo @magnachef is that really the battle to fight? Aren't there more productive ways to improve the city and living experience?",
  "id" : 156932958501076993,
  "in_reply_to_status_id" : 156759783586807808,
  "created_at" : "2012-01-11 02:58:27 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    }, {
      "name" : "Jim Remsik",
      "screen_name" : "jremsikjr",
      "indices" : [ 15, 25 ],
      "id_str" : "1942",
      "id" : 1942
    }, {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 26, 37 ],
      "id_str" : "13893562",
      "id" : 13893562
    }, {
      "name" : "Vii",
      "screen_name" : "veezus",
      "indices" : [ 38, 45 ],
      "id_str" : "818377692",
      "id" : 818377692
    }, {
      "name" : "leon",
      "screen_name" : "rubybuddha",
      "indices" : [ 46, 57 ],
      "id_str" : "129873542",
      "id" : 129873542
    }, {
      "name" : "Matt Yoho",
      "screen_name" : "mattyoho",
      "indices" : [ 58, 67 ],
      "id_str" : "12251322",
      "id" : 12251322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156908208726867969",
  "geo" : { },
  "id_str" : "156917445540577280",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt @jremsikjr @joefiorini @veezus @rubybuddha @mattyoho I think we're gonna take it easy tonight. See yaz tomorrow !",
  "id" : 156917445540577280,
  "in_reply_to_status_id" : 156908208726867969,
  "created_at" : "2012-01-11 01:56:49 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Peabody",
      "screen_name" : "marcpeabody",
      "indices" : [ 0, 12 ],
      "id_str" : "18827544",
      "id" : 18827544
    }, {
      "name" : "edge case",
      "screen_name" : "edgecase",
      "indices" : [ 13, 22 ],
      "id_str" : "1060026457",
      "id" : 1060026457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156908196705996801",
  "geo" : { },
  "id_str" : "156912405446791168",
  "in_reply_to_user_id" : 18827544,
  "text" : "@marcpeabody @EdgeCase oh man, I need to get in on some of this. is this for edgecasers only? :)",
  "id" : 156912405446791168,
  "in_reply_to_status_id" : 156908196705996801,
  "created_at" : "2012-01-11 01:36:47 +0000",
  "in_reply_to_screen_name" : "marcpeabody",
  "in_reply_to_user_id_str" : "18827544",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 69, 83 ],
      "id_str" : "809685",
      "id" : 809685
    }, {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 84, 95 ],
      "id_str" : "13893562",
      "id" : 13893562
    }, {
      "name" : "Vii",
      "screen_name" : "veezus",
      "indices" : [ 96, 103 ],
      "id_str" : "818377692",
      "id" : 818377692
    }, {
      "name" : "leon",
      "screen_name" : "rubybuddha",
      "indices" : [ 104, 115 ],
      "id_str" : "129873542",
      "id" : 129873542
    }, {
      "name" : "Matt Yoho",
      "screen_name" : "mattyoho",
      "indices" : [ 116, 125 ],
      "id_str" : "12251322",
      "id" : 12251322
    }, {
      "name" : "Jim Remsik",
      "screen_name" : "jremsikjr",
      "indices" : [ 126, 136 ],
      "id_str" : "1942",
      "id" : 1942
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 4, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156906417553547264",
  "text" : "Any #codemash folks out somewhere getting food\/drinks? I HUNGER! \/cc @garybernhardt @joefiorini @veezus @rubybuddha @mattyoho @jremsikjr",
  "id" : 156906417553547264,
  "created_at" : "2012-01-11 01:12:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156897820421529600",
  "geo" : { },
  "id_str" : "156898413907165185",
  "in_reply_to_user_id" : 372319943,
  "text" : "@A_R_Q_522 This sounds disgusting out of context.",
  "id" : 156898413907165185,
  "in_reply_to_status_id" : 156897820421529600,
  "created_at" : "2012-01-11 00:41:11 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 132 ],
      "url" : "https:\/\/t.co\/fZqblxYd",
      "expanded_url" : "https:\/\/github.com\/Lokaltog\/vim-powerline\/issues\/13",
      "display_url" : "github.com\/Lokaltog\/vim-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "156886471578628096",
  "text" : "Just got vim-powerline hooked up! Follow the instructions here to patch yourr font (check out my comment too): https:\/\/t.co\/fZqblxYd",
  "id" : 156886471578628096,
  "created_at" : "2012-01-10 23:53:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Hardy",
      "screen_name" : "packagethief",
      "indices" : [ 0, 13 ],
      "id_str" : "12089482",
      "id" : 12089482
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 14, 18 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156885548479430656",
  "geo" : { },
  "id_str" : "156886092761665536",
  "in_reply_to_user_id" : 12089482,
  "text" : "@packagethief @dhh yeah, must be warm in spain. in buffalo\/southern ontario, not so much bare feet this time of year :)",
  "id" : 156886092761665536,
  "in_reply_to_status_id" : 156885548479430656,
  "created_at" : "2012-01-10 23:52:13 +0000",
  "in_reply_to_screen_name" : "packagethief",
  "in_reply_to_user_id_str" : "12089482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Silkeb\u00E6kken",
      "screen_name" : "Lokaltog",
      "indices" : [ 0, 9 ],
      "id_str" : "19385850",
      "id" : 19385850
    }, {
      "name" : "Paul Hinze",
      "screen_name" : "phinze",
      "indices" : [ 10, 17 ],
      "id_str" : "37412405",
      "id" : 37412405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156806790611341312",
  "geo" : { },
  "id_str" : "156885413204738048",
  "in_reply_to_user_id" : 19385850,
  "text" : "@Lokaltog @phinze just did and it works great. commenting on that issue now.",
  "id" : 156885413204738048,
  "in_reply_to_status_id" : 156806790611341312,
  "created_at" : "2012-01-10 23:49:31 +0000",
  "in_reply_to_screen_name" : "Lokaltog",
  "in_reply_to_user_id_str" : "19385850",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 24, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156878790398713856",
  "text" : "Arrived in Sandusky for #codemash!",
  "id" : 156878790398713856,
  "created_at" : "2012-01-10 23:23:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156861594591182848",
  "geo" : { },
  "id_str" : "156878310671007744",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight no idea, sorry :(",
  "id" : 156878310671007744,
  "in_reply_to_status_id" : 156861594591182848,
  "created_at" : "2012-01-10 23:21:18 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Hinze",
      "screen_name" : "phinze",
      "indices" : [ 0, 7 ],
      "id_str" : "37412405",
      "id" : 37412405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156795866311696385",
  "geo" : { },
  "id_str" : "156800334650544128",
  "in_reply_to_user_id" : 37412405,
  "text" : "@phinze yeah was just looking into that....we'll see.",
  "id" : 156800334650544128,
  "in_reply_to_status_id" : 156795866311696385,
  "created_at" : "2012-01-10 18:11:27 +0000",
  "in_reply_to_screen_name" : "phinze",
  "in_reply_to_user_id_str" : "37412405",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 71 ],
      "url" : "https:\/\/t.co\/AsdHbQNA",
      "expanded_url" : "https:\/\/github.com\/Lokaltog\/vim-powerline",
      "display_url" : "github.com\/Lokaltog\/vim-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "156793805755006976",
  "text" : "Wow, definitely going to check out vim-powerline. https:\/\/t.co\/AsdHbQNA",
  "id" : 156793805755006976,
  "created_at" : "2012-01-10 17:45:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156575468684980224",
  "text" : "I think I know why I like Assassin's Creed so much. It's like Carmen Sandiego, except you can murder people.",
  "id" : 156575468684980224,
  "created_at" : "2012-01-10 03:17:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 27, 34 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 35, 42 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156529430230073344",
  "geo" : { },
  "id_str" : "156537761933967362",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen not sure, hey @Croaky @gabebw any ideas?",
  "id" : 156537761933967362,
  "in_reply_to_status_id" : 156529430230073344,
  "created_at" : "2012-01-10 00:48:05 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Cull",
      "screen_name" : "seanreloaded",
      "indices" : [ 0, 13 ],
      "id_str" : "2129061",
      "id" : 2129061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156485372522663937",
  "geo" : { },
  "id_str" : "156509477175169024",
  "in_reply_to_user_id" : 2129061,
  "text" : "@seanreloaded thanks! :)",
  "id" : 156509477175169024,
  "in_reply_to_status_id" : 156485372522663937,
  "created_at" : "2012-01-09 22:55:41 +0000",
  "in_reply_to_screen_name" : "seanreloaded",
  "in_reply_to_user_id_str" : "2129061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CodeMash",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156447719043502080",
  "text" : "Going to try to get through #CodeMash by not going to one .NET talk...is it even possible!?",
  "id" : 156447719043502080,
  "created_at" : "2012-01-09 18:50:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 61, 72 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/N84seKd5",
      "expanded_url" : "http:\/\/is.gd\/dlOJDH",
      "display_url" : "is.gd\/dlOJDH"
    } ]
  },
  "geo" : { },
  "id_str" : "156422994032459776",
  "text" : "Great article about working from home from local Buffalonian @kevinpurdy. Need to take some of this advice. http:\/\/t.co\/N84seKd5",
  "id" : 156422994032459776,
  "created_at" : "2012-01-09 17:12:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 0, 8 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "Bill Chapman",
      "screen_name" : "byllc",
      "indices" : [ 9, 15 ],
      "id_str" : "34287352",
      "id" : 34287352
    }, {
      "name" : "Trocaire College",
      "screen_name" : "TrocaireCollege",
      "indices" : [ 16, 32 ],
      "id_str" : "54944254",
      "id" : 54944254
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156413113414062081",
  "geo" : { },
  "id_str" : "156416333704212480",
  "in_reply_to_user_id" : 205886758,
  "text" : "@wnyruby @byllc @TrocaireCollege \"Industry standard certifications in Ruby\" ...seriously? this shows zero understanding of Ruby's ecosystem.",
  "id" : 156416333704212480,
  "in_reply_to_status_id" : 156413113414062081,
  "created_at" : "2012-01-09 16:45:34 +0000",
  "in_reply_to_screen_name" : "wnyruby",
  "in_reply_to_user_id_str" : "205886758",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156413351654719488",
  "text" : "Two vim crashes today and did a git checkout -f instead of checkout -p. HAPPY MONDAY!",
  "id" : 156413351654719488,
  "created_at" : "2012-01-09 16:33:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/r2g906pJ",
      "expanded_url" : "http:\/\/boston.io",
      "display_url" : "boston.io"
    } ]
  },
  "geo" : { },
  "id_str" : "156393179594244098",
  "text" : "Happy to announce I'll be returning to Boston to speak at http:\/\/t.co\/r2g906pJ !",
  "id" : 156393179594244098,
  "created_at" : "2012-01-09 15:13:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156249599022084096",
  "geo" : { },
  "id_str" : "156251733096542208",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg nice place, seems like a sweet town. congrats dude!",
  "id" : 156251733096542208,
  "in_reply_to_status_id" : 156249599022084096,
  "created_at" : "2012-01-09 05:51:30 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oren Teich",
      "screen_name" : "teich",
      "indices" : [ 0, 6 ],
      "id_str" : "814033",
      "id" : 814033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156245137599639552",
  "geo" : { },
  "id_str" : "156245541456584704",
  "in_reply_to_user_id" : 814033,
  "text" : "@teich FREE PONIES!",
  "id" : 156245541456584704,
  "in_reply_to_status_id" : 156245137599639552,
  "created_at" : "2012-01-09 05:26:54 +0000",
  "in_reply_to_screen_name" : "teich",
  "in_reply_to_user_id_str" : "814033",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/h5DDkNcM",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=DFXXAuDK1Ao",
      "display_url" : "youtube.com\/watch?v=DFXXAu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "156240850526011392",
  "text" : "VERMIN SUPREME 2012. http:\/\/t.co\/h5DDkNcM",
  "id" : 156240850526011392,
  "created_at" : "2012-01-09 05:08:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156234093108019200",
  "geo" : { },
  "id_str" : "156239702607933440",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella Not a fan either here, seems like they're fixing things that weren't broken.",
  "id" : 156239702607933440,
  "in_reply_to_status_id" : 156234093108019200,
  "created_at" : "2012-01-09 05:03:42 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156223744698880000",
  "geo" : { },
  "id_str" : "156224304005132288",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck LOL had the EXACT same reaction.",
  "id" : 156224304005132288,
  "in_reply_to_status_id" : 156223744698880000,
  "created_at" : "2012-01-09 04:02:31 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Ingram",
      "screen_name" : "pjammer",
      "indices" : [ 0, 8 ],
      "id_str" : "15266123",
      "id" : 15266123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155850334294646784",
  "geo" : { },
  "id_str" : "155896358342103040",
  "in_reply_to_user_id" : 15266123,
  "text" : "@pjammer agreed, maybe we need a wny\/Toronto night!",
  "id" : 155896358342103040,
  "in_reply_to_status_id" : 155850334294646784,
  "created_at" : "2012-01-08 06:19:22 +0000",
  "in_reply_to_screen_name" : "pjammer",
  "in_reply_to_user_id_str" : "15266123",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155862546849595393",
  "geo" : { },
  "id_str" : "155896167539027968",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss the odds are so stacked sometimes. Ruthless game.",
  "id" : 155896167539027968,
  "in_reply_to_status_id" : 155862546849595393,
  "created_at" : "2012-01-08 06:18:37 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155883976005918721",
  "geo" : { },
  "id_str" : "155894048765386752",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox what up with that?",
  "id" : 155894048765386752,
  "in_reply_to_status_id" : 155883976005918721,
  "created_at" : "2012-01-08 06:10:12 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 32, 42 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/RR8rd5Wr",
      "expanded_url" : "http:\/\/path.com\/p\/32ZFRz",
      "display_url" : "path.com\/p\/32ZFRz"
    } ]
  },
  "geo" : { },
  "id_str" : "155860168133976066",
  "text" : "Definitely lost to bioterrorist @aquaranto. (with Amanda) [pic] \u2014 http:\/\/t.co\/RR8rd5Wr",
  "id" : 155860168133976066,
  "created_at" : "2012-01-08 03:55:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Ingram",
      "screen_name" : "pjammer",
      "indices" : [ 0, 8 ],
      "id_str" : "15266123",
      "id" : 15266123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155756018192744448",
  "geo" : { },
  "id_str" : "155831272168636417",
  "in_reply_to_user_id" : 15266123,
  "text" : "@pjammer yes! Moved in November.",
  "id" : 155831272168636417,
  "in_reply_to_status_id" : 155756018192744448,
  "created_at" : "2012-01-08 02:00:45 +0000",
  "in_reply_to_screen_name" : "pjammer",
  "in_reply_to_user_id_str" : "15266123",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/NL7v3H7O",
      "expanded_url" : "http:\/\/instagr.am\/p\/fONmd\/",
      "display_url" : "instagr.am\/p\/fONmd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "155753285150707712",
  "text" : "Pretty sure I'm never going to be sick of these sunsets on the lake. http:\/\/t.co\/NL7v3H7O",
  "id" : 155753285150707712,
  "created_at" : "2012-01-07 20:50:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Van Fleet",
      "screen_name" : "bigfleet",
      "indices" : [ 0, 9 ],
      "id_str" : "3123671",
      "id" : 3123671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155660154682089472",
  "geo" : { },
  "id_str" : "155660612209356801",
  "in_reply_to_user_id" : 3123671,
  "text" : "@bigfleet HELP ME I CAN'T PUT THIS GAME DOWN",
  "id" : 155660612209356801,
  "in_reply_to_status_id" : 155660154682089472,
  "created_at" : "2012-01-07 14:42:36 +0000",
  "in_reply_to_screen_name" : "bigfleet",
  "in_reply_to_user_id_str" : "3123671",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/1tEQVt7c",
      "expanded_url" : "http:\/\/bit.ly\/TempleRunGame",
      "display_url" : "bit.ly\/TempleRunGame"
    } ]
  },
  "geo" : { },
  "id_str" : "155659702624194560",
  "text" : "I got 1,532,586 points while escaping from demon monkeys in Temple Run. Beat that! http:\/\/t.co\/1tEQVt7c",
  "id" : 155659702624194560,
  "created_at" : "2012-01-07 14:38:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/FX8dOOH7",
      "expanded_url" : "http:\/\/instagr.am\/p\/e8uYz\/",
      "display_url" : "instagr.am\/p\/e8uYz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "155410170892128257",
  "text" : "No filter required! http:\/\/t.co\/FX8dOOH7",
  "id" : 155410170892128257,
  "created_at" : "2012-01-06 22:07:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155387930922328064",
  "geo" : { },
  "id_str" : "155389114651394048",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y \/play tmyk ?",
  "id" : 155389114651394048,
  "in_reply_to_status_id" : 155387930922328064,
  "created_at" : "2012-01-06 20:43:46 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/ZrGBceem",
      "expanded_url" : "http:\/\/is.gd\/vgS8i5",
      "display_url" : "is.gd\/vgS8i5"
    } ]
  },
  "geo" : { },
  "id_str" : "155298267717042178",
  "text" : "Try reading this blog post and not making every single face with your face. http:\/\/t.co\/ZrGBceem",
  "id" : 155298267717042178,
  "created_at" : "2012-01-06 14:42:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155150934870196226",
  "geo" : { },
  "id_str" : "155152772889714688",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik thanks dude!",
  "id" : 155152772889714688,
  "in_reply_to_status_id" : 155150934870196226,
  "created_at" : "2012-01-06 05:04:38 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155149752814678017",
  "text" : "For added fun when pairing, hold down the F key when tests are running and see what your partner does.",
  "id" : 155149752814678017,
  "created_at" : "2012-01-06 04:52:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 34, 43 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 48, 58 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/0baFm7vJ",
      "expanded_url" : "http:\/\/rubyrogues.com\/036-rr-rubygems\/",
      "display_url" : "rubyrogues.com\/036-rr-rubygem\u2026"
    }, {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/U3Gku0JR",
      "expanded_url" : "http:\/\/rubyrogues.com\/036a-rubygems-bonus-content\/",
      "display_url" : "rubyrogues.com\/036a-rubygems-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154985416993415169",
  "text" : "I was on RubyRogues talking about @rubygems and @gemcutter! http:\/\/t.co\/0baFm7vJ With bonus content too! http:\/\/t.co\/U3Gku0JR",
  "id" : 154985416993415169,
  "created_at" : "2012-01-05 17:59:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The HTML5 Douche",
      "screen_name" : "html5douche",
      "indices" : [ 3, 15 ],
      "id_str" : "198612383",
      "id" : 198612383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154812256402677761",
  "text" : "RT @html5douche: THINGS YOU CAN DO WITH CSS3:\n\n1) MAKE AN IPHONE 4 WITH NO IMAGES!!\n2) MAKE SUPER MARIOOOO!!!\n3) MAKE A FUCKING WEBSITE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154800435729928192",
    "text" : "THINGS YOU CAN DO WITH CSS3:\n\n1) MAKE AN IPHONE 4 WITH NO IMAGES!!\n2) MAKE SUPER MARIOOOO!!!\n3) MAKE A FUCKING WEBSITE",
    "id" : 154800435729928192,
    "created_at" : "2012-01-05 05:44:34 +0000",
    "user" : {
      "name" : "The HTML5 Douche",
      "screen_name" : "html5douche",
      "protected" : false,
      "id_str" : "198612383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1138106603\/66_A_Douchebag_normal.jpg",
      "id" : 198612383,
      "verified" : false
    }
  },
  "id" : 154812256402677761,
  "created_at" : "2012-01-05 06:31:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 102, 111 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154784974439055361",
  "text" : "Slides 99% done for #codemash. I haven't been this excited for a talk in a while, pumped to introduce @rubygems to folks!",
  "id" : 154784974439055361,
  "created_at" : "2012-01-05 04:43:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/edew5S0J",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=9CS7j5I6aOc",
      "display_url" : "youtube.com\/watch?v=9CS7j5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154781046599196672",
  "text" : "Current status: http:\/\/t.co\/edew5S0J",
  "id" : 154781046599196672,
  "created_at" : "2012-01-05 04:27:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154761568582774785",
  "geo" : { },
  "id_str" : "154761965229719552",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt class String; def =~(s); \"LOLRUBY\"; end; end",
  "id" : 154761965229719552,
  "in_reply_to_status_id" : 154761568582774785,
  "created_at" : "2012-01-05 03:11:42 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154742290861146113",
  "geo" : { },
  "id_str" : "154742909751656449",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant \"Any sufficiently advanced technology is indistinguishable from magic\"",
  "id" : 154742909751656449,
  "in_reply_to_status_id" : 154742290861146113,
  "created_at" : "2012-01-05 01:55:59 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Conway",
      "screen_name" : "mattonrails",
      "indices" : [ 0, 12 ],
      "id_str" : "419811835",
      "id" : 419811835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154741891534028800",
  "geo" : { },
  "id_str" : "154742091510063104",
  "in_reply_to_user_id" : 33829595,
  "text" : "@mattonrails that's just like, your opinion, man",
  "id" : 154742091510063104,
  "in_reply_to_status_id" : 154741891534028800,
  "created_at" : "2012-01-05 01:52:44 +0000",
  "in_reply_to_screen_name" : "mattreduce",
  "in_reply_to_user_id_str" : "33829595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154740878097924096",
  "geo" : { },
  "id_str" : "154741831454826496",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant haha so? This technique has been around for a while.",
  "id" : 154741831454826496,
  "in_reply_to_status_id" : 154740878097924096,
  "created_at" : "2012-01-05 01:51:42 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter van Hardenberg",
      "screen_name" : "pvh",
      "indices" : [ 0, 4 ],
      "id_str" : "15532680",
      "id" : 15532680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154728624912744449",
  "geo" : { },
  "id_str" : "154741007336996864",
  "in_reply_to_user_id" : 15532680,
  "text" : "@pvh start by writing a blog post explaining what that tweet just said",
  "id" : 154741007336996864,
  "in_reply_to_status_id" : 154728624912744449,
  "created_at" : "2012-01-05 01:48:25 +0000",
  "in_reply_to_screen_name" : "pvh",
  "in_reply_to_user_id_str" : "15532680",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154736479317393409",
  "geo" : { },
  "id_str" : "154739015457837056",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison carcassone on iOS",
  "id" : 154739015457837056,
  "in_reply_to_status_id" : 154736479317393409,
  "created_at" : "2012-01-05 01:40:30 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Follow @henrikhodne",
      "screen_name" : "dvyjones",
      "indices" : [ 0, 9 ],
      "id_str" : "632309987",
      "id" : 632309987
    }, {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 10, 17 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154733250764488704",
  "geo" : { },
  "id_str" : "154734954109087745",
  "in_reply_to_user_id" : 14746604,
  "text" : "@dvyjones @tekkub IT'S YOUR TURN NOW",
  "id" : 154734954109087745,
  "in_reply_to_status_id" : 154733250764488704,
  "created_at" : "2012-01-05 01:24:22 +0000",
  "in_reply_to_screen_name" : "henrikhodne",
  "in_reply_to_user_id_str" : "14746604",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Follow @henrikhodne",
      "screen_name" : "dvyjones",
      "indices" : [ 3, 12 ],
      "id_str" : "632309987",
      "id" : 632309987
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 39, 45 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 50, 57 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/henrikhodne\/status\/154733250764488704\/photo\/1",
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/hGf7qWXY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AiW5El8CQAACE-d.jpg",
      "id_str" : "154733250768683008",
      "id" : 154733250768683008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AiW5El8CQAACE-d.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/hGf7qWXY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154734889697161216",
  "text" : "RT @dvyjones: Playing Carcassonne with @qrush and @tekkub. Squee! http:\/\/t.co\/hGf7qWXY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 25, 31 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "tekkub",
        "screen_name" : "tekkub",
        "indices" : [ 36, 43 ],
        "id_str" : "15827231",
        "id" : 15827231
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/henrikhodne\/status\/154733250764488704\/photo\/1",
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/hGf7qWXY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AiW5El8CQAACE-d.jpg",
        "id_str" : "154733250768683008",
        "id" : 154733250768683008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AiW5El8CQAACE-d.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/hGf7qWXY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154733250764488704",
    "text" : "Playing Carcassonne with @qrush and @tekkub. Squee! http:\/\/t.co\/hGf7qWXY",
    "id" : 154733250764488704,
    "created_at" : "2012-01-05 01:17:37 +0000",
    "user" : {
      "name" : "Henrik  Hodne",
      "screen_name" : "henrikhodne",
      "protected" : false,
      "id_str" : "14746604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530690997412302848\/Hc0moVXm_normal.jpeg",
      "id" : 14746604,
      "verified" : false
    }
  },
  "id" : 154734889697161216,
  "created_at" : "2012-01-05 01:24:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Larrick",
      "screen_name" : "deathbob",
      "indices" : [ 0, 9 ],
      "id_str" : "16340597",
      "id" : 16340597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154668799730253825",
  "geo" : { },
  "id_str" : "154688983564173312",
  "in_reply_to_user_id" : 16340597,
  "text" : "@deathbob sure! problem right now is that view of the data isn't available. And it would be huge. There's over 180k versions, way more deps.",
  "id" : 154688983564173312,
  "in_reply_to_status_id" : 154668799730253825,
  "created_at" : "2012-01-04 22:21:42 +0000",
  "in_reply_to_screen_name" : "deathbob",
  "in_reply_to_user_id_str" : "16340597",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154631248160100352",
  "text" : "VICTORY! \"DEPRECATION WARNING: Plugins are deprecated and will be removed in Rails 4.0.\"",
  "id" : 154631248160100352,
  "created_at" : "2012-01-04 18:32:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/iBp3d4D6",
      "expanded_url" : "http:\/\/tonawanda-news.com\/local\/x1818106082\/Four-decades-and-out",
      "display_url" : "tonawanda-news.com\/local\/x1818106\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154594323017641984",
  "text" : "Sadface: Local pizza & wings shop near where I grew up just died. http:\/\/t.co\/iBp3d4D6",
  "id" : 154594323017641984,
  "created_at" : "2012-01-04 16:05:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 0, 11 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154426729241378816",
  "geo" : { },
  "id_str" : "154445340152573952",
  "in_reply_to_user_id" : 48431692,
  "text" : "@laserlemon yeah, i outsource my designs to picking a random one and hoping they know what to do. i'm colordumb.",
  "id" : 154445340152573952,
  "in_reply_to_status_id" : 154426729241378816,
  "created_at" : "2012-01-04 06:13:33 +0000",
  "in_reply_to_screen_name" : "laserlemon",
  "in_reply_to_user_id_str" : "48431692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 6, 11 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154444126606213120",
  "text" : "First @woot purchase in years tonight.",
  "id" : 154444126606213120,
  "created_at" : "2012-01-04 06:08:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 0, 11 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/9papnjXF",
      "expanded_url" : "http:\/\/www.colourlovers.com\/palette\/650120\/old_woodcut",
      "display_url" : "colourlovers.com\/palette\/650120\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "154422759831777280",
  "geo" : { },
  "id_str" : "154425379027820544",
  "in_reply_to_user_id" : 48431692,
  "text" : "@laserlemon oh totally. I actually used a separate colour scheme: http:\/\/t.co\/9papnjXF",
  "id" : 154425379027820544,
  "in_reply_to_status_id" : 154422759831777280,
  "created_at" : "2012-01-04 04:54:14 +0000",
  "in_reply_to_screen_name" : "laserlemon",
  "in_reply_to_user_id_str" : "48431692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154422107391012865",
  "geo" : { },
  "id_str" : "154422474283552769",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg more like a teaser!",
  "id" : 154422474283552769,
  "in_reply_to_status_id" : 154422107391012865,
  "created_at" : "2012-01-04 04:42:41 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 84 ],
      "url" : "https:\/\/t.co\/JbBztXeP",
      "expanded_url" : "https:\/\/img.skitch.com\/20120104-k6ng8bsi7upbx3ef67m28kia2b.png",
      "display_url" : "img.skitch.com\/20120104-k6ng8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154421893175316481",
  "text" : "I'm approximately this excited to speak at my first #codemash. https:\/\/t.co\/JbBztXeP.",
  "id" : 154421893175316481,
  "created_at" : "2012-01-04 04:40:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    }, {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 12, 19 ],
      "id_str" : "10257182",
      "id" : 10257182
    }, {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 20, 33 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154397678422327297",
  "geo" : { },
  "id_str" : "154398463772209153",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff @heroku @jordansissel holy crap! congrats !!",
  "id" : 154398463772209153,
  "in_reply_to_status_id" : 154397678422327297,
  "created_at" : "2012-01-04 03:07:17 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154354261109645312",
  "geo" : { },
  "id_str" : "154354747585990656",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv really surprised you're watching jeopardy",
  "id" : 154354747585990656,
  "in_reply_to_status_id" : 154354261109645312,
  "created_at" : "2012-01-04 00:13:34 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/hSqOHSYD",
      "expanded_url" : "http:\/\/showoff.io",
      "display_url" : "showoff.io"
    } ]
  },
  "geo" : { },
  "id_str" : "154308355727425536",
  "text" : "First time playing with http:\/\/t.co\/hSqOHSYD, it's really impressive.",
  "id" : 154308355727425536,
  "created_at" : "2012-01-03 21:09:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gehard",
      "screen_name" : "mikegehard",
      "indices" : [ 0, 11 ],
      "id_str" : "38679514",
      "id" : 38679514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154250417084186625",
  "geo" : { },
  "id_str" : "154251013195436034",
  "in_reply_to_user_id" : 38679514,
  "text" : "@mikegehard needs to be a push (not pull\/rsync) system that's easy to setup and install. I was talking the mirrorbrain dude, i can cc you in",
  "id" : 154251013195436034,
  "in_reply_to_status_id" : 154250417084186625,
  "created_at" : "2012-01-03 17:21:22 +0000",
  "in_reply_to_screen_name" : "mikegehard",
  "in_reply_to_user_id_str" : "38679514",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Tanksley",
      "screen_name" : "charlietanksley",
      "indices" : [ 0, 16 ],
      "id_str" : "124224684",
      "id" : 124224684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154189627337613313",
  "geo" : { },
  "id_str" : "154249424728637440",
  "in_reply_to_user_id" : 124224684,
  "text" : "@charlietanksley yes, definitely calmed him down when people were over. it's like he was a completely different dog.",
  "id" : 154249424728637440,
  "in_reply_to_status_id" : 154189627337613313,
  "created_at" : "2012-01-03 17:15:03 +0000",
  "in_reply_to_screen_name" : "charlietanksley",
  "in_reply_to_user_id_str" : "124224684",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/RRls9WHJ",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=3420335",
      "display_url" : "news.ycombinator.com\/item?id=3420335"
    } ]
  },
  "geo" : { },
  "id_str" : "154248975493509120",
  "text" : "Just landed possibly the most seminal Hacker News comment of my career. http:\/\/t.co\/RRls9WHJ",
  "id" : 154248975493509120,
  "created_at" : "2012-01-03 17:13:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154076951399772160",
  "geo" : { },
  "id_str" : "154077962860380162",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape do you crate her during the day? We're starting to do meals in the crate, and we give a stuffed Kong before going.",
  "id" : 154077962860380162,
  "in_reply_to_status_id" : 154076951399772160,
  "created_at" : "2012-01-03 05:53:43 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Hariharan",
      "screen_name" : "hkarthik",
      "indices" : [ 0, 9 ],
      "id_str" : "4514261",
      "id" : 4514261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154076521244528640",
  "geo" : { },
  "id_str" : "154076905040117761",
  "in_reply_to_user_id" : 4514261,
  "text" : "@hkarthik we've met all ranges of boxer and it sounds familiar. Luckily ours is extremely social around everyone, sometimes too much so :)",
  "id" : 154076905040117761,
  "in_reply_to_status_id" : 154076521244528640,
  "created_at" : "2012-01-03 05:49:31 +0000",
  "in_reply_to_screen_name" : "hkarthik",
  "in_reply_to_user_id_str" : "4514261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154076287672139776",
  "geo" : { },
  "id_str" : "154076534536282113",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape haha he does, knows basic commands and listens well, just had bad, bad separation anxiety.",
  "id" : 154076534536282113,
  "in_reply_to_status_id" : 154076287672139776,
  "created_at" : "2012-01-03 05:48:03 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Hariharan",
      "screen_name" : "hkarthik",
      "indices" : [ 0, 9 ],
      "id_str" : "4514261",
      "id" : 4514261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154075398739738625",
  "geo" : { },
  "id_str" : "154076198534791168",
  "in_reply_to_user_id" : 4514261,
  "text" : "@hkarthik dang. What breed? I be the shirt will help, but socializing is rough.",
  "id" : 154076198534791168,
  "in_reply_to_status_id" : 154075398739738625,
  "created_at" : "2012-01-03 05:46:42 +0000",
  "in_reply_to_screen_name" : "hkarthik",
  "in_reply_to_user_id_str" : "4514261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154074804742402048",
  "geo" : { },
  "id_str" : "154075885207691264",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape he's slid the lining out, tried to dig out (tearing up carpet), broken one, almost wrecked this one. Not as easy as you think.",
  "id" : 154075885207691264,
  "in_reply_to_status_id" : 154074804742402048,
  "created_at" : "2012-01-03 05:45:28 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Hariharan",
      "screen_name" : "hkarthik",
      "indices" : [ 0, 9 ],
      "id_str" : "4514261",
      "id" : 4514261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154073788949086209",
  "geo" : { },
  "id_str" : "154074550374645760",
  "in_reply_to_user_id" : 4514261,
  "text" : "@hkarthik oh yeah, if we're not at the dog park for at least an hour daily he's a maniac. IIRC 2 hour walk == 15 mins off leash.",
  "id" : 154074550374645760,
  "in_reply_to_status_id" : 154073788949086209,
  "created_at" : "2012-01-03 05:40:10 +0000",
  "in_reply_to_screen_name" : "hkarthik",
  "in_reply_to_user_id_str" : "4514261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154071001779552257",
  "geo" : { },
  "id_str" : "154074051218915328",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape yeah it's time to get a trainer. Many other bad habits persist from his former owner. Need to take it to the next level.",
  "id" : 154074051218915328,
  "in_reply_to_status_id" : 154071001779552257,
  "created_at" : "2012-01-03 05:38:11 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt MattTodd Todd",
      "screen_name" : "mtodd",
      "indices" : [ 0, 6 ],
      "id_str" : "5933482",
      "id" : 5933482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154070104752136192",
  "geo" : { },
  "id_str" : "154070352845221889",
  "in_reply_to_user_id" : 5933482,
  "text" : "@mtodd I was hoping for a sextant or compass, that doesn't count",
  "id" : 154070352845221889,
  "in_reply_to_status_id" : 154070104752136192,
  "created_at" : "2012-01-03 05:23:29 +0000",
  "in_reply_to_screen_name" : "mtodd",
  "in_reply_to_user_id_str" : "5933482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Hariharan",
      "screen_name" : "hkarthik",
      "indices" : [ 0, 9 ],
      "id_str" : "4514261",
      "id" : 4514261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154067960653287424",
  "in_reply_to_user_id" : 4514261,
  "text" : "@hkarthik We used to be gone 8-9 hours too when in Boston, working from home has worsened his anxiety :(",
  "id" : 154067960653287424,
  "created_at" : "2012-01-03 05:13:58 +0000",
  "in_reply_to_screen_name" : "hkarthik",
  "in_reply_to_user_id_str" : "4514261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Hariharan",
      "screen_name" : "hkarthik",
      "indices" : [ 0, 9 ],
      "id_str" : "4514261",
      "id" : 4514261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154066983682449408",
  "geo" : { },
  "id_str" : "154067280781787136",
  "in_reply_to_user_id" : 4514261,
  "text" : "@hkarthik it's really easy, I think we just were gone for too long (just under 6 hours)",
  "id" : 154067280781787136,
  "in_reply_to_status_id" : 154066983682449408,
  "created_at" : "2012-01-03 05:11:16 +0000",
  "in_reply_to_screen_name" : "hkarthik",
  "in_reply_to_user_id_str" : "4514261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153957376121253889",
  "geo" : { },
  "id_str" : "154066996017897472",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene very sure this is due to no API for setting that link, and no metadata in the gemspec",
  "id" : 154066996017897472,
  "in_reply_to_status_id" : 153957376121253889,
  "created_at" : "2012-01-03 05:10:08 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nap.tld, ltd.",
      "screen_name" : "zapnap",
      "indices" : [ 0, 7 ],
      "id_str" : "1566201",
      "id" : 1566201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154065203108118528",
  "geo" : { },
  "id_str" : "154065865271287808",
  "in_reply_to_user_id" : 1566201,
  "text" : "@zapnap it was working wonders when having folks over, he just gets destructive when alone. On his second metal crate now.",
  "id" : 154065865271287808,
  "in_reply_to_status_id" : 154065203108118528,
  "created_at" : "2012-01-03 05:05:39 +0000",
  "in_reply_to_screen_name" : "zapnap",
  "in_reply_to_user_id_str" : "1566201",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThunderShirt",
      "screen_name" : "ThunderShirt",
      "indices" : [ 4, 17 ],
      "id_str" : "50336688",
      "id" : 50336688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154065616205135874",
  "text" : "Hey @thundershirt any chance of a replacement for one stressed out husky that wrecked his shirt after 2 weeks? :(",
  "id" : 154065616205135874,
  "created_at" : "2012-01-03 05:04:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154065038762713088",
  "text" : "Well, the thundershirt lasted 2 weeks, Ged just tore it apart in his crate tonight. Dog separation anxiety FTL.",
  "id" : 154065038762713088,
  "created_at" : "2012-01-03 05:02:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/DNy1xWyT",
      "expanded_url" : "http:\/\/path.com\/p\/4D8sPd",
      "display_url" : "path.com\/p\/4D8sPd"
    } ]
  },
  "geo" : { },
  "id_str" : "154056952975065088",
  "text" : "39 points, lost by 1 point to Amanda!! (with Amanda) [pic] \u2014 http:\/\/t.co\/DNy1xWyT",
  "id" : 154056952975065088,
  "created_at" : "2012-01-03 04:30:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154036167958986752",
  "text" : "STRAWMAN ARGUMENT WHY RAILS IS DEAD\/STUPID\/OLD, APOLOGY FOR PAST PAID WORK USING SAID FRAMEWORK, TROLL BAIT SPRINKLED WITH KARMA WHORING",
  "id" : 154036167958986752,
  "created_at" : "2012-01-03 03:07:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 11, 20 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154028443896520704",
  "geo" : { },
  "id_str" : "154034340878221312",
  "in_reply_to_user_id" : 372319943,
  "text" : "@A_R_Q_522 @bquarant why stop there? Dream big. Get a barista too.",
  "id" : 154034340878221312,
  "in_reply_to_status_id" : 154028443896520704,
  "created_at" : "2012-01-03 03:00:23 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/Xkh4Buf0",
      "expanded_url" : "http:\/\/path.com\/p\/8uYzp",
      "display_url" : "path.com\/p\/8uYzp"
    } ]
  },
  "geo" : { },
  "id_str" : "153999322877399043",
  "text" : "First pandemic: rousing success ! (with Amanda) [pic] \u2014 http:\/\/t.co\/Xkh4Buf0",
  "id" : 153999322877399043,
  "created_at" : "2012-01-03 00:41:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 3, 13 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/8V9dPEhN",
      "expanded_url" : "http:\/\/ngauthier.com\/2012\/01\/open-for-business.html",
      "display_url" : "ngauthier.com\/2012\/01\/open-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "153920467789549568",
  "text" : "RT @ngauthier: Hello 2012, I'm Open for Business! http:\/\/t.co\/8V9dPEhN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/8V9dPEhN",
        "expanded_url" : "http:\/\/ngauthier.com\/2012\/01\/open-for-business.html",
        "display_url" : "ngauthier.com\/2012\/01\/open-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "153920248586838016",
    "text" : "Hello 2012, I'm Open for Business! http:\/\/t.co\/8V9dPEhN",
    "id" : 153920248586838016,
    "created_at" : "2012-01-02 19:27:01 +0000",
    "user" : {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "protected" : false,
      "id_str" : "15243796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539452893112201217\/aJOphfgM_normal.png",
      "id" : 15243796,
      "verified" : false
    }
  },
  "id" : 153920467789549568,
  "created_at" : "2012-01-02 19:27:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153918832476557314",
  "text" : "One of these days I want to ask someone with a Transformer sticker on their car what it transforms into.",
  "id" : 153918832476557314,
  "created_at" : "2012-01-02 19:21:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153907538314801153",
  "geo" : { },
  "id_str" : "153917490810994688",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie so basically, you guys hate ActionController",
  "id" : 153917490810994688,
  "in_reply_to_status_id" : 153907538314801153,
  "created_at" : "2012-01-02 19:16:04 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153906648518373376",
  "geo" : { },
  "id_str" : "153907376314003457",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie that seems a little excessive, how do they not all get out of sync?",
  "id" : 153907376314003457,
  "in_reply_to_status_id" : 153906648518373376,
  "created_at" : "2012-01-02 18:35:52 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Williams",
      "screen_name" : "mwilliams",
      "indices" : [ 0, 10 ],
      "id_str" : "1259861",
      "id" : 1259861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153905154666676224",
  "geo" : { },
  "id_str" : "153905917807706113",
  "in_reply_to_user_id" : 1259861,
  "text" : "@mwilliams sounds like way more for one night!",
  "id" : 153905917807706113,
  "in_reply_to_status_id" : 153905154666676224,
  "created_at" : "2012-01-02 18:30:04 +0000",
  "in_reply_to_screen_name" : "mwilliams",
  "in_reply_to_user_id_str" : "1259861",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/ZxzoFKFx",
      "expanded_url" : "http:\/\/www.chrissawyergames.com\/faq3.htm",
      "display_url" : "chrissawyergames.com\/faq3.htm"
    } ]
  },
  "geo" : { },
  "id_str" : "153895738328363008",
  "text" : "Also ridiculous: Rollercoaster Tycoon was \"99% written in x86 assembler\/machine code (yes, really!)\" http:\/\/t.co\/ZxzoFKFx",
  "id" : 153895738328363008,
  "created_at" : "2012-01-02 17:49:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/ERKEnyuH",
      "expanded_url" : "http:\/\/i.imgur.com\/DcxJI.png",
      "display_url" : "i.imgur.com\/DcxJI.png"
    } ]
  },
  "geo" : { },
  "id_str" : "153895178862739456",
  "text" : "Oh, how I miss Rollercoaster Tycoon. Tried playing it again a few years ago and it didn't have the same effect. http:\/\/t.co\/ERKEnyuH",
  "id" : 153895178862739456,
  "created_at" : "2012-01-02 17:47:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153892317969911809",
  "text" : "The short SHA for the commit I'm working on is a239b00b. Finding this way too funny for my own good.",
  "id" : 153892317969911809,
  "created_at" : "2012-01-02 17:36:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 90, 97 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/Ri0d4OlH",
      "expanded_url" : "http:\/\/www.southparkstudios.com\/clips\/154854\/stans-speech",
      "display_url" : "southparkstudios.com\/clips\/154854\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "153882552917164032",
  "text" : "We're using the power of rock and roll to change the world! Woo! http:\/\/t.co\/Ri0d4OlH \/cc @Croaky",
  "id" : 153882552917164032,
  "created_at" : "2012-01-02 16:57:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3055\u308A",
      "screen_name" : "hiro_asari",
      "indices" : [ 0, 11 ],
      "id_str" : "14284130",
      "id" : 14284130
    }, {
      "name" : "Steven Haddox",
      "screen_name" : "stevenhaddox",
      "indices" : [ 12, 25 ],
      "id_str" : "2563828880",
      "id" : 2563828880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153659231789260800",
  "geo" : { },
  "id_str" : "153714910776397824",
  "in_reply_to_user_id" : 14284130,
  "text" : "@hiro_asari @stevenhaddox if you want to help, get involved, in IRC, and more. Lots of talk, no action, and things don't get improved.",
  "id" : 153714910776397824,
  "in_reply_to_status_id" : 153659231789260800,
  "created_at" : "2012-01-02 05:51:05 +0000",
  "in_reply_to_screen_name" : "hiro_asari",
  "in_reply_to_user_id_str" : "14284130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153694554120392705",
  "geo" : { },
  "id_str" : "153713634068021249",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene yes, many gems from the ruby forge era have stupid names. Oh wait, still true :)",
  "id" : 153713634068021249,
  "in_reply_to_status_id" : 153694554120392705,
  "created_at" : "2012-01-02 05:46:00 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153688488074674176",
  "geo" : { },
  "id_str" : "153690830597660672",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene because there's... A lot. We could cache it though. For now, gem list -a -r (read up on Gem::RemoteFetcher)",
  "id" : 153690830597660672,
  "in_reply_to_status_id" : 153688488074674176,
  "created_at" : "2012-01-02 04:15:24 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 10, 20 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153687200817618944",
  "geo" : { },
  "id_str" : "153688322630352896",
  "in_reply_to_user_id" : 23621187,
  "text" : "@Schneems @aquaranto haha mostly just general zombie stuff, nothing specific. Lots of zombie murder.",
  "id" : 153688322630352896,
  "in_reply_to_status_id" : 153687200817618944,
  "created_at" : "2012-01-02 04:05:26 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 42, 52 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153686040190779393",
  "text" : "Started to design a zombie card game with @aquaranto tonight. Definitely a fun process, excited to make some cards and play it!",
  "id" : 153686040190779393,
  "created_at" : "2012-01-02 03:56:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Upton",
      "screen_name" : "uptonic",
      "indices" : [ 0, 8 ],
      "id_str" : "14408469",
      "id" : 14408469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153667012655194113",
  "geo" : { },
  "id_str" : "153669718165815297",
  "in_reply_to_user_id" : 14408469,
  "text" : "@uptonic my problem with most of these fancy in browser slide deck libs is that you spend more time messing with them than writing your talk",
  "id" : 153669718165815297,
  "in_reply_to_status_id" : 153667012655194113,
  "created_at" : "2012-01-02 02:51:30 +0000",
  "in_reply_to_screen_name" : "uptonic",
  "in_reply_to_user_id_str" : "14408469",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/SInV8TU0",
      "expanded_url" : "http:\/\/instagr.am\/p\/drTka\/",
      "display_url" : "instagr.am\/p\/drTka\/"
    } ]
  },
  "geo" : { },
  "id_str" : "153611742503649281",
  "text" : "Abraham what? http:\/\/t.co\/SInV8TU0",
  "id" : 153611742503649281,
  "created_at" : "2012-01-01 23:01:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153536756594114561",
  "geo" : { },
  "id_str" : "153546298753155072",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton the Bills what now?",
  "id" : 153546298753155072,
  "in_reply_to_status_id" : 153536756594114561,
  "created_at" : "2012-01-01 18:41:05 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 15, 21 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/Caa5Zojq",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=51LeCswsTMw",
      "display_url" : "youtube.com\/watch?v=51LeCs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "153544982437961728",
  "text" : "Great video of @Phish's NYE gag, lots of floating people, balloons, and guitar players! http:\/\/t.co\/Caa5Zojq",
  "id" : 153544982437961728,
  "created_at" : "2012-01-01 18:35:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/Ejb25OKn",
      "expanded_url" : "http:\/\/cheezcomixed.files.wordpress.com\/2011\/12\/koma-comic-strip-just-a-heads-up.jpg",
      "display_url" : "cheezcomixed.files.wordpress.com\/2011\/12\/koma-c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "153482114891923456",
  "geo" : { },
  "id_str" : "153482354114048000",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius http:\/\/t.co\/Ejb25OKn",
  "id" : 153482354114048000,
  "in_reply_to_status_id" : 153482114891923456,
  "created_at" : "2012-01-01 14:26:59 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153481050595663872",
  "geo" : { },
  "id_str" : "153481197094322176",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm rsync and round robin DNS has proven itself to be terribly slow and unreliable, that's how rubyforge mirrors used to work",
  "id" : 153481197094322176,
  "in_reply_to_status_id" : 153481050595663872,
  "created_at" : "2012-01-01 14:22:23 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/bdjxoR36",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "153480441091989504",
  "geo" : { },
  "id_str" : "153480781795307520",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm no, i think just a completely mirrored\/cached site for fetching gems, use http:\/\/t.co\/bdjxoR36 as a web frontend only",
  "id" : 153480781795307520,
  "in_reply_to_status_id" : 153480441091989504,
  "created_at" : "2012-01-01 14:20:44 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/4Nagg3uU",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/2729333530\/fetching-source-index-for-http-rubygems-org",
      "display_url" : "robots.thoughtbot.com\/post\/272933353\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "153480539096092672",
  "text" : "Better mirroring was one of my goals for 2011 that I didn't get to. I'd really appreciate any help in 2012. http:\/\/t.co\/4Nagg3uU",
  "id" : 153480539096092672,
  "created_at" : "2012-01-01 14:19:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153480348053938176",
  "text" : "We're back up. I think we need a better gem source that people can rely on, no matter if our databases work or not.",
  "id" : 153480348053938176,
  "created_at" : "2012-01-01 14:19:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 104, 113 ],
      "id_str" : "729936824",
      "id" : 729936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 88 ],
      "url" : "https:\/\/t.co\/n0j2SfQq",
      "expanded_url" : "https:\/\/gist.github.com\/806216aab92a8bf04f05",
      "display_url" : "gist.github.com\/806216aab92a8b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "153479926799011840",
  "text" : "Full error log of what happened to postgres, really strange stuff. https:\/\/t.co\/n0j2SfQq Any ideas? \/cc @hgimenez",
  "id" : 153479926799011840,
  "created_at" : "2012-01-01 14:17:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/DsTsC8dX",
      "expanded_url" : "http:\/\/images.wikia.com\/finalfantasy\/images\/6\/60\/Facepalm.png",
      "display_url" : "images.wikia.com\/finalfantasy\/i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "153473947185315841",
  "geo" : { },
  "id_str" : "153479133706469376",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu http:\/\/t.co\/DsTsC8dX",
  "id" : 153479133706469376,
  "in_reply_to_status_id" : 153473947185315841,
  "created_at" : "2012-01-01 14:14:11 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Haddox",
      "screen_name" : "stevenhaddox",
      "indices" : [ 0, 13 ],
      "id_str" : "2563828880",
      "id" : 2563828880
    }, {
      "name" : "Devdatta Kane",
      "screen_name" : "devdatta",
      "indices" : [ 14, 23 ],
      "id_str" : "14257769",
      "id" : 14257769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153479027225673728",
  "text" : "@stevenhaddox @devdatta back up, sorry guys.",
  "id" : 153479027225673728,
  "created_at" : "2012-01-01 14:13:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153475757950251009",
  "text" : "RT @gemcutter: Looks like postgresql partied too hard last night and crashed. Happy New Year!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153475728367828994",
    "text" : "Looks like postgresql partied too hard last night and crashed. Happy New Year!",
    "id" : 153475728367828994,
    "created_at" : "2012-01-01 14:00:39 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 153475757950251009,
  "created_at" : "2012-01-01 14:00:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153473909319143424",
  "text" : "Looks like Postgres died? This isn't good.",
  "id" : 153473909319143424,
  "created_at" : "2012-01-01 13:53:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 24, 34 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153473405226713088",
  "text" : "Awake, looking into the @gemcutter problems. Hold on folks.",
  "id" : 153473405226713088,
  "created_at" : "2012-01-01 13:51:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
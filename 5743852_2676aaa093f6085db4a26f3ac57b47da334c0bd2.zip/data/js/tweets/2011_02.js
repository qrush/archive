Grailbird.data.tweets_2011_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42315349298913280",
  "text" : "Apparently you can play Doom on the Virgin America TV's?! Awesome.",
  "id" : 42315349298913280,
  "created_at" : "2011-02-28 20:09:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "indices" : [ 0, 13 ],
      "id_str" : "1341781",
      "id" : 1341781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42299471094222848",
  "geo" : { },
  "id_str" : "42300643888730112",
  "in_reply_to_user_id" : 1341781,
  "text" : "@gilesgoatboy Any specific problems you can name? Obviously it has issues but bundler + gemcutter have improved things. Can only get better.",
  "id" : 42300643888730112,
  "in_reply_to_status_id" : 42299471094222848,
  "created_at" : "2011-02-28 19:10:34 +0000",
  "in_reply_to_screen_name" : "gilesgoatboy",
  "in_reply_to_user_id_str" : "1341781",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "indices" : [ 0, 13 ],
      "id_str" : "1341781",
      "id" : 1341781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41983363573092352",
  "geo" : { },
  "id_str" : "42290456175972352",
  "in_reply_to_user_id" : 1341781,
  "text" : "@gilesgoatboy seriously dude?",
  "id" : 42290456175972352,
  "in_reply_to_status_id" : 41983363573092352,
  "created_at" : "2011-02-28 18:30:05 +0000",
  "in_reply_to_screen_name" : "gilesgoatboy",
  "in_reply_to_user_id_str" : "1341781",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42290331198296064",
  "text" : "New favorite webservice: http:\/\/placekitten.com\/",
  "id" : 42290331198296064,
  "created_at" : "2011-02-28 18:29:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42145527793590272",
  "geo" : { },
  "id_str" : "42290292547780608",
  "in_reply_to_user_id" : 44097930,
  "text" : "@deniszgonjanin Thanks! just used Keynote.",
  "id" : 42290292547780608,
  "in_reply_to_status_id" : 42145527793590272,
  "created_at" : "2011-02-28 18:29:26 +0000",
  "in_reply_to_screen_name" : "zgonj",
  "in_reply_to_user_id_str" : "44097930",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42061130985766912",
  "text" : "Oh man, this autotune video has Autotune the News all over it.",
  "id" : 42061130985766912,
  "created_at" : "2011-02-28 03:18:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    }, {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 31, 38 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42056898102562816",
  "geo" : { },
  "id_str" : "42058773707235328",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic thanks!! huge thanks to @peterc for getting me started on the graphs",
  "id" : 42058773707235328,
  "in_reply_to_status_id" : 42056898102562816,
  "created_at" : "2011-02-28 03:09:27 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 15, 29 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42056585479979008",
  "text" : "i dub thee the @joshuaclayton button http:\/\/inception.davepedu.com\/",
  "id" : 42056585479979008,
  "created_at" : "2011-02-28 03:00:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Graham",
      "screen_name" : "grahams",
      "indices" : [ 0, 8 ],
      "id_str" : "758727",
      "id" : 758727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42053407351115776",
  "geo" : { },
  "id_str" : "42056514428469248",
  "in_reply_to_user_id" : 758727,
  "text" : "@grahams BAWWWWWWWWW",
  "id" : 42056514428469248,
  "in_reply_to_status_id" : 42053407351115776,
  "created_at" : "2011-02-28 03:00:29 +0000",
  "in_reply_to_screen_name" : "grahams",
  "in_reply_to_user_id_str" : "758727",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "janey!",
      "screen_name" : "janeylicious",
      "indices" : [ 0, 13 ],
      "id_str" : "6310822",
      "id" : 6310822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42020167001186304",
  "geo" : { },
  "id_str" : "42043562279305216",
  "in_reply_to_user_id" : 6310822,
  "text" : "@janeylicious thanks!",
  "id" : 42043562279305216,
  "in_reply_to_status_id" : 42020167001186304,
  "created_at" : "2011-02-28 02:09:01 +0000",
  "in_reply_to_screen_name" : "janeylicious",
  "in_reply_to_user_id_str" : "6310822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scale9x",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42042080503144448",
  "text" : "Thanks for sticking around to the end of #scale9x for my Redis talk! Here's the slides: http:\/\/bit.ly\/redis-data-cheeseburgers",
  "id" : 42042080503144448,
  "created_at" : "2011-02-28 02:03:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    }, {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 11, 21 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42010100130529280",
  "geo" : { },
  "id_str" : "42010698955501568",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything @jbarnette i'm convinced ri\/local docs are used by a minority of ruby devs. I'd rather code for 90% of people instead of 10%",
  "id" : 42010698955501568,
  "in_reply_to_status_id" : 42010100130529280,
  "created_at" : "2011-02-27 23:58:25 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42008296101650432",
  "text" : "Oh boy, I can't wait until I'm old and I get to be crotchety about new languages",
  "id" : 42008296101650432,
  "created_at" : "2011-02-27 23:48:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 31, 40 ],
      "id_str" : "148198686",
      "id" : 148198686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41955271299305472",
  "text" : "Moving several domains over to @dnsimple and getting the hell off godaddy. They even make moving off stupidly difficult and complex.",
  "id" : 41955271299305472,
  "created_at" : "2011-02-27 20:18:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theydeserveit",
      "indices" : [ 49, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41952912590651392",
  "text" : "Huge troll in the MySQL talk shittalkin' Oracle. #theydeserveit",
  "id" : 41952912590651392,
  "created_at" : "2011-02-27 20:08:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 22, 31 ],
      "id_str" : "148198686",
      "id" : 148198686
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 45, 55 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41932919060570112",
  "text" : "Wow, about 10 million @dnsimple requests for @gemcutter in the last 30 days. http:\/\/is.gd\/NYYQou",
  "id" : 41932919060570112,
  "created_at" : "2011-02-27 18:49:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41927060964388864",
  "text" : "# FIX: holy shit this is dumb http:\/\/is.gd\/wMvX2S",
  "id" : 41927060964388864,
  "created_at" : "2011-02-27 18:26:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41926239778246656",
  "text" : "Interrupting a keynote talk: CRUISE CONTROL FOR COOL",
  "id" : 41926239778246656,
  "created_at" : "2011-02-27 18:22:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scale9x",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41920827435917312",
  "text" : "Adjusting too quickly to PST, not good. Up for another day of #scale9x!",
  "id" : 41920827435917312,
  "created_at" : "2011-02-27 18:01:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Grosser",
      "screen_name" : "grosser",
      "indices" : [ 0, 8 ],
      "id_str" : "18628850",
      "id" : 18628850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41765390849679360",
  "geo" : { },
  "id_str" : "41766750286647296",
  "in_reply_to_user_id" : 18628850,
  "text" : "@grosser eh? can you open a request on help.rubygems.org about it with your gem\/gemspec?",
  "id" : 41766750286647296,
  "in_reply_to_status_id" : 41765390849679360,
  "created_at" : "2011-02-27 07:49:03 +0000",
  "in_reply_to_screen_name" : "grosser",
  "in_reply_to_user_id_str" : "18628850",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41705513519423488",
  "text" : "LA: Land of Parking Garages",
  "id" : 41705513519423488,
  "created_at" : "2011-02-27 03:45:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41699318008127488",
  "text" : "Going to King's Head, any LA folks up for drinks?",
  "id" : 41699318008127488,
  "created_at" : "2011-02-27 03:21:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter van Hardenberg",
      "screen_name" : "pvh",
      "indices" : [ 0, 4 ],
      "id_str" : "15532680",
      "id" : 15532680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41693153048272896",
  "geo" : { },
  "id_str" : "41693607136075776",
  "in_reply_to_user_id" : 15532680,
  "text" : "@pvh haha no, it was a dude who was presenting! I would terminate that instance pronto, bad mojo there",
  "id" : 41693607136075776,
  "in_reply_to_status_id" : 41693153048272896,
  "created_at" : "2011-02-27 02:58:25 +0000",
  "in_reply_to_screen_name" : "pvh",
  "in_reply_to_user_id_str" : "15532680",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41693121683136512",
  "text" : "OH: \"I wanted to say 'Fuck off and die' but instead I said we don't sell anything\"",
  "id" : 41693121683136512,
  "created_at" : "2011-02-27 02:56:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scale9x",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41688075625168896",
  "text" : "Whaaat, just provisioned i-00000001 on ec2 with Chef. How does it work?! #scale9x",
  "id" : 41688075625168896,
  "created_at" : "2011-02-27 02:36:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 0, 12 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41603338554458112",
  "geo" : { },
  "id_str" : "41660743753543680",
  "in_reply_to_user_id" : 5716862,
  "text" : "@tristandunn dude :( when?",
  "id" : 41660743753543680,
  "in_reply_to_status_id" : 41603338554458112,
  "created_at" : "2011-02-27 00:47:49 +0000",
  "in_reply_to_screen_name" : "tristandunn",
  "in_reply_to_user_id_str" : "5716862",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    }, {
      "name" : "Kyle Wild",
      "screen_name" : "dorkitude",
      "indices" : [ 8, 18 ],
      "id_str" : "12626542",
      "id" : 12626542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41658302052040704",
  "geo" : { },
  "id_str" : "41659051464990720",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh @dorkitude check out \"The Ring\" section here for W, R, N. http:\/\/wiki.basho.com\/How-Things-Work.html",
  "id" : 41659051464990720,
  "in_reply_to_status_id" : 41658302052040704,
  "created_at" : "2011-02-27 00:41:06 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "usethebesttool",
      "indices" : [ 115, 130 ]
    }, {
      "text" : "scale9x",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41649062109388800",
  "text" : "Asked re: membase vs riak in regards to the WRN problem: membase doesn't handle it, meant for more transient data. #usethebesttool #scale9x",
  "id" : 41649062109388800,
  "created_at" : "2011-02-27 00:01:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John E. Vincent",
      "screen_name" : "lusis",
      "indices" : [ 0, 6 ],
      "id_str" : "14586723",
      "id" : 14586723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41641478539329536",
  "geo" : { },
  "id_str" : "41645918956560384",
  "in_reply_to_user_id" : 14586723,
  "text" : "@lusis this is just on membase, we've heard nothing about couch",
  "id" : 41645918956560384,
  "in_reply_to_status_id" : 41641478539329536,
  "created_at" : "2011-02-26 23:48:55 +0000",
  "in_reply_to_screen_name" : "lusis",
  "in_reply_to_user_id_str" : "14586723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StylePedant.erl",
      "screen_name" : "seancribbs",
      "indices" : [ 0, 11 ],
      "id_str" : "14939200",
      "id" : 14939200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41643683375890432",
  "geo" : { },
  "id_str" : "41645776018866176",
  "in_reply_to_user_id" : 14939200,
  "text" : "@seancribbs lol open source'd",
  "id" : 41645776018866176,
  "in_reply_to_status_id" : 41643683375890432,
  "created_at" : "2011-02-26 23:48:21 +0000",
  "in_reply_to_screen_name" : "seancribbs",
  "in_reply_to_user_id_str" : "14939200",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41644810448142336",
  "text" : "Membase's cluster support looks awesome, especially their web UI. redis-cluster has a long way to go to catch up to this.",
  "id" : 41644810448142336,
  "created_at" : "2011-02-26 23:44:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41639574262251520",
  "text" : "Membase is sounding a lot like Riak...erlang backend, vector clocks, k\/v store... am I missing something big here?",
  "id" : 41639574262251520,
  "created_at" : "2011-02-26 23:23:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scale9x",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41635641028517888",
  "text" : "Time for some membasin'! Definitely want to see how it's different from memcached and redis. #scale9x",
  "id" : 41635641028517888,
  "created_at" : "2011-02-26 23:08:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scale9x",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41589268388380672",
  "text" : "ok, big advantage in that byobu has an ncurses configuration interface. reliance on F keys sucks. seems *really* server oriented. #scale9x",
  "id" : 41589268388380672,
  "created_at" : "2011-02-26 20:03:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scale9x",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41586407474597888",
  "text" : "byabo seems like a huge improvement over normal screen (just a ton of config\/scripts for it), but not over tmux. #scale9x",
  "id" : 41586407474597888,
  "created_at" : "2011-02-26 19:52:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scale9x",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41561253432262656",
  "text" : "Waiting for the #scale9x keynote to start, apparently the boot process wasn't documented :)",
  "id" : 41561253432262656,
  "created_at" : "2011-02-26 18:12:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klondike Gold",
      "screen_name" : "Klondike",
      "indices" : [ 0, 9 ],
      "id_str" : "298070410",
      "id" : 298070410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41558955268390912",
  "geo" : { },
  "id_str" : "41559550058299392",
  "in_reply_to_user_id" : 5232171,
  "text" : "@Klondike dealing with exceptions? ;)",
  "id" : 41559550058299392,
  "in_reply_to_status_id" : 41558955268390912,
  "created_at" : "2011-02-26 18:05:43 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scale9x",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41539691501064192",
  "text" : "Psyched for day 1 of #scale9x, lots of learning incoming: byobu, membase, openstack, and more! :D",
  "id" : 41539691501064192,
  "created_at" : "2011-02-26 16:46:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41538704354967552",
  "geo" : { },
  "id_str" : "41539235249000448",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv just as I was thinking the LA skyline would be more fun with aliens\/monsters or a volcano",
  "id" : 41539235249000448,
  "in_reply_to_status_id" : 41538704354967552,
  "created_at" : "2011-02-26 16:45:00 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scale9x",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41327618410287104",
  "text" : "Nooo, battery dying and approaching the South Dakota border. Pumped for #scale9x, anyone gonna be there tomorrow?",
  "id" : 41327618410287104,
  "created_at" : "2011-02-26 02:44:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicol\u00E1s Hock Isaza",
      "screen_name" : "nhocki",
      "indices" : [ 0, 7 ],
      "id_str" : "85498700",
      "id" : 85498700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41312740194787328",
  "geo" : { },
  "id_str" : "41325377808908289",
  "in_reply_to_user_id" : 85498700,
  "text" : "@nhocki you have to uncomment the mysql driver in the Gemfile (and comment out pg) ...why can't you just use postgres? :(",
  "id" : 41325377808908289,
  "in_reply_to_status_id" : 41312740194787328,
  "created_at" : "2011-02-26 02:35:12 +0000",
  "in_reply_to_screen_name" : "nhocki",
  "in_reply_to_user_id_str" : "85498700",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 24, 34 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41306612106924033",
  "text" : "Over 70 contributors to @gemcutter now! Thanks for the hard work, folks. (And if you want commit rights say so!) http:\/\/is.gd\/N6RZl0",
  "id" : 41306612106924033,
  "created_at" : "2011-02-26 01:20:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 6, 13 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41304354803810304",
  "text" : "heyyy @elight more comments for you, sorry about the delay and being a pain",
  "id" : 41304354803810304,
  "created_at" : "2011-02-26 01:11:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 10, 29 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41300747710627840",
  "geo" : { },
  "id_str" : "41303149331353600",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil #firstworldproblems",
  "id" : 41303149331353600,
  "in_reply_to_status_id" : 41300747710627840,
  "created_at" : "2011-02-26 01:06:52 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 0, 6 ],
      "id_str" : "1438261",
      "id" : 1438261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41295354053787648",
  "geo" : { },
  "id_str" : "41296586612936705",
  "in_reply_to_user_id" : 1438261,
  "text" : "@atmos i think geolocate is messed up, but i'm headed to scale9x. somewhere over Toronto now.",
  "id" : 41296586612936705,
  "in_reply_to_status_id" : 41295354053787648,
  "created_at" : "2011-02-26 00:40:48 +0000",
  "in_reply_to_screen_name" : "atmos",
  "in_reply_to_user_id_str" : "1438261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41296391745576960",
  "text" : "GIT PUSH ON A PLANE. What now!?",
  "id" : 41296391745576960,
  "created_at" : "2011-02-26 00:40:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 48, 58 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/UCp3du9",
      "expanded_url" : "http:\/\/blog.websolr.com\/post\/3505903537\/rubygems-search-upgrade-1",
      "display_url" : "blog.websolr.com\/post\/350590353\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "41295135564107776",
  "text" : "Seriously good writeup of integrating Solr into @gemcutter. I need to merge some code soon, thanks @nzadrozny! http:\/\/t.co\/UCp3du9",
  "id" : 41295135564107776,
  "created_at" : "2011-02-26 00:35:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41258884026994688",
  "geo" : { },
  "id_str" : "41265743920111616",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn i saw your doppleganger on the way here. I almost made a snarky comment but stopped at the last moment. AWKWARD",
  "id" : 41265743920111616,
  "in_reply_to_status_id" : 41258884026994688,
  "created_at" : "2011-02-25 22:38:14 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41258421881815040",
  "text" : "Virgin has their own gate and security line with no wait at Logan. Awesome.",
  "id" : 41258421881815040,
  "created_at" : "2011-02-25 22:09:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Elliott",
      "screen_name" : "p_elliott",
      "indices" : [ 0, 10 ],
      "id_str" : "18047782",
      "id" : 18047782
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 62, 72 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41248618484604928",
  "geo" : { },
  "id_str" : "41250773740437504",
  "in_reply_to_user_id" : 18047782,
  "text" : "@p_elliott yikes what happened? Fog's s3 stuff works great on @gemcutter",
  "id" : 41250773740437504,
  "in_reply_to_status_id" : 41248618484604928,
  "created_at" : "2011-02-25 21:38:45 +0000",
  "in_reply_to_screen_name" : "p_elliott",
  "in_reply_to_user_id_str" : "18047782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41238462472527872",
  "text" : "Current status: http:\/\/i.imgur.com\/p5zFs.gif",
  "id" : 41238462472527872,
  "created_at" : "2011-02-25 20:49:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scale9x",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41225579130920960",
  "text" : "Excited to head out soon for #scale9x! Worried that I'll have the only Mac there D:",
  "id" : 41225579130920960,
  "created_at" : "2011-02-25 19:58:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 0, 9 ],
      "id_str" : "14925480",
      "id" : 14925480
    }, {
      "name" : "Jason Haruska",
      "screen_name" : "haruska",
      "indices" : [ 10, 18 ],
      "id_str" : "9865602",
      "id" : 9865602
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 19, 31 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41182248325754880",
  "geo" : { },
  "id_str" : "41186162278273024",
  "in_reply_to_user_id" : 14925480,
  "text" : "@nirvdrum @haruska @bcardarella the bundler guys were actually given a lot of heads up on it. Get involved more with RG if you want change.",
  "id" : 41186162278273024,
  "in_reply_to_status_id" : 41182248325754880,
  "created_at" : "2011-02-25 17:22:00 +0000",
  "in_reply_to_screen_name" : "nirvdrum",
  "in_reply_to_user_id_str" : "14925480",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40999564785885184",
  "text" : "When's the last time you actually used ri or gem server to read docs? If I need docs, I go to rubydoc.info, or READ CODE.",
  "id" : 40999564785885184,
  "created_at" : "2011-02-25 05:00:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40997905187876864",
  "text" : "Still on WordFeud as qrush, challenge me up there instead!",
  "id" : 40997905187876864,
  "created_at" : "2011-02-25 04:53:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40997647896674304",
  "text" : "Uninstalling Words with Friends for Android. Forcing ads after every move, very loud spanish ads for Disney Parks are the last straw.",
  "id" : 40997647896674304,
  "created_at" : "2011-02-25 04:52:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40964553797939200",
  "text" : "Current status: http:\/\/i.imgur.com\/OoiTn.jpg",
  "id" : 40964553797939200,
  "created_at" : "2011-02-25 02:41:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40906224543350784",
  "text" : "Current status: http:\/\/i.imgur.com\/BgIzd.jpg",
  "id" : 40906224543350784,
  "created_at" : "2011-02-24 22:49:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 3, 13 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40805533078261760",
  "text" : "RT @joeferris: technical details on copycopter_client with a focus on performance: http:\/\/bit.ly\/gcPvcf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40802763906490368",
    "text" : "technical details on copycopter_client with a focus on performance: http:\/\/bit.ly\/gcPvcf",
    "id" : 40802763906490368,
    "created_at" : "2011-02-24 15:58:31 +0000",
    "user" : {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "protected" : false,
      "id_str" : "14575143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518019567\/jferris-square_normal.jpg",
      "id" : 14575143,
      "verified" : false
    }
  },
  "id" : 40805533078261760,
  "created_at" : "2011-02-24 16:09:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josiah Kiehl",
      "screen_name" : "bluepojo",
      "indices" : [ 0, 9 ],
      "id_str" : "327477172",
      "id" : 327477172
    }, {
      "name" : "Erik Hollensbe",
      "screen_name" : "erikhollensbe",
      "indices" : [ 10, 24 ],
      "id_str" : "1497113923",
      "id" : 1497113923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40520596991246336",
  "geo" : { },
  "id_str" : "40526216351977472",
  "in_reply_to_user_id" : 14464631,
  "text" : "@BluePojo @erikhollensbe you guys need to hook up some middleware to redirect to one domain so google loves us. +1 test.rubygems.org",
  "id" : 40526216351977472,
  "in_reply_to_status_id" : 40520596991246336,
  "created_at" : "2011-02-23 21:39:37 +0000",
  "in_reply_to_screen_name" : "CapoFerro",
  "in_reply_to_user_id_str" : "14464631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40524036727382017",
  "geo" : { },
  "id_str" : "40525091255099392",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv dude twitter is not google image search",
  "id" : 40525091255099392,
  "in_reply_to_status_id" : 40524036727382017,
  "created_at" : "2011-02-23 21:35:09 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Kinney",
      "screen_name" : "j2fly",
      "indices" : [ 0, 6 ],
      "id_str" : "771575496",
      "id" : 771575496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40219147363155968",
  "geo" : { },
  "id_str" : "40223442326401024",
  "in_reply_to_user_id" : 14695434,
  "text" : "@j2fly watch the master exploder one or run to the hills",
  "id" : 40223442326401024,
  "in_reply_to_status_id" : 40219147363155968,
  "created_at" : "2011-02-23 01:36:30 +0000",
  "in_reply_to_screen_name" : "jondkinney",
  "in_reply_to_user_id_str" : "14695434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 5, 16 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40223090134876160",
  "text" : "Only @tenderlove can submit bug reports with YouTube videos with Madonna in the background. We need more of this. http:\/\/ln-s.net\/8YFm",
  "id" : 40223090134876160,
  "created_at" : "2011-02-23 01:35:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 87, 94 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40206773793193984",
  "text" : "Oh man, http:\/\/www.youtube.com\/user\/nevaklass has a ton of live Trey. Thanks for this, @croaky!",
  "id" : 40206773793193984,
  "created_at" : "2011-02-23 00:30:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40082330345422848",
  "text" : "Seriously. This guy ROCKS. http:\/\/www.youtube.com\/user\/elhombredeloskaraoke#p\/u\/16\/SXdIFKo6-9Y",
  "id" : 40082330345422848,
  "created_at" : "2011-02-22 16:15:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40080965602639872",
  "text" : "Someone get this guy a band and on stage. Holy crap. http:\/\/www.youtube.com\/user\/elhombredeloskaraoke",
  "id" : 40080965602639872,
  "created_at" : "2011-02-22 16:10:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39870570900365312",
  "text" : "Smuggled a loaf of bread on the plane back to Boston. Current status: toasty! http:\/\/yfrog.com\/h08u5jj",
  "id" : 39870570900365312,
  "created_at" : "2011-02-22 02:14:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 0, 10 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39518354771279872",
  "geo" : { },
  "id_str" : "39519671573155840",
  "in_reply_to_user_id" : 14575143,
  "text" : "@joeferris shouldn't you have a vim macro for this?",
  "id" : 39519671573155840,
  "in_reply_to_status_id" : 39518354771279872,
  "created_at" : "2011-02-21 02:59:58 +0000",
  "in_reply_to_screen_name" : "joeferris",
  "in_reply_to_user_id_str" : "14575143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39519427389161472",
  "text" : "Current status: https:\/\/img.skitch.com\/20110221-mxbdip9qhqttdpyqipc32kfhrn.png",
  "id" : 39519427389161472,
  "created_at" : "2011-02-21 02:59:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    }, {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 8, 15 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39508551969943552",
  "geo" : { },
  "id_str" : "39508818903842816",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox @tekkub uh...i haven't bought a single app on android. don't plan on doing so, ever",
  "id" : 39508818903842816,
  "in_reply_to_status_id" : 39508551969943552,
  "created_at" : "2011-02-21 02:16:51 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39504715871948800",
  "text" : "Oh geez, tons of requests. Worst part so far, Words with Friends forces an ad down your throat after every move...at least Wordfeud didn't.",
  "id" : 39504715871948800,
  "created_at" : "2011-02-21 02:00:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39493810094489600",
  "text" : "Trying out Words with Friends for Android. My username: \"qrush13\" BRING IT!",
  "id" : 39493810094489600,
  "created_at" : "2011-02-21 01:17:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Durham",
      "screen_name" : "jeremydurham",
      "indices" : [ 0, 13 ],
      "id_str" : "966341",
      "id" : 966341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39128273422127104",
  "geo" : { },
  "id_str" : "39132014233915392",
  "in_reply_to_user_id" : 966341,
  "text" : "@jeremydurham because C++ is fucking hard. Not sure about you but ruby is easier :)",
  "id" : 39132014233915392,
  "in_reply_to_status_id" : 39128273422127104,
  "created_at" : "2011-02-20 01:19:33 +0000",
  "in_reply_to_screen_name" : "jeremydurham",
  "in_reply_to_user_id_str" : "966341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39048814425800704",
  "text" : "Current status: http:\/\/yfrog.com\/h4tymdxj",
  "id" : 39048814425800704,
  "created_at" : "2011-02-19 19:48:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38827941144174592",
  "geo" : { },
  "id_str" : "38967729646084096",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic dude the sabres didn't even show up to play",
  "id" : 38967729646084096,
  "in_reply_to_status_id" : 38827941144174592,
  "created_at" : "2011-02-19 14:26:45 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38967036617043968",
  "text" : "Current status: http:\/\/30.media.tumblr.com\/tumblr_lfbujvLqv91qae5rmo1_500.gif",
  "id" : 38967036617043968,
  "created_at" : "2011-02-19 14:24:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38787391498100736",
  "geo" : { },
  "id_str" : "38790062820962304",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc .ini? What is this, Windows 95?",
  "id" : 38790062820962304,
  "in_reply_to_status_id" : 38787391498100736,
  "created_at" : "2011-02-19 02:40:46 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38766936569548800",
  "text" : "Seriously terrible font choice. Yes, at a sporting event this is what I care about. http:\/\/yfrog.com\/h0yhkitj",
  "id" : 38766936569548800,
  "created_at" : "2011-02-19 01:08:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brntbeer",
      "screen_name" : "brntbeer",
      "indices" : [ 0, 9 ],
      "id_str" : "14563437",
      "id" : 14563437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38760592646864896",
  "geo" : { },
  "id_str" : "38765791700725760",
  "in_reply_to_user_id" : 14563437,
  "text" : "@brntbeer yep!",
  "id" : 38765791700725760,
  "in_reply_to_status_id" : 38760592646864896,
  "created_at" : "2011-02-19 01:04:19 +0000",
  "in_reply_to_screen_name" : "brntbeer",
  "in_reply_to_user_id_str" : "14563437",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo DiNardi",
      "screen_name" : "adinardi",
      "indices" : [ 0, 9 ],
      "id_str" : "781929",
      "id" : 781929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38756413702406144",
  "geo" : { },
  "id_str" : "38759347664326656",
  "in_reply_to_user_id" : 781929,
  "text" : "@adinardi we've literally had recruiters begging for job applicants on boston.rb's list",
  "id" : 38759347664326656,
  "in_reply_to_status_id" : 38756413702406144,
  "created_at" : "2011-02-19 00:38:43 +0000",
  "in_reply_to_screen_name" : "adinardi",
  "in_reply_to_user_id_str" : "781929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38749703260737537",
  "text" : "MILLER TIME http:\/\/yfrog.com\/gyx2tej",
  "id" : 38749703260737537,
  "created_at" : "2011-02-19 00:00:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Richards",
      "screen_name" : "noahsmark",
      "indices" : [ 0, 10 ],
      "id_str" : "14198565",
      "id" : 14198565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38746057127108608",
  "geo" : { },
  "id_str" : "38748808666025984",
  "in_reply_to_user_id" : 14198565,
  "text" : "@noahsmark congrats!",
  "id" : 38748808666025984,
  "in_reply_to_status_id" : 38746057127108608,
  "created_at" : "2011-02-18 23:56:50 +0000",
  "in_reply_to_screen_name" : "noahsmark",
  "in_reply_to_user_id_str" : "14198565",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Richards",
      "screen_name" : "noahsmark",
      "indices" : [ 0, 10 ],
      "id_str" : "14198565",
      "id" : 14198565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38737361970020352",
  "geo" : { },
  "id_str" : "38745859734769664",
  "in_reply_to_user_id" : 14198565,
  "text" : "@noahsmark woo, about time! Where you going to?",
  "id" : 38745859734769664,
  "in_reply_to_status_id" : 38737361970020352,
  "created_at" : "2011-02-18 23:45:07 +0000",
  "in_reply_to_screen_name" : "noahsmark",
  "in_reply_to_user_id_str" : "14198565",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38708806968016896",
  "text" : "DO WANT http:\/\/imgur.com\/ikqZi",
  "id" : 38708806968016896,
  "created_at" : "2011-02-18 21:17:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38706725641003008",
  "text" : "EPIC WEDDING PLANNING TIME! And soonly, Sabres. Awesome weekend is awesome.",
  "id" : 38706725641003008,
  "created_at" : "2011-02-18 21:09:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 0, 13 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38576162590425088",
  "geo" : { },
  "id_str" : "38588396121100289",
  "in_reply_to_user_id" : 9645312,
  "text" : "@ferventcoder thanks!",
  "id" : 38588396121100289,
  "in_reply_to_status_id" : 38576162590425088,
  "created_at" : "2011-02-18 13:19:25 +0000",
  "in_reply_to_screen_name" : "ferventcoder",
  "in_reply_to_user_id_str" : "9645312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38440691344351232",
  "text" : "HI BUFFALO! So excited to see the Sabres tomorrow.",
  "id" : 38440691344351232,
  "created_at" : "2011-02-18 03:32:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 0, 11 ],
      "id_str" : "4243",
      "id" : 4243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38431541961048064",
  "geo" : { },
  "id_str" : "38440560742109184",
  "in_reply_to_user_id" : 4243,
  "text" : "@jnunemaker but...uhh....   ....",
  "id" : 38440560742109184,
  "in_reply_to_status_id" : 38431541961048064,
  "created_at" : "2011-02-18 03:31:58 +0000",
  "in_reply_to_screen_name" : "jnunemaker",
  "in_reply_to_user_id_str" : "4243",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38405914310606848",
  "text" : "\u007B:BOS =&gt; :BUF\u007D",
  "id" : 38405914310606848,
  "created_at" : "2011-02-18 01:14:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh French",
      "screen_name" : "joshfrench",
      "indices" : [ 3, 14 ],
      "id_str" : "19110970",
      "id" : 19110970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 82 ],
      "url" : "http:\/\/t.co\/nFs3dIZ",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems\/commit\/e4d04e2d728f813325433890c0a8af7fd4fa6be3",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "38392241655525376",
  "text" : "RT @joshfrench: Sweet, my `gem push --key` patch was accepted! http:\/\/t.co\/nFs3dIZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 66 ],
        "url" : "http:\/\/t.co\/nFs3dIZ",
        "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems\/commit\/e4d04e2d728f813325433890c0a8af7fd4fa6be3",
        "display_url" : "github.com\/rubygems\/rubyg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "38387194385137664",
    "text" : "Sweet, my `gem push --key` patch was accepted! http:\/\/t.co\/nFs3dIZ",
    "id" : 38387194385137664,
    "created_at" : "2011-02-17 23:59:54 +0000",
    "user" : {
      "name" : "Josh French",
      "screen_name" : "joshfrench",
      "protected" : false,
      "id_str" : "19110970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3705733024\/2dfe172e8f46e85fe5cce4174c1a564c_normal.jpeg",
      "id" : 19110970,
      "verified" : false
    }
  },
  "id" : 38392241655525376,
  "created_at" : "2011-02-18 00:19:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38319191480205312",
  "text" : "Current status: http:\/\/www.youtube.com\/watch?v=Wp7pLCRO4YM",
  "id" : 38319191480205312,
  "created_at" : "2011-02-17 19:29:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38273959430590464",
  "text" : "NO NEW EPISODES :( http:\/\/i.imgur.com\/WBMzN.jpg",
  "id" : 38273959430590464,
  "created_at" : "2011-02-17 16:29:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38273553421832192",
  "text" : "!!!!!! http:\/\/insidetv.ew.com\/2011\/02\/17\/firefly-returns\/",
  "id" : 38273553421832192,
  "created_at" : "2011-02-17 16:28:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38257343712083968",
  "text" : "So true: http:\/\/www.smbc-comics.com\/comics\/20110217.gif",
  "id" : 38257343712083968,
  "created_at" : "2011-02-17 15:23:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38053865383407617",
  "text" : "Back on TweetDeck. Twitter for Android was not fetching tweets right and ordering their dates wrong. :(",
  "id" : 38053865383407617,
  "created_at" : "2011-02-17 01:55:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37995184105078784",
  "text" : "one of these days i'm going to alias \"git push hamster\" to \"git push heroku master\" and just be done with it",
  "id" : 37995184105078784,
  "created_at" : "2011-02-16 22:02:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 3, 11 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37932439850582016",
  "text" : "RT @capotej: triple entendre ftw: http:\/\/bit.ly\/oLUq4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37931700742922240",
    "text" : "triple entendre ftw: http:\/\/bit.ly\/oLUq4",
    "id" : 37931700742922240,
    "created_at" : "2011-02-16 17:49:56 +0000",
    "user" : {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "protected" : false,
      "id_str" : "8898642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497932410890510337\/i-8d5ayf_normal.jpeg",
      "id" : 8898642,
      "verified" : false
    }
  },
  "id" : 37932439850582016,
  "created_at" : "2011-02-16 17:52:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37709320288342016",
  "geo" : { },
  "id_str" : "37710611928453120",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey doesn't look like it",
  "id" : 37710611928453120,
  "in_reply_to_status_id" : 37709320288342016,
  "created_at" : "2011-02-16 03:11:25 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37709224523857920",
  "text" : "Twitter for Android 2.0 doesn't seem too bad...may have to give this a go for a while.",
  "id" : 37709224523857920,
  "created_at" : "2011-02-16 03:05:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    }, {
      "name" : "follow @mattetti",
      "screen_name" : "merbist",
      "indices" : [ 11, 19 ],
      "id_str" : "1549117117",
      "id" : 1549117117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37672882507227136",
  "geo" : { },
  "id_str" : "37676716738478080",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything @merbist SORRY TO RUIN THE PAINFULLY OBVIOUS CONCLUSION",
  "id" : 37676716738478080,
  "in_reply_to_status_id" : 37672882507227136,
  "created_at" : "2011-02-16 00:56:43 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37672160373903360",
  "text" : "Watson is already kicking ass. What a boss, $6,435 daily double WTF",
  "id" : 37672160373903360,
  "created_at" : "2011-02-16 00:38:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37670031168897024",
  "text" : "GO WATSON!",
  "id" : 37670031168897024,
  "created_at" : "2011-02-16 00:30:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37623917136838656",
  "text" : "\"If Java had true garbage collection, most programs\nwould delete themselves upon execution.\"\n        -- Robert Sewell",
  "id" : 37623917136838656,
  "created_at" : "2011-02-15 21:26:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37572656219951104",
  "text" : "Is IE9 a modern browser? http:\/\/people.mozilla.com\/~prouget\/ie9\/",
  "id" : 37572656219951104,
  "created_at" : "2011-02-15 18:03:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conferenshish",
      "screen_name" : "tundal45",
      "indices" : [ 0, 9 ],
      "id_str" : "5573992",
      "id" : 5573992
    }, {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 10, 17 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37247723539398656",
  "geo" : { },
  "id_str" : "37549121770360832",
  "in_reply_to_user_id" : 5573992,
  "text" : "@tundal45 @elight PULL REQUEST COMMENT ATTACK",
  "id" : 37549121770360832,
  "in_reply_to_status_id" : 37247723539398656,
  "created_at" : "2011-02-15 16:29:42 +0000",
  "in_reply_to_screen_name" : "tundal45",
  "in_reply_to_user_id_str" : "5573992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Watson",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37313504239304704",
  "text" : "I love that they're putting a human face to #Watson by showing and interviewing engineers that worked on it. So awesome.",
  "id" : 37313504239304704,
  "created_at" : "2011-02-15 00:53:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cohen",
      "screen_name" : "flargh",
      "indices" : [ 3, 10 ],
      "id_str" : "2960721",
      "id" : 2960721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jeopardy",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37311093470789632",
  "text" : "RT @flargh: Watson is now addressing the world using the smoking corpse of Alex Trebek as a marionette. #jeopardy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jeopardy",
        "indices" : [ 92, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37302321222262784",
    "text" : "Watson is now addressing the world using the smoking corpse of Alex Trebek as a marionette. #jeopardy",
    "id" : 37302321222262784,
    "created_at" : "2011-02-15 00:09:01 +0000",
    "user" : {
      "name" : "Peter Cohen",
      "screen_name" : "flargh",
      "protected" : false,
      "id_str" : "2960721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569537151268712448\/FRON2C2N_normal.jpeg",
      "id" : 2960721,
      "verified" : false
    }
  },
  "id" : 37311093470789632,
  "created_at" : "2011-02-15 00:43:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF30\uFF21\uFF35\uFF2C\u3000\uFF26\uFF29\uFF33\uFF28\uFF25\uFF32",
      "screen_name" : "thetorpedodog",
      "indices" : [ 3, 17 ],
      "id_str" : "5889062",
      "id" : 5889062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jeopardy",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37311030312976384",
  "text" : "RT @thetorpedodog: The future not looking too bright for humanity right now #jeopardy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jeopardy",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37310852054908928",
    "text" : "The future not looking too bright for humanity right now #jeopardy",
    "id" : 37310852054908928,
    "created_at" : "2011-02-15 00:42:54 +0000",
    "user" : {
      "name" : "\uFF30\uFF21\uFF35\uFF2C\u3000\uFF26\uFF29\uFF33\uFF28\uFF25\uFF32",
      "screen_name" : "thetorpedodog",
      "protected" : false,
      "id_str" : "5889062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547218178179211264\/Z6gY4yuT_normal.jpeg",
      "id" : 5889062,
      "verified" : false
    }
  },
  "id" : 37311030312976384,
  "created_at" : "2011-02-15 00:43:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37310816478961664",
  "text" : "Watching Watson kick ass on Jeopardy. They forgot to put in some 'sleep 1's to make it fair!",
  "id" : 37310816478961664,
  "created_at" : "2011-02-15 00:42:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37278121048674304",
  "geo" : { },
  "id_str" : "37285841638408192",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton roses are red\/violets are blue\/ here's some data\/I lost for you",
  "id" : 37285841638408192,
  "in_reply_to_status_id" : 37278121048674304,
  "created_at" : "2011-02-14 23:03:32 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 0, 13 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37272264869158912",
  "geo" : { },
  "id_str" : "37275381245415424",
  "in_reply_to_user_id" : 9645312,
  "text" : "@ferventcoder you're joking right? if git daemon works on windows i'd be impressed. Use github.",
  "id" : 37275381245415424,
  "in_reply_to_status_id" : 37272264869158912,
  "created_at" : "2011-02-14 22:21:58 +0000",
  "in_reply_to_screen_name" : "ferventcoder",
  "in_reply_to_user_id_str" : "9645312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37246063450521600",
  "geo" : { },
  "id_str" : "37249739338694656",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule more like gemcutter zeitgeist",
  "id" : 37249739338694656,
  "in_reply_to_status_id" : 37246063450521600,
  "created_at" : "2011-02-14 20:40:04 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 56, 66 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37249230686916608",
  "text" : "Looking for some constructive criticism re: overhauling @gemcutter's search: https:\/\/groups.google.com\/forum\/#!topic\/gemcutter\/xIzyTmFdXVo",
  "id" : 37249230686916608,
  "created_at" : "2011-02-14 20:38:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conferenshish",
      "screen_name" : "tundal45",
      "indices" : [ 0, 9 ],
      "id_str" : "5573992",
      "id" : 5573992
    }, {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 10, 17 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 80, 90 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37246576267108355",
  "geo" : { },
  "id_str" : "37247012994818049",
  "in_reply_to_user_id" : 5573992,
  "text" : "@tundal45 @elight agh, i owe you guys some reviews this week. just dealing with @gemcutter supports sucks up most of my OSS time.",
  "id" : 37247012994818049,
  "in_reply_to_status_id" : 37246576267108355,
  "created_at" : "2011-02-14 20:29:14 +0000",
  "in_reply_to_screen_name" : "tundal45",
  "in_reply_to_user_id_str" : "5573992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jos\u00E9 Valim",
      "screen_name" : "josevalim",
      "indices" : [ 0, 10 ],
      "id_str" : "10230812",
      "id" : 10230812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37245630413930496",
  "geo" : { },
  "id_str" : "37246909391441920",
  "in_reply_to_user_id" : 10230812,
  "text" : "@josevalim RIP",
  "id" : 37246909391441920,
  "in_reply_to_status_id" : 37245630413930496,
  "created_at" : "2011-02-14 20:28:49 +0000",
  "in_reply_to_screen_name" : "josevalim",
  "in_reply_to_user_id_str" : "10230812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 30, 40 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37243871725494272",
  "text" : "The last month of searches at @gemcutter....clearly some interesting popularity metrics here we should track! http:\/\/db.tt\/Xq2ugZL",
  "id" : 37243871725494272,
  "created_at" : "2011-02-14 20:16:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37193040682553344",
  "text" : "Today's Ruby 1.9 WTF: https:\/\/gist.github.com\/826147",
  "id" : 37193040682553344,
  "created_at" : "2011-02-14 16:54:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kareem Kouddous",
      "screen_name" : "kareemk",
      "indices" : [ 3, 11 ],
      "id_str" : "8859412",
      "id" : 8859412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37187275414573056",
  "text" : "RT @kareemk: We've been using http:\/\/copycopter.com for months. Simple CMS for all the copy on your site. A must have for any Rails app.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36856331944067072",
    "text" : "We've been using http:\/\/copycopter.com for months. Simple CMS for all the copy on your site. A must have for any Rails app.",
    "id" : 36856331944067072,
    "created_at" : "2011-02-13 18:36:48 +0000",
    "user" : {
      "name" : "Kareem Kouddous",
      "screen_name" : "kareemk",
      "protected" : false,
      "id_str" : "8859412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2005959921\/ab2b959a4ec8427db04c51c69fcf8fe6_1000_normal.jpg",
      "id" : 8859412,
      "verified" : false
    }
  },
  "id" : 37187275414573056,
  "created_at" : "2011-02-14 16:31:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 3, 14 ],
      "id_str" : "4243",
      "id" : 4243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 70 ],
      "url" : "http:\/\/t.co\/yG0UM5H",
      "expanded_url" : "https:\/\/market.android.com\/details?id=com.zynga.words",
      "display_url" : "market.android.com\/details?id=com\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "37183155655942144",
  "text" : "RT @jnunemaker: Words with friends now on android. http:\/\/t.co\/yG0UM5H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 54 ],
        "url" : "http:\/\/t.co\/yG0UM5H",
        "expanded_url" : "https:\/\/market.android.com\/details?id=com.zynga.words",
        "display_url" : "market.android.com\/details?id=com\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "37183049791832064",
    "text" : "Words with friends now on android. http:\/\/t.co\/yG0UM5H",
    "id" : 37183049791832064,
    "created_at" : "2011-02-14 16:15:04 +0000",
    "user" : {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "protected" : false,
      "id_str" : "4243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552924817620361216\/36tFSZR1_normal.jpeg",
      "id" : 4243,
      "verified" : false
    }
  },
  "id" : 37183155655942144,
  "created_at" : "2011-02-14 16:15:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37117419637964800",
  "text" : "I meant Redbones has the best BBQ. I was going into a food coma.",
  "id" : 37117419637964800,
  "created_at" : "2011-02-14 11:54:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36967766389043200",
  "text" : "Rawbones = best BBQ in Boston. Just sayin'.",
  "id" : 36967766389043200,
  "created_at" : "2011-02-14 01:59:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "36642216839618560",
  "geo" : { },
  "id_str" : "36664692139098112",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv i ate some insulation once. it wasn't cotton candy like that guy told me. MY TUMMY ITCHES.",
  "id" : 36664692139098112,
  "in_reply_to_status_id" : 36642216839618560,
  "created_at" : "2011-02-13 05:55:18 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36265125619048448",
  "text" : "This...is genius. http:\/\/codereddit.com\/",
  "id" : 36265125619048448,
  "created_at" : "2011-02-12 03:27:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36252192109375488",
  "text" : "My droid's touch screen has just...stopped working. Unresponsive. I hate technology.",
  "id" : 36252192109375488,
  "created_at" : "2011-02-12 02:36:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Flipse",
      "screen_name" : "cflipse",
      "indices" : [ 0, 8 ],
      "id_str" : "15709932",
      "id" : 15709932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "36209949855981568",
  "geo" : { },
  "id_str" : "36219410343534592",
  "in_reply_to_user_id" : 15709932,
  "text" : "@cflipse ah yes. thats just the ordering on rubygems#show, versions#index has the right version ordering",
  "id" : 36219410343534592,
  "in_reply_to_status_id" : 36209949855981568,
  "created_at" : "2011-02-12 00:25:55 +0000",
  "in_reply_to_screen_name" : "cflipse",
  "in_reply_to_user_id_str" : "15709932",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Flipse",
      "screen_name" : "cflipse",
      "indices" : [ 0, 8 ],
      "id_str" : "15709932",
      "id" : 15709932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "36198714573991936",
  "geo" : { },
  "id_str" : "36208108644601856",
  "in_reply_to_user_id" : 15709932,
  "text" : "@cflipse ha the what? Confused. I can barely read my own mind.",
  "id" : 36208108644601856,
  "in_reply_to_status_id" : 36198714573991936,
  "created_at" : "2011-02-11 23:41:00 +0000",
  "in_reply_to_screen_name" : "cflipse",
  "in_reply_to_user_id_str" : "15709932",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36171301655683072",
  "text" : "Hey internet, can we knock if off with the blog articles split over multiple pages? If you need ad revenue that bad, well, fuck you.",
  "id" : 36171301655683072,
  "created_at" : "2011-02-11 21:14:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35934537812946944",
  "text" : "Current status: http:\/\/5secondfilms.com\/watch\/mr._forgetful",
  "id" : 35934537812946944,
  "created_at" : "2011-02-11 05:33:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 16, 25 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 28, 38 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35865285202284544",
  "text" : "Working through @rubygems \/ @gemcutter support issues tonight... big queue again.",
  "id" : 35865285202284544,
  "created_at" : "2011-02-11 00:58:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Santiago Pastorino",
      "screen_name" : "spastorino",
      "indices" : [ 0, 11 ],
      "id_str" : "19661139",
      "id" : 19661139
    }, {
      "name" : "Emilio Tagua",
      "screen_name" : "miloops",
      "indices" : [ 12, 20 ],
      "id_str" : "14994463",
      "id" : 14994463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35785945458552832",
  "geo" : { },
  "id_str" : "35786801285169152",
  "in_reply_to_user_id" : 19661139,
  "text" : "@spastorino @miloops FFFFFFUUUUUUUUUUU (actually i only spent like 20 minutes writing a crappy sinatra app, but oh well)",
  "id" : 35786801285169152,
  "in_reply_to_status_id" : 35785945458552832,
  "created_at" : "2011-02-10 19:46:52 +0000",
  "in_reply_to_screen_name" : "spastorino",
  "in_reply_to_user_id_str" : "19661139",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Tagua",
      "screen_name" : "miloops",
      "indices" : [ 0, 8 ],
      "id_str" : "14994463",
      "id" : 14994463
    }, {
      "name" : "Santiago Pastorino",
      "screen_name" : "spastorino",
      "indices" : [ 9, 20 ],
      "id_str" : "19661139",
      "id" : 19661139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35785332674797569",
  "geo" : { },
  "id_str" : "35785773831684097",
  "in_reply_to_user_id" : 14994463,
  "text" : "@miloops @spastorino I had to implement the redirects myself in a different service, is that working for all campfire users now?",
  "id" : 35785773831684097,
  "in_reply_to_status_id" : 35785332674797569,
  "created_at" : "2011-02-10 19:42:48 +0000",
  "in_reply_to_screen_name" : "miloops",
  "in_reply_to_user_id_str" : "14994463",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Delcambre",
      "screen_name" : "adelcambre",
      "indices" : [ 0, 11 ],
      "id_str" : "5424182",
      "id" : 5424182
    }, {
      "name" : "Carlos Rodriguez",
      "screen_name" : "eddorre",
      "indices" : [ 12, 20 ],
      "id_str" : "6149992",
      "id" : 6149992
    }, {
      "name" : "Aman Gupta",
      "screen_name" : "tmm1",
      "indices" : [ 21, 26 ],
      "id_str" : "15591045",
      "id" : 15591045
    }, {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 27, 40 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35735009386176512",
  "geo" : { },
  "id_str" : "35745735655817216",
  "in_reply_to_user_id" : 5424182,
  "text" : "@adelcambre @eddorre @tmm1 @technoweenie figured it out, it's glorious. thanks!",
  "id" : 35745735655817216,
  "in_reply_to_status_id" : 35735009386176512,
  "created_at" : "2011-02-10 17:03:42 +0000",
  "in_reply_to_screen_name" : "adelcambre",
  "in_reply_to_user_id_str" : "5424182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carlos Rodriguez",
      "screen_name" : "eddorre",
      "indices" : [ 0, 8 ],
      "id_str" : "6149992",
      "id" : 6149992
    }, {
      "name" : "Aman Gupta",
      "screen_name" : "tmm1",
      "indices" : [ 9, 14 ],
      "id_str" : "15591045",
      "id" : 15591045
    }, {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 15, 28 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35728089887539200",
  "geo" : { },
  "id_str" : "35733641887883264",
  "in_reply_to_user_id" : 6149992,
  "text" : "@eddorre @tmm1 @technoweenie yeah, seeing that...how does one figure out the redirects?",
  "id" : 35733641887883264,
  "in_reply_to_status_id" : 35728089887539200,
  "created_at" : "2011-02-10 16:15:38 +0000",
  "in_reply_to_screen_name" : "eddorre",
  "in_reply_to_user_id_str" : "6149992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Russo",
      "screen_name" : "mjrusso",
      "indices" : [ 0, 8 ],
      "id_str" : "11827472",
      "id" : 11827472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35722634700398592",
  "geo" : { },
  "id_str" : "35724562838593538",
  "in_reply_to_user_id" : 11827472,
  "text" : "@mjrusso thanks! http:\/\/cheeseburger.heroku.com\/ is a more basic intro, being revamped soon",
  "id" : 35724562838593538,
  "in_reply_to_status_id" : 35722634700398592,
  "created_at" : "2011-02-10 15:39:34 +0000",
  "in_reply_to_screen_name" : "mjrusso",
  "in_reply_to_user_id_str" : "11827472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35721487734280192",
  "geo" : { },
  "id_str" : "35724271326076928",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie dude nice! are those gravatars? can you share that stylesheet?",
  "id" : 35724271326076928,
  "in_reply_to_status_id" : 35721487734280192,
  "created_at" : "2011-02-10 15:38:24 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35721504117235712",
  "text" : "I wish mailing lists presented small programming tasks to allow posting to keep recruiters out.",
  "id" : 35721504117235712,
  "created_at" : "2011-02-10 15:27:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Rental monad",
      "screen_name" : "txustice",
      "indices" : [ 0, 9 ],
      "id_str" : "6895722",
      "id" : 6895722
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gemcutter",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35461786513838080",
  "geo" : { },
  "id_str" : "35502218010435584",
  "in_reply_to_user_id" : 6895722,
  "text" : "@txustice I think there's some patches to do that but I haven't been happy about them. hit me on #gemcutter at freenode sometime.",
  "id" : 35502218010435584,
  "in_reply_to_status_id" : 35461786513838080,
  "created_at" : "2011-02-10 00:56:03 +0000",
  "in_reply_to_screen_name" : "txustice",
  "in_reply_to_user_id_str" : "6895722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Curry",
      "screen_name" : "robincurry",
      "indices" : [ 0, 11 ],
      "id_str" : "6330782",
      "id" : 6330782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35472984739299328",
  "geo" : { },
  "id_str" : "35502054696816640",
  "in_reply_to_user_id" : 6330782,
  "text" : "@robincurry there's come folks building a service like that. shoot me an email, i'll hook you up with them",
  "id" : 35502054696816640,
  "in_reply_to_status_id" : 35472984739299328,
  "created_at" : "2011-02-10 00:55:24 +0000",
  "in_reply_to_screen_name" : "robincurry",
  "in_reply_to_user_id_str" : "6330782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitchell Hashimoto",
      "screen_name" : "mitchellh",
      "indices" : [ 3, 13 ],
      "id_str" : "12819682",
      "id" : 12819682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 113 ],
      "url" : "http:\/\/t.co\/rwTuEPk",
      "expanded_url" : "http:\/\/skitch.com\/love",
      "display_url" : "skitch.com\/love"
    } ]
  },
  "geo" : { },
  "id_str" : "35408523609247745",
  "text" : "RT @mitchellh: If you were part of the Skitch beta, you can get a free year of \"Skitch Plus\": http:\/\/t.co\/rwTuEPk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 98 ],
        "url" : "http:\/\/t.co\/rwTuEPk",
        "expanded_url" : "http:\/\/skitch.com\/love",
        "display_url" : "skitch.com\/love"
      } ]
    },
    "geo" : { },
    "id_str" : "35407290278354944",
    "text" : "If you were part of the Skitch beta, you can get a free year of \"Skitch Plus\": http:\/\/t.co\/rwTuEPk",
    "id" : 35407290278354944,
    "created_at" : "2011-02-09 18:38:50 +0000",
    "user" : {
      "name" : "Mitchell Hashimoto",
      "screen_name" : "mitchellh",
      "protected" : false,
      "id_str" : "12819682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560587841445445632\/YAgfrk50_normal.jpeg",
      "id" : 12819682,
      "verified" : false
    }
  },
  "id" : 35408523609247745,
  "created_at" : "2011-02-09 18:43:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35404388440735744",
  "text" : "Get to da choppa!! http:\/\/robots.thoughtbot.com\/post\/3201164937\/introducing-copycopter",
  "id" : 35404388440735744,
  "created_at" : "2011-02-09 18:27:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serg Podtynnyi",
      "screen_name" : "shtirlic",
      "indices" : [ 0, 9 ],
      "id_str" : "8439592",
      "id" : 8439592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35368195531620353",
  "geo" : { },
  "id_str" : "35368691071713280",
  "in_reply_to_user_id" : 8439592,
  "text" : "@shtirlic ahh..yeah the google chart rendering shouldn't show decimals. patches are welcome!",
  "id" : 35368691071713280,
  "in_reply_to_status_id" : 35368195531620353,
  "created_at" : "2011-02-09 16:05:27 +0000",
  "in_reply_to_screen_name" : "shtirlic",
  "in_reply_to_user_id_str" : "8439592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serg Podtynnyi",
      "screen_name" : "shtirlic",
      "indices" : [ 0, 9 ],
      "id_str" : "8439592",
      "id" : 8439592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35337904712589313",
  "geo" : { },
  "id_str" : "35364197432958976",
  "in_reply_to_user_id" : 8439592,
  "text" : "@shtirlic Wha? There's no such thing as a half-download. Where are you seeing this?",
  "id" : 35364197432958976,
  "in_reply_to_status_id" : 35337904712589313,
  "created_at" : "2011-02-09 15:47:36 +0000",
  "in_reply_to_screen_name" : "shtirlic",
  "in_reply_to_user_id_str" : "8439592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35159868662874112",
  "text" : "Can evergreen print anything to the log? console.log, jasmine.log don't work. ...wtf",
  "id" : 35159868662874112,
  "created_at" : "2011-02-09 02:15:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35116523672576000",
  "text" : "That's it. Done with sleeping in cucumber\/akephalos\/capybara and debugging why tests fail on diff machines. Time to figure out jasmine.",
  "id" : 35116523672576000,
  "created_at" : "2011-02-08 23:23:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35087127486267392",
  "text" : "Hired. http:\/\/atlanta.craigslist.org\/atl\/crs\/2202170274.html",
  "id" : 35087127486267392,
  "created_at" : "2011-02-08 21:26:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Fiedler",
      "screen_name" : "kylefiedler",
      "indices" : [ 0, 12 ],
      "id_str" : "14838050",
      "id" : 14838050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34989538677891072",
  "geo" : { },
  "id_str" : "34989784321499137",
  "in_reply_to_user_id" : 14838050,
  "text" : "@kylefiedler WHYDOYOUHATEEMPTYSPACE",
  "id" : 34989784321499137,
  "in_reply_to_status_id" : 34989538677891072,
  "created_at" : "2011-02-08 14:59:49 +0000",
  "in_reply_to_screen_name" : "kylefiedler",
  "in_reply_to_user_id_str" : "14838050",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34988622100832258",
  "text" : "Current status: http:\/\/27.media.tumblr.com\/tumblr_lgagjm5u531qzh5gno1_500.jpg",
  "id" : 34988622100832258,
  "created_at" : "2011-02-08 14:55:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34748336980361216",
  "geo" : { },
  "id_str" : "34752597898440704",
  "in_reply_to_user_id" : 21390942,
  "text" : "@danielsju6 about time, welcome to Boston!",
  "id" : 34752597898440704,
  "in_reply_to_status_id" : 34748336980361216,
  "created_at" : "2011-02-07 23:17:19 +0000",
  "in_reply_to_screen_name" : "jamesuriah",
  "in_reply_to_user_id_str" : "21390942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34706885986885632",
  "text" : "Current status: http:\/\/yfrog.com\/h2s22oj",
  "id" : 34706885986885632,
  "created_at" : "2011-02-07 20:15:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34656431261233152",
  "text" : "Current status: http:\/\/i.imgur.com\/YqFKO.gif",
  "id" : 34656431261233152,
  "created_at" : "2011-02-07 16:55:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34465520581345280",
  "text" : "Current status: http:\/\/is.gd\/wuOVqS",
  "id" : 34465520581345280,
  "created_at" : "2011-02-07 04:16:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34448160503889921",
  "text" : "AND THE NEW YORK PACKERS WIN THE MAJOR LEAGUE FINAL CHAMPIONSHIP TOUR!",
  "id" : 34448160503889921,
  "created_at" : "2011-02-07 03:07:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34406312821395456",
  "text" : "WELCOME TO ROETHLISBERGER, HOME OF THE ROETHLISBERGER. CAN I TAKE YOUR ORDER?",
  "id" : 34406312821395456,
  "created_at" : "2011-02-07 00:21:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Redlist",
      "screen_name" : "redlist",
      "indices" : [ 7, 15 ],
      "id_str" : "14982648",
      "id" : 14982648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34296997867429889",
  "geo" : { },
  "id_str" : "34392929724268545",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik @redlist thanks!",
  "id" : 34392929724268545,
  "in_reply_to_status_id" : 34296997867429889,
  "created_at" : "2011-02-06 23:28:08 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34348034301104128",
  "text" : "Yep, Netflix knows me too well: \"Visually-striking Mind-bending Sci-Fi & Fantasy\"",
  "id" : 34348034301104128,
  "created_at" : "2011-02-06 20:29:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34248271794946048",
  "geo" : { },
  "id_str" : "34269491374329856",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight yes yes yes. Been on the issues list forever. This is why we have an API and it's in Ruby. :)",
  "id" : 34269491374329856,
  "in_reply_to_status_id" : 34248271794946048,
  "created_at" : "2011-02-06 15:17:38 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 3, 10 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "d8event",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33992157475905536",
  "text" : "RT @Croaky: Time for the #d8event after-party at Hard Rock. Meet even more Boston web folks. Map\/directions: http:\/\/d8event.org\/party",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "d8event",
        "indices" : [ 13, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33991301431033856",
    "text" : "Time for the #d8event after-party at Hard Rock. Meet even more Boston web folks. Map\/directions: http:\/\/d8event.org\/party",
    "id" : 33991301431033856,
    "created_at" : "2011-02-05 20:52:12 +0000",
    "user" : {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "protected" : false,
      "id_str" : "787595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568676101967196160\/nP3jFRbr_normal.jpeg",
      "id" : 787595,
      "verified" : false
    }
  },
  "id" : 33992157475905536,
  "created_at" : "2011-02-05 20:55:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "d8event",
      "indices" : [ 15, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33908646526058496",
  "text" : "Setting up for #d8event! Very excited. http:\/\/d8.thoughtbot.com",
  "id" : 33908646526058496,
  "created_at" : "2011-02-05 15:23:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scofield",
      "screen_name" : "bscofield",
      "indices" : [ 0, 10 ],
      "id_str" : "7921582",
      "id" : 7921582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33698613657870336",
  "geo" : { },
  "id_str" : "33699721381941248",
  "in_reply_to_user_id" : 7921582,
  "text" : "@bscofield haha that's more important. Definitely!",
  "id" : 33699721381941248,
  "in_reply_to_status_id" : 33698613657870336,
  "created_at" : "2011-02-05 01:33:34 +0000",
  "in_reply_to_screen_name" : "bscofield",
  "in_reply_to_user_id_str" : "7921582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scofield",
      "screen_name" : "bscofield",
      "indices" : [ 0, 10 ],
      "id_str" : "7921582",
      "id" : 7921582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33697202064990208",
  "geo" : { },
  "id_str" : "33697673550766080",
  "in_reply_to_user_id" : 7921582,
  "text" : "@bscofield we're headed to Stoddard's downtown. Come join us!",
  "id" : 33697673550766080,
  "in_reply_to_status_id" : 33697202064990208,
  "created_at" : "2011-02-05 01:25:26 +0000",
  "in_reply_to_screen_name" : "bscofield",
  "in_reply_to_user_id_str" : "7921582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scofield",
      "screen_name" : "bscofield",
      "indices" : [ 0, 10 ],
      "id_str" : "7921582",
      "id" : 7921582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33623261627695104",
  "geo" : { },
  "id_str" : "33696967867506688",
  "in_reply_to_user_id" : 7921582,
  "text" : "@bscofield you in town yet?",
  "id" : 33696967867506688,
  "in_reply_to_status_id" : 33623261627695104,
  "created_at" : "2011-02-05 01:22:37 +0000",
  "in_reply_to_screen_name" : "bscofield",
  "in_reply_to_user_id_str" : "7921582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 12, 17 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "decrepita",
      "screen_name" : "somevar",
      "indices" : [ 33, 41 ],
      "id_str" : "155628717",
      "id" : 155628717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33614446001655808",
  "geo" : { },
  "id_str" : "33615634487054336",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler @avdi needs context. @somevar ||= begin (some exp) end is great",
  "id" : 33615634487054336,
  "in_reply_to_status_id" : 33614446001655808,
  "created_at" : "2011-02-04 19:59:26 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/plancast.com\" rel=\"nofollow\"\u003EPlancast\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "plan",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33606579026661376",
  "text" : "#plan Whiskey Friday. (The Field Pub) Fri, Feb 4, 2011, 6-8:00pm http:\/\/planca.st\/OTu",
  "id" : 33606579026661376,
  "created_at" : "2011-02-04 19:23:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jos\u00E9 Valim",
      "screen_name" : "josevalim",
      "indices" : [ 0, 10 ],
      "id_str" : "10230812",
      "id" : 10230812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33579335923269632",
  "geo" : { },
  "id_str" : "33601131657568256",
  "in_reply_to_user_id" : 10230812,
  "text" : "@josevalim AHHHHHHHHHHHHHHHH",
  "id" : 33601131657568256,
  "in_reply_to_status_id" : 33579335923269632,
  "created_at" : "2011-02-04 19:01:48 +0000",
  "in_reply_to_screen_name" : "josevalim",
  "in_reply_to_user_id_str" : "10230812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabe da Silveira",
      "screen_name" : "dasil003",
      "indices" : [ 0, 9 ],
      "id_str" : "14389163",
      "id" : 14389163
    }, {
      "name" : "James Adam",
      "screen_name" : "lazyatom",
      "indices" : [ 10, 19 ],
      "id_str" : "53413",
      "id" : 53413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33576098772029442",
  "geo" : { },
  "id_str" : "33599867863568384",
  "in_reply_to_user_id" : 14389163,
  "text" : "@dasil003 @lazyatom that's what the description and readme are for.",
  "id" : 33599867863568384,
  "in_reply_to_status_id" : 33576098772029442,
  "created_at" : "2011-02-04 18:56:47 +0000",
  "in_reply_to_screen_name" : "dasil003",
  "in_reply_to_user_id_str" : "14389163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdir -- -rf",
      "screen_name" : "baroquebobcat",
      "indices" : [ 0, 14 ],
      "id_str" : "14247442",
      "id" : 14247442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33569399227023361",
  "geo" : { },
  "id_str" : "33570589004271616",
  "in_reply_to_user_id" : 14247442,
  "text" : "@baroquebobcat FOR WHOM THE HOP TOADDDDS",
  "id" : 33570589004271616,
  "in_reply_to_status_id" : 33569399227023361,
  "created_at" : "2011-02-04 17:00:26 +0000",
  "in_reply_to_screen_name" : "baroquebobcat",
  "in_reply_to_user_id_str" : "14247442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33568256988024832",
  "geo" : { },
  "id_str" : "33569426435481600",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius PLEASE STAND CLEAR OF THE DOORS. POR FAVOR MANT\u00C9NGANSE ALEJADO DE LAS PUERTAS.",
  "id" : 33569426435481600,
  "in_reply_to_status_id" : 33568256988024832,
  "created_at" : "2011-02-04 16:55:49 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33539457281949696",
  "text" : "I just want to embed headphones into my ears, then I'll never lose them or forget where I put them.",
  "id" : 33539457281949696,
  "created_at" : "2011-02-04 14:56:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernerd Schaefer",
      "screen_name" : "bjschaefer",
      "indices" : [ 0, 11 ],
      "id_str" : "5339",
      "id" : 5339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33481372756611072",
  "geo" : { },
  "id_str" : "33538945056772096",
  "in_reply_to_user_id" : 5339,
  "text" : "@bjschaefer i emailed you about this a while back, will dredge that up",
  "id" : 33538945056772096,
  "in_reply_to_status_id" : 33481372756611072,
  "created_at" : "2011-02-04 14:54:42 +0000",
  "in_reply_to_screen_name" : "bjschaefer",
  "in_reply_to_user_id_str" : "5339",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33404464366878720",
  "text" : "When you know you're too tired to code: benchmarking code in a dev (instead of prod) environment that reloads code\/classes. *facepalm*",
  "id" : 33404464366878720,
  "created_at" : "2011-02-04 06:00:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33387075445342208",
  "text" : "One huge thing rspec's subject has taught me: if I don't have one for my tests, I'm not modeling the problem right.",
  "id" : 33387075445342208,
  "created_at" : "2011-02-04 04:51:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33386016987422720",
  "text" : "Fuck comments, I'm just going to lay down __END__'s like a boss for now on.",
  "id" : 33386016987422720,
  "created_at" : "2011-02-04 04:47:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33297875811176449",
  "text" : "DO MATH, BECOME UNSTOPPABLE. http:\/\/is.gd\/2kgpS4",
  "id" : 33297875811176449,
  "created_at" : "2011-02-03 22:56:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33191445963735040",
  "text" : "Does ruby-doc.org feel REALLY slow to anyone else? I kind of want to toss a Varnish'd up mirror on heroku.",
  "id" : 33191445963735040,
  "created_at" : "2011-02-03 15:53:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "will code for money",
      "screen_name" : "ckeithray",
      "indices" : [ 3, 13 ],
      "id_str" : "20831678",
      "id" : 20831678
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33174083789135872",
  "text" : "RT @ckeithray: \"If your code isn't covered by automated tests, then you're not refactoring, you're just changing shit\" http:\/\/is.gd\/uKPLLJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32973313638662144",
    "text" : "\"If your code isn't covered by automated tests, then you're not refactoring, you're just changing shit\" http:\/\/is.gd\/uKPLLJ",
    "id" : 32973313638662144,
    "created_at" : "2011-02-03 01:27:05 +0000",
    "user" : {
      "name" : "will code for money",
      "screen_name" : "ckeithray",
      "protected" : false,
      "id_str" : "20831678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1617865974\/keith-in-mac_normal.png",
      "id" : 20831678,
      "verified" : false
    }
  },
  "id" : 33174083789135872,
  "created_at" : "2011-02-03 14:44:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernerd Schaefer",
      "screen_name" : "bjschaefer",
      "indices" : [ 0, 11 ],
      "id_str" : "5339",
      "id" : 5339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33166400625315841",
  "geo" : { },
  "id_str" : "33166718113161216",
  "in_reply_to_user_id" : 5339,
  "text" : "@bjschaefer awesome, thanks dude",
  "id" : 33166718113161216,
  "in_reply_to_status_id" : 33166400625315841,
  "created_at" : "2011-02-03 14:15:36 +0000",
  "in_reply_to_screen_name" : "bjschaefer",
  "in_reply_to_user_id_str" : "5339",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33150276663771136",
  "text" : "NOSTALGIA ATTACK http:\/\/www.youtube.com\/watch?v=9uDM8GJa53c",
  "id" : 33150276663771136,
  "created_at" : "2011-02-03 13:10:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AKA JMoney",
      "screen_name" : "soederpop",
      "indices" : [ 0, 10 ],
      "id_str" : "18176421",
      "id" : 18176421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33048573423648768",
  "geo" : { },
  "id_str" : "33049502210330624",
  "in_reply_to_user_id" : 18176421,
  "text" : "@soederpop hired",
  "id" : 33049502210330624,
  "in_reply_to_status_id" : 33048573423648768,
  "created_at" : "2011-02-03 06:29:50 +0000",
  "in_reply_to_screen_name" : "soederpop",
  "in_reply_to_user_id_str" : "18176421",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33035648340332544",
  "text" : "Shipped it off, thanks folks! :)",
  "id" : 33035648340332544,
  "created_at" : "2011-02-03 05:34:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33024011264856064",
  "text" : "Need some quick feedback on a conference abstract. DM me if you can spare a cycle to read it :)",
  "id" : 33024011264856064,
  "created_at" : "2011-02-03 04:48:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33018108595671040",
  "text" : "Current status: http:\/\/i.imgur.com\/D1oFM.png",
  "id" : 33018108595671040,
  "created_at" : "2011-02-03 04:25:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33006254192328705",
  "text" : "Ideas for wedding invitations: POWERTHIRST.\n\nWEDDING! ENERGY! WEDDERGY",
  "id" : 33006254192328705,
  "created_at" : "2011-02-03 03:37:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32909090376126466",
  "geo" : { },
  "id_str" : "32910786095480832",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck or use this: https:\/\/gist.github.com\/808458",
  "id" : 32910786095480832,
  "in_reply_to_status_id" : 32909090376126466,
  "created_at" : "2011-02-02 21:18:37 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32908304103514112",
  "geo" : { },
  "id_str" : "32908902848790528",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck this is more pain than it's worth IMO, especially if you're doing more than GET\/SET. i have some start\/stop_redis code if you want",
  "id" : 32908902848790528,
  "in_reply_to_status_id" : 32908304103514112,
  "created_at" : "2011-02-02 21:11:08 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32907674630750210",
  "geo" : { },
  "id_str" : "32908076793208832",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck so I've debated doing this, but it's so fast that it doesn't matter to me. Why do you need it?",
  "id" : 32908076793208832,
  "in_reply_to_status_id" : 32907674630750210,
  "created_at" : "2011-02-02 21:07:51 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32901855868620800",
  "text" : "Current status: http:\/\/www.youtube.com\/watch?v=niEIuwLCCiQ",
  "id" : 32901855868620800,
  "created_at" : "2011-02-02 20:43:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Van den Eynde",
      "screen_name" : "DaveVdE",
      "indices" : [ 0, 8 ],
      "id_str" : "18692854",
      "id" : 18692854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32816922412191745",
  "geo" : { },
  "id_str" : "32819863588179969",
  "in_reply_to_user_id" : 18692854,
  "text" : "@DaveVdE Please tell me you're joking.",
  "id" : 32819863588179969,
  "in_reply_to_status_id" : 32816922412191745,
  "created_at" : "2011-02-02 15:17:19 +0000",
  "in_reply_to_screen_name" : "DaveVdE",
  "in_reply_to_user_id_str" : "18692854",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32813224164327424",
  "text" : "People angry at .NET reflector going paid: there's other languages where you don't need a decompiler to read source code. Just saying.",
  "id" : 32813224164327424,
  "created_at" : "2011-02-02 14:50:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32670517638991872",
  "text" : "Current status: https:\/\/img.skitch.com\/20110202-fu31trem2t69af26md5qhbyhyy.png NOW SNOWPROOF. Thanks @ablissfulgal!",
  "id" : 32670517638991872,
  "created_at" : "2011-02-02 05:23:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32648776342568960",
  "geo" : { },
  "id_str" : "32649112922886144",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @ablissfulgal EPIC HONEYMOON TIME",
  "id" : 32649112922886144,
  "in_reply_to_status_id" : 32648776342568960,
  "created_at" : "2011-02-02 03:58:49 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 83, 89 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32633314632273921",
  "text" : "RT @ablissfulgal I'm trying to think up some ideas for my September honeymoon with @qrush. Any ideas (however crazy) are welcome!",
  "id" : 32633314632273921,
  "created_at" : "2011-02-02 02:56:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aaronblew",
      "screen_name" : "aaronblew",
      "indices" : [ 0, 10 ],
      "id_str" : "16455419",
      "id" : 16455419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32584360758611968",
  "geo" : { },
  "id_str" : "32590593821511680",
  "in_reply_to_user_id" : 16455419,
  "text" : "@aaronblew maybe could add it to this page? http:\/\/rubygems.org\/gems\/rails\/versions Patches welcome. :) And we don't store tars, only gems.",
  "id" : 32590593821511680,
  "in_reply_to_status_id" : 32584360758611968,
  "created_at" : "2011-02-02 00:06:17 +0000",
  "in_reply_to_screen_name" : "aaronblew",
  "in_reply_to_user_id_str" : "16455419",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aaronblew",
      "screen_name" : "aaronblew",
      "indices" : [ 0, 10 ],
      "id_str" : "16455419",
      "id" : 16455419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32500538654326784",
  "geo" : { },
  "id_str" : "32576370152312832",
  "in_reply_to_user_id" : 16455419,
  "text" : "@aaronblew huh? what could we do better? most times I just use `gem` to install stuff. :)",
  "id" : 32576370152312832,
  "in_reply_to_status_id" : 32500538654326784,
  "created_at" : "2011-02-01 23:09:46 +0000",
  "in_reply_to_screen_name" : "aaronblew",
  "in_reply_to_user_id_str" : "16455419",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shortmail",
      "screen_name" : "shortmail",
      "indices" : [ 33, 43 ],
      "id_str" : "28839008",
      "id" : 28839008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32573102063878144",
  "text" : "Going to try to forward GMail to @shortmail... D:",
  "id" : 32573102063878144,
  "created_at" : "2011-02-01 22:56:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32557403161497600",
  "text" : "Deactivated my Quora account, adds zero value to my life, it's an unwanted bastard child of StackOverflow and Yahoo Answers. See ya!",
  "id" : 32557403161497600,
  "created_at" : "2011-02-01 21:54:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32555187830788096",
  "text" : "Current status: https:\/\/img.skitch.com\/20110201-rd1wdkgj8xnu5a81qfgnhsswbr.png",
  "id" : 32555187830788096,
  "created_at" : "2011-02-01 21:45:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32535914785804288",
  "text" : "Current status: http:\/\/i.imgur.com\/sHOUh.jpg",
  "id" : 32535914785804288,
  "created_at" : "2011-02-01 20:29:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32466761756446720",
  "geo" : { },
  "id_str" : "32468554141929473",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic that's how it's done on american soil! congrats!",
  "id" : 32468554141929473,
  "in_reply_to_status_id" : 32466761756446720,
  "created_at" : "2011-02-01 16:01:21 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Han",
      "screen_name" : "knowtheory",
      "indices" : [ 0, 11 ],
      "id_str" : "14227842",
      "id" : 14227842
    }, {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 12, 18 ],
      "id_str" : "9885102",
      "id" : 9885102
    }, {
      "name" : "Wynn Netherland",
      "screen_name" : "pengwynn",
      "indices" : [ 19, 28 ],
      "id_str" : "14100886",
      "id" : 14100886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32455461793959937",
  "geo" : { },
  "id_str" : "32457097576710144",
  "in_reply_to_user_id" : 14227842,
  "text" : "@knowtheory @drnic @pengwynn seriously. whatever happened to just plain writing good code?",
  "id" : 32457097576710144,
  "in_reply_to_status_id" : 32455461793959937,
  "created_at" : "2011-02-01 15:15:49 +0000",
  "in_reply_to_screen_name" : "knowtheory",
  "in_reply_to_user_id_str" : "14227842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
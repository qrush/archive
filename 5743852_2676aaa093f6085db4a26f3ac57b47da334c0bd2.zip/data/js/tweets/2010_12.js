Grailbird.data.tweets_2010_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Durham",
      "screen_name" : "jeremydurham",
      "indices" : [ 0, 13 ],
      "id_str" : "966341",
      "id" : 966341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20985274834096128",
  "geo" : { },
  "id_str" : "21009798195580928",
  "in_reply_to_user_id" : 966341,
  "text" : "@jeremydurham known issue :( http:\/\/blog.zenspider.com\/2010\/12\/rubygems-version-140-has-been.html",
  "id" : 21009798195580928,
  "in_reply_to_status_id" : 20985274834096128,
  "created_at" : "2011-01-01 01:08:20 +0000",
  "in_reply_to_screen_name" : "jeremydurham",
  "in_reply_to_user_id_str" : "966341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21004472738119680",
  "text" : "RT @gemcutter: Ruby 1.9 users should wait to upgrade to RubyGems 1.4. More info here: http:\/\/is.gd\/jRQDm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "21004413317419008",
    "text" : "Ruby 1.9 users should wait to upgrade to RubyGems 1.4. More info here: http:\/\/is.gd\/jRQDm",
    "id" : 21004413317419008,
    "created_at" : "2011-01-01 00:46:57 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 21004472738119680,
  "created_at" : "2011-01-01 00:47:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Kahn",
      "screen_name" : "akahn",
      "indices" : [ 0, 6 ],
      "id_str" : "15068402",
      "id" : 15068402
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 7, 13 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20938463108927488",
  "geo" : { },
  "id_str" : "20978924825612288",
  "in_reply_to_user_id" : 15068402,
  "text" : "@akahn @raggi oh nice! That will speed up gem indexing too.",
  "id" : 20978924825612288,
  "in_reply_to_status_id" : 20938463108927488,
  "created_at" : "2010-12-31 23:05:40 +0000",
  "in_reply_to_screen_name" : "akahn",
  "in_reply_to_user_id_str" : "15068402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20978290068033537",
  "text" : "RT @gemcutter: Deploy done! Upgrade to RubyGems 1.4! http:\/\/rubygems.org\/pages\/download",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "20936219693154304",
    "text" : "Deploy done! Upgrade to RubyGems 1.4! http:\/\/rubygems.org\/pages\/download",
    "id" : 20936219693154304,
    "created_at" : "2010-12-31 20:15:58 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 20978290068033537,
  "created_at" : "2010-12-31 23:03:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20664452022009856",
  "text" : "TRON was awesome. END OF LINE.",
  "id" : 20664452022009856,
  "created_at" : "2010-12-31 02:16:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20621225785040896",
  "geo" : { },
  "id_str" : "20621784621518849",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis nonzero? if negative isn't an issue",
  "id" : 20621784621518849,
  "in_reply_to_status_id" : 20621225785040896,
  "created_at" : "2010-12-30 23:26:31 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20592807232147456",
  "text" : "AHHHHHH http:\/\/muppetswithpeopleeyes.tumblr.com\/",
  "id" : 20592807232147456,
  "created_at" : "2010-12-30 21:31:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20589277029076992",
  "text" : "General topics in Quora are destined to become the new Yahoo! Answers simply because of the sheer amount of dumb questions being asked.",
  "id" : 20589277029076992,
  "created_at" : "2010-12-30 21:17:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20562143480913920",
  "geo" : { },
  "id_str" : "20563432906432512",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense your cubist heart attack game needs instructions",
  "id" : 20563432906432512,
  "in_reply_to_status_id" : 20562143480913920,
  "created_at" : "2010-12-30 19:34:39 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 3, 11 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20535408894939136",
  "text" : "RT @antirez: wow a NoSQL solutions comparison that does not suck, with use cases for different products -&gt; http:\/\/bit.ly\/gLAvMI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "20535122004545536",
    "text" : "wow a NoSQL solutions comparison that does not suck, with use cases for different products -&gt; http:\/\/bit.ly\/gLAvMI",
    "id" : 20535122004545536,
    "created_at" : "2010-12-30 17:42:09 +0000",
    "user" : {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "protected" : false,
      "id_str" : "5813712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461550870648217602\/XjbUS5rb_normal.png",
      "id" : 5813712,
      "verified" : false
    }
  },
  "id" : 20535408894939136,
  "created_at" : "2010-12-30 17:43:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Chambers",
      "screen_name" : "schambers",
      "indices" : [ 0, 10 ],
      "id_str" : "8372122",
      "id" : 8372122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20507533852545025",
  "geo" : { },
  "id_str" : "20508124565737472",
  "in_reply_to_user_id" : 8372122,
  "text" : "@schambers i used this year when working on windows since I couldn't deal with how horrible SVN is. works great.",
  "id" : 20508124565737472,
  "in_reply_to_status_id" : 20507533852545025,
  "created_at" : "2010-12-30 15:54:52 +0000",
  "in_reply_to_screen_name" : "schambers",
  "in_reply_to_user_id_str" : "8372122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20318247916150784",
  "text" : "My blog, untouched since 2010. http:\/\/litanyagainstfear.com OH HOW WEB BROWSER NOSTALGIC",
  "id" : 20318247916150784,
  "created_at" : "2010-12-30 03:20:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20262881907970048",
  "geo" : { },
  "id_str" : "20265671430508545",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg wow thanks! I still think the whole step def dsl could be revisited though",
  "id" : 20265671430508545,
  "in_reply_to_status_id" : 20262881907970048,
  "created_at" : "2010-12-29 23:51:27 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20258753806864384",
  "text" : "Cucumber needs a new step mother. Should deal with finding patterns in patterns, a la named elements and paths.rb http:\/\/is.gd\/jJxiK",
  "id" : 20258753806864384,
  "created_at" : "2010-12-29 23:23:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20231611446460416",
  "geo" : { },
  "id_str" : "20233033789472768",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove urge to patch campfire hudson notifier to paste that image...rising",
  "id" : 20233033789472768,
  "in_reply_to_status_id" : 20231611446460416,
  "created_at" : "2010-12-29 21:41:45 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20230580830478336",
  "text" : "........F--------UUUUU",
  "id" : 20230580830478336,
  "created_at" : "2010-12-29 21:32:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20197650481549313",
  "text" : "CRAAAAAAWLING IN MY $STDIN\nTHESE STREAMS, THEY WILL NOT CLOSE",
  "id" : 20197650481549313,
  "created_at" : "2010-12-29 19:21:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "byplayer",
      "screen_name" : "byplayer",
      "indices" : [ 0, 9 ],
      "id_str" : "64752960",
      "id" : 64752960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19544980750073856",
  "geo" : { },
  "id_str" : "19904239727804416",
  "in_reply_to_user_id" : 64752960,
  "text" : "@byplayer i have not figured out a good way to do it. let's discuss! http:\/\/groups.google.com\/group\/gemcutter",
  "id" : 19904239727804416,
  "in_reply_to_status_id" : 19544980750073856,
  "created_at" : "2010-12-28 23:55:15 +0000",
  "in_reply_to_screen_name" : "byplayer",
  "in_reply_to_user_id_str" : "64752960",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19882128065961984",
  "text" : "2011 prediction: no one gives a fuck about predictions",
  "id" : 19882128065961984,
  "created_at" : "2010-12-28 22:27:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19859567894597633",
  "text" : "Boston!",
  "id" : 19859567894597633,
  "created_at" : "2010-12-28 20:57:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19523076626587648",
  "text" : "Current status: pair programming http:\/\/yfrog.com\/h4c50qkj",
  "id" : 19523076626587648,
  "created_at" : "2010-12-27 22:40:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 3, 13 ],
      "id_str" : "9980812",
      "id" : 9980812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19461546287562752",
  "text" : "RT @igrigorik: working on your resolutions for 2011? add this one to the list: rvm install 1.9.2 && rvm --default 1.9.2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "19461463110320128",
    "text" : "working on your resolutions for 2011? add this one to the list: rvm install 1.9.2 && rvm --default 1.9.2",
    "id" : 19461463110320128,
    "created_at" : "2010-12-27 18:35:49 +0000",
    "user" : {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "protected" : false,
      "id_str" : "9980812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458689841186611200\/SMmZLt2Y_normal.jpeg",
      "id" : 9980812,
      "verified" : false
    }
  },
  "id" : 19461546287562752,
  "created_at" : "2010-12-27 18:36:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19453101350060032",
  "geo" : { },
  "id_str" : "19457167480324096",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier DM'd ya dude",
  "id" : 19457167480324096,
  "in_reply_to_status_id" : 19453101350060032,
  "created_at" : "2010-12-27 18:18:44 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19450146840379392",
  "geo" : { },
  "id_str" : "19453190579687424",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight also thanks for reminding me, the campfire plugin hudson provides is the fixed one now, updated the post.",
  "id" : 19453190579687424,
  "in_reply_to_status_id" : 19450146840379392,
  "created_at" : "2010-12-27 18:02:56 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19450146840379392",
  "geo" : { },
  "id_str" : "19451992770347008",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight thanks, it's still chugging along great! http:\/\/ci.thoughtbot.com\/",
  "id" : 19451992770347008,
  "in_reply_to_status_id" : 19450146840379392,
  "created_at" : "2010-12-27 17:58:11 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19450604891930624",
  "geo" : { },
  "id_str" : "19451074662371328",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier dude fly here, CARPOOL",
  "id" : 19451074662371328,
  "in_reply_to_status_id" : 19450604891930624,
  "created_at" : "2010-12-27 17:54:32 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jos\u00E9 Valim",
      "screen_name" : "josevalim",
      "indices" : [ 0, 10 ],
      "id_str" : "10230812",
      "id" : 10230812
    }, {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 11, 22 ],
      "id_str" : "4243",
      "id" : 4243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19443757552242688",
  "geo" : { },
  "id_str" : "19444271153156096",
  "in_reply_to_user_id" : 10230812,
  "text" : "@josevalim @jnunemaker yeah, it's a big hack for optional args on a lambda but I hope it's worth it. we'll see.",
  "id" : 19444271153156096,
  "in_reply_to_status_id" : 19443757552242688,
  "created_at" : "2010-12-27 17:27:30 +0000",
  "in_reply_to_screen_name" : "josevalim",
  "in_reply_to_user_id_str" : "10230812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex McHale",
      "screen_name" : "alexmchale",
      "indices" : [ 0, 11 ],
      "id_str" : "13964832",
      "id" : 13964832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19439839141175296",
  "geo" : { },
  "id_str" : "19440032863485953",
  "in_reply_to_user_id" : 13964832,
  "text" : "@alexmchale yeah i dont know if it's good or not. stretching the 1.9 syntax to its limits for this app to see how it feels",
  "id" : 19440032863485953,
  "in_reply_to_status_id" : 19439839141175296,
  "created_at" : "2010-12-27 17:10:39 +0000",
  "in_reply_to_screen_name" : "alexmchale",
  "in_reply_to_user_id_str" : "13964832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19438846554935296",
  "text" : "Ruby 1.9 feels like the future: https:\/\/gist.github.com\/756299",
  "id" : 19438846554935296,
  "created_at" : "2010-12-27 17:05:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 0, 10 ],
      "id_str" : "9980812",
      "id" : 9980812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19436834207571968",
  "geo" : { },
  "id_str" : "19438060055822336",
  "in_reply_to_user_id" : 9980812,
  "text" : "@igrigorik use: http:\/\/github.com\/geemus\/excon (i wish this would replace the stdlib version)",
  "id" : 19438060055822336,
  "in_reply_to_status_id" : 19436834207571968,
  "created_at" : "2010-12-27 17:02:49 +0000",
  "in_reply_to_screen_name" : "igrigorik",
  "in_reply_to_user_id_str" : "9980812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 18, 24 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 43, 51 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19426476193484800",
  "text" : "looks like it's a @qrush \/ @ablissfulgal \/ @jayunit carpool back to Boston tomorrow!",
  "id" : 19426476193484800,
  "created_at" : "2010-12-27 16:16:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19185612997267456",
  "text" : "What I would give for an android home screen that doesn't take 2-5 seconds to load when switching\/browsing apps",
  "id" : 19185612997267456,
  "created_at" : "2010-12-27 00:19:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19180821856387072",
  "geo" : { },
  "id_str" : "19182344007061504",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg thanks, I need to write a new blog post someday",
  "id" : 19182344007061504,
  "in_reply_to_status_id" : 19180821856387072,
  "created_at" : "2010-12-27 00:06:41 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19174177382604800",
  "geo" : { },
  "id_str" : "19182235861123073",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky buffalo fans are used to disappointment",
  "id" : 19182235861123073,
  "in_reply_to_status_id" : 19174177382604800,
  "created_at" : "2010-12-27 00:06:16 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Aronoff",
      "screen_name" : "PeterAronoff",
      "indices" : [ 0, 13 ],
      "id_str" : "351880716",
      "id" : 351880716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19082001348829184",
  "geo" : { },
  "id_str" : "19140427273736193",
  "in_reply_to_user_id" : 131991214,
  "text" : "@peteraronoff broken link from your tweet",
  "id" : 19140427273736193,
  "in_reply_to_status_id" : 19082001348829184,
  "created_at" : "2010-12-26 21:20:08 +0000",
  "in_reply_to_screen_name" : "telemachus",
  "in_reply_to_user_id_str" : "131991214",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19102124411461632",
  "geo" : { },
  "id_str" : "19140375037874176",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton what a massacre.",
  "id" : 19140375037874176,
  "in_reply_to_status_id" : 19102124411461632,
  "created_at" : "2010-12-26 21:19:55 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Aronoff",
      "screen_name" : "PeterAronoff",
      "indices" : [ 0, 13 ],
      "id_str" : "351880716",
      "id" : 351880716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19078948608544768",
  "geo" : { },
  "id_str" : "19081168284553216",
  "in_reply_to_user_id" : 131991214,
  "text" : "@peteraronoff 404'D!",
  "id" : 19081168284553216,
  "in_reply_to_status_id" : 19078948608544768,
  "created_at" : "2010-12-26 17:24:39 +0000",
  "in_reply_to_screen_name" : "telemachus",
  "in_reply_to_user_id_str" : "131991214",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blizzardfail",
      "indices" : [ 59, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19066936214159360",
  "text" : "No flights until Wednesday. Awesome. Driving back Tuesday. #blizzardfail",
  "id" : 19066936214159360,
  "created_at" : "2010-12-26 16:28:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19034763847270400",
  "geo" : { },
  "id_str" : "19041669055778816",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier not yet, I bet we won't be back until Tuesday or Wednesday. Going to the airport soon since JetBlue won't pick up their phone.",
  "id" : 19041669055778816,
  "in_reply_to_status_id" : 19034763847270400,
  "created_at" : "2010-12-26 14:47:42 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19019671843905536",
  "text" : "Fuck.",
  "id" : 19019671843905536,
  "created_at" : "2010-12-26 13:20:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19017429338300416",
  "text" : "And JetBlue's call center drops your call after holding for 30 seconds.",
  "id" : 19017429338300416,
  "created_at" : "2010-12-26 13:11:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19015013301755904",
  "text" : "Flight canceled back to BOS for tonight...great.",
  "id" : 19015013301755904,
  "created_at" : "2010-12-26 13:01:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18902782622826496",
  "geo" : { },
  "id_str" : "18914632819277826",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit nope, sunday...but given the look of the BOSTON BLIZZARD 2010 i'm skeptical we'll make it out",
  "id" : 18914632819277826,
  "in_reply_to_status_id" : 18902782622826496,
  "created_at" : "2010-12-26 06:22:54 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18884385914757120",
  "text" : "Merry Quine-mas! http:\/\/mamememo.blogspot.com\/2010\/12\/merry-quine-mas-2010.html",
  "id" : 18884385914757120,
  "created_at" : "2010-12-26 04:22:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18839929782018048",
  "geo" : { },
  "id_str" : "18882262703546368",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier oh lame, mine's not canceled yet. Where are you flying out of?",
  "id" : 18882262703546368,
  "in_reply_to_status_id" : 18839929782018048,
  "created_at" : "2010-12-26 04:14:16 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18798750310858752",
  "text" : "TIL grandpa hunted for spare change on the Falls when they shut off the American side in 1969. Apparently people took pails of it home.",
  "id" : 18798750310858752,
  "created_at" : "2010-12-25 22:42:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18523563245969408",
  "text" : "Just got beat by my dad by one point in Agricola. Curses!",
  "id" : 18523563245969408,
  "created_at" : "2010-12-25 04:28:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil \u03BB Wadghule",
      "screen_name" : "anildigital",
      "indices" : [ 0, 12 ],
      "id_str" : "63603",
      "id" : 63603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18350485979267072",
  "geo" : { },
  "id_str" : "18384035130642432",
  "in_reply_to_user_id" : 63603,
  "text" : "@anildigital just replaced a join over a huge table (million+ rows) with a much faster WHERE IN and a better index. No brainer :)",
  "id" : 18384035130642432,
  "in_reply_to_status_id" : 18350485979267072,
  "created_at" : "2010-12-24 19:14:30 +0000",
  "in_reply_to_screen_name" : "anildigital",
  "in_reply_to_user_id_str" : "63603",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 62, 69 ],
      "id_str" : "9488922",
      "id" : 9488922
    }, {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 70, 77 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18373634632450049",
  "text" : "Antipatterns spotted in Buffalo! http:\/\/yfrog.com\/hsbbvmj \/cc @cpytel @tsaleh",
  "id" : 18373634632450049,
  "created_at" : "2010-12-24 18:33:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Davis",
      "screen_name" : "edavis10",
      "indices" : [ 0, 9 ],
      "id_str" : "9695352",
      "id" : 9695352
    }, {
      "name" : "New Relic",
      "screen_name" : "newrelic",
      "indices" : [ 20, 29 ],
      "id_str" : "15527007",
      "id" : 15527007
    }, {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 41, 48 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18346400815255552",
  "geo" : { },
  "id_str" : "18347472237625345",
  "in_reply_to_user_id" : 9695352,
  "text" : "@edavis10 it's from @newrelic, bronze on @heroku. very helpful.",
  "id" : 18347472237625345,
  "in_reply_to_status_id" : 18346400815255552,
  "created_at" : "2010-12-24 16:49:12 +0000",
  "in_reply_to_screen_name" : "edavis10",
  "in_reply_to_user_id_str" : "9695352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18345990826229760",
  "text" : "Performance optimization refactoring: I HAS IT. http:\/\/is.gd\/jnEvG",
  "id" : 18345990826229760,
  "created_at" : "2010-12-24 16:43:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18124655227305984",
  "text" : "Greek food, sabres, and Yuengling. Perfect night.",
  "id" : 18124655227305984,
  "created_at" : "2010-12-24 02:03:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18083483817615360",
  "geo" : { },
  "id_str" : "18094017916960769",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv MY ARTERIES",
  "id" : 18094017916960769,
  "in_reply_to_status_id" : 18083483817615360,
  "created_at" : "2010-12-24 00:02:04 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17711560700993536",
  "geo" : { },
  "id_str" : "17711835746672640",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis mirrors, dude",
  "id" : 17711835746672640,
  "in_reply_to_status_id" : 17711560700993536,
  "created_at" : "2010-12-22 22:43:25 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17697448508002304",
  "text" : "A visual guide to the open internet: http:\/\/www.theopeninter.net",
  "id" : 17697448508002304,
  "created_at" : "2010-12-22 21:46:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 112, 122 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17648867948371968",
  "text" : "Awesome christmas present: rubygems.org hit 100 million downloads! Huge thanks to everyone who's contributed to @gemcutter!",
  "id" : 17648867948371968,
  "created_at" : "2010-12-22 18:33:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 0, 7 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17360763433783296",
  "geo" : { },
  "id_str" : "17364711691517954",
  "in_reply_to_user_id" : 14237099,
  "text" : "@geemus CRITICISM APPLIED VROOMMMMMM FOGDAY!!!!",
  "id" : 17364711691517954,
  "in_reply_to_status_id" : 17360763433783296,
  "created_at" : "2010-12-21 23:44:04 +0000",
  "in_reply_to_screen_name" : "geemus",
  "in_reply_to_user_id_str" : "14237099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17354378226700288",
  "geo" : { },
  "id_str" : "17355125798473728",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight yeah, writes will fail if redis-server crashes, which it never has in months. Append only storage gives us decent durability",
  "id" : 17355125798473728,
  "in_reply_to_status_id" : 17354378226700288,
  "created_at" : "2010-12-21 23:05:59 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 25, 35 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17341765581279232",
  "geo" : { },
  "id_str" : "17354191185911808",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight yeah, seriously. @gemcutter's redis instance cranks at around 170 commands\/sec :)",
  "id" : 17354191185911808,
  "in_reply_to_status_id" : 17341765581279232,
  "created_at" : "2010-12-21 23:02:16 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 0, 8 ],
      "id_str" : "9337082",
      "id" : 9337082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17346468394303488",
  "geo" : { },
  "id_str" : "17351900441616385",
  "in_reply_to_user_id" : 9337082,
  "text" : "@godfoca XCOPY to the shared drive, duh",
  "id" : 17351900441616385,
  "in_reply_to_status_id" : 17346468394303488,
  "created_at" : "2010-12-21 22:53:10 +0000",
  "in_reply_to_screen_name" : "godfoca",
  "in_reply_to_user_id_str" : "9337082",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17318815960408066",
  "geo" : { },
  "id_str" : "17319372380962816",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight faster writes\/reads for sure. before it was one Downloads table...that would now have 99M rows :X",
  "id" : 17319372380962816,
  "in_reply_to_status_id" : 17318815960408066,
  "created_at" : "2010-12-21 20:43:54 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17311386187071489",
  "geo" : { },
  "id_str" : "17312219763056640",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight http:\/\/github.com\/rubygems\/gemcutter see app\/models\/download.rb and app\/controllers\/api\/v1\/downloads_controller.rb",
  "id" : 17312219763056640,
  "in_reply_to_status_id" : 17311386187071489,
  "created_at" : "2010-12-21 20:15:29 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17258105893027840",
  "geo" : { },
  "id_str" : "17311120805076992",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight courtesy of some extreme redis power :)",
  "id" : 17311120805076992,
  "in_reply_to_status_id" : 17258105893027840,
  "created_at" : "2010-12-21 20:11:07 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17292160499982336",
  "text" : "A much better explanation of what's at stake here, folks: http:\/\/is.gd\/jav1k",
  "id" : 17292160499982336,
  "created_at" : "2010-12-21 18:55:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17287533972955136",
  "text" : "Fuck. http:\/\/www.huffingtonpost.com\/2010\/12\/21\/net-neutrality-rules-pass_n_799775.html?ref=tw",
  "id" : 17287533972955136,
  "created_at" : "2010-12-21 18:37:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Mabey",
      "screen_name" : "bmabey",
      "indices" : [ 16, 23 ],
      "id_str" : "5417872",
      "id" : 5417872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17283589074845696",
  "text" : "Wow, looks like @bmabey's email-spec is above RFC 2822 when googling \"email spec\" http:\/\/bit.ly\/i8tkOk",
  "id" : 17283589074845696,
  "created_at" : "2010-12-21 18:21:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17251532558831616",
  "geo" : { },
  "id_str" : "17253010069528576",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez new redis site looks great, community definitely needed it!",
  "id" : 17253010069528576,
  "in_reply_to_status_id" : 17251532558831616,
  "created_at" : "2010-12-21 16:20:12 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17251484773126146",
  "text" : "RT @thoughtbot: Yuletide Logs and MongoDB Capped Collections: http:\/\/bit.ly\/f7xEf9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "17251430670794752",
    "text" : "Yuletide Logs and MongoDB Capped Collections: http:\/\/bit.ly\/f7xEf9",
    "id" : 17251430670794752,
    "created_at" : "2010-12-21 16:13:56 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 17251484773126146,
  "created_at" : "2010-12-21 16:14:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grooveshark",
      "screen_name" : "Grooveshark",
      "indices" : [ 29, 41 ],
      "id_str" : "3806441",
      "id" : 3806441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ 45, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 77 ],
      "url" : "http:\/\/t.co\/KJrKyny",
      "expanded_url" : "http:\/\/tinysong.com\/nbkC",
      "display_url" : "tinysong.com\/nbkC"
    } ]
  },
  "geo" : { },
  "id_str" : "17196214726426624",
  "text" : "listening to 2112 by Rush on @Grooveshark:   #nowplaying  http:\/\/t.co\/KJrKyny",
  "id" : 17196214726426624,
  "created_at" : "2010-12-21 12:34:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speedy Hundreds",
      "screen_name" : "ClassicRockProg",
      "indices" : [ 3, 19 ],
      "id_str" : "2553100724",
      "id" : 2553100724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17194449331294209",
  "text" : "RT @ClassicRockProg: is listening to Rush. Well it is 21.12!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "17187252710936576",
    "text" : "is listening to Rush. Well it is 21.12!!",
    "id" : 17187252710936576,
    "created_at" : "2010-12-21 11:58:55 +0000",
    "user" : {
      "name" : "Prog",
      "screen_name" : "ProgMagazineUK",
      "protected" : false,
      "id_str" : "24894216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460744337198825474\/2Np0LhIZ_normal.jpeg",
      "id" : 24894216,
      "verified" : false
    }
  },
  "id" : 17194449331294209,
  "created_at" : "2010-12-21 12:27:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Prather",
      "screen_name" : "perigrin",
      "indices" : [ 0, 9 ],
      "id_str" : "798335",
      "id" : 798335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16945543863336960",
  "geo" : { },
  "id_str" : "17007359314362368",
  "in_reply_to_user_id" : 798335,
  "text" : "@perigrin it is, that's unique gem names on the homepage. Overall we're close to 100k unique versions of those",
  "id" : 17007359314362368,
  "in_reply_to_status_id" : 16945543863336960,
  "created_at" : "2010-12-21 00:04:05 +0000",
  "in_reply_to_screen_name" : "perigrin",
  "in_reply_to_user_id_str" : "798335",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16912258240094208",
  "text" : "SNOW!",
  "id" : 16912258240094208,
  "created_at" : "2010-12-20 17:46:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mislav Marohni\u0107",
      "screen_name" : "mislav",
      "indices" : [ 4, 11 ],
      "id_str" : "7516242",
      "id" : 7516242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16878418293424128",
  "text" : "Hey @mislav any reason will_paginate hasn't shipped 3.0?",
  "id" : 16878418293424128,
  "created_at" : "2010-12-20 15:31:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Curious Mind",
      "screen_name" : "drusellers",
      "indices" : [ 0, 11 ],
      "id_str" : "9238852",
      "id" : 9238852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16865266507972608",
  "geo" : { },
  "id_str" : "16865433957171200",
  "in_reply_to_user_id" : 9238852,
  "text" : "@drusellers ahahahahaha IT HAS BEGUN",
  "id" : 16865433957171200,
  "in_reply_to_status_id" : 16865266507972608,
  "created_at" : "2010-12-20 14:40:07 +0000",
  "in_reply_to_screen_name" : "drusellers",
  "in_reply_to_user_id_str" : "9238852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16862619918934016",
  "text" : "Apparently 100M downloads, ~19k gems, and almost 100k versions is not enough to appease cranky slashdot commenters. http:\/\/bit.ly\/guA4Qn",
  "id" : 16862619918934016,
  "created_at" : "2010-12-20 14:28:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16718833989455873",
  "text" : "What a maniac. This is how one perfects his craft: http:\/\/www.varasanos.com\/PizzaRecipe.htm",
  "id" : 16718833989455873,
  "created_at" : "2010-12-20 04:57:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16669115397701632",
  "text" : "\"A boxing drama set in the near-future where 2,000-pound robots that look like humans do battle.\" WTF http:\/\/is.gd\/j2qGv",
  "id" : 16669115397701632,
  "created_at" : "2010-12-20 01:40:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 102, 112 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16595174893293568",
  "text" : "JHelioviewer is awesome, see some astonishing views of the Sun: http:\/\/www.jhelioviewer.org\/demo.html @neiltyson would love it!",
  "id" : 16595174893293568,
  "created_at" : "2010-12-19 20:46:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik DeBill",
      "screen_name" : "edebill",
      "indices" : [ 0, 8 ],
      "id_str" : "39057894",
      "id" : 39057894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16576626548543488",
  "geo" : { },
  "id_str" : "16582570426769408",
  "in_reply_to_user_id" : 39057894,
  "text" : "@edebill I would love to see if we're beating CPAN in terms of daily downloads, that would be a better measure IMO",
  "id" : 16582570426769408,
  "in_reply_to_status_id" : 16576626548543488,
  "created_at" : "2010-12-19 19:56:07 +0000",
  "in_reply_to_screen_name" : "edebill",
  "in_reply_to_user_id_str" : "39057894",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 25, 32 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16581643678515200",
  "text" : "1.9.2 rails migration on @heroku took ~1 hour, main issues: stupid 1.8 only syntax I wrote, and rack gem spitting out warnings. A+",
  "id" : 16581643678515200,
  "created_at" : "2010-12-19 19:52:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik DeBill",
      "screen_name" : "edebill",
      "indices" : [ 0, 8 ],
      "id_str" : "39057894",
      "id" : 39057894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16549866847076352",
  "geo" : { },
  "id_str" : "16569971605770240",
  "in_reply_to_user_id" : 39057894,
  "text" : "@edebill that's just unique gem names. we're hosting 92,915 gem versions from 18,896 gems currently",
  "id" : 16569971605770240,
  "in_reply_to_status_id" : 16549866847076352,
  "created_at" : "2010-12-19 19:06:03 +0000",
  "in_reply_to_screen_name" : "edebill",
  "in_reply_to_user_id_str" : "39057894",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16528544230277120",
  "text" : "Why I haven't played TF2 in months: http:\/\/img138.imageshack.us\/img138\/2756\/1292753852951.jpg",
  "id" : 16528544230277120,
  "created_at" : "2010-12-19 16:21:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16497997453991936",
  "geo" : { },
  "id_str" : "16499772940619776",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez evicted_keys is what exactly? number of keys EXPIRE booted out?",
  "id" : 16499772940619776,
  "in_reply_to_status_id" : 16497997453991936,
  "created_at" : "2010-12-19 14:27:07 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16170098435821568",
  "geo" : { },
  "id_str" : "16171007924510720",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh homebrew much?",
  "id" : 16171007924510720,
  "in_reply_to_status_id" : 16170098435821568,
  "created_at" : "2010-12-18 16:40:43 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15850980448931841",
  "text" : "Current status: http:\/\/www.wielandhelicopters.com.au\/images\/product\/extra_image\/helicopter-tree-crane.jpg",
  "id" : 15850980448931841,
  "created_at" : "2010-12-17 19:29:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 0, 12 ],
      "id_str" : "517029319",
      "id" : 517029319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15823702826422274",
  "text" : "@seacreature puts",
  "id" : 15823702826422274,
  "created_at" : "2010-12-17 17:40:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15535107167227904",
  "geo" : { },
  "id_str" : "15538108422426624",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg i can't\/won't \"nuke\" gems. contact the author.",
  "id" : 15538108422426624,
  "in_reply_to_status_id" : 15535107167227904,
  "created_at" : "2010-12-16 22:45:48 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amir Barylko",
      "screen_name" : "abarylko",
      "indices" : [ 0, 9 ],
      "id_str" : "24180793",
      "id" : 24180793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15515366105030657",
  "geo" : { },
  "id_str" : "15525573367431168",
  "in_reply_to_user_id" : 24180793,
  "text" : "@abarylko usually means something is wacky in your gemspec :) make an issue on http:\/\/help.rubygems.org and we'll get you sorted",
  "id" : 15525573367431168,
  "in_reply_to_status_id" : 15515366105030657,
  "created_at" : "2010-12-16 21:55:59 +0000",
  "in_reply_to_screen_name" : "abarylko",
  "in_reply_to_user_id_str" : "24180793",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15524788239867904",
  "text" : "Tab groups in FF are actually growing on me. Cmd-E to open up an expose-style view, you can use arrow keys to navigate in there.",
  "id" : 15524788239867904,
  "created_at" : "2010-12-16 21:52:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15454950947561472",
  "text" : "Submitted a Redis talk for SCALE9x. Still one more day to submit! https:\/\/www.socallinuxexpo.org\/scale9x\/",
  "id" : 15454950947561472,
  "created_at" : "2010-12-16 17:15:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15447172728225792",
  "text" : "Firefox 4's private browsing doesn't compare to Chrome's Incognito. Why does it share sessions? Trying to test logins from different users.",
  "id" : 15447172728225792,
  "created_at" : "2010-12-16 16:44:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex McHale",
      "screen_name" : "alexmchale",
      "indices" : [ 0, 11 ],
      "id_str" : "13964832",
      "id" : 13964832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15440742243639296",
  "geo" : { },
  "id_str" : "15443534941265920",
  "in_reply_to_user_id" : 13964832,
  "text" : "@alexmchale yes, chrome renders fonts better. :(",
  "id" : 15443534941265920,
  "in_reply_to_status_id" : 15440742243639296,
  "created_at" : "2010-12-16 16:30:00 +0000",
  "in_reply_to_screen_name" : "alexmchale",
  "in_reply_to_user_id_str" : "13964832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15438953041625088",
  "text" : "Seems like the Firefox 4 tab groups are a poorly implemented concept, too mouse driven. Mozilla can't get away from bloat.",
  "id" : 15438953041625088,
  "created_at" : "2010-12-16 16:11:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moore",
      "screen_name" : "cdmwebs",
      "indices" : [ 28, 36 ],
      "id_str" : "5692572",
      "id" : 5692572
    }, {
      "name" : "Chad Humphries",
      "screen_name" : "spicycode",
      "indices" : [ 37, 47 ],
      "id_str" : "278580629",
      "id" : 278580629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15436071894519809",
  "text" : "Yay, I have firebug! Thanks @cdmwebs @spicycode http:\/\/blog.getfirebug.com\/2010\/12\/10\/firebug-1-6-1b1\/",
  "id" : 15436071894519809,
  "created_at" : "2010-12-16 16:00:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15434650319065088",
  "text" : "Trying out Firefox beta 4 today. Feels snappy, not sure if I can go back to this foxy temptress full-time yet without Firebug.",
  "id" : 15434650319065088,
  "created_at" : "2010-12-16 15:54:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zeno Davatz",
      "screen_name" : "zdavatz",
      "indices" : [ 0, 8 ],
      "id_str" : "5733162",
      "id" : 5733162
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 48, 58 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 65, 72 ],
      "id_str" : "5186831",
      "id" : 5186831
    }, {
      "name" : "nap.tld, ltd.",
      "screen_name" : "zapnap",
      "indices" : [ 73, 80 ],
      "id_str" : "1566201",
      "id" : 1566201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15356384136663040",
  "geo" : { },
  "id_str" : "15404429452775424",
  "in_reply_to_user_id" : 5733162,
  "text" : "@zdavatz not sure, it's a separate service from @gemcutter...hey @lsegal @zapnap any ideas?",
  "id" : 15404429452775424,
  "in_reply_to_status_id" : 15356384136663040,
  "created_at" : "2010-12-16 13:54:36 +0000",
  "in_reply_to_screen_name" : "zdavatz",
  "in_reply_to_user_id_str" : "5733162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15282267505041408",
  "text" : "I am so excited for new music to come out using the Kitara. And concerts. It runs linux! http:\/\/www.youtube.com\/watch?v=Q2t5CpIMZQk",
  "id" : 15282267505041408,
  "created_at" : "2010-12-16 05:49:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15232381447315456",
  "geo" : { },
  "id_str" : "15232654613938176",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh dude I have 6 ascensions. It happens. http:\/\/alt.org\/nethack\/player-stats.php?player=DoctorNick",
  "id" : 15232654613938176,
  "in_reply_to_status_id" : 15232381447315456,
  "created_at" : "2010-12-16 02:32:02 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15232406294364160",
  "text" : "The Prince of Darkness is hilarious. http:\/\/www.buzzfeed.com\/reddit\/ozzy-osbourne-scares-the-fuck-out-of-people-at-mad",
  "id" : 15232406294364160,
  "created_at" : "2010-12-16 02:31:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Huckstep",
      "screen_name" : "darkhelmetlive",
      "indices" : [ 0, 15 ],
      "id_str" : "19567986",
      "id" : 19567986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15206729516060672",
  "geo" : { },
  "id_str" : "15209154574548992",
  "in_reply_to_user_id" : 19567986,
  "text" : "@darkhelmetlive https:\/\/rubygems.org\/passwords\/new ?",
  "id" : 15209154574548992,
  "in_reply_to_status_id" : 15206729516060672,
  "created_at" : "2010-12-16 00:58:39 +0000",
  "in_reply_to_screen_name" : "darkhelmetlive",
  "in_reply_to_user_id_str" : "19567986",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15207885709508608",
  "text" : "Facebook doesn't understand \"Ruby\" as a language I can speak.",
  "id" : 15207885709508608,
  "created_at" : "2010-12-16 00:53:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gustin",
      "screen_name" : "gustin",
      "indices" : [ 0, 7 ],
      "id_str" : "14381877",
      "id" : 14381877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15179159571529728",
  "geo" : { },
  "id_str" : "15183095175053312",
  "in_reply_to_user_id" : 14381877,
  "text" : "@gustin would love if you could show us what url was erroring out! http:\/\/help.hoptoadapp.com",
  "id" : 15183095175053312,
  "in_reply_to_status_id" : 15179159571529728,
  "created_at" : "2010-12-15 23:15:06 +0000",
  "in_reply_to_screen_name" : "gustin",
  "in_reply_to_user_id_str" : "14381877",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15169187253063680",
  "text" : "Current status: http:\/\/i.imgur.com\/A4yAI.jpg",
  "id" : 15169187253063680,
  "created_at" : "2010-12-15 22:19:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ahmed Al Hafoudh",
      "screen_name" : "alhafoudh",
      "indices" : [ 0, 10 ],
      "id_str" : "14870290",
      "id" : 14870290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15148872590430208",
  "geo" : { },
  "id_str" : "15167744706093057",
  "in_reply_to_user_id" : 14870290,
  "text" : "@alhafoudh how about bundle --local ? if everything is in vendor\/cache it should go faster with latest bundler",
  "id" : 15167744706093057,
  "in_reply_to_status_id" : 15148872590430208,
  "created_at" : "2010-12-15 22:14:06 +0000",
  "in_reply_to_screen_name" : "alhafoudh",
  "in_reply_to_user_id_str" : "14870290",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "indices" : [ 0, 8 ],
      "id_str" : "6532552",
      "id" : 6532552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15146185513766912",
  "geo" : { },
  "id_str" : "15146764222865408",
  "in_reply_to_user_id" : 6532552,
  "text" : "@nkohari https:\/\/dnsimple.com\/ command line domain registration is amazing (the site is great too)",
  "id" : 15146764222865408,
  "in_reply_to_status_id" : 15146185513766912,
  "created_at" : "2010-12-15 20:50:44 +0000",
  "in_reply_to_screen_name" : "nkohari",
  "in_reply_to_user_id_str" : "6532552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15112542376435712",
  "geo" : { },
  "id_str" : "15112717241163777",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad next time i'll pipe it to \/dev\/null, that will be faster",
  "id" : 15112717241163777,
  "in_reply_to_status_id" : 15112542376435712,
  "created_at" : "2010-12-15 18:35:27 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vladimir Andrijevik",
      "screen_name" : "vandrijevik",
      "indices" : [ 0, 12 ],
      "id_str" : "14407694",
      "id" : 14407694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15109707958063104",
  "geo" : { },
  "id_str" : "15111753289437184",
  "in_reply_to_user_id" : 14407694,
  "text" : "@vandrijevik WEBSCALEDATA (big big json array, going to skip putting it mongo in the first place instead)",
  "id" : 15111753289437184,
  "in_reply_to_status_id" : 15109707958063104,
  "created_at" : "2010-12-15 18:31:37 +0000",
  "in_reply_to_screen_name" : "vandrijevik",
  "in_reply_to_user_id_str" : "14407694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Angilly",
      "screen_name" : "angilly",
      "indices" : [ 0, 8 ],
      "id_str" : "16195791",
      "id" : 16195791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15084422042746881",
  "geo" : { },
  "id_str" : "15085017617145856",
  "in_reply_to_user_id" : 16195791,
  "text" : "@angilly my main concern is not parsing all of that JSON twice in any other format. use smaller document chunks for the array, 500 at a time",
  "id" : 15085017617145856,
  "in_reply_to_status_id" : 15084422042746881,
  "created_at" : "2010-12-15 16:45:23 +0000",
  "in_reply_to_screen_name" : "angilly",
  "in_reply_to_user_id_str" : "16195791",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Young",
      "screen_name" : "nicholaswyoung",
      "indices" : [ 0, 15 ],
      "id_str" : "10003492",
      "id" : 10003492
    }, {
      "name" : "MongoHQ, the elder",
      "screen_name" : "mongohq",
      "indices" : [ 74, 82 ],
      "id_str" : "2511331628",
      "id" : 2511331628
    }, {
      "name" : "Ryan Angilly",
      "screen_name" : "angilly",
      "indices" : [ 87, 95 ],
      "id_str" : "16195791",
      "id" : 16195791
    }, {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 96, 105 ],
      "id_str" : "14658472",
      "id" : 14658472
    }, {
      "name" : "Ethan Gunderson",
      "screen_name" : "ethangunderson",
      "indices" : [ 106, 121 ],
      "id_str" : "14412520",
      "id" : 14412520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15082752248389632",
  "geo" : { },
  "id_str" : "15083482787094528",
  "in_reply_to_user_id" : 10003492,
  "text" : "@nicholaswyoung just a huge JSON array dump. not sure about upgrading, on @mongohq \/cc @angilly @roidrage @ethangunderson",
  "id" : 15083482787094528,
  "in_reply_to_status_id" : 15082752248389632,
  "created_at" : "2010-12-15 16:39:17 +0000",
  "in_reply_to_screen_name" : "nicholaswyoung",
  "in_reply_to_user_id_str" : "10003492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mongodb",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15082481069850624",
  "text" : "BSON::InvalidDocument: Document too large: BSON documents are limited to 4MB. Lame :( #mongodb",
  "id" : 15082481069850624,
  "created_at" : "2010-12-15 16:35:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Feathers",
      "screen_name" : "mfeathers",
      "indices" : [ 0, 10 ],
      "id_str" : "14253068",
      "id" : 14253068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15068799531229184",
  "geo" : { },
  "id_str" : "15076791567785984",
  "in_reply_to_user_id" : 14253068,
  "text" : "@mfeathers we had to write a lot of UML for classes, always was a chore. Some kids were better at visio than coding :(",
  "id" : 15076791567785984,
  "in_reply_to_status_id" : 15068799531229184,
  "created_at" : "2010-12-15 16:12:41 +0000",
  "in_reply_to_screen_name" : "mfeathers",
  "in_reply_to_user_id_str" : "14253068",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15076511690260480",
  "text" : "Ahem, is anyone going to scale9x? http:\/\/www.socallinuxexpo.org\/ Considering submitting a talk.",
  "id" : 15076511690260480,
  "created_at" : "2010-12-15 16:11:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 13, 23 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15071584150622208",
  "geo" : { },
  "id_str" : "15071794415276032",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez for @gemcutter yes, but the changelog says \"better MONITOR output\"",
  "id" : 15071794415276032,
  "in_reply_to_status_id" : 15071584150622208,
  "created_at" : "2010-12-15 15:52:50 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15070934402600961",
  "geo" : { },
  "id_str" : "15071449442164737",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez nice! how did the MONITOR output change? it is still TIMESTAMP \"command\" \"arg1\" \"arg2\" ?",
  "id" : 15071449442164737,
  "in_reply_to_status_id" : 15070934402600961,
  "created_at" : "2010-12-15 15:51:28 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 3, 11 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15071280571092993",
  "text" : "RT @antirez: Ok, this is the impressive list of new features of Redis 2.2 -&gt; https:\/\/github.com\/antirez\/redis\/raw\/master\/00-RELEASENOTES",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "15070934402600961",
    "text" : "Ok, this is the impressive list of new features of Redis 2.2 -&gt; https:\/\/github.com\/antirez\/redis\/raw\/master\/00-RELEASENOTES",
    "id" : 15070934402600961,
    "created_at" : "2010-12-15 15:49:25 +0000",
    "user" : {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "protected" : false,
      "id_str" : "5813712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461550870648217602\/XjbUS5rb_normal.png",
      "id" : 5813712,
      "verified" : false
    }
  },
  "id" : 15071280571092993,
  "created_at" : "2010-12-15 15:50:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14917483953659904",
  "geo" : { },
  "id_str" : "15053767384760320",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense holy shit the third golden sun is out? Can you continue your game from the second one?",
  "id" : 15053767384760320,
  "in_reply_to_status_id" : 14917483953659904,
  "created_at" : "2010-12-15 14:41:12 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15038760852914176",
  "text" : "This is your brain on Vim. http:\/\/kevinw.github.com\/2010\/12\/15\/this-is-your-brain-on-vim\/",
  "id" : 15038760852914176,
  "created_at" : "2010-12-15 13:41:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14912368890871809",
  "text" : "Also, I wish Boston had an equivalent of garbage plates. Some nights just call for it.",
  "id" : 14912368890871809,
  "created_at" : "2010-12-15 05:19:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Peruzzini",
      "screen_name" : "KeightP",
      "indices" : [ 0, 8 ],
      "id_str" : "18247553",
      "id" : 18247553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14911481053192192",
  "geo" : { },
  "id_str" : "14911991537737728",
  "in_reply_to_user_id" : 18247553,
  "text" : "@KeightP did we just seriously pass the same cave?",
  "id" : 14911991537737728,
  "in_reply_to_status_id" : 14911481053192192,
  "created_at" : "2010-12-15 05:17:50 +0000",
  "in_reply_to_screen_name" : "KeightP",
  "in_reply_to_user_id_str" : "18247553",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badanimaljokes",
      "indices" : [ 54, 69 ]
    }, {
      "text" : "kindofdrunktweets",
      "indices" : [ 70, 88 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14907953404452864",
  "geo" : { },
  "id_str" : "14908777350307840",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense well if you play enough WoW, you can be one #badanimaljokes #kindofdrunktweets",
  "id" : 14908777350307840,
  "in_reply_to_status_id" : 14907953404452864,
  "created_at" : "2010-12-15 05:05:04 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14908175736119296",
  "text" : "This T station has achieved Cave status.",
  "id" : 14908175736119296,
  "created_at" : "2010-12-15 05:02:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mbta",
      "indices" : [ 50, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14908063530094592",
  "text" : "Big leak and 4\" salt crystal at Park St. Station. #mbta http:\/\/yfrog.com\/gy7pyzj",
  "id" : 14908063530094592,
  "created_at" : "2010-12-15 05:02:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 18, 27 ],
      "id_str" : "21431343",
      "id" : 21431343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14905677105332224",
  "text" : "As usual, awesome @bostonrb night and drinkup. Chilly night, but great conversations, code, and beer.",
  "id" : 14905677105332224,
  "created_at" : "2010-12-15 04:52:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Humphries",
      "screen_name" : "spicycode",
      "indices" : [ 0, 10 ],
      "id_str" : "278580629",
      "id" : 278580629
    }, {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 26, 35 ],
      "id_str" : "21431343",
      "id" : 21431343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14818011017908224",
  "text" : "@spicycode you're missing @bostonrb tonight! weak. come back soon!",
  "id" : 14818011017908224,
  "created_at" : "2010-12-14 23:04:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Humphries",
      "screen_name" : "spicycode",
      "indices" : [ 0, 10 ],
      "id_str" : "278580629",
      "id" : 278580629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14817518891835392",
  "text" : "@spicycode are you in boston or something?",
  "id" : 14817518891835392,
  "created_at" : "2010-12-14 23:02:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yardboy",
      "screen_name" : "Yardboy",
      "indices" : [ 0, 8 ],
      "id_str" : "7939892",
      "id" : 7939892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14806318753779712",
  "geo" : { },
  "id_str" : "14806924579053569",
  "in_reply_to_user_id" : 7939892,
  "text" : "@Yardboy or RUSH :(",
  "id" : 14806924579053569,
  "in_reply_to_status_id" : 14806318753779712,
  "created_at" : "2010-12-14 22:20:20 +0000",
  "in_reply_to_screen_name" : "Yardboy",
  "in_reply_to_user_id_str" : "7939892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14712304058769408",
  "geo" : { },
  "id_str" : "14713209009213440",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil maybe it means screwing open source developers over?",
  "id" : 14713209009213440,
  "in_reply_to_status_id" : 14712304058769408,
  "created_at" : "2010-12-14 16:07:57 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14493902136410113",
  "text" : "Watching the Princess Bride with @ablissfulgal since she's sick. This movie never gets old.",
  "id" : 14493902136410113,
  "created_at" : "2010-12-14 01:36:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14483764621082625",
  "text" : "HTTP is a beautiful thing: http:\/\/vimeo.com\/14439742",
  "id" : 14483764621082625,
  "created_at" : "2010-12-14 00:56:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14437446674546688",
  "text" : "HEYYY BOOO BOO! WHY DO YOU HAVE A SHOTGUN?! http:\/\/www.youtube.com\/watch?v=m6w0r-ScEG4",
  "id" : 14437446674546688,
  "created_at" : "2010-12-13 21:52:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twuration.com\/\" rel=\"nofollow\"\u003ETwuration\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14431728835760128",
  "text" : "I joined Twitter on the 3rd of May 2007, making my account 1,321 days old. Find your date at http:\/\/www.twuration.com\/",
  "id" : 14431728835760128,
  "created_at" : "2010-12-13 21:29:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Morrill",
      "screen_name" : "DanielleMorrill",
      "indices" : [ 0, 16 ],
      "id_str" : "7017692",
      "id" : 7017692
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 22, 31 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14172064546029569",
  "geo" : { },
  "id_str" : "14360941512626176",
  "in_reply_to_user_id" : 7017692,
  "text" : "@DanielleMORRILL yes, @rubygems is run off a gem webhook. whats up?",
  "id" : 14360941512626176,
  "in_reply_to_status_id" : 14172064546029569,
  "created_at" : "2010-12-13 16:48:09 +0000",
  "in_reply_to_screen_name" : "DanielleMorrill",
  "in_reply_to_user_id_str" : "7017692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Collison",
      "screen_name" : "patrickc",
      "indices" : [ 0, 9 ],
      "id_str" : "4939401",
      "id" : 4939401
    }, {
      "name" : "Avi Bryant",
      "screen_name" : "avibryant",
      "indices" : [ 10, 20 ],
      "id_str" : "13192",
      "id" : 13192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14176273932746752",
  "geo" : { },
  "id_str" : "14178974280187904",
  "in_reply_to_user_id" : 4939401,
  "text" : "@patrickc @avibryant it's hard enough to get some CS kids to use version control. really?",
  "id" : 14178974280187904,
  "in_reply_to_status_id" : 14176273932746752,
  "created_at" : "2010-12-13 04:45:05 +0000",
  "in_reply_to_screen_name" : "patrickc",
  "in_reply_to_user_id_str" : "4939401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 0, 7 ],
      "id_str" : "3928731",
      "id" : 3928731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14177603820720128",
  "geo" : { },
  "id_str" : "14178771045191680",
  "in_reply_to_user_id" : 3928731,
  "text" : "@cssboy that is not the right video.",
  "id" : 14178771045191680,
  "in_reply_to_status_id" : 14177603820720128,
  "created_at" : "2010-12-13 04:44:17 +0000",
  "in_reply_to_screen_name" : "cssboy",
  "in_reply_to_user_id_str" : "3928731",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14124181008424960",
  "text" : "DUHHHH http:\/\/rails.rubyonrails.org\/classes\/ActionController\/Base.html#M000453",
  "id" : 14124181008424960,
  "created_at" : "2010-12-13 01:07:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14121066293104641",
  "text" : "Anyone know how to turn params logging off (not parsing) for a specific action in Rails 3? http:\/\/is.gd\/iDIxW",
  "id" : 14121066293104641,
  "created_at" : "2010-12-13 00:54:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14118496497569792",
  "geo" : { },
  "id_str" : "14120866568740864",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek HOUSE UNLOCKED, 1200 HUMAN POINTS",
  "id" : 14120866568740864,
  "in_reply_to_status_id" : 14118496497569792,
  "created_at" : "2010-12-13 00:54:11 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Helmkamp",
      "screen_name" : "brynary",
      "indices" : [ 0, 8 ],
      "id_str" : "2049071",
      "id" : 2049071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14048834015465472",
  "geo" : { },
  "id_str" : "14058779737853953",
  "in_reply_to_user_id" : 2049071,
  "text" : "@brynary been actually thinking of trying out Steak for this. not sure yet if I should switch.",
  "id" : 14058779737853953,
  "in_reply_to_status_id" : 14048834015465472,
  "created_at" : "2010-12-12 20:47:28 +0000",
  "in_reply_to_screen_name" : "brynary",
  "in_reply_to_user_id_str" : "2049071",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Helmkamp",
      "screen_name" : "brynary",
      "indices" : [ 0, 8 ],
      "id_str" : "2049071",
      "id" : 2049071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14048834015465472",
  "geo" : { },
  "id_str" : "14054112442195968",
  "in_reply_to_user_id" : 2049071,
  "text" : "@brynary truth.",
  "id" : 14054112442195968,
  "in_reply_to_status_id" : 14048834015465472,
  "created_at" : "2010-12-12 20:28:56 +0000",
  "in_reply_to_screen_name" : "brynary",
  "in_reply_to_user_id_str" : "2049071",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Humphries",
      "screen_name" : "spicycode",
      "indices" : [ 0, 10 ],
      "id_str" : "278580629",
      "id" : 278580629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14054071904243712",
  "text" : "@spicycode CLOUD3SCALE",
  "id" : 14054071904243712,
  "created_at" : "2010-12-12 20:28:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14025095408259073",
  "geo" : { },
  "id_str" : "14032807495995392",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck pretty much what i'm using it for, only showing the last ~15 elements and dont want to DELETE all the time",
  "id" : 14032807495995392,
  "in_reply_to_status_id" : 14025095408259073,
  "created_at" : "2010-12-12 19:04:16 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14031873781010432",
  "text" : "I love Cucumber. Refactored a huge part of the app, had to change some models\/controllers, new rspec's of course, cukes ALL GREEN. SHIP IT!",
  "id" : 14031873781010432,
  "created_at" : "2010-12-12 19:00:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonardo Mateo",
      "screen_name" : "k4nd4lf",
      "indices" : [ 0, 8 ],
      "id_str" : "52960866",
      "id" : 52960866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13988060869951488",
  "geo" : { },
  "id_str" : "14010171713916928",
  "in_reply_to_user_id" : 52960866,
  "text" : "@k4nd4lf looks fine here. is your traceroute to it slow?",
  "id" : 14010171713916928,
  "in_reply_to_status_id" : 13988060869951488,
  "created_at" : "2010-12-12 17:34:19 +0000",
  "in_reply_to_screen_name" : "k4nd4lf",
  "in_reply_to_user_id_str" : "52960866",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seivan Heidari",
      "screen_name" : "Seivanheidari",
      "indices" : [ 0, 14 ],
      "id_str" : "93118049",
      "id" : 93118049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13989321761619968",
  "geo" : { },
  "id_str" : "13990405192294400",
  "in_reply_to_user_id" : 93118049,
  "text" : "@Seivanheidari dude you're preaching to the choir",
  "id" : 13990405192294400,
  "in_reply_to_status_id" : 13989321761619968,
  "created_at" : "2010-12-12 16:15:47 +0000",
  "in_reply_to_screen_name" : "Seivanheidari",
  "in_reply_to_user_id_str" : "93118049",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seivan Heidari",
      "screen_name" : "Seivanheidari",
      "indices" : [ 0, 14 ],
      "id_str" : "93118049",
      "id" : 93118049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13988926305869824",
  "geo" : { },
  "id_str" : "13989190869975041",
  "in_reply_to_user_id" : 93118049,
  "text" : "@Seivanheidari yeah it would be too much of a pain in redis, dont need to keep everything in memory. and fun fact: it's for a redis app :)",
  "id" : 13989190869975041,
  "in_reply_to_status_id" : 13988926305869824,
  "created_at" : "2010-12-12 16:10:57 +0000",
  "in_reply_to_screen_name" : "Seivanheidari",
  "in_reply_to_user_id_str" : "93118049",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13988960434921472",
  "text" : "Nothing is better than a domain model that fits a meat grinder perfectly. Hopper, Grinder classes incoming!",
  "id" : 13988960434921472,
  "created_at" : "2010-12-12 16:10:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13661822569676800",
  "geo" : { },
  "id_str" : "13986626678030336",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl fixed!",
  "id" : 13986626678030336,
  "in_reply_to_status_id" : 13661822569676800,
  "created_at" : "2010-12-12 16:00:46 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13985279958319104",
  "text" : "Reasons being: Capped collections, and I don't want to reparse JSON twice that's incoming to the service. BOOM",
  "id" : 13985279958319104,
  "created_at" : "2010-12-12 15:55:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13983841609850880",
  "geo" : { },
  "id_str" : "13984827581669377",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits DESIGNBRO, make me a blender, i'll sell it in 2048 for you",
  "id" : 13984827581669377,
  "in_reply_to_status_id" : 13983841609850880,
  "created_at" : "2010-12-12 15:53:37 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13984602876018688",
  "text" : "Going to use Postgres AND Mongo, SIDE BY SIDE. OH MY GOODNESS",
  "id" : 13984602876018688,
  "created_at" : "2010-12-12 15:52:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 3, 12 ],
      "id_str" : "14658472",
      "id" : 14658472
    }, {
      "name" : "Pieter Noordhuis",
      "screen_name" : "pnoordhuis",
      "indices" : [ 68, 79 ],
      "id_str" : "14809096",
      "id" : 14809096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13971946425294848",
  "text" : "RT @roidrage: Nice overview slide set of what's new in Redis 2.2 by @pnoordhuis: http:\/\/roidi.us\/vjUD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/kiwi-app.net\" rel=\"nofollow\"\u003EKiwi\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pieter Noordhuis",
        "screen_name" : "pnoordhuis",
        "indices" : [ 54, 65 ],
        "id_str" : "14809096",
        "id" : 14809096
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "13944133068521472",
    "text" : "Nice overview slide set of what's new in Redis 2.2 by @pnoordhuis: http:\/\/roidi.us\/vjUD",
    "id" : 13944133068521472,
    "created_at" : "2010-12-12 13:11:55 +0000",
    "user" : {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "protected" : false,
      "id_str" : "14658472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2938540224\/9ffc554b0eabb077a915cfe0d56f3c1f_normal.jpeg",
      "id" : 14658472,
      "verified" : false
    }
  },
  "id" : 13971946425294848,
  "created_at" : "2010-12-12 15:02:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13876223834857472",
  "geo" : { },
  "id_str" : "13971863864606720",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius i prefer \"Mechanic\"",
  "id" : 13971863864606720,
  "in_reply_to_status_id" : 13876223834857472,
  "created_at" : "2010-12-12 15:02:06 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nikki graziano",
      "screen_name" : "nikkigraziano",
      "indices" : [ 0, 14 ],
      "id_str" : "12914422",
      "id" : 12914422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13834972238454784",
  "geo" : { },
  "id_str" : "13836130818465792",
  "in_reply_to_user_id" : 12914422,
  "text" : "@nikkigraziano OH's are way better when not anonymous",
  "id" : 13836130818465792,
  "in_reply_to_status_id" : 13834972238454784,
  "created_at" : "2010-12-12 06:02:45 +0000",
  "in_reply_to_screen_name" : "nikkigraziano",
  "in_reply_to_user_id_str" : "12914422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13805872551567361",
  "geo" : { },
  "id_str" : "13806744320868352",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits apparently android can't comprehend !'s",
  "id" : 13806744320868352,
  "in_reply_to_status_id" : 13805872551567361,
  "created_at" : "2010-12-12 04:05:59 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13805872551567361",
  "geo" : { },
  "id_str" : "13806637294813184",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits THE GAME IS AFOOT\u00DF",
  "id" : 13806637294813184,
  "in_reply_to_status_id" : 13805872551567361,
  "created_at" : "2010-12-12 04:05:33 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13705532539932672",
  "geo" : { },
  "id_str" : "13707923901386752",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety IF YOU DONT LIKE AMERICA YOU CAN GEEET OUT http:\/\/www.youtube.com\/watch?v=nT0OqHr3wHQ",
  "id" : 13707923901386752,
  "in_reply_to_status_id" : 13705532539932672,
  "created_at" : "2010-12-11 21:33:18 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13689230093983744",
  "text" : "HACKING http:\/\/www.youtube.com\/watch?v=FztcnouLezM",
  "id" : 13689230093983744,
  "created_at" : "2010-12-11 20:19:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13687443861540864",
  "text" : "Goodnight, Dune http:\/\/imgur.com\/j4yyY.png",
  "id" : 13687443861540864,
  "created_at" : "2010-12-11 20:11:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13641805509697536",
  "text" : "XBOX TWEETS",
  "id" : 13641805509697536,
  "created_at" : "2010-12-11 17:10:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13637191552991232",
  "text" : "@IselaMariaPhoto around 12:30 after a quick 4th floor visit",
  "id" : 13637191552991232,
  "created_at" : "2010-12-11 16:52:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13601371542523905",
  "text" : "Finally hooked up my twitter to @ablissfulgal's iPad. This app is seriously nice.",
  "id" : 13601371542523905,
  "created_at" : "2010-12-11 14:29:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13314904274509824",
  "text" : "These kids are really learning a lot! http:\/\/www.boston.com\/bigpicture\/2010\/12\/london_tuition_fee_protest.html",
  "id" : 13314904274509824,
  "created_at" : "2010-12-10 19:31:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13279372446269440",
  "geo" : { },
  "id_str" : "13280348557283328",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh it's always on. horiz\/vert splits, session reattaching helps immensely. still learning the rest.",
  "id" : 13280348557283328,
  "in_reply_to_status_id" : 13279372446269440,
  "created_at" : "2010-12-10 17:14:16 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 61, 72 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13278300935815168",
  "text" : "Love, hate and tmux. Glad to see this catching on with other @thoughtbot folks. http:\/\/is.gd\/ivrI7",
  "id" : 13278300935815168,
  "created_at" : "2010-12-10 17:06:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 0, 11 ],
      "id_str" : "9070452",
      "id" : 9070452
    }, {
      "name" : "Carl Lerche",
      "screen_name" : "carllerche",
      "indices" : [ 12, 23 ],
      "id_str" : "3763061",
      "id" : 3763061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13272030535225344",
  "geo" : { },
  "id_str" : "13272874647289856",
  "in_reply_to_user_id" : 9070452,
  "text" : "@jimweirich @carllerche yeah, checking out Queue now. thanks.",
  "id" : 13272874647289856,
  "in_reply_to_status_id" : 13272030535225344,
  "created_at" : "2010-12-10 16:44:34 +0000",
  "in_reply_to_screen_name" : "jimweirich",
  "in_reply_to_user_id_str" : "9070452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Lerche",
      "screen_name" : "carllerche",
      "indices" : [ 0, 11 ],
      "id_str" : "3763061",
      "id" : 3763061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13269212508196864",
  "geo" : { },
  "id_str" : "13269985132544001",
  "in_reply_to_user_id" : 3763061,
  "text" : "@carllerche i guess i dont understand why these actions aren't atomic to begin with, or why this is necessary to start",
  "id" : 13269985132544001,
  "in_reply_to_status_id" : 13269212508196864,
  "created_at" : "2010-12-10 16:33:05 +0000",
  "in_reply_to_screen_name" : "carllerche",
  "in_reply_to_user_id_str" : "3763061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 0, 11 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13266345206484992",
  "geo" : { },
  "id_str" : "13267725593874432",
  "in_reply_to_user_id" : 9070452,
  "text" : "@jimweirich argh, is the problem really this hard? I just want to clear a list while still pushing to into it in a thread.",
  "id" : 13267725593874432,
  "in_reply_to_status_id" : 13266345206484992,
  "created_at" : "2010-12-10 16:24:06 +0000",
  "in_reply_to_screen_name" : "jimweirich",
  "in_reply_to_user_id_str" : "9070452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13263570011684865",
  "text" : "\"I needed to log onto the mainframe to test stuff\" \"do you work in 1970?\" \"Well I work at a financial institution, so yes\"",
  "id" : 13263570011684865,
  "created_at" : "2010-12-10 16:07:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 0, 11 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13256867186745344",
  "geo" : { },
  "id_str" : "13263270173474816",
  "in_reply_to_user_id" : 9070452,
  "text" : "@jimweirich pushing happens in a thread, need to pop all the list every few seconds but keep the list intact and also not lose any.",
  "id" : 13263270173474816,
  "in_reply_to_status_id" : 13256867186745344,
  "created_at" : "2010-12-10 16:06:24 +0000",
  "in_reply_to_screen_name" : "jimweirich",
  "in_reply_to_user_id_str" : "9070452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pop",
      "indices" : [ 84, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13222522271043587",
  "text" : "Looks like a = [1, 2, 3]; a.pop(a.size) was what I needed. ruby-doc.org didn't show #pop as taking an argument :(",
  "id" : 13222522271043587,
  "created_at" : "2010-12-10 13:24:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "replace",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13077174202404865",
  "text" : "I need to atomically pop off all elements from a Ruby array. #replace would work, but it doesn't return the values that were in the array.",
  "id" : 13077174202404865,
  "created_at" : "2010-12-10 03:46:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13031994459955200",
  "text" : "People still argue about frameworks? What year do they live in? http:\/\/is.gd\/isYkd",
  "id" : 13031994459955200,
  "created_at" : "2010-12-10 00:47:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12563057737732096",
  "text" : "Does anyone else hate this sentiment? \"If you're using a NoSQL database, you fucked up somewhere.\" http:\/\/is.gd\/ioR8F",
  "id" : 12563057737732096,
  "created_at" : "2010-12-08 17:44:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 9, 16 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12512596619952128",
  "text" : "Congrats @heroku, please don't stop kicking ass",
  "id" : 12512596619952128,
  "created_at" : "2010-12-08 14:23:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12356766859792385",
  "text" : "Sabres put up a great fight. Only got booed once outside the garden with 'miller sucks!'",
  "id" : 12356766859792385,
  "created_at" : "2010-12-08 04:04:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12313684160282625",
  "text" : "Current status: http:\/\/twitpic.com\/3dx4py",
  "id" : 12313684160282625,
  "created_at" : "2010-12-08 01:13:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12295747680608256",
  "text" : "SABRES!",
  "id" : 12295747680608256,
  "created_at" : "2010-12-08 00:01:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    }, {
      "name" : "Caius Durling",
      "screen_name" : "Caius",
      "indices" : [ 7, 13 ],
      "id_str" : "5857812",
      "id" : 5857812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12150942459760640",
  "geo" : { },
  "id_str" : "12154894748221440",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy @Caius the big win for me, others new to a project, and CI, is that you can go from zero to 60 with `bundle` even faster",
  "id" : 12154894748221440,
  "in_reply_to_status_id" : 12150942459760640,
  "created_at" : "2010-12-07 14:42:07 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12145737764708352",
  "geo" : { },
  "id_str" : "12149144063836160",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy not sure what your fuss is about. Using (not requiring) bundler while developing a gem makes setup and testing easier",
  "id" : 12149144063836160,
  "in_reply_to_status_id" : 12145737764708352,
  "created_at" : "2010-12-07 14:19:16 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12060651887271936",
  "geo" : { },
  "id_str" : "12120178720505857",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu I want to hide yanked gems from gems#show. But that sorting is right, see Gem::Version#&lt;=&gt;",
  "id" : 12120178720505857,
  "in_reply_to_status_id" : 12060651887271936,
  "created_at" : "2010-12-07 12:24:10 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "follow @mattetti",
      "screen_name" : "merbist",
      "indices" : [ 0, 8 ],
      "id_str" : "1549117117",
      "id" : 1549117117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12038607946653696",
  "geo" : { },
  "id_str" : "12119844568694784",
  "in_reply_to_user_id" : 16476741,
  "text" : "@merbist dude you have no idea :(",
  "id" : 12119844568694784,
  "in_reply_to_status_id" : 12038607946653696,
  "created_at" : "2010-12-07 12:22:50 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11970609084899329",
  "text" : "The \"Dolphins\" episode of Bullshit is some of the most awkward, unsettling TV I've watched in years.",
  "id" : 11970609084899329,
  "created_at" : "2010-12-07 02:29:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11958711597670400",
  "text" : "Definitely the same song: http:\/\/www.youtube.com\/watch?v=r-NF-gIFAWE http:\/\/www.youtube.com\/watch?v=2w7M8QSl3xg",
  "id" : 11958711597670400,
  "created_at" : "2010-12-07 01:42:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11931721654079488",
  "geo" : { },
  "id_str" : "11932234428715008",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie why cant you use LRANGE 1000 -1 ? Maybe i'm missing the point.",
  "id" : 11932234428715008,
  "in_reply_to_status_id" : 11931721654079488,
  "created_at" : "2010-12-06 23:57:21 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poul Stevens",
      "screen_name" : "louisck",
      "indices" : [ 11, 19 ],
      "id_str" : "2218092372",
      "id" : 2218092372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11932018443030530",
  "text" : "Seriously, @louisck is funny. http:\/\/is.gd\/ijnHG",
  "id" : 11932018443030530,
  "created_at" : "2010-12-06 23:56:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11913113217531904",
  "geo" : { },
  "id_str" : "11913918855249920",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub RABBLE! PEAS AND CARROTS PEAS AND CARROTS! RABBLE RABBLE RABBLE!",
  "id" : 11913918855249920,
  "in_reply_to_status_id" : 11913113217531904,
  "created_at" : "2010-12-06 22:44:34 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "billsaysthis",
      "screen_name" : "billsaysthis",
      "indices" : [ 0, 13 ],
      "id_str" : "15472352",
      "id" : 15472352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11865367555084288",
  "geo" : { },
  "id_str" : "11911523572129792",
  "in_reply_to_user_id" : 15472352,
  "text" : "@billsaysthis ended that era a while ago. the changelog does a much better job than I ever could :)",
  "id" : 11911523572129792,
  "in_reply_to_status_id" : 11865367555084288,
  "created_at" : "2010-12-06 22:35:03 +0000",
  "in_reply_to_screen_name" : "billsaysthis",
  "in_reply_to_user_id_str" : "15472352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Maleh",
      "screen_name" : "AndyMaleh",
      "indices" : [ 0, 10 ],
      "id_str" : "16437273",
      "id" : 16437273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11830357527633920",
  "geo" : { },
  "id_str" : "11835457025343488",
  "in_reply_to_user_id" : 16437273,
  "text" : "@AndyMaleh can you open up a request on help.rubygems.org? We'll get you sorted",
  "id" : 11835457025343488,
  "in_reply_to_status_id" : 11830357527633920,
  "created_at" : "2010-12-06 17:32:47 +0000",
  "in_reply_to_screen_name" : "AndyMaleh",
  "in_reply_to_user_id_str" : "16437273",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11586618540433408",
  "text" : "Been playing too much Halo: Reach this weekend. My gamertag is Doctor Q if you don't have me yet.",
  "id" : 11586618540433408,
  "created_at" : "2010-12-06 01:03:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11559546556252160",
  "geo" : { },
  "id_str" : "11561867885416448",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv been there since the summer dude",
  "id" : 11561867885416448,
  "in_reply_to_status_id" : 11559546556252160,
  "created_at" : "2010-12-05 23:25:38 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Nyman",
      "screen_name" : "tnm",
      "indices" : [ 0, 4 ],
      "id_str" : "77009486",
      "id" : 77009486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11526357427167232",
  "geo" : { },
  "id_str" : "11537895793889280",
  "in_reply_to_user_id" : 77009486,
  "text" : "@tnm redis book? would love to peruse :)",
  "id" : 11537895793889280,
  "in_reply_to_status_id" : 11526357427167232,
  "created_at" : "2010-12-05 21:50:23 +0000",
  "in_reply_to_screen_name" : "tnm",
  "in_reply_to_user_id_str" : "77009486",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11236669600571392",
  "text" : "Yeah, well, that's just like your opinion man. http:\/\/www.viddler.com\/explore\/Magus\/videos\/12\/",
  "id" : 11236669600571392,
  "created_at" : "2010-12-05 01:53:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Turnbull",
      "screen_name" : "brianturnbull",
      "indices" : [ 0, 14 ],
      "id_str" : "1896331",
      "id" : 1896331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11229489774198785",
  "geo" : { },
  "id_str" : "11229820813836289",
  "in_reply_to_user_id" : 1896331,
  "text" : "@brianturnbull jealous, dude. i miss doing that, especially hanging them, ladders, wrenches...all of it :(",
  "id" : 11229820813836289,
  "in_reply_to_status_id" : 11229489774198785,
  "created_at" : "2010-12-05 01:26:12 +0000",
  "in_reply_to_screen_name" : "brianturnbull",
  "in_reply_to_user_id_str" : "1896331",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11199631144779776",
  "geo" : { },
  "id_str" : "11203000525660161",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza invoicemachine is tight",
  "id" : 11203000525660161,
  "in_reply_to_status_id" : 11199631144779776,
  "created_at" : "2010-12-04 23:39:38 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10716126690418689",
  "geo" : { },
  "id_str" : "10717516569518080",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey welcome to Rails!",
  "id" : 10717516569518080,
  "in_reply_to_status_id" : 10716126690418689,
  "created_at" : "2010-12-03 15:30:29 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fikri Rahman",
      "screen_name" : "fikri_rahman",
      "indices" : [ 3, 16 ],
      "id_str" : "33422007",
      "id" : 33422007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10717452774150144",
  "text" : "RT @fikri_rahman: redis the hacker's database http:\/\/bit.ly\/h9IuRG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10706467602567168",
    "text" : "redis the hacker's database http:\/\/bit.ly\/h9IuRG",
    "id" : 10706467602567168,
    "created_at" : "2010-12-03 14:46:35 +0000",
    "user" : {
      "name" : "Fikri Rahman",
      "screen_name" : "fikri_rahman",
      "protected" : false,
      "id_str" : "33422007",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492319836534349824\/zjfmBJ_n_normal.png",
      "id" : 33422007,
      "verified" : false
    }
  },
  "id" : 10717452774150144,
  "created_at" : "2010-12-03 15:30:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10712642482081793",
  "geo" : { },
  "id_str" : "10712844148416512",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey https:\/\/github.com\/bmabey\/email-spec",
  "id" : 10712844148416512,
  "in_reply_to_status_id" : 10712642482081793,
  "created_at" : "2010-12-03 15:11:55 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10686034547318784",
  "text" : "nyooooooo http:\/\/imgur.com\/td4q4.jpg",
  "id" : 10686034547318784,
  "created_at" : "2010-12-03 13:25:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marrily Happily",
      "screen_name" : "marrilyhappily",
      "indices" : [ 23, 38 ],
      "id_str" : "198234033",
      "id" : 198234033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10500465498259456",
  "text" : "It's thursday, so it's @marrilyhappily night. Loving this webapp.",
  "id" : 10500465498259456,
  "created_at" : "2010-12-03 01:08:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10473331438395392",
  "text" : "http:\/\/dumbtweetsatcelebrities.tumblr.com\/",
  "id" : 10473331438395392,
  "created_at" : "2010-12-02 23:20:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10471239248252928",
  "text" : "git checkout -p\n\nthat is all.",
  "id" : 10471239248252928,
  "created_at" : "2010-12-02 23:11:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10465387439198209",
  "geo" : { },
  "id_str" : "10465704981569536",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler has_many :meetings, :through =&gt; :timewastings",
  "id" : 10465704981569536,
  "in_reply_to_status_id" : 10465387439198209,
  "created_at" : "2010-12-02 22:49:53 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10465023331663872",
  "text" : "zomg. http:\/\/things90skidsrealize.com",
  "id" : 10465023331663872,
  "created_at" : "2010-12-02 22:47:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 0, 6 ],
      "id_str" : "1438261",
      "id" : 1438261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10450221901291520",
  "geo" : { },
  "id_str" : "10450530786607105",
  "in_reply_to_user_id" : 1438261,
  "text" : "@atmos dude stop dropping those production databases",
  "id" : 10450530786607105,
  "in_reply_to_status_id" : 10450221901291520,
  "created_at" : "2010-12-02 21:49:35 +0000",
  "in_reply_to_screen_name" : "atmos",
  "in_reply_to_user_id_str" : "1438261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10371697270063104",
  "text" : "Whoa, dudes made of Arsenic? Groovy. http:\/\/gizmodo.com\/5704158\/",
  "id" : 10371697270063104,
  "created_at" : "2010-12-02 16:36:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Alba",
      "screen_name" : "joealba",
      "indices" : [ 0, 8 ],
      "id_str" : "9664212",
      "id" : 9664212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10336089533325312",
  "geo" : { },
  "id_str" : "10336991770050560",
  "in_reply_to_user_id" : 9664212,
  "text" : "@joealba easier to fork it on github, use the :git option",
  "id" : 10336991770050560,
  "in_reply_to_status_id" : 10336089533325312,
  "created_at" : "2010-12-02 14:18:25 +0000",
  "in_reply_to_screen_name" : "joealba",
  "in_reply_to_user_id_str" : "9664212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10126551681073152",
  "text" : "I've figured out why so many unwind to video games daily (myself included): after being a loser all day it's nice to win something",
  "id" : 10126551681073152,
  "created_at" : "2010-12-02 00:22:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9834817625526273",
  "text" : "\"Death Buy Lemonade\" is great. http:\/\/is.gd\/i1IqC (via @kcgeep)",
  "id" : 9834817625526273,
  "created_at" : "2010-12-01 05:02:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
Grailbird.data.tweets_2011_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shunsuke Nakamura",
      "screen_name" : "sunsuk7tp",
      "indices" : [ 0, 10 ],
      "id_str" : "14712537",
      "id" : 14712537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75749046207250432",
  "geo" : { },
  "id_str" : "75768854478979072",
  "in_reply_to_user_id" : 14712537,
  "text" : "@sunsuk7tp hi, have you seen http:\/\/bit.ly\/igEiZ2 ? if you have other questions let us know at http:\/\/support.radishapp.com !",
  "id" : 75768854478979072,
  "in_reply_to_status_id" : 75749046207250432,
  "created_at" : "2011-06-01 03:41:17 +0000",
  "in_reply_to_screen_name" : "sunsuk7tp",
  "in_reply_to_user_id_str" : "14712537",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75754447355133952",
  "geo" : { },
  "id_str" : "75756295801683968",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit I hate net-http so hard",
  "id" : 75756295801683968,
  "in_reply_to_status_id" : 75754447355133952,
  "created_at" : "2011-06-01 02:51:23 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wood",
      "screen_name" : "JellybobUK",
      "indices" : [ 0, 11 ],
      "id_str" : "16557322",
      "id" : 16557322
    }, {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "indices" : [ 18, 28 ],
      "id_str" : "220097555",
      "id" : 220097555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75680799176921088",
  "geo" : { },
  "id_str" : "75683880518164480",
  "in_reply_to_user_id" : 16557322,
  "text" : "@JellybobUK yeah, @radishapp is somewhere between dev and ops...understanding data and how it effects load\/storage",
  "id" : 75683880518164480,
  "in_reply_to_status_id" : 75680799176921088,
  "created_at" : "2011-05-31 22:03:37 +0000",
  "in_reply_to_screen_name" : "JellybobUK",
  "in_reply_to_user_id_str" : "16557322",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75678828701286400",
  "geo" : { },
  "id_str" : "75681980859166720",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety I am very tempted to post that to http:\/\/reddit.com\/r\/adviceanimals",
  "id" : 75681980859166720,
  "in_reply_to_status_id" : 75678828701286400,
  "created_at" : "2011-05-31 21:56:04 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75678828701286400",
  "geo" : { },
  "id_str" : "75679158142910464",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety dude WTF",
  "id" : 75679158142910464,
  "in_reply_to_status_id" : 75678828701286400,
  "created_at" : "2011-05-31 21:44:52 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Redpath",
      "screen_name" : "lukeredpath",
      "indices" : [ 0, 12 ],
      "id_str" : "72573",
      "id" : 72573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75668523728388096",
  "geo" : { },
  "id_str" : "75669079565930496",
  "in_reply_to_user_id" : 72573,
  "text" : "@lukeredpath you could post it to the google group! http:\/\/groups.google.com\/group\/gemcutter or nick@quaran.to works",
  "id" : 75669079565930496,
  "in_reply_to_status_id" : 75668523728388096,
  "created_at" : "2011-05-31 21:04:49 +0000",
  "in_reply_to_screen_name" : "lukeredpath",
  "in_reply_to_user_id_str" : "72573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75663536457650177",
  "text" : "Rails 3: Debugging with `rescue Exception` in controllers since 2010\u2122",
  "id" : 75663536457650177,
  "created_at" : "2011-05-31 20:42:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75660114530545664",
  "geo" : { },
  "id_str" : "75660315311882240",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic http:\/\/28.media.tumblr.com\/tumblr_ll9ca9TmzO1qazdhko1_500.jpg",
  "id" : 75660315311882240,
  "in_reply_to_status_id" : 75660114530545664,
  "created_at" : "2011-05-31 20:29:59 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Remer",
      "screen_name" : "jeffremer",
      "indices" : [ 0, 10 ],
      "id_str" : "14295001",
      "id" : 14295001
    }, {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 36, 45 ],
      "id_str" : "21431343",
      "id" : 21431343
    }, {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 81, 88 ],
      "id_str" : "3928731",
      "id" : 3928731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75647762053595137",
  "geo" : { },
  "id_str" : "75658809716117504",
  "in_reply_to_user_id" : 14295001,
  "text" : "@jeffremer it was based off the old @bostonrb site, but actually i like to blame @cssboy...and why not? :)",
  "id" : 75658809716117504,
  "in_reply_to_status_id" : 75647762053595137,
  "created_at" : "2011-05-31 20:24:00 +0000",
  "in_reply_to_screen_name" : "jeffremer",
  "in_reply_to_user_id_str" : "14295001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75658041516769281",
  "text" : "Current status: http:\/\/28.media.tumblr.com\/tumblr_ll9ca9TmzO1qazdhko1_500.jpg",
  "id" : 75658041516769281,
  "created_at" : "2011-05-31 20:20:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 0, 11 ],
      "id_str" : "9887102",
      "id" : 9887102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75644220035182592",
  "geo" : { },
  "id_str" : "75645200302747648",
  "in_reply_to_user_id" : 9887102,
  "text" : "@metaskills no, it's *anyone*'s next gem push. we should probably make it queue up a job to reindex anyway now that it's faster",
  "id" : 75645200302747648,
  "in_reply_to_status_id" : 75644220035182592,
  "created_at" : "2011-05-31 19:29:55 +0000",
  "in_reply_to_screen_name" : "metaskills",
  "in_reply_to_user_id_str" : "9887102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 0, 11 ],
      "id_str" : "9887102",
      "id" : 9887102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75635157129895936",
  "geo" : { },
  "id_str" : "75639012664152064",
  "in_reply_to_user_id" : 9887102,
  "text" : "@metaskills yanks get removed on the next gem push. does it work after `gem sources -c` ?",
  "id" : 75639012664152064,
  "in_reply_to_status_id" : 75635157129895936,
  "created_at" : "2011-05-31 19:05:20 +0000",
  "in_reply_to_screen_name" : "metaskills",
  "in_reply_to_user_id_str" : "9887102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 4, 11 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75616043732701184",
  "text" : "Hey @github you gave us a file finder, can we get a magic button for a project finder next?",
  "id" : 75616043732701184,
  "created_at" : "2011-05-31 17:34:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Whitmire",
      "screen_name" : "jwhitmire",
      "indices" : [ 0, 10 ],
      "id_str" : "23374570",
      "id" : 23374570
    }, {
      "name" : "Emma Lindsay",
      "screen_name" : "ejlindsay",
      "indices" : [ 11, 21 ],
      "id_str" : "90351184",
      "id" : 90351184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75593435305877504",
  "geo" : { },
  "id_str" : "75606771720388609",
  "in_reply_to_user_id" : 23374570,
  "text" : "@jwhitmire @ejlindsay thanks!!",
  "id" : 75606771720388609,
  "in_reply_to_status_id" : 75593435305877504,
  "created_at" : "2011-05-31 16:57:13 +0000",
  "in_reply_to_screen_name" : "jwhitmire",
  "in_reply_to_user_id_str" : "23374570",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adventure Access",
      "screen_name" : "adventureaccess",
      "indices" : [ 0, 16 ],
      "id_str" : "303570267",
      "id" : 303570267
    }, {
      "name" : "Evan Burchard",
      "screen_name" : "evanburchard",
      "indices" : [ 17, 30 ],
      "id_str" : "28855059",
      "id" : 28855059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75582900770308099",
  "geo" : { },
  "id_str" : "75593507913478144",
  "in_reply_to_user_id" : 303570267,
  "text" : "@adventureaccess @evanburchard wow, this is awesome. good luck!!",
  "id" : 75593507913478144,
  "in_reply_to_status_id" : 75582900770308099,
  "created_at" : "2011-05-31 16:04:31 +0000",
  "in_reply_to_screen_name" : "adventureaccess",
  "in_reply_to_user_id_str" : "303570267",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75590785487220736",
  "text" : "Current status: https:\/\/img.skitch.com\/20110531-gsexyia25j79ijtbsmp42gdc6.png",
  "id" : 75590785487220736,
  "created_at" : "2011-05-31 15:53:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75588368683122689",
  "geo" : { },
  "id_str" : "75588492268277760",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez maybe you're missing http:\/\/news.ycombinator.com\/item?id=2602727 !",
  "id" : 75588492268277760,
  "in_reply_to_status_id" : 75588368683122689,
  "created_at" : "2011-05-31 15:44:35 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerred",
      "screen_name" : "justicefries",
      "indices" : [ 0, 13 ],
      "id_str" : "188906158",
      "id" : 188906158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75585980693884928",
  "geo" : { },
  "id_str" : "75586526381219840",
  "in_reply_to_user_id" : 188906158,
  "text" : "@justicefries taking a break from confs for a few months (almost did one a month for 2011 so far!), sounds fun though!",
  "id" : 75586526381219840,
  "in_reply_to_status_id" : 75585980693884928,
  "created_at" : "2011-05-31 15:36:46 +0000",
  "in_reply_to_screen_name" : "justicefries",
  "in_reply_to_user_id_str" : "188906158",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "indices" : [ 24, 34 ],
      "id_str" : "220097555",
      "id" : 220097555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75585463716548608",
  "text" : "ZOMG Happy Shipsday for @radishapp, a Redis monitoring service! Upvotes please! http:\/\/news.ycombinator.com\/item?id=2602727",
  "id" : 75585463716548608,
  "created_at" : "2011-05-31 15:32:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Forbes",
      "screen_name" : "caseyf",
      "indices" : [ 0, 7 ],
      "id_str" : "5772642",
      "id" : 5772642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75571018369998848",
  "geo" : { },
  "id_str" : "75580545156915200",
  "in_reply_to_user_id" : 5772642,
  "text" : "@caseyf good idea! definitely will consider it.",
  "id" : 75580545156915200,
  "in_reply_to_status_id" : 75571018369998848,
  "created_at" : "2011-05-31 15:13:00 +0000",
  "in_reply_to_screen_name" : "caseyf",
  "in_reply_to_user_id_str" : "5772642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Jim\u00E9nez",
      "screen_name" : "ernesto_jimenez",
      "indices" : [ 0, 16 ],
      "id_str" : "724263",
      "id" : 724263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75571768697425920",
  "geo" : { },
  "id_str" : "75580473455280128",
  "in_reply_to_user_id" : 724263,
  "text" : "@ernesto_jimenez fixed, thanks!",
  "id" : 75580473455280128,
  "in_reply_to_status_id" : 75571768697425920,
  "created_at" : "2011-05-31 15:12:43 +0000",
  "in_reply_to_screen_name" : "ernesto_jimenez",
  "in_reply_to_user_id_str" : "724263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerred",
      "screen_name" : "justicefries",
      "indices" : [ 0, 13 ],
      "id_str" : "188906158",
      "id" : 188906158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75573249513226240",
  "geo" : { },
  "id_str" : "75573982455267328",
  "in_reply_to_user_id" : 188906158,
  "text" : "@justicefries good idea! start a suggestion at http:\/\/support.radishapp.com\/ and let's see who piles on!",
  "id" : 75573982455267328,
  "in_reply_to_status_id" : 75573249513226240,
  "created_at" : "2011-05-31 14:46:56 +0000",
  "in_reply_to_screen_name" : "justicefries",
  "in_reply_to_user_id_str" : "188906158",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75568249663782912",
  "text" : "RT @thoughtbot: We just launched Radish, a new monitoring and analysis tool for Redis: http:\/\/bit.ly\/igEiZ2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75566815517999104",
    "text" : "We just launched Radish, a new monitoring and analysis tool for Redis: http:\/\/bit.ly\/igEiZ2",
    "id" : 75566815517999104,
    "created_at" : "2011-05-31 14:18:27 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 75568249663782912,
  "created_at" : "2011-05-31 14:24:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75533745964326913",
  "text" : "The bells at Downtown Crossing playing The Sound of Silence is really, really creepy.",
  "id" : 75533745964326913,
  "created_at" : "2011-05-31 12:07:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75505996730077184",
  "geo" : { },
  "id_str" : "75508622494408704",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage +1! Compared it em-redis it's wonderful, especially the implementation and use of deferrables",
  "id" : 75508622494408704,
  "in_reply_to_status_id" : 75505996730077184,
  "created_at" : "2011-05-31 10:27:13 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75363694074273793",
  "text" : "Proposing an extension to OH tweets: GOH and WOH. Figure it out. I guess BOH and HOH works too.",
  "id" : 75363694074273793,
  "created_at" : "2011-05-31 00:51:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 0, 9 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 10, 16 ],
      "id_str" : "15359408",
      "id" : 15359408
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 17, 24 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74983026894970880",
  "geo" : { },
  "id_str" : "75304097846272000",
  "in_reply_to_user_id" : 5674672,
  "text" : "@indirect @raggi @hone02 but! we should do both! more performance, the better.",
  "id" : 75304097846272000,
  "in_reply_to_status_id" : 74983026894970880,
  "created_at" : "2011-05-30 20:54:30 +0000",
  "in_reply_to_screen_name" : "indirect",
  "in_reply_to_user_id_str" : "5674672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 0, 6 ],
      "id_str" : "15359408",
      "id" : 15359408
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 7, 16 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 17, 24 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74982406058295297",
  "geo" : { },
  "id_str" : "75303956343046145",
  "in_reply_to_user_id" : 15359408,
  "text" : "@raggi @indirect @hone02 the perf boost with squashing the index is great, but doesn't fix the *root* problem, which is that the index sucks",
  "id" : 75303956343046145,
  "in_reply_to_status_id" : 74982406058295297,
  "created_at" : "2011-05-30 20:53:56 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 0, 8 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75291875979968512",
  "geo" : { },
  "id_str" : "75295124212547584",
  "in_reply_to_user_id" : 5502392,
  "text" : "@mojombo yay wget! Woot!",
  "id" : 75295124212547584,
  "in_reply_to_status_id" : 75291875979968512,
  "created_at" : "2011-05-30 20:18:51 +0000",
  "in_reply_to_screen_name" : "mojombo",
  "in_reply_to_user_id_str" : "5502392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75040226287947778",
  "geo" : { },
  "id_str" : "75041919411044352",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats pretty 99% of MSPL crap up on codeplex (except for nuget!)",
  "id" : 75041919411044352,
  "in_reply_to_status_id" : 75040226287947778,
  "created_at" : "2011-05-30 03:32:42 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75010739307425794",
  "text" : "Current status: http:\/\/yfrog.com\/h2ge6qvj",
  "id" : 75010739307425794,
  "created_at" : "2011-05-30 01:28:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 0, 7 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74894772610940928",
  "geo" : { },
  "id_str" : "74958260364525569",
  "in_reply_to_user_id" : 15317640,
  "text" : "@hone02 I think you're correct...why would you need to request dev deps?",
  "id" : 74958260364525569,
  "in_reply_to_status_id" : 74894772610940928,
  "created_at" : "2011-05-29 22:00:16 +0000",
  "in_reply_to_screen_name" : "hone02",
  "in_reply_to_user_id_str" : "15317640",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74892328573222912",
  "text" : "Current status: http:\/\/www.youtube.com\/watch?feature=youtube_gdata_player&v=FPxY8lpYAUM",
  "id" : 74892328573222912,
  "created_at" : "2011-05-29 17:38:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james_herdman",
      "screen_name" : "james_herdman",
      "indices" : [ 0, 14 ],
      "id_str" : "10713002",
      "id" : 10713002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74540166584352768",
  "geo" : { },
  "id_str" : "74835544311468032",
  "in_reply_to_user_id" : 10713002,
  "text" : "@james_herdman the new site is guides.rubygems.org. I need to get redirects in for the old docs site.",
  "id" : 74835544311468032,
  "in_reply_to_status_id" : 74540166584352768,
  "created_at" : "2011-05-29 13:52:38 +0000",
  "in_reply_to_screen_name" : "james_herdman",
  "in_reply_to_user_id_str" : "10713002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74825557937885184",
  "text" : "Troll Sagan: http:\/\/i.imgur.com\/Xl0jl.jpg",
  "id" : 74825557937885184,
  "created_at" : "2011-05-29 13:12:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74659141267886080",
  "geo" : { },
  "id_str" : "74672992755519488",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 do it!!",
  "id" : 74672992755519488,
  "in_reply_to_status_id" : 74659141267886080,
  "created_at" : "2011-05-29 03:06:43 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74644645010874368",
  "text" : "More of this, please. We need it! http:\/\/rhnh.net\/2011\/05\/28\/speeding-up-rails-startup-time",
  "id" : 74644645010874368,
  "created_at" : "2011-05-29 01:14:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vladimir Andrijevik",
      "screen_name" : "vandrijevik",
      "indices" : [ 0, 12 ],
      "id_str" : "14407694",
      "id" : 14407694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74629614986731520",
  "geo" : { },
  "id_str" : "74631895467565056",
  "in_reply_to_user_id" : 14407694,
  "text" : "@vandrijevik furries? lololol",
  "id" : 74631895467565056,
  "in_reply_to_status_id" : 74629614986731520,
  "created_at" : "2011-05-29 00:23:25 +0000",
  "in_reply_to_screen_name" : "vandrijevik",
  "in_reply_to_user_id_str" : "14407694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anand",
      "screen_name" : "luckydev",
      "indices" : [ 0, 9 ],
      "id_str" : "39436270",
      "id" : 39436270
    }, {
      "name" : "Lakshman Hari",
      "screen_name" : "lakshman",
      "indices" : [ 10, 19 ],
      "id_str" : "9161132",
      "id" : 9161132
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 74, 84 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74283420548743168",
  "geo" : { },
  "id_str" : "74285791668482048",
  "in_reply_to_user_id" : 39436270,
  "text" : "@luckydev @lakshman yep, was a user request on github! The whole point of @gemcutter is that we can improve it as the community grows :)",
  "id" : 74285791668482048,
  "in_reply_to_status_id" : 74283420548743168,
  "created_at" : "2011-05-28 01:28:07 +0000",
  "in_reply_to_screen_name" : "luckydev",
  "in_reply_to_user_id_str" : "39436270",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 0, 10 ],
      "id_str" : "9980812",
      "id" : 9980812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74266149453447168",
  "geo" : { },
  "id_str" : "74283474177110016",
  "in_reply_to_user_id" : 9980812,
  "text" : "@igrigorik oh, perfect. Webmock can definitely hook into that easier than monkeypatching\/aliasing...could you release a beta4 gem?",
  "id" : 74283474177110016,
  "in_reply_to_status_id" : 74266149453447168,
  "created_at" : "2011-05-28 01:18:55 +0000",
  "in_reply_to_screen_name" : "igrigorik",
  "in_reply_to_user_id_str" : "9980812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 0, 10 ],
      "id_str" : "9980812",
      "id" : 9980812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74266149453447168",
  "geo" : { },
  "id_str" : "74282394533904384",
  "in_reply_to_user_id" : 9980812,
  "text" : "@igrigorik nope, not yet. Also haven't touched it in a few hours. Will look at your commits, but those aren't webmock commits? O_o",
  "id" : 74282394533904384,
  "in_reply_to_status_id" : 74266149453447168,
  "created_at" : "2011-05-28 01:14:37 +0000",
  "in_reply_to_screen_name" : "igrigorik",
  "in_reply_to_user_id_str" : "9980812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ohio",
      "indices" : [ 84, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74256589607014400",
  "text" : "Confed flag #2 and 3 spotted, this time a real flag inside of a car and a flag hat! #ohio",
  "id" : 74256589607014400,
  "created_at" : "2011-05-27 23:32:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photo",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1131102333, -80.6513328 ]
  },
  "id_str" : "74224470679760896",
  "in_reply_to_user_id" : 5744442,
  "text" : "@ablissfulgal's sister's HS graduation! @ Stambaugh Auditorium http:\/\/gowal.la\/p\/eS4w #photo",
  "id" : 74224470679760896,
  "created_at" : "2011-05-27 21:24:27 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ohio",
      "indices" : [ 65, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74211520103448576",
  "text" : "Yep, first truck with a confederate flag window sticker spotted. #ohio",
  "id" : 74211520103448576,
  "created_at" : "2011-05-27 20:32:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74189797752709120",
  "geo" : { },
  "id_str" : "74192827214602240",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety ECONOSMACKDOWN",
  "id" : 74192827214602240,
  "in_reply_to_status_id" : 74189797752709120,
  "created_at" : "2011-05-27 19:18:43 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 113, 123 ],
      "id_str" : "9980812",
      "id" : 9980812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74187330453385216",
  "text" : "Been banging my brain over making webmock work with em-http-request's 1.0 beta. Almost there, but aggggghhh! \/cc @igrigorik",
  "id" : 74187330453385216,
  "created_at" : "2011-05-27 18:56:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74129354354982912",
  "text" : "Hi Pittsburghhhhhhhhhh!",
  "id" : 74129354354982912,
  "created_at" : "2011-05-27 15:06:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Spectre",
      "screen_name" : "dN0t",
      "indices" : [ 3, 8 ],
      "id_str" : "10947242",
      "id" : 10947242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74129299216678912",
  "text" : "RT @dN0t: Best tumblog I've seen in a long while - http:\/\/bit.ly\/lI7ODZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74127103498526720",
    "text" : "Best tumblog I've seen in a long while - http:\/\/bit.ly\/lI7ODZ",
    "id" : 74127103498526720,
    "created_at" : "2011-05-27 14:57:33 +0000",
    "user" : {
      "name" : "Rob Spectre",
      "screen_name" : "dN0t",
      "protected" : false,
      "id_str" : "10947242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000498983952\/78760ee25c66e5e7c517a5b4af1afbe0_normal.jpeg",
      "id" : 10947242,
      "verified" : false
    }
  },
  "id" : 74129299216678912,
  "created_at" : "2011-05-27 15:06:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74057674584629248",
  "text" : "Current status: http:\/\/www.youtube.com\/watch?v=MK6TXMsvgQg",
  "id" : 74057674584629248,
  "created_at" : "2011-05-27 10:21:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whyamiawake",
      "indices" : [ 25, 37 ]
    }, {
      "text" : "ahhhhh",
      "indices" : [ 38, 45 ]
    }, {
      "text" : "rapture",
      "indices" : [ 46, 54 ]
    }, {
      "text" : "bananas",
      "indices" : [ 55, 63 ]
    }, {
      "text" : "sleep",
      "indices" : [ 64, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74049582161608704",
  "text" : "There's a 5 on my clock. #whyamiawake #ahhhhh #rapture #bananas #sleep",
  "id" : 74049582161608704,
  "created_at" : "2011-05-27 09:49:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "indices" : [ 0, 8 ],
      "id_str" : "713263",
      "id" : 713263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73960692222406656",
  "geo" : { },
  "id_str" : "73961085232877568",
  "in_reply_to_user_id" : 713263,
  "text" : "@defunkt I AM SHOCKED AND HURT",
  "id" : 73961085232877568,
  "in_reply_to_status_id" : 73960692222406656,
  "created_at" : "2011-05-27 03:57:51 +0000",
  "in_reply_to_screen_name" : "defunkt",
  "in_reply_to_user_id_str" : "713263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73960218375098368",
  "text" : "Oh thank god, gem update --system will be re-enabled in Debian: http:\/\/blade.nagaokaut.ac.jp\/cgi-bin\/scat.rb\/ruby\/ruby-core\/36440",
  "id" : 73960218375098368,
  "created_at" : "2011-05-27 03:54:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73919941652393984",
  "text" : "Current status: http:\/\/25.media.tumblr.com\/tumblr_llttiuNx591qzlfumo1_500.jpg",
  "id" : 73919941652393984,
  "created_at" : "2011-05-27 01:14:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby on Rails",
      "screen_name" : "rails",
      "indices" : [ 0, 6 ],
      "id_str" : "3116191",
      "id" : 3116191
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 7, 18 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73558411018637312",
  "geo" : { },
  "id_str" : "73901842152697856",
  "in_reply_to_user_id" : 3116191,
  "text" : "@rails @tenderlove boog is starting to replace bug in my brain. this is entirely your fault",
  "id" : 73901842152697856,
  "in_reply_to_status_id" : 73558411018637312,
  "created_at" : "2011-05-27 00:02:26 +0000",
  "in_reply_to_screen_name" : "rails",
  "in_reply_to_user_id_str" : "3116191",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 12, 19 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73884099793797120",
  "geo" : { },
  "id_str" : "73891827270430720",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier @croaky damn!! when is that again!?!",
  "id" : 73891827270430720,
  "in_reply_to_status_id" : 73884099793797120,
  "created_at" : "2011-05-26 23:22:39 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73886756818268160",
  "text" : "I still can't believe you have to add shell variables to use Go. It's not even noted on http:\/\/golang.org\/doc\/install.html :(",
  "id" : 73886756818268160,
  "created_at" : "2011-05-26 23:02:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73871694175023105",
  "text" : "So many lessons out of that article. It's sad that instead of PEP proposals we just write angsty blog posts for Ruby.",
  "id" : 73871694175023105,
  "created_at" : "2011-05-26 22:02:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73871429518622720",
  "text" : "It's great to see that the state of Python packaging is equally as crazy as Ruby's. http:\/\/www.aosabook.org\/en\/packaging.html",
  "id" : 73871429518622720,
  "created_at" : "2011-05-26 22:01:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 5, 18 ],
      "id_str" : "5875112",
      "id" : 5875112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73863804206841857",
  "geo" : { },
  "id_str" : "73867033086922752",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh @stevenharman yep, we could build a new api for that, basically would yank everything and add a link to the new gem",
  "id" : 73867033086922752,
  "in_reply_to_status_id" : 73863804206841857,
  "created_at" : "2011-05-26 21:44:07 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73860649435934720",
  "geo" : { },
  "id_str" : "73866772457074689",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety SUGGESTION DULY NOTED THANK YOU",
  "id" : 73866772457074689,
  "in_reply_to_status_id" : 73860649435934720,
  "created_at" : "2011-05-26 21:43:05 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73856062792536064",
  "geo" : { },
  "id_str" : "73856655959396352",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier GREAT SUCCESS",
  "id" : 73856655959396352,
  "in_reply_to_status_id" : 73856062792536064,
  "created_at" : "2011-05-26 21:02:53 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Lindsay",
      "screen_name" : "ejlindsay",
      "indices" : [ 0, 10 ],
      "id_str" : "90351184",
      "id" : 90351184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73787587327823873",
  "geo" : { },
  "id_str" : "73853388051320832",
  "in_reply_to_user_id" : 90351184,
  "text" : "@ejlindsay I pretty much do the same! +1",
  "id" : 73853388051320832,
  "in_reply_to_status_id" : 73787587327823873,
  "created_at" : "2011-05-26 20:49:54 +0000",
  "in_reply_to_screen_name" : "ejlindsay",
  "in_reply_to_user_id_str" : "90351184",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 0, 13 ],
      "id_str" : "5875112",
      "id" : 5875112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73849914664292352",
  "geo" : { },
  "id_str" : "73850283750473728",
  "in_reply_to_user_id" : 5875112,
  "text" : "@stevenharman there is none, and we wouldn't do that. Gems are atomic and shouldn't be hard deleted, lost, or redirected ever imo",
  "id" : 73850283750473728,
  "in_reply_to_status_id" : 73849914664292352,
  "created_at" : "2011-05-26 20:37:34 +0000",
  "in_reply_to_screen_name" : "stevenharman",
  "in_reply_to_user_id_str" : "5875112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Campbell",
      "screen_name" : "paulca",
      "indices" : [ 0, 7 ],
      "id_str" : "815973",
      "id" : 815973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73844396029771776",
  "geo" : { },
  "id_str" : "73849241948266496",
  "in_reply_to_user_id" : 815973,
  "text" : "@paulca maybe http:\/\/vis.stanford.edu\/protovis\/ex\/stem-and-leaf.html ? hmmmm",
  "id" : 73849241948266496,
  "in_reply_to_status_id" : 73844396029771776,
  "created_at" : "2011-05-26 20:33:25 +0000",
  "in_reply_to_screen_name" : "paulca",
  "in_reply_to_user_id_str" : "815973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73847904221147136",
  "text" : "RT @dhh: I have updated pjax-rails to be pjax_rails according to the RubyGems naming convention: http:\/\/bit.ly\/iv1Rmo (please follow suit!)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73837935866281984",
    "text" : "I have updated pjax-rails to be pjax_rails according to the RubyGems naming convention: http:\/\/bit.ly\/iv1Rmo (please follow suit!)",
    "id" : 73837935866281984,
    "created_at" : "2011-05-26 19:48:30 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 73847904221147136,
  "created_at" : "2011-05-26 20:28:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Campbell",
      "screen_name" : "paulca",
      "indices" : [ 0, 7 ],
      "id_str" : "815973",
      "id" : 815973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73844396029771776",
  "geo" : { },
  "id_str" : "73847455476756480",
  "in_reply_to_user_id" : 815973,
  "text" : "@paulca ah, interesting. we should have more of a timeline\/semver view down there instead, all protovis'd up!",
  "id" : 73847455476756480,
  "in_reply_to_status_id" : 73844396029771776,
  "created_at" : "2011-05-26 20:26:20 +0000",
  "in_reply_to_screen_name" : "paulca",
  "in_reply_to_user_id_str" : "815973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73846134312943617",
  "text" : "Current status: http:\/\/27.media.tumblr.com\/tumblr_lixhnx1Giw1qdn2x4o1_400.jpg",
  "id" : 73846134312943617,
  "created_at" : "2011-05-26 20:21:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    }, {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 13, 23 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73825754332401664",
  "geo" : { },
  "id_str" : "73837438124048384",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick @joedamato what a hoser",
  "id" : 73837438124048384,
  "in_reply_to_status_id" : 73825754332401664,
  "created_at" : "2011-05-26 19:46:31 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73819550990348288",
  "text" : "Wow: http:\/\/www.aosabook.org\/en\/",
  "id" : 73819550990348288,
  "created_at" : "2011-05-26 18:35:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73819418496471040",
  "geo" : { },
  "id_str" : "73819516899045376",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad totally :(",
  "id" : 73819516899045376,
  "in_reply_to_status_id" : 73819418496471040,
  "created_at" : "2011-05-26 18:35:18 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73818736695574528",
  "text" : "Seriously though, I don't want to type any passwords, ever. I just want sites to figure their shit out.",
  "id" : 73818736695574528,
  "created_at" : "2011-05-26 18:32:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73818641354862592",
  "text" : "Current stupid image status: http:\/\/i.imgur.com\/SdokU.jpg",
  "id" : 73818641354862592,
  "created_at" : "2011-05-26 18:31:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73805362502971392",
  "geo" : { },
  "id_str" : "73814206939529217",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant SUPRISING",
  "id" : 73814206939529217,
  "in_reply_to_status_id" : 73805362502971392,
  "created_at" : "2011-05-26 18:14:12 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73806522072842240",
  "text" : "I also SO FUCKING SICK of typing a password everywhere 50 times a day. If you suggest 1password I will send you a stupid image.",
  "id" : 73806522072842240,
  "created_at" : "2011-05-26 17:43:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen Madsen",
      "screen_name" : "blatyo",
      "indices" : [ 0, 7 ],
      "id_str" : "14188909",
      "id" : 14188909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73710996547575808",
  "geo" : { },
  "id_str" : "73712675330326528",
  "in_reply_to_user_id" : 14188909,
  "text" : "@blatyo fixed. argh. thanks.",
  "id" : 73712675330326528,
  "in_reply_to_status_id" : 73710996547575808,
  "created_at" : "2011-05-26 11:30:45 +0000",
  "in_reply_to_screen_name" : "blatyo",
  "in_reply_to_user_id_str" : "14188909",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Griego",
      "screen_name" : "cgriego",
      "indices" : [ 0, 8 ],
      "id_str" : "33043",
      "id" : 33043
    }, {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 89, 96 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 97, 106 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73615427862937600",
  "geo" : { },
  "id_str" : "73709798604029952",
  "in_reply_to_user_id" : 33043,
  "text" : "@cgriego how so? Why does it need to be liberal? I usually do exact versions in mine \/cc @wycats @indirect",
  "id" : 73709798604029952,
  "in_reply_to_status_id" : 73615427862937600,
  "created_at" : "2011-05-26 11:19:20 +0000",
  "in_reply_to_screen_name" : "cgriego",
  "in_reply_to_user_id_str" : "33043",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Hanke",
      "screen_name" : "hanke",
      "indices" : [ 0, 6 ],
      "id_str" : "1018421",
      "id" : 1018421
    }, {
      "name" : "Jason Weathered",
      "screen_name" : "jasoncodes",
      "indices" : [ 7, 18 ],
      "id_str" : "9848542",
      "id" : 9848542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73632485434601473",
  "geo" : { },
  "id_str" : "73709485553758208",
  "in_reply_to_user_id" : 1018421,
  "text" : "@hanke @jasoncodes ah fuck. Will fix.",
  "id" : 73709485553758208,
  "in_reply_to_status_id" : 73632485434601473,
  "created_at" : "2011-05-26 11:18:05 +0000",
  "in_reply_to_screen_name" : "hanke",
  "in_reply_to_user_id_str" : "1018421",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 0, 11 ],
      "id_str" : "48431692",
      "id" : 48431692
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 17, 24 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73540417039245312",
  "geo" : { },
  "id_str" : "73597726708862976",
  "in_reply_to_user_id" : 48431692,
  "text" : "@laserlemon hey, @sferik was thinking of making one. not sure what happened with it",
  "id" : 73597726708862976,
  "in_reply_to_status_id" : 73540417039245312,
  "created_at" : "2011-05-26 03:54:00 +0000",
  "in_reply_to_screen_name" : "laserlemon",
  "in_reply_to_user_id_str" : "48431692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73595036863954944",
  "geo" : { },
  "id_str" : "73595919261642752",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv IS THIS AWESOME? \u2611",
  "id" : 73595919261642752,
  "in_reply_to_status_id" : 73595036863954944,
  "created_at" : "2011-05-26 03:46:49 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73595664210198528",
  "text" : "LOLICENSE http:\/\/download.oracle.com\/javase\/tutorial\/getStarted\/application\/examples\/HelloWorldApp.java",
  "id" : 73595664210198528,
  "created_at" : "2011-05-26 03:45:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    }, {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 4, 15 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73593954561572864",
  "geo" : { },
  "id_str" : "73594356979875840",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 @joshsusser i definitely think so. &gt;= is terrible, see very end of http:\/\/www.scribd.com\/doc\/55824468\/Cutting-your-own-RubyGems",
  "id" : 73594356979875840,
  "in_reply_to_status_id" : 73593954561572864,
  "created_at" : "2011-05-26 03:40:36 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aman Gupta",
      "screen_name" : "tmm1",
      "indices" : [ 0, 5 ],
      "id_str" : "15591045",
      "id" : 15591045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73592140403441664",
  "geo" : { },
  "id_str" : "73592700871520256",
  "in_reply_to_user_id" : 15591045,
  "text" : "@tmm1 haha way out, not coming back in tonight. gonna be around outside of Logan tomorrow?",
  "id" : 73592700871520256,
  "in_reply_to_status_id" : 73592140403441664,
  "created_at" : "2011-05-26 03:34:01 +0000",
  "in_reply_to_screen_name" : "tmm1",
  "in_reply_to_user_id_str" : "15591045",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 76, 87 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73592599063183360",
  "text" : "RT @gemcutter: Also added a Bundler section to rubygems#show, with kudos to @joshsusser. Any thoughts? http:\/\/rubygems.org\/gems\/factory_girl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Susser",
        "screen_name" : "joshsusser",
        "indices" : [ 61, 72 ],
        "id_str" : "35954885",
        "id" : 35954885
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73592499901435904",
    "text" : "Also added a Bundler section to rubygems#show, with kudos to @joshsusser. Any thoughts? http:\/\/rubygems.org\/gems\/factory_girl",
    "id" : 73592499901435904,
    "created_at" : "2011-05-26 03:33:13 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 73592599063183360,
  "created_at" : "2011-05-26 03:33:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Philip",
      "screen_name" : "parndt",
      "indices" : [ 52, 59 ],
      "id_str" : "15346781",
      "id" : 15346781
    }, {
      "name" : "Matt Pruitt",
      "screen_name" : "guitsaru",
      "indices" : [ 113, 122 ],
      "id_str" : "8110342",
      "id" : 8110342
    }, {
      "name" : "Shanon McQuay",
      "screen_name" : "compactcode",
      "indices" : [ 139, 140 ],
      "id_str" : "202022689",
      "id" : 202022689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73592586853548034",
  "text" : "RT @gemcutter: Deploy out, some fixes\/features from @parndt (hey, i can't list you on @gemcutter\/contributors!), @guitsaru, and @compact ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Philip",
        "screen_name" : "parndt",
        "indices" : [ 37, 44 ],
        "id_str" : "15346781",
        "id" : 15346781
      }, {
        "name" : "Matt Pruitt",
        "screen_name" : "guitsaru",
        "indices" : [ 98, 107 ],
        "id_str" : "8110342",
        "id" : 8110342
      }, {
        "name" : "Shanon McQuay",
        "screen_name" : "compactcode",
        "indices" : [ 113, 125 ],
        "id_str" : "202022689",
        "id" : 202022689
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73592269239881729",
    "text" : "Deploy out, some fixes\/features from @parndt (hey, i can't list you on @gemcutter\/contributors!), @guitsaru, and @compactcode ! Thanks!!",
    "id" : 73592269239881729,
    "created_at" : "2011-05-26 03:32:18 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 73592586853548034,
  "created_at" : "2011-05-26 03:33:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73561406225645568",
  "text" : "Kleenex explosion in washing machine = http:\/\/h.imagehost.org\/0086\/fffuuuu.jpg",
  "id" : 73561406225645568,
  "created_at" : "2011-05-26 01:29:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IRCCloud",
      "screen_name" : "IRCCloud",
      "indices" : [ 10, 19 ],
      "id_str" : "171845650",
      "id" : 171845650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73554942224371712",
  "text" : "Seriously @irccloud is everything I want for an IRC service. Uninstalling Colloquy right now. http:\/\/i.imgur.com\/8oymJ.jpg",
  "id" : 73554942224371712,
  "created_at" : "2011-05-26 01:03:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aman Gupta",
      "screen_name" : "tmm1",
      "indices" : [ 0, 5 ],
      "id_str" : "15591045",
      "id" : 15591045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73553049045565440",
  "geo" : { },
  "id_str" : "73553340893630465",
  "in_reply_to_user_id" : 15591045,
  "text" : "@tmm1 haha gonna be in town for long!?",
  "id" : 73553340893630465,
  "in_reply_to_status_id" : 73553049045565440,
  "created_at" : "2011-05-26 00:57:37 +0000",
  "in_reply_to_screen_name" : "tmm1",
  "in_reply_to_user_id_str" : "15591045",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fletcher Nichol",
      "screen_name" : "fnichol",
      "indices" : [ 0, 8 ],
      "id_str" : "139169934",
      "id" : 139169934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73482819430649857",
  "geo" : { },
  "id_str" : "73499202910556161",
  "in_reply_to_user_id" : 139169934,
  "text" : "@fnichol I immediately regret this decision!",
  "id" : 73499202910556161,
  "in_reply_to_status_id" : 73482819430649857,
  "created_at" : "2011-05-25 21:22:30 +0000",
  "in_reply_to_screen_name" : "fnichol",
  "in_reply_to_user_id_str" : "139169934",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73464570487898112",
  "geo" : { },
  "id_str" : "73465888090763264",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel whaaaaaaaaaat",
  "id" : 73465888090763264,
  "in_reply_to_status_id" : 73464570487898112,
  "created_at" : "2011-05-25 19:10:07 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 0, 11 ],
      "id_str" : "9887102",
      "id" : 9887102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73456773188681728",
  "geo" : { },
  "id_str" : "73464967243902976",
  "in_reply_to_user_id" : 9887102,
  "text" : "@metaskills it should be removed on the next gem push, which should have happened by now...",
  "id" : 73464967243902976,
  "in_reply_to_status_id" : 73456773188681728,
  "created_at" : "2011-05-25 19:06:27 +0000",
  "in_reply_to_screen_name" : "metaskills",
  "in_reply_to_user_id_str" : "9887102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73400500292292608",
  "text" : "Classy move, Snape. http:\/\/i.imgur.com\/kDHL7.jpg",
  "id" : 73400500292292608,
  "created_at" : "2011-05-25 14:50:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 0, 9 ],
      "id_str" : "616163",
      "id" : 616163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73197708931891200",
  "geo" : { },
  "id_str" : "73198351851601920",
  "in_reply_to_user_id" : 616163,
  "text" : "@joshpeek ...YARD?",
  "id" : 73198351851601920,
  "in_reply_to_status_id" : 73197708931891200,
  "created_at" : "2011-05-25 01:27:01 +0000",
  "in_reply_to_screen_name" : "joshpeek",
  "in_reply_to_user_id_str" : "616163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73077936445603840",
  "geo" : { },
  "id_str" : "73078446623956992",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant only $100 off craigslist too. maybe thats why.",
  "id" : 73078446623956992,
  "in_reply_to_status_id" : 73077936445603840,
  "created_at" : "2011-05-24 17:30:34 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73078241778335744",
  "geo" : { },
  "id_str" : "73078349857169408",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant nice dude!",
  "id" : 73078349857169408,
  "in_reply_to_status_id" : 73078241778335744,
  "created_at" : "2011-05-24 17:30:10 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdir -- -rf",
      "screen_name" : "baroquebobcat",
      "indices" : [ 0, 14 ],
      "id_str" : "14247442",
      "id" : 14247442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73046489248710656",
  "geo" : { },
  "id_str" : "73048872557101057",
  "in_reply_to_user_id" : 14247442,
  "text" : "@baroquebobcat nope, you crazy",
  "id" : 73048872557101057,
  "in_reply_to_status_id" : 73046489248710656,
  "created_at" : "2011-05-24 15:33:03 +0000",
  "in_reply_to_screen_name" : "baroquebobcat",
  "in_reply_to_user_id_str" : "14247442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "coderwall",
      "screen_name" : "coderwall",
      "indices" : [ 25, 35 ],
      "id_str" : "296019552",
      "id" : 296019552
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 39, 46 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 47, 55 ],
      "id_str" : "5502392",
      "id" : 5502392
    }, {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "indices" : [ 56, 64 ],
      "id_str" : "713263",
      "id" : 713263
    }, {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 65, 78 ],
      "id_str" : "780561",
      "id" : 780561
    }, {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 79, 85 ],
      "id_str" : "1438261",
      "id" : 1438261
    }, {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 86, 95 ],
      "id_str" : "9267332",
      "id" : 9267332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73023764593516544",
  "text" : "Current wait: 5 days for @coderwall !? @github @mojombo @defunkt @technoweenie @atmos @rtomayko those API limits stink :(",
  "id" : 73023764593516544,
  "created_at" : "2011-05-24 13:53:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72727406212947968",
  "geo" : { },
  "id_str" : "72729266713935872",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi bad link, asks for sign in?",
  "id" : 72729266713935872,
  "in_reply_to_status_id" : 72727406212947968,
  "created_at" : "2011-05-23 18:23:03 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72712593382440960",
  "geo" : { },
  "id_str" : "72714818074836992",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin NERDTree is great, rails.vim too",
  "id" : 72714818074836992,
  "in_reply_to_status_id" : 72712593382440960,
  "created_at" : "2011-05-23 17:25:38 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "leonid shafran",
      "screen_name" : "kombainer",
      "indices" : [ 0, 10 ],
      "id_str" : "2800843728",
      "id" : 2800843728
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 16, 30 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72709150999724032",
  "text" : "@kombainer hey, @joshuaclayton might be working on it if you want to help. The guides site is a work in progress!",
  "id" : 72709150999724032,
  "created_at" : "2011-05-23 17:03:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/nnHMtwV",
      "expanded_url" : "http:\/\/workshops.thoughtbot.com\/",
      "display_url" : "workshops.thoughtbot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "72704622803959808",
  "text" : "RT @thoughtbot: Get smarter in June: Rails Antipatterns (Boston & SF), Design for Developers, & Intro to iOS Development. http:\/\/t.co\/nn ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 125 ],
        "url" : "http:\/\/t.co\/nnHMtwV",
        "expanded_url" : "http:\/\/workshops.thoughtbot.com\/",
        "display_url" : "workshops.thoughtbot.com"
      } ]
    },
    "geo" : { },
    "id_str" : "72703820462948352",
    "text" : "Get smarter in June: Rails Antipatterns (Boston & SF), Design for Developers, & Intro to iOS Development. http:\/\/t.co\/nnHMtwV",
    "id" : 72703820462948352,
    "created_at" : "2011-05-23 16:41:56 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 72704622803959808,
  "created_at" : "2011-05-23 16:45:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72681246433615872",
  "text" : "Honored to see my talk up on http:\/\/bestofrailsconf2011.heroku.com\/ ...thanks to anyone who voted! #railsconf",
  "id" : 72681246433615872,
  "created_at" : "2011-05-23 15:12:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 18, 27 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photo",
      "indices" : [ 69, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3356436861, -71.1705064774 ]
  },
  "id_str" : "72645363353387008",
  "text" : "BC graduation for @bquarant! @ Boston College http:\/\/gowal.la\/p\/eK7N #photo",
  "id" : 72645363353387008,
  "created_at" : "2011-05-23 12:49:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72413553457500160",
  "geo" : { },
  "id_str" : "72416889082626048",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel I'm actively trying to resolve this nonsense. Please don't lose faith, some of us do sincerely care.",
  "id" : 72416889082626048,
  "in_reply_to_status_id" : 72413553457500160,
  "created_at" : "2011-05-22 21:41:46 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72411243138392064",
  "geo" : { },
  "id_str" : "72412423138713600",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl is that a new groupon for the no gay touching + crabmeat special?",
  "id" : 72412423138713600,
  "in_reply_to_status_id" : 72411243138392064,
  "created_at" : "2011-05-22 21:24:01 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72403485093666816",
  "geo" : { },
  "id_str" : "72408933997887488",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson except if you're right all the time, those stupid users",
  "id" : 72408933997887488,
  "in_reply_to_status_id" : 72403485093666816,
  "created_at" : "2011-05-22 21:10:09 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 16, 26 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72406308543930368",
  "geo" : { },
  "id_str" : "72408616627478528",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu if I may, @gemcutter? ;)",
  "id" : 72408616627478528,
  "in_reply_to_status_id" : 72406308543930368,
  "created_at" : "2011-05-22 21:08:54 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Kreeftmeijer",
      "screen_name" : "jkreeftmeijer",
      "indices" : [ 0, 14 ],
      "id_str" : "8284992",
      "id" : 8284992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72371879087841280",
  "geo" : { },
  "id_str" : "72373124288622592",
  "in_reply_to_user_id" : 8284992,
  "text" : "@jkreeftmeijer gem yank every version and someone else can push onto it",
  "id" : 72373124288622592,
  "in_reply_to_status_id" : 72371879087841280,
  "created_at" : "2011-05-22 18:47:52 +0000",
  "in_reply_to_screen_name" : "jkreeftmeijer",
  "in_reply_to_user_id_str" : "8284992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Cooke",
      "screen_name" : "jc00ke",
      "indices" : [ 0, 7 ],
      "id_str" : "14425908",
      "id" : 14425908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72117575982657536",
  "geo" : { },
  "id_str" : "72168800476332032",
  "in_reply_to_user_id" : 14425908,
  "text" : "@jc00ke Slides? Wha? Did I kill someone?",
  "id" : 72168800476332032,
  "in_reply_to_status_id" : 72117575982657536,
  "created_at" : "2011-05-22 05:15:57 +0000",
  "in_reply_to_screen_name" : "jc00ke",
  "in_reply_to_user_id_str" : "14425908",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72168737872162816",
  "text" : "Oh please, let this work: https:\/\/github.com\/adambeynon\/opal",
  "id" : 72168737872162816,
  "created_at" : "2011-05-22 05:15:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71950065987629057",
  "text" : "Current status: http:\/\/25.media.tumblr.com\/tumblr_llj6dwdT8X1qc0v2vo1_400.gif",
  "id" : 71950065987629057,
  "created_at" : "2011-05-21 14:46:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby News",
      "screen_name" : "ruby_news",
      "indices" : [ 3, 13 ],
      "id_str" : "16903992",
      "id" : 16903992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71948582265167872",
  "text" : "RT @ruby_news: This rapture thing is getting out of hand... http:\/\/bit.ly\/iVfRlR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71794814642954241",
    "text" : "This rapture thing is getting out of hand... http:\/\/bit.ly\/iVfRlR",
    "id" : 71794814642954241,
    "created_at" : "2011-05-21 04:29:52 +0000",
    "user" : {
      "name" : "Ruby News",
      "screen_name" : "ruby_news",
      "protected" : false,
      "id_str" : "16903992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224369862\/Ruby-News-Logo_normal.png",
      "id" : 16903992,
      "verified" : false
    }
  },
  "id" : 71948582265167872,
  "created_at" : "2011-05-21 14:40:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71903984071352320",
  "geo" : { },
  "id_str" : "71905434830782464",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez where are you coming in to? I'd let you use my netflix! :P",
  "id" : 71905434830782464,
  "in_reply_to_status_id" : 71903984071352320,
  "created_at" : "2011-05-21 11:49:26 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71777265704386560",
  "text" : "Someone should rename YSlow to Y U SLOW?",
  "id" : 71777265704386560,
  "created_at" : "2011-05-21 03:20:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominik Honnef",
      "screen_name" : "dominikhonnef",
      "indices" : [ 0, 14 ],
      "id_str" : "81519160",
      "id" : 81519160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71335582021853184",
  "geo" : { },
  "id_str" : "71723004480077824",
  "in_reply_to_user_id" : 81519160,
  "text" : "@dominikhonnef ah yes, we should add in a sentence re: 1.9.2. the guides are a work in progress :)",
  "id" : 71723004480077824,
  "in_reply_to_status_id" : 71335582021853184,
  "created_at" : "2011-05-20 23:44:31 +0000",
  "in_reply_to_screen_name" : "dominikhonnef",
  "in_reply_to_user_id_str" : "81519160",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELLIOTTCABLE",
      "screen_name" : "ELLIOTTCABLE",
      "indices" : [ 0, 13 ],
      "id_str" : "771681",
      "id" : 771681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71617434855018496",
  "geo" : { },
  "id_str" : "71619937629777920",
  "in_reply_to_user_id" : 771681,
  "text" : "@elliottcable insert informed car opinion here",
  "id" : 71619937629777920,
  "in_reply_to_status_id" : 71617434855018496,
  "created_at" : "2011-05-20 16:54:58 +0000",
  "in_reply_to_screen_name" : "ELLIOTTCABLE",
  "in_reply_to_user_id_str" : "771681",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/UN7gf9u",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/5668152476\/taming-a-supercar",
      "display_url" : "robots.thoughtbot.com\/post\/566815247\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "71617035674714112",
  "text" : "RT @thoughtbot: A designer discovers vim, calls it a Lamborghini \"supercar\" (Textmate\/Code are like VW Jettas) http:\/\/t.co\/UN7gf9u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 114 ],
        "url" : "http:\/\/t.co\/UN7gf9u",
        "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/5668152476\/taming-a-supercar",
        "display_url" : "robots.thoughtbot.com\/post\/566815247\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "71613568008732672",
    "text" : "A designer discovers vim, calls it a Lamborghini \"supercar\" (Textmate\/Code are like VW Jettas) http:\/\/t.co\/UN7gf9u",
    "id" : 71613568008732672,
    "created_at" : "2011-05-20 16:29:39 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 71617035674714112,
  "created_at" : "2011-05-20 16:43:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 26, 37 ],
      "id_str" : "790205",
      "id" : 790205
    }, {
      "name" : "Ben Scofield",
      "screen_name" : "bscofield",
      "indices" : [ 39, 49 ],
      "id_str" : "7921582",
      "id" : 7921582
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71616711589244929",
  "text" : "Back in Boston! Thanks to @chadfowler, @bscofield, and everyone else who made #railsconf awesome.",
  "id" : 71616711589244929,
  "created_at" : "2011-05-20 16:42:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71570441235480577",
  "geo" : { },
  "id_str" : "71573294297522178",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin fuckin smart.",
  "id" : 71573294297522178,
  "in_reply_to_status_id" : 71570441235480577,
  "created_at" : "2011-05-20 13:49:37 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    }, {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 7, 20 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71434409798148098",
  "geo" : { },
  "id_str" : "71443772617134080",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic @ryandotsmith mega sadface",
  "id" : 71443772617134080,
  "in_reply_to_status_id" : 71434409798148098,
  "created_at" : "2011-05-20 05:14:57 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71400005595963392",
  "geo" : { },
  "id_str" : "71401835839225856",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape oh I can't wait to fork it and add short circuit and\/or. LOL NO FUCKING WAY",
  "id" : 71401835839225856,
  "in_reply_to_status_id" : 71400005595963392,
  "created_at" : "2011-05-20 02:28:18 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "legally a wizard",
      "screen_name" : "dennyabraham",
      "indices" : [ 0, 13 ],
      "id_str" : "16036099",
      "id" : 16036099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71396503347933184",
  "geo" : { },
  "id_str" : "71396756818108417",
  "in_reply_to_user_id" : 16036099,
  "text" : "@dennyabraham this makes my night",
  "id" : 71396756818108417,
  "in_reply_to_status_id" : 71396503347933184,
  "created_at" : "2011-05-20 02:08:07 +0000",
  "in_reply_to_screen_name" : "dennyabraham",
  "in_reply_to_user_id_str" : "16036099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71343717994336256",
  "geo" : { },
  "id_str" : "71346645085859840",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv fuckin smart",
  "id" : 71346645085859840,
  "in_reply_to_status_id" : 71343717994336256,
  "created_at" : "2011-05-19 22:49:00 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71308636755984384",
  "geo" : { },
  "id_str" : "71308920039288832",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan start another guide instead! :)",
  "id" : 71308920039288832,
  "in_reply_to_status_id" : 71308636755984384,
  "created_at" : "2011-05-19 20:19:06 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 0, 11 ],
      "id_str" : "2355631",
      "id" : 2355631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71269888097923072",
  "geo" : { },
  "id_str" : "71303363534389248",
  "in_reply_to_user_id" : 2355631,
  "text" : "@lmarburger @ra66i a pile of monkeypatches to hack the async out of async libraries is not acceptable IMO. We can do better!",
  "id" : 71303363534389248,
  "in_reply_to_status_id" : 71269888097923072,
  "created_at" : "2011-05-19 19:57:01 +0000",
  "in_reply_to_screen_name" : "lmarburger",
  "in_reply_to_user_id_str" : "2355631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 0, 9 ],
      "id_str" : "616163",
      "id" : 616163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71302241121873921",
  "in_reply_to_user_id" : 616163,
  "text" : "@joshpeek hey, I borrowed a lot of content from your rails blog post for the patterns section. I noted that on the guides site. Thanks dude.",
  "id" : 71302241121873921,
  "created_at" : "2011-05-19 19:52:33 +0000",
  "in_reply_to_screen_name" : "joshpeek",
  "in_reply_to_user_id_str" : "616163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keif",
      "screen_name" : "gnoshme",
      "indices" : [ 0, 8 ],
      "id_str" : "12471462",
      "id" : 12471462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71284126451380224",
  "geo" : { },
  "id_str" : "71292976135016448",
  "in_reply_to_user_id" : 12471462,
  "text" : "@gnoshme it worked! :D thanks!!",
  "id" : 71292976135016448,
  "in_reply_to_status_id" : 71284126451380224,
  "created_at" : "2011-05-19 19:15:44 +0000",
  "in_reply_to_screen_name" : "gnoshme",
  "in_reply_to_user_id_str" : "12471462",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elvi Braun",
      "screen_name" : "elvi_braun",
      "indices" : [ 0, 11 ],
      "id_str" : "15860805",
      "id" : 15860805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71284542501175296",
  "geo" : { },
  "id_str" : "71292925874683904",
  "in_reply_to_user_id" : 15860805,
  "text" : "@elvi_braun thanks! I'm glad it helped!!",
  "id" : 71292925874683904,
  "in_reply_to_status_id" : 71284542501175296,
  "created_at" : "2011-05-19 19:15:32 +0000",
  "in_reply_to_screen_name" : "elvi_braun",
  "in_reply_to_user_id_str" : "15860805",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alpha Ori",
      "screen_name" : "alpha_ori",
      "indices" : [ 0, 10 ],
      "id_str" : "519394555",
      "id" : 519394555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71284900686336000",
  "geo" : { },
  "id_str" : "71292855322288129",
  "in_reply_to_user_id" : 1020191,
  "text" : "@alpha_ori woot! go make one!",
  "id" : 71292855322288129,
  "in_reply_to_status_id" : 71284900686336000,
  "created_at" : "2011-05-19 19:15:15 +0000",
  "in_reply_to_screen_name" : "orion_auld",
  "in_reply_to_user_id_str" : "1020191",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Collen",
      "screen_name" : "tcollen",
      "indices" : [ 0, 8 ],
      "id_str" : "15201409",
      "id" : 15201409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71290230262611968",
  "geo" : { },
  "id_str" : "71292824464789504",
  "in_reply_to_user_id" : 15201409,
  "text" : "@tcollen thanks!",
  "id" : 71292824464789504,
  "in_reply_to_status_id" : 71290230262611968,
  "created_at" : "2011-05-19 19:15:08 +0000",
  "in_reply_to_screen_name" : "tcollen",
  "in_reply_to_user_id_str" : "15201409",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raymond T. Hightower",
      "screen_name" : "RayHightower",
      "indices" : [ 0, 13 ],
      "id_str" : "17503660",
      "id" : 17503660
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 18, 29 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Erik Hedenstr\u00F6m",
      "screen_name" : "ErikH",
      "indices" : [ 49, 55 ],
      "id_str" : "766894",
      "id" : 766894
    }, {
      "name" : "Josiah Kiehl",
      "screen_name" : "bluepojo",
      "indices" : [ 60, 69 ],
      "id_str" : "327477172",
      "id" : 327477172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71279933686681600",
  "geo" : { },
  "id_str" : "71292403742539776",
  "in_reply_to_user_id" : 17503660,
  "text" : "@RayHightower hey @thoughtbot didn't write that! @erikh and @bluepojo did!",
  "id" : 71292403742539776,
  "in_reply_to_status_id" : 71279933686681600,
  "created_at" : "2011-05-19 19:13:28 +0000",
  "in_reply_to_screen_name" : "RayHightower",
  "in_reply_to_user_id_str" : "17503660",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71274104556224512",
  "geo" : { },
  "id_str" : "71289319314300928",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan PULL REQUEST PLZ http:\/\/github.com\/rubygems\/guides",
  "id" : 71289319314300928,
  "in_reply_to_status_id" : 71274104556224512,
  "created_at" : "2011-05-19 19:01:12 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Lavena",
      "screen_name" : "luislavena",
      "indices" : [ 0, 11 ],
      "id_str" : "16891327",
      "id" : 16891327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71277163172741120",
  "geo" : { },
  "id_str" : "71289265941774336",
  "in_reply_to_user_id" : 16891327,
  "text" : "@luislavena ah yes, sorry :(",
  "id" : 71289265941774336,
  "in_reply_to_status_id" : 71277163172741120,
  "created_at" : "2011-05-19 19:01:00 +0000",
  "in_reply_to_screen_name" : "luislavena",
  "in_reply_to_user_id_str" : "16891327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71289183548866560",
  "text" : "Thanks for coming to my talk at #railsconf! Here's the slides: http:\/\/is.gd\/LeXMmT and visit http:\/\/guides.rubygems.org !",
  "id" : 71289183548866560,
  "created_at" : "2011-05-19 19:00:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RailsConf 2015",
      "screen_name" : "railsconf",
      "indices" : [ 4, 14 ],
      "id_str" : "5493662",
      "id" : 5493662
    }, {
      "name" : "Ben Scofield",
      "screen_name" : "bscofield",
      "indices" : [ 53, 63 ],
      "id_str" : "7921582",
      "id" : 7921582
    }, {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 64, 75 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71256614816055296",
  "text" : "Hey @railsconf do the podiums have mac adapters? \/cc @bscofield @chadfowler",
  "id" : 71256614816055296,
  "created_at" : "2011-05-19 16:51:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EMRubyConf",
      "screen_name" : "emrubyconf",
      "indices" : [ 3, 14 ],
      "id_str" : "293645295",
      "id" : 293645295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71255906930786304",
  "text" : "At @emrubyconf ZOMG!",
  "id" : 71255906930786304,
  "created_at" : "2011-05-19 16:48:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 3, 9 ],
      "id_str" : "9885102",
      "id" : 9885102
    }, {
      "name" : "EMRubyConf",
      "screen_name" : "emrubyconf",
      "indices" : [ 31, 42 ],
      "id_str" : "293645295",
      "id" : 293645295
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71245871991365632",
  "text" : "RT @drnic: Grab lunch and join @emrubyconf in rm 348 at 12:45ish. Lots of great talks http:\/\/EMRubyConf.com #railsconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EMRubyConf",
        "screen_name" : "emrubyconf",
        "indices" : [ 20, 31 ],
        "id_str" : "293645295",
        "id" : 293645295
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "railsconf",
        "indices" : [ 97, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71245531434848256",
    "text" : "Grab lunch and join @emrubyconf in rm 348 at 12:45ish. Lots of great talks http:\/\/EMRubyConf.com #railsconf",
    "id" : 71245531434848256,
    "created_at" : "2011-05-19 16:07:13 +0000",
    "user" : {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "protected" : false,
      "id_str" : "9885102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540867377907253249\/T8RB8AXG_normal.jpeg",
      "id" : 9885102,
      "verified" : false
    }
  },
  "id" : 71245871991365632,
  "created_at" : "2011-05-19 16:08:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BohConf",
      "screen_name" : "bohconf",
      "indices" : [ 22, 30 ],
      "id_str" : "135572769",
      "id" : 135572769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71224388736909312",
  "text" : "Candy of all kinds at @bohconf http:\/\/yfrog.com\/gyfjgozej",
  "id" : 71224388736909312,
  "created_at" : "2011-05-19 14:43:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 27, 39 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71219059911430145",
  "text" : "ZOMG! http:\/\/rubyconf.org\/ @tristandunn !!!",
  "id" : 71219059911430145,
  "created_at" : "2011-05-19 14:22:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EMRubyConf",
      "screen_name" : "emrubyconf",
      "indices" : [ 57, 68 ],
      "id_str" : "293645295",
      "id" : 293645295
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71218604913340417",
  "text" : "Packed day today: 12:45, talking about EM and testing at @emrubyconf, 1:50, learn to cut your own gems! #railsconf",
  "id" : 71218604913340417,
  "created_at" : "2011-05-19 14:20:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Scruggs",
      "screen_name" : "jakescruggs",
      "indices" : [ 36, 48 ],
      "id_str" : "15246024",
      "id" : 15246024
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71217745882124288",
  "geo" : { },
  "id_str" : "71218104918740993",
  "in_reply_to_user_id" : 133486420,
  "text" : "@BlueBoxRenee maybe you should find @jakescruggs !!",
  "id" : 71218104918740993,
  "in_reply_to_status_id" : 71217745882124288,
  "created_at" : "2011-05-19 14:18:14 +0000",
  "in_reply_to_screen_name" : "gigglegirl4e",
  "in_reply_to_user_id_str" : "133486420",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71007994120372225",
  "geo" : { },
  "id_str" : "71015346676563969",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant listen to moar Crimson King",
  "id" : 71015346676563969,
  "in_reply_to_status_id" : 71007994120372225,
  "created_at" : "2011-05-19 00:52:32 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 8, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70996354708680704",
  "text" : "Current #railsconf status: http:\/\/www.burningshed.com\/covers\/large1379.jpg",
  "id" : 70996354708680704,
  "created_at" : "2011-05-18 23:37:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 70, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70993704059543552",
  "text" : "This keynote is like a whirlwind tour through http:\/\/\/rosettacode.org #railsconf",
  "id" : 70993704059543552,
  "created_at" : "2011-05-18 23:26:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70990846362791936",
  "text" : "Did I just walk into a Guy Steele programming music video? #railsconf",
  "id" : 70990846362791936,
  "created_at" : "2011-05-18 23:15:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 44 ],
      "url" : "http:\/\/t.co\/X4LCxmQ",
      "expanded_url" : "http:\/\/thoughtbot.com",
      "display_url" : "thoughtbot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "70958452607954944",
  "text" : "RT @thoughtbot: hey, new http:\/\/t.co\/X4LCxmQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 28 ],
        "url" : "http:\/\/t.co\/X4LCxmQ",
        "expanded_url" : "http:\/\/thoughtbot.com",
        "display_url" : "thoughtbot.com"
      } ]
    },
    "geo" : { },
    "id_str" : "70905187430182913",
    "text" : "hey, new http:\/\/t.co\/X4LCxmQ",
    "id" : 70905187430182913,
    "created_at" : "2011-05-18 17:34:48 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 70958452607954944,
  "created_at" : "2011-05-18 21:06:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    }, {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 52, 65 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70944493939068929",
  "geo" : { },
  "id_str" : "70949826015133697",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick the sad part of this statement is that @wayneeseguin wrote it to deploy ruby to his production servers",
  "id" : 70949826015133697,
  "in_reply_to_status_id" : 70944493939068929,
  "created_at" : "2011-05-18 20:32:11 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 5, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70916258287198208",
  "text" : "Dear #railsconf speakers: Please make your fonts bigger when on screen. Love, all programmers with terrible vision.",
  "id" : 70916258287198208,
  "created_at" : "2011-05-18 18:18:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 72, 83 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70854784080551937",
  "text" : "Double dream hands! So intense! http:\/\/yfrog.com\/h288378241j #railsconf @tenderlove this is a riot.",
  "id" : 70854784080551937,
  "created_at" : "2011-05-18 14:14:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 0, 7 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70696897739894784",
  "geo" : { },
  "id_str" : "70700616577585152",
  "in_reply_to_user_id" : 15317640,
  "text" : "@hone02 just me left! hacking still.",
  "id" : 70700616577585152,
  "in_reply_to_status_id" : 70696897739894784,
  "created_at" : "2011-05-18 04:01:55 +0000",
  "in_reply_to_screen_name" : "hone02",
  "in_reply_to_user_id_str" : "15317640",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70677495019606017",
  "text" : "Chilling at the Hyatt bar. Anyone up for Innovation or Munchkin now? :D",
  "id" : 70677495019606017,
  "created_at" : "2011-05-18 02:30:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EMRubyConf",
      "screen_name" : "emrubyconf",
      "indices" : [ 3, 14 ],
      "id_str" : "293645295",
      "id" : 293645295
    }, {
      "name" : "BohConf",
      "screen_name" : "bohconf",
      "indices" : [ 114, 122 ],
      "id_str" : "135572769",
      "id" : 135572769
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70674286477709313",
  "text" : "RT @emrubyconf: The website and program is live!! http:\/\/emrubyconf.com Bring a friend. They know nothing either. @bohconf 12:30 Thursda ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BohConf",
        "screen_name" : "bohconf",
        "indices" : [ 98, 106 ],
        "id_str" : "135572769",
        "id" : 135572769
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "railsconf",
        "indices" : [ 122, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70580354544705536",
    "text" : "The website and program is live!! http:\/\/emrubyconf.com Bring a friend. They know nothing either. @bohconf 12:30 Thursday #railsconf",
    "id" : 70580354544705536,
    "created_at" : "2011-05-17 20:04:02 +0000",
    "user" : {
      "name" : "EMRubyConf",
      "screen_name" : "emrubyconf",
      "protected" : false,
      "id_str" : "293645295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1340210705\/rubyicons-1.gif_normal.png",
      "id" : 293645295,
      "verified" : false
    }
  },
  "id" : 70674286477709313,
  "created_at" : "2011-05-18 02:17:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 0, 11 ],
      "id_str" : "2355631",
      "id" : 2355631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70656391915905024",
  "geo" : { },
  "id_str" : "70658247467610112",
  "in_reply_to_user_id" : 2355631,
  "text" : "@lmarburger at the hyatt chilling, might play later or tomorrow though!",
  "id" : 70658247467610112,
  "in_reply_to_status_id" : 70656391915905024,
  "created_at" : "2011-05-18 01:13:33 +0000",
  "in_reply_to_screen_name" : "lmarburger",
  "in_reply_to_user_id_str" : "2355631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70646760363667456",
  "text" : "Ok, maybe not! Another night for the games!",
  "id" : 70646760363667456,
  "created_at" : "2011-05-18 00:27:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BohConf",
      "screen_name" : "bohconf",
      "indices" : [ 11, 19 ],
      "id_str" : "135572769",
      "id" : 135572769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70645937025978368",
  "text" : "Heading to @bohconf ...anyone up for Innovation or Munchkin?",
  "id" : 70645937025978368,
  "created_at" : "2011-05-18 00:24:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "jumparound29",
      "indices" : [ 0, 13 ],
      "id_str" : "27851856",
      "id" : 27851856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70643824023715841",
  "geo" : { },
  "id_str" : "70645347302653952",
  "in_reply_to_user_id" : 27851856,
  "text" : "@jumparound29 :D a programming language! http:\/\/ruby-lang.org try it: http:\/\/try-ruby.org",
  "id" : 70645347302653952,
  "in_reply_to_status_id" : 70643824023715841,
  "created_at" : "2011-05-18 00:22:17 +0000",
  "in_reply_to_screen_name" : "jumparound29",
  "in_reply_to_user_id_str" : "27851856",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 3, 10 ],
      "id_str" : "14246143",
      "id" : 14246143
    }, {
      "name" : "Darcy Laycock",
      "screen_name" : "Sutto",
      "indices" : [ 53, 59 ],
      "id_str" : "5099921",
      "id" : 5099921
    }, {
      "name" : "Jonas Nicklas",
      "screen_name" : "jonicklas",
      "indices" : [ 60, 70 ],
      "id_str" : "7807502",
      "id" : 7807502
    }, {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 71, 80 ],
      "id_str" : "14506011",
      "id" : 14506011
    }, {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 81, 88 ],
      "id_str" : "5186831",
      "id" : 5186831
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 89, 102 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Michael Hartl",
      "screen_name" : "mhartl",
      "indices" : [ 103, 110 ],
      "id_str" : "9902092",
      "id" : 9902092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70642576801271808",
  "text" : "RT @rbates: Congratulations to the 2011 Ruby Heroes! @sutto @jonicklas @ryanbigg @lsegal @steveklabnik @mhartl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Darcy Laycock",
        "screen_name" : "Sutto",
        "indices" : [ 41, 47 ],
        "id_str" : "5099921",
        "id" : 5099921
      }, {
        "name" : "Jonas Nicklas",
        "screen_name" : "jonicklas",
        "indices" : [ 48, 58 ],
        "id_str" : "7807502",
        "id" : 7807502
      }, {
        "name" : "Ryan Bigg",
        "screen_name" : "ryanbigg",
        "indices" : [ 59, 68 ],
        "id_str" : "14506011",
        "id" : 14506011
      }, {
        "name" : "Loren Segal",
        "screen_name" : "lsegal",
        "indices" : [ 69, 76 ],
        "id_str" : "5186831",
        "id" : 5186831
      }, {
        "name" : "The Dream of the 90s",
        "screen_name" : "steveklabnik",
        "indices" : [ 77, 90 ],
        "id_str" : "22386062",
        "id" : 22386062
      }, {
        "name" : "Michael Hartl",
        "screen_name" : "mhartl",
        "indices" : [ 91, 98 ],
        "id_str" : "9902092",
        "id" : 9902092
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70640637740982275",
    "text" : "Congratulations to the 2011 Ruby Heroes! @sutto @jonicklas @ryanbigg @lsegal @steveklabnik @mhartl",
    "id" : 70640637740982275,
    "created_at" : "2011-05-18 00:03:35 +0000",
    "user" : {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "protected" : false,
      "id_str" : "14246143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/52189024\/ryan_bates_cropped_normal.jpg",
      "id" : 14246143,
      "verified" : false
    }
  },
  "id" : 70642576801271808,
  "created_at" : "2011-05-18 00:11:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70637336827936768",
  "text" : "Current status: http:\/\/isotropic.org\/papers\/chicken.pdf",
  "id" : 70637336827936768,
  "created_at" : "2011-05-17 23:50:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70630311763001344",
  "geo" : { },
  "id_str" : "70631450201952257",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove http:\/\/3.bp.blogspot.com\/_kVBIKsx0ZqQ\/TDT1cQsDIPI\/AAAAAAAAGeU\/wq8cndFLVdw\/s1600\/dizzybat2.jpg",
  "id" : 70631450201952257,
  "in_reply_to_status_id" : 70630311763001344,
  "created_at" : "2011-05-17 23:27:04 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Cox",
      "screen_name" : "imajes",
      "indices" : [ 0, 7 ],
      "id_str" : "75533",
      "id" : 75533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70630163787948032",
  "geo" : { },
  "id_str" : "70631348846592000",
  "in_reply_to_user_id" : 75533,
  "text" : "@imajes INSTALL MORE",
  "id" : 70631348846592000,
  "in_reply_to_status_id" : 70630163787948032,
  "created_at" : "2011-05-17 23:26:40 +0000",
  "in_reply_to_screen_name" : "imajes",
  "in_reply_to_user_id_str" : "75533",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "augustl4j",
      "screen_name" : "augustl",
      "indices" : [ 0, 8 ],
      "id_str" : "870091423",
      "id" : 870091423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70591944543309824",
  "text" : "@augustl u mad bro?",
  "id" : 70591944543309824,
  "created_at" : "2011-05-17 20:50:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EMRubyConf",
      "screen_name" : "emrubyconf",
      "indices" : [ 3, 14 ],
      "id_str" : "293645295",
      "id" : 293645295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70589545804079104",
  "text" : "RT @emrubyconf: Going to EMRubyConf? Let us know! http:\/\/lanyrd.com\/2011\/emrubyconf\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70583546137415680",
    "text" : "Going to EMRubyConf? Let us know! http:\/\/lanyrd.com\/2011\/emrubyconf\/",
    "id" : 70583546137415680,
    "created_at" : "2011-05-17 20:16:43 +0000",
    "user" : {
      "name" : "EMRubyConf",
      "screen_name" : "emrubyconf",
      "protected" : false,
      "id_str" : "293645295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1340210705\/rubyicons-1.gif_normal.png",
      "id" : 293645295,
      "verified" : false
    }
  },
  "id" : 70589545804079104,
  "created_at" : "2011-05-17 20:40:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70506673571250178",
  "text" : "TIL that Rails is complicated.",
  "id" : 70506673571250178,
  "created_at" : "2011-05-17 15:11:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 3, 10 ],
      "id_str" : "6505422",
      "id" : 6505422
    }, {
      "name" : "Fake Josh",
      "screen_name" : "joshkalderimis",
      "indices" : [ 54, 69 ],
      "id_str" : "628398860",
      "id" : 628398860
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 78, 89 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 100, 108 ],
      "id_str" : "28819745",
      "id" : 28819745
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 113, 119 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70503308317556736",
  "text" : "RT @jyurek: Received a nice gift of stroopwafels from @joshkalderimis for the @thoughtbot team (and @sikachu and @qrush in particular).  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fake Josh",
        "screen_name" : "joshkalderimis",
        "indices" : [ 42, 57 ],
        "id_str" : "628398860",
        "id" : 628398860
      }, {
        "name" : "thoughtbot",
        "screen_name" : "thoughtbot",
        "indices" : [ 66, 77 ],
        "id_str" : "14114392",
        "id" : 14114392
      }, {
        "name" : "Prem Sichanugrist",
        "screen_name" : "sikachu",
        "indices" : [ 88, 96 ],
        "id_str" : "28819745",
        "id" : 28819745
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 101, 107 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70502265848467456",
    "text" : "Received a nice gift of stroopwafels from @joshkalderimis for the @thoughtbot team (and @sikachu and @qrush in particular). Awesome!",
    "id" : 70502265848467456,
    "created_at" : "2011-05-17 14:53:44 +0000",
    "user" : {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "protected" : false,
      "id_str" : "6505422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/26559072\/498945207_94895e9527_s_normal.jpg",
      "id" : 6505422,
      "verified" : false
    }
  },
  "id" : 70503308317556736,
  "created_at" : "2011-05-17 14:57:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 87, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70488022189228032",
  "text" : "GRRRRRR CHANGING THINGS IS HARD I USE A DYNAMIC INTERPRETED LANGUAGE THAT LEAKS MEMORY #railsconf",
  "id" : 70488022189228032,
  "created_at" : "2011-05-17 13:57:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Cangiano",
      "screen_name" : "acangiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14582359",
      "id" : 14582359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70483338783227905",
  "geo" : { },
  "id_str" : "70484544733716481",
  "in_reply_to_user_id" : 14582359,
  "text" : "@acangiano use the twiddle-wakka: ~&gt; it's pessimistic, not optimistic.",
  "id" : 70484544733716481,
  "in_reply_to_status_id" : 70483338783227905,
  "created_at" : "2011-05-17 13:43:19 +0000",
  "in_reply_to_screen_name" : "acangiano",
  "in_reply_to_user_id_str" : "14582359",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Cangiano",
      "screen_name" : "acangiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14582359",
      "id" : 14582359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70483338783227905",
  "geo" : { },
  "id_str" : "70484280823918592",
  "in_reply_to_user_id" : 14582359,
  "text" : "@acangiano no, that's even worse! That means your gem will work *any* future version, no matter how their API changes.",
  "id" : 70484280823918592,
  "in_reply_to_status_id" : 70483338783227905,
  "created_at" : "2011-05-17 13:42:16 +0000",
  "in_reply_to_screen_name" : "acangiano",
  "in_reply_to_user_id_str" : "14582359",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70480961497866240",
  "geo" : { },
  "id_str" : "70481296572424192",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad I'll refactor that to 45 new folders. Innovation!",
  "id" : 70481296572424192,
  "in_reply_to_status_id" : 70480961497866240,
  "created_at" : "2011-05-17 13:30:25 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 70, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70481039566450688",
  "text" : "What is so difficult about just making folders in public\/javascripts? #railsconf",
  "id" : 70481039566450688,
  "created_at" : "2011-05-17 13:29:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gowalla",
      "screen_name" : "gowalla",
      "indices" : [ 3, 11 ],
      "id_str" : "18695316",
      "id" : 18695316
    }, {
      "name" : "Adam Keys",
      "screen_name" : "adamkeys",
      "indices" : [ 12, 21 ],
      "id_str" : "35980659",
      "id" : 35980659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70470921676271616",
  "text" : "Yo @gowalla @adamkeys ...no #railsconf event? :(",
  "id" : 70470921676271616,
  "created_at" : "2011-05-17 12:49:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RailsConf",
      "indices" : [ 3, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70470804365778944",
  "text" : "Hi #RailsConf!",
  "id" : 70470804365778944,
  "created_at" : "2011-05-17 12:48:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.2863203667, -76.6181232667 ]
  },
  "id_str" : "70286162719293440",
  "text" : "I'm at Pratt Street Ale House in Baltimore, MD http:\/\/gowal.la\/c\/4eSHE",
  "id" : 70286162719293440,
  "created_at" : "2011-05-17 00:35:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ruscio",
      "screen_name" : "josephruscio",
      "indices" : [ 0, 13 ],
      "id_str" : "18210643",
      "id" : 18210643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70276417279111168",
  "geo" : { },
  "id_str" : "70277114984796160",
  "in_reply_to_user_id" : 18210643,
  "text" : "@josephruscio I have done that before from Scranton back to Boston...will be doing it again over the summer. So good.",
  "id" : 70277114984796160,
  "in_reply_to_status_id" : 70276417279111168,
  "created_at" : "2011-05-16 23:59:04 +0000",
  "in_reply_to_screen_name" : "josephruscio",
  "in_reply_to_user_id_str" : "18210643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    }, {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 8, 15 ],
      "id_str" : "11322372",
      "id" : 11322372
    }, {
      "name" : "Joseph Ruscio",
      "screen_name" : "josephruscio",
      "indices" : [ 16, 29 ],
      "id_str" : "18210643",
      "id" : 18210643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70270889068998656",
  "geo" : { },
  "id_str" : "70275926897856512",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox @holman @josephruscio i would try this. No joke.",
  "id" : 70275926897856512,
  "in_reply_to_status_id" : 70270889068998656,
  "created_at" : "2011-05-16 23:54:21 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70270526639190016",
  "geo" : { },
  "id_str" : "70275602766237696",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman seriously! They don't sell it in Boston :(",
  "id" : 70275602766237696,
  "in_reply_to_status_id" : 70270526639190016,
  "created_at" : "2011-05-16 23:53:04 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.2862710097, -76.6143429183 ]
  },
  "id_str" : "70262467686699008",
  "text" : "Yuengling! Finally! @ Kona Grill http:\/\/gowal.la\/c\/4eRor",
  "id" : 70262467686699008,
  "created_at" : "2011-05-16 23:00:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70251286070689792",
  "geo" : { },
  "id_str" : "70262158058995712",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman yep, sorry dude.",
  "id" : 70262158058995712,
  "in_reply_to_status_id" : 70251286070689792,
  "created_at" : "2011-05-16 22:59:38 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70240437302075392",
  "geo" : { },
  "id_str" : "70240594122903552",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic the crappy irish pub? Just came from boston dude, cmon!",
  "id" : 70240594122903552,
  "in_reply_to_status_id" : 70240437302075392,
  "created_at" : "2011-05-16 21:33:57 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 80, 90 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70239418400784384",
  "text" : "Hey Baltimore! Any suggestions for food near #railsconf that isn't Hooters? \/cc @jtrupiano",
  "id" : 70239418400784384,
  "created_at" : "2011-05-16 21:29:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70226314392649728",
  "text" : "Hi Baltimore!",
  "id" : 70226314392649728,
  "created_at" : "2011-05-16 20:37:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70179364158967808",
  "geo" : { },
  "id_str" : "70182677948538880",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal trying to generate docs off of Gem::Specification ...I only want the :section: parts though :( \/cc @ra66i",
  "id" : 70182677948538880,
  "in_reply_to_status_id" : 70179364158967808,
  "created_at" : "2011-05-16 17:43:49 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70179364158967808",
  "geo" : { },
  "id_str" : "70182334305021953",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal arriving in bmore soon! I'll have to look at the markdown generator for yard.",
  "id" : 70182334305021953,
  "in_reply_to_status_id" : 70179364158967808,
  "created_at" : "2011-05-16 17:42:27 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 87, 94 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70165327794814976",
  "text" : "Writing a Darkfish RDoc template to spit out Markdown and it's brain hurtingly stupid. @lsegal does YARD make this any easier?",
  "id" : 70165327794814976,
  "created_at" : "2011-05-16 16:34:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 0, 10 ],
      "id_str" : "9980812",
      "id" : 9980812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69976170787123200",
  "geo" : { },
  "id_str" : "69979081848000512",
  "in_reply_to_user_id" : 9980812,
  "text" : "@igrigorik your variables aren't LOLing enough. also, \"GIMME LINEZ\" is awesome.",
  "id" : 69979081848000512,
  "in_reply_to_status_id" : 69976170787123200,
  "created_at" : "2011-05-16 04:14:47 +0000",
  "in_reply_to_screen_name" : "igrigorik",
  "in_reply_to_user_id_str" : "9980812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69956343401955328",
  "text" : "It's like ordering a speciality dollar coin with the Statue of Liberty on it in REAL CALIFORNIA GOLD just for nerds. http:\/\/bitbills.com",
  "id" : 69956343401955328,
  "created_at" : "2011-05-16 02:44:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69921630612234241",
  "text" : "Getting many votes for Munchkin and Innovation. Both are tiny, so both shall come!",
  "id" : 69921630612234241,
  "created_at" : "2011-05-16 00:26:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Bair",
      "screen_name" : "adambair",
      "indices" : [ 0, 9 ],
      "id_str" : "10647472",
      "id" : 10647472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69912895881875456",
  "geo" : { },
  "id_str" : "69913545214656512",
  "in_reply_to_user_id" : 10647472,
  "text" : "@adambair cool, you gonna bring it? Just going from my collection",
  "id" : 69913545214656512,
  "in_reply_to_status_id" : 69912895881875456,
  "created_at" : "2011-05-15 23:54:22 +0000",
  "in_reply_to_screen_name" : "adambair",
  "in_reply_to_user_id_str" : "10647472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69912482961047552",
  "text" : "What game should I bring to #railsconf? Ticket to Ride Europe, Innovation, or Munchkin?",
  "id" : 69912482961047552,
  "created_at" : "2011-05-15 23:50:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.37177595, -71.2364305833 ]
  },
  "id_str" : "69908077033439232",
  "text" : "Living across the street from here is going to be dangerous. @ Watch City Brewing Company http:\/\/gowal.la\/c\/4eu98",
  "id" : 69908077033439232,
  "created_at" : "2011-05-15 23:32:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69885942428745728",
  "geo" : { },
  "id_str" : "69897174690963457",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu just in boston, because it started here!",
  "id" : 69897174690963457,
  "in_reply_to_status_id" : 69885942428745728,
  "created_at" : "2011-05-15 22:49:19 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keenan Brock",
      "screen_name" : "kbrock",
      "indices" : [ 0, 7 ],
      "id_str" : "623223",
      "id" : 623223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69744787602939904",
  "geo" : { },
  "id_str" : "69746943148044288",
  "in_reply_to_user_id" : 623223,
  "text" : "@kbrock you mean the syntax highlighting? It uses highlight.js",
  "id" : 69746943148044288,
  "in_reply_to_status_id" : 69744787602939904,
  "created_at" : "2011-05-15 12:52:21 +0000",
  "in_reply_to_screen_name" : "kbrock",
  "in_reply_to_user_id_str" : "623223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69599016601665537",
  "geo" : { },
  "id_str" : "69600266567155712",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic I will, after much hacking on em-hiredis i would love to pick some brains about it",
  "id" : 69600266567155712,
  "in_reply_to_status_id" : 69599016601665537,
  "created_at" : "2011-05-15 03:09:31 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brntbeer",
      "screen_name" : "brntbeer",
      "indices" : [ 0, 9 ],
      "id_str" : "14563437",
      "id" : 14563437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69581566728351744",
  "geo" : { },
  "id_str" : "69588210711408640",
  "in_reply_to_user_id" : 14563437,
  "text" : "@brntbeer waltham, not far!",
  "id" : 69588210711408640,
  "in_reply_to_status_id" : 69581566728351744,
  "created_at" : "2011-05-15 02:21:36 +0000",
  "in_reply_to_screen_name" : "brntbeer",
  "in_reply_to_user_id_str" : "14563437",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69581438470717440",
  "text" : "Packed! Moving before #railsconf: BONUS STRESS",
  "id" : 69581438470717440,
  "created_at" : "2011-05-15 01:54:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 12, 18 ],
      "id_str" : "9885102",
      "id" : 9885102
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 68, 78 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69271813401747456",
  "geo" : { },
  "id_str" : "69277586651492352",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove @drnic +1 as gems. We could have 'blessed' gems then on @gemcutter that only the core team has access to",
  "id" : 69277586651492352,
  "in_reply_to_status_id" : 69271813401747456,
  "created_at" : "2011-05-14 05:47:18 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 3, 9 ],
      "id_str" : "9885102",
      "id" : 9885102
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 11, 22 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69277317393956864",
  "text" : "RT @drnic: @tenderlove 600,000 git[hub] users have figured it out; why can't 20 ruby-core committers?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aaron Patterson",
        "screen_name" : "tenderlove",
        "indices" : [ 0, 11 ],
        "id_str" : "14761655",
        "id" : 14761655
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "69273093947920384",
    "geo" : { },
    "id_str" : "69273578377461760",
    "in_reply_to_user_id" : 14761655,
    "text" : "@tenderlove 600,000 git[hub] users have figured it out; why can't 20 ruby-core committers?",
    "id" : 69273578377461760,
    "in_reply_to_status_id" : 69273093947920384,
    "created_at" : "2011-05-14 05:31:22 +0000",
    "in_reply_to_screen_name" : "tenderlove",
    "in_reply_to_user_id_str" : "14761655",
    "user" : {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "protected" : false,
      "id_str" : "9885102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540867377907253249\/T8RB8AXG_normal.jpeg",
      "id" : 9885102,
      "verified" : false
    }
  },
  "id" : 69277317393956864,
  "created_at" : "2011-05-14 05:46:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69221483448250368",
  "text" : "Hilarious Rush reference in the latest South Park. Geddy's nose! https:\/\/img.skitch.com\/20110514-k13b27jqmygymyjwx516apwunb.gif",
  "id" : 69221483448250368,
  "created_at" : "2011-05-14 02:04:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69169087955218433",
  "geo" : { },
  "id_str" : "69169702819209216",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg I disagree. I have a bit of a surprise too. We'll have to meet up and discuss.",
  "id" : 69169702819209216,
  "in_reply_to_status_id" : 69169087955218433,
  "created_at" : "2011-05-13 22:38:36 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 3, 10 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http:\/\/t.co\/3HrN0jf",
      "expanded_url" : "http:\/\/bostonrb.org\/presentations",
      "display_url" : "bostonrb.org\/presentations"
    } ]
  },
  "geo" : { },
  "id_str" : "69038580588232704",
  "text" : "RT @Croaky: Lots of good Ruby content now live here: http:\/\/t.co\/3HrN0jf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 60 ],
        "url" : "http:\/\/t.co\/3HrN0jf",
        "expanded_url" : "http:\/\/bostonrb.org\/presentations",
        "display_url" : "bostonrb.org\/presentations"
      } ]
    },
    "geo" : { },
    "id_str" : "68882440109826048",
    "text" : "Lots of good Ruby content now live here: http:\/\/t.co\/3HrN0jf",
    "id" : 68882440109826048,
    "created_at" : "2011-05-13 03:37:08 +0000",
    "user" : {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "protected" : false,
      "id_str" : "787595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568676101967196160\/nP3jFRbr_normal.jpeg",
      "id" : 787595,
      "verified" : false
    }
  },
  "id" : 69038580588232704,
  "created_at" : "2011-05-13 13:57:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Will",
      "screen_name" : "rakaur",
      "indices" : [ 0, 7 ],
      "id_str" : "14470078",
      "id" : 14470078
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 8, 18 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69031577132351489",
  "geo" : { },
  "id_str" : "69038071542333440",
  "in_reply_to_user_id" : 14470078,
  "text" : "@rakaur @gemcutter nope.",
  "id" : 69038071542333440,
  "in_reply_to_status_id" : 69031577132351489,
  "created_at" : "2011-05-13 13:55:33 +0000",
  "in_reply_to_screen_name" : "rakaur",
  "in_reply_to_user_id_str" : "14470078",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 0, 10 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69014455467511810",
  "geo" : { },
  "id_str" : "69031496542978048",
  "in_reply_to_user_id" : 5965482,
  "text" : "@jankowski I hope that's your background for standup!",
  "id" : 69031496542978048,
  "in_reply_to_status_id" : 69014455467511810,
  "created_at" : "2011-05-13 13:29:25 +0000",
  "in_reply_to_screen_name" : "jankowski",
  "in_reply_to_user_id_str" : "5965482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Leveille",
      "screen_name" : "danlev",
      "indices" : [ 0, 7 ],
      "id_str" : "13612732",
      "id" : 13612732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68935320078516224",
  "geo" : { },
  "id_str" : "68941070481891329",
  "in_reply_to_user_id" : 13612732,
  "text" : "@danlev hey its domain name girl!",
  "id" : 68941070481891329,
  "in_reply_to_status_id" : 68935320078516224,
  "created_at" : "2011-05-13 07:30:06 +0000",
  "in_reply_to_screen_name" : "danlev",
  "in_reply_to_user_id_str" : "13612732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Wiggins",
      "screen_name" : "hirodusk",
      "indices" : [ 0, 9 ],
      "id_str" : "9341072",
      "id" : 9341072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68830633111199744",
  "geo" : { },
  "id_str" : "68831604235186176",
  "in_reply_to_user_id" : 9341072,
  "text" : "@hirodusk same with looking up certs. First time I've use 'tee'",
  "id" : 68831604235186176,
  "in_reply_to_status_id" : 68830633111199744,
  "created_at" : "2011-05-13 00:15:07 +0000",
  "in_reply_to_screen_name" : "hirodusk",
  "in_reply_to_user_id_str" : "9341072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68772927193100289",
  "text" : "Expected errors when name is set to \"\u2603\", got no errors",
  "id" : 68772927193100289,
  "created_at" : "2011-05-12 20:21:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 0, 6 ],
      "id_str" : "15359408",
      "id" : 15359408
    }, {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 7, 23 ],
      "id_str" : "16997374",
      "id" : 16997374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68767175263006720",
  "geo" : { },
  "id_str" : "68770077637492736",
  "in_reply_to_user_id" : 15359408,
  "text" : "@raggi @konstantinhaase https:\/\/github.com\/rubygems\/gemcutter\/issues\/285",
  "id" : 68770077637492736,
  "in_reply_to_status_id" : 68767175263006720,
  "created_at" : "2011-05-12 20:10:38 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68732808255909888",
  "text" : "Possibly the most accurate image for a Wikipedia article, ever: http:\/\/en.wikipedia.org\/wiki\/Mathlete",
  "id" : 68732808255909888,
  "created_at" : "2011-05-12 17:42:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Cangiano",
      "screen_name" : "acangiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14582359",
      "id" : 14582359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68656266267992064",
  "geo" : { },
  "id_str" : "68667545917460480",
  "in_reply_to_user_id" : 14582359,
  "text" : "@acangiano ooh, guess what 'dicks' does.",
  "id" : 68667545917460480,
  "in_reply_to_status_id" : 68656266267992064,
  "created_at" : "2011-05-12 13:23:13 +0000",
  "in_reply_to_screen_name" : "acangiano",
  "in_reply_to_user_id_str" : "14582359",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Aguilar",
      "screen_name" : "AlexAguilar18",
      "indices" : [ 0, 14 ],
      "id_str" : "19413679",
      "id" : 19413679
    }, {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 15, 20 ],
      "id_str" : "20941662",
      "id" : 20941662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68376040468250624",
  "geo" : { },
  "id_str" : "68408351272349696",
  "in_reply_to_user_id" : 19413679,
  "text" : "@AlexAguilar18 @JEG2 haha thanks!",
  "id" : 68408351272349696,
  "in_reply_to_status_id" : 68376040468250624,
  "created_at" : "2011-05-11 20:13:16 +0000",
  "in_reply_to_screen_name" : "AlexAguilar18",
  "in_reply_to_user_id_str" : "19413679",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68407294660063232",
  "text" : "I can't wait for 10-20 years from now where writing tests won't be an option, and there's not a stupid stigma of \"wasting time\" around TDD.",
  "id" : 68407294660063232,
  "created_at" : "2011-05-11 20:09:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Youssef Chaker",
      "screen_name" : "ychaker",
      "indices" : [ 0, 8 ],
      "id_str" : "16708075",
      "id" : 16708075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68401767150403584",
  "geo" : { },
  "id_str" : "68405523472592896",
  "in_reply_to_user_id" : 16708075,
  "text" : "@ychaker cancel and start again. also if you're more specific with gem versions it will go faster.",
  "id" : 68405523472592896,
  "in_reply_to_status_id" : 68401767150403584,
  "created_at" : "2011-05-11 20:02:02 +0000",
  "in_reply_to_screen_name" : "ychaker",
  "in_reply_to_user_id_str" : "16708075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68400322200092672",
  "text" : "First one to make a level editor for http:\/\/chrome.angrybirds.com\/ wins a prize!",
  "id" : 68400322200092672,
  "created_at" : "2011-05-11 19:41:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Denney",
      "screen_name" : "dandenney",
      "indices" : [ 3, 13 ],
      "id_str" : "15777123",
      "id" : 15777123
    }, {
      "name" : "Build Guild",
      "screen_name" : "buildguild",
      "indices" : [ 139, 140 ],
      "id_str" : "14686508",
      "id" : 14686508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 101 ],
      "url" : "http:\/\/t.co\/MFZZzej",
      "expanded_url" : "http:\/\/buildguild.org",
      "display_url" : "buildguild.org"
    } ]
  },
  "geo" : { },
  "id_str" : "68161101342314496",
  "text" : "RT @dandenney: \"Were these credits boring for you? Watch them as a movie ending!\" http:\/\/t.co\/MFZZzej - How do you not click that? Very  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Build Guild",
        "screen_name" : "buildguild",
        "indices" : [ 127, 138 ],
        "id_str" : "14686508",
        "id" : 14686508
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 86 ],
        "url" : "http:\/\/t.co\/MFZZzej",
        "expanded_url" : "http:\/\/buildguild.org",
        "display_url" : "buildguild.org"
      } ]
    },
    "geo" : { },
    "id_str" : "68153278042607616",
    "text" : "\"Were these credits boring for you? Watch them as a movie ending!\" http:\/\/t.co\/MFZZzej - How do you not click that? Very nice, @buildguild",
    "id" : 68153278042607616,
    "created_at" : "2011-05-11 03:19:42 +0000",
    "user" : {
      "name" : "Dan Denney",
      "screen_name" : "dandenney",
      "protected" : false,
      "id_str" : "15777123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556514560908075008\/gxOsLvjE_normal.png",
      "id" : 15777123,
      "verified" : false
    }
  },
  "id" : 68161101342314496,
  "created_at" : "2011-05-11 03:50:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68154674531938304",
  "text" : "Oh wow, GAE for Go. http:\/\/code.google.com\/appengine\/docs\/go\/overview.html",
  "id" : 68154674531938304,
  "created_at" : "2011-05-11 03:25:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 0, 10 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "include",
      "indices" : [ 11, 19 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68107615145697280",
  "geo" : { },
  "id_str" : "68110991841443840",
  "in_reply_to_user_id" : 23830105,
  "text" : "@joedamato #include &lt;herp.h&gt;",
  "id" : 68110991841443840,
  "in_reply_to_status_id" : 68107615145697280,
  "created_at" : "2011-05-11 00:31:40 +0000",
  "in_reply_to_screen_name" : "joedamato",
  "in_reply_to_user_id_str" : "23830105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 34, 44 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 53, 65 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68098581604737025",
  "text" : "Whoa, client side validations for @gemcutter! I hope @bcardarella has a pull request!",
  "id" : 68098581604737025,
  "created_at" : "2011-05-10 23:42:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Stephens",
      "screen_name" : "kindlyviking",
      "indices" : [ 0, 13 ],
      "id_str" : "6140922",
      "id" : 6140922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68096910774374402",
  "geo" : { },
  "id_str" : "68098360938201089",
  "in_reply_to_user_id" : 6140922,
  "text" : "@kindlyviking open a request on help.rubygems.org!",
  "id" : 68098360938201089,
  "in_reply_to_status_id" : 68096910774374402,
  "created_at" : "2011-05-10 23:41:29 +0000",
  "in_reply_to_screen_name" : "kindlyviking",
  "in_reply_to_user_id_str" : "6140922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photo",
      "indices" : [ 47, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.364018068, -71.079911346 ]
  },
  "id_str" : "68094957596065792",
  "text" : "Boston.rb time! @ Sermo http:\/\/gowal.la\/p\/ek9h #photo",
  "id" : 68094957596065792,
  "created_at" : "2011-05-10 23:27:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streeting",
      "screen_name" : "stevestreeting",
      "indices" : [ 0, 15 ],
      "id_str" : "138065190",
      "id" : 138065190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67919406977658880",
  "geo" : { },
  "id_str" : "67926637836115969",
  "in_reply_to_user_id" : 138065190,
  "text" : "@stevestreeting oh yeah, I've hit that before. Just wait until you get merge errors with your .hgtags file!",
  "id" : 67926637836115969,
  "in_reply_to_status_id" : 67919406977658880,
  "created_at" : "2011-05-10 12:19:07 +0000",
  "in_reply_to_screen_name" : "stevestreeting",
  "in_reply_to_user_id_str" : "138065190",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67776689802973184",
  "geo" : { },
  "id_str" : "67778938860077056",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza Put the text next to an avatar. BOOM TWITTER CLIENT",
  "id" : 67778938860077056,
  "in_reply_to_status_id" : 67776689802973184,
  "created_at" : "2011-05-10 02:32:12 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67753568643465216",
  "text" : "Most of Bob's Burger is pretty terrible, but it has absolute moments of genius.",
  "id" : 67753568643465216,
  "created_at" : "2011-05-10 00:51:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67721418313445377",
  "text" : "Ok, apparently Sparrow does do Send As, I just suck. Reconfigured it and it works.",
  "id" : 67721418313445377,
  "created_at" : "2011-05-09 22:43:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67719754131050496",
  "text" : "Once again on the hunt for an OSX mail client that doesn't suck. Do any handle sending from multiple accounts? (Send As from GMail)",
  "id" : 67719754131050496,
  "created_at" : "2011-05-09 22:37:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mic Pringle",
      "screen_name" : "micpringle",
      "indices" : [ 0, 11 ],
      "id_str" : "154493778",
      "id" : 154493778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67548443945598976",
  "geo" : { },
  "id_str" : "67603117587431424",
  "in_reply_to_user_id" : 154493778,
  "text" : "@micpringle i dont even have an iphone dude.",
  "id" : 67603117587431424,
  "in_reply_to_status_id" : 67548443945598976,
  "created_at" : "2011-05-09 14:53:33 +0000",
  "in_reply_to_screen_name" : "micpringle",
  "in_reply_to_user_id_str" : "154493778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67316826895433728",
  "text" : "Current status: http:\/\/www.youtube.com\/watch?v=UmQ5LsNMXZ4",
  "id" : 67316826895433728,
  "created_at" : "2011-05-08 19:55:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67295643294629888",
  "geo" : { },
  "id_str" : "67311948676599808",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh yeah especially the part where you have to use a special comb to pick all of the gross shit out of it",
  "id" : 67311948676599808,
  "in_reply_to_status_id" : 67295643294629888,
  "created_at" : "2011-05-08 19:36:33 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67264696474021888",
  "geo" : { },
  "id_str" : "67274701952663552",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu i only have it on xbox! sorry dude.",
  "id" : 67274701952663552,
  "in_reply_to_status_id" : 67264696474021888,
  "created_at" : "2011-05-08 17:08:33 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66999630059147264",
  "text" : "Boxed the TV up. Definitely moving time.",
  "id" : 66999630059147264,
  "created_at" : "2011-05-07 22:55:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66974757417000961",
  "text" : "Current status: http:\/\/www.youtube.com\/watch?v=xt5ghXdq6Z0",
  "id" : 66974757417000961,
  "created_at" : "2011-05-07 21:16:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66923804257038336",
  "text" : "Rather, beat it with @ablissfulgal. CAN I HAS MULTIPLAYER PORTAL 2 PLZKTHX",
  "id" : 66923804257038336,
  "created_at" : "2011-05-07 17:54:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66922006100180992",
  "text" : "Beat Portal 2 co-op. I wish it wasn't over!",
  "id" : 66922006100180992,
  "created_at" : "2011-05-07 17:47:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 6, 14 ],
      "id_str" : "28819745",
      "id" : 28819745
    }, {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 82, 89 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66328559366586369",
  "text" : "Damn, @sikachu is all over this changelog! https:\/\/gist.github.com\/958283 (Thanks @rbates!)",
  "id" : 66328559366586369,
  "created_at" : "2011-05-06 02:28:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 53, 61 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66214829840535552",
  "text" : "Created a new list, @qrush\/css-haters to commemorate @rubiety's realization. If anyone else wants in, yell (physically, verbally).",
  "id" : 66214829840535552,
  "created_at" : "2011-05-05 18:57:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66214378407608322",
  "text" : "Re: IRC question: Maybe I'll write a webservice someday that basically acts as a crappy IRC client that can email you. Fun.",
  "id" : 66214378407608322,
  "created_at" : "2011-05-05 18:55:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66163810725150720",
  "text" : "Current status: http:\/\/www.esquire.com\/cm\/esquire\/images\/billy-mays-092909-lg.jpg",
  "id" : 66163810725150720,
  "created_at" : "2011-05-05 15:34:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66131625901178880",
  "text" : "Are there any IRC clients that run in the background (or on a site) that notify you via email or something if you get pinged?",
  "id" : 66131625901178880,
  "created_at" : "2011-05-05 13:26:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    }, {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 11, 24 ],
      "id_str" : "11587602",
      "id" : 11587602
    }, {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 51, 60 ],
      "id_str" : "19297751",
      "id" : 19297751
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 107, 116 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65948303891775488",
  "geo" : { },
  "id_str" : "65949574023487488",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking @wayneeseguin did the same for git with @gitready...just wait until you see what's in store for @rubygems :)",
  "id" : 65949574023487488,
  "in_reply_to_status_id" : 65948303891775488,
  "created_at" : "2011-05-05 01:22:58 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ph7",
      "screen_name" : "ph7",
      "indices" : [ 0, 4 ],
      "id_str" : "16472345",
      "id" : 16472345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65842923169783809",
  "geo" : { },
  "id_str" : "65843450079219713",
  "in_reply_to_user_id" : 16472345,
  "text" : "@ph7 yes, nethack!",
  "id" : 65843450079219713,
  "in_reply_to_status_id" : 65842923169783809,
  "created_at" : "2011-05-04 18:21:16 +0000",
  "in_reply_to_screen_name" : "ph7",
  "in_reply_to_user_id_str" : "16472345",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65829213571264512",
  "text" : "Current status: http:\/\/fc08.deviantart.net\/fs26\/f\/2008\/111\/5\/b\/Wolverine_vs_T_rex_by_nJoo.jpg",
  "id" : 65829213571264512,
  "created_at" : "2011-05-04 17:24:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The HTML5 Douche",
      "screen_name" : "html5douche",
      "indices" : [ 3, 15 ],
      "id_str" : "198612383",
      "id" : 198612383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65589150560169984",
  "text" : "RT @html5douche: YOU KNOW WHAT WE NEED?\n\nLIKE FIFTY MORE CSS FRAMEWORKS.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65589058310651904",
    "text" : "YOU KNOW WHAT WE NEED?\n\nLIKE FIFTY MORE CSS FRAMEWORKS.",
    "id" : 65589058310651904,
    "created_at" : "2011-05-04 01:30:24 +0000",
    "user" : {
      "name" : "The HTML5 Douche",
      "screen_name" : "html5douche",
      "protected" : false,
      "id_str" : "198612383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1138106603\/66_A_Douchebag_normal.jpg",
      "id" : 198612383,
      "verified" : false
    }
  },
  "id" : 65589150560169984,
  "created_at" : "2011-05-04 01:30:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65586662247378944",
  "geo" : { },
  "id_str" : "65587262284505088",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton you mean, You're Fucking Welcome. Can I has iterm 2 config?",
  "id" : 65587262284505088,
  "in_reply_to_status_id" : 65586662247378944,
  "created_at" : "2011-05-04 01:23:16 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65545151510085632",
  "text" : "Current status: http:\/\/yfrog.com\/h2xrftwzj",
  "id" : 65545151510085632,
  "created_at" : "2011-05-03 22:35:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photo",
      "indices" : [ 72, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3462225998, -71.0977756977 ]
  },
  "id_str" : "65544035934281728",
  "text" : "Ridiculous seats for the Sox game! @ Fenway Park http:\/\/gowal.la\/p\/e626 #photo",
  "id" : 65544035934281728,
  "created_at" : "2011-05-03 22:31:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65472414762532865",
  "text" : "Current status: http:\/\/i.imgur.com\/rTST6.gif",
  "id" : 65472414762532865,
  "created_at" : "2011-05-03 17:46:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Bair",
      "screen_name" : "adambair",
      "indices" : [ 0, 9 ],
      "id_str" : "10647472",
      "id" : 10647472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65467648053477376",
  "geo" : { },
  "id_str" : "65468167132164096",
  "in_reply_to_user_id" : 10647472,
  "text" : "@adambair https:\/\/img.skitch.com\/20110503-rum4ra5cx267t2kmmu716d8p4g.gif",
  "id" : 65468167132164096,
  "in_reply_to_status_id" : 65467648053477376,
  "created_at" : "2011-05-03 17:30:02 +0000",
  "in_reply_to_screen_name" : "adambair",
  "in_reply_to_user_id_str" : "10647472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65467260499800064",
  "text" : "First one to say \"WAHHH HAVE YOU USED SCSS\" gets an angry image.",
  "id" : 65467260499800064,
  "created_at" : "2011-05-03 17:26:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65467100436762624",
  "text" : "I fucking hate CSS.",
  "id" : 65467100436762624,
  "created_at" : "2011-05-03 17:25:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Davis",
      "screen_name" : "edavis10",
      "indices" : [ 0, 9 ],
      "id_str" : "9695352",
      "id" : 9695352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65438527730626562",
  "geo" : { },
  "id_str" : "65439510841917441",
  "in_reply_to_user_id" : 9695352,
  "text" : "@edavis10 i disagree, thats a common pattern to accept custom arguments for many tools.",
  "id" : 65439510841917441,
  "in_reply_to_status_id" : 65438527730626562,
  "created_at" : "2011-05-03 15:36:09 +0000",
  "in_reply_to_screen_name" : "edavis10",
  "in_reply_to_user_id_str" : "9695352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Chiang",
      "screen_name" : "thinkerbot",
      "indices" : [ 0, 11 ],
      "id_str" : "15038046",
      "id" : 15038046
    }, {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 12, 18 ],
      "id_str" : "9885102",
      "id" : 9885102
    }, {
      "name" : "Eric Davis",
      "screen_name" : "edavis10",
      "indices" : [ 46, 55 ],
      "id_str" : "9695352",
      "id" : 9695352
    }, {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 56, 66 ],
      "id_str" : "15243796",
      "id" : 15243796
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 67, 75 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65436740332175360",
  "geo" : { },
  "id_str" : "65437648503848960",
  "in_reply_to_user_id" : 15038046,
  "text" : "@thinkerbot @drnic this is AWESOME. +1!!! \/cc @edavis10 @ngauthier @sikachu",
  "id" : 65437648503848960,
  "in_reply_to_status_id" : 65436740332175360,
  "created_at" : "2011-05-03 15:28:45 +0000",
  "in_reply_to_screen_name" : "thinkerbot",
  "in_reply_to_user_id_str" : "15038046",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65431397506088960",
  "geo" : { },
  "id_str" : "65432239588122624",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic the current ways of doing args suck. i dont want to perpetuate it any further",
  "id" : 65432239588122624,
  "in_reply_to_status_id" : 65431397506088960,
  "created_at" : "2011-05-03 15:07:16 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65430778342948864",
  "geo" : { },
  "id_str" : "65432119362600960",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu I have no complaints about the DSL, would love to hear your opinion on it. it's just command line args that suck.",
  "id" : 65432119362600960,
  "in_reply_to_status_id" : 65430778342948864,
  "created_at" : "2011-05-03 15:06:47 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65430131962953728",
  "geo" : { },
  "id_str" : "65430514584141824",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier what is it for then? I thought it was for automating commands in every ruby project, ever.",
  "id" : 65430514584141824,
  "in_reply_to_status_id" : 65430131962953728,
  "created_at" : "2011-05-03 15:00:24 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Hariharan",
      "screen_name" : "hkarthik",
      "indices" : [ 0, 9 ],
      "id_str" : "4514261",
      "id" : 4514261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65428199022141440",
  "geo" : { },
  "id_str" : "65428429616586752",
  "in_reply_to_user_id" : 4514261,
  "text" : "@hkarthik yes, i've played with Thor and it's awesome for command line apps...not the same use case as Rake.",
  "id" : 65428429616586752,
  "in_reply_to_status_id" : 65428199022141440,
  "created_at" : "2011-05-03 14:52:07 +0000",
  "in_reply_to_screen_name" : "hkarthik",
  "in_reply_to_user_id_str" : "4514261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "h\u00EEp\u00DFt\u00EBr b\u00E5b\u00FF",
      "screen_name" : "reagent",
      "indices" : [ 0, 8 ],
      "id_str" : "7430672",
      "id" : 7430672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65426478841593857",
  "geo" : { },
  "id_str" : "65427161351327744",
  "in_reply_to_user_id" : 7430672,
  "text" : "@reagent that pattern is terrible, IMO. brackets in zsh need to be escaped :(",
  "id" : 65427161351327744,
  "in_reply_to_status_id" : 65426478841593857,
  "created_at" : "2011-05-03 14:47:05 +0000",
  "in_reply_to_screen_name" : "reagent",
  "in_reply_to_user_id_str" : "7430672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65426310763266048",
  "text" : "Why is it that after all of these years, passing command line arguments to Rake is still terrible?",
  "id" : 65426310763266048,
  "created_at" : "2011-05-03 14:43:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alancfrancis",
      "screen_name" : "alancfrancis",
      "indices" : [ 0, 13 ],
      "id_str" : "2663864833",
      "id" : 2663864833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65425204280696832",
  "text" : "@alancfrancis http:\/\/book.git-scm.com\/4_rebasing.html http:\/\/gitready.com\/intermediate\/2009\/01\/31\/intro-to-rebase.html",
  "id" : 65425204280696832,
  "created_at" : "2011-05-03 14:39:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Chelimsky",
      "screen_name" : "dchelimsky",
      "indices" : [ 0, 11 ],
      "id_str" : "14107142",
      "id" : 14107142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65420825800609792",
  "geo" : { },
  "id_str" : "65421479101210625",
  "in_reply_to_user_id" : 14107142,
  "text" : "@dchelimsky best guess works fine.",
  "id" : 65421479101210625,
  "in_reply_to_status_id" : 65420825800609792,
  "created_at" : "2011-05-03 14:24:30 +0000",
  "in_reply_to_screen_name" : "dchelimsky",
  "in_reply_to_user_id_str" : "14107142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Chelimsky",
      "screen_name" : "dchelimsky",
      "indices" : [ 0, 11 ],
      "id_str" : "14107142",
      "id" : 14107142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65419192404426752",
  "geo" : { },
  "id_str" : "65420198269820928",
  "in_reply_to_user_id" : 14107142,
  "text" : "@dchelimsky Thanks. It should be easy to figure out what old links point to new ones and hook up redirects....just time consuming ;)",
  "id" : 65420198269820928,
  "in_reply_to_status_id" : 65419192404426752,
  "created_at" : "2011-05-03 14:19:25 +0000",
  "in_reply_to_screen_name" : "dchelimsky",
  "in_reply_to_user_id_str" : "14107142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65418852569321472",
  "geo" : { },
  "id_str" : "65419749865164800",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking I would love to comment on your post but I can't. WordPress sucks, you should install Disqus.",
  "id" : 65419749865164800,
  "in_reply_to_status_id" : 65418852569321472,
  "created_at" : "2011-05-03 14:17:38 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Chelimsky",
      "screen_name" : "dchelimsky",
      "indices" : [ 0, 11 ],
      "id_str" : "14107142",
      "id" : 14107142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65414340559388673",
  "geo" : { },
  "id_str" : "65415031206060032",
  "in_reply_to_user_id" : 14107142,
  "text" : "@dchelimsky what about all the books that have been published with URLs in them? :)",
  "id" : 65415031206060032,
  "in_reply_to_status_id" : 65414340559388673,
  "created_at" : "2011-05-03 13:58:53 +0000",
  "in_reply_to_screen_name" : "dchelimsky",
  "in_reply_to_user_id_str" : "14107142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Chelimsky",
      "screen_name" : "dchelimsky",
      "indices" : [ 0, 11 ],
      "id_str" : "14107142",
      "id" : 14107142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65414340559388673",
  "geo" : { },
  "id_str" : "65414950113386496",
  "in_reply_to_user_id" : 14107142,
  "text" : "@dchelimsky that's not a bummer, it's a huge disservice to the rspec community and anyone that's written a blog post\/linked to the site",
  "id" : 65414950113386496,
  "in_reply_to_status_id" : 65414340559388673,
  "created_at" : "2011-05-03 13:58:34 +0000",
  "in_reply_to_screen_name" : "dchelimsky",
  "in_reply_to_user_id_str" : "14107142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Chelimsky",
      "screen_name" : "dchelimsky",
      "indices" : [ 0, 11 ],
      "id_str" : "14107142",
      "id" : 14107142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65254624315179008",
  "geo" : { },
  "id_str" : "65413429908873216",
  "in_reply_to_user_id" : 14107142,
  "text" : "@dchelimsky hurray! you broke all of the links anyone has ever made to rspec.info though :( just google for \"rspec\"",
  "id" : 65413429908873216,
  "in_reply_to_status_id" : 65254624315179008,
  "created_at" : "2011-05-03 13:52:31 +0000",
  "in_reply_to_screen_name" : "dchelimsky",
  "in_reply_to_user_id_str" : "14107142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65219547577327616",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt apparently I can't dm you, but some are working hard to make it better for others. Would love to hear your opinion.",
  "id" : 65219547577327616,
  "created_at" : "2011-05-03 01:02:06 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "github",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65218835015417856",
  "text" : "Awesome time at the #github drinkup! Someday I'll have a serious git discussion at one of those.",
  "id" : 65218835015417856,
  "created_at" : "2011-05-03 00:59:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "github",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3725768899, -71.1193057895 ]
  },
  "id_str" : "65192000852459520",
  "text" : "#github drankup! @ John Harvard's Brew House http:\/\/gowal.la\/c\/48Xow",
  "id" : 65192000852459520,
  "created_at" : "2011-05-02 23:12:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65084600375984128",
  "text" : "Why isn't there a Portal deathmatch mode? Or heck, even HL2DM with portals.",
  "id" : 65084600375984128,
  "created_at" : "2011-05-02 16:05:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64898418182594560",
  "text" : "Well...now what?",
  "id" : 64898418182594560,
  "created_at" : "2011-05-02 03:46:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 0, 8 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64892466314231811",
  "geo" : { },
  "id_str" : "64892557364170753",
  "in_reply_to_user_id" : 15029296,
  "text" : "@zedshaw http:\/\/www.youtube.com\/user\/JulienBrasart#p\/u\/7\/eXcfe9TENqU too...damn.",
  "id" : 64892557364170753,
  "in_reply_to_status_id" : 64892466314231811,
  "created_at" : "2011-05-02 03:22:45 +0000",
  "in_reply_to_screen_name" : "zedshaw",
  "in_reply_to_user_id_str" : "15029296",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 0, 8 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64890003058204672",
  "geo" : { },
  "id_str" : "64891935126601729",
  "in_reply_to_user_id" : 15029296,
  "text" : "@zedshaw his benny hill is SICK",
  "id" : 64891935126601729,
  "in_reply_to_status_id" : 64890003058204672,
  "created_at" : "2011-05-02 03:20:17 +0000",
  "in_reply_to_screen_name" : "zedshaw",
  "in_reply_to_user_id_str" : "15029296",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64887697721921537",
  "text" : "Twitter search for \"BOOM HEADSHOT\" right now is priceless.",
  "id" : 64887697721921537,
  "created_at" : "2011-05-02 03:03:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64883489807413248",
  "geo" : { },
  "id_str" : "64884775973949441",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella He hasn't even come on the air yet!!",
  "id" : 64884775973949441,
  "in_reply_to_status_id" : 64883489807413248,
  "created_at" : "2011-05-02 02:51:50 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64884664682291200",
  "text" : "I haven't favorited so many tweets in a long time. Keep it coming, this is fantastic.",
  "id" : 64884664682291200,
  "created_at" : "2011-05-02 02:51:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64884072538849280",
  "text" : "Fired up https:\/\/github.com\/intridea\/tweetstream to watch all of the Obama tweets...I wish I had some interesting stats to pull out here",
  "id" : 64884072538849280,
  "created_at" : "2011-05-02 02:49:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64882584097783808",
  "text" : "BREAKING NEWS: President Obama just wants to say have a wonderful night and read you a bedtime story.",
  "id" : 64882584097783808,
  "created_at" : "2011-05-02 02:43:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64876079021703168",
  "geo" : { },
  "id_str" : "64876773011243008",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit don't lie to me, you loved every second of it",
  "id" : 64876773011243008,
  "in_reply_to_status_id" : 64876079021703168,
  "created_at" : "2011-05-02 02:20:02 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64875120468041728",
  "text" : "Well, that's all I need to learn about the Royal Wedding. http:\/\/www.youtube.com\/watch?v=HQb6jpPbCz0",
  "id" : 64875120468041728,
  "created_at" : "2011-05-02 02:13:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64744762187591681",
  "text" : "Current http:\/\/yfrog.com\/gydpcggj",
  "id" : 64744762187591681,
  "created_at" : "2011-05-01 17:35:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "config",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64687274759159808",
  "geo" : { },
  "id_str" : "64690155776249858",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan #config.paths.public = \"foo\" in config\/application.rb",
  "id" : 64690155776249858,
  "in_reply_to_status_id" : 64687274759159808,
  "created_at" : "2011-05-01 13:58:29 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
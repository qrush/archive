Grailbird.data.tweets_2010_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 11, 21 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 41, 51 ],
      "id_str" : "14736332",
      "id" : 14736332
    }, {
      "name" : "Jeff Smick",
      "screen_name" : "sprsquish",
      "indices" : [ 76, 86 ],
      "id_str" : "2296675008",
      "id" : 2296675008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9814260098",
  "text" : "Late night @gemcutter SQL debugging with @jtrupiano was successful. I blame @sprsquish for this.",
  "id" : 9814260098,
  "created_at" : "2010-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9826405791",
  "geo" : { },
  "id_str" : "9826474186",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey learning the visual modes with vim make everything easier. http:\/\/www.viemu.com\/a_vi_vim_graphical_cheat_sheet_tutorial.html",
  "id" : 9826474186,
  "in_reply_to_status_id" : 9826405791,
  "created_at" : "2010-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9826593561",
  "geo" : { },
  "id_str" : "9827266209",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey I mostly just learned by stopping myself when I did an action 2-3 times and learning a faster way.",
  "id" : 9827266209,
  "in_reply_to_status_id" : 9826593561,
  "created_at" : "2010-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 0, 9 ],
      "id_str" : "616163",
      "id" : 616163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9830998885",
  "geo" : { },
  "id_str" : "9831518295",
  "in_reply_to_user_id" : 616163,
  "text" : "@joshpeek I'm all confused...why would I use that over Jeweler?",
  "id" : 9831518295,
  "in_reply_to_status_id" : 9830998885,
  "created_at" : "2010-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshpeek",
  "in_reply_to_user_id_str" : "616163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9842936711",
  "text" : "2 A's, 2 B's. How did that even happen?",
  "id" : 9842936711,
  "created_at" : "2010-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9843017523",
  "geo" : { },
  "id_str" : "9843194021",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv I do have one of those as well that I can bring into the office once I'm back.",
  "id" : 9843194021,
  "in_reply_to_status_id" : 9843017523,
  "created_at" : "2010-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9846180403",
  "text" : "It's the Day After Tomorrow! WE DIDN'T LISTEN",
  "id" : 9846180403,
  "created_at" : "2010-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    }, {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 12, 23 ],
      "id_str" : "14086000",
      "id" : 14086000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9800191981",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser @timocratic how would that even be accomplished? Education\/spreading the word re: semver.org would work too.",
  "id" : 9800191981,
  "created_at" : "2010-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9807185470",
  "text" : "I think the closing ceremony is actually a rave with the camera flashes, just needs a good beat. UNCE UNCE UNCE",
  "id" : 9807185470,
  "created_at" : "2010-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9812211298",
  "text" : "gem yank prerelease is out, would certainly appreciate any testing\/feedback of it. http:\/\/is.gd\/9qEk0",
  "id" : 9812211298,
  "created_at" : "2010-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Smick",
      "screen_name" : "sprsquish",
      "indices" : [ 0, 10 ],
      "id_str" : "2296675008",
      "id" : 2296675008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9812294305",
  "geo" : { },
  "id_str" : "9812515769",
  "in_reply_to_user_id" : 3732061,
  "text" : "@sprsquish yes it did, looking into it now.",
  "id" : 9812515769,
  "in_reply_to_status_id" : 9812294305,
  "created_at" : "2010-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrsprsquish",
  "in_reply_to_user_id_str" : "3732061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vladimir Andrijevik",
      "screen_name" : "vandrijevik",
      "indices" : [ 0, 12 ],
      "id_str" : "14407694",
      "id" : 14407694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9813101839",
  "geo" : { },
  "id_str" : "9813430026",
  "in_reply_to_user_id" : 14407694,
  "text" : "@vandrijevik i think the idea is that would ideally never happen. the download link is there just in case",
  "id" : 9813430026,
  "in_reply_to_status_id" : 9813101839,
  "created_at" : "2010-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "vandrijevik",
  "in_reply_to_user_id_str" : "14407694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "JoshClayton",
      "indices" : [ 0, 12 ],
      "id_str" : "18761603",
      "id" : 18761603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9762117262",
  "geo" : { },
  "id_str" : "9762319495",
  "in_reply_to_user_id" : 18761603,
  "text" : "@JoshClayton gah, deleting that tweet until I get it right. You crazy Claytons.",
  "id" : 9762319495,
  "in_reply_to_status_id" : 9762117262,
  "created_at" : "2010-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "JoshClayton",
  "in_reply_to_user_id_str" : "18761603",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9762390055",
  "text" : "I give up, I can't drunk while I tweet.",
  "id" : 9762390055,
  "created_at" : "2010-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9777605708",
  "text" : "Video: The Lion King Fortress 2 http:\/\/tumblr.com\/x176wmg4s",
  "id" : 9777605708,
  "created_at" : "2010-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9779552298",
  "text" : "So many awesome projects for GitHub Rebase this week, hard to choose between them all.",
  "id" : 9779552298,
  "created_at" : "2010-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9785143732",
  "text" : "I'm not sure what's more boring: golf or cross-country distance skiing. When does hockey start?",
  "id" : 9785143732,
  "created_at" : "2010-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9789393774",
  "text" : "LETS GO SABRES...er......USA!",
  "id" : 9789393774,
  "created_at" : "2010-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "indices" : [ 3, 11 ],
      "id_str" : "713263",
      "id" : 713263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9790542293",
  "text" : "RT @defunkt: `gist` is now RubyGem, has a manpage, grows up: http:\/\/ozmm.org\/posts\/gist_1.html",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "9790494863",
    "text" : "`gist` is now RubyGem, has a manpage, grows up: http:\/\/ozmm.org\/posts\/gist_1.html",
    "id" : 9790494863,
    "created_at" : "2010-02-28 20:31:44 +0000",
    "user" : {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "protected" : false,
      "id_str" : "713263",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1245949369\/b8dbb1987e8e5318584865f880036796_normal.jpeg",
      "id" : 713263,
      "verified" : false
    }
  },
  "id" : 9790542293,
  "created_at" : "2010-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9790842071",
  "text" : "FFFFFFFFFFFFUUUUUUU",
  "id" : 9790842071,
  "created_at" : "2010-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 3, 19 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9795197702",
  "text" : "RT @RobotDeathSquad: I'm pretty sure all of Canada just said \"Shit, eh hosers?\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "9795098092",
    "text" : "I'm pretty sure all of Canada just said \"Shit, eh hosers?\"",
    "id" : 9795098092,
    "created_at" : "2010-02-28 22:29:14 +0000",
    "user" : {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "protected" : false,
      "id_str" : "637113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000041039702\/5b4cc07b2005a680410bbf6c9a34c7ef_normal.jpeg",
      "id" : 637113,
      "verified" : false
    }
  },
  "id" : 9795197702,
  "created_at" : "2010-02-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hank",
      "screen_name" : "Hankers",
      "indices" : [ 0, 8 ],
      "id_str" : "17735910",
      "id" : 17735910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9796565826",
  "geo" : { },
  "id_str" : "9796805400",
  "in_reply_to_user_id" : 17735910,
  "text" : "@Hankers twas a good game, I think Miller and the Sabres deserve a visit with Lord Stanley for that game",
  "id" : 9796805400,
  "in_reply_to_status_id" : 9796565826,
  "created_at" : "2010-02-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Hankers",
  "in_reply_to_user_id_str" : "17735910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Green",
      "screen_name" : "hotgazpacho",
      "indices" : [ 0, 12 ],
      "id_str" : "10687942",
      "id" : 10687942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9710159460",
  "geo" : { },
  "id_str" : "9710402790",
  "in_reply_to_user_id" : 10687942,
  "text" : "@hotgazpacho but...jeweler helps you use gemcutter. http:\/\/help.rubygems.org\/faqs\/gemcutter\/publishing-your-own-rubygem",
  "id" : 9710402790,
  "in_reply_to_status_id" : 9710159460,
  "created_at" : "2010-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "hotgazpacho",
  "in_reply_to_user_id_str" : "10687942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Dowell",
      "screen_name" : "CerebroJD",
      "indices" : [ 0, 10 ],
      "id_str" : "5744302",
      "id" : 5744302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9711888285",
  "geo" : { },
  "id_str" : "9711967995",
  "in_reply_to_user_id" : 5744302,
  "text" : "@CerebroJD Watching it here too! I'm hoping Canada wins, USA vs Canada for the final will be crazy.",
  "id" : 9711967995,
  "in_reply_to_status_id" : 9711888285,
  "created_at" : "2010-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "CerebroJD",
  "in_reply_to_user_id_str" : "5744302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9739206014",
  "text" : "Apartment hunting in Boston. Someday I'll learn to use Craigslist.",
  "id" : 9739206014,
  "created_at" : "2010-02-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Kahn",
      "screen_name" : "AlexanderKahn",
      "indices" : [ 0, 14 ],
      "id_str" : "402592582",
      "id" : 402592582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9739861149",
  "geo" : { },
  "id_str" : "9739917990",
  "in_reply_to_user_id" : 15068402,
  "text" : "@alexanderkahn RIT does quarters, we're on break",
  "id" : 9739917990,
  "in_reply_to_status_id" : 9739861149,
  "created_at" : "2010-02-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "akahn",
  "in_reply_to_user_id_str" : "15068402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 0, 9 ],
      "id_str" : "616163",
      "id" : 616163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9652889109",
  "geo" : { },
  "id_str" : "9664499478",
  "in_reply_to_user_id" : 616163,
  "text" : "@joshpeek yeah, open up a request on http:\/\/help.rubygems.org ...gem yank is coming soon!",
  "id" : 9664499478,
  "in_reply_to_status_id" : 9652889109,
  "created_at" : "2010-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshpeek",
  "in_reply_to_user_id_str" : "616163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 31, 38 ],
      "id_str" : "3286561",
      "id" : 3286561
    }, {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 43, 54 ],
      "id_str" : "14086000",
      "id" : 14086000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9664571839",
  "text" : "First night out in Boston with @tsaleh and @timocratic. Somehow made it back alive.",
  "id" : 9664571839,
  "created_at" : "2010-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9684770906",
  "text" : "JRuby really, really, REALLY hates large FileLists.",
  "id" : 9684770906,
  "created_at" : "2010-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Sieger [\u65E5\u7A7A]",
      "screen_name" : "nicksieger",
      "indices" : [ 0, 11 ],
      "id_str" : "5504482",
      "id" : 5504482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9685416410",
  "geo" : { },
  "id_str" : "9686562950",
  "in_reply_to_user_id" : 5504482,
  "text" : "@nicksieger yes, actually using Warbler and had to dig into the codebase. It just doesn't handle hundreds of files + symlinks well.",
  "id" : 9686562950,
  "in_reply_to_status_id" : 9685416410,
  "created_at" : "2010-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "nicksieger",
  "in_reply_to_user_id_str" : "5504482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Wilson",
      "screen_name" : "unixdaemon",
      "indices" : [ 0, 11 ],
      "id_str" : "16155205",
      "id" : 16155205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9682513380",
  "geo" : { },
  "id_str" : "9687261465",
  "in_reply_to_user_id" : 16155205,
  "text" : "@unixdaemon what exactly did you get 'bogged down' with?",
  "id" : 9687261465,
  "in_reply_to_status_id" : 9682513380,
  "created_at" : "2010-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "unixdaemon",
  "in_reply_to_user_id_str" : "16155205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9599644109",
  "text" : "Packing feverishly for a spring break trip to Boston! Going to ride in front of the oncoming storm.",
  "id" : 9599644109,
  "created_at" : "2010-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9644074022",
  "text" : "Arrived in Boston ahead of the storm, but ended up in one anyway.",
  "id" : 9644074022,
  "created_at" : "2010-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "genexerjv",
      "screen_name" : "genexerjv",
      "indices" : [ 0, 10 ],
      "id_str" : "2547334176",
      "id" : 2547334176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9645351146",
  "geo" : { },
  "id_str" : "9645804028",
  "in_reply_to_user_id" : 15950889,
  "text" : "@genexerjv are you using a really old version of rubygems?",
  "id" : 9645804028,
  "in_reply_to_status_id" : 9645351146,
  "created_at" : "2010-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "genfixie",
  "in_reply_to_user_id_str" : "15950889",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 3, 10 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 40, 49 ],
      "id_str" : "729936824",
      "id" : 729936824
    }, {
      "name" : "Kyle Fiedler",
      "screen_name" : "kylefiedler",
      "indices" : [ 52, 64 ],
      "id_str" : "14838050",
      "id" : 14838050
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 73, 84 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9647020931",
  "text" : "RT @Croaky: word's out. excited to have @hgimenez & @kylefiedler joining @thoughtbot soon. welcome aboard, fellas!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "hiolanda gimenez",
        "screen_name" : "HGimenez",
        "indices" : [ 28, 37 ],
        "id_str" : "729936824",
        "id" : 729936824
      }, {
        "name" : "Kyle Fiedler",
        "screen_name" : "kylefiedler",
        "indices" : [ 40, 52 ],
        "id_str" : "14838050",
        "id" : 14838050
      }, {
        "name" : "thoughtbot",
        "screen_name" : "thoughtbot",
        "indices" : [ 61, 72 ],
        "id_str" : "14114392",
        "id" : 14114392
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "9646412687",
    "text" : "word's out. excited to have @hgimenez & @kylefiedler joining @thoughtbot soon. welcome aboard, fellas!",
    "id" : 9646412687,
    "created_at" : "2010-02-25 22:26:40 +0000",
    "user" : {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "protected" : false,
      "id_str" : "787595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568676101967196160\/nP3jFRbr_normal.jpeg",
      "id" : 787595,
      "verified" : false
    }
  },
  "id" : 9647020931,
  "created_at" : "2010-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "genexerjv",
      "screen_name" : "genexerjv",
      "indices" : [ 0, 10 ],
      "id_str" : "2547334176",
      "id" : 2547334176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9647950821",
  "geo" : { },
  "id_str" : "9648118308",
  "in_reply_to_user_id" : 15950889,
  "text" : "@genexerjv just run gem update --system, you should be all set. if not, http:\/\/rubygems.org\/pages\/download",
  "id" : 9648118308,
  "in_reply_to_status_id" : 9647950821,
  "created_at" : "2010-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "genfixie",
  "in_reply_to_user_id_str" : "15950889",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9648372365",
  "text" : "And this is why @ablissfulgal and I left for Boston a day early. http:\/\/is.gd\/9bTtC",
  "id" : 9648372365,
  "created_at" : "2010-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9649054528",
  "geo" : { },
  "id_str" : "9649100083",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil there's a two letter word for stuff like this, the monadics need to learn to use it",
  "id" : 9649100083,
  "in_reply_to_status_id" : 9649054528,
  "created_at" : "2010-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Weiss",
      "screen_name" : "brandon_weiss",
      "indices" : [ 0, 14 ],
      "id_str" : "72153",
      "id" : 72153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9549523427",
  "geo" : { },
  "id_str" : "9549912039",
  "in_reply_to_user_id" : 72153,
  "text" : "@brandon_weiss gemcutter.org will live on, especially once we have gem subdomains working. weiss.gemcutter.org, etc :)",
  "id" : 9549912039,
  "in_reply_to_status_id" : 9549523427,
  "created_at" : "2010-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "brandon_weiss",
  "in_reply_to_user_id_str" : "72153",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9550274469",
  "text" : "Photo: Knuth doing some real hacking http:\/\/tumblr.com\/x176quc8b",
  "id" : 9550274469,
  "created_at" : "2010-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9582217595",
  "text" : "Force mercurial to page output, like a good scm should: http:\/\/mercurial.selenic.com\/wiki\/PagerExtension",
  "id" : 9582217595,
  "created_at" : "2010-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 91, 101 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9582355345",
  "text" : "Oh, and use modern diffs too. Why isn't this crap on by default? http:\/\/is.gd\/95t4k Thanks @stevelosh.",
  "id" : 9582355345,
  "created_at" : "2010-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia West",
      "screen_name" : "juliamae",
      "indices" : [ 0, 9 ],
      "id_str" : "6354852",
      "id" : 6354852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9585907472",
  "geo" : { },
  "id_str" : "9587886577",
  "in_reply_to_user_id" : 6354852,
  "text" : "@juliamae we didn't force any changes. main problem was that rubygems stopped requiring stringio and yaml, libs depended on that assumption",
  "id" : 9587886577,
  "in_reply_to_status_id" : 9585907472,
  "created_at" : "2010-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "juliamae",
  "in_reply_to_user_id_str" : "6354852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia West",
      "screen_name" : "juliamae",
      "indices" : [ 0, 9 ],
      "id_str" : "6354852",
      "id" : 6354852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9585907472",
  "geo" : { },
  "id_str" : "9587925979",
  "in_reply_to_user_id" : 6354852,
  "text" : "@juliamae the prerelease was out for weeks before, didn't hear a peep about this. going to really call in the troops for the next release",
  "id" : 9587925979,
  "in_reply_to_status_id" : 9585907472,
  "created_at" : "2010-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "juliamae",
  "in_reply_to_user_id_str" : "6354852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc-Andr\u00E9 Cournoyer",
      "screen_name" : "macournoyer",
      "indices" : [ 56, 68 ],
      "id_str" : "5915562",
      "id" : 5915562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9592277371",
  "text" : "http:\/\/www.fucking-windows.com\/ best website ever? (via @macournoyer)",
  "id" : 9592277371,
  "created_at" : "2010-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9593838274",
  "text" : "And today, Nick finally learns about String#to_xs. These to_* methods deserve a blog post.",
  "id" : 9593838274,
  "created_at" : "2010-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9594381042",
  "text" : "Video: \u201CThe idea was to play with pitch and color, but you know what\u2019s more fun? YELLING AT EVERYTHING\u201D http:\/\/tumblr.com\/x176rxio2",
  "id" : 9594381042,
  "created_at" : "2010-02-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    }, {
      "name" : "Mike Rubits (sponge)",
      "screen_name" : "mikerubits",
      "indices" : [ 14, 25 ],
      "id_str" : "18455656",
      "id" : 18455656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9598451139",
  "geo" : { },
  "id_str" : "9599370246",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm @mikerubits i highly recommend the Rails Way. I have it if you want it, after break",
  "id" : 9599370246,
  "in_reply_to_status_id" : 9598451139,
  "created_at" : "2010-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9501531537",
  "text" : "Video: Cartman interviewed on NPR. http:\/\/tumblr.com\/x176pmin1",
  "id" : 9501531537,
  "created_at" : "2010-02-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Walsh",
      "screen_name" : "davidwalshblog",
      "indices" : [ 0, 15 ],
      "id_str" : "15759583",
      "id" : 15759583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9512944103",
  "geo" : { },
  "id_str" : "9513076820",
  "in_reply_to_user_id" : 15759583,
  "text" : "@davidwalshblog that doesn't make much sense :( could you paste the commands your running and the output at http:\/\/help.rubygems.org ?",
  "id" : 9513076820,
  "in_reply_to_status_id" : 9512944103,
  "created_at" : "2010-02-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "davidwalshblog",
  "in_reply_to_user_id_str" : "15759583",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Reynolds",
      "screen_name" : "scottcreynolds",
      "indices" : [ 0, 15 ],
      "id_str" : "441985676",
      "id" : 441985676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9528485749",
  "text" : "@scottcreynolds that's the second report i've heard of that...can you paste the output\/commands at http:\/\/help.rubygems.org ? :(",
  "id" : 9528485749,
  "created_at" : "2010-02-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9542304732",
  "text" : "DONE with exams. Dear lord I hope I pass.",
  "id" : 9542304732,
  "created_at" : "2010-02-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Huckstep",
      "screen_name" : "darkhelmetlive",
      "indices" : [ 0, 15 ],
      "id_str" : "19567986",
      "id" : 19567986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9542379469",
  "geo" : { },
  "id_str" : "9543050122",
  "in_reply_to_user_id" : 19567986,
  "text" : "@darkhelmetlive no, we're on quarters, so winter quarter is now over. spring quarter coming up! :(",
  "id" : 9543050122,
  "in_reply_to_status_id" : 9542379469,
  "created_at" : "2010-02-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "darkhelmetlive",
  "in_reply_to_user_id_str" : "19567986",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9545487422",
  "geo" : { },
  "id_str" : "9545845957",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety yes, it used to be much, much worse",
  "id" : 9545845957,
  "in_reply_to_status_id" : 9545487422,
  "created_at" : "2010-02-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9546187138",
  "geo" : { },
  "id_str" : "9546347543",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety the first prerelease was out on the 9th. There's just not enough interest in testing it out. Would love to make the process better",
  "id" : 9546347543,
  "in_reply_to_status_id" : 9546187138,
  "created_at" : "2010-02-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Mayer",
      "screen_name" : "danmayer",
      "indices" : [ 0, 9 ],
      "id_str" : "14630648",
      "id" : 14630648
    }, {
      "name" : "nap.tld, ltd.",
      "screen_name" : "zapnap",
      "indices" : [ 55, 62 ],
      "id_str" : "1566201",
      "id" : 1566201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9545402336",
  "geo" : { },
  "id_str" : "9546728533",
  "in_reply_to_user_id" : 14630648,
  "text" : "@danmayer nice! now for rdoc.info to catch up. *cough* @zapnap @ jeffrafter",
  "id" : 9546728533,
  "in_reply_to_status_id" : 9545402336,
  "created_at" : "2010-02-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "danmayer",
  "in_reply_to_user_id_str" : "14630648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9495503530",
  "text" : "Video: Queen, Live at the Bowl: The Hero \/ We Will Rock You http:\/\/tumblr.com\/x176pgpin",
  "id" : 9495503530,
  "created_at" : "2010-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9451422973",
  "text" : "Photo: \u201CI had that Javatar dream again last night\u201D http:\/\/tumblr.com\/x176oc331",
  "id" : 9451422973,
  "created_at" : "2010-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 0, 11 ],
      "id_str" : "4243",
      "id" : 4243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9453426601",
  "geo" : { },
  "id_str" : "9453488787",
  "in_reply_to_user_id" : 4243,
  "text" : "@jnunemaker aww thanks. I can't wait to get it to Rails 3 and use ActiveModel.",
  "id" : 9453488787,
  "in_reply_to_status_id" : 9453426601,
  "created_at" : "2010-02-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "jnunemaker",
  "in_reply_to_user_id_str" : "4243",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 0, 11 ],
      "id_str" : "4243",
      "id" : 4243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9453649335",
  "geo" : { },
  "id_str" : "9454253249",
  "in_reply_to_user_id" : 4243,
  "text" : "@jnunemaker yeah definitely use a namespace a la \/api\/v1 from the start, heck, even make it a separate rack app. http:\/\/is.gd\/8TJdq",
  "id" : 9454253249,
  "in_reply_to_status_id" : 9453649335,
  "created_at" : "2010-02-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "jnunemaker",
  "in_reply_to_user_id_str" : "4243",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9457723865",
  "text" : "Video: dancroak: http:\/\/tumblr.com\/x176oj0kh",
  "id" : 9457723865,
  "created_at" : "2010-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen van Meeuwen",
      "screen_name" : "kanarip",
      "indices" : [ 0, 8 ],
      "id_str" : "21991789",
      "id" : 21991789
    }, {
      "name" : "Julian Simpson",
      "screen_name" : "builddoctor",
      "indices" : [ 9, 21 ],
      "id_str" : "60339361",
      "id" : 60339361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9469599611",
  "geo" : { },
  "id_str" : "9477253585",
  "in_reply_to_user_id" : 21991789,
  "text" : "@kanarip @builddoctor you don't need the gemcutter gem to push gems anymore as of 0.4.0, it's baked in. what's the issue with upgrading?",
  "id" : 9477253585,
  "in_reply_to_status_id" : 9469599611,
  "created_at" : "2010-02-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "kanarip",
  "in_reply_to_user_id_str" : "21991789",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Simpson",
      "screen_name" : "builddoctor",
      "indices" : [ 0, 12 ],
      "id_str" : "60339361",
      "id" : 60339361
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 45, 53 ],
      "id_str" : "670283",
      "id" : 670283
    }, {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 58, 68 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9478812940",
  "geo" : { },
  "id_str" : "9479305443",
  "in_reply_to_user_id" : 60339361,
  "text" : "@builddoctor yeah, been discussing that with @drbrain and @jbarnette, hoping to fix it today (right?)",
  "id" : 9479305443,
  "in_reply_to_status_id" : 9478812940,
  "created_at" : "2010-02-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "builddoctor",
  "in_reply_to_user_id_str" : "60339361",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oduntan abiodun",
      "screen_name" : "Idokan",
      "indices" : [ 0, 7 ],
      "id_str" : "466589277",
      "id" : 466589277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9489907072",
  "text" : "@idokan everything's working here afaik..could you gist the commands\/output you're seeing with 'gem env' ? http:\/\/gist.github.com",
  "id" : 9489907072,
  "created_at" : "2010-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oduntan abiodun",
      "screen_name" : "Idokan",
      "indices" : [ 0, 7 ],
      "id_str" : "466589277",
      "id" : 466589277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9490093308",
  "text" : "@idokan what commands are you running? that would help (output too)",
  "id" : 9490093308,
  "created_at" : "2010-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oduntan abiodun",
      "screen_name" : "Idokan",
      "indices" : [ 0, 7 ],
      "id_str" : "466589277",
      "id" : 466589277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9490224207",
  "text" : "@idokan i think this is a rubygems bug, seeing another report of this already... http:\/\/is.gd\/8WXnf",
  "id" : 9490224207,
  "created_at" : "2010-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 3, 13 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9492993616",
  "text" : "RT @jbarnette: Maintainers of older RubyGems, make sure your development deps (like Hoe and RubyForge) are really DEVELOPMENT deps. 1.3. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "9492905261",
    "text" : "Maintainers of older RubyGems, make sure your development deps (like Hoe and RubyForge) are really DEVELOPMENT deps. 1.3.6 will punish you.",
    "id" : 9492905261,
    "created_at" : "2010-02-22 20:56:33 +0000",
    "user" : {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "protected" : false,
      "id_str" : "10453902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482193494002642944\/J3ZE2OBm_normal.jpeg",
      "id" : 10453902,
      "verified" : false
    }
  },
  "id" : 9492993616,
  "created_at" : "2010-02-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9410973415",
  "text" : "RT @gemcutter: RubyGems.org move is now complete! Woot! http:\/\/is.gd\/8PL9J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "9410828128",
    "text" : "RubyGems.org move is now complete! Woot! http:\/\/is.gd\/8PL9J",
    "id" : 9410828128,
    "created_at" : "2010-02-21 02:47:43 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 9410973415,
  "created_at" : "2010-02-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9412899930",
  "geo" : { },
  "id_str" : "9413220847",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick that's awesome. Watching it at the bar here.",
  "id" : 9413220847,
  "in_reply_to_status_id" : 9412899930,
  "created_at" : "2010-02-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "amy bonner",
      "screen_name" : "cake_face",
      "indices" : [ 14, 24 ],
      "id_str" : "15018484",
      "id" : 15018484
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 76, 87 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9413255899",
  "text" : "I just ousted @cake_face as the mayor of Mac Gregor's Grill and Tap Room on @foursquare! http:\/\/4sq.com\/6hNKyN",
  "id" : 9413255899,
  "created_at" : "2010-02-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9413256835",
  "text" : "I'm at Mac Gregor's Grill and Tap Room (300 Jefferson Rd, Rochester). http:\/\/4sq.com\/6hNKyN",
  "id" : 9413256835,
  "created_at" : "2010-02-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9421095092",
  "text" : "bad news bears: monroe county sheriff + huge SWAT esque truck outside of Perkins...I didn't see any cops swarming the apts though.",
  "id" : 9421095092,
  "created_at" : "2010-02-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Good",
      "screen_name" : "gooberdlx",
      "indices" : [ 0, 10 ],
      "id_str" : "661703",
      "id" : 661703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9434517858",
  "geo" : { },
  "id_str" : "9434744753",
  "in_reply_to_user_id" : 661703,
  "text" : "@gooberdlx that's a mswin32 only gem...maybe that's why? http:\/\/rubygems.org\/gems\/ming-ruby",
  "id" : 9434744753,
  "in_reply_to_status_id" : 9434517858,
  "created_at" : "2010-02-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "gooberdlx",
  "in_reply_to_user_id_str" : "661703",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9436783607",
  "text" : "I'm at Wegmans - Calkins Rd (745 Calkins Rd., Rochester). http:\/\/4sq.com\/8vSh45",
  "id" : 9436783607,
  "created_at" : "2010-02-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Mayer",
      "screen_name" : "danmayer",
      "indices" : [ 0, 9 ],
      "id_str" : "14630648",
      "id" : 14630648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9444102959",
  "geo" : { },
  "id_str" : "9444310656",
  "in_reply_to_user_id" : 14630648,
  "text" : "@danmayer thanks! I think I've messed up most of the caliper links though...:(",
  "id" : 9444310656,
  "in_reply_to_status_id" : 9444102959,
  "created_at" : "2010-02-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "danmayer",
  "in_reply_to_user_id_str" : "14630648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Ricketts",
      "screen_name" : "nightshade427",
      "indices" : [ 0, 14 ],
      "id_str" : "16505371",
      "id" : 16505371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9445689267",
  "geo" : { },
  "id_str" : "9445712746",
  "in_reply_to_user_id" : 16505371,
  "text" : "@nightshade427 hah great question...I'll find out.",
  "id" : 9445712746,
  "in_reply_to_status_id" : 9445689267,
  "created_at" : "2010-02-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "nightshade427",
  "in_reply_to_user_id_str" : "16505371",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9448999657",
  "text" : "Photo: Since gunshowcomic.com never updates, the author\u2019s LJ will have to do. http:\/\/tumblr.com\/x176o9ej4",
  "id" : 9448999657,
  "created_at" : "2010-02-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9385231155",
  "text" : "\"Put your freaking raddish on the curb. PUT IT ON THE CURB, RIGHT NOW!\" http:\/\/shirt.woot.com\/",
  "id" : 9385231155,
  "created_at" : "2010-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9401414050",
  "text" : "Got tickets for tonight's RIT hockey match. Not sold out...yet!",
  "id" : 9401414050,
  "created_at" : "2010-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9403105374",
  "text" : "I'm at Frank Ritter Arena (Rochester Institute of Technology, Henrietta). http:\/\/4sq.com\/6IjpwD",
  "id" : 9403105374,
  "created_at" : "2010-02-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    }, {
      "name" : "Penguinoh Waddles",
      "screen_name" : "penguinoh",
      "indices" : [ 24, 34 ],
      "id_str" : "93986627",
      "id" : 93986627
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9308187625",
  "geo" : { },
  "id_str" : "9308473023",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn I vote you shank @penguinoh",
  "id" : 9308473023,
  "in_reply_to_status_id" : 9308187625,
  "created_at" : "2010-02-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 44, 52 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9312331100",
  "text" : "Exploring some Rails 3 at Rochester.rb with @rubiety. and LOL IM ON THE SCREEN",
  "id" : 9312331100,
  "created_at" : "2010-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9317447436",
  "text" : "I'm at Tap & Mallet (381 Gregory St., Rochester). http:\/\/4sq.com\/5n0t7p",
  "id" : 9317447436,
  "created_at" : "2010-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Younge",
      "screen_name" : "ayounge",
      "indices" : [ 0, 8 ],
      "id_str" : "14746618",
      "id" : 14746618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9343604014",
  "geo" : { },
  "id_str" : "9343640898",
  "in_reply_to_user_id" : 14746618,
  "text" : "@ayounge http:\/\/hoth.entp.com\/output\/git_for_designers.html http:\/\/progit.org http:\/\/gitready.com",
  "id" : 9343640898,
  "in_reply_to_status_id" : 9343604014,
  "created_at" : "2010-02-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "ayounge",
  "in_reply_to_user_id_str" : "14746618",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9349929162",
  "text" : "LET'S GET READY TO BUNNNNNNNNNNNDLE",
  "id" : 9349929162,
  "created_at" : "2010-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flip Sasser",
      "screen_name" : "flipsasser",
      "indices" : [ 0, 11 ],
      "id_str" : "9144132",
      "id" : 9144132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9350922393",
  "geo" : { },
  "id_str" : "9351701870",
  "in_reply_to_user_id" : 9144132,
  "text" : "@flipsasser you can submit gem deletion requests to http:\/\/help.rubygems.org, I usually try to get to requests nightly.",
  "id" : 9351701870,
  "in_reply_to_status_id" : 9350922393,
  "created_at" : "2010-02-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "flipsasser",
  "in_reply_to_user_id_str" : "9144132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9353512244",
  "text" : "Closely following on the \u201Cleast drunk\u2019\u2019 end of the list are... Rochester, N.Y. http:\/\/is.gd\/8KvNf",
  "id" : 9353512244,
  "created_at" : "2010-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9353773945",
  "text" : "Ok, we're #98, I'm stupid. redacted that last tweet. http:\/\/www.menshealth.com\/mhlists\/Americas-Drunkest-Cities\/Rochester-NY.php",
  "id" : 9353773945,
  "created_at" : "2010-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9357371832",
  "text" : "RIT hockey time!",
  "id" : 9357371832,
  "created_at" : "2010-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9357941832",
  "text" : "I'm at Frank Ritter Arena (Rochester Institute of Technology, Henrietta). http:\/\/4sq.com\/6IjpwD",
  "id" : 9357941832,
  "created_at" : "2010-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9358205292",
  "text" : "Ok, maybe not, game is sold out. LAME.",
  "id" : 9358205292,
  "created_at" : "2010-02-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 8, 16 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9261617651",
  "text" : "Oh man, @garyvee at #railsconf. Now it's a party. http:\/\/en.oreilly.com\/rails2010",
  "id" : 9261617651,
  "created_at" : "2010-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9261659231",
  "geo" : { },
  "id_str" : "9262256763",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee definitely! might need to get this copy of 101 wines signed :)",
  "id" : 9262256763,
  "in_reply_to_status_id" : 9261659231,
  "created_at" : "2010-02-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 45, 56 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 3, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9262482818",
  "text" : "My #railsconf talk needs a better title like @tenderlove's Tasty Burgers. http:\/\/is.gd\/8CrMl",
  "id" : 9262482818,
  "created_at" : "2010-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt MattTodd Todd",
      "screen_name" : "mtodd",
      "indices" : [ 0, 6 ],
      "id_str" : "5933482",
      "id" : 5933482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9262673882",
  "geo" : { },
  "id_str" : "9262854530",
  "in_reply_to_user_id" : 5933482,
  "text" : "@mtodd oh, I didn't even touch any Rush lyrics. Now I'll be listening to them all night.",
  "id" : 9262854530,
  "in_reply_to_status_id" : 9262673882,
  "created_at" : "2010-02-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "mtodd",
  "in_reply_to_user_id_str" : "5933482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9263237329",
  "geo" : { },
  "id_str" : "9263385811",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick my favorite is unless !something.blank?",
  "id" : 9263385811,
  "in_reply_to_status_id" : 9263237329,
  "created_at" : "2010-02-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 39, 46 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9267025016",
  "text" : "Mirrored the 1972 Unix reproduction on @github: http:\/\/github.com\/qrush\/unix (Thanks @superpants5000!)",
  "id" : 9267025016,
  "created_at" : "2010-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9294274307",
  "geo" : { },
  "id_str" : "9295363829",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule What rubygems verison are you trying to upgrade from?",
  "id" : 9295363829,
  "in_reply_to_status_id" : 9294274307,
  "created_at" : "2010-02-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Gillies",
      "screen_name" : "DamoG",
      "indices" : [ 0, 6 ],
      "id_str" : "73335629",
      "id" : 73335629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9296697670",
  "text" : "@damog Yeah, our search sucks. Patches are welcome!",
  "id" : 9296697670,
  "created_at" : "2010-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 9, 19 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9300191691",
  "text" : "Upgraded @gemcutter to bundler 0.9. Instead of writing blog posts I think I'm just going to start a Rails Guide for it.",
  "id" : 9300191691,
  "created_at" : "2010-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 3, 11 ],
      "id_str" : "22682102",
      "id" : 22682102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9306340954",
  "text" : "RT @dmansen: Another note: nothing in a software project happens \"automatically\", especially documentation.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "9305501972",
    "text" : "Another note: nothing in a software project happens \"automatically\", especially documentation.",
    "id" : 9305501972,
    "created_at" : "2010-02-18 22:53:40 +0000",
    "user" : {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "protected" : false,
      "id_str" : "22682102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533634167473311744\/SLnTgxfz_normal.jpeg",
      "id" : 22682102,
      "verified" : false
    }
  },
  "id" : 9306340954,
  "created_at" : "2010-02-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathaniel Talbott",
      "screen_name" : "ntalbott",
      "indices" : [ 0, 9 ],
      "id_str" : "654653",
      "id" : 654653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9305736192",
  "geo" : { },
  "id_str" : "9306563947",
  "in_reply_to_user_id" : 654653,
  "text" : "@ntalbott that's the #1 reason why i started gitready.com. (i need to contribute more to that site...)",
  "id" : 9306563947,
  "in_reply_to_status_id" : 9305736192,
  "created_at" : "2010-02-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ntalbott",
  "in_reply_to_user_id_str" : "654653",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dannytatom",
      "screen_name" : "dannytatom",
      "indices" : [ 0, 11 ],
      "id_str" : "2500287421",
      "id" : 2500287421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9307885724",
  "geo" : { },
  "id_str" : "9307990146",
  "in_reply_to_user_id" : 17012066,
  "text" : "@dannytatom movement doesn't work for me with hjkl or arrow keys in chrome or firefox. Also, just stick to @'s :) nethack forever.",
  "id" : 9307990146,
  "in_reply_to_status_id" : 9307885724,
  "created_at" : "2010-02-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "rabitrup",
  "in_reply_to_user_id_str" : "17012066",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dannytatom",
      "screen_name" : "dannytatom",
      "indices" : [ 0, 11 ],
      "id_str" : "2500287421",
      "id" : 2500287421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9308038308",
  "geo" : { },
  "id_str" : "9308148840",
  "in_reply_to_user_id" : 17012066,
  "text" : "@dannytatom fix that right now: telnet nethack.alt.org. I still want to write a web proxy server for that :\/",
  "id" : 9308148840,
  "in_reply_to_status_id" : 9308038308,
  "created_at" : "2010-02-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "rabitrup",
  "in_reply_to_user_id_str" : "17012066",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9212658387",
  "geo" : { },
  "id_str" : "9212908527",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey ahh, i see. read up about DSLs! http:\/\/is.gd\/8xVBO http:\/\/is.gd\/8xVx6",
  "id" : 9212908527,
  "in_reply_to_status_id" : 9212658387,
  "created_at" : "2010-02-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Neighman",
      "screen_name" : "hassox",
      "indices" : [ 0, 7 ],
      "id_str" : "4128391",
      "id" : 4128391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9221532438",
  "geo" : { },
  "id_str" : "9222456242",
  "in_reply_to_user_id" : 4128391,
  "text" : "@hassox Ugh, that's been a constant hassle...I'd have to see the exact error. Have you seen http:\/\/github.com\/cwninja\/geminabox ?",
  "id" : 9222456242,
  "in_reply_to_status_id" : 9221532438,
  "created_at" : "2010-02-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "hassox",
  "in_reply_to_user_id_str" : "4128391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9251385119",
  "geo" : { },
  "id_str" : "9251479981",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad Wow...what a mistake.",
  "id" : 9251479981,
  "in_reply_to_status_id" : 9251385119,
  "created_at" : "2010-02-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9209743791",
  "text" : "http:\/\/fav4.org\/ is cute, but i really would love to specify custom links\/icons.",
  "id" : 9209743791,
  "created_at" : "2010-02-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Nesbitt",
      "screen_name" : "joshnesbitt",
      "indices" : [ 0, 12 ],
      "id_str" : "15652424",
      "id" : 15652424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9205499123",
  "geo" : { },
  "id_str" : "9211055364",
  "in_reply_to_user_id" : 15652424,
  "text" : "@joshnesbitt woot. :) always glad to see it's a fluid process for those new to the service.",
  "id" : 9211055364,
  "in_reply_to_status_id" : 9205499123,
  "created_at" : "2010-02-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshnesbitt",
  "in_reply_to_user_id_str" : "15652424",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9212244825",
  "geo" : { },
  "id_str" : "9212480551",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey That snippet is too small for me to grok\/refactor. Seeing the whole source would be helpful... :\/",
  "id" : 9212480551,
  "in_reply_to_status_id" : 9212244825,
  "created_at" : "2010-02-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9170156963",
  "text" : "Is there any way for Flickr not to make photos super small when you upload them? I promise, they're not that tiny.",
  "id" : 9170156963,
  "created_at" : "2010-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9170932252",
  "geo" : { },
  "id_str" : "9191083544",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y ha, thanks. I've resolved to never say 'awesome' in a presentation again.",
  "id" : 9191083544,
  "in_reply_to_status_id" : 9170932252,
  "created_at" : "2010-02-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9191403862",
  "text" : "I don't know any other SE grads yet that are going to work for a small company or startup. This makes me a sad panda.",
  "id" : 9191403862,
  "created_at" : "2010-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sam :",
      "screen_name" : "Lenary",
      "indices" : [ 0, 7 ],
      "id_str" : "14466962",
      "id" : 14466962
    }, {
      "name" : "Mike Champion",
      "screen_name" : "graysky",
      "indices" : [ 34, 42 ],
      "id_str" : "364",
      "id" : 364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9192918464",
  "geo" : { },
  "id_str" : "9193066642",
  "in_reply_to_user_id" : 14466962,
  "text" : "@Lenary Software Engineering. and @graysky, i think it's the former...not enough students know the benefits or differences.",
  "id" : 9193066642,
  "in_reply_to_status_id" : 9192918464,
  "created_at" : "2010-02-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "Lenary",
  "in_reply_to_user_id_str" : "14466962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Chambers",
      "screen_name" : "schambers",
      "indices" : [ 0, 10 ],
      "id_str" : "8372122",
      "id" : 8372122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9197016505",
  "geo" : { },
  "id_str" : "9197269667",
  "in_reply_to_user_id" : 8372122,
  "text" : "@schambers so worth it. Play some nethack for training.",
  "id" : 9197269667,
  "in_reply_to_status_id" : 9197016505,
  "created_at" : "2010-02-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "schambers",
  "in_reply_to_user_id_str" : "8372122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Neighman",
      "screen_name" : "hassox",
      "indices" : [ 0, 7 ],
      "id_str" : "4128391",
      "id" : 4128391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9205649317",
  "geo" : { },
  "id_str" : "9207021733",
  "in_reply_to_user_id" : 4128391,
  "text" : "@hassox specify GEMCUTTER_URL=http:\/\/yourcustomgemcutter.com gem push. in the new rubygems it will be RUBYGEMS_HOST.",
  "id" : 9207021733,
  "in_reply_to_status_id" : 9205649317,
  "created_at" : "2010-02-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "hassox",
  "in_reply_to_user_id_str" : "4128391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Neighman",
      "screen_name" : "hassox",
      "indices" : [ 0, 7 ],
      "id_str" : "4128391",
      "id" : 4128391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9205649317",
  "geo" : { },
  "id_str" : "9207034608",
  "in_reply_to_user_id" : 4128391,
  "text" : "@hassox I'd love to make that process easier...there's an issue open on it but I haven't had time to look into it.",
  "id" : 9207034608,
  "in_reply_to_status_id" : 9205649317,
  "created_at" : "2010-02-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "hassox",
  "in_reply_to_user_id_str" : "4128391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9207486304",
  "text" : "Still hilarious: Worst. Ideas. Ever. http:\/\/is.gd\/8xuhI",
  "id" : 9207486304,
  "created_at" : "2010-02-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9118233553",
  "text" : "Why is user authentication\/authorization so damn hard in ASP.NET? restful_auth and Clearance have spoiled me.",
  "id" : 9118233553,
  "created_at" : "2010-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Wildermuth",
      "screen_name" : "ShawnWildermuth",
      "indices" : [ 0, 16 ],
      "id_str" : "1388411",
      "id" : 1388411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9118912032",
  "geo" : { },
  "id_str" : "9122049067",
  "in_reply_to_user_id" : 1388411,
  "text" : "@ShawnWildermuth please do enlighten me....are there any good open source frameworks or tutorials I should be looking at&gt;",
  "id" : 9122049067,
  "in_reply_to_status_id" : 9118912032,
  "created_at" : "2010-02-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ShawnWildermuth",
  "in_reply_to_user_id_str" : "1388411",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hudson CI",
      "screen_name" : "hudsonci",
      "indices" : [ 25, 34 ],
      "id_str" : "245535216",
      "id" : 245535216
    }, {
      "name" : "Integrity: CI Server",
      "screen_name" : "integrityrb",
      "indices" : [ 36, 48 ],
      "id_str" : "15350321",
      "id" : 15350321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9123299890",
  "text" : "Seriously impressed with @hudsonci. @integrityrb has a long ways to go.",
  "id" : 9123299890,
  "created_at" : "2010-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9124346364",
  "geo" : { },
  "id_str" : "9124561327",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg automatic updating build console output for one. Need to use it more. I like the weather style icons too for history.",
  "id" : 9124561327,
  "in_reply_to_status_id" : 9124346364,
  "created_at" : "2010-02-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9125477980",
  "text" : "Does anyone know the name of the webapp that does straight-to-html mockups? It's not Mockingbird.",
  "id" : 9125477980,
  "created_at" : "2010-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9147536183",
  "text" : "Repeating this now that people are awake: Does anyone know the webapp that does straight-to-html mockups? Not Mockingbird. Or Napkee.",
  "id" : 9147536183,
  "created_at" : "2010-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9149439521",
  "geo" : { },
  "id_str" : "9149606175",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius What gem?",
  "id" : 9149606175,
  "in_reply_to_status_id" : 9149439521,
  "created_at" : "2010-02-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francisco ruiz",
      "screen_name" : "Paco36",
      "indices" : [ 30, 37 ],
      "id_str" : "2460224676",
      "id" : 2460224676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9151640817",
  "text" : "Bing Maps is blowing my mind. @paco36 have you seen this? http:\/\/www.ted.com\/talks\/blaise_aguera.html",
  "id" : 9151640817,
  "created_at" : "2010-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9155390369",
  "geo" : { },
  "id_str" : "9155565100",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats http:\/\/cdn0.knowyourmeme.com\/i\/1582\/original\/picard-facepalm.jpg",
  "id" : 9155565100,
  "in_reply_to_status_id" : 9155390369,
  "created_at" : "2010-02-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9159062196",
  "text" : "Yes, people are dumb. http:\/\/mattstratton.com\/hilarity\/hundreds-of-facebook-users-are-apparently-really-dumb",
  "id" : 9159062196,
  "created_at" : "2010-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9076407955",
  "text" : "Making some homemade Chacarero sandwiches tonight. Sweet potato fries and everything.",
  "id" : 9076407955,
  "created_at" : "2010-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Wright",
      "screen_name" : "Abica",
      "indices" : [ 0, 6 ],
      "id_str" : "23170767",
      "id" : 23170767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9088272551",
  "geo" : { },
  "id_str" : "9099024860",
  "in_reply_to_user_id" : 23170767,
  "text" : "@Abica we're working with http:\/\/rdoc.info to provide that...soon i hope!",
  "id" : 9099024860,
  "in_reply_to_status_id" : 9088272551,
  "created_at" : "2010-02-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "Abica",
  "in_reply_to_user_id_str" : "23170767",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DATO  KIPIANI",
      "screen_name" : "_dato",
      "indices" : [ 0, 6 ],
      "id_str" : "306901459",
      "id" : 306901459
    }, {
      "name" : "Pingdom",
      "screen_name" : "pingdom",
      "indices" : [ 28, 36 ],
      "id_str" : "15674759",
      "id" : 15674759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9099179407",
  "text" : "@_dato definitely just you, @pingdom would be yelling at me if so.",
  "id" : 9099179407,
  "created_at" : "2010-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devs @ Wieck Labs",
      "screen_name" : "wiecklabs",
      "indices" : [ 0, 10 ],
      "id_str" : "39839464",
      "id" : 39839464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9087467464",
  "geo" : { },
  "id_str" : "9099376522",
  "in_reply_to_user_id" : 39839464,
  "text" : "@wiecklabs it's just hard to figure out the selling point over rails or sinatra. the debug panel is nice but not enough.",
  "id" : 9099376522,
  "in_reply_to_status_id" : 9087467464,
  "created_at" : "2010-02-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "wiecklabs",
  "in_reply_to_user_id_str" : "39839464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9103364790",
  "text" : "Current status: http:\/\/twitgoo.com\/dxijc",
  "id" : 9103364790,
  "created_at" : "2010-02-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Plancast",
      "screen_name" : "plancast",
      "indices" : [ 0, 9 ],
      "id_str" : "67219958",
      "id" : 67219958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9108113672",
  "geo" : { },
  "id_str" : "9108706137",
  "in_reply_to_user_id" : 67219958,
  "text" : "@plancast I mean, to finish a plan. I'm not seeing any 'finish' or 'done!' button on http:\/\/plancast.com\/a\/me4",
  "id" : 9108706137,
  "in_reply_to_status_id" : 9108113672,
  "created_at" : "2010-02-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "plancast",
  "in_reply_to_user_id_str" : "67219958",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9037931167",
  "text" : "I'm at Wegmans - Hylan Dr. (650 Hylan Dr., Rochester). http:\/\/4sq.com\/74kvOb",
  "id" : 9037931167,
  "created_at" : "2010-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allan branch",
      "screen_name" : "lessallan",
      "indices" : [ 0, 10 ],
      "id_str" : "18058252",
      "id" : 18058252
    }, {
      "name" : "hoptoadapp",
      "screen_name" : "hoptoadapp",
      "indices" : [ 65, 76 ],
      "id_str" : "15689539",
      "id" : 15689539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9059440672",
  "geo" : { },
  "id_str" : "9059691001",
  "in_reply_to_user_id" : 6183972,
  "text" : "@lessallan Tender has been great, been using it for a while with @hoptoadapp and now at http:\/\/help.rubygems.org",
  "id" : 9059691001,
  "in_reply_to_status_id" : 9059440672,
  "created_at" : "2010-02-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "allanbranch",
  "in_reply_to_user_id_str" : "6183972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Plancast",
      "screen_name" : "plancast",
      "indices" : [ 25, 34 ],
      "id_str" : "67219958",
      "id" : 67219958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9059873834",
  "text" : "I'm really trying to get @plancast. I don't see a big giant \"ACCOMPLISH\" or \"FINISH\" button.",
  "id" : 9059873834,
  "created_at" : "2010-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9063925521",
  "text" : "The Verizon has turned into a daycare. Tons of kids running amok.",
  "id" : 9063925521,
  "created_at" : "2010-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9063946490",
  "text" : "The verizon store. Although, that previous statement may also be true.",
  "id" : 9063946490,
  "created_at" : "2010-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9068654292",
  "text" : "Going snowshoeing tomorrow for the first time. Any advice? (I used to ski, if that helps).",
  "id" : 9068654292,
  "created_at" : "2010-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9071316936",
  "text" : "Thanks for the advice so far folks. Going to take them for test drive in a few before the real thing tomorrow.",
  "id" : 9071316936,
  "created_at" : "2010-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Schwager",
      "screen_name" : "onlycodered",
      "indices" : [ 0, 12 ],
      "id_str" : "1622561",
      "id" : 1622561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9071637982",
  "geo" : { },
  "id_str" : "9071806581",
  "in_reply_to_user_id" : 1622561,
  "text" : "@onlycodered haha I had snowblades...never liked snowboarding, tears up too much good powder :)",
  "id" : 9071806581,
  "in_reply_to_status_id" : 9071637982,
  "created_at" : "2010-02-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "onlycodered",
  "in_reply_to_user_id_str" : "1622561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9073512404",
  "text" : "Snowshoe test was successful. But holy crap, it's cold out Rochester.",
  "id" : 9073512404,
  "created_at" : "2010-02-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Zygmuntowicz",
      "screen_name" : "ezmobius",
      "indices" : [ 0, 9 ],
      "id_str" : "3560241",
      "id" : 3560241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8981296929",
  "geo" : { },
  "id_str" : "8981377664",
  "in_reply_to_user_id" : 3560241,
  "text" : "@ezmobius would love to see the slides when you're done. are you covering any real world uses?",
  "id" : 8981377664,
  "in_reply_to_status_id" : 8981296929,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "ezmobius",
  "in_reply_to_user_id_str" : "3560241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elad Meidar",
      "screen_name" : "eladmeidar",
      "indices" : [ 0, 11 ],
      "id_str" : "16815376",
      "id" : 16815376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8981285499",
  "geo" : { },
  "id_str" : "8981402862",
  "in_reply_to_user_id" : 16815376,
  "text" : "@eladmeidar you could build such a service with gem webhooks. Do eeet!",
  "id" : 8981402862,
  "in_reply_to_status_id" : 8981285499,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "eladmeidar",
  "in_reply_to_user_id_str" : "16815376",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabien Penso",
      "screen_name" : "fabienpenso",
      "indices" : [ 0, 12 ],
      "id_str" : "8423832",
      "id" : 8423832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8982007549",
  "geo" : { },
  "id_str" : "8982929492",
  "in_reply_to_user_id" : 8423832,
  "text" : "@fabienpenso process right now is to open up a request on http:\/\/help.rubygems.org",
  "id" : 8982929492,
  "in_reply_to_status_id" : 8982007549,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "fabienpenso",
  "in_reply_to_user_id_str" : "8423832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8989665364",
  "text" : "I'm at Mac Gregor's Grill and Tap Room (300 Jefferson Rd, Rochester). http:\/\/4sq.com\/6hNKyN",
  "id" : 8989665364,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Turnbull",
      "screen_name" : "dsturnbull",
      "indices" : [ 0, 11 ],
      "id_str" : "13450182",
      "id" : 13450182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8992644287",
  "geo" : { },
  "id_str" : "8996451389",
  "in_reply_to_user_id" : 13450182,
  "text" : "@dsturnbull What?",
  "id" : 8996451389,
  "in_reply_to_status_id" : 8992644287,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "dsturnbull",
  "in_reply_to_user_id_str" : "13450182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8996473367",
  "text" : "MacGregor's is a horrib^H^H^H^H^H^Hawesome influence on life.",
  "id" : 8996473367,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 0, 8 ],
      "id_str" : "22682102",
      "id" : 22682102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8983807036",
  "geo" : { },
  "id_str" : "8996606395",
  "in_reply_to_user_id" : 22682102,
  "text" : "@dmansen no, that was fine. the detailed design stuff is all BS though.",
  "id" : 8996606395,
  "in_reply_to_status_id" : 8983807036,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "dmansen",
  "in_reply_to_user_id_str" : "22682102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    }, {
      "name" : "Andrew J. Younge",
      "screen_name" : "ayounge",
      "indices" : [ 10, 18 ],
      "id_str" : "14746618",
      "id" : 14746618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8996507955",
  "geo" : { },
  "id_str" : "8996614188",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil @ayounge don't judge me and my terminal",
  "id" : 8996614188,
  "in_reply_to_status_id" : 8996507955,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8994347650",
  "geo" : { },
  "id_str" : "8996635318",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps would love to see that work. rubygems are one of the main reasons I don't look back favorably on the .net landscape.",
  "id" : 8996635318,
  "in_reply_to_status_id" : 8994347650,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Britt",
      "screen_name" : "jamesbritt",
      "indices" : [ 0, 11 ],
      "id_str" : "13234242",
      "id" : 13234242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gemcutter",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9000149846",
  "geo" : { },
  "id_str" : "9009740258",
  "in_reply_to_user_id" : 13234242,
  "text" : "@jamesbritt we have guides on setting it up on our github wiki. Hop into #gemcutter on freenode sometime.",
  "id" : 9009740258,
  "in_reply_to_status_id" : 9000149846,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "jamesbritt",
  "in_reply_to_user_id_str" : "13234242",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9012806626",
  "text" : "Pretty but I still don't get it. http:\/\/www.wiecklabs.com\/",
  "id" : 9012806626,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9017604047",
  "text" : "\"Connectology Leadership Advancement Conference\" thanks RIT, I just threw up in my mouth a little.",
  "id" : 9017604047,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9020853305",
  "text" : "I'm at Java Wally's (90 Lomb Memorial Drive, Rochester). http:\/\/4sq.com\/6pTb3i",
  "id" : 9020853305,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dannytatom",
      "screen_name" : "dannytatom",
      "indices" : [ 0, 11 ],
      "id_str" : "2500287421",
      "id" : 2500287421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9021409476",
  "geo" : { },
  "id_str" : "9022506738",
  "in_reply_to_user_id" : 17012066,
  "text" : "@dannytatom yep, and hopefully more endpoints\/uses coming up soon...gem deleting, downloads, you name it.",
  "id" : 9022506738,
  "in_reply_to_status_id" : 9021409476,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "rabitrup",
  "in_reply_to_user_id_str" : "17012066",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hoang van ninh",
      "screen_name" : "ninh",
      "indices" : [ 42, 47 ],
      "id_str" : "1845099079",
      "id" : 1845099079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8943202396",
  "text" : "I don't know what magic scaling sprinkles @ninh and Hongli put into Passenger 2.2.9 and REE, but dear lord it's fast.",
  "id" : 8943202396,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hoang van ninh",
      "screen_name" : "ninh",
      "indices" : [ 0, 5 ],
      "id_str" : "1845099079",
      "id" : 1845099079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8943544984",
  "text" : "@ninh there's passenger buckin' a bale of hay! http:\/\/www.youtube.com\/watch?v=JvltzwkUEEA",
  "id" : 8943544984,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Kane Parker",
      "screen_name" : "moonmaster9000",
      "indices" : [ 0, 15 ],
      "id_str" : "14391298",
      "id" : 14391298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8946149865",
  "geo" : { },
  "id_str" : "8946715147",
  "in_reply_to_user_id" : 14391298,
  "text" : "@moonmaster9000 no, really, that's it. We moved off config.ru to use the 'smart spawning' too http:\/\/bit.ly\/7E6zmb",
  "id" : 8946715147,
  "in_reply_to_status_id" : 8946149865,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "moonmaster9000",
  "in_reply_to_user_id_str" : "14391298",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Reynolds",
      "screen_name" : "scottcreynolds",
      "indices" : [ 0, 15 ],
      "id_str" : "441985676",
      "id" : 441985676
    }, {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 16, 29 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8964183203",
  "text" : "@scottcreynolds @derickbailey I know the java guys did something similar with maven. If you need help let me know.",
  "id" : 8964183203,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ollivier Robert",
      "screen_name" : "Keltounet",
      "indices" : [ 0, 10 ],
      "id_str" : "95639457",
      "id" : 95639457
    }, {
      "name" : "Ryan Hartzog",
      "screen_name" : "rhartzog",
      "indices" : [ 11, 20 ],
      "id_str" : "17465544",
      "id" : 17465544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8968431691",
  "geo" : { },
  "id_str" : "8969503545",
  "in_reply_to_user_id" : 95639457,
  "text" : "@Keltounet @rhartzog gems.rubyforge.org == gemcutter.org. and github gems aren't updated anymore. http:\/\/is.gd\/8ayg6",
  "id" : 8969503545,
  "in_reply_to_status_id" : 8968431691,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "Keltounet",
  "in_reply_to_user_id_str" : "95639457",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hartzog",
      "screen_name" : "rhartzog",
      "indices" : [ 0, 9 ],
      "id_str" : "17465544",
      "id" : 17465544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8973328009",
  "geo" : { },
  "id_str" : "8974084192",
  "in_reply_to_user_id" : 17465544,
  "text" : "@rhartzog the github gem server is still alive, but you can't index new gems on it.",
  "id" : 8974084192,
  "in_reply_to_status_id" : 8973328009,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "rhartzog",
  "in_reply_to_user_id_str" : "17465544",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hartzog",
      "screen_name" : "rhartzog",
      "indices" : [ 0, 9 ],
      "id_str" : "17465544",
      "id" : 17465544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8974321797",
  "geo" : { },
  "id_str" : "8974510792",
  "in_reply_to_user_id" : 17465544,
  "text" : "@rhartzog that sounds like a pretty horrible firewall. you can setup a proxy with rubygems. http:\/\/is.gd\/8b3D6",
  "id" : 8974510792,
  "in_reply_to_status_id" : 8974321797,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "rhartzog",
  "in_reply_to_user_id_str" : "17465544",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8980302118",
  "text" : "I tend to cringe at UML class diagrams in presentations. The SE student in me is dead.",
  "id" : 8980302118,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8980409733",
  "geo" : { },
  "id_str" : "8980551067",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm heavy design up front is usually a failure. TDD makes it an evolutionary process.",
  "id" : 8980551067,
  "in_reply_to_status_id" : 8980409733,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 0, 7 ],
      "id_str" : "728173",
      "id" : 728173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8925560648",
  "geo" : { },
  "id_str" : "8926085664",
  "in_reply_to_user_id" : 728173,
  "text" : "@MikeG1 FFFFFFFFFFUUUUUUUUUUUUUUUUUUUUUUUUUUUUU",
  "id" : 8926085664,
  "in_reply_to_status_id" : 8925560648,
  "created_at" : "2010-02-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "MikeG1",
  "in_reply_to_user_id_str" : "728173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Sinclair",
      "screen_name" : "anathematic",
      "indices" : [ 0, 12 ],
      "id_str" : "14610920",
      "id" : 14610920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8925853718",
  "geo" : { },
  "id_str" : "8926192523",
  "in_reply_to_user_id" : 14610920,
  "text" : "@anathematic FTFY http:\/\/progit.org\/",
  "id" : 8926192523,
  "in_reply_to_status_id" : 8925853718,
  "created_at" : "2010-02-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "anathematic",
  "in_reply_to_user_id_str" : "14610920",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Wu",
      "screen_name" : "fredwu",
      "indices" : [ 0, 7 ],
      "id_str" : "14189878",
      "id" : 14189878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8926905165",
  "geo" : { },
  "id_str" : "8926939403",
  "in_reply_to_user_id" : 14189878,
  "text" : "@fredwu it's up here, i would be getting slammed with pingdom alerts if not :)",
  "id" : 8926939403,
  "in_reply_to_status_id" : 8926905165,
  "created_at" : "2010-02-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "fredwu",
  "in_reply_to_user_id_str" : "14189878",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Huckstep",
      "screen_name" : "darkhelmetlive",
      "indices" : [ 0, 15 ],
      "id_str" : "19567986",
      "id" : 19567986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8875895163",
  "geo" : { },
  "id_str" : "8884108124",
  "in_reply_to_user_id" : 19567986,
  "text" : "@darkhelmetlive http:\/\/github.com\/qrush\/gemcutter\/issues is a good place.",
  "id" : 8884108124,
  "in_reply_to_status_id" : 8875895163,
  "created_at" : "2010-02-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "darkhelmetlive",
  "in_reply_to_user_id_str" : "19567986",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8908985997",
  "text" : "Total mob scene in Javas and the SAU thanks to building 7 trying to burn itself down.",
  "id" : 8908985997,
  "created_at" : "2010-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 3, 13 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8910192072",
  "text" : "RT @confreaks: New #rubyconf 09 talk available: \"Gemcutter: The Next Step in Gem Hosting\" by Nick Quaranto http:\/\/bit.ly\/9VVNoo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubyconf",
        "indices" : [ 4, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8900338257",
    "text" : "New #rubyconf 09 talk available: \"Gemcutter: The Next Step in Gem Hosting\" by Nick Quaranto http:\/\/bit.ly\/9VVNoo",
    "id" : 8900338257,
    "created_at" : "2010-02-10 13:02:57 +0000",
    "user" : {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "protected" : false,
      "id_str" : "14182110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508193987417485312\/4FaFrBga_normal.png",
      "id" : 14182110,
      "verified" : false
    }
  },
  "id" : 8910192072,
  "created_at" : "2010-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIT",
      "indices" : [ 5, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8916588012",
  "text" : "Wow. #RIT is moving to semesters. Glad I'm out of here in May.",
  "id" : 8916588012,
  "created_at" : "2010-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8921079133",
  "geo" : { },
  "id_str" : "8921121755",
  "in_reply_to_user_id" : 16892522,
  "text" : "@wolfz0rz Why do you even bother? You won't be a student at that point. It's stupid. Choose a different school if you don't like the policy.",
  "id" : 8921121755,
  "in_reply_to_status_id" : 8921079133,
  "created_at" : "2010-02-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "cregatron",
  "in_reply_to_user_id_str" : "16892522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8921356950",
  "geo" : { },
  "id_str" : "8921577426",
  "in_reply_to_user_id" : 16892522,
  "text" : "@wolfz0rz Call me cynical or bitter, but it's a \"private\" institution for a reason. It's seeking profit like any other business would.",
  "id" : 8921577426,
  "in_reply_to_status_id" : 8921356950,
  "created_at" : "2010-02-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "cregatron",
  "in_reply_to_user_id_str" : "16892522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    }, {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 7, 19 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8833199422",
  "geo" : { },
  "id_str" : "8833316381",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn @SteveStreza you don't need tests when YOUR CODES ARE PERFECT. http:\/\/farm3.static.flickr.com\/2316\/2312000537_51cc7bf751.jpg",
  "id" : 8833316381,
  "in_reply_to_status_id" : 8833199422,
  "created_at" : "2010-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8834171171",
  "text" : "Video: One man cover of Subdivisions\u2026on a roof. Amazing. http:\/\/tumblr.com\/x1769o3jj",
  "id" : 8834171171,
  "created_at" : "2010-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8839333109",
  "text" : "Former coworker has the high bid on http:\/\/cgi.ebay.com\/ws\/eBayISAPI.dll?ViewItem&rd=1&item=200433782898#ht_1170wt_1167. Insane.",
  "id" : 8839333109,
  "created_at" : "2010-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 102, 112 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 113, 122 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8842612980",
  "text" : "Is there a way to watch\/subscribe to a tag or search on StackOverflow? Would be nice to keep track of @gemcutter\/@rubygems issues.",
  "id" : 8842612980,
  "created_at" : "2010-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8857476461",
  "text" : "Grad student commandeering my morning class today. Commence awkwardness!",
  "id" : 8857476461,
  "created_at" : "2010-02-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "greatseth",
      "screen_name" : "greatseth",
      "indices" : [ 0, 10 ],
      "id_str" : "15181592",
      "id" : 15181592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8862485390",
  "geo" : { },
  "id_str" : "8862715742",
  "in_reply_to_user_id" : 15181592,
  "text" : "@greatseth why not? I think it's a great resource for the community. any reasons why you don't like it?",
  "id" : 8862715742,
  "in_reply_to_status_id" : 8862485390,
  "created_at" : "2010-02-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "greatseth",
  "in_reply_to_user_id_str" : "15181592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 30, 41 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8790253853",
  "text" : "I think I just saw ralph from @thoughtbot on a super bowl commercial. Angry he didn't invite us to vegas.",
  "id" : 8790253853,
  "created_at" : "2010-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8798407950",
  "text" : "\"Download complete. You can now disconnect from the internet.\" Thanks for this, Microsoft.",
  "id" : 8798407950,
  "created_at" : "2010-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8813218686",
  "text" : "GitHub Rebase #36! I want to blast Through the Fire and the Flames now. http:\/\/github.com\/blog\/598-github-rebase-36",
  "id" : 8813218686,
  "created_at" : "2010-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8813681089",
  "text" : "There's a massive amount of Ruby conferences between now and May (my graduation). Can we just move them until after that? Please?",
  "id" : 8813681089,
  "created_at" : "2010-02-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Filip Tepper",
      "screen_name" : "filiptepper",
      "indices" : [ 0, 12 ],
      "id_str" : "2539791",
      "id" : 2539791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8816295104",
  "geo" : { },
  "id_str" : "8816522157",
  "in_reply_to_user_id" : 2539791,
  "text" : "@filiptepper Usually I just try to find a git\/github\/rebase related image. http:\/\/rebase.github.com\/archive.html",
  "id" : 8816522157,
  "in_reply_to_status_id" : 8816295104,
  "created_at" : "2010-02-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "filiptepper",
  "in_reply_to_user_id_str" : "2539791",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Old",
      "screen_name" : "kevinold",
      "indices" : [ 0, 9 ],
      "id_str" : "9823452",
      "id" : 9823452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8816535845",
  "geo" : { },
  "id_str" : "8816813722",
  "in_reply_to_user_id" : 9823452,
  "text" : "@kevinold MountainWest, Red Dirt, Goruco, Scottish, Thailand, India...I'm probably missing some.",
  "id" : 8816813722,
  "in_reply_to_status_id" : 8816535845,
  "created_at" : "2010-02-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "kevinold",
  "in_reply_to_user_id_str" : "9823452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Huckstep",
      "screen_name" : "darkhelmetlive",
      "indices" : [ 0, 15 ],
      "id_str" : "19567986",
      "id" : 19567986
    }, {
      "name" : "ashley",
      "screen_name" : "grlwithcomputer",
      "indices" : [ 16, 32 ],
      "id_str" : "96403503",
      "id" : 96403503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8816597208",
  "geo" : { },
  "id_str" : "8816839732",
  "in_reply_to_user_id" : 19567986,
  "text" : "@darkhelmetlive @grlwithcomputer Thanks! I need to get writing again on it...plenty to add.",
  "id" : 8816839732,
  "in_reply_to_status_id" : 8816597208,
  "created_at" : "2010-02-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "darkhelmetlive",
  "in_reply_to_user_id_str" : "19567986",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Filip Tepper",
      "screen_name" : "filiptepper",
      "indices" : [ 0, 12 ],
      "id_str" : "2539791",
      "id" : 2539791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8816625482",
  "geo" : { },
  "id_str" : "8816946635",
  "in_reply_to_user_id" : 2539791,
  "text" : "@filiptepper It's just for fun. I'm considering doing screencasts for rebase, so maybe the images will be going away soon.",
  "id" : 8816946635,
  "in_reply_to_status_id" : 8816625482,
  "created_at" : "2010-02-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "filiptepper",
  "in_reply_to_user_id_str" : "2539791",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8818717774",
  "geo" : { },
  "id_str" : "8818757794",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines my recommendations: David Deutsch, Richard Dawkins, Mike Rowe. If you watch other good ones, let me know!",
  "id" : 8818757794,
  "in_reply_to_status_id" : 8818717774,
  "created_at" : "2010-02-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8819075418",
  "geo" : { },
  "id_str" : "8819481755",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil talk about what you've done, not about you. http:\/\/litanyagainstfear.com\/",
  "id" : 8819481755,
  "in_reply_to_status_id" : 8819075418,
  "created_at" : "2010-02-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8819658146",
  "geo" : { },
  "id_str" : "8819747276",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil if you put a UML diagram on your website I will end you.",
  "id" : 8819747276,
  "in_reply_to_status_id" : 8819658146,
  "created_at" : "2010-02-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8819805459",
  "geo" : { },
  "id_str" : "8823187902",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil STRONG NO HIRE.",
  "id" : 8823187902,
  "in_reply_to_status_id" : 8819805459,
  "created_at" : "2010-02-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8826158997",
  "geo" : { },
  "id_str" : "8826223731",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick time to register iphonecutter.com",
  "id" : 8826223731,
  "in_reply_to_status_id" : 8826158997,
  "created_at" : "2010-02-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8772828352",
  "text" : "I'm at five guys burgers and fries. http:\/\/4sq.com\/dbeXn0",
  "id" : 8772828352,
  "created_at" : "2010-02-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lopez",
      "screen_name" : "brianmario",
      "indices" : [ 0, 11 ],
      "id_str" : "9994542",
      "id" : 9994542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8729023246",
  "geo" : { },
  "id_str" : "8729065834",
  "in_reply_to_user_id" : 9994542,
  "text" : "@brianmario I'd love to see the time difference in using yajl-ruby for parsing hashes.",
  "id" : 8729065834,
  "in_reply_to_status_id" : 8729023246,
  "created_at" : "2010-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "brianmario",
  "in_reply_to_user_id_str" : "9994542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lopez",
      "screen_name" : "brianmario",
      "indices" : [ 0, 11 ],
      "id_str" : "9994542",
      "id" : 9994542
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 12, 20 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8729379880",
  "geo" : { },
  "id_str" : "8730673192",
  "in_reply_to_user_id" : 9994542,
  "text" : "@brianmario @mperham Awesome. Definitely will use yajl from the start.",
  "id" : 8730673192,
  "in_reply_to_status_id" : 8729379880,
  "created_at" : "2010-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "brianmario",
  "in_reply_to_user_id_str" : "9994542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 39, 49 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 70, 78 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8730764207",
  "text" : "Really excited to start using Redis on @gemcutter to track downloads. @antirez has shown me the light with sorted sets.",
  "id" : 8730764207,
  "created_at" : "2010-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 3, 13 ],
      "id_str" : "9980812",
      "id" : 9980812
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rant",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8732269487",
  "text" : "RT @igrigorik: hey coop students, please read this: http:\/\/bit.ly\/bl7mSe  ... it'll land you 110% more job interviews. srsly. #rant",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rant",
        "indices" : [ 111, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8732224953",
    "text" : "hey coop students, please read this: http:\/\/bit.ly\/bl7mSe  ... it'll land you 110% more job interviews. srsly. #rant",
    "id" : 8732224953,
    "created_at" : "2010-02-06 18:53:12 +0000",
    "user" : {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "protected" : false,
      "id_str" : "9980812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458689841186611200\/SMmZLt2Y_normal.jpeg",
      "id" : 9980812,
      "verified" : false
    }
  },
  "id" : 8732269487,
  "created_at" : "2010-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8733175667",
  "text" : "Day 2 of awkward music playing in Java's is about to begin.",
  "id" : 8733175667,
  "created_at" : "2010-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "follow @mattetti",
      "screen_name" : "merbist",
      "indices" : [ 0, 8 ],
      "id_str" : "1549117117",
      "id" : 1549117117
    }, {
      "name" : "Brian Lopez",
      "screen_name" : "brianmario",
      "indices" : [ 107, 118 ],
      "id_str" : "9994542",
      "id" : 9994542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8733465704",
  "geo" : { },
  "id_str" : "8733566125",
  "in_reply_to_user_id" : 16476741,
  "text" : "@merbist hash for marshal\/yajl seem basically equivalent, have you seen http:\/\/gist.github.com\/296828 from @brianmario?",
  "id" : 8733566125,
  "in_reply_to_status_id" : 8733465704,
  "created_at" : "2010-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 15, 25 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8734104800",
  "text" : "Redis spec for @gemcutter downloads: http:\/\/gist.github.com\/296921 If only it could code itself. Feedback welcome!",
  "id" : 8734104800,
  "created_at" : "2010-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8734615192",
  "text" : "\"Anyone from NYC here? I play this song in the subway...\" Oh god.",
  "id" : 8734615192,
  "created_at" : "2010-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    }, {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 46, 55 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8735000166",
  "geo" : { },
  "id_str" : "8735088013",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez Great idea, fixed the cron spec. And @roidrage, either that or have thousands of counters for daily values...which would suck.",
  "id" : 8735088013,
  "in_reply_to_status_id" : 8735000166,
  "created_at" : "2010-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8737151597",
  "text" : "AWKWARD LEVELS AT MAXIMUM CAPACITY....trying to sing along with the audience.",
  "id" : 8737151597,
  "created_at" : "2010-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8738275565",
  "text" : "I'm at Java Wally's (90 Lomb Memorial Drive, Rochester) w\/ 3 others. http:\/\/4sq.com\/6pTb3i",
  "id" : 8738275565,
  "created_at" : "2010-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8741138728",
  "text" : "I'm at Wegmans - Calkins Rd (745 Calkins Rd., Rochester). http:\/\/4sq.com\/8vSh45",
  "id" : 8741138728,
  "created_at" : "2010-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8728461370",
  "text" : "Maybe this is a stupid question... Is parsing a hash in Ruby's Marshal or JSON going to be faster?",
  "id" : 8728461370,
  "created_at" : "2010-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 67, 77 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8728824716",
  "geo" : { },
  "id_str" : "8729049464",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham yeah...i'm favoring JSON, just since we can expose it via @gemcutter's api at some point. (fixing the downloads table)",
  "id" : 8729049464,
  "in_reply_to_status_id" : 8728824716,
  "created_at" : "2010-02-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8657906786",
  "text" : "A Maturity Model for SCM, or, why git\/hg own: http:\/\/lucas-ward.blogspot.com\/2010\/02\/maturity-model-for-source-control-scmm.html",
  "id" : 8657906786,
  "created_at" : "2010-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 3, 12 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8660618970",
  "text" : "RT @rubygems: rails (3.0.0.beta): Full-stack web-application framework. http:\/\/bit.ly\/7CwXv9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8660557607",
    "text" : "rails (3.0.0.beta): Full-stack web-application framework. http:\/\/bit.ly\/7CwXv9",
    "id" : 8660557607,
    "created_at" : "2010-02-05 03:04:04 +0000",
    "user" : {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "protected" : false,
      "id_str" : "14881835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651086638\/rubygems-125x125t_normal.png",
      "id" : 14881835,
      "verified" : false
    }
  },
  "id" : 8660618970,
  "created_at" : "2010-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8664855985",
  "text" : "Video: \u201CTom Sawyer built a raft and floated down a river with a black guy, I read the book!\u201D http:\/\/tumblr.com\/x1765dadu",
  "id" : 8664855985,
  "created_at" : "2010-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 49, 59 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8667447597",
  "text" : "Loving these graphs of huge performance wins for @gemcutter. More coming this month I hope! http:\/\/is.gd\/7JSTa",
  "id" : 8667447597,
  "created_at" : "2010-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandora",
      "screen_name" : "pandora_radio",
      "indices" : [ 38, 52 ],
      "id_str" : "5796972",
      "id" : 5796972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8680785529",
  "text" : "Pianobar finally compiles on OSX! Get @Pandora_radio in your terminal: http:\/\/github.com\/PromyLOPh\/pianobar",
  "id" : 8680785529,
  "created_at" : "2010-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8680820484",
  "geo" : { },
  "id_str" : "8681168034",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza I don't use your fancy upgraded versions of OSX, I'm still on 10.5.",
  "id" : 8681168034,
  "in_reply_to_status_id" : 8680820484,
  "created_at" : "2010-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8681354964",
  "geo" : { },
  "id_str" : "8681485234",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza I really don't see a reason to upgrade, still. I'd rather just wait until I have a new box to set up to bother.",
  "id" : 8681485234,
  "in_reply_to_status_id" : 8681354964,
  "created_at" : "2010-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8681354964",
  "geo" : { },
  "id_str" : "8681724341",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza I also hop between Vista, Ubuntu, and OSX on a daily basis. Consistency is key, not so much the latest OS.",
  "id" : 8681724341,
  "in_reply_to_status_id" : 8681354964,
  "created_at" : "2010-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIT",
      "indices" : [ 41, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8687366859",
  "text" : "Supposedly there's something going on at #RIT...ice rink forming behind Gracies, rail park\/snow ramps behind the tiger statues.",
  "id" : 8687366859,
  "created_at" : "2010-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8691051379",
  "text" : "git config --global alias.ch \"\\!git log master..origin\/master | git shortlog\"",
  "id" : 8691051379,
  "created_at" : "2010-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 3, 14 ],
      "id_str" : "14086000",
      "id" : 14086000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8694652683",
  "text" : "RT @timocratic: Alaska fuck yeah! http:\/\/vimeo.com\/7577554",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8694585536",
    "text" : "Alaska fuck yeah! http:\/\/vimeo.com\/7577554",
    "id" : 8694585536,
    "created_at" : "2010-02-05 21:40:43 +0000",
    "user" : {
      "name" : "You",
      "screen_name" : "timocratic",
      "protected" : false,
      "id_str" : "14086000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493904815840186369\/9GCLtaKC_normal.png",
      "id" : 14086000,
      "verified" : false
    }
  },
  "id" : 8694652683,
  "created_at" : "2010-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Hodges",
      "screen_name" : "jmhodges",
      "indices" : [ 0, 9 ],
      "id_str" : "9267272",
      "id" : 9267272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8698698835",
  "geo" : { },
  "id_str" : "8698906179",
  "in_reply_to_user_id" : 9267272,
  "text" : "@jmhodges what use case?",
  "id" : 8698906179,
  "in_reply_to_status_id" : 8698698835,
  "created_at" : "2010-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "jmhodges",
  "in_reply_to_user_id_str" : "9267272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Hodges",
      "screen_name" : "jmhodges",
      "indices" : [ 0, 9 ],
      "id_str" : "9267272",
      "id" : 9267272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8698932589",
  "geo" : { },
  "id_str" : "8698992931",
  "in_reply_to_user_id" : 9267272,
  "text" : "@jmhodges i want to have shared api keys, just other things have been more important. http:\/\/github.com\/qrush\/gemcutter\/issues#issue\/152",
  "id" : 8698992931,
  "in_reply_to_status_id" : 8698932589,
  "created_at" : "2010-02-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "jmhodges",
  "in_reply_to_user_id_str" : "9267272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyFlow",
      "screen_name" : "rubyflow",
      "indices" : [ 3, 12 ],
      "id_str" : "14482752",
      "id" : 14482752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8611239125",
  "text" : "RT @rubyflow: Using Gemcutter's API from the Commandline http:\/\/bit.ly\/d3Q1aQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8608738921",
    "text" : "Using Gemcutter's API from the Commandline http:\/\/bit.ly\/d3Q1aQ",
    "id" : 8608738921,
    "created_at" : "2010-02-03 23:43:22 +0000",
    "user" : {
      "name" : "RubyFlow",
      "screen_name" : "rubyflow",
      "protected" : false,
      "id_str" : "14482752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53166491\/apple-touch-icon_normal.png",
      "id" : 14482752,
      "verified" : false
    }
  },
  "id" : 8611239125,
  "created_at" : "2010-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8612188670",
  "text" : "I'm at TC Riley's (200 Park Point Dr, Rochester). http:\/\/4sq.com\/6QibLZ",
  "id" : 8612188670,
  "created_at" : "2010-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray Krueger",
      "screen_name" : "raykrueger",
      "indices" : [ 0, 11 ],
      "id_str" : "5778932",
      "id" : 5778932
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 66, 76 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8613977635",
  "geo" : { },
  "id_str" : "8614762686",
  "in_reply_to_user_id" : 5778932,
  "text" : "@RayKrueger I think you're confused, bundler is for dependencies. @gemcutter uses bundler: http:\/\/is.gd\/7EJm3",
  "id" : 8614762686,
  "in_reply_to_status_id" : 8613977635,
  "created_at" : "2010-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "raykrueger",
  "in_reply_to_user_id_str" : "5778932",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Seifer",
      "screen_name" : "jseifer",
      "indices" : [ 0, 8 ],
      "id_str" : "1714531",
      "id" : 1714531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8615362030",
  "geo" : { },
  "id_str" : "8615715958",
  "in_reply_to_user_id" : 1714531,
  "text" : "@jseifer been to http:\/\/gems.rubyforge.org lately? :) We'll be moving to http:\/\/rubygems.org soon! (all URLs will still work)",
  "id" : 8615715958,
  "in_reply_to_status_id" : 8615362030,
  "created_at" : "2010-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "jseifer",
  "in_reply_to_user_id_str" : "1714531",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8618597646",
  "geo" : { },
  "id_str" : "8618660066",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham just worked for me http:\/\/pastie.org\/808843",
  "id" : 8618660066,
  "in_reply_to_status_id" : 8618597646,
  "created_at" : "2010-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8618947705",
  "text" : "@jseiferno thanks! and will do. full story was here: http:\/\/update.gemcutter.org\/2009\/10\/26\/transition.html",
  "id" : 8618947705,
  "created_at" : "2010-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8635073558",
  "text" : "The Rails Module (in Rails 3): http:\/\/short.to\/15yo6",
  "id" : 8635073558,
  "created_at" : "2010-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Souza",
      "screen_name" : "rafaelss",
      "indices" : [ 0, 9 ],
      "id_str" : "8539552",
      "id" : 8539552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8638341357",
  "geo" : { },
  "id_str" : "8638687541",
  "in_reply_to_user_id" : 8539552,
  "text" : "@rafaelss what version of rubygems are you on?",
  "id" : 8638687541,
  "in_reply_to_status_id" : 8638341357,
  "created_at" : "2010-02-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "rafaelss",
  "in_reply_to_user_id_str" : "8539552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 15, 23 ],
      "id_str" : "22682102",
      "id" : 22682102
    }, {
      "name" : "Francisco ruiz",
      "screen_name" : "Paco36",
      "indices" : [ 25, 32 ],
      "id_str" : "2460224676",
      "id" : 2460224676
    }, {
      "name" : "nikki graziano",
      "screen_name" : "nikkigraziano",
      "indices" : [ 38, 52 ],
      "id_str" : "12914422",
      "id" : 12914422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8639464965",
  "text" : "At Java's with @dmansen, @paco36, and @nikkigraziano (who made http:\/\/www.wired.com\/magazine\/2010\/01\/pl_arts_found\/ !)",
  "id" : 8639464965,
  "created_at" : "2010-02-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8568924083",
  "text" : "FINAL SEASON OF LOST FINALLY PEOPLE CAN STOP TALKING ABOUT THIS STUPID CRAPPY SHOW. OMG SO EXCITED!",
  "id" : 8568924083,
  "created_at" : "2010-02-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8570374076",
  "text" : "Are there any decent alternatives to quicksilver? It seems to forget everything in Applications after a day of running, rescan doesn't help.",
  "id" : 8570374076,
  "created_at" : "2010-02-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Richards",
      "screen_name" : "noahsmark",
      "indices" : [ 75, 85 ],
      "id_str" : "14198565",
      "id" : 14198565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8570825991",
  "text" : "Trying out google's quick search: http:\/\/code.google.com\/p\/qsb-mac\/ Thanks @noahsmark.",
  "id" : 8570825991,
  "created_at" : "2010-02-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 3, 11 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8572318439",
  "text" : "RT @zedshaw: Man, how far microsoft has come in security: http:\/\/imgur.com\/83POx.gif",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8572053074",
    "text" : "Man, how far microsoft has come in security: http:\/\/imgur.com\/83POx.gif",
    "id" : 8572053074,
    "created_at" : "2010-02-03 03:23:19 +0000",
    "user" : {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "protected" : false,
      "id_str" : "15029296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572162070242529280\/jB3uzB2E_normal.jpeg",
      "id" : 15029296,
      "verified" : false
    }
  },
  "id" : 8572318439,
  "created_at" : "2010-02-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "indices" : [ 57, 70 ],
      "id_str" : "1341781",
      "id" : 1341781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8574774782",
  "text" : "For the first time in years I have a blog rant worthy of @gilesgoatboy proportions, but tests and papers block me. Boohiss.",
  "id" : 8574774782,
  "created_at" : "2010-02-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8593658762",
  "text" : "One of these days I need to do some serious Python. http:\/\/blog.peepcode.com\/tutorials\/2010\/what-pythonistas-think-of-ruby",
  "id" : 8593658762,
  "created_at" : "2010-02-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8597309791",
  "text" : "I'm at Java Wally's (90 Lomb Memorial Drive, Rochester). http:\/\/4sq.com\/6pTb3i",
  "id" : 8597309791,
  "created_at" : "2010-02-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 0, 11 ],
      "id_str" : "4243",
      "id" : 4243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8598750612",
  "geo" : { },
  "id_str" : "8598910758",
  "in_reply_to_user_id" : 4243,
  "text" : "@jnunemaker Kernel.awesome!",
  "id" : 8598910758,
  "in_reply_to_status_id" : 8598750612,
  "created_at" : "2010-02-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "jnunemaker",
  "in_reply_to_user_id_str" : "4243",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8600039930",
  "text" : "Bunch of PHP devs talking WordPress in Java's today. Depressing.",
  "id" : 8600039930,
  "created_at" : "2010-02-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8601705572",
  "geo" : { },
  "id_str" : "8602903851",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil I'd have to introduce them to 'reusability' and 'objects', that's just too much work.",
  "id" : 8602903851,
  "in_reply_to_status_id" : 8601705572,
  "created_at" : "2010-02-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lopez",
      "screen_name" : "brianmario",
      "indices" : [ 0, 11 ],
      "id_str" : "9994542",
      "id" : 9994542
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 100, 110 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8606321757",
  "geo" : { },
  "id_str" : "8607353056",
  "in_reply_to_user_id" : 9994542,
  "text" : "@brianmario haven't touched it in a while...going to wait until the official beta is out to convert @gemcutter.",
  "id" : 8607353056,
  "in_reply_to_status_id" : 8606321757,
  "created_at" : "2010-02-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "brianmario",
  "in_reply_to_user_id_str" : "9994542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 0, 11 ],
      "id_str" : "14086000",
      "id" : 14086000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8520506308",
  "geo" : { },
  "id_str" : "8520545460",
  "in_reply_to_user_id" : 14086000,
  "text" : "@timocratic usually we try to contact the original author, they've been responsive so far",
  "id" : 8520545460,
  "in_reply_to_status_id" : 8520506308,
  "created_at" : "2010-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "timocratic",
  "in_reply_to_user_id_str" : "14086000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 0, 11 ],
      "id_str" : "14086000",
      "id" : 14086000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8520564910",
  "geo" : { },
  "id_str" : "8520705537",
  "in_reply_to_user_id" : 14086000,
  "text" : "@timocratic crack open a new issue at http:\/\/help.rubygems.org and we'll figure it out",
  "id" : 8520705537,
  "in_reply_to_status_id" : 8520564910,
  "created_at" : "2010-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "timocratic",
  "in_reply_to_user_id_str" : "14086000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8526189131",
  "text" : "Scratching a project for the first time ever in Rebase, since after 3 hours, I still can't run it. My Lisp beard just isn't big enough.",
  "id" : 8526189131,
  "created_at" : "2010-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8528768132",
  "text" : "Can run a python project either. I quit programming for tonight.",
  "id" : 8528768132,
  "created_at" : "2010-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Schierbeck",
      "screen_name" : "dasch",
      "indices" : [ 0, 6 ],
      "id_str" : "6146372",
      "id" : 6146372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8539426750",
  "geo" : { },
  "id_str" : "8543463418",
  "in_reply_to_user_id" : 6146372,
  "text" : "@dasch yep, open an issue at http:\/\/help.rubygems.org and we'll handle it",
  "id" : 8543463418,
  "in_reply_to_status_id" : 8539426750,
  "created_at" : "2010-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "dasch",
  "in_reply_to_user_id_str" : "6146372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8544762176",
  "text" : "A ton of dust has sneaked into my droid's screen from where the speaker is. Not cool.",
  "id" : 8544762176,
  "created_at" : "2010-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Sharp",
      "screen_name" : "ajsharp",
      "indices" : [ 0, 8 ],
      "id_str" : "18071073",
      "id" : 18071073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8552625705",
  "geo" : { },
  "id_str" : "8553703986",
  "in_reply_to_user_id" : 18071073,
  "text" : "@ajsharp Seems to be up here, pingdom would be yelling at me if not. Was the site just responding slowly?",
  "id" : 8553703986,
  "in_reply_to_status_id" : 8552625705,
  "created_at" : "2010-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "ajsharp",
  "in_reply_to_user_id_str" : "18071073",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 3, 8 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8554867798",
  "text" : "RT @avdi: Gemcutter and Caliper are now integrated: http:\/\/bit.ly\/cYL1gs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mylife.threadsy.com\" rel=\"nofollow\"\u003Ethreadsy\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8554626264",
    "text" : "Gemcutter and Caliper are now integrated: http:\/\/bit.ly\/cYL1gs",
    "id" : 8554626264,
    "created_at" : "2010-02-02 19:27:56 +0000",
    "user" : {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "protected" : false,
      "id_str" : "52593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436586539229777920\/4NQoTOEN_normal.png",
      "id" : 52593,
      "verified" : false
    }
  },
  "id" : 8554867798,
  "created_at" : "2010-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Phillips",
      "screen_name" : "jicksta",
      "indices" : [ 0, 8 ],
      "id_str" : "753783",
      "id" : 753783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8560546073",
  "geo" : { },
  "id_str" : "8562374624",
  "in_reply_to_user_id" : 753783,
  "text" : "@jicksta it's not down here...maybe your DNS is wacky? heard some reports of this a few hours ago",
  "id" : 8562374624,
  "in_reply_to_status_id" : 8560546073,
  "created_at" : "2010-02-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "jicksta",
  "in_reply_to_user_id_str" : "753783",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
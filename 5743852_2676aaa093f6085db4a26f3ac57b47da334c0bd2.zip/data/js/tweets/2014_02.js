Grailbird.data.tweets_2014_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/439614692038701056\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/S9i3AYM2I7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhnTO5xCUAErxPn.jpg",
      "id_str" : "439614691623456769",
      "id" : 439614691623456769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhnTO5xCUAErxPn.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/S9i3AYM2I7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439614692038701056",
  "text" : "Pandemic on Hangouts commencing! This setup is equally as ridiculous. http:\/\/t.co\/S9i3AYM2I7",
  "id" : 439614692038701056,
  "created_at" : "2014-03-01 04:14:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 0, 7 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439600178048139264",
  "geo" : { },
  "id_str" : "439604133994037248",
  "in_reply_to_user_id" : 15317640,
  "text" : "@hone02 mostly making it up as we go along! Using MacBook webcams seem to have the best resolution though.",
  "id" : 439604133994037248,
  "in_reply_to_status_id" : 439600178048139264,
  "created_at" : "2014-03-01 03:32:47 +0000",
  "in_reply_to_screen_name" : "hone02",
  "in_reply_to_user_id_str" : "15317640",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/439603987453853696\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/XXvtuSGVdQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhnJfzqIIAAFRkh.jpg",
      "id_str" : "439603986925363200",
      "id" : 439603986925363200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhnJfzqIIAAFRkh.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/XXvtuSGVdQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439603987453853696",
  "text" : "Lazy blue beach dwellers continue to fizzle. http:\/\/t.co\/XXvtuSGVdQ",
  "id" : 439603987453853696,
  "created_at" : "2014-03-01 03:32:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/439598248269869056\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/EeguqmFA3r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhnERwHCYAAJYWD.jpg",
      "id_str" : "439598247896571904",
      "id" : 439598247896571904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhnERwHCYAAJYWD.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/EeguqmFA3r"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439598248269869056",
  "text" : "Settlers on Hangouts in progress. Not looking good for my blues. http:\/\/t.co\/EeguqmFA3r",
  "id" : 439598248269869056,
  "created_at" : "2014-03-01 03:09:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alberto De Lucca ",
      "screen_name" : "adeluccar",
      "indices" : [ 0, 10 ],
      "id_str" : "174408001",
      "id" : 174408001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439596731416989696",
  "geo" : { },
  "id_str" : "439597125517979648",
  "in_reply_to_user_id" : 174408001,
  "text" : "@adeluccar yes.",
  "id" : 439597125517979648,
  "in_reply_to_status_id" : 439596731416989696,
  "created_at" : "2014-03-01 03:04:56 +0000",
  "in_reply_to_screen_name" : "adeluccar",
  "in_reply_to_user_id_str" : "174408001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alberto De Lucca ",
      "screen_name" : "adeluccar",
      "indices" : [ 0, 10 ],
      "id_str" : "174408001",
      "id" : 174408001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439596580577243136",
  "geo" : { },
  "id_str" : "439597092240371715",
  "in_reply_to_user_id" : 174408001,
  "text" : "@adeluccar it's already complicated enough remotely. Haven't ever had this problem and doubtful it will come up.",
  "id" : 439597092240371715,
  "in_reply_to_status_id" : 439596580577243136,
  "created_at" : "2014-03-01 03:04:48 +0000",
  "in_reply_to_screen_name" : "adeluccar",
  "in_reply_to_user_id_str" : "174408001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alberto De Lucca ",
      "screen_name" : "adeluccar",
      "indices" : [ 0, 10 ],
      "id_str" : "174408001",
      "id" : 174408001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439594296061460480",
  "geo" : { },
  "id_str" : "439596040585363456",
  "in_reply_to_user_id" : 174408001,
  "text" : "@adeluccar I have never run out of resource cards even in 4 player games.",
  "id" : 439596040585363456,
  "in_reply_to_status_id" : 439594296061460480,
  "created_at" : "2014-03-01 03:00:38 +0000",
  "in_reply_to_screen_name" : "adeluccar",
  "in_reply_to_user_id_str" : "174408001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alberto De Lucca ",
      "screen_name" : "adeluccar",
      "indices" : [ 0, 10 ],
      "id_str" : "174408001",
      "id" : 174408001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439593311683497984",
  "geo" : { },
  "id_str" : "439593719755325440",
  "in_reply_to_user_id" : 174408001,
  "text" : "@adeluccar trades are announced...not sure what a buffer is needed for",
  "id" : 439593719755325440,
  "in_reply_to_status_id" : 439593311683497984,
  "created_at" : "2014-03-01 02:51:24 +0000",
  "in_reply_to_screen_name" : "adeluccar",
  "in_reply_to_user_id_str" : "174408001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alberto De Lucca ",
      "screen_name" : "adeluccar",
      "indices" : [ 0, 10 ],
      "id_str" : "174408001",
      "id" : 174408001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439591288028278784",
  "geo" : { },
  "id_str" : "439591978645200896",
  "in_reply_to_user_id" : 174408001,
  "text" : "@adeluccar each board keeps resources and announce rolls. Dev card has one master deck and revealed to the camera.",
  "id" : 439591978645200896,
  "in_reply_to_status_id" : 439591288028278784,
  "created_at" : "2014-03-01 02:44:29 +0000",
  "in_reply_to_screen_name" : "adeluccar",
  "in_reply_to_user_id_str" : "174408001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/439589147720687617\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/q8fnn5XF2c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhm8ACDCYAAewLr.jpg",
      "id_str" : "439589147380965376",
      "id" : 439589147380965376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhm8ACDCYAAewLr.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/q8fnn5XF2c"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439589147720687617",
  "text" : "Easily the most ridiculous Settlers setup to date http:\/\/t.co\/q8fnn5XF2c",
  "id" : 439589147720687617,
  "created_at" : "2014-03-01 02:33:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439587479159468032",
  "text" : "Current status: playing Settlers over Hangouts and syncing two boards.",
  "id" : 439587479159468032,
  "created_at" : "2014-03-01 02:26:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simulator Generator",
      "screen_name" : "SimGenerator",
      "indices" : [ 3, 16 ],
      "id_str" : "2282369803",
      "id" : 2282369803
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SimGenerator\/status\/439354322519080960\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/woVlrLqAth",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhjmba8IEAAN8vV.png",
      "id_str" : "439354322430988288",
      "id" : 439354322430988288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhjmba8IEAAN8vV.png",
      "sizes" : [ {
        "h" : 352,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 450
      } ],
      "display_url" : "pic.twitter.com\/woVlrLqAth"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439555116929007616",
  "text" : "RT @SimGenerator: Project Manager Simulator 2009 http:\/\/t.co\/woVlrLqAth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/github.com\/sjml\/SimulatorGenerator\/\" rel=\"nofollow\"\u003ESimulator Generator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SimGenerator\/status\/439354322519080960\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/woVlrLqAth",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhjmba8IEAAN8vV.png",
        "id_str" : "439354322430988288",
        "id" : 439354322430988288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhjmba8IEAAN8vV.png",
        "sizes" : [ {
          "h" : 352,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 450
        } ],
        "display_url" : "pic.twitter.com\/woVlrLqAth"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439354322519080960",
    "text" : "Project Manager Simulator 2009 http:\/\/t.co\/woVlrLqAth",
    "id" : 439354322519080960,
    "created_at" : "2014-02-28 11:00:07 +0000",
    "user" : {
      "name" : "Simulator Generator",
      "screen_name" : "SimGenerator",
      "protected" : false,
      "id_str" : "2282369803",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421206344289374208\/2dlPf4ax_normal.png",
      "id" : 2282369803,
      "verified" : false
    }
  },
  "id" : 439555116929007616,
  "created_at" : "2014-03-01 00:18:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439545038327250944",
  "geo" : { },
  "id_str" : "439551361978339328",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo where does one get this",
  "id" : 439551361978339328,
  "in_reply_to_status_id" : 439545038327250944,
  "created_at" : "2014-03-01 00:03:05 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 37, 47 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439544097167007744",
  "text" : "Commandereed the TV to watch TPP. If @aquaranto gets the Oscars Sunday...well, we need to beat BLUE by then.",
  "id" : 439544097167007744,
  "created_at" : "2014-02-28 23:34:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "indices" : [ 0, 8 ],
      "id_str" : "19041990",
      "id" : 19041990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439540871671730176",
  "geo" : { },
  "id_str" : "439541317727551488",
  "in_reply_to_user_id" : 19041990,
  "text" : "@kkuchta yeah I saw that.",
  "id" : 439541317727551488,
  "in_reply_to_status_id" : 439540871671730176,
  "created_at" : "2014-02-28 23:23:11 +0000",
  "in_reply_to_screen_name" : "kkuchta",
  "in_reply_to_user_id_str" : "19041990",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/GnhAZq3SUR",
      "expanded_url" : "https:\/\/twitter.com\/TwitchPokemon\/status\/439533666000060416",
      "display_url" : "twitter.com\/TwitchPokemon\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439539872546578432",
  "text" : "Or maybe I missed it already?! https:\/\/t.co\/GnhAZq3SUR",
  "id" : 439539872546578432,
  "created_at" : "2014-02-28 23:17:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439539608439644160",
  "text" : "I need an SMS hook for TPP. If Red defeats an Elite Four trainer, then text me (so I can watch the final!)",
  "id" : 439539608439644160,
  "created_at" : "2014-02-28 23:16:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Eats",
      "screen_name" : "BuffaloEats",
      "indices" : [ 0, 12 ],
      "id_str" : "21758029",
      "id" : 21758029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439536999637073920",
  "geo" : { },
  "id_str" : "439539100925054976",
  "in_reply_to_user_id" : 21758029,
  "text" : "@BuffaloEats *steals one to put on an Applebee's*",
  "id" : 439539100925054976,
  "in_reply_to_status_id" : 439536999637073920,
  "created_at" : "2014-02-28 23:14:22 +0000",
  "in_reply_to_screen_name" : "BuffaloEats",
  "in_reply_to_user_id_str" : "21758029",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 0, 13 ],
      "id_str" : "257495729",
      "id" : 257495729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439504243570257921",
  "geo" : { },
  "id_str" : "439508133384564736",
  "in_reply_to_user_id" : 257495729,
  "text" : "@TommyCreenan Just put it up on the chromecast if you want to watch over here!",
  "id" : 439508133384564736,
  "in_reply_to_status_id" : 439504243570257921,
  "created_at" : "2014-02-28 21:11:19 +0000",
  "in_reply_to_screen_name" : "TommyCreenan",
  "in_reply_to_user_id_str" : "257495729",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/NZnSpb6K7b",
      "expanded_url" : "http:\/\/www.twitch.tv\/twitchplayspokemon",
      "display_url" : "twitch.tv\/twitchplayspok\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439504264835395584",
  "text" : "Why isn't there an announcer for Twitch Plays Pokemon!!? Elite Four DOWN!! How is this even possible? http:\/\/t.co\/NZnSpb6K7b",
  "id" : 439504264835395584,
  "created_at" : "2014-02-28 20:55:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439503594287820800",
  "text" : "RT @sstephenson: MVC is not just a set of boxes for things to fit into. Controllers emerge naturally by decoupling interface from implement\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439502711248392193",
    "text" : "MVC is not just a set of boxes for things to fit into. Controllers emerge naturally by decoupling interface from implementation.",
    "id" : 439502711248392193,
    "created_at" : "2014-02-28 20:49:46 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 439503594287820800,
  "created_at" : "2014-02-28 20:53:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEO Kaz Hirai",
      "screen_name" : "KazHiraiCEO",
      "indices" : [ 3, 15 ],
      "id_str" : "246318475",
      "id" : 246318475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439502603442192384",
  "text" : "RT @KazHiraiCEO: Twitch Plays Pokemon is Nintendo's first successful online multiplayer game ever",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439501855476178944",
    "text" : "Twitch Plays Pokemon is Nintendo's first successful online multiplayer game ever",
    "id" : 439501855476178944,
    "created_at" : "2014-02-28 20:46:22 +0000",
    "user" : {
      "name" : "CEO Kaz Hirai",
      "screen_name" : "KazHiraiCEO",
      "protected" : false,
      "id_str" : "246318475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3312450384\/04f7f08f8cff85fcc32f93dae6065c70_normal.jpeg",
      "id" : 246318475,
      "verified" : false
    }
  },
  "id" : 439502603442192384,
  "created_at" : "2014-02-28 20:49:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    }, {
      "name" : "The Melissa Virus",
      "screen_name" : "0xabad1dea",
      "indices" : [ 13, 24 ],
      "id_str" : "126030998",
      "id" : 126030998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439502306619707392",
  "geo" : { },
  "id_str" : "439502447460233216",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded @0xabad1dea it's ok, ATV HAS GOT THIS!!!! Oh wait.",
  "id" : 439502447460233216,
  "in_reply_to_status_id" : 439502306619707392,
  "created_at" : "2014-02-28 20:48:43 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Melissa Virus",
      "screen_name" : "0xabad1dea",
      "indices" : [ 0, 11 ],
      "id_str" : "126030998",
      "id" : 126030998
    }, {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 12, 24 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439501876548354048",
  "geo" : { },
  "id_str" : "439502172041248768",
  "in_reply_to_user_id" : 126030998,
  "text" : "@0xabad1dea @starguarded oh man it was so close. AA-j needs to live longer.",
  "id" : 439502172041248768,
  "in_reply_to_status_id" : 439501876548354048,
  "created_at" : "2014-02-28 20:47:38 +0000",
  "in_reply_to_screen_name" : "0xabad1dea",
  "in_reply_to_user_id_str" : "126030998",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/NZnSpb6K7b",
      "expanded_url" : "http:\/\/www.twitch.tv\/twitchplayspokemon",
      "display_url" : "twitch.tv\/twitchplayspok\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439500092891217920",
  "text" : "3\/4 of the Elite Four down. http:\/\/t.co\/NZnSpb6K7b is getting intense!",
  "id" : 439500092891217920,
  "created_at" : "2014-02-28 20:39:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "5 Nights at Jamie's*",
      "screen_name" : "death2normalcy",
      "indices" : [ 0, 15 ],
      "id_str" : "129537034",
      "id" : 129537034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439492981729787904",
  "geo" : { },
  "id_str" : "439496311147339776",
  "in_reply_to_user_id" : 129537034,
  "text" : "@death2normalcy SPAM THUNDERSHOCK!!",
  "id" : 439496311147339776,
  "in_reply_to_status_id" : 439492981729787904,
  "created_at" : "2014-02-28 20:24:20 +0000",
  "in_reply_to_screen_name" : "death2normalcy",
  "in_reply_to_user_id_str" : "129537034",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/73owzlcLoX",
      "expanded_url" : "http:\/\/www.ashedryden.com\/blog\/the-responsibility-of-diversity",
      "display_url" : "ashedryden.com\/blog\/the-respo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439490101639659520",
  "text" : "Q: Who's job is \"diversity\"? A: Everyone's: http:\/\/t.co\/73owzlcLoX",
  "id" : 439490101639659520,
  "created_at" : "2014-02-28 19:59:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "5 Nights at Jamie's*",
      "screen_name" : "death2normalcy",
      "indices" : [ 0, 15 ],
      "id_str" : "129537034",
      "id" : 129537034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439476296469716993",
  "geo" : { },
  "id_str" : "439477551912595456",
  "in_reply_to_user_id" : 129537034,
  "text" : "@death2normalcy wow! I haven't watched since Giovanni. This is going to take forever. I remember needing to full restore after every battle.",
  "id" : 439477551912595456,
  "in_reply_to_status_id" : 439476296469716993,
  "created_at" : "2014-02-28 19:09:48 +0000",
  "in_reply_to_screen_name" : "death2normalcy",
  "in_reply_to_user_id_str" : "129537034",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "indices" : [ 0, 8 ],
      "id_str" : "19041990",
      "id" : 19041990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439471750942707712",
  "geo" : { },
  "id_str" : "439471880345382912",
  "in_reply_to_user_id" : 19041990,
  "text" : "@kkuchta nothing so far.",
  "id" : 439471880345382912,
  "in_reply_to_status_id" : 439471750942707712,
  "created_at" : "2014-02-28 18:47:15 +0000",
  "in_reply_to_screen_name" : "kkuchta",
  "in_reply_to_user_id_str" : "19041990",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439441362824331265",
  "text" : "Gifs folder up to 2.5 GB thanks to IFTTT. I don't have a problem, right?",
  "id" : 439441362824331265,
  "created_at" : "2014-02-28 16:45:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francis Hwang",
      "screen_name" : "fhwang",
      "indices" : [ 3, 10 ],
      "id_str" : "5465442",
      "id" : 5465442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439397283092639744",
  "text" : "RT @fhwang: This is just to say\n\nI have spread\nthe 2s and 1s\nall around\nthe board\n\nForgive me\nI was\nthis close\nto a 192",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439393183894495233",
    "text" : "This is just to say\n\nI have spread\nthe 2s and 1s\nall around\nthe board\n\nForgive me\nI was\nthis close\nto a 192",
    "id" : 439393183894495233,
    "created_at" : "2014-02-28 13:34:33 +0000",
    "user" : {
      "name" : "Francis Hwang",
      "screen_name" : "fhwang",
      "protected" : false,
      "id_str" : "5465442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2376521174\/1v446gykne4k7og1m0bn_normal.jpeg",
      "id" : 5465442,
      "verified" : false
    }
  },
  "id" : 439397283092639744,
  "created_at" : "2014-02-28 13:50:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Petty",
      "screen_name" : "lodestone",
      "indices" : [ 0, 10 ],
      "id_str" : "12413652",
      "id" : 12413652
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 11, 15 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439372406029688832",
  "geo" : { },
  "id_str" : "439373228734046208",
  "in_reply_to_user_id" : 12413652,
  "text" : "@lodestone @dhh X100S",
  "id" : 439373228734046208,
  "in_reply_to_status_id" : 439372406029688832,
  "created_at" : "2014-02-28 12:15:15 +0000",
  "in_reply_to_screen_name" : "lodestone",
  "in_reply_to_user_id_str" : "12413652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439365357447675905",
  "geo" : { },
  "id_str" : "439370512305635328",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh yep almost exactly the settings I was on. That Q button is my favorite.",
  "id" : 439370512305635328,
  "in_reply_to_status_id" : 439365357447675905,
  "created_at" : "2014-02-28 12:04:27 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Jenks",
      "screen_name" : "yeabuddy",
      "indices" : [ 0, 9 ],
      "id_str" : "10447232",
      "id" : 10447232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439256816200187904",
  "geo" : { },
  "id_str" : "439263424589987840",
  "in_reply_to_user_id" : 10447232,
  "text" : "@yeabuddy biking (especially with my husky) is great in the summer. Maybe lack of vitamin D has me down",
  "id" : 439263424589987840,
  "in_reply_to_status_id" : 439256816200187904,
  "created_at" : "2014-02-28 04:58:56 +0000",
  "in_reply_to_screen_name" : "yeabuddy",
  "in_reply_to_user_id_str" : "10447232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naaman",
      "screen_name" : "naaman",
      "indices" : [ 0, 7 ],
      "id_str" : "15430619",
      "id" : 15430619
    }, {
      "name" : "Doug Yun",
      "screen_name" : "dougyun",
      "indices" : [ 8, 16 ],
      "id_str" : "324160285",
      "id" : 324160285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439259201911533568",
  "geo" : { },
  "id_str" : "439263196881637376",
  "in_reply_to_user_id" : 15430619,
  "text" : "@naaman @dougyun tried and failed a few times to pick up guitar and bass. Perhaps need to try something else.",
  "id" : 439263196881637376,
  "in_reply_to_status_id" : 439259201911533568,
  "created_at" : "2014-02-28 04:58:01 +0000",
  "in_reply_to_screen_name" : "naaman",
  "in_reply_to_user_id_str" : "15430619",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    }, {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 22, 28 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439254756549095424",
  "geo" : { },
  "id_str" : "439255378371436544",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith I think @jamis tried this too. Sadly I lack the craftiness (and patience)",
  "id" : 439255378371436544,
  "in_reply_to_status_id" : 439254756549095424,
  "created_at" : "2014-02-28 04:26:57 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439254772059607040",
  "geo" : { },
  "id_str" : "439255080001224705",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr if there's a negative scale I would be somewhere approaching infinite",
  "id" : 439255080001224705,
  "in_reply_to_status_id" : 439254772059607040,
  "created_at" : "2014-02-28 04:25:46 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439254148874125312",
  "text" : "I need to find a hobby that doesn't involve glowing rectangles so when they're all broken or being spied on I can somehow enjoy myself.",
  "id" : 439254148874125312,
  "created_at" : "2014-02-28 04:22:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/3vOry0ZBz1",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Alembic",
      "display_url" : "en.wikipedia.org\/wiki\/Alembic"
    } ]
  },
  "geo" : { },
  "id_str" : "439249119102529536",
  "text" : "Discovered my favorite new unicode symbol: \u2697 ALEMBIC http:\/\/t.co\/3vOry0ZBz1",
  "id" : 439249119102529536,
  "created_at" : "2014-02-28 04:02:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 10, 22 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 23, 38 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439242697262374912",
  "geo" : { },
  "id_str" : "439245889396154368",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo @AqueousBand @UnclePhilsBlog thanks! it was a lot of fun. looking forward to the next one.",
  "id" : 439245889396154368,
  "in_reply_to_status_id" : 439242697262374912,
  "created_at" : "2014-02-28 03:49:15 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439239959967309824",
  "text" : "Also, shooting in low light ain't easy. At least with a Real Camera\u2122\u00AE it's not terrible looking, but blur is hard still.",
  "id" : 439239959967309824,
  "created_at" : "2014-02-28 03:25:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 16, 28 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 99, 114 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 115, 124 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/tlx3Fwek5F",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush\/sets\/72157641634750163\/",
      "display_url" : "flickr.com\/photos\/qrush\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439232555858935808",
  "text" : "Some shots from @AqueousBand's Mystery Artist\/Beatles show, last night: http:\/\/t.co\/tlx3Fwek5F \/cc @UnclePhilsBlog @LawnMemo",
  "id" : 439232555858935808,
  "created_at" : "2014-02-28 02:56:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/19Lct3W4Du",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/style-blog\/wp\/2014\/02\/27\/why-were-actually-mad-at-jeopardy-villain-arthur-chu\/?Post+generic=%3Ftid%3Dsm_twitter_washingtonpost",
      "display_url" : "washingtonpost.com\/blogs\/style-bl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439215491564208129",
  "text" : "\"nonchalantly bulldozing\" is so accurate. Watched for a round tonight and Chu utterly destroyed. http:\/\/t.co\/19Lct3W4Du",
  "id" : 439215491564208129,
  "created_at" : "2014-02-28 01:48:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439188611875864576",
  "text" : "RT @jasonfried: The sooner you ask me to sign an NDA, the less I trust *you*.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431163700997677056",
    "text" : "The sooner you ask me to sign an NDA, the less I trust *you*.",
    "id" : 431163700997677056,
    "created_at" : "2014-02-05 20:33:31 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 439188611875864576,
  "created_at" : "2014-02-28 00:01:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Geddes",
      "screen_name" : "phunnel",
      "indices" : [ 3, 11 ],
      "id_str" : "14381574",
      "id" : 14381574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439186558717927424",
  "text" : "RT @phunnel: Parenting is like helping a noob in an MMO: \"Here, wear this. Don't talk to that guy. You can't use that yet. You'll die if yo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438735344213573633",
    "text" : "Parenting is like helping a noob in an MMO: \"Here, wear this. Don't talk to that guy. You can't use that yet. You'll die if you go there.\"",
    "id" : 438735344213573633,
    "created_at" : "2014-02-26 18:00:32 +0000",
    "user" : {
      "name" : "Ryan Geddes",
      "screen_name" : "phunnel",
      "protected" : false,
      "id_str" : "14381574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447012201472069634\/ZG0zez2a_normal.jpeg",
      "id" : 14381574,
      "verified" : false
    }
  },
  "id" : 439186558717927424,
  "created_at" : "2014-02-27 23:53:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/OgC4hZkX8a",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=C16qJ8bqXjo",
      "display_url" : "youtube.com\/watch?v=C16qJ8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439186462777434112",
  "text" : "THE CIRCLE OF LIFEEEEEEE http:\/\/t.co\/OgC4hZkX8a",
  "id" : 439186462777434112,
  "created_at" : "2014-02-27 23:53:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 0, 12 ],
      "id_str" : "6556972",
      "id" : 6556972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439185901873532928",
  "geo" : { },
  "id_str" : "439186176008679424",
  "in_reply_to_user_id" : 6556972,
  "text" : "@techpickles engagedpickles!!!! congrats!",
  "id" : 439186176008679424,
  "in_reply_to_status_id" : 439185901873532928,
  "created_at" : "2014-02-27 23:51:58 +0000",
  "in_reply_to_screen_name" : "techpickles",
  "in_reply_to_user_id_str" : "6556972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 1, 9 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 10, 21 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 22, 34 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439144543959912448",
  "text" : ".@evanphx @samkottler @dwradcliffe ping in rubygems IRC please!",
  "id" : 439144543959912448,
  "created_at" : "2014-02-27 21:06:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439134114072260609",
  "geo" : { },
  "id_str" : "439134748968222721",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting what terrible registrar did you go through for this?",
  "id" : 439134748968222721,
  "in_reply_to_status_id" : 439134114072260609,
  "created_at" : "2014-02-27 20:27:37 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439133127827816448",
  "geo" : { },
  "id_str" : "439133688912031744",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting dear god, why",
  "id" : 439133688912031744,
  "in_reply_to_status_id" : 439133127827816448,
  "created_at" : "2014-02-27 20:23:24 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/439098734308114432\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/fc86t3Pq2V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhf9-OQCMAAvWLE.jpg",
      "id_str" : "439098734110978048",
      "id" : 439098734110978048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhf9-OQCMAAvWLE.jpg",
      "sizes" : [ {
        "h" : 1520,
        "resize" : "fit",
        "w" : 2688
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/fc86t3Pq2V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439114702862700544",
  "text" : "RT @coworkbuffalo: It actually makes us feel warmer today. http:\/\/t.co\/fc86t3Pq2V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/439098734308114432\/photo\/1",
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/fc86t3Pq2V",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhf9-OQCMAAvWLE.jpg",
        "id_str" : "439098734110978048",
        "id" : 439098734110978048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhf9-OQCMAAvWLE.jpg",
        "sizes" : [ {
          "h" : 1520,
          "resize" : "fit",
          "w" : 2688
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/fc86t3Pq2V"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439098734308114432",
    "text" : "It actually makes us feel warmer today. http:\/\/t.co\/fc86t3Pq2V",
    "id" : 439098734308114432,
    "created_at" : "2014-02-27 18:04:30 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 439114702862700544,
  "created_at" : "2014-02-27 19:07:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/baOMShdfDH",
      "expanded_url" : "https:\/\/twitter.com\/paulg\/status\/439098584378929152",
      "display_url" : "twitter.com\/paulg\/status\/4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439098934930075648",
  "text" : "In case you haven't gotten your dose of \"out of touch with reality today\": https:\/\/t.co\/baOMShdfDH",
  "id" : 439098934930075648,
  "created_at" : "2014-02-27 18:05:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 24, 35 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 40, 49 ],
      "id_str" : "1051521",
      "id" : 1051521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439081599322566656",
  "geo" : { },
  "id_str" : "439082153905647616",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr oh you mean like @kevinpurdy and @migreyes, who both figured out how to install\/get it working? :) lets move this to IM...",
  "id" : 439082153905647616,
  "in_reply_to_status_id" : 439081599322566656,
  "created_at" : "2014-02-27 16:58:37 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439081166730457088",
  "geo" : { },
  "id_str" : "439081395932389376",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr who cares? this has always been a problem with every piece of software. \"people\" will figure it out.",
  "id" : 439081395932389376,
  "in_reply_to_status_id" : 439081166730457088,
  "created_at" : "2014-02-27 16:55:37 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439080782972600320",
  "geo" : { },
  "id_str" : "439081206567952384",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr An alternative goal that achieves the same end: Make jekyll work with ANY ruby.",
  "id" : 439081206567952384,
  "in_reply_to_status_id" : 439080782972600320,
  "created_at" : "2014-02-27 16:54:52 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439080692157546496",
  "geo" : { },
  "id_str" : "439081002338500608",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr not really a problem with jekyll. it's stepping way over the project's bounds to solve it. this isn't Wordpress or InstantRails.",
  "id" : 439081002338500608,
  "in_reply_to_status_id" : 439080692157546496,
  "created_at" : "2014-02-27 16:54:03 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439074066134474753",
  "geo" : { },
  "id_str" : "439074320342470656",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr what is your definition of accessible? not sure why you'd want to maintain dealing with installing ruby on N platforms. also, sure",
  "id" : 439074320342470656,
  "in_reply_to_status_id" : 439074066134474753,
  "created_at" : "2014-02-27 16:27:30 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439073809141092352",
  "geo" : { },
  "id_str" : "439073923326410752",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr I hope you don't go down that path. Sounds terrible.",
  "id" : 439073923326410752,
  "in_reply_to_status_id" : 439073809141092352,
  "created_at" : "2014-02-27 16:25:55 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439072115145584640",
  "geo" : { },
  "id_str" : "439072357643063296",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr what's wrong with just using RubyGems? funny how Rails has gotten away with this for 10 years",
  "id" : 439072357643063296,
  "in_reply_to_status_id" : 439072115145584640,
  "created_at" : "2014-02-27 16:19:42 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 0, 13 ],
      "id_str" : "23820237",
      "id" : 23820237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439031473300332544",
  "geo" : { },
  "id_str" : "439067917817114624",
  "in_reply_to_user_id" : 23820237,
  "text" : "@IanCAnderson what's your game center ID?",
  "id" : 439067917817114624,
  "in_reply_to_status_id" : 439031473300332544,
  "created_at" : "2014-02-27 16:02:03 +0000",
  "in_reply_to_screen_name" : "IanCAnderson",
  "in_reply_to_user_id_str" : "23820237",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 0, 13 ],
      "id_str" : "23820237",
      "id" : 23820237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439031121385644032",
  "geo" : { },
  "id_str" : "439031326298374144",
  "in_reply_to_user_id" : 23820237,
  "text" : "@IanCAnderson you bastard",
  "id" : 439031326298374144,
  "in_reply_to_status_id" : 439031121385644032,
  "created_at" : "2014-02-27 13:36:39 +0000",
  "in_reply_to_screen_name" : "IanCAnderson",
  "in_reply_to_user_id_str" : "23820237",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438914243627610113",
  "geo" : { },
  "id_str" : "438931757832740865",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone you are a true American hero \uD83C\uDDFA\uD83C\uDDF8\uD83C\uDF55",
  "id" : 438931757832740865,
  "in_reply_to_status_id" : 438914243627610113,
  "created_at" : "2014-02-27 07:01:00 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438925137111298048",
  "geo" : { },
  "id_str" : "438931151625809920",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith being folk musicians from the 1800s duh",
  "id" : 438931151625809920,
  "in_reply_to_status_id" : 438925137111298048,
  "created_at" : "2014-02-27 06:58:36 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asher Vollmer",
      "screen_name" : "AsherVo",
      "indices" : [ 0, 8 ],
      "id_str" : "16741826",
      "id" : 16741826
    }, {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 9, 19 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438879683703103488",
  "geo" : { },
  "id_str" : "438879952297918465",
  "in_reply_to_user_id" : 16741826,
  "text" : "@AsherVo @zachwaugh cool thanks. I didn't feel like it was necessary, but maybe if there were complaints about load times :(",
  "id" : 438879952297918465,
  "in_reply_to_status_id" : 438879683703103488,
  "created_at" : "2014-02-27 03:35:09 +0000",
  "in_reply_to_screen_name" : "AsherVo",
  "in_reply_to_user_id_str" : "16741826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 0, 10 ],
      "id_str" : "14620798",
      "id" : 14620798
    }, {
      "name" : "Asher Vollmer",
      "screen_name" : "AsherVo",
      "indices" : [ 28, 36 ],
      "id_str" : "16741826",
      "id" : 16741826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438875937653133312",
  "geo" : { },
  "id_str" : "438878311360364545",
  "in_reply_to_user_id" : 14620798,
  "text" : "@zachwaugh good question... @AsherVo I'm curious too!",
  "id" : 438878311360364545,
  "in_reply_to_status_id" : 438875937653133312,
  "created_at" : "2014-02-27 03:28:38 +0000",
  "in_reply_to_screen_name" : "zachwaugh",
  "in_reply_to_user_id_str" : "14620798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438868797257433088",
  "text" : "I want to like Calculords, but the font is impossibly tiny to read and focus on. \uD83D\uDC74",
  "id" : 438868797257433088,
  "created_at" : "2014-02-27 02:50:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 0, 8 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438788721135976448",
  "geo" : { },
  "id_str" : "438789131158560768",
  "in_reply_to_user_id" : 5502392,
  "text" : "@mojombo HOW ABOUT A NICE GAME OF CHESS?",
  "id" : 438789131158560768,
  "in_reply_to_status_id" : 438788721135976448,
  "created_at" : "2014-02-26 21:34:15 +0000",
  "in_reply_to_screen_name" : "mojombo",
  "in_reply_to_user_id_str" : "5502392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438742996209520640",
  "geo" : { },
  "id_str" : "438743730703441920",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety you mean Vermont?",
  "id" : 438743730703441920,
  "in_reply_to_status_id" : 438742996209520640,
  "created_at" : "2014-02-26 18:33:51 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Schroeder",
      "screen_name" : "SchroederAM",
      "indices" : [ 0, 12 ],
      "id_str" : "236229413",
      "id" : 236229413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/E3LhR7fTEE",
      "expanded_url" : "http:\/\/coworkbuffalo.com",
      "display_url" : "coworkbuffalo.com"
    } ]
  },
  "in_reply_to_status_id_str" : "438406986133020672",
  "geo" : { },
  "id_str" : "438729953983860736",
  "in_reply_to_user_id" : 236229413,
  "text" : "@SchroederAM did you just stop by the space? sorry we missed you if so. if you have questions, email is: work [at] http:\/\/t.co\/E3LhR7fTEE",
  "id" : 438729953983860736,
  "in_reply_to_status_id" : 438406986133020672,
  "created_at" : "2014-02-26 17:39:06 +0000",
  "in_reply_to_screen_name" : "SchroederAM",
  "in_reply_to_user_id_str" : "236229413",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 3, 10 ],
      "id_str" : "224887329",
      "id" : 224887329
    }, {
      "name" : "Trash Night Video",
      "screen_name" : "trashnightvideo",
      "indices" : [ 40, 56 ],
      "id_str" : "566876709",
      "id" : 566876709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/N6xSayFM62",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=1kRcB9KRrmg",
      "display_url" : "youtube.com\/watch?v=1kRcB9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438712931736248321",
  "text" : "RT @gabebw: Powerful Garfield Tips from @trashnightvideo https:\/\/t.co\/N6xSayFM62",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Trash Night Video",
        "screen_name" : "trashnightvideo",
        "indices" : [ 28, 44 ],
        "id_str" : "566876709",
        "id" : 566876709
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/N6xSayFM62",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=1kRcB9KRrmg",
        "display_url" : "youtube.com\/watch?v=1kRcB9\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "438712553301364736",
    "text" : "Powerful Garfield Tips from @trashnightvideo https:\/\/t.co\/N6xSayFM62",
    "id" : 438712553301364736,
    "created_at" : "2014-02-26 16:29:58 +0000",
    "user" : {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "protected" : false,
      "id_str" : "224887329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522042513951977472\/vthKCPDr_normal.jpeg",
      "id" : 224887329,
      "verified" : false
    }
  },
  "id" : 438712931736248321,
  "created_at" : "2014-02-26 16:31:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@Pete716",
      "screen_name" : "Pete716",
      "indices" : [ 0, 8 ],
      "id_str" : "33588043",
      "id" : 33588043
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 9, 23 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438697762218319872",
  "geo" : { },
  "id_str" : "438697936050876416",
  "in_reply_to_user_id" : 33588043,
  "text" : "@Pete716 @coworkbuffalo must be. deleted my account long ago at the last copyright debacle :)",
  "id" : 438697936050876416,
  "in_reply_to_status_id" : 438697762218319872,
  "created_at" : "2014-02-26 15:31:53 +0000",
  "in_reply_to_screen_name" : "Pete716",
  "in_reply_to_user_id_str" : "33588043",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Nguyen",
      "screen_name" : "dancow",
      "indices" : [ 0, 7 ],
      "id_str" : "14335332",
      "id" : 14335332
    }, {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 8, 16 ],
      "id_str" : "34175404",
      "id" : 34175404
    }, {
      "name" : "Gittip",
      "screen_name" : "Gittip",
      "indices" : [ 17, 24 ],
      "id_str" : "2595663126",
      "id" : 2595663126
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 25, 38 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Etsy",
      "screen_name" : "Etsy",
      "indices" : [ 39, 44 ],
      "id_str" : "11522502",
      "id" : 11522502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/hb6tSrnjyx",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=-W1WSOthhrg",
      "display_url" : "youtube.com\/watch?v=-W1WSO\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "438468254877892608",
  "geo" : { },
  "id_str" : "438697720153268224",
  "in_reply_to_user_id" : 14335332,
  "text" : "@dancow @whit537 @Gittip @steveklabnik @Etsy are we still going with http:\/\/t.co\/hb6tSrnjyx ?",
  "id" : 438697720153268224,
  "in_reply_to_status_id" : 438468254877892608,
  "created_at" : "2014-02-26 15:31:01 +0000",
  "in_reply_to_screen_name" : "dancow",
  "in_reply_to_user_id_str" : "14335332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@Pete716",
      "screen_name" : "Pete716",
      "indices" : [ 0, 8 ],
      "id_str" : "33588043",
      "id" : 33588043
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 9, 23 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438696174258634753",
  "geo" : { },
  "id_str" : "438696581026807809",
  "in_reply_to_user_id" : 33588043,
  "text" : "@Pete716 @coworkbuffalo these are all of the old space! :(",
  "id" : 438696581026807809,
  "in_reply_to_status_id" : 438696174258634753,
  "created_at" : "2014-02-26 15:26:30 +0000",
  "in_reply_to_screen_name" : "Pete716",
  "in_reply_to_user_id_str" : "33588043",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438677385332801537",
  "text" : "I feel like Twitch Plays Pokemon needs an announcer for battles. Makes the heartbreaks easier.",
  "id" : 438677385332801537,
  "created_at" : "2014-02-26 14:10:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438647102021705729",
  "text" : "Lmao if you didn't spend the last 18 hours in bed \uD83D\uDE37",
  "id" : 438647102021705729,
  "created_at" : "2014-02-26 12:09:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "racheldonovan",
      "screen_name" : "racheldonovan",
      "indices" : [ 3, 17 ],
      "id_str" : "17181310",
      "id" : 17181310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/mJuGDwEcma",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=MqYXFWAzgBQ",
      "display_url" : "youtube.com\/watch?v=MqYXFW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438430775004770304",
  "text" : "RT @racheldonovan: I think I smiled the entire time I watched this - Nickel City Ruby 2013 My KidsRuby Journey http:\/\/t.co\/mJuGDwEcma",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/mJuGDwEcma",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=MqYXFWAzgBQ",
        "display_url" : "youtube.com\/watch?v=MqYXFW\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "438353116543856640",
    "text" : "I think I smiled the entire time I watched this - Nickel City Ruby 2013 My KidsRuby Journey http:\/\/t.co\/mJuGDwEcma",
    "id" : 438353116543856640,
    "created_at" : "2014-02-25 16:41:41 +0000",
    "user" : {
      "name" : "racheldonovan",
      "screen_name" : "racheldonovan",
      "protected" : false,
      "id_str" : "17181310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1408625551\/Screen_shot_2011-06-22_at_6.41.54_PM_normal.jpg",
      "id" : 17181310,
      "verified" : false
    }
  },
  "id" : 438430775004770304,
  "created_at" : "2014-02-25 21:50:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 9, 13 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438415950040158208",
  "geo" : { },
  "id_str" : "438430377195995136",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham @dhh the latter",
  "id" : 438430377195995136,
  "in_reply_to_status_id" : 438415950040158208,
  "created_at" : "2014-02-25 21:48:42 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "leon",
      "screen_name" : "rubybuddha",
      "indices" : [ 3, 14 ],
      "id_str" : "129873542",
      "id" : 129873542
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 74, 82 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/HC0tE7bdlZ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=4WWu1kclNDA&sns=tw",
      "display_url" : "youtube.com\/watch?v=4WWu1k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438337706104352769",
  "text" : "RT @rubybuddha: Jodorowsky's Dune - Trailer #1 http:\/\/t.co\/HC0tE7bdlZ via @youtube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 58, 66 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/HC0tE7bdlZ",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=4WWu1kclNDA&sns=tw",
        "display_url" : "youtube.com\/watch?v=4WWu1k\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 40.0706972716, -83.011903298 ]
    },
    "id_str" : "438336291625648130",
    "text" : "Jodorowsky's Dune - Trailer #1 http:\/\/t.co\/HC0tE7bdlZ via @youtube",
    "id" : 438336291625648130,
    "created_at" : "2014-02-25 15:34:50 +0000",
    "user" : {
      "name" : "leon",
      "screen_name" : "rubybuddha",
      "protected" : false,
      "id_str" : "129873542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555842804945928192\/EDjwyeWq_normal.jpeg",
      "id" : 129873542,
      "verified" : false
    }
  },
  "id" : 438337706104352769,
  "created_at" : "2014-02-25 15:40:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Laskowski",
      "screen_name" : "Clint326",
      "indices" : [ 0, 9 ],
      "id_str" : "1965871",
      "id" : 1965871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438319713119006720",
  "geo" : { },
  "id_str" : "438336852475793408",
  "in_reply_to_user_id" : 1965871,
  "text" : "@Clint326 yep, we're on it!",
  "id" : 438336852475793408,
  "in_reply_to_status_id" : 438319713119006720,
  "created_at" : "2014-02-25 15:37:04 +0000",
  "in_reply_to_screen_name" : "Clint326",
  "in_reply_to_user_id_str" : "1965871",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 35, 50 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438336744753070080",
  "text" : "RT @ashedryden: I highly recommend @nickelcityruby. Happy to answer questions about my experience there if you are going for the first time\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 19, 34 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438319076079726592",
    "text" : "I highly recommend @nickelcityruby. Happy to answer questions about my experience there if you are going for the first time \u2764\uFE0F\uD83D\uDE46",
    "id" : 438319076079726592,
    "created_at" : "2014-02-25 14:26:25 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 438336744753070080,
  "created_at" : "2014-02-25 15:36:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prakash Murthy",
      "screen_name" : "_prakash",
      "indices" : [ 0, 9 ],
      "id_str" : "14540563",
      "id" : 14540563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438311994093871104",
  "geo" : { },
  "id_str" : "438321337493254144",
  "in_reply_to_user_id" : 14540563,
  "text" : "@_prakash Most people wait until the last minute anyway, keeping a wufoo form open while we get everything lined up is pretty easy",
  "id" : 438321337493254144,
  "in_reply_to_status_id" : 438311994093871104,
  "created_at" : "2014-02-25 14:35:25 +0000",
  "in_reply_to_screen_name" : "_prakash",
  "in_reply_to_user_id_str" : "14540563",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 1, 16 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/3UAdoKIt5Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "438304134312099841",
  "text" : ".@nickelcityruby 2: Electric Boogaloo! Our CFP is OPEN!\n(Also the committee won't let me use that tagline) http:\/\/t.co\/3UAdoKIt5Q",
  "id" : 438304134312099841,
  "created_at" : "2014-02-25 13:27:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438171062967087105",
  "text" : "It's sad but I will never have a better twitter bio than a dorf's.",
  "id" : 438171062967087105,
  "created_at" : "2014-02-25 04:38:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    }, {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 13, 19 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438166368752390144",
  "geo" : { },
  "id_str" : "438167859777130496",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam @nzkoz funny, the fedoras are still in style",
  "id" : 438167859777130496,
  "in_reply_to_status_id" : 438166368752390144,
  "created_at" : "2014-02-25 04:25:33 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 12, 19 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438161397357096961",
  "geo" : { },
  "id_str" : "438162992421957633",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @zobar2 BITC...OIN?",
  "id" : 438162992421957633,
  "in_reply_to_status_id" : 438161397357096961,
  "created_at" : "2014-02-25 04:06:12 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 0, 10 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438159720319582209",
  "geo" : { },
  "id_str" : "438160025958105088",
  "in_reply_to_user_id" : 14620798,
  "text" : "@zachwaugh you forgot a goto fail;",
  "id" : 438160025958105088,
  "in_reply_to_status_id" : 438159720319582209,
  "created_at" : "2014-02-25 03:54:25 +0000",
  "in_reply_to_screen_name" : "zachwaugh",
  "in_reply_to_user_id_str" : "14620798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/zwnpiJALgw",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "438159933276958720",
  "text" : "Shhhhh.... http:\/\/t.co\/zwnpiJALgw",
  "id" : 438159933276958720,
  "created_at" : "2014-02-25 03:54:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 21, 35 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438157304673095681",
  "geo" : { },
  "id_str" : "438157667760996353",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 new name for @coworkbuffalo's conference room?",
  "id" : 438157667760996353,
  "in_reply_to_status_id" : 438157304673095681,
  "created_at" : "2014-02-25 03:45:03 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Fernandes",
      "screen_name" : "zackfern",
      "indices" : [ 0, 9 ],
      "id_str" : "261945610",
      "id" : 261945610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438146578335801344",
  "geo" : { },
  "id_str" : "438148828789608448",
  "in_reply_to_user_id" : 261945610,
  "text" : "@zackfern it hits me pretty hard every time I read it. thanks!",
  "id" : 438148828789608448,
  "in_reply_to_status_id" : 438146578335801344,
  "created_at" : "2014-02-25 03:09:55 +0000",
  "in_reply_to_screen_name" : "zackfern",
  "in_reply_to_user_id_str" : "261945610",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Fernandes",
      "screen_name" : "zackfern",
      "indices" : [ 0, 9 ],
      "id_str" : "261945610",
      "id" : 261945610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/7BVyx0Nudc",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/programming\/comments\/6nc1h\/im_in_college_and_i_want_to_contribute_to_an_oss\/c04cnad",
      "display_url" : "reddit.com\/r\/programming\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "438144894343712768",
  "geo" : { },
  "id_str" : "438145690812706816",
  "in_reply_to_user_id" : 261945610,
  "text" : "@zackfern I asked this same question 5 years ago! Best response: http:\/\/t.co\/7BVyx0Nudc",
  "id" : 438145690812706816,
  "in_reply_to_status_id" : 438144894343712768,
  "created_at" : "2014-02-25 02:57:27 +0000",
  "in_reply_to_screen_name" : "zackfern",
  "in_reply_to_user_id_str" : "261945610",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438141685164302338",
  "text" : "Of course that shouldn't discount everyone else's sacrifices for contributing to OSS...you're all awesome, kids or not.",
  "id" : 438141685164302338,
  "created_at" : "2014-02-25 02:41:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438140949437222912",
  "text" : "Any parent who contributes to open source is sacrificing time, patience and energy for others. To my fellow moms and dads of OSS: thank you.",
  "id" : 438140949437222912,
  "created_at" : "2014-02-25 02:38:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ochonicki",
      "screen_name" : "fromonesrc",
      "indices" : [ 0, 11 ],
      "id_str" : "14420513",
      "id" : 14420513
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 34, 44 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438136031603621888",
  "geo" : { },
  "id_str" : "438140034152022016",
  "in_reply_to_user_id" : 14420513,
  "text" : "@fromonesrc she really killed it. @aspleenic said she ad-libbed most of it.",
  "id" : 438140034152022016,
  "in_reply_to_status_id" : 438136031603621888,
  "created_at" : "2014-02-25 02:34:59 +0000",
  "in_reply_to_screen_name" : "fromonesrc",
  "in_reply_to_user_id_str" : "14420513",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 40, 55 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Kids Ruby",
      "screen_name" : "KidsRuby",
      "indices" : [ 65, 74 ],
      "id_str" : "238055076",
      "id" : 238055076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/sdc4CD2Id0",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=MqYXFWAzgBQ",
      "display_url" : "youtube.com\/watch?v=MqYXFW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438135099452715009",
  "text" : "Only 985 views on this? I think Katie's @nickelcityruby debut of @KidsRuby deserves some more attention: http:\/\/t.co\/sdc4CD2Id0",
  "id" : 438135099452715009,
  "created_at" : "2014-02-25 02:15:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eleanor Saitta",
      "screen_name" : "Dymaxion",
      "indices" : [ 0, 9 ],
      "id_str" : "14415338",
      "id" : 14415338
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 10, 21 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 42, 52 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436329335079702529",
  "geo" : { },
  "id_str" : "438118748331839489",
  "in_reply_to_user_id" : 14415338,
  "text" : "@Dymaxion @ashedryden I happen to know an @aquaranto who gives talks!",
  "id" : 438118748331839489,
  "in_reply_to_status_id" : 436329335079702529,
  "created_at" : "2014-02-25 01:10:24 +0000",
  "in_reply_to_screen_name" : "Dymaxion",
  "in_reply_to_user_id_str" : "14415338",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438094871211945985",
  "geo" : { },
  "id_str" : "438102402915258368",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej \uD83D\uDE10",
  "id" : 438102402915258368,
  "in_reply_to_status_id" : 438094871211945985,
  "created_at" : "2014-02-25 00:05:27 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Cichon",
      "screen_name" : "SteveBuffalo",
      "indices" : [ 0, 13 ],
      "id_str" : "235665553",
      "id" : 235665553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438095968769437697",
  "geo" : { },
  "id_str" : "438100569677647872",
  "in_reply_to_user_id" : 235665553,
  "text" : "@SteveBuffalo peameal bacon. As much as you can carry.",
  "id" : 438100569677647872,
  "in_reply_to_status_id" : 438095968769437697,
  "created_at" : "2014-02-24 23:58:09 +0000",
  "in_reply_to_screen_name" : "SteveBuffalo",
  "in_reply_to_user_id_str" : "235665553",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438074614564929536",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo latest AQ video is fantastic...thanks man!",
  "id" : 438074614564929536,
  "created_at" : "2014-02-24 22:15:01 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Maciak",
      "screen_name" : "LukeMaciak",
      "indices" : [ 0, 11 ],
      "id_str" : "810567",
      "id" : 810567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438067148196704257",
  "geo" : { },
  "id_str" : "438067798623793153",
  "in_reply_to_user_id" : 810567,
  "text" : "@LukeMaciak it's the best. Just try it with 4 (or 6) tanks to start. Some people get ridiculous.",
  "id" : 438067798623793153,
  "in_reply_to_status_id" : 438067148196704257,
  "created_at" : "2014-02-24 21:47:56 +0000",
  "in_reply_to_screen_name" : "LukeMaciak",
  "in_reply_to_user_id_str" : "810567",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/438004465757466624\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/IpeihJxxqc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhQavZ5CYAAORe5.jpg",
      "id_str" : "438004465468071936",
      "id" : 438004465468071936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhQavZ5CYAAORe5.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IpeihJxxqc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438004492475183104",
  "text" : "RT @coworkbuffalo: Ok, snow. Time to move on. It's almost March. Seriously. http:\/\/t.co\/IpeihJxxqc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/438004465757466624\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/IpeihJxxqc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhQavZ5CYAAORe5.jpg",
        "id_str" : "438004465468071936",
        "id" : 438004465468071936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhQavZ5CYAAORe5.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/IpeihJxxqc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438004465757466624",
    "text" : "Ok, snow. Time to move on. It's almost March. Seriously. http:\/\/t.co\/IpeihJxxqc",
    "id" : 438004465757466624,
    "created_at" : "2014-02-24 17:36:17 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 438004492475183104,
  "created_at" : "2014-02-24 17:36:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438002470313152512",
  "geo" : { },
  "id_str" : "438002904213905409",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden I miss having interpreters at events...almost everything at RIT does, thanks to NTID.",
  "id" : 438002904213905409,
  "in_reply_to_status_id" : 438002470313152512,
  "created_at" : "2014-02-24 17:30:04 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Gee",
      "screen_name" : "DerekGeePhoto",
      "indices" : [ 0, 14 ],
      "id_str" : "1634451608",
      "id" : 1634451608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437986254307606528",
  "geo" : { },
  "id_str" : "437986900100796417",
  "in_reply_to_user_id" : 1634451608,
  "text" : "@DerekGeePhoto jail stripes are still a thing? Or did they not have any orange jumpsuits available?",
  "id" : 437986900100796417,
  "in_reply_to_status_id" : 437986254307606528,
  "created_at" : "2014-02-24 16:26:29 +0000",
  "in_reply_to_screen_name" : "DerekGeePhoto",
  "in_reply_to_user_id_str" : "1634451608",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/437936573481365506\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/avM30AsVIs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhPc_j6CQAAHrEX.jpg",
      "id_str" : "437936573313597440",
      "id" : 437936573313597440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhPc_j6CQAAHrEX.jpg",
      "sizes" : [ {
        "h" : 1520,
        "resize" : "fit",
        "w" : 2688
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/avM30AsVIs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437946041803878400",
  "text" : "RT @coworkbuffalo: Good morning! We were busy over the weekend. Added a conference table, bunch of new chairs, and more. http:\/\/t.co\/avM30A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/437936573481365506\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/avM30AsVIs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhPc_j6CQAAHrEX.jpg",
        "id_str" : "437936573313597440",
        "id" : 437936573313597440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhPc_j6CQAAHrEX.jpg",
        "sizes" : [ {
          "h" : 1520,
          "resize" : "fit",
          "w" : 2688
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/avM30AsVIs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "437936573481365506",
    "text" : "Good morning! We were busy over the weekend. Added a conference table, bunch of new chairs, and more. http:\/\/t.co\/avM30AsVIs",
    "id" : 437936573481365506,
    "created_at" : "2014-02-24 13:06:30 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 437946041803878400,
  "created_at" : "2014-02-24 13:44:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Evans",
      "screen_name" : "b0rk",
      "indices" : [ 3, 8 ],
      "id_str" : "6603532",
      "id" : 6603532
    }, {
      "name" : "Eir\u00EDkr \u00C5sheim",
      "screen_name" : "d6",
      "indices" : [ 37, 40 ],
      "id_str" : "8041522",
      "id" : 8041522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/UMyP6xDSqY",
      "expanded_url" : "http:\/\/plastic-idolatry.com\/erik\/log.html#2014-02-21",
      "display_url" : "plastic-idolatry.com\/erik\/log.html#\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437579826589732864",
  "text" : "RT @b0rk: Just got around to reading @d6's recent post on being kind &amp; generous in OSS communities. It is so good. http:\/\/t.co\/UMyP6xDSqY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eir\u00EDkr \u00C5sheim",
        "screen_name" : "d6",
        "indices" : [ 27, 30 ],
        "id_str" : "8041522",
        "id" : 8041522
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/UMyP6xDSqY",
        "expanded_url" : "http:\/\/plastic-idolatry.com\/erik\/log.html#2014-02-21",
        "display_url" : "plastic-idolatry.com\/erik\/log.html#\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "437287660051116032",
    "text" : "Just got around to reading @d6's recent post on being kind &amp; generous in OSS communities. It is so good. http:\/\/t.co\/UMyP6xDSqY",
    "id" : 437287660051116032,
    "created_at" : "2014-02-22 18:07:57 +0000",
    "user" : {
      "name" : "Julia Evans",
      "screen_name" : "b0rk",
      "protected" : false,
      "id_str" : "6603532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500666963756982273\/KGCoCe4y_normal.jpeg",
      "id" : 6603532,
      "verified" : false
    }
  },
  "id" : 437579826589732864,
  "created_at" : "2014-02-23 13:28:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/437399894693658625\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/olTOq84d0h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhH04u9CQAA1a_t.png",
      "id_str" : "437399894345531392",
      "id" : 437399894345531392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhH04u9CQAA1a_t.png",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/olTOq84d0h"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437399894693658625",
  "text" : "Why is watching a horde of people controlling a spastic guy trying to cut a tree down more compelling than most TV? http:\/\/t.co\/olTOq84d0h",
  "id" : 437399894693658625,
  "created_at" : "2014-02-23 01:33:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437061701574221824",
  "geo" : { },
  "id_str" : "437062431953547264",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove keep the highest in the corner!",
  "id" : 437062431953547264,
  "in_reply_to_status_id" : 437061701574221824,
  "created_at" : "2014-02-22 03:12:58 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    }, {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 9, 17 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436977294117052416",
  "geo" : { },
  "id_str" : "436977870532268032",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham @patio11 charge but don't automate anything. Once a month take a screenshot and Dropbox it. 100's of hours saved from Selenium.",
  "id" : 436977870532268032,
  "in_reply_to_status_id" : 436977294117052416,
  "created_at" : "2014-02-21 21:36:57 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick thomson",
      "screen_name" : "importantshock",
      "indices" : [ 0, 15 ],
      "id_str" : "7611992",
      "id" : 7611992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436946516360437760",
  "geo" : { },
  "id_str" : "436950428501016576",
  "in_reply_to_user_id" : 7611992,
  "text" : "@importantshock Amazing. I wish the focus would be on fortress mode though...and no update in almost 2 years :(",
  "id" : 436950428501016576,
  "in_reply_to_status_id" : 436946516360437760,
  "created_at" : "2014-02-21 19:47:54 +0000",
  "in_reply_to_screen_name" : "importantshock",
  "in_reply_to_user_id_str" : "7611992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436920870364516353",
  "geo" : { },
  "id_str" : "436920937040990208",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d 'MURICA",
  "id" : 436920937040990208,
  "in_reply_to_status_id" : 436920870364516353,
  "created_at" : "2014-02-21 17:50:43 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1Password",
      "screen_name" : "1Password",
      "indices" : [ 0, 10 ],
      "id_str" : "793926",
      "id" : 793926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436883217656721408",
  "geo" : { },
  "id_str" : "436885280822276096",
  "in_reply_to_user_id" : 793926,
  "text" : "@1Password I can't be the first one to have been confused by that. Why can't it just do both?",
  "id" : 436885280822276096,
  "in_reply_to_status_id" : 436883217656721408,
  "created_at" : "2014-02-21 15:29:02 +0000",
  "in_reply_to_screen_name" : "1Password",
  "in_reply_to_user_id_str" : "793926",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1Password",
      "screen_name" : "1Password",
      "indices" : [ 0, 10 ],
      "id_str" : "793926",
      "id" : 793926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436880412560740353",
  "geo" : { },
  "id_str" : "436882376300302336",
  "in_reply_to_user_id" : 793926,
  "text" : "@1Password no, that's what Dropbox is supposed to be. Instead, Dropbox stores .agilekeychain as a folder. Seems broken to me.",
  "id" : 436882376300302336,
  "in_reply_to_status_id" : 436880412560740353,
  "created_at" : "2014-02-21 15:17:30 +0000",
  "in_reply_to_screen_name" : "1Password",
  "in_reply_to_user_id_str" : "793926",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436879161055916032",
  "text" : "1password is great, until your laptop dies, you forgot your power cord, Dropbox is out of sync, and 1pw stores a folder. HAPPY FRIDAY!",
  "id" : 436879161055916032,
  "created_at" : "2014-02-21 15:04:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Dzikiy",
      "screen_name" : "phildzikiy",
      "indices" : [ 0, 11 ],
      "id_str" : "272230417",
      "id" : 272230417
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 12, 23 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Dan Miner",
      "screen_name" : "BfloBiz_Miner",
      "indices" : [ 24, 38 ],
      "id_str" : "479610380",
      "id" : 479610380
    }, {
      "name" : "Lynn Kwon-Dzikiy",
      "screen_name" : "NForestKorean",
      "indices" : [ 39, 53 ],
      "id_str" : "148401790",
      "id" : 148401790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/8XSXLD0Xlz",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=7Vf01W0J-SY",
      "display_url" : "youtube.com\/watch?v=7Vf01W\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "436692858784206848",
  "geo" : { },
  "id_str" : "436693390860632064",
  "in_reply_to_user_id" : 272230417,
  "text" : "@phildzikiy @kevinpurdy @BfloBiz_Miner @NForestKorean get the chromecast out and buckle up: http:\/\/t.co\/8XSXLD0Xlz",
  "id" : 436693390860632064,
  "in_reply_to_status_id" : 436692858784206848,
  "created_at" : "2014-02-21 02:46:32 +0000",
  "in_reply_to_screen_name" : "phildzikiy",
  "in_reply_to_user_id_str" : "272230417",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436679504657121280",
  "geo" : { },
  "id_str" : "436679871461212160",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej i am amazed these exist still",
  "id" : 436679871461212160,
  "in_reply_to_status_id" : 436679504657121280,
  "created_at" : "2014-02-21 01:52:49 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 3, 18 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436622473443151872",
  "text" : "RT @gabrielgironda: \u266A my bikeshed brings all the devs to the yard \/ and he's like \/ more green on the doors \/ and she's like \/ different ti\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436622262264139777",
    "text" : "\u266A my bikeshed brings all the devs to the yard \/ and he's like \/ more green on the doors \/ and she's like \/ different tile on the floors \u266A",
    "id" : 436622262264139777,
    "created_at" : "2014-02-20 22:03:54 +0000",
    "user" : {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "protected" : true,
      "id_str" : "267895957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560982536772259840\/0R0rl2ao_normal.jpeg",
      "id" : 267895957,
      "verified" : false
    }
  },
  "id" : 436622473443151872,
  "created_at" : "2014-02-20 22:04:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 0, 8 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436598824891457536",
  "geo" : { },
  "id_str" : "436600758088114176",
  "in_reply_to_user_id" : 752673,
  "text" : "@jeresig Time to plan an elaborate heist.",
  "id" : 436600758088114176,
  "in_reply_to_status_id" : 436598824891457536,
  "created_at" : "2014-02-20 20:38:27 +0000",
  "in_reply_to_screen_name" : "jeresig",
  "in_reply_to_user_id_str" : "752673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436564023341903872",
  "geo" : { },
  "id_str" : "436569716627222528",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms i think it's simple enough.",
  "id" : 436569716627222528,
  "in_reply_to_status_id" : 436564023341903872,
  "created_at" : "2014-02-20 18:35:06 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Watson",
      "screen_name" : "paulmwatson",
      "indices" : [ 0, 12 ],
      "id_str" : "11214",
      "id" : 11214
    }, {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 125, 134 ],
      "id_str" : "148198686",
      "id" : 148198686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436529275949182976",
  "geo" : { },
  "id_str" : "436554055817519106",
  "in_reply_to_user_id" : 11214,
  "text" : "@paulmwatson May have been during the deploy when I flipped the background to black. Also there's been DNS issues today (see @dnsimple)",
  "id" : 436554055817519106,
  "in_reply_to_status_id" : 436529275949182976,
  "created_at" : "2014-02-20 17:32:52 +0000",
  "in_reply_to_screen_name" : "paulmwatson",
  "in_reply_to_user_id_str" : "11214",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 49, 60 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/rqLF1W5k5f",
      "expanded_url" : "http:\/\/rubygems.org\/",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "436530296846962688",
  "text" : "Just flipped http:\/\/t.co\/rqLF1W5k5f to black for @jimweirich. Happy to know that his code and spirit lives on in so many places.",
  "id" : 436530296846962688,
  "created_at" : "2014-02-20 15:58:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 1, 12 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/l3cwnIHlHY",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?feature=youtu.be&v=vKrr7aXUc1E&desktop_uri=%2Fwatch%3Fv%3DvKrr7aXUc1E%26feature%3Dyoutu.be",
      "display_url" : "m.youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436454349687230464",
  "text" : ".@jimweirich's gone to that big conference in the sky. If only all of us could bring such joy to our communities. http:\/\/t.co\/l3cwnIHlHY",
  "id" : 436454349687230464,
  "created_at" : "2014-02-20 10:56:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keenan Brock",
      "screen_name" : "kbrock",
      "indices" : [ 0, 7 ],
      "id_str" : "623223",
      "id" : 623223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/thXUqOIrgs",
      "expanded_url" : "http:\/\/www.twitch.tv\/twitchplayspokemon",
      "display_url" : "twitch.tv\/twitchplayspok\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "436371706085908480",
  "geo" : { },
  "id_str" : "436371918124355584",
  "in_reply_to_user_id" : 623223,
  "text" : "@kbrock http:\/\/t.co\/thXUqOIrgs",
  "id" : 436371918124355584,
  "in_reply_to_status_id" : 436371706085908480,
  "created_at" : "2014-02-20 05:29:07 +0000",
  "in_reply_to_screen_name" : "kbrock",
  "in_reply_to_user_id_str" : "623223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436370657883205632",
  "geo" : { },
  "id_str" : "436371775446740992",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog ridiculous as usual. Going to try and make the final show!",
  "id" : 436371775446740992,
  "in_reply_to_status_id" : 436370657883205632,
  "created_at" : "2014-02-20 05:28:33 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436262887477096449",
  "text" : "Who brought these frogs to the board meeting? WHATSAPP! WHAAATSSSSAPPPPP???? WHAAATSSSAAAAAAP!!!",
  "id" : 436262887477096449,
  "created_at" : "2014-02-19 22:15:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 4, 18 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/436250319664599040\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/lm69bduqQB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bg3fWqTCUAAV-o5.jpg",
      "id_str" : "436250319329054720",
      "id" : 436250319329054720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bg3fWqTCUAAV-o5.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/lm69bduqQB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436250319664599040",
  "text" : "Put @coworkbuffalo's new Chromecast to good use immediately. http:\/\/t.co\/lm69bduqQB",
  "id" : 436250319664599040,
  "created_at" : "2014-02-19 21:25:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436201574969651200",
  "geo" : { },
  "id_str" : "436201718271856640",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen Duh. :P",
  "id" : 436201718271856640,
  "in_reply_to_status_id" : 436201574969651200,
  "created_at" : "2014-02-19 18:12:48 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436195846997438464",
  "geo" : { },
  "id_str" : "436200566998302720",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen yeesh, how?",
  "id" : 436200566998302720,
  "in_reply_to_status_id" : 436195846997438464,
  "created_at" : "2014-02-19 18:08:14 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 12, 23 ],
      "id_str" : "137891464",
      "id" : 137891464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 38, 52 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436199340361912320",
  "geo" : { },
  "id_str" : "436200419077799936",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante @nickelcity Just switched @coworkbuffalo's here.",
  "id" : 436200419077799936,
  "in_reply_to_status_id" : 436199340361912320,
  "created_at" : "2014-02-19 18:07:38 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436197870434529281",
  "geo" : { },
  "id_str" : "436198006895816704",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante Traitor.",
  "id" : 436198006895816704,
  "in_reply_to_status_id" : 436197870434529281,
  "created_at" : "2014-02-19 17:58:03 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 60, 67 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "Bridget",
      "screen_name" : "dragonladyB17",
      "indices" : [ 72, 86 ],
      "id_str" : "158443907",
      "id" : 158443907
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/436155252942049280\/photo\/1",
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/Dn9DjtSIUb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bg2I5DKIUAA9tmr.jpg",
      "id_str" : "436155252606521344",
      "id" : 436155252606521344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bg2I5DKIUAA9tmr.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Dn9DjtSIUb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436155287914180608",
  "text" : "RT @coworkbuffalo: Our Kickstarter posters are in thanks to @zobar2 and @dragonladyB17! 100% screen printed and hand made. http:\/\/t.co\/Dn9D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David P Kleinschmidt",
        "screen_name" : "zobar2",
        "indices" : [ 41, 48 ],
        "id_str" : "22627592",
        "id" : 22627592
      }, {
        "name" : "Bridget",
        "screen_name" : "dragonladyB17",
        "indices" : [ 53, 67 ],
        "id_str" : "158443907",
        "id" : 158443907
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/436155252942049280\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/Dn9DjtSIUb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bg2I5DKIUAA9tmr.jpg",
        "id_str" : "436155252606521344",
        "id" : 436155252606521344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bg2I5DKIUAA9tmr.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Dn9DjtSIUb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436155252942049280",
    "text" : "Our Kickstarter posters are in thanks to @zobar2 and @dragonladyB17! 100% screen printed and hand made. http:\/\/t.co\/Dn9DjtSIUb",
    "id" : 436155252942049280,
    "created_at" : "2014-02-19 15:08:10 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 436155287914180608,
  "created_at" : "2014-02-19 15:08:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436143398345781248",
  "geo" : { },
  "id_str" : "436145763739922432",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh Also the hardest part of the job most times :)",
  "id" : 436145763739922432,
  "in_reply_to_status_id" : 436143398345781248,
  "created_at" : "2014-02-19 14:30:27 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/DzKtk1jyet",
      "expanded_url" : "http:\/\/signalvnoise.com\/archives2\/it_just_doesnt_matter.php",
      "display_url" : "signalvnoise.com\/archives2\/it_j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436145622433808384",
  "text" : "RT @dhh: \"The best programmers aren\u2019t the ones with the best skills [but those who] can determine what just doesn\u2019t matter\" http:\/\/t.co\/DzK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/DzKtk1jyet",
        "expanded_url" : "http:\/\/signalvnoise.com\/archives2\/it_just_doesnt_matter.php",
        "display_url" : "signalvnoise.com\/archives2\/it_j\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436143398345781248",
    "text" : "\"The best programmers aren\u2019t the ones with the best skills [but those who] can determine what just doesn\u2019t matter\" http:\/\/t.co\/DzKtk1jyet",
    "id" : 436143398345781248,
    "created_at" : "2014-02-19 14:21:03 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 436145622433808384,
  "created_at" : "2014-02-19 14:29:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/GT19A1dxsa",
      "expanded_url" : "https:\/\/ifttt.com\/recipes\/147701",
      "display_url" : "ifttt.com\/recipes\/147701"
    } ]
  },
  "geo" : { },
  "id_str" : "435914791568564224",
  "text" : "Try this IFTTT Recipe: Text me Erie County, NY (Buffalo) weather alerts from National Weather Service  https:\/\/t.co\/GT19A1dxsa",
  "id" : 435914791568564224,
  "created_at" : "2014-02-18 23:12:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conner  O'Malley",
      "screen_name" : "conner_omalley",
      "indices" : [ 11, 26 ],
      "id_str" : "980990414",
      "id" : 980990414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/94yWi6UKfx",
      "expanded_url" : "http:\/\/www.dailydot.com\/lol\/conner-omalley-vine-insane\/",
      "display_url" : "dailydot.com\/lol\/conner-oma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435900459660742656",
  "text" : "I just saw @conner_omalley on a YouTube ad for Seth Meyers and he wasn't screaming at anyone. WTF. http:\/\/t.co\/94yWi6UKfx",
  "id" : 435900459660742656,
  "created_at" : "2014-02-18 22:15:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435860615194636289",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej burning man kiev is out of control!",
  "id" : 435860615194636289,
  "created_at" : "2014-02-18 19:37:23 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/NfFWaz3sSW",
      "expanded_url" : "http:\/\/www.indiegogo.com\/projects\/icis-fashion-friendly-smart-glasses",
      "display_url" : "indiegogo.com\/projects\/icis-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435842831639257088",
  "text" : "Google Glass without the cyborg, from a bunch of RIT grads! http:\/\/t.co\/NfFWaz3sSW",
  "id" : 435842831639257088,
  "created_at" : "2014-02-18 18:26:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435632856178507776",
  "geo" : { },
  "id_str" : "435633598591680512",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda afplay can play mp3's, maybe ogg?",
  "id" : 435633598591680512,
  "in_reply_to_status_id" : 435632856178507776,
  "created_at" : "2014-02-18 04:35:18 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435495194394648576",
  "geo" : { },
  "id_str" : "435495362443239424",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek SUBTWEET",
  "id" : 435495362443239424,
  "in_reply_to_status_id" : 435495194394648576,
  "created_at" : "2014-02-17 19:26:00 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435490242620293120",
  "geo" : { },
  "id_str" : "435490408659820544",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik Space Alert's is really well done as well. Especially as a group learning a new game it was so much easier.",
  "id" : 435490408659820544,
  "in_reply_to_status_id" : 435490242620293120,
  "created_at" : "2014-02-17 19:06:19 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 5, 14 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 31, 45 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 83, 91 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "Buffalo PHP",
      "screen_name" : "BuffaloPHP",
      "indices" : [ 92, 103 ],
      "id_str" : "1508773998",
      "id" : 1508773998
    }, {
      "name" : "Buffalo JavaScript",
      "screen_name" : "BuffaloJS",
      "indices" : [ 104, 114 ],
      "id_str" : "817437266",
      "id" : 817437266
    }, {
      "name" : "Buffalo PASS",
      "screen_name" : "BuffaloPASS",
      "indices" : [ 115, 127 ],
      "id_str" : "1468216825",
      "id" : 1468216825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/V9oYlt6iR7",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/14783-openhack-february-2-0",
      "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435463588765921280",
  "text" : "It's @openhack time again, 7PM @coworkbuffalo tomorrow! http:\/\/t.co\/V9oYlt6iR7 \/cc @wnyruby @BuffaloPHP @BuffaloJS @BuffaloPASS",
  "id" : 435463588765921280,
  "created_at" : "2014-02-17 17:19:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    }, {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 8, 13 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435437901393178624",
  "geo" : { },
  "id_str" : "435438188157353985",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss @r38y No inspections there either. I have seen cars held together with duct tape and bungee cords.",
  "id" : 435438188157353985,
  "in_reply_to_status_id" : 435437901393178624,
  "created_at" : "2014-02-17 15:38:48 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    }, {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 8, 13 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435422970547548160",
  "geo" : { },
  "id_str" : "435436103563087874",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss @r38y Ever been to Ohio?",
  "id" : 435436103563087874,
  "in_reply_to_status_id" : 435422970547548160,
  "created_at" : "2014-02-17 15:30:31 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Threes",
      "screen_name" : "ThreesGame",
      "indices" : [ 42, 53 ],
      "id_str" : "2278046648",
      "id" : 2278046648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435181514452520960",
  "text" : "Best strategy I've figured out so far for @ThreesGame: keep your biggest tile in a corner and never move it out.",
  "id" : 435181514452520960,
  "created_at" : "2014-02-16 22:38:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Threes",
      "screen_name" : "ThreesGame",
      "indices" : [ 24, 35 ],
      "id_str" : "2278046648",
      "id" : 2278046648
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/435168146731716608\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/6dXYUkAHSS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgoHH6wCcAA4V4-.jpg",
      "id_str" : "435168146605895680",
      "id" : 435168146605895680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgoHH6wCcAA4V4-.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 876
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 876
      }, {
        "h" : 155,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6dXYUkAHSS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/63EkJdsKm8",
      "expanded_url" : "http:\/\/threesgame.com",
      "display_url" : "threesgame.com"
    } ]
  },
  "geo" : { },
  "id_str" : "435168146731716608",
  "text" : "I just scored 28,374 in @ThreesGame! http:\/\/t.co\/63EkJdsKm8 http:\/\/t.co\/6dXYUkAHSS",
  "id" : 435168146731716608,
  "created_at" : "2014-02-16 21:45:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 6, 14 ],
      "id_str" : "14060922",
      "id" : 14060922
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 15, 24 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 56, 70 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435155877914349568",
  "geo" : { },
  "id_str" : "435160746133962752",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y @mperham @indirect nice! We originally got it for @coworkbuffalo but didn't fit our door.",
  "id" : 435160746133962752,
  "in_reply_to_status_id" : 435155877914349568,
  "created_at" : "2014-02-16 21:16:21 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 0, 9 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 10, 18 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435153597852962816",
  "geo" : { },
  "id_str" : "435154058333011968",
  "in_reply_to_user_id" : 5674672,
  "text" : "@indirect @mperham true but think of what it's competing against...duplicating a key means trip to the locksmith...:)",
  "id" : 435154058333011968,
  "in_reply_to_status_id" : 435153597852962816,
  "created_at" : "2014-02-16 20:49:46 +0000",
  "in_reply_to_screen_name" : "indirect",
  "in_reply_to_user_id_str" : "5674672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 9, 18 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435147371668717568",
  "geo" : { },
  "id_str" : "435153275197747200",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham @indirect I can't even think of 5 people I'd give access to my house 24\/7. 2 physical keys + 1 fob + 5 eKeys is plenty.",
  "id" : 435153275197747200,
  "in_reply_to_status_id" : 435147371668717568,
  "created_at" : "2014-02-16 20:46:40 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 0, 9 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435141808478105600",
  "geo" : { },
  "id_str" : "435144800266747906",
  "in_reply_to_user_id" : 5674672,
  "text" : "@indirect we have a Kevo. there's 5 or 6 ekeys included. Have only given out one.",
  "id" : 435144800266747906,
  "in_reply_to_status_id" : 435141808478105600,
  "created_at" : "2014-02-16 20:12:59 +0000",
  "in_reply_to_screen_name" : "indirect",
  "in_reply_to_user_id_str" : "5674672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/m24pBZrY3V",
      "expanded_url" : "https:\/\/www.google.com\/search?q=dave+s+test+pid",
      "display_url" : "google.com\/search?q=dave+\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435132285159882753",
  "text" : "Dave S TEST PID - DO NOT TOUCH EVER!!! https:\/\/t.co\/m24pBZrY3V",
  "id" : 435132285159882753,
  "created_at" : "2014-02-16 19:23:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drainstop; refactor.",
      "screen_name" : "jmsmcfrlnd",
      "indices" : [ 0, 11 ],
      "id_str" : "17204864",
      "id" : 17204864
    }, {
      "name" : "Bridget",
      "screen_name" : "dragonladyB17",
      "indices" : [ 12, 26 ],
      "id_str" : "158443907",
      "id" : 158443907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434779912231469057",
  "geo" : { },
  "id_str" : "435109491130908672",
  "in_reply_to_user_id" : 17204864,
  "text" : "@jmsmcfrlnd @dragonladyB17 it's screenprinted.",
  "id" : 435109491130908672,
  "in_reply_to_status_id" : 434779912231469057,
  "created_at" : "2014-02-16 17:52:41 +0000",
  "in_reply_to_screen_name" : "jmsmcfrlnd",
  "in_reply_to_user_id_str" : "17204864",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Betteridge's Law",
      "screen_name" : "BetteridgesLaw",
      "indices" : [ 55, 70 ],
      "id_str" : "437484436",
      "id" : 437484436
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kevinpurdy\/status\/435059661973106688\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/lGSLQ8QNSJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgmkdRBCYAEyId-.jpg",
      "id_str" : "435059661708877825",
      "id" : 435059661708877825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgmkdRBCYAEyId-.jpg",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lGSLQ8QNSJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435062509016346624",
  "text" : "RT @kevinpurdy: Betteridge's Law in the local edition (@BetteridgesLaw): http:\/\/t.co\/lGSLQ8QNSJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/carbonandroid\" rel=\"nofollow\"\u003ECarbon for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Betteridge's Law",
        "screen_name" : "BetteridgesLaw",
        "indices" : [ 39, 54 ],
        "id_str" : "437484436",
        "id" : 437484436
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kevinpurdy\/status\/435059661973106688\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/lGSLQ8QNSJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgmkdRBCYAEyId-.jpg",
        "id_str" : "435059661708877825",
        "id" : 435059661708877825,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgmkdRBCYAEyId-.jpg",
        "sizes" : [ {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/lGSLQ8QNSJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "435059661973106688",
    "text" : "Betteridge's Law in the local edition (@BetteridgesLaw): http:\/\/t.co\/lGSLQ8QNSJ",
    "id" : 435059661973106688,
    "created_at" : "2014-02-16 14:34:41 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 435062509016346624,
  "created_at" : "2014-02-16 14:45:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "indices" : [ 3, 8 ],
      "id_str" : "949521",
      "id" : 949521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/Y3vLZ1sI0O",
      "expanded_url" : "http:\/\/youtu.be\/gLDYtH1RH-U",
      "display_url" : "youtu.be\/gLDYtH1RH-U"
    } ]
  },
  "geo" : { },
  "id_str" : "434904653252141058",
  "text" : "RT @stop: These skywalker videos are such a rush to watch. Shanghai Tower, 2,100 feet up. Watch it to the end, if you can. http:\/\/t.co\/Y3vL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Y3vLZ1sI0O",
        "expanded_url" : "http:\/\/youtu.be\/gLDYtH1RH-U",
        "display_url" : "youtu.be\/gLDYtH1RH-U"
      } ]
    },
    "geo" : { },
    "id_str" : "434901398933622787",
    "text" : "These skywalker videos are such a rush to watch. Shanghai Tower, 2,100 feet up. Watch it to the end, if you can. http:\/\/t.co\/Y3vLZ1sI0O",
    "id" : 434901398933622787,
    "created_at" : "2014-02-16 04:05:48 +0000",
    "user" : {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "protected" : false,
      "id_str" : "949521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537483244468318208\/H1ArNbIw_normal.jpeg",
      "id" : 949521,
      "verified" : false
    }
  },
  "id" : 434904653252141058,
  "created_at" : "2014-02-16 04:18:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/wSzb9tUbhM",
      "expanded_url" : "http:\/\/signalvnoise.com\/posts\/3720-join-our-team-were-hiring-a-product-designer",
      "display_url" : "signalvnoise.com\/posts\/3720-joi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434867105909862400",
  "text" : "RT @rjs: We're looking for another product designer to join our team at Basecamp: http:\/\/t.co\/wSzb9tUbhM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/wSzb9tUbhM",
        "expanded_url" : "http:\/\/signalvnoise.com\/posts\/3720-join-our-team-were-hiring-a-product-designer",
        "display_url" : "signalvnoise.com\/posts\/3720-joi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "434768228053553152",
    "text" : "We're looking for another product designer to join our team at Basecamp: http:\/\/t.co\/wSzb9tUbhM",
    "id" : 434768228053553152,
    "created_at" : "2014-02-15 19:16:37 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 434867105909862400,
  "created_at" : "2014-02-16 01:49:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/zobar2\/status\/434766994714673153\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/hTgJ9gfAZT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgiaRyXIYAEJ1KG.jpg",
      "id_str" : "434766994408497153",
      "id" : 434766994408497153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgiaRyXIYAEJ1KG.jpg",
      "sizes" : [ {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/hTgJ9gfAZT"
    } ],
    "hashtags" : [ {
      "text" : "coworkposter",
      "indices" : [ 28, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434767520721952768",
  "text" : "RT @zobar2: plot exposition #coworkposter http:\/\/t.co\/hTgJ9gfAZT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/zobar2\/status\/434766994714673153\/photo\/1",
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/hTgJ9gfAZT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgiaRyXIYAEJ1KG.jpg",
        "id_str" : "434766994408497153",
        "id" : 434766994408497153,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgiaRyXIYAEJ1KG.jpg",
        "sizes" : [ {
          "h" : 816,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/hTgJ9gfAZT"
      } ],
      "hashtags" : [ {
        "text" : "coworkposter",
        "indices" : [ 16, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.8873357, -78.8729215 ]
    },
    "id_str" : "434766994714673153",
    "text" : "plot exposition #coworkposter http:\/\/t.co\/hTgJ9gfAZT",
    "id" : 434766994714673153,
    "created_at" : "2014-02-15 19:11:43 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 434767520721952768,
  "created_at" : "2014-02-15 19:13:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bridget",
      "screen_name" : "dragonladyB17",
      "indices" : [ 3, 17 ],
      "id_str" : "158443907",
      "id" : 158443907
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coworkposter",
      "indices" : [ 26, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/OH70J0Zr4l",
      "expanded_url" : "http:\/\/tmblr.co\/Zjqyqx17UirFr",
      "display_url" : "tmblr.co\/Zjqyqx17UirFr"
    } ]
  },
  "geo" : { },
  "id_str" : "434767506394189824",
  "text" : "RT @dragonladyB17: Photo: #coworkposter Am in basement of WNYBAC with Z setting up to run off posters for Cowork Buffalo\u2019s... http:\/\/t.co\/O\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coworkposter",
        "indices" : [ 7, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/OH70J0Zr4l",
        "expanded_url" : "http:\/\/tmblr.co\/Zjqyqx17UirFr",
        "display_url" : "tmblr.co\/Zjqyqx17UirFr"
      } ]
    },
    "geo" : { },
    "id_str" : "434754415082610688",
    "text" : "Photo: #coworkposter Am in basement of WNYBAC with Z setting up to run off posters for Cowork Buffalo\u2019s... http:\/\/t.co\/OH70J0Zr4l",
    "id" : 434754415082610688,
    "created_at" : "2014-02-15 18:21:44 +0000",
    "user" : {
      "name" : "Bridget",
      "screen_name" : "dragonladyB17",
      "protected" : false,
      "id_str" : "158443907",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1016733212\/Photo_245_normal.jpg",
      "id" : 158443907,
      "verified" : false
    }
  },
  "id" : 434767506394189824,
  "created_at" : "2014-02-15 19:13:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434669919423053824",
  "text" : "Energy of the crowd at \uD83C\uDDFA\uD83C\uDDF8\/\uD83C\uDDF7\uD83C\uDDFA makes me miss good, live hockey.",
  "id" : 434669919423053824,
  "created_at" : "2014-02-15 12:45:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/mF0uK9rIVe",
      "expanded_url" : "http:\/\/signalvnoise.com\/posts\/3720-join-our-team-were-hiring-a-product-designer",
      "display_url" : "signalvnoise.com\/posts\/3720-joi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434512788463947776",
  "text" : "Designer friends: http:\/\/t.co\/mF0uK9rIVe",
  "id" : 434512788463947776,
  "created_at" : "2014-02-15 02:21:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 3, 12 ],
      "id_str" : "1051521",
      "id" : 1051521
    }, {
      "name" : "jekyll",
      "screen_name" : "jekyllrb",
      "indices" : [ 57, 66 ],
      "id_str" : "1143789606",
      "id" : 1143789606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/1dyE1LqmDD",
      "expanded_url" : "http:\/\/git.io\/UIbVfg",
      "display_url" : "git.io\/UIbVfg"
    } ]
  },
  "geo" : { },
  "id_str" : "434511396739366912",
  "text" : "RT @migreyes: I extracted two years of making sites with @jekyllrb into a raw starting point for new projects. http:\/\/t.co\/1dyE1LqmDD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jekyll",
        "screen_name" : "jekyllrb",
        "indices" : [ 43, 52 ],
        "id_str" : "1143789606",
        "id" : 1143789606
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/1dyE1LqmDD",
        "expanded_url" : "http:\/\/git.io\/UIbVfg",
        "display_url" : "git.io\/UIbVfg"
      } ]
    },
    "geo" : { },
    "id_str" : "434472697309831168",
    "text" : "I extracted two years of making sites with @jekyllrb into a raw starting point for new projects. http:\/\/t.co\/1dyE1LqmDD",
    "id" : 434472697309831168,
    "created_at" : "2014-02-14 23:42:17 +0000",
    "user" : {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "protected" : false,
      "id_str" : "1051521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000757770941\/4908459cf63d592540869503f2e2aacb_normal.jpeg",
      "id" : 1051521,
      "verified" : false
    }
  },
  "id" : 434511396739366912,
  "created_at" : "2014-02-15 02:16:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434492870582870016",
  "geo" : { },
  "id_str" : "434508277766836225",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten STALKER",
  "id" : 434508277766836225,
  "in_reply_to_status_id" : 434492870582870016,
  "created_at" : "2014-02-15 02:03:40 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 0, 11 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434437410869358592",
  "geo" : { },
  "id_str" : "434437854706425856",
  "in_reply_to_user_id" : 14372143,
  "text" : "@jasonfried if only meetup was that simple, still",
  "id" : 434437854706425856,
  "in_reply_to_status_id" : 434437410869358592,
  "created_at" : "2014-02-14 21:23:50 +0000",
  "in_reply_to_screen_name" : "jasonfried",
  "in_reply_to_user_id_str" : "14372143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434417039491334144",
  "geo" : { },
  "id_str" : "434417478513348608",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden \"Every week we bring you stories, based around a theme. This week's theme: Cats.\"",
  "id" : 434417478513348608,
  "in_reply_to_status_id" : 434417039491334144,
  "created_at" : "2014-02-14 20:02:52 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0410\u043D\u0434\u0440\u0438\u0439\u0447\u0443\u043A \u0412\u0430\u0441\u0438\u043B\u0438\u0439",
      "screen_name" : "brickattack",
      "indices" : [ 0, 12 ],
      "id_str" : "2833581694",
      "id" : 2833581694
    }, {
      "name" : "Level Up Conference",
      "screen_name" : "LevelUpCon",
      "indices" : [ 13, 24 ],
      "id_str" : "2190788389",
      "id" : 2190788389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434410194773504000",
  "geo" : { },
  "id_str" : "434410435681341440",
  "in_reply_to_user_id" : 14789935,
  "text" : "@brickattack @LevelUpCon sure, feel free to email. nick [at] quaran.to",
  "id" : 434410435681341440,
  "in_reply_to_status_id" : 434410194773504000,
  "created_at" : "2014-02-14 19:34:53 +0000",
  "in_reply_to_screen_name" : "brkattk",
  "in_reply_to_user_id_str" : "14789935",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 0, 10 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434406711223648256",
  "geo" : { },
  "id_str" : "434408617643483138",
  "in_reply_to_user_id" : 14620798,
  "text" : "@zachwaugh it's hard not to use Lightroom once you've figured it out.",
  "id" : 434408617643483138,
  "in_reply_to_status_id" : 434406711223648256,
  "created_at" : "2014-02-14 19:27:40 +0000",
  "in_reply_to_screen_name" : "zachwaugh",
  "in_reply_to_user_id_str" : "14620798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 16, 30 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434331210420989952",
  "geo" : { },
  "id_str" : "434402103352520706",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten @coworkbuffalo failboat. If you end up coming down I have extra quarters, just park on Washington!",
  "id" : 434402103352520706,
  "in_reply_to_status_id" : 434331210420989952,
  "created_at" : "2014-02-14 19:01:46 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    }, {
      "name" : "Mike Burns",
      "screen_name" : "mikeburns",
      "indices" : [ 15, 25 ],
      "id_str" : "15001533",
      "id" : 15001533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434392644920168449",
  "geo" : { },
  "id_str" : "434393358211891200",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k who made @mikeburns CEO!!?",
  "id" : 434393358211891200,
  "in_reply_to_status_id" : 434392644920168449,
  "created_at" : "2014-02-14 18:27:01 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434164170552901632",
  "geo" : { },
  "id_str" : "434165217094664193",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw xip.io",
  "id" : 434165217094664193,
  "in_reply_to_status_id" : 434164170552901632,
  "created_at" : "2014-02-14 03:20:28 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/zobar2\/status\/434162743537856512\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/C2Yuk9Nzzy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgZ0tvrIAAEByjv.jpg",
      "id_str" : "434162743328112641",
      "id" : 434162743328112641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgZ0tvrIAAEByjv.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 1632
      } ],
      "display_url" : "pic.twitter.com\/C2Yuk9Nzzy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434163704322457601",
  "text" : "RT @zobar2: Separated at birth? http:\/\/t.co\/C2Yuk9Nzzy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/zobar2\/status\/434162743537856512\/photo\/1",
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/C2Yuk9Nzzy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgZ0tvrIAAEByjv.jpg",
        "id_str" : "434162743328112641",
        "id" : 434162743328112641,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgZ0tvrIAAEByjv.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1224,
          "resize" : "fit",
          "w" : 1632
        } ],
        "display_url" : "pic.twitter.com\/C2Yuk9Nzzy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.9592364, -78.8500141 ]
    },
    "id_str" : "434162743537856512",
    "text" : "Separated at birth? http:\/\/t.co\/C2Yuk9Nzzy",
    "id" : 434162743537856512,
    "created_at" : "2014-02-14 03:10:39 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 434163704322457601,
  "created_at" : "2014-02-14 03:14:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 12, 25 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434155657776738304",
  "geo" : { },
  "id_str" : "434157176932691968",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @steveklabnik pretty sure I dreamed of matching tiles last night. Used to have Tetris dreams too...",
  "id" : 434157176932691968,
  "in_reply_to_status_id" : 434155657776738304,
  "created_at" : "2014-02-14 02:48:31 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 18, 25 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434152759231668224",
  "text" : "Apparently hiring @nb3004 as my Threes coach has paid off.",
  "id" : 434152759231668224,
  "created_at" : "2014-02-14 02:30:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Threes",
      "screen_name" : "ThreesGame",
      "indices" : [ 24, 35 ],
      "id_str" : "2278046648",
      "id" : 2278046648
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/434152404331020288\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/AQdYijeb7U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgZrT7qIMAAYmpb.jpg",
      "id_str" : "434152404263907328",
      "id" : 434152404263907328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgZrT7qIMAAYmpb.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 876
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 876
      }, {
        "h" : 155,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/AQdYijeb7U"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/EJBYOLLPTW",
      "expanded_url" : "http:\/\/threesgame.com",
      "display_url" : "threesgame.com"
    } ]
  },
  "geo" : { },
  "id_str" : "434152404331020288",
  "text" : "I just scored 19,977 in @ThreesGame! http:\/\/t.co\/EJBYOLLPTW http:\/\/t.co\/AQdYijeb7U",
  "id" : 434152404331020288,
  "created_at" : "2014-02-14 02:29:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434147511737933825",
  "text" : "I hate to say it, but I would pay 99\u00A2 per undo in Threes. (I'm quaranto on Game Center, add me!)",
  "id" : 434147511737933825,
  "created_at" : "2014-02-14 02:10:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah rich",
      "screen_name" : "micahbrich",
      "indices" : [ 0, 11 ],
      "id_str" : "14566614",
      "id" : 14566614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434038054802575360",
  "geo" : { },
  "id_str" : "434087151852986368",
  "in_reply_to_user_id" : 14566614,
  "text" : "@micahbrich did you find some help?",
  "id" : 434087151852986368,
  "in_reply_to_status_id" : 434038054802575360,
  "created_at" : "2014-02-13 22:10:16 +0000",
  "in_reply_to_screen_name" : "micahbrich",
  "in_reply_to_user_id_str" : "14566614",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin John Gomez",
      "screen_name" : "kevinjohngomez",
      "indices" : [ 0, 15 ],
      "id_str" : "26253666",
      "id" : 26253666
    }, {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 16, 21 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434036928652914688",
  "geo" : { },
  "id_str" : "434037094445359105",
  "in_reply_to_user_id" : 26253666,
  "text" : "@kevinjohngomez @popo It's Comcastic!",
  "id" : 434037094445359105,
  "in_reply_to_status_id" : 434036928652914688,
  "created_at" : "2014-02-13 18:51:21 +0000",
  "in_reply_to_screen_name" : "kevinjohngomez",
  "in_reply_to_user_id_str" : "26253666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 8, 22 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/434021828185423874\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/QBo6DX1Ne5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgX0jYuCAAAcy6O.jpg",
      "id_str" : "434021827879239680",
      "id" : 434021827879239680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgX0jYuCAAAcy6O.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QBo6DX1Ne5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434021828185423874",
  "text" : "Current @coworkbuffalo status: http:\/\/t.co\/QBo6DX1Ne5",
  "id" : 434021828185423874,
  "created_at" : "2014-02-13 17:50:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434016573956042752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8913573368, -78.8727054346 ]
  },
  "id_str" : "434016891653206016",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella still counts :P you have a phone booth here you're always welcome to.",
  "id" : 434016891653206016,
  "in_reply_to_status_id" : 434016573956042752,
  "created_at" : "2014-02-13 17:31:05 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434011684873965568",
  "geo" : { },
  "id_str" : "434016540259024896",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella ...in Boston.",
  "id" : 434016540259024896,
  "in_reply_to_status_id" : 434011684873965568,
  "created_at" : "2014-02-13 17:29:41 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    }, {
      "name" : "Craig Martek",
      "screen_name" : "cregatron",
      "indices" : [ 7, 17 ],
      "id_str" : "16892522",
      "id" : 16892522
    }, {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 18, 30 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434002994917818369",
  "geo" : { },
  "id_str" : "434003095819800576",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d @cregatron @john_floren yeah I tried those by habit. Had to google, used idaho.",
  "id" : 434003095819800576,
  "in_reply_to_status_id" : 434002994917818369,
  "created_at" : "2014-02-13 16:36:16 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Martek",
      "screen_name" : "cregatron",
      "indices" : [ 0, 10 ],
      "id_str" : "16892522",
      "id" : 16892522
    }, {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 55, 61 ],
      "id_str" : "325866689",
      "id" : 325866689
    }, {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 62, 74 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433999847071690752",
  "geo" : { },
  "id_str" : "434001114946473984",
  "in_reply_to_user_id" : 16892522,
  "text" : "@cregatron Holy shit, my password still works too. \/cc @mwn3d @john_floren",
  "id" : 434001114946473984,
  "in_reply_to_status_id" : 433999847071690752,
  "created_at" : "2014-02-13 16:28:23 +0000",
  "in_reply_to_screen_name" : "cregatron",
  "in_reply_to_user_id_str" : "16892522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 32, 44 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 106, 121 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433807634236727297",
  "text" : "Checking in for night 2 of 4 of @AqueousBand. Balloons and paper lanterns up! 99 red balloons cover!? \/cc @UnclePhilsBlog",
  "id" : 433807634236727297,
  "created_at" : "2014-02-13 03:39:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433763813343907840",
  "geo" : { },
  "id_str" : "433764819670274048",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 eh?",
  "id" : 433764819670274048,
  "in_reply_to_status_id" : 433763813343907840,
  "created_at" : "2014-02-13 00:49:26 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433730204876677120",
  "geo" : { },
  "id_str" : "433730637292257280",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz rewatched the latter already. So good.",
  "id" : 433730637292257280,
  "in_reply_to_status_id" : 433730204876677120,
  "created_at" : "2014-02-12 22:33:36 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Dzikiy",
      "screen_name" : "phildzikiy",
      "indices" : [ 0, 11 ],
      "id_str" : "272230417",
      "id" : 272230417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433720179613130752",
  "geo" : { },
  "id_str" : "433720423679668224",
  "in_reply_to_user_id" : 272230417,
  "text" : "@phildzikiy You mean Popeye's doesn't serve spinach?",
  "id" : 433720423679668224,
  "in_reply_to_status_id" : 433720179613130752,
  "created_at" : "2014-02-12 21:53:01 +0000",
  "in_reply_to_screen_name" : "phildzikiy",
  "in_reply_to_user_id_str" : "272230417",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433709394216235010",
  "geo" : { },
  "id_str" : "433717091791691776",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y basically my life.",
  "id" : 433717091791691776,
  "in_reply_to_status_id" : 433709394216235010,
  "created_at" : "2014-02-12 21:39:47 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/433677474266759168\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/If4WA68OUR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgS7XXlCQAASyKH.png",
      "id_str" : "433677474275147776",
      "id" : 433677474275147776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgS7XXlCQAASyKH.png",
      "sizes" : [ {
        "h" : 487,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1352,
        "resize" : "fit",
        "w" : 942
      }, {
        "h" : 1352,
        "resize" : "fit",
        "w" : 942
      }, {
        "h" : 861,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/If4WA68OUR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/iMlb4NGdKQ",
      "expanded_url" : "https:\/\/ifttt.com\/recipes\/146177-post-new-gold-medals-into-campfire",
      "display_url" : "ifttt.com\/recipes\/146177\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433677474266759168",
  "text" : "The Basecamp All Sports room is truly remote. USA, CAN, RUS, GBR gold medals being piped in! https:\/\/t.co\/iMlb4NGdKQ http:\/\/t.co\/If4WA68OUR",
  "id" : 433677474266759168,
  "created_at" : "2014-02-12 19:02:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rjs\/status\/433675732946911232\/photo\/1",
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/UMSpD9XjNj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgS5yAJCcAA0DK5.png",
      "id_str" : "433675732816916480",
      "id" : 433675732816916480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgS5yAJCcAA0DK5.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 742,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 844,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 844,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UMSpD9XjNj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433675918456811520",
  "text" : "RT @rjs: Good design is like a bell curve. You want to tune to the sweet spot between \"not enough\" and \"not valuable.\" http:\/\/t.co\/UMSpD9Xj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rjs\/status\/433675732946911232\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/UMSpD9XjNj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgS5yAJCcAA0DK5.png",
        "id_str" : "433675732816916480",
        "id" : 433675732816916480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgS5yAJCcAA0DK5.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 742,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 844,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 844,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/UMSpD9XjNj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433675732946911232",
    "text" : "Good design is like a bell curve. You want to tune to the sweet spot between \"not enough\" and \"not valuable.\" http:\/\/t.co\/UMSpD9XjNj",
    "id" : 433675732946911232,
    "created_at" : "2014-02-12 18:55:26 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 433675918456811520,
  "created_at" : "2014-02-12 18:56:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433673663771332608",
  "geo" : { },
  "id_str" : "433673820138786816",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella ooof :(",
  "id" : 433673820138786816,
  "in_reply_to_status_id" : 433673663771332608,
  "created_at" : "2014-02-12 18:47:50 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 64, 70 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/iMlb4NGdKQ",
      "expanded_url" : "https:\/\/ifttt.com\/recipes\/146177-post-new-gold-medals-into-campfire",
      "display_url" : "ifttt.com\/recipes\/146177\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433660569145446400",
  "text" : "Now posting USA vs RUS gold medals counts in Campfire. Get your @IFTTT recipe here! https:\/\/t.co\/iMlb4NGdKQ",
  "id" : 433660569145446400,
  "created_at" : "2014-02-12 17:55:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 16, 29 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 30, 39 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433616948035715073",
  "geo" : { },
  "id_str" : "433627264882712576",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog @antelopeezer @LawnMemo Cool. Hoping to make some of it.",
  "id" : 433627264882712576,
  "in_reply_to_status_id" : 433616948035715073,
  "created_at" : "2014-02-12 15:42:51 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 16, 29 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 30, 39 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433614321285746688",
  "geo" : { },
  "id_str" : "433614826229596162",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog @antelopeezer @LawnMemo yeah, would love to, but new dad duty means I have limited time...any ideas when AQ hits the stage?",
  "id" : 433614826229596162,
  "in_reply_to_status_id" : 433614321285746688,
  "created_at" : "2014-02-12 14:53:25 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 14, 29 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 111, 120 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433613613224300544",
  "geo" : { },
  "id_str" : "433613884683849728",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer @UnclePhilsBlog This show was so good. Any idea when they're starting tonight? Got the pass! \/cc @LawnMemo",
  "id" : 433613884683849728,
  "in_reply_to_status_id" : 433613613224300544,
  "created_at" : "2014-02-12 14:49:40 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433394820095430657",
  "geo" : { },
  "id_str" : "433410854944772096",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle we've been doing more objc lately. The iPhone app is still in RM for now.",
  "id" : 433410854944772096,
  "in_reply_to_status_id" : 433394820095430657,
  "created_at" : "2014-02-12 01:22:54 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 8, 16 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 17, 21 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433361622220800002",
  "geo" : { },
  "id_str" : "433382658786078720",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik @evanphx @lrz i was envisioning a monthly\/quarterly report, or even just upload the Amazon bill as a PDF. Doesn't have to be fancy.",
  "id" : 433382658786078720,
  "in_reply_to_status_id" : 433361622220800002,
  "created_at" : "2014-02-11 23:30:52 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 5, 12 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 47, 55 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433348111507812352",
  "geo" : { },
  "id_str" : "433348325966761984",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz @sferik Definitely does not. Been bugging @evanphx to publish all of the costs publicly for a bit now... ;)",
  "id" : 433348325966761984,
  "in_reply_to_status_id" : 433348111507812352,
  "created_at" : "2014-02-11 21:14:26 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    }, {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 14, 20 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/2Q56mpq4dn",
      "expanded_url" : "http:\/\/gittip.com\/rubygems",
      "display_url" : "gittip.com\/rubygems"
    } ]
  },
  "in_reply_to_status_id_str" : "433327887660232704",
  "geo" : { },
  "id_str" : "433332291884953602",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel @drnic http:\/\/t.co\/2Q56mpq4dn too.",
  "id" : 433332291884953602,
  "in_reply_to_status_id" : 433327887660232704,
  "created_at" : "2014-02-11 20:10:43 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/UsP82AxaM3",
      "expanded_url" : "http:\/\/yourmaclifeshow.com\/QT\/Box-Abuse.mov",
      "display_url" : "yourmaclifeshow.com\/QT\/Box-Abuse.m\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "433316114349563905",
  "geo" : { },
  "id_str" : "433316642244657152",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy http:\/\/t.co\/UsP82AxaM3",
  "id" : 433316642244657152,
  "in_reply_to_status_id" : 433316114349563905,
  "created_at" : "2014-02-11 19:08:32 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433315924478017537",
  "geo" : { },
  "id_str" : "433316128824098816",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow Have you tried RubyMotion yet?",
  "id" : 433316128824098816,
  "in_reply_to_status_id" : 433315924478017537,
  "created_at" : "2014-02-11 19:06:30 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "benarent",
      "screen_name" : "benarent",
      "indices" : [ 0, 9 ],
      "id_str" : "10750482",
      "id" : 10750482
    }, {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 10, 16 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433304529820323840",
  "geo" : { },
  "id_str" : "433304970264182784",
  "in_reply_to_user_id" : 10750482,
  "text" : "@benarent @drnic Build it!! I would use this too.",
  "id" : 433304970264182784,
  "in_reply_to_status_id" : 433304529820323840,
  "created_at" : "2014-02-11 18:22:09 +0000",
  "in_reply_to_screen_name" : "benarent",
  "in_reply_to_user_id_str" : "10750482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kiki Aardsma",
      "screen_name" : "kikiaards",
      "indices" : [ 3, 13 ],
      "id_str" : "355473809",
      "id" : 355473809
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 79, 89 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "weworkremotely",
      "indices" : [ 123, 138 ]
    }, {
      "text" : "basecamp",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/TA3eKVai8i",
      "expanded_url" : "https:\/\/weworkremotely.com\/jobs\/424",
      "display_url" : "weworkremotely.com\/jobs\/424"
    } ]
  },
  "geo" : { },
  "id_str" : "433304586292846593",
  "text" : "RT @kikiaards: Y'all! We're still looking for two awesome people to join us at @37signals Support: https:\/\/t.co\/TA3eKVai8i #weworkremotely \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 64, 74 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "weworkremotely",
        "indices" : [ 108, 123 ]
      }, {
        "text" : "basecamp",
        "indices" : [ 124, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/TA3eKVai8i",
        "expanded_url" : "https:\/\/weworkremotely.com\/jobs\/424",
        "display_url" : "weworkremotely.com\/jobs\/424"
      } ]
    },
    "geo" : { },
    "id_str" : "433304527899332608",
    "text" : "Y'all! We're still looking for two awesome people to join us at @37signals Support: https:\/\/t.co\/TA3eKVai8i #weworkremotely #basecamp",
    "id" : 433304527899332608,
    "created_at" : "2014-02-11 18:20:24 +0000",
    "user" : {
      "name" : "Kiki Aardsma",
      "screen_name" : "kikiaards",
      "protected" : false,
      "id_str" : "355473809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559034855111929856\/68mU4W23_normal.jpeg",
      "id" : 355473809,
      "verified" : false
    }
  },
  "id" : 433304586292846593,
  "created_at" : "2014-02-11 18:20:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "433303064561197057",
  "text" : "Huge thanks to the people, companies and Ruby Central who keep http:\/\/t.co\/2bA9BVLhWr community supported and ad-free since 2009.",
  "id" : 433303064561197057,
  "created_at" : "2014-02-11 18:14:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 3, 9 ],
      "id_str" : "9885102",
      "id" : 9885102
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 82, 88 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/drnic\/status\/433302490377768960\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/p2UJwVR3D6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgNmUbBCIAA0hiy.png",
      "id_str" : "433302490193207296",
      "id" : 433302490193207296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgNmUbBCIAA0hiy.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 642,
        "resize" : "fit",
        "w" : 959
      }, {
        "h" : 642,
        "resize" : "fit",
        "w" : 959
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/p2UJwVR3D6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/BlPZkVZVkh",
      "expanded_url" : "http:\/\/Rubygems.org",
      "display_url" : "Rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "433302643784835072",
  "text" : "RT @drnic: What if http:\/\/t.co\/BlPZkVZVkh had adverts like Maven? Introducing the @qrush Card. http:\/\/t.co\/p2UJwVR3D6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 71, 77 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/drnic\/status\/433302490377768960\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/p2UJwVR3D6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgNmUbBCIAA0hiy.png",
        "id_str" : "433302490193207296",
        "id" : 433302490193207296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgNmUbBCIAA0hiy.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 642,
          "resize" : "fit",
          "w" : 959
        }, {
          "h" : 642,
          "resize" : "fit",
          "w" : 959
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/p2UJwVR3D6"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 30 ],
        "url" : "http:\/\/t.co\/BlPZkVZVkh",
        "expanded_url" : "http:\/\/Rubygems.org",
        "display_url" : "Rubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "433302490377768960",
    "text" : "What if http:\/\/t.co\/BlPZkVZVkh had adverts like Maven? Introducing the @qrush Card. http:\/\/t.co\/p2UJwVR3D6",
    "id" : 433302490377768960,
    "created_at" : "2014-02-11 18:12:18 +0000",
    "user" : {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "protected" : false,
      "id_str" : "9885102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540867377907253249\/T8RB8AXG_normal.jpeg",
      "id" : 9885102,
      "verified" : false
    }
  },
  "id" : 433302643784835072,
  "created_at" : "2014-02-11 18:12:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 3, 11 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 13, 19 ],
      "id_str" : "9885102",
      "id" : 9885102
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 20, 26 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433299204278980609",
  "text" : "RT @evanphx: @drnic @qrush I think being a community resource funded by the community is a better business model.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr Nic",
        "screen_name" : "drnic",
        "indices" : [ 0, 6 ],
        "id_str" : "9885102",
        "id" : 9885102
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 7, 13 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "433297452326592512",
    "geo" : { },
    "id_str" : "433299079448121344",
    "in_reply_to_user_id" : 9885102,
    "text" : "@drnic @qrush I think being a community resource funded by the community is a better business model.",
    "id" : 433299079448121344,
    "in_reply_to_status_id" : 433297452326592512,
    "created_at" : "2014-02-11 17:58:45 +0000",
    "in_reply_to_screen_name" : "drnic",
    "in_reply_to_user_id_str" : "9885102",
    "user" : {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "protected" : false,
      "id_str" : "5444392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500424848519077892\/9BhPED16_normal.jpeg",
      "id" : 5444392,
      "verified" : false
    }
  },
  "id" : 433299204278980609,
  "created_at" : "2014-02-11 17:59:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433298766251053056",
  "geo" : { },
  "id_str" : "433298821984960512",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove wow !",
  "id" : 433298821984960512,
  "in_reply_to_status_id" : 433298766251053056,
  "created_at" : "2014-02-11 17:57:44 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Burton",
      "screen_name" : "bjburton",
      "indices" : [ 0, 9 ],
      "id_str" : "14858358",
      "id" : 14858358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433295410028093440",
  "geo" : { },
  "id_str" : "433296229036855296",
  "in_reply_to_user_id" : 14858358,
  "text" : "@bjburton I have no idea what Ruby Central would do with money like that. I'd assume most would go to full time people...which we have zero.",
  "id" : 433296229036855296,
  "in_reply_to_status_id" : 433295410028093440,
  "created_at" : "2014-02-11 17:47:25 +0000",
  "in_reply_to_screen_name" : "bjburton",
  "in_reply_to_user_id_str" : "14858358",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 3, 12 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433295527094910976",
  "text" : "RT @roidrage: Money and power to the people who deserve it, but is the NPM registry being run by a venture-backed company with eventual exi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433295247410745344",
    "text" : "Money and power to the people who deserve it, but is the NPM registry being run by a venture-backed company with eventual exit a good idea?",
    "id" : 433295247410745344,
    "created_at" : "2014-02-11 17:43:31 +0000",
    "user" : {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "protected" : false,
      "id_str" : "14658472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2938540224\/9ffc554b0eabb077a915cfe0d56f3c1f_normal.jpeg",
      "id" : 14658472,
      "verified" : false
    }
  },
  "id" : 433295527094910976,
  "created_at" : "2014-02-11 17:44:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/XUHzL9r7qM",
      "expanded_url" : "http:\/\/blog.npmjs.org\/post\/76320673650\/funding",
      "display_url" : "blog.npmjs.org\/post\/763206736\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433294955763617792",
  "text" : "I get the professional services route, but seriously, what? http:\/\/t.co\/XUHzL9r7qM",
  "id" : 433294955763617792,
  "created_at" : "2014-02-11 17:42:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433294885114757121",
  "text" : "I don't even understand what a package management system would do with funding. What's the exit? Business model?",
  "id" : 433294885114757121,
  "created_at" : "2014-02-11 17:42:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick",
      "screen_name" : "Nick_Macht_Bier",
      "indices" : [ 0, 16 ],
      "id_str" : "1228996698",
      "id" : 1228996698
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 17, 31 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 32, 43 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433288856742273024",
  "geo" : { },
  "id_str" : "433290319883276288",
  "in_reply_to_user_id" : 1228996698,
  "text" : "@Nick_Macht_Bier @coworkbuffalo @kevinpurdy we're thinking of opening a Shopify store soon with stickers, mugs, posters!",
  "id" : 433290319883276288,
  "in_reply_to_status_id" : 433288856742273024,
  "created_at" : "2014-02-11 17:23:57 +0000",
  "in_reply_to_screen_name" : "Nick_Macht_Bier",
  "in_reply_to_user_id_str" : "1228996698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 7, 21 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/PbRL0QuEyW",
      "expanded_url" : "http:\/\/upload.wikimedia.org\/wikipedia\/commons\/2\/2c\/Buffalo_sentence_1_parse_tree.svg",
      "display_url" : "upload.wikimedia.org\/wikipedia\/comm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "433284476970352640",
  "geo" : { },
  "id_str" : "433284789714444288",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH @coworkbuffalo I am tempted to blow up http:\/\/t.co\/PbRL0QuEyW for the walls too.",
  "id" : 433284789714444288,
  "in_reply_to_status_id" : 433284476970352640,
  "created_at" : "2014-02-11 17:01:58 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/433283692698415104\/photo\/1",
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/CdVYGiXC9E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgNVOPpCAAEyy9e.jpg",
      "id_str" : "433283692362858497",
      "id" : 433283692362858497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgNVOPpCAAEyy9e.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/CdVYGiXC9E"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433283794087342080",
  "text" : "RT @coworkbuffalo: Our new signs look awesome! Huge thanks to our Kickstarter supporters for helping us improve the space. http:\/\/t.co\/CdVY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/433283692698415104\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/CdVYGiXC9E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgNVOPpCAAEyy9e.jpg",
        "id_str" : "433283692362858497",
        "id" : 433283692362858497,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgNVOPpCAAEyy9e.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/CdVYGiXC9E"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433283692698415104",
    "text" : "Our new signs look awesome! Huge thanks to our Kickstarter supporters for helping us improve the space. http:\/\/t.co\/CdVYGiXC9E",
    "id" : 433283692698415104,
    "created_at" : "2014-02-11 16:57:37 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 433283794087342080,
  "created_at" : "2014-02-11 16:58:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/UqqmMJ2IDT",
      "expanded_url" : "http:\/\/ashedryden.com\/blog\/codes-of-conduct-101-faq",
      "display_url" : "ashedryden.com\/blog\/codes-of-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433081694602543104",
  "text" : "Great FAQ for conference organizers on Codes of Conducts: http:\/\/t.co\/UqqmMJ2IDT",
  "id" : 433081694602543104,
  "created_at" : "2014-02-11 03:34:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433081274907901952",
  "geo" : { },
  "id_str" : "433081532442370048",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking oh strange. Sounded like a good thing!",
  "id" : 433081532442370048,
  "in_reply_to_status_id" : 433081274907901952,
  "created_at" : "2014-02-11 03:34:18 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433080259454316544",
  "geo" : { },
  "id_str" : "433080591521562625",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking Yup.",
  "id" : 433080591521562625,
  "in_reply_to_status_id" : 433080259454316544,
  "created_at" : "2014-02-11 03:30:33 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Evans",
      "screen_name" : "b0rk",
      "indices" : [ 0, 5 ],
      "id_str" : "6603532",
      "id" : 6603532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433002269949181952",
  "geo" : { },
  "id_str" : "433002499574755328",
  "in_reply_to_user_id" : 5743852,
  "text" : "@b0rk it was actually longer than that! Over 6 until we got started. Other than that: Coffee. Lots of good coffee.",
  "id" : 433002499574755328,
  "in_reply_to_status_id" : 433002269949181952,
  "created_at" : "2014-02-10 22:20:15 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Evans",
      "screen_name" : "b0rk",
      "indices" : [ 0, 5 ],
      "id_str" : "6603532",
      "id" : 6603532
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 121, 135 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432999056382914560",
  "geo" : { },
  "id_str" : "433002269949181952",
  "in_reply_to_user_id" : 6603532,
  "text" : "@b0rk actually leaving the house to get work done helped me immensely. Went stir crazy for 3 months until I helped start @coworkbuffalo.",
  "id" : 433002269949181952,
  "in_reply_to_status_id" : 432999056382914560,
  "created_at" : "2014-02-10 22:19:20 +0000",
  "in_reply_to_screen_name" : "b0rk",
  "in_reply_to_user_id_str" : "6603532",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 14, 25 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 26, 40 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/k74sMzGHz2",
      "expanded_url" : "http:\/\/gitready.com\/beginner\/2009\/01\/18\/the-staging-area.html",
      "display_url" : "gitready.com\/beginner\/2009\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "432990465034448896",
  "geo" : { },
  "id_str" : "432992136582025216",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @ashedryden @garybernhardt :( I still like my loading dock\/truck analogy for staging area. http:\/\/t.co\/k74sMzGHz2",
  "id" : 432992136582025216,
  "in_reply_to_status_id" : 432990465034448896,
  "created_at" : "2014-02-10 21:39:04 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432931323842265089",
  "geo" : { },
  "id_str" : "432979679754985472",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove had to learn RCS, CVS and SVN at RIT.",
  "id" : 432979679754985472,
  "in_reply_to_status_id" : 432931323842265089,
  "created_at" : "2014-02-10 20:49:34 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Norris",
      "screen_name" : "rsl",
      "indices" : [ 0, 4 ],
      "id_str" : "82863",
      "id" : 82863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432945178844737536",
  "geo" : { },
  "id_str" : "432945311753846784",
  "in_reply_to_user_id" : 82863,
  "text" : "@rsl Yep! hjkl are movement in vim. Home row!",
  "id" : 432945311753846784,
  "in_reply_to_status_id" : 432945178844737536,
  "created_at" : "2014-02-10 18:33:00 +0000",
  "in_reply_to_screen_name" : "rsl",
  "in_reply_to_user_id_str" : "82863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432944868067778560",
  "text" : "Since when does Facebook support vim j\/k movements on the timeline?!",
  "id" : 432944868067778560,
  "created_at" : "2014-02-10 18:31:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Marsh",
      "screen_name" : "ryan_marsh",
      "indices" : [ 0, 11 ],
      "id_str" : "8679692",
      "id" : 8679692
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 12, 20 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432619061000679425",
  "geo" : { },
  "id_str" : "432622564507017216",
  "in_reply_to_user_id" : 8679692,
  "text" : "@ryan_marsh @evanphx would know, and we definitely have a mirror in Japan already.",
  "id" : 432622564507017216,
  "in_reply_to_status_id" : 432619061000679425,
  "created_at" : "2014-02-09 21:10:31 +0000",
  "in_reply_to_screen_name" : "ryan_marsh",
  "in_reply_to_user_id_str" : "8679692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432363319081836544",
  "text" : "Said my first \"I work at Basecamp\" tonight. Felt right.",
  "id" : 432363319081836544,
  "created_at" : "2014-02-09 04:00:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432340404088737792",
  "text" : "Lego Undercover is the best GTA cover I've ever played. Goofy fun and lots of movie parodies.",
  "id" : 432340404088737792,
  "created_at" : "2014-02-09 02:29:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432259001536241664",
  "geo" : { },
  "id_str" : "432261288375234561",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit Godspeed sir. There's free wifi next door at the supermarket!",
  "id" : 432261288375234561,
  "in_reply_to_status_id" : 432259001536241664,
  "created_at" : "2014-02-08 21:14:56 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432260814561886208",
  "geo" : { },
  "id_str" : "432261028231929856",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark THE SPICE MUST FLOW",
  "id" : 432261028231929856,
  "in_reply_to_status_id" : 432260814561886208,
  "created_at" : "2014-02-08 21:13:54 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/AZNeCiJGD5",
      "expanded_url" : "http:\/\/ponzi.io\/",
      "display_url" : "ponzi.io"
    } ]
  },
  "geo" : { },
  "id_str" : "432240783786139648",
  "text" : "Today in \"Please take my cryptocurrency seriously\": http:\/\/t.co\/AZNeCiJGD5",
  "id" : 432240783786139648,
  "created_at" : "2014-02-08 19:53:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "indices" : [ 3, 8 ],
      "id_str" : "10221",
      "id" : 10221
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/drew\/status\/431899927833092097\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/MGqyxqm2mh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf5qsjFCIAQrIX5.png",
      "id_str" : "431899927837286404",
      "id" : 431899927837286404,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf5qsjFCIAQrIX5.png",
      "sizes" : [ {
        "h" : 331,
        "resize" : "fit",
        "w" : 574
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 574
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 574
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MGqyxqm2mh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432162035539779584",
  "text" : "RT @drew: i quit tech. i'm done. http:\/\/t.co\/MGqyxqm2mh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/drew\/status\/431899927833092097\/photo\/1",
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/MGqyxqm2mh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf5qsjFCIAQrIX5.png",
        "id_str" : "431899927837286404",
        "id" : 431899927837286404,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf5qsjFCIAQrIX5.png",
        "sizes" : [ {
          "h" : 331,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 196,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MGqyxqm2mh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431899927833092097",
    "text" : "i quit tech. i'm done. http:\/\/t.co\/MGqyxqm2mh",
    "id" : 431899927833092097,
    "created_at" : "2014-02-07 21:19:01 +0000",
    "user" : {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "protected" : false,
      "id_str" : "10221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558018888361734144\/PKnxZHi__normal.jpeg",
      "id" : 10221,
      "verified" : false
    }
  },
  "id" : 432162035539779584,
  "created_at" : "2014-02-08 14:40:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/HyF4FWstDp",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=gD-nzHy2DdU",
      "display_url" : "youtube.com\/watch?v=gD-nzH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431968467340623872",
  "text" : "How to beat Flappy Bird! http:\/\/t.co\/HyF4FWstDp",
  "id" : 431968467340623872,
  "created_at" : "2014-02-08 01:51:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431921975238205441",
  "geo" : { },
  "id_str" : "431928794270531585",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub no it's a custom made foam core sign.",
  "id" : 431928794270531585,
  "in_reply_to_status_id" : 431921975238205441,
  "created_at" : "2014-02-07 23:13:44 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 0, 15 ],
      "id_str" : "13639982",
      "id" : 13639982
    }, {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 25, 34 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431916425989869568",
  "geo" : { },
  "id_str" : "431916767124811776",
  "in_reply_to_user_id" : 13639982,
  "text" : "@MarkVillacampa this was @shildner's doing. Our attempts here have been lackluster.",
  "id" : 431916767124811776,
  "in_reply_to_status_id" : 431916425989869568,
  "created_at" : "2014-02-07 22:25:56 +0000",
  "in_reply_to_screen_name" : "MarkVillacampa",
  "in_reply_to_user_id_str" : "13639982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 22, 36 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/431914967151820802\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/9H2VXmuK8T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf54X8ECcAEhF0c.jpg",
      "id_str" : "431914966929534977",
      "id" : 431914966929534977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf54X8ECcAEhF0c.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/9H2VXmuK8T"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431914967151820802",
  "text" : "3D @coworkbuffalo, 2D @coworkbuffalo! http:\/\/t.co\/9H2VXmuK8T",
  "id" : 431914967151820802,
  "created_at" : "2014-02-07 22:18:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/431905370315816960\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/MGCgT8ZHvK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf5vpVLCEAA2xzv.jpg",
      "id_str" : "431905370122883072",
      "id" : 431905370122883072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf5vpVLCEAA2xzv.jpg",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MGCgT8ZHvK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431908577997897729",
  "text" : "RT @coworkbuffalo: Happening now ... http:\/\/t.co\/MGCgT8ZHvK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/carbonandroid\" rel=\"nofollow\"\u003ECarbon for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/431905370315816960\/photo\/1",
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/MGCgT8ZHvK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf5vpVLCEAA2xzv.jpg",
        "id_str" : "431905370122883072",
        "id" : 431905370122883072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf5vpVLCEAA2xzv.jpg",
        "sizes" : [ {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/MGCgT8ZHvK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431905370315816960",
    "text" : "Happening now ... http:\/\/t.co\/MGCgT8ZHvK",
    "id" : 431905370315816960,
    "created_at" : "2014-02-07 21:40:39 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 431908577997897729,
  "created_at" : "2014-02-07 21:53:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/Z6XBiQQliH",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=_-agl0pOQfs",
      "display_url" : "youtube.com\/watch?v=_-agl0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431889258329030656",
  "text" : "Current status: http:\/\/t.co\/Z6XBiQQliH",
  "id" : 431889258329030656,
  "created_at" : "2014-02-07 20:36:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/EixHciLf9M",
      "expanded_url" : "http:\/\/www.icetfinallevel.com\/episodes\/2014\/2\/4\/episode-3-dungeons-dragons-the-cia-and-the-future-of-ice-loves-coco",
      "display_url" : "icetfinallevel.com\/episodes\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431858989937078272",
  "text" : "\"This motherfucker got a sword that talks to him. And shit.\" http:\/\/t.co\/EixHciLf9M",
  "id" : 431858989937078272,
  "created_at" : "2014-02-07 18:36:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 37, 49 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431851260891766785",
  "text" : "Just braved -9\u00BAF with wind chill for @whereslloyd. Dedication.",
  "id" : 431851260891766785,
  "created_at" : "2014-02-07 18:05:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/431796010826747904\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/lXaXvPEH0t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf4MLxQCcAEIEjR.jpg",
      "id_str" : "431796010612846593",
      "id" : 431796010612846593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf4MLxQCcAEIEjR.jpg",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lXaXvPEH0t"
    } ],
    "hashtags" : [ {
      "text" : "OnOurWall",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431796244273307649",
  "text" : "RT @coworkbuffalo: \"'Tell police the Rondo Kid was here again,' the gunman cracked ...\" #OnOurWall http:\/\/t.co\/lXaXvPEH0t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/carbonandroid\" rel=\"nofollow\"\u003ECarbon for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/431796010826747904\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/lXaXvPEH0t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf4MLxQCcAEIEjR.jpg",
        "id_str" : "431796010612846593",
        "id" : 431796010612846593,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf4MLxQCcAEIEjR.jpg",
        "sizes" : [ {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/lXaXvPEH0t"
      } ],
      "hashtags" : [ {
        "text" : "OnOurWall",
        "indices" : [ 69, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431796010826747904",
    "text" : "\"'Tell police the Rondo Kid was here again,' the gunman cracked ...\" #OnOurWall http:\/\/t.co\/lXaXvPEH0t",
    "id" : 431796010826747904,
    "created_at" : "2014-02-07 14:26:06 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 431796244273307649,
  "created_at" : "2014-02-07 14:27:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431744700895485952",
  "geo" : { },
  "id_str" : "431745159693225984",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy \"evil will always triumph because good is dumb\"",
  "id" : 431745159693225984,
  "in_reply_to_status_id" : 431744700895485952,
  "created_at" : "2014-02-07 11:04:02 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELLIOTTCABLE",
      "screen_name" : "ELLIOTTCABLE",
      "indices" : [ 0, 13 ],
      "id_str" : "771681",
      "id" : 771681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431663089226752000",
  "geo" : { },
  "id_str" : "431663345905573888",
  "in_reply_to_user_id" : 771681,
  "text" : "@ELLIOTTCABLE link to a Hangout on Air, but I don't remember ever giving permission to do so",
  "id" : 431663345905573888,
  "in_reply_to_status_id" : 431663089226752000,
  "created_at" : "2014-02-07 05:38:56 +0000",
  "in_reply_to_screen_name" : "ELLIOTTCABLE",
  "in_reply_to_user_id_str" : "771681",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431662175292493824",
  "text" : "Apparently Google tweeted on my behalf without asking, didn't realize until hours later. \uD83D\uDE36",
  "id" : 431662175292493824,
  "created_at" : "2014-02-07 05:34:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431578110585479168",
  "text" : "Met the dogs across the street and their names are Bowser and Koopa. I love this neighborhood.",
  "id" : 431578110585479168,
  "created_at" : "2014-02-07 00:00:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Frank",
      "screen_name" : "stevenf",
      "indices" : [ 3, 11 ],
      "id_str" : "733813",
      "id" : 733813
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/stevenf\/status\/431129373127610368\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/PTBpXXWjNJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bfut4WoCQAAdY3o.jpg",
      "id_str" : "431129373001793536",
      "id" : 431129373001793536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bfut4WoCQAAdY3o.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/PTBpXXWjNJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431523272966942720",
  "text" : "RT @stevenf: http:\/\/t.co\/PTBpXXWjNJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/stevenf\/status\/431129373127610368\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/PTBpXXWjNJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bfut4WoCQAAdY3o.jpg",
        "id_str" : "431129373001793536",
        "id" : 431129373001793536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bfut4WoCQAAdY3o.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/PTBpXXWjNJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431129373127610368",
    "text" : "http:\/\/t.co\/PTBpXXWjNJ",
    "id" : 431129373127610368,
    "created_at" : "2014-02-05 18:17:07 +0000",
    "user" : {
      "name" : "Steven Frank",
      "screen_name" : "stevenf",
      "protected" : false,
      "id_str" : "733813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838378818\/avatar_normal.png",
      "id" : 733813,
      "verified" : false
    }
  },
  "id" : 431523272966942720,
  "created_at" : "2014-02-06 20:22:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/AW8tvxnhuu",
      "expanded_url" : "http:\/\/www.bitgem.info\/",
      "display_url" : "bitgem.info"
    } ]
  },
  "geo" : { },
  "id_str" : "431503216555986944",
  "text" : "Finally, a cryptocurrency for RubyGems! http:\/\/t.co\/AW8tvxnhuu\n\n\u0CA0_\u0CA0",
  "id" : 431503216555986944,
  "created_at" : "2014-02-06 19:02:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacqui Maher",
      "screen_name" : "jacqui",
      "indices" : [ 0, 7 ],
      "id_str" : "355203",
      "id" : 355203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431470798118068225",
  "geo" : { },
  "id_str" : "431471083351326720",
  "in_reply_to_user_id" : 355203,
  "text" : "@jacqui considered doing this with my husky. I've taken him bikejoring many times and he loves it.",
  "id" : 431471083351326720,
  "in_reply_to_status_id" : 431470798118068225,
  "created_at" : "2014-02-06 16:54:57 +0000",
  "in_reply_to_screen_name" : "jacqui",
  "in_reply_to_user_id_str" : "355203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "indices" : [ 0, 13 ],
      "id_str" : "29200620",
      "id" : 29200620
    }, {
      "name" : "Charles Max Wood",
      "screen_name" : "cmaxw",
      "indices" : [ 14, 20 ],
      "id_str" : "14847041",
      "id" : 14847041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/nTEDft4iSN",
      "expanded_url" : "http:\/\/workatjelly.com\/",
      "display_url" : "workatjelly.com"
    } ]
  },
  "in_reply_to_status_id_str" : "431451112483209216",
  "geo" : { },
  "id_str" : "431461706535940096",
  "in_reply_to_user_id" : 29200620,
  "text" : "@TheOtherZach @cmaxw I do, but I hate knowledge being locked up in private spaces. I'd try to start a Jelly first. http:\/\/t.co\/nTEDft4iSN",
  "id" : 431461706535940096,
  "in_reply_to_status_id" : 431451112483209216,
  "created_at" : "2014-02-06 16:17:41 +0000",
  "in_reply_to_screen_name" : "TheOtherZach",
  "in_reply_to_user_id_str" : "29200620",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431178011665133569",
  "text" : "Just realized Keychain Access' icon changes on lock\/unlocking of your keychain. The little details.",
  "id" : 431178011665133569,
  "created_at" : "2014-02-05 21:30:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Gibbs",
      "screen_name" : "n2ishin",
      "indices" : [ 0, 8 ],
      "id_str" : "498182103",
      "id" : 498182103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431124995616411648",
  "geo" : { },
  "id_str" : "431125931646672897",
  "in_reply_to_user_id" : 498182103,
  "text" : "@n2ishin yep, we do a flat fee of $25 for meetups, or monthly members ($125\/mo) can hold them.",
  "id" : 431125931646672897,
  "in_reply_to_status_id" : 431124995616411648,
  "created_at" : "2014-02-05 18:03:26 +0000",
  "in_reply_to_screen_name" : "n2ishin",
  "in_reply_to_user_id_str" : "498182103",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Perry",
      "screen_name" : "stephperry",
      "indices" : [ 0, 11 ],
      "id_str" : "16008234",
      "id" : 16008234
    }, {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 12, 26 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431119125578919937",
  "geo" : { },
  "id_str" : "431121059396341760",
  "in_reply_to_user_id" : 16008234,
  "text" : "@stephperry @buffalopundit understood! It took being away from the city for 7 years to realize what I had been missing, and how I could help",
  "id" : 431121059396341760,
  "in_reply_to_status_id" : 431119125578919937,
  "created_at" : "2014-02-05 17:44:05 +0000",
  "in_reply_to_screen_name" : "stephperry",
  "in_reply_to_user_id_str" : "16008234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Perry",
      "screen_name" : "stephperry",
      "indices" : [ 0, 11 ],
      "id_str" : "16008234",
      "id" : 16008234
    }, {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 12, 26 ],
      "id_str" : "5795572",
      "id" : 5795572
    }, {
      "name" : "TEDxBuffalo",
      "screen_name" : "TEDxBuffalo",
      "indices" : [ 31, 43 ],
      "id_str" : "140515765",
      "id" : 140515765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431116675681746944",
  "geo" : { },
  "id_str" : "431117846207164417",
  "in_reply_to_user_id" : 16008234,
  "text" : "@stephperry @buffalopundit the @tedxbuffalo team is always looking for people to help, i'm sure",
  "id" : 431117846207164417,
  "in_reply_to_status_id" : 431116675681746944,
  "created_at" : "2014-02-05 17:31:18 +0000",
  "in_reply_to_screen_name" : "stephperry",
  "in_reply_to_user_id_str" : "16008234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Perry",
      "screen_name" : "stephperry",
      "indices" : [ 0, 11 ],
      "id_str" : "16008234",
      "id" : 16008234
    }, {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 12, 26 ],
      "id_str" : "5795572",
      "id" : 5795572
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 61, 75 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 80, 95 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431116675681746944",
  "geo" : { },
  "id_str" : "431117773532442624",
  "in_reply_to_user_id" : 16008234,
  "text" : "@stephperry @buffalopundit I moved back 2 years ago and made @coworkbuffalo and @nickelcityruby since. plenty of ways to get involved.",
  "id" : 431117773532442624,
  "in_reply_to_status_id" : 431116675681746944,
  "created_at" : "2014-02-05 17:31:01 +0000",
  "in_reply_to_screen_name" : "stephperry",
  "in_reply_to_user_id_str" : "16008234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/rBdVqXqVs9",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=sBsi5FGbY2Y",
      "display_url" : "youtube.com\/watch?v=sBsi5F\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "431098389892435968",
  "geo" : { },
  "id_str" : "431115860036440064",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle nothing's perfect, but let me throw logs on this fire: http:\/\/t.co\/rBdVqXqVs9",
  "id" : 431115860036440064,
  "in_reply_to_status_id" : 431098389892435968,
  "created_at" : "2014-02-05 17:23:25 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 5, 17 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Greensky Bluegrass",
      "screen_name" : "campgreensky",
      "indices" : [ 22, 35 ],
      "id_str" : "30786579",
      "id" : 30786579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431111057721921536",
  "text" : "Both @AqueousBand and @campgreensky playing tonight. I need a timeturner, and a good taper setup.",
  "id" : 431111057721921536,
  "created_at" : "2014-02-05 17:04:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Kilroy",
      "screen_name" : "larrykilroy",
      "indices" : [ 0, 12 ],
      "id_str" : "45215853",
      "id" : 45215853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/jor2BXvr98",
      "expanded_url" : "http:\/\/37signals.com\/",
      "display_url" : "37signals.com"
    } ]
  },
  "in_reply_to_status_id_str" : "431110550383104000",
  "geo" : { },
  "id_str" : "431110693018816512",
  "in_reply_to_user_id" : 45215853,
  "text" : "@larrykilroy did you read all of http:\/\/t.co\/jor2BXvr98 ?",
  "id" : 431110693018816512,
  "in_reply_to_status_id" : 431110550383104000,
  "created_at" : "2014-02-05 17:02:53 +0000",
  "in_reply_to_screen_name" : "larrykilroy",
  "in_reply_to_user_id_str" : "45215853",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/NDrvYPVq5t",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Buffalo_buffalo_Buffalo_buffalo_buffalo_buffalo_Buffalo_buffalo",
      "display_url" : "en.wikipedia.org\/wiki\/Buffalo_b\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "431108628339122176",
  "geo" : { },
  "id_str" : "431108958816714752",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y http:\/\/t.co\/NDrvYPVq5t",
  "id" : 431108958816714752,
  "in_reply_to_status_id" : 431108628339122176,
  "created_at" : "2014-02-05 16:56:00 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431107766912962560",
  "text" : "Basecamp basecamp Basecamp basecamp basecamp basecamp Basecamp basecamp",
  "id" : 431107766912962560,
  "created_at" : "2014-02-05 16:51:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Ward",
      "screen_name" : "tomafro",
      "indices" : [ 3, 11 ],
      "id_str" : "806464",
      "id" : 806464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/UcdPJkoaP9",
      "expanded_url" : "https:\/\/basecamp.com\/1679267\/announcements\/38",
      "display_url" : "basecamp.com\/1679267\/announ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431107569504251904",
  "text" : "RT @tomafro: Here's what I've been working on the last few months, Basecamp for Android: https:\/\/t.co\/UcdPJkoaP9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/UcdPJkoaP9",
        "expanded_url" : "https:\/\/basecamp.com\/1679267\/announcements\/38",
        "display_url" : "basecamp.com\/1679267\/announ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "431106093385658370",
    "text" : "Here's what I've been working on the last few months, Basecamp for Android: https:\/\/t.co\/UcdPJkoaP9",
    "id" : 431106093385658370,
    "created_at" : "2014-02-05 16:44:36 +0000",
    "user" : {
      "name" : "Tom Ward",
      "screen_name" : "tomafro",
      "protected" : false,
      "id_str" : "806464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430658549006356480\/cDeKvQY5_normal.png",
      "id" : 806464,
      "verified" : false
    }
  },
  "id" : 431107569504251904,
  "created_at" : "2014-02-05 16:50:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 10, 16 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 17, 25 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431094443827933184",
  "geo" : { },
  "id_str" : "431095070075256834",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone @parkr @whit537 you're forgetting Google too. Just the fact that we have humans that reply to things stuns most people",
  "id" : 431095070075256834,
  "in_reply_to_status_id" : 431094443827933184,
  "created_at" : "2014-02-05 16:00:48 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "43north",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/ZTURdlJOTC",
      "expanded_url" : "http:\/\/www.43north.org\/",
      "display_url" : "43north.org"
    } ]
  },
  "geo" : { },
  "id_str" : "431093808508317696",
  "text" : "Buffalo keeps looking brighter day by day: http:\/\/t.co\/ZTURdlJOTC #43north",
  "id" : 431093808508317696,
  "created_at" : "2014-02-05 15:55:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 10, 18 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/1RIX7md694",
      "expanded_url" : "https:\/\/twitter.com\/jasonfried\/status\/431084141908484096",
      "display_url" : "twitter.com\/jasonfried\/sta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "431090349482594307",
  "geo" : { },
  "id_str" : "431091330190544896",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone @whit537 sadly, they don't care so far. https:\/\/t.co\/1RIX7md694",
  "id" : 431091330190544896,
  "in_reply_to_status_id" : 431090349482594307,
  "created_at" : "2014-02-05 15:45:57 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Matthias Braun",
      "screen_name" : "basecamp",
      "indices" : [ 15, 24 ],
      "id_str" : "260442980",
      "id" : 260442980
    }, {
      "name" : "Basecamp News",
      "screen_name" : "basecampnews",
      "indices" : [ 107, 120 ],
      "id_str" : "47366813",
      "id" : 47366813
    }, {
      "name" : "Basecamp",
      "screen_name" : "BasecampHQ",
      "indices" : [ 124, 135 ],
      "id_str" : "2342315821",
      "id" : 2342315821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431088825331630080",
  "text" : "RT @dhh: While @basecamp is just a person, we haven't had any luck with obviously infringing accounts like @basecampnews or @basecamphq eit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthias Braun",
        "screen_name" : "basecamp",
        "indices" : [ 6, 15 ],
        "id_str" : "260442980",
        "id" : 260442980
      }, {
        "name" : "Basecamp News",
        "screen_name" : "basecampnews",
        "indices" : [ 98, 111 ],
        "id_str" : "47366813",
        "id" : 47366813
      }, {
        "name" : "Basecamp",
        "screen_name" : "BasecampHQ",
        "indices" : [ 115, 126 ],
        "id_str" : "2342315821",
        "id" : 2342315821
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431087915570327552",
    "text" : "While @basecamp is just a person, we haven't had any luck with obviously infringing accounts like @basecampnews or @basecamphq either :(",
    "id" : 431087915570327552,
    "created_at" : "2014-02-05 15:32:22 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 431088825331630080,
  "created_at" : "2014-02-05 15:35:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    }, {
      "name" : "Joe Bean Roasters",
      "screen_name" : "JoeBeanRoasters",
      "indices" : [ 15, 31 ],
      "id_str" : "83895391",
      "id" : 83895391
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 36, 50 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431086407739006976",
  "geo" : { },
  "id_str" : "431086665466388480",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi we get @JoeBeanRoasters for @coworkbuffalo, delicious stuff.",
  "id" : 431086665466388480,
  "in_reply_to_status_id" : 431086407739006976,
  "created_at" : "2014-02-05 15:27:24 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431086063546036225",
  "text" : "RT @jasonfried: Yes\u2026 we've contacted Twitter. Their trademark department has rejected our requests with generic explanation. Hard to dig in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431084141908484096",
    "text" : "Yes\u2026 we've contacted Twitter. Their trademark department has rejected our requests with generic explanation. Hard to dig into that.",
    "id" : 431084141908484096,
    "created_at" : "2014-02-05 15:17:23 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 431086063546036225,
  "created_at" : "2014-02-05 15:25:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "Matthias Braun",
      "screen_name" : "basecamp",
      "indices" : [ 62, 71 ],
      "id_str" : "260442980",
      "id" : 260442980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431085948412375041",
  "text" : "RT @jasonfried: For those who are wondering why we didn't get @basecamp\u2026 Someone else has it. Unresponsive. 1 tweet from 3 years ago. Follo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthias Braun",
        "screen_name" : "basecamp",
        "indices" : [ 46, 55 ],
        "id_str" : "260442980",
        "id" : 260442980
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431083609840025600",
    "text" : "For those who are wondering why we didn't get @basecamp\u2026 Someone else has it. Unresponsive. 1 tweet from 3 years ago. Following 4 people\u2026",
    "id" : 431083609840025600,
    "created_at" : "2014-02-05 15:15:16 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 431085948412375041,
  "created_at" : "2014-02-05 15:24:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 0, 8 ],
      "id_str" : "34175404",
      "id" : 34175404
    }, {
      "name" : "jacobstructionist",
      "screen_name" : "jacobian",
      "indices" : [ 9, 18 ],
      "id_str" : "18824526",
      "id" : 18824526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431079529847611392",
  "geo" : { },
  "id_str" : "431080130560405504",
  "in_reply_to_user_id" : 34175404,
  "text" : "@whit537 @jacobian the battle is ease of mind for those who seek tips and want to make sure it's all valid\/legal with the IRS.",
  "id" : 431080130560405504,
  "in_reply_to_status_id" : 431079529847611392,
  "created_at" : "2014-02-05 15:01:26 +0000",
  "in_reply_to_screen_name" : "whit537",
  "in_reply_to_user_id_str" : "34175404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/xSqiebe5nz",
      "expanded_url" : "https:\/\/basecamp.com\/about",
      "display_url" : "basecamp.com\/about"
    } ]
  },
  "geo" : { },
  "id_str" : "431078116745035776",
  "text" : "This page is my favorite. 26 cities. One team. One product. Stay simple. Give a damn. https:\/\/t.co\/xSqiebe5nz",
  "id" : 431078116745035776,
  "created_at" : "2014-02-05 14:53:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Guy",
      "screen_name" : "thenickguy",
      "indices" : [ 0, 11 ],
      "id_str" : "12304192",
      "id" : 12304192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431074695471853568",
  "geo" : { },
  "id_str" : "431074961114296320",
  "in_reply_to_user_id" : 12304192,
  "text" : "@thenickguy we can merge accounts to make it easier for you. Email nick at basecamp and I can look into after digging out the driveway",
  "id" : 431074961114296320,
  "in_reply_to_status_id" : 431074695471853568,
  "created_at" : "2014-02-05 14:40:54 +0000",
  "in_reply_to_screen_name" : "thenickguy",
  "in_reply_to_user_id_str" : "12304192",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 0, 8 ],
      "id_str" : "34175404",
      "id" : 34175404
    }, {
      "name" : "Joseph DelCioppio",
      "screen_name" : "TheDelChop",
      "indices" : [ 9, 20 ],
      "id_str" : "21233543",
      "id" : 21233543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431071972932325377",
  "geo" : { },
  "id_str" : "431074711519641600",
  "in_reply_to_user_id" : 34175404,
  "text" : "@whit537 @TheDelChop thanks.",
  "id" : 431074711519641600,
  "in_reply_to_status_id" : 431071972932325377,
  "created_at" : "2014-02-05 14:39:54 +0000",
  "in_reply_to_screen_name" : "whit537",
  "in_reply_to_user_id_str" : "34175404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Guy",
      "screen_name" : "thenickguy",
      "indices" : [ 0, 11 ],
      "id_str" : "12304192",
      "id" : 12304192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431074241149009920",
  "geo" : { },
  "id_str" : "431074533039030272",
  "in_reply_to_user_id" : 12304192,
  "text" : "@thenickguy what's not easy about it? Do you have &gt; 1 identity?",
  "id" : 431074533039030272,
  "in_reply_to_status_id" : 431074241149009920,
  "created_at" : "2014-02-05 14:39:12 +0000",
  "in_reply_to_screen_name" : "thenickguy",
  "in_reply_to_user_id_str" : "12304192",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 63, 73 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/M99yrBxKUv",
      "expanded_url" : "http:\/\/basecamp.com\/team",
      "display_url" : "basecamp.com\/team"
    } ]
  },
  "geo" : { },
  "id_str" : "431074067089600512",
  "text" : "Today's my first day at Basecamp. Proud to have been a part of @37signals and to work alongside this team! http:\/\/t.co\/M99yrBxKUv",
  "id" : 431074067089600512,
  "created_at" : "2014-02-05 14:37:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/re9BFFAHMs",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/2626449\/how-can-i-de-install-a-perl-module-installed-via-cpan",
      "display_url" : "stackoverflow.com\/questions\/2626\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430917639137800193",
  "text" : "LOL, can't even uninstall CPAN modules. http:\/\/t.co\/re9BFFAHMs",
  "id" : 430917639137800193,
  "created_at" : "2014-02-05 04:15:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "430914119013654529",
  "text" : "CPAN doesn't tell you how to install a module. Just assumes you know how. Still glad http:\/\/t.co\/2bA9BVLhWr has `gem install` prominent.",
  "id" : 430914119013654529,
  "created_at" : "2014-02-05 04:01:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430899434017157120",
  "geo" : { },
  "id_str" : "430899491609137152",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH MORE STRUTS",
  "id" : 430899491609137152,
  "in_reply_to_status_id" : 430899434017157120,
  "created_at" : "2014-02-05 03:03:39 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Emil Heijkants",
      "screen_name" : "Emil",
      "indices" : [ 10, 15 ],
      "id_str" : "1677561",
      "id" : 1677561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430898348409638912",
  "geo" : { },
  "id_str" : "430898885079216128",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo @Emil or you just need to hack the Nest Protect! :)",
  "id" : 430898885079216128,
  "in_reply_to_status_id" : 430898348409638912,
  "created_at" : "2014-02-05 03:01:14 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/6Wlcyroccx",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=wG6G4XBnvLQ",
      "display_url" : "youtube.com\/watch?v=wG6G4X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430896751281586177",
  "text" : "Current status: http:\/\/t.co\/6Wlcyroccx",
  "id" : 430896751281586177,
  "created_at" : "2014-02-05 02:52:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430894022224125952",
  "geo" : { },
  "id_str" : "430894824128913408",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove SHIP IT",
  "id" : 430894824128913408,
  "in_reply_to_status_id" : 430894022224125952,
  "created_at" : "2014-02-05 02:45:06 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430889652812124161",
  "geo" : { },
  "id_str" : "430893720393613312",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove do you deliver? because we left your last bacon in our AirBNB fridge :(",
  "id" : 430893720393613312,
  "in_reply_to_status_id" : 430889652812124161,
  "created_at" : "2014-02-05 02:40:43 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430887924339441664",
  "geo" : { },
  "id_str" : "430892583762419712",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone suddenly your toaster has a virus, and you need to stare at a game boy for hours to fix it.",
  "id" : 430892583762419712,
  "in_reply_to_status_id" : 430887924339441664,
  "created_at" : "2014-02-05 02:36:12 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce_Adams",
      "screen_name" : "Bruce_Adams",
      "indices" : [ 0, 12 ],
      "id_str" : "16496967",
      "id" : 16496967
    }, {
      "name" : "Gittip",
      "screen_name" : "Gittip",
      "indices" : [ 13, 20 ],
      "id_str" : "2595663126",
      "id" : 2595663126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430890470412410881",
  "geo" : { },
  "id_str" : "430891762421215232",
  "in_reply_to_user_id" : 16496967,
  "text" : "@Bruce_Adams @Gittip sounds like there's a need to start sending tips to accountants for tax advice.",
  "id" : 430891762421215232,
  "in_reply_to_status_id" : 430890470412410881,
  "created_at" : "2014-02-05 02:32:56 +0000",
  "in_reply_to_screen_name" : "Bruce_Adams",
  "in_reply_to_user_id_str" : "16496967",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce_Adams",
      "screen_name" : "Bruce_Adams",
      "indices" : [ 0, 12 ],
      "id_str" : "16496967",
      "id" : 16496967
    }, {
      "name" : "Gittip",
      "screen_name" : "Gittip",
      "indices" : [ 13, 20 ],
      "id_str" : "2595663126",
      "id" : 2595663126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430890470412410881",
  "geo" : { },
  "id_str" : "430891602815369217",
  "in_reply_to_user_id" : 16496967,
  "text" : "@Bruce_Adams @Gittip yeah, understandable. obviously not easy, but avoiding it feels like a copout",
  "id" : 430891602815369217,
  "in_reply_to_status_id" : 430890470412410881,
  "created_at" : "2014-02-05 02:32:18 +0000",
  "in_reply_to_screen_name" : "Bruce_Adams",
  "in_reply_to_user_id_str" : "16496967",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430828985950302208",
  "geo" : { },
  "id_str" : "430890974617681920",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo greensky bluegrass at towne too!",
  "id" : 430890974617681920,
  "in_reply_to_status_id" : 430828985950302208,
  "created_at" : "2014-02-05 02:29:48 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430887924339441664",
  "geo" : { },
  "id_str" : "430888010100400128",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone Yes!!!",
  "id" : 430888010100400128,
  "in_reply_to_status_id" : 430887924339441664,
  "created_at" : "2014-02-05 02:18:01 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 0, 11 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430884688861732864",
  "geo" : { },
  "id_str" : "430884822005735424",
  "in_reply_to_user_id" : 14372143,
  "text" : "@jasonfried give it 5 minutes!",
  "id" : 430884822005735424,
  "in_reply_to_status_id" : 430884688861732864,
  "created_at" : "2014-02-05 02:05:21 +0000",
  "in_reply_to_screen_name" : "jasonfried",
  "in_reply_to_user_id_str" : "14372143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph DelCioppio",
      "screen_name" : "TheDelChop",
      "indices" : [ 0, 11 ],
      "id_str" : "21233543",
      "id" : 21233543
    }, {
      "name" : "Gittip",
      "screen_name" : "Gittip",
      "indices" : [ 51, 58 ],
      "id_str" : "2595663126",
      "id" : 2595663126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430882213379727360",
  "geo" : { },
  "id_str" : "430882535921299456",
  "in_reply_to_user_id" : 21233543,
  "text" : "@TheDelChop yeah, most likely. I would like to see @gittip own this instead of avoiding it",
  "id" : 430882535921299456,
  "in_reply_to_status_id" : 430882213379727360,
  "created_at" : "2014-02-05 01:56:16 +0000",
  "in_reply_to_screen_name" : "TheDelChop",
  "in_reply_to_user_id_str" : "21233543",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 0, 8 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430876424090566656",
  "geo" : { },
  "id_str" : "430876706233016320",
  "in_reply_to_user_id" : 5743852,
  "text" : "@whit537 also this might be too long for 140 chars. :)",
  "id" : 430876706233016320,
  "in_reply_to_status_id" : 430876424090566656,
  "created_at" : "2014-02-05 01:33:06 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 4, 12 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430876424090566656",
  "text" : "Hey @whit537 how are you handling taxes for gittip? I'd imagine anyone making something reasonable has to be worried about it.",
  "id" : 430876424090566656,
  "created_at" : "2014-02-05 01:31:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serhii Balbieko",
      "screen_name" : "balbeko",
      "indices" : [ 0, 8 ],
      "id_str" : "24918275",
      "id" : 24918275
    }, {
      "name" : "Tonya Emelyanova",
      "screen_name" : "emy_ty",
      "indices" : [ 9, 16 ],
      "id_str" : "304642393",
      "id" : 304642393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430871888043474944",
  "geo" : { },
  "id_str" : "430873184246968321",
  "in_reply_to_user_id" : 24918275,
  "text" : "@balbeko @emy_ty nope sorry. maybe post on the RM google group!",
  "id" : 430873184246968321,
  "in_reply_to_status_id" : 430871888043474944,
  "created_at" : "2014-02-05 01:19:07 +0000",
  "in_reply_to_screen_name" : "balbeko",
  "in_reply_to_user_id_str" : "24918275",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    }, {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 50, 59 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430848112941596672",
  "geo" : { },
  "id_str" : "430859527831830528",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh that somehow would feel more genuine. \/cc @ryanbigg",
  "id" : 430859527831830528,
  "in_reply_to_status_id" : 430848112941596672,
  "created_at" : "2014-02-05 00:24:51 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Garcia",
      "screen_name" : "jerrygarcia",
      "indices" : [ 129, 140 ],
      "id_str" : "751004822",
      "id" : 751004822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/7QMdzAjtXw",
      "expanded_url" : "http:\/\/jerrygarcia.com",
      "display_url" : "jerrygarcia.com"
    } ]
  },
  "geo" : { },
  "id_str" : "430853572289241089",
  "text" : "RT @BourbonIO: Take a look at the new http:\/\/t.co\/7QMdzAjtXw. \nI got word it was built with Bourbon.\n\nStellar work @adamschmadum @jerrygarc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jerry Garcia",
        "screen_name" : "jerrygarcia",
        "indices" : [ 114, 126 ],
        "id_str" : "751004822",
        "id" : 751004822
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/7QMdzAjtXw",
        "expanded_url" : "http:\/\/jerrygarcia.com",
        "display_url" : "jerrygarcia.com"
      } ]
    },
    "geo" : { },
    "id_str" : "430852986928386048",
    "text" : "Take a look at the new http:\/\/t.co\/7QMdzAjtXw. \nI got word it was built with Bourbon.\n\nStellar work @adamschmadum @jerrygarcia",
    "id" : 430852986928386048,
    "created_at" : "2014-02-04 23:58:51 +0000",
    "user" : {
      "name" : "Bourbon",
      "screen_name" : "bourbonsass",
      "protected" : false,
      "id_str" : "1278508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3398632962\/39197721d4a449f2e6470cb31bf20d31_normal.jpeg",
      "id" : 1278508478,
      "verified" : false
    }
  },
  "id" : 430853572289241089,
  "created_at" : "2014-02-05 00:01:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 22, 31 ],
      "id_str" : "18230025",
      "id" : 18230025
    }, {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 32, 40 ],
      "id_str" : "22682102",
      "id" : 22682102
    }, {
      "name" : "CloudMine",
      "screen_name" : "CloudMine",
      "indices" : [ 83, 93 ],
      "id_str" : "321499248",
      "id" : 321499248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430818351250554880",
  "geo" : { },
  "id_str" : "430819132515164160",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr you could ping @marcweil @dmansen, but this friend might end up working for @CloudMine instead",
  "id" : 430819132515164160,
  "in_reply_to_status_id" : 430818351250554880,
  "created_at" : "2014-02-04 21:44:20 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/430816661893947393\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/pvJA70W2Yk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfqReK_CIAAg7-I.png",
      "id_str" : "430816661898141696",
      "id" : 430816661898141696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfqReK_CIAAg7-I.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/pvJA70W2Yk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430816661893947393",
  "text" : "Followed one weather account, and Twitter recommendations are not smart about it. http:\/\/t.co\/pvJA70W2Yk",
  "id" : 430816661893947393,
  "created_at" : "2014-02-04 21:34:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pictures in History",
      "screen_name" : "pixofhistory",
      "indices" : [ 3, 16 ],
      "id_str" : "2327686310",
      "id" : 2327686310
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/pixofhistory\/status\/430812829155721216\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/7i5p9tFd3m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfqN_EPCMAENUld.jpg",
      "id_str" : "430812828975378433",
      "id" : 430812828975378433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfqN_EPCMAENUld.jpg",
      "sizes" : [ {
        "h" : 471,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1375
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7i5p9tFd3m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430814053984763904",
  "text" : "RT @pixofhistory: Abraham Lincoln, America\u2019s first stone golem president, 1861 http:\/\/t.co\/7i5p9tFd3m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/pixofhistory\/status\/430812829155721216\/photo\/1",
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/7i5p9tFd3m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfqN_EPCMAENUld.jpg",
        "id_str" : "430812828975378433",
        "id" : 430812828975378433,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfqN_EPCMAENUld.jpg",
        "sizes" : [ {
          "h" : 471,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 804,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1375
        }, {
          "h" : 267,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7i5p9tFd3m"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "430812829155721216",
    "text" : "Abraham Lincoln, America\u2019s first stone golem president, 1861 http:\/\/t.co\/7i5p9tFd3m",
    "id" : 430812829155721216,
    "created_at" : "2014-02-04 21:19:17 +0000",
    "user" : {
      "name" : "Pictures in History",
      "screen_name" : "pixofhistory",
      "protected" : false,
      "id_str" : "2327686310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430808706918268928\/Hk83y7Il_normal.jpeg",
      "id" : 2327686310,
      "verified" : false
    }
  },
  "id" : 430814053984763904,
  "created_at" : "2014-02-04 21:24:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/AdzpDNmczE",
      "expanded_url" : "http:\/\/www.airpair.com\/",
      "display_url" : "airpair.com"
    } ]
  },
  "geo" : { },
  "id_str" : "430806433102184448",
  "text" : "Why does this feel so sleazy? http:\/\/t.co\/AdzpDNmczE",
  "id" : 430806433102184448,
  "created_at" : "2014-02-04 20:53:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    }, {
      "name" : "Kelly Rauwerdink",
      "screen_name" : "missingdink",
      "indices" : [ 11, 23 ],
      "id_str" : "65496324",
      "id" : 65496324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430780405600378880",
  "geo" : { },
  "id_str" : "430800425567010816",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy @missingdink one giant amazon box will do terrible things to you, apparently",
  "id" : 430800425567010816,
  "in_reply_to_status_id" : 430780405600378880,
  "created_at" : "2014-02-04 20:30:00 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/O58D5JCd93",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3550-a-diverse-conference",
      "display_url" : "37signals.com\/svn\/posts\/3550\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430763600190242816",
  "text" : "Good rereading for today: A Diverse Conference http:\/\/t.co\/O58D5JCd93",
  "id" : 430763600190242816,
  "created_at" : "2014-02-04 18:03:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 49, 57 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/RS8rPXqCMk",
      "expanded_url" : "https:\/\/twitter.com\/wnyruby\/status\/430742120329003008",
      "display_url" : "twitter.com\/wnyruby\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430762114269999104",
  "text" : "Also, this deal continues from 2013. Give a talk @wnyruby, we'll put you up for the night and the tacos are on us. https:\/\/t.co\/RS8rPXqCMk",
  "id" : 430762114269999104,
  "created_at" : "2014-02-04 17:57:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 11, 17 ],
      "id_str" : "9885102",
      "id" : 9885102
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 18, 32 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430742761524846593",
  "geo" : { },
  "id_str" : "430752629442887680",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @drnic @coworkbuffalo sadly the ruby paparazzi wasn't following us",
  "id" : 430752629442887680,
  "in_reply_to_status_id" : 430742761524846593,
  "created_at" : "2014-02-04 17:20:04 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 3, 11 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 22, 28 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WNYRuby",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430748794674622464",
  "text" : "RT @wnyruby: Also, as @qrush reminded us - the \"Tacos for Talks\" program is still on - you come talk at a #WNYRuby meetup, we will get you \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 9, 15 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WNYRuby",
        "indices" : [ 93, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "430742120329003008",
    "text" : "Also, as @qrush reminded us - the \"Tacos for Talks\" program is still on - you come talk at a #WNYRuby meetup, we will get you 3 tacos",
    "id" : 430742120329003008,
    "created_at" : "2014-02-04 16:38:18 +0000",
    "user" : {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "protected" : false,
      "id_str" : "205886758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1149676438\/wnyruby_normal.png",
      "id" : 205886758,
      "verified" : false
    }
  },
  "id" : 430748794674622464,
  "created_at" : "2014-02-04 17:04:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 7, 13 ],
      "id_str" : "9885102",
      "id" : 9885102
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 23, 37 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430741913268793344",
  "text" : "A wild @drnic appeared @coworkbuffalo! First Aussie ambassador to the space.",
  "id" : 430741913268793344,
  "created_at" : "2014-02-04 16:37:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "indices" : [ 0, 13 ],
      "id_str" : "29200620",
      "id" : 29200620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430715136039342080",
  "geo" : { },
  "id_str" : "430715668669792257",
  "in_reply_to_user_id" : 29200620,
  "text" : "@TheOtherZach they used to let me post on their blog back in the day",
  "id" : 430715668669792257,
  "in_reply_to_status_id" : 430715136039342080,
  "created_at" : "2014-02-04 14:53:12 +0000",
  "in_reply_to_screen_name" : "TheOtherZach",
  "in_reply_to_user_id_str" : "29200620",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/q3RKpCMXOK",
      "expanded_url" : "https:\/\/github.com\/blog\/208-github-rebase-3",
      "display_url" : "github.com\/blog\/208-githu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430714116248838145",
  "text" : "GitHub's total\/hourly events from 2008 feels paltry in comparison to what it must be today: https:\/\/t.co\/q3RKpCMXOK",
  "id" : 430714116248838145,
  "created_at" : "2014-02-04 14:47:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/q3RKpCMXOK",
      "expanded_url" : "https:\/\/github.com\/blog\/208-github-rebase-3",
      "display_url" : "github.com\/blog\/208-githu\u2026"
    }, {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/6D7B6WNH50",
      "expanded_url" : "http:\/\/rebase.github.io\/",
      "display_url" : "rebase.github.io"
    } ]
  },
  "in_reply_to_status_id_str" : "430706216650555392",
  "geo" : { },
  "id_str" : "430713426994688001",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant nice! I used to do this forever ago... https:\/\/t.co\/q3RKpCMXOK http:\/\/t.co\/6D7B6WNH50",
  "id" : 430713426994688001,
  "in_reply_to_status_id" : 430706216650555392,
  "created_at" : "2014-02-04 14:44:17 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/t3JjY5skaL",
      "expanded_url" : "http:\/\/www.tripadvisor.com\/Restaurant_Review-g188644-d2538104-Reviews-Pixel_Wine_Bar-Brussels.html",
      "display_url" : "tripadvisor.com\/Restaurant_Rev\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "430694752313704448",
  "geo" : { },
  "id_str" : "430697260817469441",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik I just happened to stumble upon it. http:\/\/t.co\/t3JjY5skaL",
  "id" : 430697260817469441,
  "in_reply_to_status_id" : 430694752313704448,
  "created_at" : "2014-02-04 13:40:03 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430683052910862336",
  "geo" : { },
  "id_str" : "430684226887745537",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik get some waffles! Also the pixel cafe was neat to check out.",
  "id" : 430684226887745537,
  "in_reply_to_status_id" : 430683052910862336,
  "created_at" : "2014-02-04 12:48:16 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430525864011653120",
  "geo" : { },
  "id_str" : "430530273311465472",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 THUNDERCATS ARE GO!",
  "id" : 430530273311465472,
  "in_reply_to_status_id" : 430525864011653120,
  "created_at" : "2014-02-04 02:36:30 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 0, 15 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430527982919516160",
  "geo" : { },
  "id_str" : "430530214599622656",
  "in_reply_to_user_id" : 16393800,
  "text" : "@AustinSeraphin hah! Maybe they deliver?",
  "id" : 430530214599622656,
  "in_reply_to_status_id" : 430527982919516160,
  "created_at" : "2014-02-04 02:36:16 +0000",
  "in_reply_to_screen_name" : "AustinSeraphin",
  "in_reply_to_user_id_str" : "16393800",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 25, 36 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430507963166371840",
  "geo" : { },
  "id_str" : "430522202077679616",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu I am going to make @kevinpurdy typeset the poster now",
  "id" : 430522202077679616,
  "in_reply_to_status_id" : 430507963166371840,
  "created_at" : "2014-02-04 02:04:26 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u277A\u27A0 David Copeland",
      "screen_name" : "davetron5000",
      "indices" : [ 0, 13 ],
      "id_str" : "5660222",
      "id" : 5660222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/9PVGgYH3qZ",
      "expanded_url" : "http:\/\/uptime.rubygems.org",
      "display_url" : "uptime.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "430518823884972032",
  "geo" : { },
  "id_str" : "430519447825039360",
  "in_reply_to_user_id" : 5660222,
  "text" : "@davetron5000 not down according to pingdom. 100% uptime for January! http:\/\/t.co\/9PVGgYH3qZ",
  "id" : 430519447825039360,
  "in_reply_to_status_id" : 430518823884972032,
  "created_at" : "2014-02-04 01:53:29 +0000",
  "in_reply_to_screen_name" : "davetron5000",
  "in_reply_to_user_id_str" : "5660222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 3, 9 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vrunt\/status\/430518894126563328\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/71A7agcfgW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfmCpznCAAAbGkP.jpg",
      "id_str" : "430518894130757632",
      "id" : 430518894130757632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfmCpznCAAAbGkP.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/71A7agcfgW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430519119293595648",
  "text" : "RT @vrunt: i ordered boneless buffalo wings. in what universe are these boneless buffalo wings. http:\/\/t.co\/71A7agcfgW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vrunt\/status\/430518894126563328\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/71A7agcfgW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfmCpznCAAAbGkP.jpg",
        "id_str" : "430518894130757632",
        "id" : 430518894130757632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfmCpznCAAAbGkP.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/71A7agcfgW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "430518894126563328",
    "text" : "i ordered boneless buffalo wings. in what universe are these boneless buffalo wings. http:\/\/t.co\/71A7agcfgW",
    "id" : 430518894126563328,
    "created_at" : "2014-02-04 01:51:17 +0000",
    "user" : {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "protected" : false,
      "id_str" : "15062828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566801374143586305\/yApDWRcm_normal.jpeg",
      "id" : 15062828,
      "verified" : false
    }
  },
  "id" : 430519119293595648,
  "created_at" : "2014-02-04 01:52:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Erin Biba",
      "screen_name" : "erinbiba",
      "indices" : [ 129, 138 ],
      "id_str" : "19624836",
      "id" : 19624836
    }, {
      "name" : "Lifehacker",
      "screen_name" : "lifehacker",
      "indices" : [ 139, 140 ],
      "id_str" : "7144422",
      "id" : 7144422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/qg7VHyHsrK",
      "expanded_url" : "http:\/\/Thistothat.com",
      "display_url" : "Thistothat.com"
    }, {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/7y9SGbK18L",
      "expanded_url" : "http:\/\/thistothat.com\/",
      "display_url" : "thistothat.com"
    } ]
  },
  "geo" : { },
  "id_str" : "430461545479278592",
  "text" : "RT @kevinpurdy: Wow. Need to glue something to something? \"http:\/\/t.co\/qg7VHyHsrK\" is there for you. http:\/\/t.co\/7y9SGbK18L (via @erinbiba,\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Erin Biba",
        "screen_name" : "erinbiba",
        "indices" : [ 113, 122 ],
        "id_str" : "19624836",
        "id" : 19624836
      }, {
        "name" : "Lifehacker",
        "screen_name" : "lifehacker",
        "indices" : [ 128, 139 ],
        "id_str" : "7144422",
        "id" : 7144422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/qg7VHyHsrK",
        "expanded_url" : "http:\/\/Thistothat.com",
        "display_url" : "Thistothat.com"
      }, {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/7y9SGbK18L",
        "expanded_url" : "http:\/\/thistothat.com\/",
        "display_url" : "thistothat.com"
      } ]
    },
    "geo" : { },
    "id_str" : "430461356542656512",
    "text" : "Wow. Need to glue something to something? \"http:\/\/t.co\/qg7VHyHsrK\" is there for you. http:\/\/t.co\/7y9SGbK18L (via @erinbiba, cc: @lifehacker)",
    "id" : 430461356542656512,
    "created_at" : "2014-02-03 22:02:39 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 430461545479278592,
  "created_at" : "2014-02-03 22:03:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NEIL cicierega",
      "screen_name" : "neilyourself",
      "indices" : [ 0, 13 ],
      "id_str" : "15360428",
      "id" : 15360428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430458964007219200",
  "geo" : { },
  "id_str" : "430459289870671872",
  "in_reply_to_user_id" : 15360428,
  "text" : "@neilyourself \"I don't know who you are. But I will find you. And I will melt you.\"",
  "id" : 430459289870671872,
  "in_reply_to_status_id" : 430458964007219200,
  "created_at" : "2014-02-03 21:54:26 +0000",
  "in_reply_to_screen_name" : "neilyourself",
  "in_reply_to_user_id_str" : "15360428",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    }, {
      "name" : "Pratik",
      "screen_name" : "lifo",
      "indices" : [ 7, 12 ],
      "id_str" : "6106092",
      "id" : 6106092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430425329077739520",
  "geo" : { },
  "id_str" : "430425892758646784",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH @lifo one of my favorite parts about the company. That and old Rails apps that you would never guess are 7-10 years old.",
  "id" : 430425892758646784,
  "in_reply_to_status_id" : 430425329077739520,
  "created_at" : "2014-02-03 19:41:44 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pratik",
      "screen_name" : "lifo",
      "indices" : [ 3, 8 ],
      "id_str" : "6106092",
      "id" : 6106092
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 28, 38 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430425562213912576",
  "text" : "RT @lifo: Completed 4 years @37signals on February 1. Time flies!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 18, 28 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "430424902228000769",
    "text" : "Completed 4 years @37signals on February 1. Time flies!!!",
    "id" : 430424902228000769,
    "created_at" : "2014-02-03 19:37:48 +0000",
    "user" : {
      "name" : "Pratik",
      "screen_name" : "lifo",
      "protected" : false,
      "id_str" : "6106092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430426827987767296\/Zo6q_uVZ_normal.png",
      "id" : 6106092,
      "verified" : false
    }
  },
  "id" : 430425562213912576,
  "created_at" : "2014-02-03 19:40:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 0, 9 ],
      "id_str" : "1051521",
      "id" : 1051521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430396492184969216",
  "geo" : { },
  "id_str" : "430397588253048834",
  "in_reply_to_user_id" : 1051521,
  "text" : "@migreyes Really? \u0CA0_\u0CA0",
  "id" : 430397588253048834,
  "in_reply_to_status_id" : 430396492184969216,
  "created_at" : "2014-02-03 17:49:16 +0000",
  "in_reply_to_screen_name" : "migreyes",
  "in_reply_to_user_id_str" : "1051521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Borenstein",
      "screen_name" : "pborenstein",
      "indices" : [ 0, 12 ],
      "id_str" : "3675931",
      "id" : 3675931
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 13, 24 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/cKv2YlJZC0",
      "expanded_url" : "https:\/\/github.com\/coworkbuffalo",
      "display_url" : "github.com\/coworkbuffalo"
    } ]
  },
  "in_reply_to_status_id_str" : "430375740472049664",
  "geo" : { },
  "id_str" : "430379150444998656",
  "in_reply_to_user_id" : 3675931,
  "text" : "@pborenstein @kevinpurdy cool. yeah maybe could just start with some blog posts! the site is on github: https:\/\/t.co\/cKv2YlJZC0",
  "id" : 430379150444998656,
  "in_reply_to_status_id" : 430375740472049664,
  "created_at" : "2014-02-03 16:36:00 +0000",
  "in_reply_to_screen_name" : "pborenstein",
  "in_reply_to_user_id_str" : "3675931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 5, 14 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 43, 57 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/IkEjlONKQv",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/14813-openhack-feburary-1-0",
      "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430365076663455744",
  "text" : "It's @openhack time again! Tomorrow @ 7PM, @CoworkBuffalo. RSVP here: http:\/\/t.co\/IkEjlONKQv",
  "id" : 430365076663455744,
  "created_at" : "2014-02-03 15:40:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Borenstein",
      "screen_name" : "pborenstein",
      "indices" : [ 0, 12 ],
      "id_str" : "3675931",
      "id" : 3675931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430361303027576832",
  "geo" : { },
  "id_str" : "430362485195956225",
  "in_reply_to_user_id" : 3675931,
  "text" : "@pborenstein we really do need to write about it. what kind of resources are you wondering about?",
  "id" : 430362485195956225,
  "in_reply_to_status_id" : 430361303027576832,
  "created_at" : "2014-02-03 15:29:46 +0000",
  "in_reply_to_screen_name" : "pborenstein",
  "in_reply_to_user_id_str" : "3675931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 43, 57 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430357769716514816",
  "text" : "Maserati spotted in downtown on my walk to @coworkbuffalo. Maybe the Super Bowl ad worked?",
  "id" : 430357769716514816,
  "created_at" : "2014-02-03 15:11:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430147750437470209",
  "geo" : { },
  "id_str" : "430148242391969792",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending SHOW ME THE COOKIES!",
  "id" : 430148242391969792,
  "in_reply_to_status_id" : 430147750437470209,
  "created_at" : "2014-02-03 01:18:27 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 3, 12 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheOnion\/status\/430145370895556608\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/aB8YBY03WX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bfgu75JCIAAp3nn.jpg",
      "id_str" : "430145370899750912",
      "id" : 430145370899750912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bfgu75JCIAAp3nn.jpg",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1133,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/aB8YBY03WX"
    } ],
    "hashtags" : [ {
      "text" : "SuperBowl",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/QON4Adnzae",
      "expanded_url" : "http:\/\/onion.com\/1erApI6",
      "display_url" : "onion.com\/1erApI6"
    } ]
  },
  "geo" : { },
  "id_str" : "430146947081854976",
  "text" : "RT @TheOnion: Huskies Unstoppable During Cold Weather Puppy Bowl http:\/\/t.co\/QON4Adnzae #SuperBowl http:\/\/t.co\/aB8YBY03WX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheOnion\/status\/430145370895556608\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/aB8YBY03WX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bfgu75JCIAAp3nn.jpg",
        "id_str" : "430145370899750912",
        "id" : 430145370899750912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bfgu75JCIAAp3nn.jpg",
        "sizes" : [ {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 580,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1133,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/aB8YBY03WX"
      } ],
      "hashtags" : [ {
        "text" : "SuperBowl",
        "indices" : [ 74, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/QON4Adnzae",
        "expanded_url" : "http:\/\/onion.com\/1erApI6",
        "display_url" : "onion.com\/1erApI6"
      } ]
    },
    "geo" : { },
    "id_str" : "430145370895556608",
    "text" : "Huskies Unstoppable During Cold Weather Puppy Bowl http:\/\/t.co\/QON4Adnzae #SuperBowl http:\/\/t.co\/aB8YBY03WX",
    "id" : 430145370895556608,
    "created_at" : "2014-02-03 01:07:02 +0000",
    "user" : {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "protected" : false,
      "id_str" : "14075928",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3654358881\/476bd54bd9c2bc0f9a38b4e097ce6af5_normal.jpeg",
      "id" : 14075928,
      "verified" : true
    }
  },
  "id" : 430146947081854976,
  "created_at" : "2014-02-03 01:13:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 0, 7 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430135224450564097",
  "geo" : { },
  "id_str" : "430136096069275648",
  "in_reply_to_user_id" : 5452072,
  "text" : "@nb3004 don't forget websites for your small business!",
  "id" : 430136096069275648,
  "in_reply_to_status_id" : 430135224450564097,
  "created_at" : "2014-02-03 00:30:11 +0000",
  "in_reply_to_screen_name" : "nb3004",
  "in_reply_to_user_id_str" : "5452072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430119719648370688",
  "geo" : { },
  "id_str" : "430120804979052544",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh is this your first Super Bowl?",
  "id" : 430120804979052544,
  "in_reply_to_status_id" : 430119719648370688,
  "created_at" : "2014-02-02 23:29:25 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430022193117151232",
  "geo" : { },
  "id_str" : "430030839221477376",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d too many bets. say no to feature requests :P",
  "id" : 430030839221477376,
  "in_reply_to_status_id" : 430022193117151232,
  "created_at" : "2014-02-02 17:31:56 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429996350676021248",
  "geo" : { },
  "id_str" : "429998715407835137",
  "in_reply_to_user_id" : 23217545,
  "text" : "@StrategicIP Emailed!",
  "id" : 429998715407835137,
  "in_reply_to_status_id" : 429996350676021248,
  "created_at" : "2014-02-02 15:24:17 +0000",
  "in_reply_to_screen_name" : "LisaPrimerano",
  "in_reply_to_user_id_str" : "23217545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/EUG6IRdU0V",
      "expanded_url" : "http:\/\/www.shakelaw.com\/",
      "display_url" : "shakelaw.com"
    } ]
  },
  "geo" : { },
  "id_str" : "429982822678294528",
  "text" : "What's that website that lets you build contracts piece by piece? Not http:\/\/t.co\/EUG6IRdU0V",
  "id" : 429982822678294528,
  "created_at" : "2014-02-02 14:21:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/Nybgb5RFgl",
      "expanded_url" : "https:\/\/twitter.com\/BuffaloSabres\/status\/429744815622717440",
      "display_url" : "twitter.com\/BuffaloSabres\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429963868673044480",
  "text" : "I wish more sports teams were this honest: https:\/\/t.co\/Nybgb5RFgl",
  "id" : 429963868673044480,
  "created_at" : "2014-02-02 13:05:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Sabres",
      "screen_name" : "BuffaloSabres",
      "indices" : [ 3, 17 ],
      "id_str" : "22536395",
      "id" : 22536395
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sabres",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429862806637146112",
  "text" : "RT @BuffaloSabres: Game's over. If you want to know the final score, you can find it on the Internet somewhere. #Sabres",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sabres",
        "indices" : [ 93, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429744815622717440",
    "text" : "Game's over. If you want to know the final score, you can find it on the Internet somewhere. #Sabres",
    "id" : 429744815622717440,
    "created_at" : "2014-02-01 22:35:22 +0000",
    "user" : {
      "name" : "Buffalo Sabres",
      "screen_name" : "BuffaloSabres",
      "protected" : false,
      "id_str" : "22536395",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/532243809112166400\/DD9FAvoo_normal.jpeg",
      "id" : 22536395,
      "verified" : true
    }
  },
  "id" : 429862806637146112,
  "created_at" : "2014-02-02 06:24:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 0, 7 ],
      "id_str" : "34953",
      "id" : 34953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429802122033762305",
  "geo" : { },
  "id_str" : "429802397964464128",
  "in_reply_to_user_id" : 34953,
  "text" : "@nathos of course, Simpsons did it",
  "id" : 429802397964464128,
  "in_reply_to_status_id" : 429802122033762305,
  "created_at" : "2014-02-02 02:24:11 +0000",
  "in_reply_to_screen_name" : "nathos",
  "in_reply_to_user_id_str" : "34953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 3, 10 ],
      "id_str" : "34953",
      "id" : 34953
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 12, 18 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/S2ydR1JCYl",
      "expanded_url" : "http:\/\/upload.wikimedia.org\/wikipedia\/en\/0\/09\/Watchmen_Babies.jpg",
      "display_url" : "upload.wikimedia.org\/wikipedia\/en\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429802343002292224",
  "text" : "RT @nathos: @qrush http:\/\/t.co\/S2ydR1JCYl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 7, 29 ],
        "url" : "http:\/\/t.co\/S2ydR1JCYl",
        "expanded_url" : "http:\/\/upload.wikimedia.org\/wikipedia\/en\/0\/09\/Watchmen_Babies.jpg",
        "display_url" : "upload.wikimedia.org\/wikipedia\/en\/0\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "429801828805787649",
    "geo" : { },
    "id_str" : "429802122033762305",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush http:\/\/t.co\/S2ydR1JCYl",
    "id" : 429802122033762305,
    "in_reply_to_status_id" : 429801828805787649,
    "created_at" : "2014-02-02 02:23:05 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "protected" : false,
      "id_str" : "34953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570421723984429056\/SiXp3XlU_normal.jpeg",
      "id" : 34953,
      "verified" : false
    }
  },
  "id" : 429802343002292224,
  "created_at" : "2014-02-02 02:23:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429801828805787649",
  "text" : "Baby Watchmen: \"I'm not snuggled in here with you. You're snuggled in here with ME!\"",
  "id" : 429801828805787649,
  "created_at" : "2014-02-02 02:21:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@Pete716",
      "screen_name" : "Pete716",
      "indices" : [ 0, 8 ],
      "id_str" : "33588043",
      "id" : 33588043
    }, {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 37, 43 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429791379208671232",
  "in_reply_to_user_id" : 33588043,
  "text" : "@Pete716 hey nice featured recipe on @IFTTT!",
  "id" : 429791379208671232,
  "created_at" : "2014-02-02 01:40:24 +0000",
  "in_reply_to_screen_name" : "Pete716",
  "in_reply_to_user_id_str" : "33588043",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429762730510147584",
  "geo" : { },
  "id_str" : "429762895363055618",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden HELP I'M TRAPPED IN PAPER",
  "id" : 429762895363055618,
  "in_reply_to_status_id" : 429762730510147584,
  "created_at" : "2014-02-01 23:47:13 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429762663401283584",
  "text" : "Free idea: restaurant for parents with newborns\/young kids. House band plays white noise. Only enclosed booths. Built in kids seats.",
  "id" : 429762663401283584,
  "created_at" : "2014-02-01 23:46:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lori M Olson",
      "screen_name" : "wndxlori",
      "indices" : [ 3, 12 ],
      "id_str" : "30369946",
      "id" : 30369946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429749327179698176",
  "text" : "RT @wndxlori: Ummm. When did iOS Mail get an Edit button that let\u2019s you REORDER INBOXES and have an UNREAD folder?!?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429728086364389376",
    "text" : "Ummm. When did iOS Mail get an Edit button that let\u2019s you REORDER INBOXES and have an UNREAD folder?!?",
    "id" : 429728086364389376,
    "created_at" : "2014-02-01 21:28:54 +0000",
    "user" : {
      "name" : "Lori M Olson",
      "screen_name" : "wndxlori",
      "protected" : false,
      "id_str" : "30369946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000790491454\/fcf7dbac0162576cc840197a1f17f674_normal.jpeg",
      "id" : 30369946,
      "verified" : false
    }
  },
  "id" : 429749327179698176,
  "created_at" : "2014-02-01 22:53:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/429657672325922820\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/p5gYsHkXyE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfZzYF0CEAEaU0w.png",
      "id_str" : "429657672174931969",
      "id" : 429657672174931969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfZzYF0CEAEaU0w.png",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/p5gYsHkXyE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429657672325922820",
  "text" : "The Tamer in Slayin' is just unfair compared to the other classes. http:\/\/t.co\/p5gYsHkXyE",
  "id" : 429657672325922820,
  "created_at" : "2014-02-01 16:49:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429607646531166208",
  "geo" : { },
  "id_str" : "429607858012184576",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton \uD83D\uDE31\uD83D\uDCA9",
  "id" : 429607858012184576,
  "in_reply_to_status_id" : 429607646531166208,
  "created_at" : "2014-02-01 13:31:09 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
Grailbird.data.tweets_2013_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329389918642118656",
  "geo" : { },
  "id_str" : "329398431393140737",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella the rules are on the front page. Maybe should rename Basics to Rules ?",
  "id" : 329398431393140737,
  "in_reply_to_status_id" : 329389918642118656,
  "created_at" : "2013-05-01 00:54:40 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329390913455546368",
  "text" : "@withloudhands heading to the help desk area now. Kind of bummed to hear that, but bigger groups have trouble with the format too.",
  "id" : 329390913455546368,
  "created_at" : "2013-05-01 00:24:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329388659432361984",
  "geo" : { },
  "id_str" : "329389566945546240",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy haven\u2019t really used it. Maybe should try but wouldn\u2019t be on most prod envs.",
  "id" : 329389566945546240,
  "in_reply_to_status_id" : 329388659432361984,
  "created_at" : "2013-05-01 00:19:27 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 6, 15 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329389252397891585",
  "text" : "Maybe @openhack rules should be in RFC format: MUST do intros. SHOULD provide wifi and food. SHOULD NOT have formal talks. Beer is OPTIONAL.",
  "id" : 329389252397891585,
  "created_at" : "2013-05-01 00:18:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329388158447919104",
  "text" : "Pry feels like an entire shell, not just a simple ruby console. Wondering if the added weight is worth it.",
  "id" : 329388158447919104,
  "created_at" : "2013-05-01 00:13:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 10, 19 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329383409661145088",
  "text" : "A goal of @openhack has been let it evolve and see how locals interpret it, but if you missed intros, I think you missed the point entirely.",
  "id" : 329383409661145088,
  "created_at" : "2013-04-30 23:54:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 12, 21 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329383075056336897",
  "text" : "First known @openhack meetup conflict has happened in 6 months, where the name was used but format of the meetup was not followed :(",
  "id" : 329383075056336897,
  "created_at" : "2013-04-30 23:53:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Horner",
      "screen_name" : "meganHorner00",
      "indices" : [ 0, 14 ],
      "id_str" : "809450287",
      "id" : 809450287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329375504715096064",
  "geo" : { },
  "id_str" : "329376229297881089",
  "in_reply_to_user_id" : 809450287,
  "text" : "@meganHorner00 just feels unfair to the 60+ cities globally that are trying out this model of running meetups, and yours does not reflect it",
  "id" : 329376229297881089,
  "in_reply_to_status_id" : 329375504715096064,
  "created_at" : "2013-04-30 23:26:27 +0000",
  "in_reply_to_screen_name" : "meganHorner00",
  "in_reply_to_user_id_str" : "809450287",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Horner",
      "screen_name" : "meganHorner00",
      "indices" : [ 0, 14 ],
      "id_str" : "809450287",
      "id" : 809450287
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 82, 91 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329375504715096064",
  "geo" : { },
  "id_str" : "329375950410223616",
  "in_reply_to_user_id" : 809450287,
  "text" : "@meganHorner00 I\u2019d appreciate changing the name then if it is not associated with @OpenHack.",
  "id" : 329375950410223616,
  "in_reply_to_status_id" : 329375504715096064,
  "created_at" : "2013-04-30 23:25:20 +0000",
  "in_reply_to_screen_name" : "meganHorner00",
  "in_reply_to_user_id_str" : "809450287",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Horner",
      "screen_name" : "meganHorner00",
      "indices" : [ 0, 14 ],
      "id_str" : "809450287",
      "id" : 809450287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/uqsXRCj7dG",
      "expanded_url" : "http:\/\/openhack.github.io\/",
      "display_url" : "openhack.github.io"
    } ]
  },
  "in_reply_to_status_id_str" : "329337112342188032",
  "geo" : { },
  "id_str" : "329374433062047744",
  "in_reply_to_user_id" : 809450287,
  "text" : "@meganHorner00 is this associated with http:\/\/t.co\/uqsXRCj7dG ? Not on the list and the meetup group doesn\u2019t mention intros :(",
  "id" : 329374433062047744,
  "in_reply_to_status_id" : 329337112342188032,
  "created_at" : "2013-04-30 23:19:18 +0000",
  "in_reply_to_screen_name" : "meganHorner00",
  "in_reply_to_user_id_str" : "809450287",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 24, 38 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329356868629716992",
  "geo" : { },
  "id_str" : "329357321744564224",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 heading down to @coworkbuffalo soon? I\u2019ll be back next week :)",
  "id" : 329357321744564224,
  "in_reply_to_status_id" : 329356868629716992,
  "created_at" : "2013-04-30 22:11:19 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329353252929953793",
  "geo" : { },
  "id_str" : "329356861700714497",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad again? There was one yesterday :(",
  "id" : 329356861700714497,
  "in_reply_to_status_id" : 329353252929953793,
  "created_at" : "2013-04-30 22:09:29 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329284942121013249",
  "text" : "I\u2019ll have JavaScript sprinkles on my ice cream please. Delicious!",
  "id" : 329284942121013249,
  "created_at" : "2013-04-30 17:23:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 3, 14 ],
      "id_str" : "2384071",
      "id" : 2384071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/iwnbGqueUW",
      "expanded_url" : "http:\/\/on.wsj.com\/17vzVM6",
      "display_url" : "on.wsj.com\/17vzVM6"
    } ]
  },
  "geo" : { },
  "id_str" : "329261599716147201",
  "text" : "RT @timoreilly: Beautiful photo of massive hurricane on Saturn http:\/\/t.co\/iwnbGqueUW Space travel stirred my imagination when I was growin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/iwnbGqueUW",
        "expanded_url" : "http:\/\/on.wsj.com\/17vzVM6",
        "display_url" : "on.wsj.com\/17vzVM6"
      } ]
    },
    "geo" : { },
    "id_str" : "329260884415365122",
    "text" : "Beautiful photo of massive hurricane on Saturn http:\/\/t.co\/iwnbGqueUW Space travel stirred my imagination when I was growing up! Still does",
    "id" : 329260884415365122,
    "created_at" : "2013-04-30 15:48:06 +0000",
    "user" : {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "protected" : false,
      "id_str" : "2384071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2823681988\/f4f6f2bed8ab4d5a48dea4b9ea85d5f1_normal.jpeg",
      "id" : 2384071,
      "verified" : true
    }
  },
  "id" : 329261599716147201,
  "created_at" : "2013-04-30 15:50:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "indices" : [ 0, 13 ],
      "id_str" : "29200620",
      "id" : 29200620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329234497688190978",
  "geo" : { },
  "id_str" : "329236030110715904",
  "in_reply_to_user_id" : 29200620,
  "text" : "@TheOtherZach we have food things at our AirBNB, sorry. Also I\u2019m pretty sure he wants to read its mind. Watch a few of the top hits",
  "id" : 329236030110715904,
  "in_reply_to_status_id" : 329234497688190978,
  "created_at" : "2013-04-30 14:09:21 +0000",
  "in_reply_to_screen_name" : "TheOtherZach",
  "in_reply_to_user_id_str" : "29200620",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/5b7jB14YY6",
      "expanded_url" : "http:\/\/github.com\/rubygems\/rubygems-aws",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "329233180857098241",
  "geo" : { },
  "id_str" : "329233564967260160",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage :( our infrastructure is all open - I\u2019m not sure what the root problem is but it would be awesome to fix it http:\/\/t.co\/5b7jB14YY6",
  "id" : 329233564967260160,
  "in_reply_to_status_id" : 329233180857098241,
  "created_at" : "2013-04-30 13:59:33 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/mmz7iqcQ4F",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/id599139477",
      "display_url" : "itunes.apple.com\/us\/app\/id59913\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "329233088733380610",
  "text" : "RT @37signals: Use Basecamp? Got an iPhone? Get the official Basecamp iPhone app: https:\/\/t.co\/mmz7iqcQ4F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/mmz7iqcQ4F",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/id599139477",
        "display_url" : "itunes.apple.com\/us\/app\/id59913\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "329224176219062272",
    "text" : "Use Basecamp? Got an iPhone? Get the official Basecamp iPhone app: https:\/\/t.co\/mmz7iqcQ4F",
    "id" : 329224176219062272,
    "created_at" : "2013-04-30 13:22:14 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 329233088733380610,
  "created_at" : "2013-04-30 13:57:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329232795069198336",
  "geo" : { },
  "id_str" : "329232887234834433",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage why is it a beast?",
  "id" : 329232887234834433,
  "in_reply_to_status_id" : 329232795069198336,
  "created_at" : "2013-04-30 13:56:51 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329232061783228416",
  "text" : "Eyes open, no fear.",
  "id" : 329232061783228416,
  "created_at" : "2013-04-30 13:53:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/tddtY8KSI7",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=Pa4rGqYDSPg",
      "display_url" : "youtube.com\/watch?v=Pa4rGq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "329232019336867842",
  "text" : "Fascinating earth and space weather data + a bit of tinfoil = riveting daily videos. http:\/\/t.co\/tddtY8KSI7",
  "id" : 329232019336867842,
  "created_at" : "2013-04-30 13:53:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329143284033277953",
  "geo" : { },
  "id_str" : "329143863556067328",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense w.t.f. Might be worse than carmageddon\u2019s UI?",
  "id" : 329143863556067328,
  "in_reply_to_status_id" : 329143284033277953,
  "created_at" : "2013-04-30 08:03:06 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rands",
      "screen_name" : "rands",
      "indices" : [ 62, 68 ],
      "id_str" : "30923",
      "id" : 30923
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 72, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/9vEuKgGRh1",
      "expanded_url" : "http:\/\/www.randsinrepose.com\/archives\/2012\/11\/14\/stables_and_volatiles.html",
      "display_url" : "randsinrepose.com\/archives\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "329037046985392129",
  "text" : "Very excited to hear some Stables &amp; Volatiles wisdom from @rands at #railsconf. Must read for all devs: http:\/\/t.co\/9vEuKgGRh1",
  "id" : 329037046985392129,
  "created_at" : "2013-04-30 00:58:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/wCsxAY8phr",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "329034621725593600",
  "text" : "Woot, got http:\/\/t.co\/wCsxAY8phr running on Rails 4.0.0.rc1, and gems pushing. Test suite needs help though! #railsconf",
  "id" : 329034621725593600,
  "created_at" : "2013-04-30 00:49:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 0, 6 ],
      "id_str" : "1679",
      "id" : 1679
    }, {
      "name" : "Kiki Aardsma",
      "screen_name" : "kikiaards",
      "indices" : [ 7, 17 ],
      "id_str" : "355473809",
      "id" : 355473809
    }, {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 18, 27 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329004143052206080",
  "geo" : { },
  "id_str" : "329015917319168000",
  "in_reply_to_user_id" : 1679,
  "text" : "@javan @kikiaards @bitsweat oooh Game night is tomorrow night. Maybe tonight or Wednesday?",
  "id" : 329015917319168000,
  "in_reply_to_status_id" : 329004143052206080,
  "created_at" : "2013-04-29 23:34:42 +0000",
  "in_reply_to_screen_name" : "javan",
  "in_reply_to_user_id_str" : "1679",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kiki Aardsma",
      "screen_name" : "kikiaards",
      "indices" : [ 0, 10 ],
      "id_str" : "355473809",
      "id" : 355473809
    }, {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 11, 17 ],
      "id_str" : "1679",
      "id" : 1679
    }, {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 18, 27 ],
      "id_str" : "9462972",
      "id" : 9462972
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 28, 38 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328959482090635267",
  "geo" : { },
  "id_str" : "329008319865950210",
  "in_reply_to_user_id" : 355473809,
  "text" : "@kikiaards @javan @bitsweat @aquaranto yes!",
  "id" : 329008319865950210,
  "in_reply_to_status_id" : 328959482090635267,
  "created_at" : "2013-04-29 23:04:30 +0000",
  "in_reply_to_screen_name" : "kikiaards",
  "in_reply_to_user_id_str" : "355473809",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329002238871760896",
  "geo" : { },
  "id_str" : "329002450700881921",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan \uD83D\uDE31\uD83D\uDE10\uD83D\uDE12",
  "id" : 329002450700881921,
  "in_reply_to_status_id" : 329002238871760896,
  "created_at" : "2013-04-29 22:41:11 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328989894192005123",
  "geo" : { },
  "id_str" : "329002034646900736",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan you\u2019re here?! You?!",
  "id" : 329002034646900736,
  "in_reply_to_status_id" : 328989894192005123,
  "created_at" : "2013-04-29 22:39:32 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Yj38N1r7rQ",
      "expanded_url" : "http:\/\/Hawaii.gov",
      "display_url" : "Hawaii.gov"
    }, {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/oXt2vqroao",
      "expanded_url" : "http:\/\/bit.ly\/18g71hj",
      "display_url" : "bit.ly\/18g71hj"
    } ]
  },
  "geo" : { },
  "id_str" : "328986740482256896",
  "text" : "http:\/\/t.co\/Yj38N1r7rQ is using Jekyll. I never thought this project would get usage with public government sites! http:\/\/t.co\/oXt2vqroao",
  "id" : 328986740482256896,
  "created_at" : "2013-04-29 21:38:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328985626001145856",
  "geo" : { },
  "id_str" : "328985925365411842",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan I am here \uD83D\uDC4B",
  "id" : 328985925365411842,
  "in_reply_to_status_id" : 328985626001145856,
  "created_at" : "2013-04-29 21:35:31 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 12, 21 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 111, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328985468286935040",
  "text" : "Considering @indirect\u2019s talk on security and wondering if whoever pushed the \u201Cexploit\u201D gem is actually here at #railsconf.",
  "id" : 328985468286935040,
  "created_at" : "2013-04-29 21:33:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Balter",
      "screen_name" : "BenBalter",
      "indices" : [ 3, 13 ],
      "id_str" : "16211142",
      "id" : 16211142
    }, {
      "name" : "jekyll",
      "screen_name" : "jekyllrb",
      "indices" : [ 41, 50 ],
      "id_str" : "1143789606",
      "id" : 1143789606
    }, {
      "name" : "Danny Chapman",
      "screen_name" : "dannychapman",
      "indices" : [ 139, 140 ],
      "id_str" : "10894752",
      "id" : 10894752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/iTO3nt30ea",
      "expanded_url" : "http:\/\/bit.ly\/Zw8wYy",
      "display_url" : "bit.ly\/Zw8wYy"
    }, {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/JJgQ8iVkIX",
      "expanded_url" : "http:\/\/bit.ly\/18g71hj",
      "display_url" : "bit.ly\/18g71hj"
    } ]
  },
  "geo" : { },
  "id_str" : "328985025368424449",
  "text" : "RT @BenBalter: Hawaii .gov relaunches on @jekyllrb http:\/\/t.co\/iTO3nt30ea (overview of their technical stack: http:\/\/t.co\/JJgQ8iVkIX) props\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jekyll",
        "screen_name" : "jekyllrb",
        "indices" : [ 26, 35 ],
        "id_str" : "1143789606",
        "id" : 1143789606
      }, {
        "name" : "Danny Chapman",
        "screen_name" : "dannychapman",
        "indices" : [ 125, 138 ],
        "id_str" : "10894752",
        "id" : 10894752
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/iTO3nt30ea",
        "expanded_url" : "http:\/\/bit.ly\/Zw8wYy",
        "display_url" : "bit.ly\/Zw8wYy"
      }, {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/JJgQ8iVkIX",
        "expanded_url" : "http:\/\/bit.ly\/18g71hj",
        "display_url" : "bit.ly\/18g71hj"
      } ]
    },
    "geo" : { },
    "id_str" : "328960800930811905",
    "text" : "Hawaii .gov relaunches on @jekyllrb http:\/\/t.co\/iTO3nt30ea (overview of their technical stack: http:\/\/t.co\/JJgQ8iVkIX) props @dannychapman",
    "id" : 328960800930811905,
    "created_at" : "2013-04-29 19:55:41 +0000",
    "user" : {
      "name" : "Ben Balter",
      "screen_name" : "BenBalter",
      "protected" : false,
      "id_str" : "16211142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504989503564443648\/rWZu4dnD_normal.jpeg",
      "id" : 16211142,
      "verified" : false
    }
  },
  "id" : 328985025368424449,
  "created_at" : "2013-04-29 21:31:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Baird",
      "screen_name" : "Jeffrey_Baird",
      "indices" : [ 0, 14 ],
      "id_str" : "33135710",
      "id" : 33135710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/BIsVS2IXtQ",
      "expanded_url" : "http:\/\/nickelcityruby.com\/cfp\/",
      "display_url" : "nickelcityruby.com\/cfp\/"
    } ]
  },
  "in_reply_to_status_id_str" : "328964980806406144",
  "geo" : { },
  "id_str" : "328979794882605056",
  "in_reply_to_user_id" : 33135710,
  "text" : "@Jeffrey_Baird it\u2019s here: http:\/\/t.co\/BIsVS2IXtQ",
  "id" : 328979794882605056,
  "in_reply_to_status_id" : 328964980806406144,
  "created_at" : "2013-04-29 21:11:09 +0000",
  "in_reply_to_screen_name" : "Jeffrey_Baird",
  "in_reply_to_user_id_str" : "33135710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Delmont",
      "screen_name" : "sd",
      "indices" : [ 0, 3 ],
      "id_str" : "755241",
      "id" : 755241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328943219700289536",
  "geo" : { },
  "id_str" : "328947123099926528",
  "in_reply_to_user_id" : 755241,
  "text" : "@sd at the helpdesk! downstairs next to the desk.",
  "id" : 328947123099926528,
  "in_reply_to_status_id" : 328943219700289536,
  "created_at" : "2013-04-29 19:01:20 +0000",
  "in_reply_to_screen_name" : "sd",
  "in_reply_to_user_id_str" : "755241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/328946421027975170\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/i7zNVJ3ZyB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJCnBu_CMAEajGs.jpg",
      "id_str" : "328946421032169473",
      "id" : 328946421032169473,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJCnBu_CMAEajGs.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/i7zNVJ3ZyB"
    } ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328946421027975170",
  "text" : "Moved the #railsconf help desk to the hallway outside of registration. Much more open! http:\/\/t.co\/i7zNVJ3ZyB",
  "id" : 328946421027975170,
  "created_at" : "2013-04-29 18:58:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328934652326850561",
  "geo" : { },
  "id_str" : "328939998458048512",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale i'm here all week! \/play rimshot",
  "id" : 328939998458048512,
  "in_reply_to_status_id" : 328934652326850561,
  "created_at" : "2013-04-29 18:33:01 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 89, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328934363582582784",
  "text" : "Your periodic reminder that there\u2019s more than one way to build a web app, and that\u2019s OK\u2122 #railsconf",
  "id" : 328934363582582784,
  "created_at" : "2013-04-29 18:10:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Harvey",
      "screen_name" : "mootpointer",
      "indices" : [ 0, 12 ],
      "id_str" : "1054931",
      "id" : 1054931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328931638224506880",
  "geo" : { },
  "id_str" : "328931802616037376",
  "in_reply_to_user_id" : 1054931,
  "text" : "@mootpointer Basecamp\u2019s is not, but you could base it off a REVISION on deploy certainly",
  "id" : 328931802616037376,
  "in_reply_to_status_id" : 328931638224506880,
  "created_at" : "2013-04-29 18:00:27 +0000",
  "in_reply_to_screen_name" : "mootpointer",
  "in_reply_to_user_id_str" : "1054931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 9, 15 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328930952543891457",
  "geo" : { },
  "id_str" : "328931642704015360",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale @cmeik Rails 6: P vs NP",
  "id" : 328931642704015360,
  "in_reply_to_status_id" : 328930952543891457,
  "created_at" : "2013-04-29 17:59:49 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Harvey",
      "screen_name" : "mootpointer",
      "indices" : [ 0, 12 ],
      "id_str" : "1054931",
      "id" : 1054931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328930597219225600",
  "geo" : { },
  "id_str" : "328931108697808896",
  "in_reply_to_user_id" : 1054931,
  "text" : "@mootpointer if you change something that\u2019s cached, just need to bump the cache key (v12 =&gt; v13) etc.",
  "id" : 328931108697808896,
  "in_reply_to_status_id" : 328930597219225600,
  "created_at" : "2013-04-29 17:57:42 +0000",
  "in_reply_to_screen_name" : "mootpointer",
  "in_reply_to_user_id_str" : "1054931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    }, {
      "name" : "Pete Kinnecom",
      "screen_name" : "petekinnecom",
      "indices" : [ 11, 24 ],
      "id_str" : "1235765311",
      "id" : 1235765311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/Wfg8t2kKUz",
      "expanded_url" : "http:\/\/4.bp.blogspot.com\/-PprshXlMAg4\/TjBdbhPUcnI\/AAAAAAAADng\/-GSGAs0oWD4\/s1600\/2112group.jpg",
      "display_url" : "4.bp.blogspot.com\/-PprshXlMAg4\/T\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "328926220844691456",
  "geo" : { },
  "id_str" : "328926994416947200",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald @petekinnecom actually this might work well in Portland http:\/\/t.co\/Wfg8t2kKUz",
  "id" : 328926994416947200,
  "in_reply_to_status_id" : 328926220844691456,
  "created_at" : "2013-04-29 17:41:21 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scofield",
      "screen_name" : "bscofield",
      "indices" : [ 0, 10 ],
      "id_str" : "7921582",
      "id" : 7921582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328925756476514305",
  "geo" : { },
  "id_str" : "328926355288907777",
  "in_reply_to_user_id" : 7921582,
  "text" : "@bscofield D135. We should get a sign\u2026",
  "id" : 328926355288907777,
  "in_reply_to_status_id" : 328925756476514305,
  "created_at" : "2013-04-29 17:38:48 +0000",
  "in_reply_to_screen_name" : "bscofield",
  "in_reply_to_user_id_str" : "7921582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scofield",
      "screen_name" : "bscofield",
      "indices" : [ 0, 10 ],
      "id_str" : "7921582",
      "id" : 7921582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328925625375154177",
  "geo" : { },
  "id_str" : "328925713585545216",
  "in_reply_to_user_id" : 7921582,
  "text" : "@bscofield thanks!!",
  "id" : 328925713585545216,
  "in_reply_to_status_id" : 328925625375154177,
  "created_at" : "2013-04-29 17:36:15 +0000",
  "in_reply_to_screen_name" : "bscofield",
  "in_reply_to_user_id_str" : "7921582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scofield",
      "screen_name" : "bscofield",
      "indices" : [ 0, 10 ],
      "id_str" : "7921582",
      "id" : 7921582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328925545540751361",
  "in_reply_to_user_id" : 7921582,
  "text" : "@bscofield not sure if you\u2019re doing an outro, but might be nice to do a help desk mention :)",
  "id" : 328925545540751361,
  "created_at" : "2013-04-29 17:35:35 +0000",
  "in_reply_to_screen_name" : "bscofield",
  "in_reply_to_user_id_str" : "7921582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Kinnecom",
      "screen_name" : "petekinnecom",
      "indices" : [ 3, 16 ],
      "id_str" : "1235765311",
      "id" : 1235765311
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328925045009289216",
  "text" : "RT @petekinnecom: Already seen two Rush shirts in the first hour. It seems I am finally among my people #railsconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "railsconf",
        "indices" : [ 86, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328920671721754624",
    "text" : "Already seen two Rush shirts in the first hour. It seems I am finally among my people #railsconf",
    "id" : 328920671721754624,
    "created_at" : "2013-04-29 17:16:13 +0000",
    "user" : {
      "name" : "Pete Kinnecom",
      "screen_name" : "petekinnecom",
      "protected" : false,
      "id_str" : "1235765311",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3329457361\/41cd1c5590ace083e7afb53a7ec76a1c_normal.jpeg",
      "id" : 1235765311,
      "verified" : false
    }
  },
  "id" : 328925045009289216,
  "created_at" : "2013-04-29 17:33:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Owens",
      "screen_name" : "intjonathan",
      "indices" : [ 0, 12 ],
      "id_str" : "62634651",
      "id" : 62634651
    }, {
      "name" : "Pete Kinnecom",
      "screen_name" : "petekinnecom",
      "indices" : [ 13, 26 ],
      "id_str" : "1235765311",
      "id" : 1235765311
    }, {
      "name" : "Zack Hubert",
      "screen_name" : "zhubert",
      "indices" : [ 27, 35 ],
      "id_str" : "9229622",
      "id" : 9229622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328922741560471552",
  "geo" : { },
  "id_str" : "328922888029757441",
  "in_reply_to_user_id" : 62634651,
  "text" : "@intjonathan @petekinnecom @zhubert YES! Sadly I didn\u2019t bring any.",
  "id" : 328922888029757441,
  "in_reply_to_status_id" : 328922741560471552,
  "created_at" : "2013-04-29 17:25:02 +0000",
  "in_reply_to_screen_name" : "intjonathan",
  "in_reply_to_user_id_str" : "62634651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 0, 11 ],
      "id_str" : "2355631",
      "id" : 2355631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328894608710983680",
  "geo" : { },
  "id_str" : "328917834140897280",
  "in_reply_to_user_id" : 2355631,
  "text" : "@lmarburger agh! There is no perfect scheduling time. Obviously you know what to pick ;)",
  "id" : 328917834140897280,
  "in_reply_to_status_id" : 328894608710983680,
  "created_at" : "2013-04-29 17:04:57 +0000",
  "in_reply_to_screen_name" : "lmarburger",
  "in_reply_to_user_id_str" : "2355631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 31, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328917346771165184",
  "text" : "Front of the overflow room for #railsconf! Help desk after.",
  "id" : 328917346771165184,
  "created_at" : "2013-04-29 17:03:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Wunsch",
      "screen_name" : "markwunsch",
      "indices" : [ 0, 11 ],
      "id_str" : "15108584",
      "id" : 15108584
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 12, 25 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328895649040961536",
  "geo" : { },
  "id_str" : "328903547661979648",
  "in_reply_to_user_id" : 15108584,
  "text" : "@markwunsch @steveklabnik I usually do, but not at the same time. I don\u2019t like giving a talk more than 2-3 times.",
  "id" : 328903547661979648,
  "in_reply_to_status_id" : 328895649040961536,
  "created_at" : "2013-04-29 16:08:11 +0000",
  "in_reply_to_screen_name" : "markwunsch",
  "in_reply_to_user_id_str" : "15108584",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/328894644446457856\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/S9HklvgIuJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJB378MCcAA2Lcb.jpg",
      "id_str" : "328894644450652160",
      "id" : 328894644450652160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJB378MCcAA2Lcb.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/S9HklvgIuJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328894644446457856",
  "text" : "It\u2019s about that time. http:\/\/t.co\/S9HklvgIuJ",
  "id" : 328894644446457856,
  "created_at" : "2013-04-29 15:32:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328884729539596288",
  "text" : "Strangest thing about Portland so far: it\u2019s actually Spring here and there\u2019s leaves on the trees. Not the case in Buffalo.",
  "id" : 328884729539596288,
  "created_at" : "2013-04-29 14:53:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Allen",
      "screen_name" : "ultrasaurus",
      "indices" : [ 16, 28 ],
      "id_str" : "13368452",
      "id" : 13368452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/l91dT9Jk4m",
      "expanded_url" : "http:\/\/www.npr.org\/blogs\/alltechconsidered\/2013\/04\/29\/178810467\/blazing-the-trail-for-female-programmers",
      "display_url" : "npr.org\/blogs\/alltechc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "328878079529328640",
  "text" : "RailsBridge and @ultrasaurus are on NPR this morning, what a great way to start off #railsconf week! http:\/\/t.co\/l91dT9Jk4m",
  "id" : 328878079529328640,
  "created_at" : "2013-04-29 14:26:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 8, 20 ],
      "id_str" : "12027042",
      "id" : 12027042
    }, {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 21, 31 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328876687037190144",
  "geo" : { },
  "id_str" : "328877548421382146",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik @jamesgolick @joedamato this is everything I ever wanted.",
  "id" : 328877548421382146,
  "in_reply_to_status_id" : 328876687037190144,
  "created_at" : "2013-04-29 14:24:52 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/MO5MZT7rI6",
      "expanded_url" : "http:\/\/goo.gl\/fWT57",
      "display_url" : "goo.gl\/fWT57"
    } ]
  },
  "geo" : { },
  "id_str" : "328754180762247169",
  "text" : "A quick reminder that we're doing a Helpdesk during #railsconf, if you want to help out still, sign up: http:\/\/t.co\/MO5MZT7rI6",
  "id" : 328754180762247169,
  "created_at" : "2013-04-29 06:14:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328737695402700800",
  "text" : "Hi PDX!",
  "id" : 328737695402700800,
  "created_at" : "2013-04-29 05:09:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328628305077100544",
  "text" : "Successfully guessed a wifi password. This is the closest I ever get to being a hacker in a movie.",
  "id" : 328628305077100544,
  "created_at" : "2013-04-28 21:54:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328618702767529985",
  "text" : "At what point in the country does a \u201Ceuu-ro\u201D wrap become \u201Cjai-roh\u201D ?",
  "id" : 328618702767529985,
  "created_at" : "2013-04-28 21:16:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328612542761037824",
  "text" : "Forgot big DTW is. It\u2019s big.",
  "id" : 328612542761037824,
  "created_at" : "2013-04-28 20:51:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RailsConf 2015",
      "screen_name" : "railsconf",
      "indices" : [ 3, 13 ],
      "id_str" : "5493662",
      "id" : 5493662
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/N8FSRLEl9h",
      "expanded_url" : "http:\/\/lightning2013.herokuapp.com\/",
      "display_url" : "lightning2013.herokuapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "328522097133498368",
  "text" : "RT @railsconf: FYI, lightning talk signups are now live at http:\/\/t.co\/N8FSRLEl9h #railsconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "railsconf",
        "indices" : [ 67, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/N8FSRLEl9h",
        "expanded_url" : "http:\/\/lightning2013.herokuapp.com\/",
        "display_url" : "lightning2013.herokuapp.com"
      } ]
    },
    "geo" : { },
    "id_str" : "328505271276167168",
    "text" : "FYI, lightning talk signups are now live at http:\/\/t.co\/N8FSRLEl9h #railsconf",
    "id" : 328505271276167168,
    "created_at" : "2013-04-28 13:45:34 +0000",
    "user" : {
      "name" : "RailsConf 2015",
      "screen_name" : "railsconf",
      "protected" : false,
      "id_str" : "5493662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555794992384327680\/l6g_DE69_normal.jpeg",
      "id" : 5493662,
      "verified" : false
    }
  },
  "id" : 328522097133498368,
  "created_at" : "2013-04-28 14:52:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328506607715627009",
  "text" : "Is it considered \u201Cnot cool\u201D if I watch Portlandia on the way to Portland?",
  "id" : 328506607715627009,
  "created_at" : "2013-04-28 13:50:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328288169311227904",
  "geo" : { },
  "id_str" : "328289153366249473",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw I didn\u2019t sign in to one. \uD83D\uDE1E",
  "id" : 328289153366249473,
  "in_reply_to_status_id" : 328288169311227904,
  "created_at" : "2013-04-27 23:26:48 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328277803365720064",
  "text" : "TIL people sign into iPhones at the Apple Store with their actual accounts.",
  "id" : 328277803365720064,
  "created_at" : "2013-04-27 22:41:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328209001298919425",
  "geo" : { },
  "id_str" : "328227289051578368",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove please bring some to Railsconf. I will pay for your meat.",
  "id" : 328227289051578368,
  "in_reply_to_status_id" : 328209001298919425,
  "created_at" : "2013-04-27 19:20:58 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327943001173274624",
  "geo" : { },
  "id_str" : "327944250564165633",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden not that dark out yet, but they are friggin bright",
  "id" : 327944250564165633,
  "in_reply_to_status_id" : 327943001173274624,
  "created_at" : "2013-04-27 00:36:16 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327942424922050561",
  "text" : "Front revolight installed. Time: ~4 hours. I am exhausted.",
  "id" : 327942424922050561,
  "created_at" : "2013-04-27 00:29:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 89, 104 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/YGDKhh2LT4",
      "expanded_url" : "http:\/\/www.gironda.org\/post_images\/clippy_ios_advice.gif",
      "display_url" : "gironda.org\/post_images\/cl\u2026"
    }, {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/mHp7ISoOJj",
      "expanded_url" : "http:\/\/www.gironda.org\/2013\/03\/03\/digging-in-the-vineyard-part-2.html",
      "display_url" : "gironda.org\/2013\/03\/03\/dig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327878874119680002",
  "text" : "\"It looks like you're trying to reverse engineer an iOS app\" http:\/\/t.co\/YGDKhh2LT4 (via @gabrielgironda's http:\/\/t.co\/mHp7ISoOJj)",
  "id" : 327878874119680002,
  "created_at" : "2013-04-26 20:16:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327845917275340800",
  "geo" : { },
  "id_str" : "327862611230195713",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y Actually I just got it. Not joking.",
  "id" : 327862611230195713,
  "in_reply_to_status_id" : 327845917275340800,
  "created_at" : "2013-04-26 19:11:52 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Block Club",
      "screen_name" : "BlockClub",
      "indices" : [ 17, 27 ],
      "id_str" : "21003240",
      "id" : 21003240
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/327840668263264256\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/THNf13spgV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIy5Wc8CMAEYekK.jpg",
      "id_str" : "327840668267458561",
      "id" : 327840668267458561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIy5Wc8CMAEYekK.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/THNf13spgV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327840668263264256",
  "text" : "Didn\u2019t know that @BlockClub was Creative Commons licensed. I wish more print publications did this. http:\/\/t.co\/THNf13spgV",
  "id" : 327840668263264256,
  "created_at" : "2013-04-26 17:44:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chase Clemons",
      "screen_name" : "chaseclemons",
      "indices" : [ 0, 13 ],
      "id_str" : "16159121",
      "id" : 16159121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327825417278992385",
  "geo" : { },
  "id_str" : "327825703141781504",
  "in_reply_to_user_id" : 16159121,
  "text" : "@chaseclemons holy crap, did you have a house fire!?",
  "id" : 327825703141781504,
  "in_reply_to_status_id" : 327825417278992385,
  "created_at" : "2013-04-26 16:45:12 +0000",
  "in_reply_to_screen_name" : "chaseclemons",
  "in_reply_to_user_id_str" : "16159121",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pittsburgh Dad",
      "screen_name" : "Pittsburgh_Dad",
      "indices" : [ 3, 18 ],
      "id_str" : "394826630",
      "id" : 394826630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327823040706654208",
  "text" : "RT @Pittsburgh_Dad: Who the hell would eat a salad with no French fries on it!?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327785318667390977",
    "text" : "Who the hell would eat a salad with no French fries on it!?",
    "id" : 327785318667390977,
    "created_at" : "2013-04-26 14:04:44 +0000",
    "user" : {
      "name" : "Pittsburgh Dad",
      "screen_name" : "Pittsburgh_Dad",
      "protected" : false,
      "id_str" : "394826630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1599876133\/dad_profilepic_normal.jpg",
      "id" : 394826630,
      "verified" : false
    }
  },
  "id" : 327823040706654208,
  "created_at" : "2013-04-26 16:34:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ochonicki",
      "screen_name" : "fromonesrc",
      "indices" : [ 0, 11 ],
      "id_str" : "14420513",
      "id" : 14420513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327816411483340800",
  "geo" : { },
  "id_str" : "327816651875708928",
  "in_reply_to_user_id" : 14420513,
  "text" : "@fromonesrc chances are very low - too much businessy stuff in it ;)",
  "id" : 327816651875708928,
  "in_reply_to_status_id" : 327816411483340800,
  "created_at" : "2013-04-26 16:09:15 +0000",
  "in_reply_to_screen_name" : "fromonesrc",
  "in_reply_to_user_id_str" : "14420513",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clay Allsopp",
      "screen_name" : "clayallsopp",
      "indices" : [ 0, 12 ],
      "id_str" : "48464282",
      "id" : 48464282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327808301037404160",
  "geo" : { },
  "id_str" : "327808670656233472",
  "in_reply_to_user_id" : 48464282,
  "text" : "@clayallsopp It sure is. If an ad is compelling in &lt; 5 seconds I'll watch it.",
  "id" : 327808670656233472,
  "in_reply_to_status_id" : 327808301037404160,
  "created_at" : "2013-04-26 15:37:32 +0000",
  "in_reply_to_screen_name" : "clayallsopp",
  "in_reply_to_user_id_str" : "48464282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ochonicki",
      "screen_name" : "fromonesrc",
      "indices" : [ 0, 11 ],
      "id_str" : "14420513",
      "id" : 14420513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327804893119266817",
  "geo" : { },
  "id_str" : "327805144857198593",
  "in_reply_to_user_id" : 14420513,
  "text" : "@fromonesrc nope. custom data just gets fed out of Dash, which already has hooked into our statsd magic",
  "id" : 327805144857198593,
  "in_reply_to_status_id" : 327804893119266817,
  "created_at" : "2013-04-26 15:23:31 +0000",
  "in_reply_to_screen_name" : "fromonesrc",
  "in_reply_to_user_id_str" : "14420513",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Panic Inc",
      "screen_name" : "panic",
      "indices" : [ 16, 22 ],
      "id_str" : "6687652",
      "id" : 6687652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/QruWbpLegy",
      "expanded_url" : "http:\/\/37svn.com\/3514",
      "display_url" : "37svn.com\/3514"
    } ]
  },
  "geo" : { },
  "id_str" : "327803410571198465",
  "text" : "Current status: @panic's StatusBoard is making my job better: http:\/\/t.co\/QruWbpLegy",
  "id" : 327803410571198465,
  "created_at" : "2013-04-26 15:16:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/a64cpk9kkx",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=eSMeUPFjQHc",
      "display_url" : "youtube.com\/watch?v=eSMeUP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327621940615467009",
  "text" : "Robot Unicorn Attack 2 left out the best part of the original: http:\/\/t.co\/a64cpk9kkx",
  "id" : 327621940615467009,
  "created_at" : "2013-04-26 03:15:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327614796109332480",
  "text" : "@AlMehltretter holy hell dude. Hope things get better for you.",
  "id" : 327614796109332480,
  "created_at" : "2013-04-26 02:47:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Garner",
      "screen_name" : "WolfpackAlan",
      "indices" : [ 3, 16 ],
      "id_str" : "470937613",
      "id" : 470937613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327595830439723009",
  "text" : "RT @WolfpackAlan: To find your cool robot name, take the 16 digits of your credit card and add the expiration date and security code. What\u2019\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "206211814869049344",
    "text" : "To find your cool robot name, take the 16 digits of your credit card and add the expiration date and security code. What\u2019s yours?",
    "id" : 206211814869049344,
    "created_at" : "2012-05-26 02:35:02 +0000",
    "user" : {
      "name" : "Alan Garner",
      "screen_name" : "WolfpackAlan",
      "protected" : false,
      "id_str" : "470937613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1928783673\/zach-beard_normal.jpeg",
      "id" : 470937613,
      "verified" : false
    }
  },
  "id" : 327595830439723009,
  "created_at" : "2013-04-26 01:31:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 0, 12 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/gKtWUGTFn9",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Buffalo,_New_York#Nicknames",
      "display_url" : "en.wikipedia.org\/wiki\/Buffalo,_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "327583739343433730",
  "geo" : { },
  "id_str" : "327586255019855874",
  "in_reply_to_user_id" : 10035582,
  "text" : "@rocketslide I actually like Queen City better, but Nickel does the job. And it makes for cheap marketing campaigns. http:\/\/t.co\/gKtWUGTFn9",
  "id" : 327586255019855874,
  "in_reply_to_status_id" : 327583739343433730,
  "created_at" : "2013-04-26 00:53:44 +0000",
  "in_reply_to_screen_name" : "rocketslide",
  "in_reply_to_user_id_str" : "10035582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/327582945869168640\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/db26VydXXd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIvO9CNCAAISzDz.jpg",
      "id_str" : "327582945873362946",
      "id" : 327582945873362946,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIvO9CNCAAISzDz.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/db26VydXXd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327582945869168640",
  "text" : "Found a real Buffalo nickel finally! http:\/\/t.co\/db26VydXXd",
  "id" : 327582945869168640,
  "created_at" : "2013-04-26 00:40:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 7, 18 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 88, 96 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327575746170212352",
  "geo" : { },
  "id_str" : "327575991868325888",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH @ashedryden it's not like we're punching holes in coins or anything... &gt;_&gt; @whit537",
  "id" : 327575991868325888,
  "in_reply_to_status_id" : 327575746170212352,
  "created_at" : "2013-04-26 00:12:57 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 7, 18 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327575394960154624",
  "geo" : { },
  "id_str" : "327575690461446145",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH @ashedryden It's just a sticker. Comes off, and leaves no residue.",
  "id" : 327575690461446145,
  "in_reply_to_status_id" : 327575394960154624,
  "created_at" : "2013-04-26 00:11:45 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 18, 33 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/327574178901417984\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/EPxUbuaouI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIvG-utCYAAhXPO.jpg",
      "id_str" : "327574178905612288",
      "id" : 327574178905612288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIvG-utCYAAhXPO.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/EPxUbuaouI"
    } ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327574178901417984",
  "text" : "Getting ready for @nickelcityruby\u2019s #railsconf blitz! http:\/\/t.co\/EPxUbuaouI",
  "id" : 327574178901417984,
  "created_at" : "2013-04-26 00:05:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/hznu0Vop4d",
      "expanded_url" : "http:\/\/edu.mkrecny.com\/thoughts\/how-i-fired-myself",
      "display_url" : "edu.mkrecny.com\/thoughts\/how-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327501077895327745",
  "text" : "\"this, is a monumental fuck up\" http:\/\/t.co\/hznu0Vop4d",
  "id" : 327501077895327745,
  "created_at" : "2013-04-25 19:15:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heisenbeard",
      "screen_name" : "blainsmith",
      "indices" : [ 3, 14 ],
      "id_str" : "119995231",
      "id" : 119995231
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 35, 50 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327499420033753089",
  "text" : "RT @blainsmith: Got my tickets for @nickelcityruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 19, 34 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327497188810817538",
    "text" : "Got my tickets for @nickelcityruby",
    "id" : 327497188810817538,
    "created_at" : "2013-04-25 18:59:49 +0000",
    "user" : {
      "name" : "Heisenbeard",
      "screen_name" : "blainsmith",
      "protected" : false,
      "id_str" : "119995231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497376695167774720\/Un3XljbS_normal.jpeg",
      "id" : 119995231,
      "verified" : false
    }
  },
  "id" : 327499420033753089,
  "created_at" : "2013-04-25 19:08:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 3, 10 ],
      "id_str" : "34953",
      "id" : 34953
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 33, 48 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/zOh7mOzAWs",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "327494321773346816",
  "text" : "RT @nathos: Ticket purchased for @nickelcityruby. Looking forward to it! http:\/\/t.co\/zOh7mOzAWs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 21, 36 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/zOh7mOzAWs",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "327493748613328896",
    "text" : "Ticket purchased for @nickelcityruby. Looking forward to it! http:\/\/t.co\/zOh7mOzAWs",
    "id" : 327493748613328896,
    "created_at" : "2013-04-25 18:46:08 +0000",
    "user" : {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "protected" : false,
      "id_str" : "34953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570421723984429056\/SiXp3XlU_normal.jpeg",
      "id" : 34953,
      "verified" : false
    }
  },
  "id" : 327494321773346816,
  "created_at" : "2013-04-25 18:48:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 3, 14 ],
      "id_str" : "15445975",
      "id" : 15445975
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 40, 55 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327492590180110337",
  "text" : "RT @paddyforan: If people want to go to @nickelcityruby but can't afford it, I can probably offer a couch to sleep on to save on hotel expe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 24, 39 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327491539913814016",
    "text" : "If people want to go to @nickelcityruby but can't afford it, I can probably offer a couch to sleep on to save on hotel expenses.",
    "id" : 327491539913814016,
    "created_at" : "2013-04-25 18:37:22 +0000",
    "user" : {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "protected" : false,
      "id_str" : "15445975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433766988179963904\/MjnoKMzP_normal.jpeg",
      "id" : 15445975,
      "verified" : false
    }
  },
  "id" : 327492590180110337,
  "created_at" : "2013-04-25 18:41:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0410\u043D\u0434\u0440\u0438\u0439\u0447\u0443\u043A \u0412\u0430\u0441\u0438\u043B\u0438\u0439",
      "screen_name" : "brickattack",
      "indices" : [ 0, 12 ],
      "id_str" : "2833581694",
      "id" : 2833581694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327426519389577217",
  "geo" : { },
  "id_str" : "327490872268713984",
  "in_reply_to_user_id" : 14789935,
  "text" : "@brickattack It's beautiful. No snow. I promise.",
  "id" : 327490872268713984,
  "in_reply_to_status_id" : 327426519389577217,
  "created_at" : "2013-04-25 18:34:43 +0000",
  "in_reply_to_screen_name" : "brkattk",
  "in_reply_to_user_id_str" : "14789935",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0410\u043D\u0434\u0440\u0438\u0439\u0447\u0443\u043A \u0412\u0430\u0441\u0438\u043B\u0438\u0439",
      "screen_name" : "brickattack",
      "indices" : [ 3, 15 ],
      "id_str" : "2833581694",
      "id" : 2833581694
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 42, 57 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327490823145005056",
  "text" : "RT @brickattack: Just bought a ticket for @nickelcityruby so I guess I'll see what Buffalo is like in September",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\/mac\" rel=\"nofollow\"\u003EOsfoora for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 25, 40 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327426519389577217",
    "text" : "Just bought a ticket for @nickelcityruby so I guess I'll see what Buffalo is like in September",
    "id" : 327426519389577217,
    "created_at" : "2013-04-25 14:19:00 +0000",
    "user" : {
      "name" : "Erik Straub",
      "screen_name" : "brkattk",
      "protected" : false,
      "id_str" : "14789935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484774254479941632\/vyADZwQ3_normal.jpeg",
      "id" : 14789935,
      "verified" : false
    }
  },
  "id" : 327490823145005056,
  "created_at" : "2013-04-25 18:34:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327475289745682432",
  "text" : "Completely forgot about WWDC. Ooops.",
  "id" : 327475289745682432,
  "created_at" : "2013-04-25 17:32:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327459286471041024",
  "text" : "Yet another advantage to remote work: helping out a friend with a flat tire on a whim.",
  "id" : 327459286471041024,
  "created_at" : "2013-04-25 16:29:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 3, 10 ],
      "id_str" : "6505422",
      "id" : 6505422
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 33, 48 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327443020150620160",
  "text" : "RT @jyurek: Submitted my talk to @nickelcityruby!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 21, 36 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327441575670083584",
    "text" : "Submitted my talk to @nickelcityruby!",
    "id" : 327441575670083584,
    "created_at" : "2013-04-25 15:18:49 +0000",
    "user" : {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "protected" : false,
      "id_str" : "6505422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/26559072\/498945207_94895e9527_s_normal.jpg",
      "id" : 6505422,
      "verified" : false
    }
  },
  "id" : 327443020150620160,
  "created_at" : "2013-04-25 15:24:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327423026087985152",
  "geo" : { },
  "id_str" : "327425692029566977",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda cliche, but Watchmen and V for Vendetta are essentials.",
  "id" : 327425692029566977,
  "in_reply_to_status_id" : 327423026087985152,
  "created_at" : "2013-04-25 14:15:42 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Lindsay",
      "screen_name" : "adamlindsay",
      "indices" : [ 0, 12 ],
      "id_str" : "49763",
      "id" : 49763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327251587233890305",
  "geo" : { },
  "id_str" : "327255229311635456",
  "in_reply_to_user_id" : 49763,
  "text" : "@adamlindsay \u201CGrab Dem Balls\u201D ? Are you serious?",
  "id" : 327255229311635456,
  "in_reply_to_status_id" : 327251587233890305,
  "created_at" : "2013-04-25 02:58:21 +0000",
  "in_reply_to_screen_name" : "adamlindsay",
  "in_reply_to_user_id_str" : "49763",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Barnard",
      "screen_name" : "drbarnard",
      "indices" : [ 0, 10 ],
      "id_str" : "7826502",
      "id" : 7826502
    }, {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 11, 23 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326901690806702080",
  "geo" : { },
  "id_str" : "327247719062196224",
  "in_reply_to_user_id" : 7826502,
  "text" : "@drbarnard @marcoarment we enabled it via Crittercism but only after 15 app loads. Wanted to encourage some positive reviews.",
  "id" : 327247719062196224,
  "in_reply_to_status_id" : 326901690806702080,
  "created_at" : "2013-04-25 02:28:30 +0000",
  "in_reply_to_screen_name" : "drbarnard",
  "in_reply_to_user_id_str" : "7826502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/XQdRbPC8XP",
      "expanded_url" : "http:\/\/thatcan.be\/my\/next\/tweet",
      "display_url" : "thatcan.be\/my\/next\/tweet"
    } ]
  },
  "geo" : { },
  "id_str" : "327215848437731328",
  "text" : "This is kind of hubris, arrogance, and shouting FUCK! I never did. yep, have more apps do this. \u2014 http:\/\/t.co\/XQdRbPC8XP",
  "id" : 327215848437731328,
  "created_at" : "2013-04-25 00:21:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 52, 67 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327215319481466881",
  "text" : "RT @zombidev: I just submitted a proposal on DCI to @nickelcityruby! Couldn't be more excited!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 38, 53 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327135048765669376",
    "text" : "I just submitted a proposal on DCI to @nickelcityruby! Couldn't be more excited!",
    "id" : 327135048765669376,
    "created_at" : "2013-04-24 19:00:48 +0000",
    "user" : {
      "name" : "Mike Pack",
      "screen_name" : "mikepack_",
      "protected" : false,
      "id_str" : "271076364",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472095259778744320\/leeormXT_normal.jpeg",
      "id" : 271076364,
      "verified" : false
    }
  },
  "id" : 327215319481466881,
  "created_at" : "2013-04-25 00:19:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Kreeftmeijer",
      "screen_name" : "jkreeftmeijer",
      "indices" : [ 0, 14 ],
      "id_str" : "8284992",
      "id" : 8284992
    }, {
      "name" : "Christoph Olszowka",
      "screen_name" : "TheDeadSerious",
      "indices" : [ 15, 30 ],
      "id_str" : "6151392",
      "id" : 6151392
    }, {
      "name" : "Peter Schr\u00F6der",
      "screen_name" : "phoet",
      "indices" : [ 31, 37 ],
      "id_str" : "14339524",
      "id" : 14339524
    }, {
      "name" : "Lean (inkel)",
      "screen_name" : "inkel",
      "indices" : [ 38, 44 ],
      "id_str" : "7849852",
      "id" : 7849852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/4gR2ekqqAZ",
      "expanded_url" : "http:\/\/guides.rubygems.org\/make-your-own-gem\/",
      "display_url" : "guides.rubygems.org\/make-your-own-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "327158876216639488",
  "geo" : { },
  "id_str" : "327160839431921666",
  "in_reply_to_user_id" : 8284992,
  "text" : "@jkreeftmeijer @TheDeadSerious @phoet @inkel what's why I wrote http:\/\/t.co\/4gR2ekqqAZ - it's just simple, and will work.",
  "id" : 327160839431921666,
  "in_reply_to_status_id" : 327158876216639488,
  "created_at" : "2013-04-24 20:43:17 +0000",
  "in_reply_to_screen_name" : "jkreeftmeijer",
  "in_reply_to_user_id_str" : "8284992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 0, 10 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327124321556369409",
  "geo" : { },
  "id_str" : "327126515194142720",
  "in_reply_to_user_id" : 5965482,
  "text" : "@jankowski rebasing is cleaner",
  "id" : 327126515194142720,
  "in_reply_to_status_id" : 327124321556369409,
  "created_at" : "2013-04-24 18:26:53 +0000",
  "in_reply_to_screen_name" : "jankowski",
  "in_reply_to_user_id_str" : "5965482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    }, {
      "name" : "Synacor",
      "screen_name" : "Synacor",
      "indices" : [ 15, 23 ],
      "id_str" : "19976046",
      "id" : 19976046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327117990141259776",
  "geo" : { },
  "id_str" : "327118997071994880",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting @Synacor awesome!",
  "id" : 327118997071994880,
  "in_reply_to_status_id" : 327117990141259776,
  "created_at" : "2013-04-24 17:57:01 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327114975493640193",
  "geo" : { },
  "id_str" : "327116788468944897",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik Ah, dang.",
  "id" : 327116788468944897,
  "in_reply_to_status_id" : 327114975493640193,
  "created_at" : "2013-04-24 17:48:14 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/THvEMuT3XI",
      "expanded_url" : "http:\/\/twinbeard.com\/frog-fractions",
      "display_url" : "twinbeard.com\/frog-fractions"
    } ]
  },
  "geo" : { },
  "id_str" : "327113605579415553",
  "text" : "Learn some fractions with Frog Fractions! http:\/\/t.co\/THvEMuT3XI",
  "id" : 327113605579415553,
  "created_at" : "2013-04-24 17:35:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327101740300247040",
  "geo" : { },
  "id_str" : "327108942767456256",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik in Providence!",
  "id" : 327108942767456256,
  "in_reply_to_status_id" : 327101740300247040,
  "created_at" : "2013-04-24 17:17:04 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucas Pope",
      "screen_name" : "dukope",
      "indices" : [ 0, 7 ],
      "id_str" : "520685404",
      "id" : 520685404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/Tao8y4qjcX",
      "expanded_url" : "http:\/\/pages.github.com",
      "display_url" : "pages.github.com"
    } ]
  },
  "in_reply_to_status_id_str" : "327101295460745216",
  "geo" : { },
  "id_str" : "327108225109479425",
  "in_reply_to_user_id" : 520685404,
  "text" : "@dukope maybe time to move the site to github pages? http:\/\/t.co\/Tao8y4qjcX (it's free!)",
  "id" : 327108225109479425,
  "in_reply_to_status_id" : 327101295460745216,
  "created_at" : "2013-04-24 17:14:12 +0000",
  "in_reply_to_screen_name" : "dukope",
  "in_reply_to_user_id_str" : "520685404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 34, 46 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/sc8O2QIUxO",
      "expanded_url" : "http:\/\/www.aqueousband.com\/tour.php",
      "display_url" : "aqueousband.com\/tour.php"
    } ]
  },
  "geo" : { },
  "id_str" : "327098222956933120",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik I hope you're going to see @AqueousBand tonight: http:\/\/t.co\/sc8O2QIUxO",
  "id" : 327098222956933120,
  "created_at" : "2013-04-24 16:34:28 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher",
      "screen_name" : "mstrchrstphr",
      "indices" : [ 0, 13 ],
      "id_str" : "6702692",
      "id" : 6702692
    }, {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 14, 27 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327073323810975744",
  "geo" : { },
  "id_str" : "327078588417462272",
  "in_reply_to_user_id" : 6702692,
  "text" : "@mstrchrstphr @olivierlacan Trillian.",
  "id" : 327078588417462272,
  "in_reply_to_status_id" : 327073323810975744,
  "created_at" : "2013-04-24 15:16:26 +0000",
  "in_reply_to_screen_name" : "mstrchrstphr",
  "in_reply_to_user_id_str" : "6702692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    }, {
      "name" : "Synacor",
      "screen_name" : "Synacor",
      "indices" : [ 57, 65 ],
      "id_str" : "19976046",
      "id" : 19976046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327059313002676224",
  "geo" : { },
  "id_str" : "327061093522472960",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting woot woot! We need to get the word out to @synacor that this is happening :)",
  "id" : 327061093522472960,
  "in_reply_to_status_id" : 327059313002676224,
  "created_at" : "2013-04-24 14:06:55 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 3, 17 ],
      "id_str" : "15060778",
      "id" : 15060778
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 38, 53 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327061018058563585",
  "text" : "RT @gnuconsulting: Just signed up for @nickelcityruby Still crossing my fingers that my talk proposal is accepted!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 19, 34 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327059313002676224",
    "text" : "Just signed up for @nickelcityruby Still crossing my fingers that my talk proposal is accepted!",
    "id" : 327059313002676224,
    "created_at" : "2013-04-24 13:59:51 +0000",
    "user" : {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "protected" : false,
      "id_str" : "15060778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474011977006579712\/EWheVLDk_normal.jpeg",
      "id" : 15060778,
      "verified" : false
    }
  },
  "id" : 327061018058563585,
  "created_at" : "2013-04-24 14:06:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 3, 7 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327048371393138689",
  "text" : "RT @lrz: WWDC announced! Now let\u2019s run to hacker news to read expert commentary about the conference logo and what it secretly implies!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327042837566861312",
    "text" : "WWDC announced! Now let\u2019s run to hacker news to read expert commentary about the conference logo and what it secretly implies!",
    "id" : 327042837566861312,
    "created_at" : "2013-04-24 12:54:23 +0000",
    "user" : {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "protected" : false,
      "id_str" : "10452222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459499652228714497\/EiSPykkq_normal.png",
      "id" : 10452222,
      "verified" : false
    }
  },
  "id" : 327048371393138689,
  "created_at" : "2013-04-24 13:16:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Jake Goulding",
      "screen_name" : "JakeGoulding",
      "indices" : [ 15, 28 ],
      "id_str" : "197769225",
      "id" : 197769225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327033002943188993",
  "geo" : { },
  "id_str" : "327038399787700225",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents @JakeGoulding yay! Congrats!",
  "id" : 327038399787700225,
  "in_reply_to_status_id" : 327033002943188993,
  "created_at" : "2013-04-24 12:36:45 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326908206934802432",
  "geo" : { },
  "id_str" : "326908610045157376",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove they sprout hundreds of wings. That\u2019s why it\u2019s a herd.",
  "id" : 326908610045157376,
  "in_reply_to_status_id" : 326908206934802432,
  "created_at" : "2013-04-24 04:01:00 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 3, 14 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326908310047567872",
  "text" : "RT @tenderlove: Buffalo seem to have very small wings for their size.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "326908206934802432",
    "text" : "Buffalo seem to have very small wings for their size.",
    "id" : 326908206934802432,
    "created_at" : "2013-04-24 03:59:24 +0000",
    "user" : {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "protected" : false,
      "id_str" : "14761655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000325798111\/ca48276f8ebbbbac9c6ce83aac3c8548_normal.jpeg",
      "id" : 14761655,
      "verified" : false
    }
  },
  "id" : 326908310047567872,
  "created_at" : "2013-04-24 03:59:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bipolar Fleece",
      "screen_name" : "porkbelt",
      "indices" : [ 0, 9 ],
      "id_str" : "614019653",
      "id" : 614019653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326907066025398272",
  "geo" : { },
  "id_str" : "326907707498049536",
  "in_reply_to_user_id" : 614019653,
  "text" : "@porkbelt this can\u2019t be real",
  "id" : 326907707498049536,
  "in_reply_to_status_id" : 326907066025398272,
  "created_at" : "2013-04-24 03:57:25 +0000",
  "in_reply_to_screen_name" : "porkbelt",
  "in_reply_to_user_id_str" : "614019653",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alberto De Lucca ",
      "screen_name" : "adeluccar",
      "indices" : [ 0, 10 ],
      "id_str" : "174408001",
      "id" : 174408001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326898453714182145",
  "geo" : { },
  "id_str" : "326898656374558720",
  "in_reply_to_user_id" : 174408001,
  "text" : "@adeluccar it\u2019s on the footer of every page\u2026 not sure how else to broadcast it :\/",
  "id" : 326898656374558720,
  "in_reply_to_status_id" : 326898453714182145,
  "created_at" : "2013-04-24 03:21:27 +0000",
  "in_reply_to_screen_name" : "adeluccar",
  "in_reply_to_user_id_str" : "174408001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alberto De Lucca ",
      "screen_name" : "adeluccar",
      "indices" : [ 0, 10 ],
      "id_str" : "174408001",
      "id" : 174408001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/d6jgBXAGym",
      "expanded_url" : "http:\/\/status.rubygems.org\/",
      "display_url" : "status.rubygems.org"
    }, {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/0ePC1qO9DV",
      "expanded_url" : "http:\/\/uptime.rubygems.org\/",
      "display_url" : "uptime.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "326889801590644737",
  "geo" : { },
  "id_str" : "326892864187539457",
  "in_reply_to_user_id" : 174408001,
  "text" : "@adeluccar no: http:\/\/t.co\/d6jgBXAGym http:\/\/t.co\/0ePC1qO9DV",
  "id" : 326892864187539457,
  "in_reply_to_status_id" : 326889801590644737,
  "created_at" : "2013-04-24 02:58:26 +0000",
  "in_reply_to_screen_name" : "adeluccar",
  "in_reply_to_user_id_str" : "174408001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326885913181425666",
  "text" : "Atom Zombie Smasher is...really difficult. It's more RTS than I thought (I'm terrible at them)",
  "id" : 326885913181425666,
  "created_at" : "2013-04-24 02:30:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326861711476944897",
  "geo" : { },
  "id_str" : "326865942434942976",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr heck yes! Would love to see some more githubbers out here for it.",
  "id" : 326865942434942976,
  "in_reply_to_status_id" : 326861711476944897,
  "created_at" : "2013-04-24 01:11:28 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 3, 9 ],
      "id_str" : "10403812",
      "id" : 10403812
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 31, 46 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326865867474337792",
  "text" : "RT @wfarr: Super excited about @nickelcityruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 20, 35 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "326861711476944897",
    "text" : "Super excited about @nickelcityruby",
    "id" : 326861711476944897,
    "created_at" : "2013-04-24 00:54:39 +0000",
    "user" : {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "protected" : false,
      "id_str" : "10403812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543857966395305984\/IVdcW2qU_normal.png",
      "id" : 10403812,
      "verified" : false
    }
  },
  "id" : 326865867474337792,
  "created_at" : "2013-04-24 01:11:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garrett Murphey",
      "screen_name" : "gmurphey",
      "indices" : [ 0, 9 ],
      "id_str" : "822220",
      "id" : 822220
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326844009693712384",
  "geo" : { },
  "id_str" : "326845716259536896",
  "in_reply_to_user_id" : 822220,
  "text" : "@gmurphey wat?",
  "id" : 326845716259536896,
  "in_reply_to_status_id" : 326844009693712384,
  "created_at" : "2013-04-23 23:51:05 +0000",
  "in_reply_to_screen_name" : "gmurphey",
  "in_reply_to_user_id_str" : "822220",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias G\u00FCnther",
      "screen_name" : "wikimatze",
      "indices" : [ 0, 10 ],
      "id_str" : "89908942",
      "id" : 89908942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326779697327374337",
  "geo" : { },
  "id_str" : "326838473363431426",
  "in_reply_to_user_id" : 89908942,
  "text" : "@wikimatze woot! Glad we\u2019re getting some international attention )",
  "id" : 326838473363431426,
  "in_reply_to_status_id" : 326779697327374337,
  "created_at" : "2013-04-23 23:22:19 +0000",
  "in_reply_to_screen_name" : "wikimatze",
  "in_reply_to_user_id_str" : "89908942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias G\u00FCnther",
      "screen_name" : "wikimatze",
      "indices" : [ 3, 13 ],
      "id_str" : "89908942",
      "id" : 89908942
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 42, 57 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326837323893444609",
  "text" : "RT @wikimatze: Submitted my proposals for @NickelCityRuby.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 27, 42 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "326779697327374337",
    "text" : "Submitted my proposals for @NickelCityRuby.",
    "id" : 326779697327374337,
    "created_at" : "2013-04-23 19:28:45 +0000",
    "user" : {
      "name" : "Matthias G\u00FCnther",
      "screen_name" : "wikimatze",
      "protected" : false,
      "id_str" : "89908942",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478095113655042048\/AL9arPXH_normal.jpeg",
      "id" : 89908942,
      "verified" : false
    }
  },
  "id" : 326837323893444609,
  "created_at" : "2013-04-23 23:17:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven! Ragnar\u00F6k",
      "screen_name" : "nuclearsandwich",
      "indices" : [ 0, 16 ],
      "id_str" : "178492493",
      "id" : 178492493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/qYDh2FH33O",
      "expanded_url" : "https:\/\/github.com\/qrush",
      "display_url" : "github.com\/qrush"
    } ]
  },
  "in_reply_to_status_id_str" : "326801648376741889",
  "geo" : { },
  "id_str" : "326804773175164928",
  "in_reply_to_user_id" : 178492493,
  "text" : "@nuclearsandwich email is on https:\/\/t.co\/qYDh2FH33O",
  "id" : 326804773175164928,
  "in_reply_to_status_id" : 326801648376741889,
  "created_at" : "2013-04-23 21:08:24 +0000",
  "in_reply_to_screen_name" : "nuclearsandwich",
  "in_reply_to_user_id_str" : "178492493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Futch",
      "screen_name" : "Futch007",
      "indices" : [ 0, 9 ],
      "id_str" : "490897163",
      "id" : 490897163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/uqsXRCj7dG",
      "expanded_url" : "http:\/\/openhack.github.io\/",
      "display_url" : "openhack.github.io"
    } ]
  },
  "in_reply_to_status_id_str" : "326767184581898240",
  "geo" : { },
  "id_str" : "326767981071855616",
  "in_reply_to_user_id" : 490897163,
  "text" : "@Futch007 Yes, and OpenHack is free. You can read more about how it works here: http:\/\/t.co\/uqsXRCj7dG",
  "id" : 326767981071855616,
  "in_reply_to_status_id" : 326767184581898240,
  "created_at" : "2013-04-23 18:42:12 +0000",
  "in_reply_to_screen_name" : "Futch007",
  "in_reply_to_user_id_str" : "490897163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Futch",
      "screen_name" : "Futch007",
      "indices" : [ 0, 9 ],
      "id_str" : "490897163",
      "id" : 490897163
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 25, 34 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/80o2X9y6cF",
      "expanded_url" : "http:\/\/openhack.github.io\/buffalo\/",
      "display_url" : "openhack.github.io\/buffalo\/"
    } ]
  },
  "in_reply_to_status_id_str" : "326763486417936384",
  "geo" : { },
  "id_str" : "326764706809384960",
  "in_reply_to_user_id" : 490897163,
  "text" : "@Futch007 well, the next @OpenHack will be the first Tuesday of May. I need to get the RSVP up, but it'll be at 7pm! http:\/\/t.co\/80o2X9y6cF",
  "id" : 326764706809384960,
  "in_reply_to_status_id" : 326763486417936384,
  "created_at" : "2013-04-23 18:29:11 +0000",
  "in_reply_to_screen_name" : "Futch007",
  "in_reply_to_user_id_str" : "490897163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326746147110653952",
  "text" : "I love how my Quora notifications are a fraction.",
  "id" : 326746147110653952,
  "created_at" : "2013-04-23 17:15:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326737029620703232",
  "geo" : { },
  "id_str" : "326737385889095680",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff saw someone with 2 at the dog park yesterday. I like big dogs, but holy crap, they were huge.",
  "id" : 326737385889095680,
  "in_reply_to_status_id" : 326737029620703232,
  "created_at" : "2013-04-23 16:40:37 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326732140521869312",
  "geo" : { },
  "id_str" : "326732347867291649",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella Seriously! Good question.",
  "id" : 326732347867291649,
  "in_reply_to_status_id" : 326732140521869312,
  "created_at" : "2013-04-23 16:20:36 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/ObLfPsEYHz",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    }, {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/TkH0LbkPBI",
      "expanded_url" : "http:\/\/www.hhs.gov\/digitalstrategy\/blog\/2013\/04\/healthcare-gov-uses-open-source.html",
      "display_url" : "hhs.gov\/digitalstrateg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326731824485249025",
  "text" : "Very awesome, http:\/\/t.co\/ObLfPsEYHz is Jekyll powered! That's some real-world OSS contribution right there. http:\/\/t.co\/TkH0LbkPBI",
  "id" : 326731824485249025,
  "created_at" : "2013-04-23 16:18:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "756161",
      "id" : 756161
    }, {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 62, 68 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326730086881570816",
  "geo" : { },
  "id_str" : "326731329930682368",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer I haven't done much work on Jekyll lately. It's all @parkr 's fault.",
  "id" : 326731329930682368,
  "in_reply_to_status_id" : 326730086881570816,
  "created_at" : "2013-04-23 16:16:34 +0000",
  "in_reply_to_screen_name" : "zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Faustino",
      "screen_name" : "kfaustino",
      "indices" : [ 3, 13 ],
      "id_str" : "14846554",
      "id" : 14846554
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 29, 44 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 92, 100 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326731198439239680",
  "text" : "RT @kfaustino: I\u2019m attending @nickelcityruby in September. Excited to see what the folks of @wnyruby have in store for us.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 14, 29 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "WNY Ruby",
        "screen_name" : "wnyruby",
        "indices" : [ 77, 85 ],
        "id_str" : "205886758",
        "id" : 205886758
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "326729692621189120",
    "text" : "I\u2019m attending @nickelcityruby in September. Excited to see what the folks of @wnyruby have in store for us.",
    "id" : 326729692621189120,
    "created_at" : "2013-04-23 16:10:03 +0000",
    "user" : {
      "name" : "Kevin Faustino",
      "screen_name" : "kfaustino",
      "protected" : false,
      "id_str" : "14846554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410761741\/9a1d70c6af6138529cd46da64f9a5922_normal.jpeg",
      "id" : 14846554,
      "verified" : false
    }
  },
  "id" : 326731198439239680,
  "created_at" : "2013-04-23 16:16:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 13, 28 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326730325516492800",
  "geo" : { },
  "id_str" : "326731177014722561",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @nickelcityruby Fixed, thanks!",
  "id" : 326731177014722561,
  "in_reply_to_status_id" : 326730325516492800,
  "created_at" : "2013-04-23 16:15:57 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "developmentseed",
      "screen_name" : "developmentseed",
      "indices" : [ 3, 19 ],
      "id_str" : "14074424",
      "id" : 14074424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/6vV9sG74a7",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/GONyuuXtFm",
      "expanded_url" : "http:\/\/www.hhs.gov\/digitalstrategy\/blog\/2013\/04\/healthcare-gov-uses-open-source.html",
      "display_url" : "hhs.gov\/digitalstrateg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326729950889639936",
  "text" : "RT @developmentseed: \"Jekyll-supported http:\/\/t.co\/6vV9sG74a7 will require approximately 30 less servers than current CMS implementations\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/6vV9sG74a7",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      }, {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/GONyuuXtFm",
        "expanded_url" : "http:\/\/www.hhs.gov\/digitalstrategy\/blog\/2013\/04\/healthcare-gov-uses-open-source.html",
        "display_url" : "hhs.gov\/digitalstrateg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "326331039796576256",
    "text" : "\"Jekyll-supported http:\/\/t.co\/6vV9sG74a7 will require approximately 30 less servers than current CMS implementations\" http:\/\/t.co\/GONyuuXtFm",
    "id" : 326331039796576256,
    "created_at" : "2013-04-22 13:45:57 +0000",
    "user" : {
      "name" : "developmentseed",
      "screen_name" : "developmentseed",
      "protected" : false,
      "id_str" : "14074424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453533673652899841\/cfxNRM0Y_normal.png",
      "id" : 14074424,
      "verified" : false
    }
  },
  "id" : 326729950889639936,
  "created_at" : "2013-04-23 16:11:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/eXldmt1AF0",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "326722302291083268",
  "text" : "RT @nickelcityruby: Tickets are still available at http:\/\/t.co\/eXldmt1AF0 for our conference in Buffalo, NY in September!  CFP is still ope\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/eXldmt1AF0",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "326721803982626817",
    "text" : "Tickets are still available at http:\/\/t.co\/eXldmt1AF0 for our conference in Buffalo, NY in September!  CFP is still open!",
    "id" : 326721803982626817,
    "created_at" : "2013-04-23 15:38:42 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 326722302291083268,
  "created_at" : "2013-04-23 15:40:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 0, 11 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 57, 71 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326667143741599745",
  "geo" : { },
  "id_str" : "326679979071004673",
  "in_reply_to_user_id" : 14114392,
  "text" : "@thoughtbot I lost it at ambient noise of the office and @joshuaclayton shouting FUCK!",
  "id" : 326679979071004673,
  "in_reply_to_status_id" : 326667143741599745,
  "created_at" : "2013-04-23 12:52:31 +0000",
  "in_reply_to_screen_name" : "thoughtbot",
  "in_reply_to_user_id_str" : "14114392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex McHale",
      "screen_name" : "alexmchale",
      "indices" : [ 0, 11 ],
      "id_str" : "13964832",
      "id" : 13964832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326656752483442689",
  "geo" : { },
  "id_str" : "326675831147597824",
  "in_reply_to_user_id" : 13964832,
  "text" : "@alexmchale I use Jolly Bastion. Awesome!",
  "id" : 326675831147597824,
  "in_reply_to_status_id" : 326656752483442689,
  "created_at" : "2013-04-23 12:36:02 +0000",
  "in_reply_to_screen_name" : "alexmchale",
  "in_reply_to_user_id_str" : "13964832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "corey s",
      "screen_name" : "corey_schaf",
      "indices" : [ 0, 12 ],
      "id_str" : "208497212",
      "id" : 208497212
    }, {
      "name" : "Futch",
      "screen_name" : "Futch007",
      "indices" : [ 13, 22 ],
      "id_str" : "490897163",
      "id" : 490897163
    }, {
      "name" : "Chris Langford",
      "screen_name" : "Chris_Langford",
      "indices" : [ 23, 38 ],
      "id_str" : "130242651",
      "id" : 130242651
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 122, 136 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/6S1Nh86Csr",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/?fromgroups=#!topic\/bigdcollective\/8oe8x2uhPSU",
      "display_url" : "groups.google.com\/forum\/?fromgro\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "326544620538437633",
  "geo" : { },
  "id_str" : "326547032040947714",
  "in_reply_to_user_id" : 5743852,
  "text" : "@corey_schaf @Futch007 @Chris_Langford also saw https:\/\/t.co\/6S1Nh86Csr, would be more than happy to host gamedev meetups @coworkbuffalo.",
  "id" : 326547032040947714,
  "in_reply_to_status_id" : 326544620538437633,
  "created_at" : "2013-04-23 04:04:14 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Brady",
      "screen_name" : "dbrady",
      "indices" : [ 0, 7 ],
      "id_str" : "14253546",
      "id" : 14253546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/K7tZXwmuLK",
      "expanded_url" : "http:\/\/dwarffortresswiki.org\/index.php\/DF2012:Quickstart_guide",
      "display_url" : "dwarffortresswiki.org\/index.php\/DF20\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "326545566995718145",
  "geo" : { },
  "id_str" : "326545935549227008",
  "in_reply_to_user_id" : 14253546,
  "text" : "@dbrady It's dangerous to go alone! Take this! http:\/\/t.co\/K7tZXwmuLK",
  "id" : 326545935549227008,
  "in_reply_to_status_id" : 326545566995718145,
  "created_at" : "2013-04-23 03:59:52 +0000",
  "in_reply_to_screen_name" : "dbrady",
  "in_reply_to_user_id_str" : "14253546",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Brady",
      "screen_name" : "dbrady",
      "indices" : [ 0, 7 ],
      "id_str" : "14253546",
      "id" : 14253546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/gVM2UUKjZR",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/ac867be7aefc9432a42074fc5195902d\/tumblr_mlcoj9RTsq1qj1cg2o1_400.jpg",
      "display_url" : "24.media.tumblr.com\/ac867be7aefc94\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "326542286014017538",
  "geo" : { },
  "id_str" : "326545227240337408",
  "in_reply_to_user_id" : 14253546,
  "text" : "@dbrady Learning curve is nothing. Programmers attune themselves to terrible interfaces in no time. http:\/\/t.co\/gVM2UUKjZR",
  "id" : 326545227240337408,
  "in_reply_to_status_id" : 326542286014017538,
  "created_at" : "2013-04-23 03:57:03 +0000",
  "in_reply_to_screen_name" : "dbrady",
  "in_reply_to_user_id_str" : "14253546",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "corey s",
      "screen_name" : "corey_schaf",
      "indices" : [ 0, 12 ],
      "id_str" : "208497212",
      "id" : 208497212
    }, {
      "name" : "Futch",
      "screen_name" : "Futch007",
      "indices" : [ 13, 22 ],
      "id_str" : "490897163",
      "id" : 490897163
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 59, 73 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326124337805529090",
  "geo" : { },
  "id_str" : "326544620538437633",
  "in_reply_to_user_id" : 208497212,
  "text" : "@corey_schaf @Futch007 we'd love to have more devs down at @coworkbuffalo. Come on down, coffee's on us :)",
  "id" : 326544620538437633,
  "in_reply_to_status_id" : 326124337805529090,
  "created_at" : "2013-04-23 03:54:39 +0000",
  "in_reply_to_screen_name" : "corey_schaf",
  "in_reply_to_user_id_str" : "208497212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Brady",
      "screen_name" : "dbrady",
      "indices" : [ 0, 7 ],
      "id_str" : "14253546",
      "id" : 14253546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/Cw0CRu0ldc",
      "expanded_url" : "http:\/\/oilfurnace.timdenee.com\/",
      "display_url" : "oilfurnace.timdenee.com"
    }, {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/5I9J5jyshV",
      "expanded_url" : "http:\/\/www.bravemule.com\/",
      "display_url" : "bravemule.com"
    } ]
  },
  "in_reply_to_status_id_str" : "326541128545492992",
  "geo" : { },
  "id_str" : "326541783775449088",
  "in_reply_to_user_id" : 14253546,
  "text" : "@dbrady Probably wise. I've burned many hours on it. Have you seen http:\/\/t.co\/Cw0CRu0ldc or http:\/\/t.co\/5I9J5jyshV ? &lt;3 Bravemule.",
  "id" : 326541783775449088,
  "in_reply_to_status_id" : 326541128545492992,
  "created_at" : "2013-04-23 03:43:22 +0000",
  "in_reply_to_screen_name" : "dbrady",
  "in_reply_to_user_id_str" : "14253546",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Brady",
      "screen_name" : "dbrady",
      "indices" : [ 0, 7 ],
      "id_str" : "14253546",
      "id" : 14253546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326540708053929985",
  "geo" : { },
  "id_str" : "326540830301102080",
  "in_reply_to_user_id" : 14253546,
  "text" : "@dbrady It totally is. Just missing zombie elephants.",
  "id" : 326540830301102080,
  "in_reply_to_status_id" : 326540708053929985,
  "created_at" : "2013-04-23 03:39:35 +0000",
  "in_reply_to_screen_name" : "dbrady",
  "in_reply_to_user_id_str" : "14253546",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/pWWOiWd4ZO",
      "expanded_url" : "http:\/\/englishrussia.com\/2013\/04\/19\/in-the-lava-mountains\/",
      "display_url" : "englishrussia.com\/2013\/04\/19\/in-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326539913128443905",
  "text" : "How my last Dwarf Fortress turned out: http:\/\/t.co\/pWWOiWd4ZO",
  "id" : 326539913128443905,
  "created_at" : "2013-04-23 03:35:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326531224694845441",
  "geo" : { },
  "id_str" : "326532004902490112",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant APPROVED",
  "id" : 326532004902490112,
  "in_reply_to_status_id" : 326531224694845441,
  "created_at" : "2013-04-23 03:04:31 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Van Cleef",
      "screen_name" : "joshvc",
      "indices" : [ 0, 7 ],
      "id_str" : "15422369",
      "id" : 15422369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326522472625238018",
  "geo" : { },
  "id_str" : "326526047795429377",
  "in_reply_to_user_id" : 15422369,
  "text" : "@joshvc DENIED",
  "id" : 326526047795429377,
  "in_reply_to_status_id" : 326522472625238018,
  "created_at" : "2013-04-23 02:40:51 +0000",
  "in_reply_to_screen_name" : "joshvc",
  "in_reply_to_user_id_str" : "15422369",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 11, 22 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/5IZy5q9Evi",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/b06a5eeeae113cfa5c2126f6ec6a43a9\/tumblr_mloakyn23r1qardsjo1_500.png",
      "display_url" : "25.media.tumblr.com\/b06a5eeeae113c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326526002572431360",
  "text" : "Predicting @kevinpurdy's near future: http:\/\/t.co\/5IZy5q9Evi",
  "id" : 326526002572431360,
  "created_at" : "2013-04-23 02:40:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hoang van ninh",
      "screen_name" : "ninh",
      "indices" : [ 0, 5 ],
      "id_str" : "1845099079",
      "id" : 1845099079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326517631194636289",
  "text" : "@ninh yeah, loving it. there's an Oregon Trail feel to it too, with keeping your family alive.",
  "id" : 326517631194636289,
  "created_at" : "2013-04-23 02:07:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/5JJjOXg9Ly",
      "expanded_url" : "http:\/\/www.dukope.com\/",
      "display_url" : "dukope.com"
    } ]
  },
  "geo" : { },
  "id_str" : "326502326057721856",
  "text" : "No seriously, try out Papers Please. Most intensely psychological game I've played in a while: http:\/\/t.co\/5JJjOXg9Ly",
  "id" : 326502326057721856,
  "created_at" : "2013-04-23 01:06:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Watson-Hamblin",
      "screen_name" : "FluffyJack",
      "indices" : [ 0, 11 ],
      "id_str" : "20360016",
      "id" : 20360016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326457106880425985",
  "geo" : { },
  "id_str" : "326458122505973760",
  "in_reply_to_user_id" : 20360016,
  "text" : "@FluffyJack nice! Not sure how it has butt saving abilities but great. There\u2019s really not much to it :)",
  "id" : 326458122505973760,
  "in_reply_to_status_id" : 326457106880425985,
  "created_at" : "2013-04-22 22:10:56 +0000",
  "in_reply_to_screen_name" : "FluffyJack",
  "in_reply_to_user_id_str" : "20360016",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Watson-Hamblin",
      "screen_name" : "FluffyJack",
      "indices" : [ 3, 14 ],
      "id_str" : "20360016",
      "id" : 20360016
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 56, 67 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "https:\/\/t.co\/Mkn7tEMBbE",
      "expanded_url" : "https:\/\/github.com\/qrush\/motion-layout",
      "display_url" : "github.com\/qrush\/motion-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326457989189992450",
  "text" : "RT @FluffyJack: I do have to say that motion-layout for @RubyMotion saved my butt with an app we're releasing soon at 6.2. https:\/\/t.co\/Mkn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyMotion",
        "screen_name" : "RubyMotion",
        "indices" : [ 40, 51 ],
        "id_str" : "381521407",
        "id" : 381521407
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/Mkn7tEMBbE",
        "expanded_url" : "https:\/\/github.com\/qrush\/motion-layout",
        "display_url" : "github.com\/qrush\/motion-l\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "326457106880425985",
    "text" : "I do have to say that motion-layout for @RubyMotion saved my butt with an app we're releasing soon at 6.2. https:\/\/t.co\/Mkn7tEMBbE",
    "id" : 326457106880425985,
    "created_at" : "2013-04-22 22:06:54 +0000",
    "user" : {
      "name" : "Jack Watson-Hamblin",
      "screen_name" : "FluffyJack",
      "protected" : false,
      "id_str" : "20360016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440703262056923136\/3C2cyUk0_normal.jpeg",
      "id" : 20360016,
      "verified" : false
    }
  },
  "id" : 326457989189992450,
  "created_at" : "2013-04-22 22:10:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 3, 14 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inspect",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/G61tkpvmH1",
      "expanded_url" : "http:\/\/blog.rubymotion.com\/post\/48547461731\/rubymotion-inspect-2013-wrap-up",
      "display_url" : "blog.rubymotion.com\/post\/485474617\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326444086678667264",
  "text" : "RT @RubyMotion: RubyMotion #inspect 2013 Wrap-Up http:\/\/t.co\/G61tkpvmH1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "inspect",
        "indices" : [ 11, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/G61tkpvmH1",
        "expanded_url" : "http:\/\/blog.rubymotion.com\/post\/48547461731\/rubymotion-inspect-2013-wrap-up",
        "display_url" : "blog.rubymotion.com\/post\/485474617\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "326336195623788544",
    "text" : "RubyMotion #inspect 2013 Wrap-Up http:\/\/t.co\/G61tkpvmH1",
    "id" : 326336195623788544,
    "created_at" : "2013-04-22 14:06:26 +0000",
    "user" : {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "protected" : false,
      "id_str" : "381521407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540869126445490178\/xG24kW5B_normal.png",
      "id" : 381521407,
      "verified" : false
    }
  },
  "id" : 326444086678667264,
  "created_at" : "2013-04-22 21:15:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucas Pope",
      "screen_name" : "dukope",
      "indices" : [ 0, 7 ],
      "id_str" : "520685404",
      "id" : 520685404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326419131589083136",
  "geo" : { },
  "id_str" : "326420463108644865",
  "in_reply_to_user_id" : 520685404,
  "text" : "@dukope ...True. that would be awesome too. Really liking it so far. Let a suicide bomber in.... D:",
  "id" : 326420463108644865,
  "in_reply_to_status_id" : 326419131589083136,
  "created_at" : "2013-04-22 19:41:17 +0000",
  "in_reply_to_screen_name" : "dukope",
  "in_reply_to_user_id_str" : "520685404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Acker",
      "screen_name" : "ackerdev",
      "indices" : [ 0, 9 ],
      "id_str" : "305174496",
      "id" : 305174496
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 10, 21 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Lucas Pope",
      "screen_name" : "dukope",
      "indices" : [ 22, 29 ],
      "id_str" : "520685404",
      "id" : 520685404
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 30, 44 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326417431167897601",
  "geo" : { },
  "id_str" : "326419106465210368",
  "in_reply_to_user_id" : 305174496,
  "text" : "@ackerdev @kevinpurdy @dukope @coworkbuffalo That's not a country! DENIED",
  "id" : 326419106465210368,
  "in_reply_to_status_id" : 326417431167897601,
  "created_at" : "2013-04-22 19:35:54 +0000",
  "in_reply_to_screen_name" : "ackerdev",
  "in_reply_to_user_id_str" : "305174496",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucas Pope",
      "screen_name" : "dukope",
      "indices" : [ 0, 7 ],
      "id_str" : "520685404",
      "id" : 520685404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326417222119596032",
  "in_reply_to_user_id" : 520685404,
  "text" : "@dukope Loving this. I'd kill for an iOS version...would much rather drag around with my fingers.",
  "id" : 326417222119596032,
  "created_at" : "2013-04-22 19:28:24 +0000",
  "in_reply_to_screen_name" : "dukope",
  "in_reply_to_user_id_str" : "520685404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Lucas Pope",
      "screen_name" : "dukope",
      "indices" : [ 17, 24 ],
      "id_str" : "520685404",
      "id" : 520685404
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 65, 79 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/mHUNS87dBp",
      "expanded_url" : "http:\/\/www.dukope.com\/",
      "display_url" : "dukope.com"
    } ]
  },
  "geo" : { },
  "id_str" : "326417087687954432",
  "text" : "RT @kevinpurdy: .@dukope's \"Papers, Please\" game is just killing @coworkbuffalo's productivity today. We are all agents. http:\/\/t.co\/mHUNS8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lucas Pope",
        "screen_name" : "dukope",
        "indices" : [ 1, 8 ],
        "id_str" : "520685404",
        "id" : 520685404
      }, {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 49, 63 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/mHUNS87dBp",
        "expanded_url" : "http:\/\/www.dukope.com\/",
        "display_url" : "dukope.com"
      } ]
    },
    "geo" : { },
    "id_str" : "326415751550480387",
    "text" : ".@dukope's \"Papers, Please\" game is just killing @coworkbuffalo's productivity today. We are all agents. http:\/\/t.co\/mHUNS87dBp",
    "id" : 326415751550480387,
    "created_at" : "2013-04-22 19:22:34 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 326417087687954432,
  "created_at" : "2013-04-22 19:27:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "Greg Borenstein",
      "screen_name" : "atduskgreg",
      "indices" : [ 10, 21 ],
      "id_str" : "26853",
      "id" : 26853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326408290156310530",
  "geo" : { },
  "id_str" : "326417021191479296",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone @atduskgreg basically. I don't like the stories I hear of products not shipping :\/",
  "id" : 326417021191479296,
  "in_reply_to_status_id" : 326408290156310530,
  "created_at" : "2013-04-22 19:27:37 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Maggard",
      "screen_name" : "cmaggard",
      "indices" : [ 0, 9 ],
      "id_str" : "13643732",
      "id" : 13643732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/pHHUrgE9yY",
      "expanded_url" : "http:\/\/dukope.com\/#ppl",
      "display_url" : "dukope.com\/#ppl"
    } ]
  },
  "in_reply_to_status_id_str" : "326402278980481024",
  "geo" : { },
  "id_str" : "326402635508875264",
  "in_reply_to_user_id" : 13643732,
  "text" : "@cmaggard No, I'm not? Beta is here: http:\/\/t.co\/pHHUrgE9yY I'm a sucker for any 8-bit styled game.",
  "id" : 326402635508875264,
  "in_reply_to_status_id" : 326402278980481024,
  "created_at" : "2013-04-22 18:30:27 +0000",
  "in_reply_to_screen_name" : "cmaggard",
  "in_reply_to_user_id_str" : "13643732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/I0jWNIsKz4",
      "expanded_url" : "http:\/\/steamcommunity.com\/sharedfiles\/filedetails\/?id=138290904",
      "display_url" : "steamcommunity.com\/sharedfiles\/fi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326400823347269633",
  "text" : "Papers, Please looks like it's going to be a great game...upvote it! http:\/\/t.co\/I0jWNIsKz4",
  "id" : 326400823347269633,
  "created_at" : "2013-04-22 18:23:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "Greg Borenstein",
      "screen_name" : "atduskgreg",
      "indices" : [ 10, 21 ],
      "id_str" : "26853",
      "id" : 26853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326393899268599808",
  "geo" : { },
  "id_str" : "326397414187626496",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone @atduskgreg Zero. I refuse to be disappointed.",
  "id" : 326397414187626496,
  "in_reply_to_status_id" : 326393899268599808,
  "created_at" : "2013-04-22 18:09:42 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326375222754295808",
  "geo" : { },
  "id_str" : "326376053385854977",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn sorted in order of my preference.",
  "id" : 326376053385854977,
  "in_reply_to_status_id" : 326375222754295808,
  "created_at" : "2013-04-22 16:44:49 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/RRguAXnDfs",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food\/",
      "display_url" : "coworkbuffalo.com\/food\/"
    } ]
  },
  "geo" : { },
  "id_str" : "326374472766599168",
  "text" : "Updated http:\/\/t.co\/RRguAXnDfs with some of the latest trucks here in Buffalo.",
  "id" : 326374472766599168,
  "created_at" : "2013-04-22 16:38:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yannick \u2603 Schutz",
      "screen_name" : "yann_ck",
      "indices" : [ 3, 11 ],
      "id_str" : "14835545",
      "id" : 14835545
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 32, 41 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326174090132070400",
  "text" : "RT @yann_ck: I want to organize @openhack on Brussels! Who\u2019s in? Who wants to help? Who may sponsor us?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 19, 28 ],
        "id_str" : "715440464",
        "id" : 715440464
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "326010739439587328",
    "text" : "I want to organize @openhack on Brussels! Who\u2019s in? Who wants to help? Who may sponsor us?",
    "id" : 326010739439587328,
    "created_at" : "2013-04-21 16:33:11 +0000",
    "user" : {
      "name" : "Yannick \u2603 Schutz",
      "screen_name" : "yann_ck",
      "protected" : false,
      "id_str" : "14835545",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456012586043985921\/VITqbNxD_normal.jpeg",
      "id" : 14835545,
      "verified" : false
    }
  },
  "id" : 326174090132070400,
  "created_at" : "2013-04-22 03:22:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 0, 7 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326167056208777216",
  "geo" : { },
  "id_str" : "326167190334226432",
  "in_reply_to_user_id" : 38003,
  "text" : "@gedeon that is the worst.",
  "id" : 326167190334226432,
  "in_reply_to_status_id" : 326167056208777216,
  "created_at" : "2013-04-22 02:54:52 +0000",
  "in_reply_to_screen_name" : "gedeon",
  "in_reply_to_user_id_str" : "38003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "The Jesuit Post",
      "screen_name" : "TheJesuitPost",
      "indices" : [ 27, 41 ],
      "id_str" : "362139458",
      "id" : 362139458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326158474457280512",
  "geo" : { },
  "id_str" : "326163371265228800",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky this is great. Hey @TheJesuitPost, perhaps worth a reblog?",
  "id" : 326163371265228800,
  "in_reply_to_status_id" : 326158474457280512,
  "created_at" : "2013-04-22 02:39:42 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 3, 10 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/ZWZ6PZwgwO",
      "expanded_url" : "https:\/\/m.facebook.com\/mikerogerssj\/posts\/10100201942133474",
      "display_url" : "m.facebook.com\/mikerogerssj\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326163121045643266",
  "text" : "RT @Croaky: \"your death can never be my gain\" - written by my freshman year Resident Assistant in college and soon-to-be priest https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/ZWZ6PZwgwO",
        "expanded_url" : "https:\/\/m.facebook.com\/mikerogerssj\/posts\/10100201942133474",
        "display_url" : "m.facebook.com\/mikerogerssj\/p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "326158474457280512",
    "text" : "\"your death can never be my gain\" - written by my freshman year Resident Assistant in college and soon-to-be priest https:\/\/t.co\/ZWZ6PZwgwO",
    "id" : 326158474457280512,
    "created_at" : "2013-04-22 02:20:14 +0000",
    "user" : {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "protected" : false,
      "id_str" : "787595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568676101967196160\/nP3jFRbr_normal.jpeg",
      "id" : 787595,
      "verified" : false
    }
  },
  "id" : 326163121045643266,
  "created_at" : "2013-04-22 02:38:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326068715999346688",
  "text" : "RT @neiltyson: Watching on the FX network the film \"2012\" in which 6-billion people die. Was prepared: the rating warned of \"mild violence\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "326063362666553344",
    "text" : "Watching on the FX network the film \"2012\" in which 6-billion people die. Was prepared: the rating warned of \"mild violence\"",
    "id" : 326063362666553344,
    "created_at" : "2013-04-21 20:02:18 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 326068715999346688,
  "created_at" : "2013-04-21 20:23:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Downie",
      "screen_name" : "richdownie",
      "indices" : [ 3, 14 ],
      "id_str" : "10774712",
      "id" : 10774712
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 44, 59 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rustbelt",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326060938342043650",
  "text" : "RT @richdownie: I just bought my ticket for @nickelcityruby \n#rustbelt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 28, 43 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rustbelt",
        "indices" : [ 45, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "326060232197423105",
    "text" : "I just bought my ticket for @nickelcityruby \n#rustbelt",
    "id" : 326060232197423105,
    "created_at" : "2013-04-21 19:49:51 +0000",
    "user" : {
      "name" : "Rich Downie",
      "screen_name" : "richdownie",
      "protected" : false,
      "id_str" : "10774712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558639851176603649\/3qXKrGpA_normal.jpeg",
      "id" : 10774712,
      "verified" : false
    }
  },
  "id" : 326060938342043650,
  "created_at" : "2013-04-21 19:52:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Follow @CoralineAda",
      "screen_name" : "Bantik",
      "indices" : [ 3, 10 ],
      "id_str" : "2375715212",
      "id" : 2375715212
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 49, 64 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326055435255820289",
  "text" : "RT @bantik: Just submitted two talk proposals to @nickelcityruby.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 37, 52 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "326036827532316673",
    "text" : "Just submitted two talk proposals to @nickelcityruby.",
    "id" : 326036827532316673,
    "created_at" : "2013-04-21 18:16:51 +0000",
    "user" : {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "protected" : false,
      "id_str" : "9526722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566343829851099137\/QzrOHV5-_normal.jpeg",
      "id" : 9526722,
      "verified" : false
    }
  },
  "id" : 326055435255820289,
  "created_at" : "2013-04-21 19:30:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/ITAJFl3Hco",
      "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/culture\/2013\/04\/simcitys-evil-twin.html",
      "display_url" : "newyorker.com\/online\/blogs\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326045293969801217",
  "text" : "Dwarf Fortress made it to the New Yorker. http:\/\/t.co\/ITAJFl3Hco",
  "id" : 326045293969801217,
  "created_at" : "2013-04-21 18:50:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326037163240210433",
  "text" : "Watching some TPB movies tonight, complete with burgers, frozen chicken fingers, and a jug of OJ. Way of the road.",
  "id" : 326037163240210433,
  "created_at" : "2013-04-21 18:18:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326014976227672065",
  "geo" : { },
  "id_str" : "326018100459868160",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger woot woot :) Hope it works well for you!",
  "id" : 326018100459868160,
  "in_reply_to_status_id" : 326014976227672065,
  "created_at" : "2013-04-21 17:02:26 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325963760286187520",
  "text" : "Trevor. Smokes. Let's go.",
  "id" : 325963760286187520,
  "created_at" : "2013-04-21 13:26:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 13, 24 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325799295343284224",
  "text" : "@juliepagano @ashedryden OHHHHHH. This is why I\u2019m going to bed.",
  "id" : 325799295343284224,
  "created_at" : "2013-04-21 02:32:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 13, 24 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325798539462586369",
  "text" : "@juliepagano @ashedryden how does it even fit?!",
  "id" : 325798539462586369,
  "created_at" : "2013-04-21 02:29:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Dickson",
      "screen_name" : "alexdickson",
      "indices" : [ 3, 15 ],
      "id_str" : "16625702",
      "id" : 16625702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/ZaQY9lU1Tw",
      "expanded_url" : "https:\/\/medium.com\/editors-picks\/9ae1727d2479",
      "display_url" : "medium.com\/editors-picks\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "325797605504327682",
  "text" : "RT @alexdickson: You are not Steve Jobs https:\/\/t.co\/ZaQY9lU1Tw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/ZaQY9lU1Tw",
        "expanded_url" : "https:\/\/medium.com\/editors-picks\/9ae1727d2479",
        "display_url" : "medium.com\/editors-picks\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "325784717964230656",
    "text" : "You are not Steve Jobs https:\/\/t.co\/ZaQY9lU1Tw",
    "id" : 325784717964230656,
    "created_at" : "2013-04-21 01:35:04 +0000",
    "user" : {
      "name" : "Alex Dickson",
      "screen_name" : "alexdickson",
      "protected" : false,
      "id_str" : "16625702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468972557526253568\/N2bb2YCh_normal.jpeg",
      "id" : 16625702,
      "verified" : false
    }
  },
  "id" : 325797605504327682,
  "created_at" : "2013-04-21 02:26:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "JC",
      "screen_name" : "jcavena",
      "indices" : [ 11, 19 ],
      "id_str" : "15431544",
      "id" : 15431544
    }, {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 20, 27 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/325796856506482690\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/CcgTDTABRE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIV2g81CAAATtxy.jpg",
      "id_str" : "325796856510676992",
      "id" : 325796856510676992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIV2g81CAAATtxy.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/CcgTDTABRE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325763723392335872",
  "geo" : { },
  "id_str" : "325796856506482690",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @jcavena @elight :( http:\/\/t.co\/CcgTDTABRE",
  "id" : 325796856506482690,
  "in_reply_to_status_id" : 325763723392335872,
  "created_at" : "2013-04-21 02:23:18 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325780075385614336",
  "geo" : { },
  "id_str" : "325781486177509376",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden \u2026jar?",
  "id" : 325781486177509376,
  "in_reply_to_status_id" : 325780075385614336,
  "created_at" : "2013-04-21 01:22:13 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "coderjoe",
      "screen_name" : "coderjoe",
      "indices" : [ 0, 9 ],
      "id_str" : "15494948",
      "id" : 15494948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325692732683206659",
  "geo" : { },
  "id_str" : "325702881137262592",
  "in_reply_to_user_id" : 15494948,
  "text" : "@coderjoe heading out, sorry! Maybe next time.",
  "id" : 325702881137262592,
  "in_reply_to_status_id" : 325692732683206659,
  "created_at" : "2013-04-20 20:09:52 +0000",
  "in_reply_to_screen_name" : "coderjoe",
  "in_reply_to_user_id_str" : "15494948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "coderjoe",
      "screen_name" : "coderjoe",
      "indices" : [ 0, 9 ],
      "id_str" : "15494948",
      "id" : 15494948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325684471355539456",
  "geo" : { },
  "id_str" : "325686634756575232",
  "in_reply_to_user_id" : 15494948,
  "text" : "@coderjoe I was considering doing another talk on how to survive your first few minutes.",
  "id" : 325686634756575232,
  "in_reply_to_status_id" : 325684471355539456,
  "created_at" : "2013-04-20 19:05:19 +0000",
  "in_reply_to_screen_name" : "coderjoe",
  "in_reply_to_user_id_str" : "15494948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/325681784304046081\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/4oMdQMjJi6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIUN23fCEAASmSn.jpg",
      "id_str" : "325681784312434688",
      "id" : 325681784312434688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIUN23fCEAASmSn.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4oMdQMjJi6"
    } ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325681784304046081",
  "text" : "Tried out a Windows Surface at #barcamproc. Stock camera app asks for access to camera. \uD83D\uDE11 http:\/\/t.co\/4oMdQMjJi6",
  "id" : 325681784304046081,
  "created_at" : "2013-04-20 18:46:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 34, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/XFllugSOuP",
      "expanded_url" : "http:\/\/i.imgur.com\/wxMc2fE.gif",
      "display_url" : "i.imgur.com\/wxMc2fE.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "325663061065203713",
  "text" : "ALIENS.gif http:\/\/t.co\/XFllugSOuP #barcamproc",
  "id" : 325663061065203713,
  "created_at" : "2013-04-20 17:31:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325646527882227713",
  "geo" : { },
  "id_str" : "325647043383132160",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu feelings",
  "id" : 325647043383132160,
  "in_reply_to_status_id" : 325646527882227713,
  "created_at" : "2013-04-20 16:28:00 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325639058166521856",
  "geo" : { },
  "id_str" : "325646342615605251",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier I haven't set it up...haven't really needed it yet.",
  "id" : 325646342615605251,
  "in_reply_to_status_id" : 325639058166521856,
  "created_at" : "2013-04-20 16:25:12 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325624373442641922",
  "geo" : { },
  "id_str" : "325626847033434112",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin nope :(",
  "id" : 325626847033434112,
  "in_reply_to_status_id" : 325624373442641922,
  "created_at" : "2013-04-20 15:07:44 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inspect",
      "indices" : [ 33, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/1ct7xTUCCI",
      "expanded_url" : "https:\/\/speakerdeck.com\/qrush\/rubymotion-the-sleeper-has-awakened",
      "display_url" : "speakerdeck.com\/qrush\/rubymoti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "325622455211261953",
  "text" : "Finally got around to posting my #inspect talk - RubyMotion: The sleeper has awakened! https:\/\/t.co\/1ct7xTUCCI",
  "id" : 325622455211261953,
  "created_at" : "2013-04-20 14:50:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo JavaScript",
      "screen_name" : "BuffaloJS",
      "indices" : [ 20, 30 ],
      "id_str" : "817437266",
      "id" : 817437266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 3, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/MY9KokTCCr",
      "expanded_url" : "https:\/\/speakerdeck.com\/qrush\/coffeescript-spartan-javascript",
      "display_url" : "speakerdeck.com\/qrush\/coffeesc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "325622329453465601",
  "text" : "My #barcamproc (and @BuffaloJS) talk: CoffeeScript - Spartan Javascript https:\/\/t.co\/MY9KokTCCr",
  "id" : 325622329453465601,
  "created_at" : "2013-04-20 14:49:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "davidmoffitt",
      "screen_name" : "davidmoffitt",
      "indices" : [ 0, 13 ],
      "id_str" : "15101175",
      "id" : 15101175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BARCAMPROC",
      "indices" : [ 24, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325619676447121408",
  "geo" : { },
  "id_str" : "325619933797044226",
  "in_reply_to_user_id" : 15101175,
  "text" : "@davidmoffitt Y U NO AT #BARCAMPROC",
  "id" : 325619933797044226,
  "in_reply_to_status_id" : 325619676447121408,
  "created_at" : "2013-04-20 14:40:16 +0000",
  "in_reply_to_screen_name" : "davidmoffitt",
  "in_reply_to_user_id_str" : "15101175",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 72, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/6NdLQCI7tQ",
      "expanded_url" : "http:\/\/perl.plover.com\/yak\/presentation\/samples\/slide027.html",
      "display_url" : "perl.plover.com\/yak\/presentati\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "325605992735834112",
  "text" : "First talk and there's already a Second Row Guy: http:\/\/t.co\/6NdLQCI7tQ #barcamproc",
  "id" : 325605992735834112,
  "created_at" : "2013-04-20 13:44:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 5, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325601990799392769",
  "text" : "It\u2019s #barcamproc time! I think there\u2019s a new RIT building every time I come back to campus.",
  "id" : 325601990799392769,
  "created_at" : "2013-04-20 13:28:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325564527213166592",
  "text" : "Either I woke up too early for #barcamproc, or I\u2019m really high, or there\u2019s a snowstorm in Buffalo.",
  "id" : 325564527213166592,
  "created_at" : "2013-04-20 11:00:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 3, 10 ],
      "id_str" : "6154602",
      "id" : 6154602
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 48, 54 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325560846124204034",
  "text" : "RT @soffes: Just pushed version 1.3.2 of `m` by @qrush to Ruby Gems that fixes double running MiniTest tests!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 36, 42 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325540321989623808",
    "text" : "Just pushed version 1.3.2 of `m` by @qrush to Ruby Gems that fixes double running MiniTest tests!",
    "id" : 325540321989623808,
    "created_at" : "2013-04-20 09:23:55 +0000",
    "user" : {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "protected" : false,
      "id_str" : "6154602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545995221914230785\/N9a6vr0W_normal.jpeg",
      "id" : 6154602,
      "verified" : false
    }
  },
  "id" : 325560846124204034,
  "created_at" : "2013-04-20 10:45:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Holmes",
      "screen_name" : "DaveHolmes",
      "indices" : [ 3, 14 ],
      "id_str" : "7120172",
      "id" : 7120172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325340505531617280",
  "text" : "RT @DaveHolmes: Have we tried turning the world off for two minutes and then turning it back on?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325340092371722241",
    "text" : "Have we tried turning the world off for two minutes and then turning it back on?",
    "id" : 325340092371722241,
    "created_at" : "2013-04-19 20:08:17 +0000",
    "user" : {
      "name" : "Dave Holmes",
      "screen_name" : "DaveHolmes",
      "protected" : false,
      "id_str" : "7120172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000050706803\/a709b2642881b0024acd62878af5c249_normal.jpeg",
      "id" : 7120172,
      "verified" : true
    }
  },
  "id" : 325340505531617280,
  "created_at" : "2013-04-19 20:09:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BarCamp Rochester",
      "screen_name" : "BarCampRoc",
      "indices" : [ 3, 14 ],
      "id_str" : "20751318",
      "id" : 20751318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/m040Sbht2S",
      "expanded_url" : "http:\/\/barcamproc.org\/howto\/",
      "display_url" : "barcamproc.org\/howto\/"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/qwEGBTqrdM",
      "expanded_url" : "http:\/\/barcamproc.org\/directions\/",
      "display_url" : "barcamproc.org\/directions\/"
    } ]
  },
  "geo" : { },
  "id_str" : "325333734884773888",
  "text" : "RT @BarCampRoc: BarCamp Rochester is tomorrow! Registration starts at 8am, Talks start at 9am. http:\/\/t.co\/m040Sbht2S http:\/\/t.co\/qwEGBTqrdM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/m040Sbht2S",
        "expanded_url" : "http:\/\/barcamproc.org\/howto\/",
        "display_url" : "barcamproc.org\/howto\/"
      }, {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/qwEGBTqrdM",
        "expanded_url" : "http:\/\/barcamproc.org\/directions\/",
        "display_url" : "barcamproc.org\/directions\/"
      } ]
    },
    "geo" : { },
    "id_str" : "325333396949704706",
    "text" : "BarCamp Rochester is tomorrow! Registration starts at 8am, Talks start at 9am. http:\/\/t.co\/m040Sbht2S http:\/\/t.co\/qwEGBTqrdM",
    "id" : 325333396949704706,
    "created_at" : "2013-04-19 19:41:40 +0000",
    "user" : {
      "name" : "BarCamp Rochester",
      "screen_name" : "BarCampRoc",
      "protected" : false,
      "id_str" : "20751318",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1550483558\/barcamp_rochester_icon_445x445_trans_normal.png",
      "id" : 20751318,
      "verified" : false
    }
  },
  "id" : 325333734884773888,
  "created_at" : "2013-04-19 19:43:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick thomson",
      "screen_name" : "importantshock",
      "indices" : [ 0, 15 ],
      "id_str" : "7611992",
      "id" : 7611992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325326250480648192",
  "geo" : { },
  "id_str" : "325326756871561217",
  "in_reply_to_user_id" : 7611992,
  "text" : "@importantshock Slayin is good.",
  "id" : 325326756871561217,
  "in_reply_to_status_id" : 325326250480648192,
  "created_at" : "2013-04-19 19:15:17 +0000",
  "in_reply_to_screen_name" : "importantshock",
  "in_reply_to_user_id_str" : "7611992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325322471186251776",
  "geo" : { },
  "id_str" : "325323209484431361",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik ....wtf??",
  "id" : 325323209484431361,
  "in_reply_to_status_id" : 325322471186251776,
  "created_at" : "2013-04-19 19:01:12 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/325315114121179139\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/DfxdY852CH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIPAX2mCMAAuyZG.png",
      "id_str" : "325315114125373440",
      "id" : 325315114125373440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIPAX2mCMAAuyZG.png",
      "sizes" : [ {
        "h" : 105,
        "resize" : "fit",
        "w" : 477
      }, {
        "h" : 105,
        "resize" : "fit",
        "w" : 477
      }, {
        "h" : 105,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 105,
        "resize" : "fit",
        "w" : 477
      }, {
        "h" : 74,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DfxdY852CH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325315114121179139",
  "text" : "I've reached a new high in my career - http:\/\/t.co\/DfxdY852CH",
  "id" : 325315114121179139,
  "created_at" : "2013-04-19 18:29:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Fayram",
      "screen_name" : "KirinDave",
      "indices" : [ 0, 10 ],
      "id_str" : "784519",
      "id" : 784519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/Wv0c1tAQQj",
      "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=5576340",
      "display_url" : "news.ycombinator.com\/item?id=5576340"
    } ]
  },
  "in_reply_to_status_id_str" : "325313835449872384",
  "geo" : { },
  "id_str" : "325314090773909505",
  "in_reply_to_user_id" : 784519,
  "text" : "@KirinDave not even a joke https:\/\/t.co\/Wv0c1tAQQj",
  "id" : 325314090773909505,
  "in_reply_to_status_id" : 325313835449872384,
  "created_at" : "2013-04-19 18:24:57 +0000",
  "in_reply_to_screen_name" : "KirinDave",
  "in_reply_to_user_id_str" : "784519",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325313762720624640",
  "text" : "\"_why was the first person to actually create art around and about software\"- A Concerned Hacker News Commenter",
  "id" : 325313762720624640,
  "created_at" : "2013-04-19 18:23:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan McAdams",
      "screen_name" : "rit",
      "indices" : [ 0, 4 ],
      "id_str" : "5961382",
      "id" : 5961382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325290474262917121",
  "geo" : { },
  "id_str" : "325293040669437952",
  "in_reply_to_user_id" : 5961382,
  "text" : "@rit I'm amazed you haven't sold your account to RIT yet.",
  "id" : 325293040669437952,
  "in_reply_to_status_id" : 325290474262917121,
  "created_at" : "2013-04-19 17:01:19 +0000",
  "in_reply_to_screen_name" : "rit",
  "in_reply_to_user_id_str" : "5961382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325288345439719426",
  "geo" : { },
  "id_str" : "325288762932346880",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson nice!! Didn't know this was a thing.",
  "id" : 325288762932346880,
  "in_reply_to_status_id" : 325288345439719426,
  "created_at" : "2013-04-19 16:44:19 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hussey",
      "screen_name" : "seanhussey",
      "indices" : [ 0, 11 ],
      "id_str" : "14685595",
      "id" : 14685595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325276912538746881",
  "geo" : { },
  "id_str" : "325277328156528640",
  "in_reply_to_user_id" : 14685595,
  "text" : "@seanhussey WTF?",
  "id" : 325277328156528640,
  "in_reply_to_status_id" : 325276912538746881,
  "created_at" : "2013-04-19 15:58:53 +0000",
  "in_reply_to_screen_name" : "seanhussey",
  "in_reply_to_user_id_str" : "14685595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325274244709744640",
  "geo" : { },
  "id_str" : "325275131926679552",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit and another reason why no one I know under 30 reads the paper.",
  "id" : 325275131926679552,
  "in_reply_to_status_id" : 325274244709744640,
  "created_at" : "2013-04-19 15:50:09 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 3, 15 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325274954994155520",
  "text" : "RT @bcardarella: How bad ass would it be if the Spare Change Guy took this kid down?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325274395994107904",
    "text" : "How bad ass would it be if the Spare Change Guy took this kid down?",
    "id" : 325274395994107904,
    "created_at" : "2013-04-19 15:47:13 +0000",
    "user" : {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "protected" : false,
      "id_str" : "18787589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000553511645\/21a9348ff9f9ff11f9278695b8afa76d_normal.jpeg",
      "id" : 18787589,
      "verified" : false
    }
  },
  "id" : 325274954994155520,
  "created_at" : "2013-04-19 15:49:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325274395994107904",
  "geo" : { },
  "id_str" : "325274912719769600",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella ANYBODY KNOW WHAT TIME IT IS?",
  "id" : 325274912719769600,
  "in_reply_to_status_id" : 325274395994107904,
  "created_at" : "2013-04-19 15:49:17 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visual Idiot",
      "screen_name" : "idiot",
      "indices" : [ 3, 9 ],
      "id_str" : "202571491",
      "id" : 202571491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/P7KmLxzQY9",
      "expanded_url" : "http:\/\/artpolikarpov.github.io\/garmoshka\/",
      "display_url" : "artpolikarpov.github.io\/garmoshka\/"
    } ]
  },
  "geo" : { },
  "id_str" : "325262628756803585",
  "text" : "RT @idiot: Finally, someone\u2019s done something useful with responsive design. http:\/\/t.co\/P7KmLxzQY9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/P7KmLxzQY9",
        "expanded_url" : "http:\/\/artpolikarpov.github.io\/garmoshka\/",
        "display_url" : "artpolikarpov.github.io\/garmoshka\/"
      } ]
    },
    "geo" : { },
    "id_str" : "325254998650941440",
    "text" : "Finally, someone\u2019s done something useful with responsive design. http:\/\/t.co\/P7KmLxzQY9",
    "id" : 325254998650941440,
    "created_at" : "2013-04-19 14:30:09 +0000",
    "user" : {
      "name" : "Visual Idiot",
      "screen_name" : "idiot",
      "protected" : false,
      "id_str" : "202571491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569916959244840960\/-naw9y3Q_normal.png",
      "id" : 202571491,
      "verified" : false
    }
  },
  "id" : 325262628756803585,
  "created_at" : "2013-04-19 15:00:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325204071554371585",
  "text" : "Holy hell, as a former Waltham resident (next door to Watertown) I can\u2019t believe this news. Stay safe Boston.",
  "id" : 325204071554371585,
  "created_at" : "2013-04-19 11:07:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Weston Platter",
      "screen_name" : "westonplatter",
      "indices" : [ 0, 14 ],
      "id_str" : "114336396",
      "id" : 114336396
    }, {
      "name" : "Chris Thorn",
      "screen_name" : "thorncp",
      "indices" : [ 15, 23 ],
      "id_str" : "31168483",
      "id" : 31168483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325082257360564224",
  "geo" : { },
  "id_str" : "325083577484193792",
  "in_reply_to_user_id" : 114336396,
  "text" : "@westonplatter @thorncp any",
  "id" : 325083577484193792,
  "in_reply_to_status_id" : 325082257360564224,
  "created_at" : "2013-04-19 03:08:59 +0000",
  "in_reply_to_screen_name" : "westonplatter",
  "in_reply_to_user_id_str" : "114336396",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325042278794133504",
  "geo" : { },
  "id_str" : "325079565368188929",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik this guy needs a hug.",
  "id" : 325079565368188929,
  "in_reply_to_status_id" : 325042278794133504,
  "created_at" : "2013-04-19 02:53:02 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Fontenot",
      "screen_name" : "GFontenot",
      "indices" : [ 0, 10 ],
      "id_str" : "14848965",
      "id" : 14848965
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 11, 25 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325072726270304256",
  "geo" : { },
  "id_str" : "325073038376857601",
  "in_reply_to_user_id" : 14848965,
  "text" : "@GFontenot @joshuaclayton chrome works fine here\u2026just takes patience to make web views perform well :)",
  "id" : 325073038376857601,
  "in_reply_to_status_id" : 325072726270304256,
  "created_at" : "2013-04-19 02:27:06 +0000",
  "in_reply_to_screen_name" : "GFontenot",
  "in_reply_to_user_id_str" : "14848965",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    }, {
      "name" : "Gordon Fontenot",
      "screen_name" : "GFontenot",
      "indices" : [ 15, 25 ],
      "id_str" : "14848965",
      "id" : 14848965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325072023221043200",
  "geo" : { },
  "id_str" : "325072328553820160",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton @GFontenot afaik uiwebviews can\u2019t use Nitro, which is mobile Safari\u2019s optimized JS engine.",
  "id" : 325072328553820160,
  "in_reply_to_status_id" : 325072023221043200,
  "created_at" : "2013-04-19 02:24:17 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325057020547969024",
  "geo" : { },
  "id_str" : "325059415189368832",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule which belies the greater problems of hubris, arrogance, and ignorance. Humility is underrated :(",
  "id" : 325059415189368832,
  "in_reply_to_status_id" : 325057020547969024,
  "created_at" : "2013-04-19 01:32:58 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Ryan",
      "screen_name" : "MrJohnnyRyan",
      "indices" : [ 3, 16 ],
      "id_str" : "189310742",
      "id" : 189310742
    }, {
      "name" : "Kate Beaton",
      "screen_name" : "beatonna",
      "indices" : [ 19, 28 ],
      "id_str" : "36735522",
      "id" : 36735522
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/MrJohnnyRyan\/status\/325056515914473474\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/4GTYP7SLGU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BILVLdOCIAEeOGg.jpg",
      "id_str" : "325056515922862081",
      "id" : 325056515922862081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BILVLdOCIAEeOGg.jpg",
      "sizes" : [ {
        "h" : 530,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/4GTYP7SLGU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325058705672507392",
  "text" : "RT @MrJohnnyRyan: .@beatonna Harkonnen! A Vagrant http:\/\/t.co\/4GTYP7SLGU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kate Beaton",
        "screen_name" : "beatonna",
        "indices" : [ 1, 10 ],
        "id_str" : "36735522",
        "id" : 36735522
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MrJohnnyRyan\/status\/325056515914473474\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/4GTYP7SLGU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BILVLdOCIAEeOGg.jpg",
        "id_str" : "325056515922862081",
        "id" : 325056515922862081,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BILVLdOCIAEeOGg.jpg",
        "sizes" : [ {
          "h" : 530,
          "resize" : "fit",
          "w" : 554
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 554
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 554
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/4GTYP7SLGU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325056515914473474",
    "text" : ".@beatonna Harkonnen! A Vagrant http:\/\/t.co\/4GTYP7SLGU",
    "id" : 325056515914473474,
    "created_at" : "2013-04-19 01:21:27 +0000",
    "user" : {
      "name" : "Johnny Ryan",
      "screen_name" : "MrJohnnyRyan",
      "protected" : false,
      "id_str" : "189310742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1331643570\/34967_460274034151_839599151_6365190_639796_n_normal.jpg",
      "id" : 189310742,
      "verified" : false
    }
  },
  "id" : 325058705672507392,
  "created_at" : "2013-04-19 01:30:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/6xaRZaiGmZ",
      "expanded_url" : "http:\/\/flic.kr\/p\/eckURv",
      "display_url" : "flic.kr\/p\/eckURv"
    } ]
  },
  "geo" : { },
  "id_str" : "325037504841539585",
  "text" : "Just some spring clouds. http:\/\/t.co\/6xaRZaiGmZ",
  "id" : 325037504841539585,
  "created_at" : "2013-04-19 00:05:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/7woqiOsIls",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?feature=player_embedded&v=E6SCviG8PTI",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324989673917263873",
  "text" : "LEMONS?! UNACCEPTABLE!!!! https:\/\/t.co\/7woqiOsIls",
  "id" : 324989673917263873,
  "created_at" : "2013-04-18 20:55:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/exlAKmLa1v",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?&v=LORVfnFtcH0",
      "display_url" : "youtube.com\/watch?&v=LORVf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324977983817396224",
  "text" : "Holy shit: http:\/\/t.co\/exlAKmLa1v",
  "id" : 324977983817396224,
  "created_at" : "2013-04-18 20:09:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324954903317458944",
  "geo" : { },
  "id_str" : "324955247934058497",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette Cool. We have a similar thing at 37, might be time to standardize!",
  "id" : 324955247934058497,
  "in_reply_to_status_id" : 324954903317458944,
  "created_at" : "2013-04-18 18:39:03 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/JmPhg2ToE9",
      "expanded_url" : "http:\/\/github.com",
      "display_url" : "github.com"
    } ]
  },
  "in_reply_to_status_id_str" : "324952685612781568",
  "geo" : { },
  "id_str" : "324954690615922689",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette This looks great, are you guys using it on http:\/\/t.co\/JmPhg2ToE9 ?",
  "id" : 324954690615922689,
  "in_reply_to_status_id" : 324952685612781568,
  "created_at" : "2013-04-18 18:36:50 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324949360947388416",
  "geo" : { },
  "id_str" : "324949500282146818",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH More like \"I don't get it\", but then again, I never did.",
  "id" : 324949500282146818,
  "in_reply_to_status_id" : 324949360947388416,
  "created_at" : "2013-04-18 18:16:12 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "indices" : [ 3, 10 ],
      "id_str" : "668423",
      "id" : 668423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324948939583397889",
  "text" : "RT @mikeal: HTML5 didn\u2019t make your mobile app shitty, your developers did.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "324948750470615040",
    "text" : "HTML5 didn\u2019t make your mobile app shitty, your developers did.",
    "id" : 324948750470615040,
    "created_at" : "2013-04-18 18:13:14 +0000",
    "user" : {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "protected" : false,
      "id_str" : "668423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549609524038877184\/01oMFk1H_normal.png",
      "id" : 668423,
      "verified" : false
    }
  },
  "id" : 324948939583397889,
  "created_at" : "2013-04-18 18:13:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Gaebel \u272D",
      "screen_name" : "gryghostvisuals",
      "indices" : [ 0, 16 ],
      "id_str" : "218159376",
      "id" : 218159376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324931028508631041",
  "geo" : { },
  "id_str" : "324935619832868864",
  "in_reply_to_user_id" : 218159376,
  "text" : "@gryghostvisuals yep, have heard this a lot. Todos can have comments, and that mostly covers it.",
  "id" : 324935619832868864,
  "in_reply_to_status_id" : 324931028508631041,
  "created_at" : "2013-04-18 17:21:03 +0000",
  "in_reply_to_screen_name" : "gryghostvisuals",
  "in_reply_to_user_id_str" : "218159376",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324904669946204161",
  "geo" : { },
  "id_str" : "324905103867920386",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic Every day is the wrong day to wear any non-Boston sports gear in Boston.",
  "id" : 324905103867920386,
  "in_reply_to_status_id" : 324904669946204161,
  "created_at" : "2013-04-18 15:19:47 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rundle",
      "screen_name" : "flyosity",
      "indices" : [ 0, 9 ],
      "id_str" : "10545",
      "id" : 10545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324901436100059137",
  "geo" : { },
  "id_str" : "324901724739485697",
  "in_reply_to_user_id" : 10545,
  "text" : "@flyosity Thanks :) I'd love to see more apps do this.",
  "id" : 324901724739485697,
  "in_reply_to_status_id" : 324901436100059137,
  "created_at" : "2013-04-18 15:06:22 +0000",
  "in_reply_to_screen_name" : "flyosity",
  "in_reply_to_user_id_str" : "10545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rundle",
      "screen_name" : "flyosity",
      "indices" : [ 0, 9 ],
      "id_str" : "10545",
      "id" : 10545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/PNr2sqf4lP",
      "expanded_url" : "http:\/\/37svn.com\/3438",
      "display_url" : "37svn.com\/3438"
    } ]
  },
  "in_reply_to_status_id_str" : "324867082929963008",
  "geo" : { },
  "id_str" : "324900121957502978",
  "in_reply_to_user_id" : 10545,
  "text" : "@flyosity hey, have you seen http:\/\/t.co\/PNr2sqf4lP ?",
  "id" : 324900121957502978,
  "in_reply_to_status_id" : 324867082929963008,
  "created_at" : "2013-04-18 15:00:00 +0000",
  "in_reply_to_screen_name" : "flyosity",
  "in_reply_to_user_id_str" : "10545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324895458424156160",
  "geo" : { },
  "id_str" : "324895614645190656",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella same here. GLHF",
  "id" : 324895614645190656,
  "in_reply_to_status_id" : 324895458424156160,
  "created_at" : "2013-04-18 14:42:05 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324894783413825536",
  "geo" : { },
  "id_str" : "324895242895650816",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella what's the name? also, congrats again from another shit-picker-upper.",
  "id" : 324895242895650816,
  "in_reply_to_status_id" : 324894783413825536,
  "created_at" : "2013-04-18 14:40:36 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Williams",
      "screen_name" : "j_m_williams",
      "indices" : [ 0, 13 ],
      "id_str" : "16210953",
      "id" : 16210953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324890533359149057",
  "geo" : { },
  "id_str" : "324893144510504962",
  "in_reply_to_user_id" : 16210953,
  "text" : "@j_m_williams also I bet many don't have as flexible a job...:\/",
  "id" : 324893144510504962,
  "in_reply_to_status_id" : 324890533359149057,
  "created_at" : "2013-04-18 14:32:16 +0000",
  "in_reply_to_screen_name" : "j_m_williams",
  "in_reply_to_user_id_str" : "16210953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sheelah Brennan",
      "screen_name" : "sheelah_b",
      "indices" : [ 3, 13 ],
      "id_str" : "711040375",
      "id" : 711040375
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 25, 40 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324738213379964928",
  "text" : "RT @sheelah_b: Love it.. @nickelcityruby, a conference in my hometown.  Go see Niagara Falls, only a 30-min drive, and have Duff's Buffa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 10, 25 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "324608881428946944",
    "text" : "Love it.. @nickelcityruby, a conference in my hometown.  Go see Niagara Falls, only a 30-min drive, and have Duff's Buffalo wings :)",
    "id" : 324608881428946944,
    "created_at" : "2013-04-17 19:42:42 +0000",
    "user" : {
      "name" : "Sheelah Brennan",
      "screen_name" : "sheelah_b",
      "protected" : false,
      "id_str" : "711040375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510561068268003328\/SQVsVV46_normal.jpeg",
      "id" : 711040375,
      "verified" : false
    }
  },
  "id" : 324738213379964928,
  "created_at" : "2013-04-18 04:16:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324713787359911937",
  "geo" : { },
  "id_str" : "324716459232206848",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking I also liked how the intro video bragged about how rich the founder is",
  "id" : 324716459232206848,
  "in_reply_to_status_id" : 324713787359911937,
  "created_at" : "2013-04-18 02:50:11 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324712233080856577",
  "geo" : { },
  "id_str" : "324712951942639620",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking This has to be a scam. BUY GOLD! BUY COINS! VIRAL!",
  "id" : 324712951942639620,
  "in_reply_to_status_id" : 324712233080856577,
  "created_at" : "2013-04-18 02:36:15 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324711803005321216",
  "geo" : { },
  "id_str" : "324712049273872384",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden yeah i've had some shitty ones and they end up, well, being shitty.",
  "id" : 324712049273872384,
  "in_reply_to_status_id" : 324711803005321216,
  "created_at" : "2013-04-18 02:32:40 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324711272002248704",
  "text" : "Latest revolights are $229 + $25 shipping, and don't say when they'll ship. :(",
  "id" : 324711272002248704,
  "created_at" : "2013-04-18 02:29:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/WQxrUW4u1I",
      "expanded_url" : "http:\/\/revolights.com\/#lighting",
      "display_url" : "revolights.com\/#lighting"
    } ]
  },
  "geo" : { },
  "id_str" : "324696013136859136",
  "text" : "Anyone tried out or seen Revolights? They look awesome. http:\/\/t.co\/WQxrUW4u1I",
  "id" : 324696013136859136,
  "created_at" : "2013-04-18 01:28:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/oamj9UGUe6",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=HrIeP798hiQ",
      "display_url" : "youtube.com\/watch?v=HrIeP7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324681151342055424",
  "text" : "Current status: http:\/\/t.co\/oamj9UGUe6",
  "id" : 324681151342055424,
  "created_at" : "2013-04-18 00:29:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/rQBi2A9TOd",
      "expanded_url" : "http:\/\/www.daedtech.com\/how-developers-stop-learning-rise-of-the-expert-beginner",
      "display_url" : "daedtech.com\/how-developers\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324678820152086531",
  "text" : "\"The only thing stopping them [is] a combination of peer review and interaction with the development community\" http:\/\/t.co\/rQBi2A9TOd",
  "id" : 324678820152086531,
  "created_at" : "2013-04-18 00:20:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/utLlyfbs5K",
      "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=5567412",
      "display_url" : "news.ycombinator.com\/item?id=5567412"
    } ]
  },
  "geo" : { },
  "id_str" : "324677203134672896",
  "text" : "Today's piece of HN wisdom: https:\/\/t.co\/utLlyfbs5K",
  "id" : 324677203134672896,
  "created_at" : "2013-04-18 00:14:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/gVM2UUKjZR",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/ac867be7aefc9432a42074fc5195902d\/tumblr_mlcoj9RTsq1qj1cg2o1_400.jpg",
      "display_url" : "24.media.tumblr.com\/ac867be7aefc94\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324668982038773760",
  "text" : "Dwarf Fortress in one image: http:\/\/t.co\/gVM2UUKjZR",
  "id" : 324668982038773760,
  "created_at" : "2013-04-17 23:41:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Rotman",
      "screen_name" : "LaurenfRotman",
      "indices" : [ 0, 14 ],
      "id_str" : "24725628",
      "id" : 24725628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324626308812390400",
  "geo" : { },
  "id_str" : "324626837886083073",
  "in_reply_to_user_id" : 24725628,
  "text" : "@LaurenfRotman Yep, sure is!",
  "id" : 324626837886083073,
  "in_reply_to_status_id" : 324626308812390400,
  "created_at" : "2013-04-17 20:54:04 +0000",
  "in_reply_to_screen_name" : "LaurenfRotman",
  "in_reply_to_user_id_str" : "24725628",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/bVDEXkt7Nz",
      "expanded_url" : "http:\/\/blog.priceonomics.com\/post\/48216173465\/the-business-of-phish",
      "display_url" : "blog.priceonomics.com\/post\/482161734\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324625315240488961",
  "text" : "The Business of Phish: http:\/\/t.co\/bVDEXkt7Nz",
  "id" : 324625315240488961,
  "created_at" : "2013-04-17 20:48:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 44, 59 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324619155573706754",
  "geo" : { },
  "id_str" : "324620324446556160",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms Agreed re: fireline. Hoping to run @nickelcityruby in a similar family-friendly way.",
  "id" : 324620324446556160,
  "in_reply_to_status_id" : 324619155573706754,
  "created_at" : "2013-04-17 20:28:11 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 3, 11 ],
      "id_str" : "15947489",
      "id" : 15947489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/uWKbZ0jLya",
      "expanded_url" : "http:\/\/goo.gl\/87GSJ",
      "display_url" : "goo.gl\/87GSJ"
    } ]
  },
  "geo" : { },
  "id_str" : "324620183085936640",
  "text" : "RT @sgharms: Blog:  Spring Break and Tech Conferences:  http:\/\/t.co\/uWKbZ0jLya",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/uWKbZ0jLya",
        "expanded_url" : "http:\/\/goo.gl\/87GSJ",
        "display_url" : "goo.gl\/87GSJ"
      } ]
    },
    "geo" : { },
    "id_str" : "324619155573706754",
    "text" : "Blog:  Spring Break and Tech Conferences:  http:\/\/t.co\/uWKbZ0jLya",
    "id" : 324619155573706754,
    "created_at" : "2013-04-17 20:23:32 +0000",
    "user" : {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "protected" : false,
      "id_str" : "15947489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443827037573115904\/j6Jp8jht_normal.jpeg",
      "id" : 15947489,
      "verified" : false
    }
  },
  "id" : 324620183085936640,
  "created_at" : "2013-04-17 20:27:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324606261138178048",
  "geo" : { },
  "id_str" : "324606488196812800",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog Awesome!",
  "id" : 324606488196812800,
  "in_reply_to_status_id" : 324606261138178048,
  "created_at" : "2013-04-17 19:33:12 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Campbell",
      "screen_name" : "paulca",
      "indices" : [ 0, 7 ],
      "id_str" : "815973",
      "id" : 815973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324599427174113280",
  "geo" : { },
  "id_str" : "324604299567058946",
  "in_reply_to_user_id" : 815973,
  "text" : "@paulca We had a quick \"oh shit\" moment about this, luckily we're exempt to this in our state.",
  "id" : 324604299567058946,
  "in_reply_to_status_id" : 324599427174113280,
  "created_at" : "2013-04-17 19:24:30 +0000",
  "in_reply_to_screen_name" : "paulca",
  "in_reply_to_user_id_str" : "815973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Campbell",
      "screen_name" : "paulca",
      "indices" : [ 0, 7 ],
      "id_str" : "815973",
      "id" : 815973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324599427174113280",
  "geo" : { },
  "id_str" : "324604183686811649",
  "in_reply_to_user_id" : 815973,
  "text" : "@paulca Something to consider for future signups...maybe have a blurb on \"Does your state require you to charge taxes?\"",
  "id" : 324604183686811649,
  "in_reply_to_status_id" : 324599427174113280,
  "created_at" : "2013-04-17 19:24:02 +0000",
  "in_reply_to_screen_name" : "paulca",
  "in_reply_to_user_id_str" : "815973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Winn",
      "screen_name" : "tony_winn",
      "indices" : [ 0, 10 ],
      "id_str" : "14948226",
      "id" : 14948226
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 11, 16 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324556655972978689",
  "geo" : { },
  "id_str" : "324560461766987776",
  "in_reply_to_user_id" : 14948226,
  "text" : "@tony_winn @r00k Seriously changed how I use vim. Fuck yeah!",
  "id" : 324560461766987776,
  "in_reply_to_status_id" : 324556655972978689,
  "created_at" : "2013-04-17 16:30:18 +0000",
  "in_reply_to_screen_name" : "tony_winn",
  "in_reply_to_user_id_str" : "14948226",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "indices" : [ 0, 12 ],
      "id_str" : "588743",
      "id" : 588743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324558176789884929",
  "geo" : { },
  "id_str" : "324558754181967874",
  "in_reply_to_user_id" : 588743,
  "text" : "@antiheroine A hoodie or sweater. No seriously.",
  "id" : 324558754181967874,
  "in_reply_to_status_id" : 324558176789884929,
  "created_at" : "2013-04-17 16:23:31 +0000",
  "in_reply_to_screen_name" : "antiheroine",
  "in_reply_to_user_id_str" : "588743",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "indices" : [ 0, 13 ],
      "id_str" : "16275936",
      "id" : 16275936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/RRguAXnDfs",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food\/",
      "display_url" : "coworkbuffalo.com\/food\/"
    } ]
  },
  "in_reply_to_status_id_str" : "324548800574279681",
  "geo" : { },
  "id_str" : "324549832394043392",
  "in_reply_to_user_id" : 16275936,
  "text" : "@rachbarnhart as an RIT alum, this is sad given the amount we have here and Buffalo... http:\/\/t.co\/RRguAXnDfs",
  "id" : 324549832394043392,
  "in_reply_to_status_id" : 324548800574279681,
  "created_at" : "2013-04-17 15:48:04 +0000",
  "in_reply_to_screen_name" : "rachbarnhart",
  "in_reply_to_user_id_str" : "16275936",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 3, 11 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/l3TVEingTb",
      "expanded_url" : "http:\/\/www.mikeperham.com\/2013\/04\/17\/board-games-and-beverages-at-railsconf-2013\/",
      "display_url" : "mikeperham.com\/2013\/04\/17\/boa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324536634609659904",
  "text" : "RT @mperham: You are invited to Board Games and Beverages at Railsconf 2013: http:\/\/t.co\/l3TVEingTb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/l3TVEingTb",
        "expanded_url" : "http:\/\/www.mikeperham.com\/2013\/04\/17\/board-games-and-beverages-at-railsconf-2013\/",
        "display_url" : "mikeperham.com\/2013\/04\/17\/boa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "324536468112560129",
    "text" : "You are invited to Board Games and Beverages at Railsconf 2013: http:\/\/t.co\/l3TVEingTb",
    "id" : 324536468112560129,
    "created_at" : "2013-04-17 14:54:58 +0000",
    "user" : {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "protected" : false,
      "id_str" : "14060922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519271188569128960\/i2t9GfcA_normal.jpeg",
      "id" : 14060922,
      "verified" : false
    }
  },
  "id" : 324536634609659904,
  "created_at" : "2013-04-17 14:55:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324490397860626433",
  "geo" : { },
  "id_str" : "324515941960536065",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j oh no :(",
  "id" : 324515941960536065,
  "in_reply_to_status_id" : 324490397860626433,
  "created_at" : "2013-04-17 13:33:24 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Menard",
      "screen_name" : "mark_menard",
      "indices" : [ 3, 15 ],
      "id_str" : "13168222",
      "id" : 13168222
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 38, 53 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324515466850758658",
  "text" : "RT @mark_menard: I just signed up for @nickelcityruby. It's going to be an awesome time. Ignite event, 2 days of talks, and a code retreat.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 21, 36 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "324514348817055744",
    "text" : "I just signed up for @nickelcityruby. It's going to be an awesome time. Ignite event, 2 days of talks, and a code retreat.",
    "id" : 324514348817055744,
    "created_at" : "2013-04-17 13:27:04 +0000",
    "user" : {
      "name" : "Mark Menard",
      "screen_name" : "mark_menard",
      "protected" : false,
      "id_str" : "13168222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444487338647769088\/bXO_JEA6_normal.jpeg",
      "id" : 13168222,
      "verified" : false
    }
  },
  "id" : 324515466850758658,
  "created_at" : "2013-04-17 13:31:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 9, 24 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324419423735803904",
  "geo" : { },
  "id_str" : "324505778268536833",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety @nickelcityruby evening for sure. Exact time for sure yet.",
  "id" : 324505778268536833,
  "in_reply_to_status_id" : 324419423735803904,
  "created_at" : "2013-04-17 12:53:01 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James O'Leary",
      "screen_name" : "jpohh",
      "indices" : [ 0, 6 ],
      "id_str" : "14174759",
      "id" : 14174759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324377271047696384",
  "geo" : { },
  "id_str" : "324378687887798273",
  "in_reply_to_user_id" : 14174759,
  "text" : "@jpohh $$$$",
  "id" : 324378687887798273,
  "in_reply_to_status_id" : 324377271047696384,
  "created_at" : "2013-04-17 04:28:00 +0000",
  "in_reply_to_screen_name" : "jpohh",
  "in_reply_to_user_id_str" : "14174759",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 10, 25 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 89, 100 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324339818794479617",
  "geo" : { },
  "id_str" : "324340045945372672",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn @nickelcityruby it\u2019s TBA right now, but will be the night before the conf. \/cc @kevinpurdy",
  "id" : 324340045945372672,
  "in_reply_to_status_id" : 324339818794479617,
  "created_at" : "2013-04-17 01:54:27 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324339605677694976",
  "geo" : { },
  "id_str" : "324339658253279232",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy RHOMBUS!",
  "id" : 324339658253279232,
  "in_reply_to_status_id" : 324339605677694976,
  "created_at" : "2013-04-17 01:52:55 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike susz",
      "screen_name" : "mikesusz",
      "indices" : [ 0, 9 ],
      "id_str" : "14531472",
      "id" : 14531472
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 10, 25 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324334387749609472",
  "geo" : { },
  "id_str" : "324338406253531136",
  "in_reply_to_user_id" : 14531472,
  "text" : "@mikesusz @nickelcityruby woot!!",
  "id" : 324338406253531136,
  "in_reply_to_status_id" : 324334387749609472,
  "created_at" : "2013-04-17 01:47:56 +0000",
  "in_reply_to_screen_name" : "mikesusz",
  "in_reply_to_user_id_str" : "14531472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike susz",
      "screen_name" : "mikesusz",
      "indices" : [ 3, 12 ],
      "id_str" : "14531472",
      "id" : 14531472
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 34, 49 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324338342600794112",
  "text" : "RT @mikesusz: yay! registered for @nickelcityruby a Ruby conference in Buffalo, NY in September. if you make the trip, i\u2019ll take you out ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 20, 35 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "324334387749609472",
    "text" : "yay! registered for @nickelcityruby a Ruby conference in Buffalo, NY in September. if you make the trip, i\u2019ll take you out for wings &amp; beer.",
    "id" : 324334387749609472,
    "created_at" : "2013-04-17 01:31:58 +0000",
    "user" : {
      "name" : "mike susz",
      "screen_name" : "mikesusz",
      "protected" : false,
      "id_str" : "14531472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479668081800011776\/ZT23cqOn_normal.jpeg",
      "id" : 14531472,
      "verified" : false
    }
  },
  "id" : 324338342600794112,
  "created_at" : "2013-04-17 01:47:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324335815058665472",
  "geo" : { },
  "id_str" : "324336022701887489",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham haha totally wasn\u2019t her fault. Unicorns gonna unicorn",
  "id" : 324336022701887489,
  "in_reply_to_status_id" : 324335815058665472,
  "created_at" : "2013-04-17 01:38:28 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324333797321609216",
  "geo" : { },
  "id_str" : "324335118628040706",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik her first PR! And I broke the site when deploying it too.",
  "id" : 324335118628040706,
  "in_reply_to_status_id" : 324333797321609216,
  "created_at" : "2013-04-17 01:34:52 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 3, 10 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 73, 83 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/VEXa8wdmYB",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/Wb1KI7gyoV",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/commit\/4a10370f6efc73db58f1079346ed000cd02ce9be",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324335025845833728",
  "text" : "RT @sferik: Awesome to see patches to http:\/\/t.co\/VEXa8wdmYB coming from @aquaranto: https:\/\/t.co\/Wb1KI7gyoV. That\u2019s true love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 61, 71 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/VEXa8wdmYB",
        "expanded_url" : "http:\/\/rubygems.org",
        "display_url" : "rubygems.org"
      }, {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/Wb1KI7gyoV",
        "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/commit\/4a10370f6efc73db58f1079346ed000cd02ce9be",
        "display_url" : "github.com\/rubygems\/rubyg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "324333797321609216",
    "text" : "Awesome to see patches to http:\/\/t.co\/VEXa8wdmYB coming from @aquaranto: https:\/\/t.co\/Wb1KI7gyoV. That\u2019s true love.",
    "id" : 324333797321609216,
    "created_at" : "2013-04-17 01:29:37 +0000",
    "user" : {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "protected" : false,
      "id_str" : "7505382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567932260847206401\/ErQwT5za_normal.jpeg",
      "id" : 7505382,
      "verified" : false
    }
  },
  "id" : 324335025845833728,
  "created_at" : "2013-04-17 01:34:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/33aYAp8SaM",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "324326283611865088",
  "text" : "Unicorn needed a full restart for http:\/\/t.co\/33aYAp8SaM. Sorry about that everyone.",
  "id" : 324326283611865088,
  "created_at" : "2013-04-17 00:59:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Lassoff",
      "screen_name" : "jof",
      "indices" : [ 0, 4 ],
      "id_str" : "11623",
      "id" : 11623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324324489917775872",
  "geo" : { },
  "id_str" : "324324902633082881",
  "in_reply_to_user_id" : 11623,
  "text" : "@jof gem hosting is not impacted, just the rails frontend is down.",
  "id" : 324324902633082881,
  "in_reply_to_status_id" : 324324489917775872,
  "created_at" : "2013-04-17 00:54:17 +0000",
  "in_reply_to_screen_name" : "jof",
  "in_reply_to_user_id_str" : "11623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/33aYAp8SaM",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "324324291602694145",
  "text" : "Deployed http:\/\/t.co\/33aYAp8SaM and we're having some issues. Sorry everyone :(",
  "id" : 324324291602694145,
  "created_at" : "2013-04-17 00:51:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 65, 78 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324297573739397122",
  "text" : "What was that site with the low hanging github issues fruit? \/cc @steveklabnik",
  "id" : 324297573739397122,
  "created_at" : "2013-04-16 23:05:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 3, 14 ],
      "id_str" : "1742",
      "id" : 1742
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 25, 35 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/hsGnrSOHBr",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Matching_gift",
      "display_url" : "en.wikipedia.org\/wiki\/Matching_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324286685049417729",
  "text" : "RT @trevorturk: Awesome! @37signals is matching charitable gifts now! http:\/\/t.co\/hsGnrSOHBr -- ask your employer if they would consider ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 9, 19 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/hsGnrSOHBr",
        "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Matching_gift",
        "display_url" : "en.wikipedia.org\/wiki\/Matching_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "324262918889799681",
    "text" : "Awesome! @37signals is matching charitable gifts now! http:\/\/t.co\/hsGnrSOHBr -- ask your employer if they would consider doing the same?",
    "id" : 324262918889799681,
    "created_at" : "2013-04-16 20:47:59 +0000",
    "user" : {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "protected" : false,
      "id_str" : "1742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/59730474\/costco_normal.png",
      "id" : 1742,
      "verified" : false
    }
  },
  "id" : 324286685049417729,
  "created_at" : "2013-04-16 22:22:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 7, 22 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324278977667686400",
  "geo" : { },
  "id_str" : "324280579514314752",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik @nickelcityruby Woot!",
  "id" : 324280579514314752,
  "in_reply_to_status_id" : 324278977667686400,
  "created_at" : "2013-04-16 21:58:09 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Woods",
      "screen_name" : "bryanwoods",
      "indices" : [ 0, 11 ],
      "id_str" : "11857402",
      "id" : 11857402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324277541433139201",
  "geo" : { },
  "id_str" : "324278084645822466",
  "in_reply_to_user_id" : 11857402,
  "text" : "@bryanwoods Great! That was definitely a huge concern for us. Hopefully we'll see you there?",
  "id" : 324278084645822466,
  "in_reply_to_status_id" : 324277541433139201,
  "created_at" : "2013-04-16 21:48:14 +0000",
  "in_reply_to_screen_name" : "bryanwoods",
  "in_reply_to_user_id_str" : "11857402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carina C. Zona",
      "screen_name" : "cczona",
      "indices" : [ 0, 7 ],
      "id_str" : "39617149",
      "id" : 39617149
    }, {
      "name" : "Golden Gate RubyConf",
      "screen_name" : "gogaruco",
      "indices" : [ 8, 17 ],
      "id_str" : "19278778",
      "id" : 19278778
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 18, 33 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324272763126833152",
  "geo" : { },
  "id_str" : "324277704692224000",
  "in_reply_to_user_id" : 39617149,
  "text" : "@cczona @gogaruco @nickelcityruby yes, sorry - there's a time limit before the weather is a factor here. we almost had to push to 2014.",
  "id" : 324277704692224000,
  "in_reply_to_status_id" : 324272763126833152,
  "created_at" : "2013-04-16 21:46:44 +0000",
  "in_reply_to_screen_name" : "cczona",
  "in_reply_to_user_id_str" : "39617149",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tito",
      "screen_name" : "useTito",
      "indices" : [ 43, 51 ],
      "id_str" : "741445453",
      "id" : 741445453
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 97, 112 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324277070219866112",
  "text" : "Just wanted to say, big thanks to everyone @useTito for helping us get the registration site for @nickelcityruby ready. It's great!",
  "id" : 324277070219866112,
  "created_at" : "2013-04-16 21:44:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324270436164722688",
  "geo" : { },
  "id_str" : "324274946761183232",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn Great! ATTEND!",
  "id" : 324274946761183232,
  "in_reply_to_status_id" : 324270436164722688,
  "created_at" : "2013-04-16 21:35:46 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324252484187078656",
  "geo" : { },
  "id_str" : "324267203086147584",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz thank you for selling a product for $ instead of nothing",
  "id" : 324267203086147584,
  "in_reply_to_status_id" : 324252484187078656,
  "created_at" : "2013-04-16 21:05:00 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate West",
      "screen_name" : "nate_west",
      "indices" : [ 0, 10 ],
      "id_str" : "942661",
      "id" : 942661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324256588145762304",
  "geo" : { },
  "id_str" : "324256840009543680",
  "in_reply_to_user_id" : 942661,
  "text" : "@nate_west ~5 hours depending on bridge traffic. Bring your passport!",
  "id" : 324256840009543680,
  "in_reply_to_status_id" : 324256588145762304,
  "created_at" : "2013-04-16 20:23:49 +0000",
  "in_reply_to_screen_name" : "nate_west",
  "in_reply_to_user_id_str" : "942661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate West",
      "screen_name" : "nate_west",
      "indices" : [ 0, 10 ],
      "id_str" : "942661",
      "id" : 942661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324253015441821699",
  "geo" : { },
  "id_str" : "324255885994106880",
  "in_reply_to_user_id" : 942661,
  "text" : "@nate_west I won't have any time to speak thanks to hosting...but I will gladly talk about this over drinks at the conf!",
  "id" : 324255885994106880,
  "in_reply_to_status_id" : 324253015441821699,
  "created_at" : "2013-04-16 20:20:02 +0000",
  "in_reply_to_screen_name" : "nate_west",
  "in_reply_to_user_id_str" : "942661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Murphy",
      "screen_name" : "wfm",
      "indices" : [ 3, 7 ],
      "id_str" : "6655452",
      "id" : 6655452
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 22, 37 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/c5NKIUc1Hh",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "324252539598024704",
  "text" : "RT @wfm: I'm going to @nickelcityruby in September. Join in the fun: http:\/\/t.co\/c5NKIUc1Hh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 13, 28 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/c5NKIUc1Hh",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "324251392317472768",
    "text" : "I'm going to @nickelcityruby in September. Join in the fun: http:\/\/t.co\/c5NKIUc1Hh",
    "id" : 324251392317472768,
    "created_at" : "2013-04-16 20:02:10 +0000",
    "user" : {
      "name" : "Bill Murphy",
      "screen_name" : "wfm",
      "protected" : false,
      "id_str" : "6655452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504446539700264961\/uvFpAub3_normal.jpeg",
      "id" : 6655452,
      "verified" : false
    }
  },
  "id" : 324252539598024704,
  "created_at" : "2013-04-16 20:06:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324245156922531840",
  "geo" : { },
  "id_str" : "324245412494077952",
  "in_reply_to_user_id" : 1130185466,
  "text" : "@erinbrownUF right now I'm open to anything. Just amended to CFP to mention this.",
  "id" : 324245412494077952,
  "in_reply_to_status_id" : 324245156922531840,
  "created_at" : "2013-04-16 19:38:25 +0000",
  "in_reply_to_screen_name" : "thegeekprof",
  "in_reply_to_user_id_str" : "1130185466",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324245161146195969",
  "text" : "@juliepagano sure! I'll make a note of that.",
  "id" : 324245161146195969,
  "created_at" : "2013-04-16 19:37:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324237814420086785",
  "geo" : { },
  "id_str" : "324238097359454208",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman You are. I hope? :)",
  "id" : 324238097359454208,
  "in_reply_to_status_id" : 324237814420086785,
  "created_at" : "2013-04-16 19:09:21 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/eXldmt1AF0",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "324237472563335168",
  "text" : "RT @nickelcityruby: CFP and Registration are now open! http:\/\/t.co\/eXldmt1AF0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/eXldmt1AF0",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "324237319269912576",
    "text" : "CFP and Registration are now open! http:\/\/t.co\/eXldmt1AF0",
    "id" : 324237319269912576,
    "created_at" : "2013-04-16 19:06:15 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 324237472563335168,
  "created_at" : "2013-04-16 19:06:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 39, 54 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "324236583068921856",
  "text" : "We'd like to invite you to Buffalo for @nickelcityruby: http:\/\/t.co\/3UAdoKZw7Q CFP + Registration are open!",
  "id" : 324236583068921856,
  "created_at" : "2013-04-16 19:03:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 60, 70 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/WwQ1zH3UKb",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/rails\/comments\/1cgd0m\/how_to_become_a_junior_rails_developer\/c9gc4t8",
      "display_url" : "reddit.com\/r\/rails\/commen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324190950786207745",
  "text" : "The best part of the Ruby community is how inclusive it is. @aquaranto goes over how she became a developer: http:\/\/t.co\/WwQ1zH3UKb",
  "id" : 324190950786207745,
  "created_at" : "2013-04-16 16:02:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill Terreri Ramos",
      "screen_name" : "jillterreri",
      "indices" : [ 3, 15 ],
      "id_str" : "46209505",
      "id" : 46209505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/jQLcCfdZLm",
      "expanded_url" : "http:\/\/blogs.buffalonews.com\/politics_now\/2013\/04\/today-in-city-hall-niagara-square-gets-a-makeover.html",
      "display_url" : "blogs.buffalonews.com\/politics_now\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324175573876350976",
  "text" : "RT @jillterreri: Good news for pedestrians around Niagara Square: http:\/\/t.co\/jQLcCfdZLm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/jQLcCfdZLm",
        "expanded_url" : "http:\/\/blogs.buffalonews.com\/politics_now\/2013\/04\/today-in-city-hall-niagara-square-gets-a-makeover.html",
        "display_url" : "blogs.buffalonews.com\/politics_now\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "324174443821817856",
    "text" : "Good news for pedestrians around Niagara Square: http:\/\/t.co\/jQLcCfdZLm",
    "id" : 324174443821817856,
    "created_at" : "2013-04-16 14:56:24 +0000",
    "user" : {
      "name" : "Jill Terreri Ramos",
      "screen_name" : "jillterreri",
      "protected" : false,
      "id_str" : "46209505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1240296962\/Terreri__Jill_normal.jpg",
      "id" : 46209505,
      "verified" : false
    }
  },
  "id" : 324175573876350976,
  "created_at" : "2013-04-16 15:00:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324045547201773568",
  "text" : "2am in the middle of a productive streak is not the best time for the Internet to die :(",
  "id" : 324045547201773568,
  "created_at" : "2013-04-16 06:24:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Suttles",
      "screen_name" : "jlsuttles",
      "indices" : [ 0, 10 ],
      "id_str" : "21170138",
      "id" : 21170138
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 11, 24 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324020518053376000",
  "geo" : { },
  "id_str" : "324021147702280192",
  "in_reply_to_user_id" : 21170138,
  "text" : "@jlsuttles @steveklabnik oh my glob you guys.",
  "id" : 324021147702280192,
  "in_reply_to_status_id" : 324020518053376000,
  "created_at" : "2013-04-16 04:47:16 +0000",
  "in_reply_to_screen_name" : "jlsuttles",
  "in_reply_to_user_id_str" : "21170138",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/SUkIDkJjBZ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ASO_zypdnsQ",
      "display_url" : "youtube.com\/watch?v=ASO_zy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324020247835340800",
  "text" : "PSY is kind of a jerk. http:\/\/t.co\/SUkIDkJjBZ",
  "id" : 324020247835340800,
  "created_at" : "2013-04-16 04:43:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 0, 9 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/AkpOU3u5D1",
      "expanded_url" : "https:\/\/twitter.com\/MikeClattenburg\/status\/323899855678345216",
      "display_url" : "twitter.com\/MikeClattenbur\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "324017730917384192",
  "geo" : { },
  "id_str" : "324019107546689537",
  "in_reply_to_user_id" : 9462972,
  "text" : "@bitsweat related news, Phil passed away :( https:\/\/t.co\/AkpOU3u5D1",
  "id" : 324019107546689537,
  "in_reply_to_status_id" : 324017730917384192,
  "created_at" : "2013-04-16 04:39:09 +0000",
  "in_reply_to_screen_name" : "bitsweat",
  "in_reply_to_user_id_str" : "9462972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/PMXKAyfwmV",
      "expanded_url" : "http:\/\/instagram.com\/p\/YDwHCXgSYN\/",
      "display_url" : "instagram.com\/p\/YDwHCXgSYN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "324016366258642944",
  "text" : "We'd better haul in the jib before it gets covered in shit. There's going to be a new Trailer Park Boys movie! http:\/\/t.co\/PMXKAyfwmV",
  "id" : 324016366258642944,
  "created_at" : "2013-04-16 04:28:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 0, 13 ],
      "id_str" : "23820237",
      "id" : 23820237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323958916159508480",
  "geo" : { },
  "id_str" : "323959967512154112",
  "in_reply_to_user_id" : 23820237,
  "text" : "@IanCAnderson see!",
  "id" : 323959967512154112,
  "in_reply_to_status_id" : 323958916159508480,
  "created_at" : "2013-04-16 00:44:09 +0000",
  "in_reply_to_screen_name" : "IanCAnderson",
  "in_reply_to_user_id_str" : "23820237",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323880767082074112",
  "text" : "Holy shit, I hope everyone I know in Boston is safe.",
  "id" : 323880767082074112,
  "created_at" : "2013-04-15 19:29:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Bair",
      "screen_name" : "adambair",
      "indices" : [ 0, 9 ],
      "id_str" : "10647472",
      "id" : 10647472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323865287780864000",
  "geo" : { },
  "id_str" : "323865451077713920",
  "in_reply_to_user_id" : 10647472,
  "text" : "@adambair git commit -am \"stuff\"",
  "id" : 323865451077713920,
  "in_reply_to_status_id" : 323865287780864000,
  "created_at" : "2013-04-15 18:28:35 +0000",
  "in_reply_to_screen_name" : "adambair",
  "in_reply_to_user_id_str" : "10647472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/wvelFd3xke",
      "expanded_url" : "http:\/\/www.penny-arcade.com\/report\/article\/why-your-games-are-made-by-childless-31-year-old-white-men-and-how-one-stud",
      "display_url" : "penny-arcade.com\/report\/article\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "323856442249601024",
  "text" : "\"Why your games are made by childless, 31 year old white men\"\n http:\/\/t.co\/wvelFd3xke",
  "id" : 323856442249601024,
  "created_at" : "2013-04-15 17:52:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roaming Buffalo",
      "screen_name" : "RoamingBuffalo1",
      "indices" : [ 38, 54 ],
      "id_str" : "195824825",
      "id" : 195824825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/4zJAoqn2Es",
      "expanded_url" : "http:\/\/flic.kr\/p\/ebx67X",
      "display_url" : "flic.kr\/p\/ebx67X"
    } ]
  },
  "geo" : { },
  "id_str" : "323851534502871041",
  "text" : "Biked down to the waterfront for some @RoamingBuffalo1. First good bike weather day in a while! http:\/\/t.co\/4zJAoqn2Es",
  "id" : 323851534502871041,
  "created_at" : "2013-04-15 17:33:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Loupasakis",
      "screen_name" : "andy_lupo",
      "indices" : [ 0, 10 ],
      "id_str" : "36675716",
      "id" : 36675716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323802105699774465",
  "geo" : { },
  "id_str" : "323802311686242304",
  "in_reply_to_user_id" : 36675716,
  "text" : "@andy_lupo I haven\u2019t deployed or merged anything in a while. What\u2019s wrong?",
  "id" : 323802311686242304,
  "in_reply_to_status_id" : 323802105699774465,
  "created_at" : "2013-04-15 14:17:41 +0000",
  "in_reply_to_screen_name" : "andy_lupo",
  "in_reply_to_user_id_str" : "36675716",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 35, 50 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/EvXjcxY8Dn",
      "expanded_url" : "http:\/\/www.bostonglobe.com\/lifestyle\/travel\/2013\/04\/13\/buffalo-architectural-gems-get-facelift\/tg5eUu7txLksUxYrUwNXTO\/story.html",
      "display_url" : "bostonglobe.com\/lifestyle\/trav\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "323801432052625408",
  "text" : "Another big reason I\u2019m excited for @nickelcityruby: we\u2019re next door to this! http:\/\/t.co\/EvXjcxY8Dn",
  "id" : 323801432052625408,
  "created_at" : "2013-04-15 14:14:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Skud Bayley",
      "screen_name" : "Skud",
      "indices" : [ 0, 5 ],
      "id_str" : "823980",
      "id" : 823980
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 6, 17 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323654281649602561",
  "geo" : { },
  "id_str" : "323656183217020928",
  "in_reply_to_user_id" : 823980,
  "text" : "@Skud @ashedryden yep, all attributed. it\u2019s great that I could just fork it and modify. Hadn\u2019t heard of it before the Pycon incident.",
  "id" : 323656183217020928,
  "in_reply_to_status_id" : 323654281649602561,
  "created_at" : "2013-04-15 04:37:01 +0000",
  "in_reply_to_screen_name" : "Skud",
  "in_reply_to_user_id_str" : "823980",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323651281052921856",
  "geo" : { },
  "id_str" : "323652056651030528",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense I really hope the new WoW TCG game isn\u2019t like this. :\/ just let me play! Why is that so hard?",
  "id" : 323652056651030528,
  "in_reply_to_status_id" : 323651281052921856,
  "created_at" : "2013-04-15 04:20:38 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323651281052921856",
  "geo" : { },
  "id_str" : "323651421788590082",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense played one match and got destroyed. Just not fun for me, sorry :(",
  "id" : 323651421788590082,
  "in_reply_to_status_id" : 323651281052921856,
  "created_at" : "2013-04-15 04:18:06 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 83, 92 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/323651004161748992\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/hThEmfGjKU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BH3W356CcAAviCC.png",
      "id_str" : "323651004165943296",
      "id" : 323651004165943296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BH3W356CcAAviCC.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hThEmfGjKU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323651004161748992",
  "text" : "This is pretty much bullshit :( (have to pay to continue to play) uninstalled. \/cc @mittense http:\/\/t.co\/hThEmfGjKU",
  "id" : 323651004161748992,
  "created_at" : "2013-04-15 04:16:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "indices" : [ 3, 16 ],
      "id_str" : "29200620",
      "id" : 29200620
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 37, 52 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323618120537366529",
  "text" : "RT @TheOtherZach: I am so happy that @nickelcityruby is coming this September. There are more and more green shoots all the time in my h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 19, 34 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "323616716636688384",
    "text" : "I am so happy that @nickelcityruby is coming this September. There are more and more green shoots all the time in my home state.",
    "id" : 323616716636688384,
    "created_at" : "2013-04-15 02:00:12 +0000",
    "user" : {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "protected" : false,
      "id_str" : "29200620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427580633745854465\/Oo8wowKC_normal.png",
      "id" : 29200620,
      "verified" : false
    }
  },
  "id" : 323618120537366529,
  "created_at" : "2013-04-15 02:05:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323618040661028868",
  "text" : "@juliepagano Yeah, I'll be discussing this first thing each morning.",
  "id" : 323618040661028868,
  "created_at" : "2013-04-15 02:05:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 0, 7 ],
      "id_str" : "34953",
      "id" : 34953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323615891969417217",
  "geo" : { },
  "id_str" : "323617206946648065",
  "in_reply_to_user_id" : 34953,
  "text" : "@nathos haha I know :)",
  "id" : 323617206946648065,
  "in_reply_to_status_id" : 323615891969417217,
  "created_at" : "2013-04-15 02:02:09 +0000",
  "in_reply_to_screen_name" : "nathos",
  "in_reply_to_user_id_str" : "34953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 0, 7 ],
      "id_str" : "34953",
      "id" : 34953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/HMj4GWAauh",
      "expanded_url" : "https:\/\/github.com\/python\/pycon-code-of-conduct\/blob\/master\/code_of_conduct.md#license",
      "display_url" : "github.com\/python\/pycon-c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "323615891969417217",
  "geo" : { },
  "id_str" : "323616593449996289",
  "in_reply_to_user_id" : 34953,
  "text" : "@nathos no: https:\/\/t.co\/HMj4GWAauh",
  "id" : 323616593449996289,
  "in_reply_to_status_id" : 323615891969417217,
  "created_at" : "2013-04-15 01:59:43 +0000",
  "in_reply_to_screen_name" : "nathos",
  "in_reply_to_user_id_str" : "34953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323601578764414976",
  "geo" : { },
  "id_str" : "323613838178123777",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella that's much better than \"hurry up\" ...both of which wouldn't work on ours.",
  "id" : 323613838178123777,
  "in_reply_to_status_id" : 323601578764414976,
  "created_at" : "2013-04-15 01:48:46 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PyCon",
      "screen_name" : "pycon",
      "indices" : [ 14, 20 ],
      "id_str" : "9475182",
      "id" : 9475182
    }, {
      "name" : "Jesse Noller",
      "screen_name" : "jessenoller",
      "indices" : [ 25, 37 ],
      "id_str" : "14100497",
      "id" : 14100497
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 100, 115 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323613701729026048",
  "text" : "Big thanks to @pycon and @jessenoller for making their Code of Conduct CC-licensed. Just forked for @nickelcityruby !",
  "id" : 323613701729026048,
  "created_at" : "2013-04-15 01:48:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/E3eDI3r1h1",
      "expanded_url" : "http:\/\/moonjock.tumblr.com\/post\/47988338981",
      "display_url" : "moonjock.tumblr.com\/post\/479883389\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "323592963697545218",
  "text" : "Get Lucky. http:\/\/t.co\/E3eDI3r1h1",
  "id" : 323592963697545218,
  "created_at" : "2013-04-15 00:25:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323589685324701698",
  "geo" : { },
  "id_str" : "323590505898311680",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck get some blue cheese or manchego. be patient. don't be afraid to cut it to check the rawness. you're not on top chef. eat it.",
  "id" : 323590505898311680,
  "in_reply_to_status_id" : 323589685324701698,
  "created_at" : "2013-04-15 00:16:03 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323553268997435393",
  "geo" : { },
  "id_str" : "323553545976700928",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler oh yes. even more of a reason.",
  "id" : 323553545976700928,
  "in_reply_to_status_id" : 323553268997435393,
  "created_at" : "2013-04-14 21:49:11 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323549572477636610",
  "text" : "\"I've long suspected bitcoin was created by a government.\" ...and that's when I stopped reading HN today.",
  "id" : 323549572477636610,
  "created_at" : "2013-04-14 21:33:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 0, 7 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323459367980654592",
  "geo" : { },
  "id_str" : "323463238266269696",
  "in_reply_to_user_id" : 38003,
  "text" : "@gedeon what game is this?",
  "id" : 323463238266269696,
  "in_reply_to_status_id" : 323459367980654592,
  "created_at" : "2013-04-14 15:50:20 +0000",
  "in_reply_to_screen_name" : "gedeon",
  "in_reply_to_user_id_str" : "38003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/tFUIGiccBw",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=a7jJnwEeiU0",
      "display_url" : "youtube.com\/watch?v=a7jJnw\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "323112232470867970",
  "geo" : { },
  "id_str" : "323456126203076608",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr there\u2019a Wayne\u2019s world quotes all over. http:\/\/t.co\/tFUIGiccBw",
  "id" : 323456126203076608,
  "in_reply_to_status_id" : 323112232470867970,
  "created_at" : "2013-04-14 15:22:04 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/cXIBlicMfI",
      "expanded_url" : "http:\/\/m.youtube.com\/#\/watch?v=pefow5Kp_W4&desktop_uri=%2Fwatch%3Fv%3Dpefow5Kp_W4",
      "display_url" : "m.youtube.com\/#\/watch?v=pefo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "323452519202299904",
  "text" : "New Daft Punk\u2026MORE!! http:\/\/t.co\/cXIBlicMfI",
  "id" : 323452519202299904,
  "created_at" : "2013-04-14 15:07:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Levinthal",
      "screen_name" : "davelevinthal",
      "indices" : [ 3, 17 ],
      "id_str" : "222554961",
      "id" : 222554961
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/cgZiGC2yah",
      "expanded_url" : "http:\/\/www.indiegogo.com\/projects\/grain-elevator-rock-climbing-center",
      "display_url" : "indiegogo.com\/projects\/grain\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "323238359529029632",
  "text" : "RT @davelevinthal: The final push in #Buffalo to turn an abandoned grain mill into a climbing mecca http:\/\/t.co\/cgZiGC2yah",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 18, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/cgZiGC2yah",
        "expanded_url" : "http:\/\/www.indiegogo.com\/projects\/grain-elevator-rock-climbing-center",
        "display_url" : "indiegogo.com\/projects\/grain\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "323196799085060096",
    "text" : "The final push in #Buffalo to turn an abandoned grain mill into a climbing mecca http:\/\/t.co\/cgZiGC2yah",
    "id" : 323196799085060096,
    "created_at" : "2013-04-13 22:11:36 +0000",
    "user" : {
      "name" : "Dave Levinthal",
      "screen_name" : "davelevinthal",
      "protected" : false,
      "id_str" : "222554961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510081173330997249\/kCiJts9O_normal.png",
      "id" : 222554961,
      "verified" : true
    }
  },
  "id" : 323238359529029632,
  "created_at" : "2013-04-14 00:56:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 3, 18 ],
      "id_str" : "13639982",
      "id" : 13639982
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 46, 52 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/MarkVillacampa\/status\/323222474978373634\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/bnpDdCXyDW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHxRIOUCMAA7tF0.jpg",
      "id_str" : "323222474986762240",
      "id" : 323222474986762240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHxRIOUCMAA7tF0.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      } ],
      "display_url" : "pic.twitter.com\/bnpDdCXyDW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323223249192366080",
  "text" : "RT @MarkVillacampa: 3D printed buffalo :) cc\/ @qrush http:\/\/t.co\/bnpDdCXyDW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 26, 32 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MarkVillacampa\/status\/323222474978373634\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/bnpDdCXyDW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BHxRIOUCMAA7tF0.jpg",
        "id_str" : "323222474986762240",
        "id" : 323222474986762240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHxRIOUCMAA7tF0.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 1136
        } ],
        "display_url" : "pic.twitter.com\/bnpDdCXyDW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "323222474978373634",
    "text" : "3D printed buffalo :) cc\/ @qrush http:\/\/t.co\/bnpDdCXyDW",
    "id" : 323222474978373634,
    "created_at" : "2013-04-13 23:53:38 +0000",
    "user" : {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "protected" : false,
      "id_str" : "13639982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000025087301\/4e8c8e2eb1083fc2c34135029ef3fd4e_normal.jpeg",
      "id" : 13639982,
      "verified" : false
    }
  },
  "id" : 323223249192366080,
  "created_at" : "2013-04-13 23:56:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 0, 15 ],
      "id_str" : "13639982",
      "id" : 13639982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323222474978373634",
  "geo" : { },
  "id_str" : "323222908740698112",
  "in_reply_to_user_id" : 13639982,
  "text" : "@MarkVillacampa awesome!",
  "id" : 323222908740698112,
  "in_reply_to_status_id" : 323222474978373634,
  "created_at" : "2013-04-13 23:55:21 +0000",
  "in_reply_to_screen_name" : "MarkVillacampa",
  "in_reply_to_user_id_str" : "13639982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 3, 18 ],
      "id_str" : "13639982",
      "id" : 13639982
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 62, 68 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/MarkVillacampa\/status\/323201482969198592\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/Voscmr23VL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHw-CU_CMAAM3Xc.jpg",
      "id_str" : "323201482977587200",
      "id" : 323201482977587200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHw-CU_CMAAM3Xc.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Voscmr23VL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323216400783122432",
  "text" : "RT @MarkVillacampa: Current status: 3d printing a buffalo cc\/ @qrush http:\/\/t.co\/Voscmr23VL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 42, 48 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MarkVillacampa\/status\/323201482969198592\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/Voscmr23VL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BHw-CU_CMAAM3Xc.jpg",
        "id_str" : "323201482977587200",
        "id" : 323201482977587200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHw-CU_CMAAM3Xc.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Voscmr23VL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "323201482969198592",
    "text" : "Current status: 3d printing a buffalo cc\/ @qrush http:\/\/t.co\/Voscmr23VL",
    "id" : 323201482969198592,
    "created_at" : "2013-04-13 22:30:13 +0000",
    "user" : {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "protected" : false,
      "id_str" : "13639982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000025087301\/4e8c8e2eb1083fc2c34135029ef3fd4e_normal.jpeg",
      "id" : 13639982,
      "verified" : false
    }
  },
  "id" : 323216400783122432,
  "created_at" : "2013-04-13 23:29:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/7LNq3QKGgJ",
      "expanded_url" : "http:\/\/flic.kr\/u\/tZEsU\/aHsjEHa8Y5",
      "display_url" : "flic.kr\/u\/tZEsU\/aHsjEH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "323185315009404928",
  "text" : "View my 55 latest photos on Flickr: http:\/\/t.co\/7LNq3QKGgJ",
  "id" : 323185315009404928,
  "created_at" : "2013-04-13 21:25:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles\uE416",
      "screen_name" : "THEANGRYGUMBALL",
      "indices" : [ 0, 16 ],
      "id_str" : "109550679",
      "id" : 109550679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/Hr6XLvAk1M",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/status\/822613478",
      "display_url" : "twitter.com\/qrush\/status\/8\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "322839051948412930",
  "geo" : { },
  "id_str" : "322841106196877312",
  "in_reply_to_user_id" : 109550679,
  "text" : "@THEANGRYGUMBALL I have the first known mention of it! https:\/\/t.co\/Hr6XLvAk1M",
  "id" : 322841106196877312,
  "in_reply_to_status_id" : 322839051948412930,
  "created_at" : "2013-04-12 22:38:12 +0000",
  "in_reply_to_screen_name" : "THEANGRYGUMBALL",
  "in_reply_to_user_id_str" : "109550679",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u277A\u27A0 David Copeland",
      "screen_name" : "davetron5000",
      "indices" : [ 0, 13 ],
      "id_str" : "5660222",
      "id" : 5660222
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 47, 61 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322785098724421632",
  "geo" : { },
  "id_str" : "322785909131079681",
  "in_reply_to_user_id" : 5660222,
  "text" : "@davetron5000 This is another reason I started @coworkbuffalo. No joke.",
  "id" : 322785909131079681,
  "in_reply_to_status_id" : 322785098724421632,
  "created_at" : "2013-04-12 18:58:52 +0000",
  "in_reply_to_screen_name" : "davetron5000",
  "in_reply_to_user_id_str" : "5660222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/TtMgbeRi7w",
      "expanded_url" : "http:\/\/kottke.org\/13\/04\/how-baseballs-are-made",
      "display_url" : "kottke.org\/13\/04\/how-base\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "322730349195038720",
  "text" : "Blown away that baseballs are hand-stitched together. TMYK... http:\/\/t.co\/TtMgbeRi7w",
  "id" : 322730349195038720,
  "created_at" : "2013-04-12 15:18:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Newland",
      "screen_name" : "jnewland",
      "indices" : [ 0, 9 ],
      "id_str" : "13518",
      "id" : 13518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322705097748533249",
  "geo" : { },
  "id_str" : "322729636440195072",
  "in_reply_to_user_id" : 13518,
  "text" : "@jnewland if you have questions about how we run stuff I'd be more than happy to help",
  "id" : 322729636440195072,
  "in_reply_to_status_id" : 322705097748533249,
  "created_at" : "2013-04-12 15:15:16 +0000",
  "in_reply_to_screen_name" : "jnewland",
  "in_reply_to_user_id_str" : "13518",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Yusuke Endoh",
      "screen_name" : "mametter",
      "indices" : [ 12, 21 ],
      "id_str" : "58427169",
      "id" : 58427169
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 22, 30 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322712479614509058",
  "geo" : { },
  "id_str" : "322716861143867392",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove @mametter @evanphx existing gems should be allowed to update, clearly an oversight",
  "id" : 322716861143867392,
  "in_reply_to_status_id" : 322712479614509058,
  "created_at" : "2013-04-12 14:24:30 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Newland",
      "screen_name" : "jnewland",
      "indices" : [ 0, 9 ],
      "id_str" : "13518",
      "id" : 13518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/OXHKG5x7SW",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3162-the-on-call-programmer",
      "display_url" : "37signals.com\/svn\/posts\/3162\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "322688842006159360",
  "geo" : { },
  "id_str" : "322704626438774785",
  "in_reply_to_user_id" : 13518,
  "text" : "@jnewland http:\/\/t.co\/OXHKG5x7SW",
  "id" : 322704626438774785,
  "in_reply_to_status_id" : 322688842006159360,
  "created_at" : "2013-04-12 13:35:53 +0000",
  "in_reply_to_screen_name" : "jnewland",
  "in_reply_to_user_id_str" : "13518",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bradford do\u00A3\u00A3a sign",
      "screen_name" : "LusciousPear",
      "indices" : [ 0, 13 ],
      "id_str" : "15829680",
      "id" : 15829680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322578535925555201",
  "geo" : { },
  "id_str" : "322578726174986240",
  "in_reply_to_user_id" : 15829680,
  "text" : "@LusciousPear most of them are loft apartments now. Gorgeous spaces, terrible commute length into Boston.",
  "id" : 322578726174986240,
  "in_reply_to_status_id" : 322578535925555201,
  "created_at" : "2013-04-12 05:15:36 +0000",
  "in_reply_to_screen_name" : "LusciousPear",
  "in_reply_to_user_id_str" : "15829680",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322574758287917056",
  "geo" : { },
  "id_str" : "322577844490346496",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza I don't get why or how people fall for it. I would never feed a *physical* game machine more quarters, etc.",
  "id" : 322577844490346496,
  "in_reply_to_status_id" : 322574758287917056,
  "created_at" : "2013-04-12 05:12:05 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bradford do\u00A3\u00A3a sign",
      "screen_name" : "LusciousPear",
      "indices" : [ 0, 13 ],
      "id_str" : "15829680",
      "id" : 15829680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322574844048838657",
  "geo" : { },
  "id_str" : "322576715597627392",
  "in_reply_to_user_id" : 15829680,
  "text" : "@LusciousPear I lived in one of those mills. Such a crazy history behind them.",
  "id" : 322576715597627392,
  "in_reply_to_status_id" : 322574844048838657,
  "created_at" : "2013-04-12 05:07:36 +0000",
  "in_reply_to_screen_name" : "LusciousPear",
  "in_reply_to_user_id_str" : "15829680",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 0, 13 ],
      "id_str" : "257495729",
      "id" : 257495729
    }, {
      "name" : "Buffalo JavaScript",
      "screen_name" : "BuffaloJS",
      "indices" : [ 14, 24 ],
      "id_str" : "817437266",
      "id" : 817437266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322486944003149824",
  "geo" : { },
  "id_str" : "322549738845110272",
  "in_reply_to_user_id" : 257495729,
  "text" : "@TommyCreenan @BuffaloJS awesome! more!!!",
  "id" : 322549738845110272,
  "in_reply_to_status_id" : 322486944003149824,
  "created_at" : "2013-04-12 03:20:25 +0000",
  "in_reply_to_screen_name" : "TommyCreenan",
  "in_reply_to_user_id_str" : "257495729",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/PaQ2DiDXVl",
      "expanded_url" : "http:\/\/dresdencodak.tumblr.com\/post\/47724463171\/inspired-by-anita-sarkeesians-video-game-tropes",
      "display_url" : "dresdencodak.tumblr.com\/post\/477244631\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "322545461196115968",
  "text" : "It's time for Zelda to be Link. I'd play the heck out of this. http:\/\/t.co\/PaQ2DiDXVl",
  "id" : 322545461196115968,
  "created_at" : "2013-04-12 03:03:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 0, 13 ],
      "id_str" : "257495729",
      "id" : 257495729
    }, {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 14, 23 ],
      "id_str" : "20531902",
      "id" : 20531902
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 75, 90 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 97, 107 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 108, 115 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322472953679839232",
  "geo" : { },
  "id_str" : "322477322743713792",
  "in_reply_to_user_id" : 257495729,
  "text" : "@TommyCreenan @sabiddle this is awesome, and we do need a shirt design for @nickelcityruby \u2026 \/cc @aquaranto @nb3004",
  "id" : 322477322743713792,
  "in_reply_to_status_id" : 322472953679839232,
  "created_at" : "2013-04-11 22:32:39 +0000",
  "in_reply_to_screen_name" : "TommyCreenan",
  "in_reply_to_user_id_str" : "257495729",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 3, 16 ],
      "id_str" : "257495729",
      "id" : 257495729
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TommyCreenan\/status\/322472953679839232\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ZMF3eJSuVd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHmncV4CAAAMhze.jpg",
      "id_str" : "322472953684033536",
      "id" : 322472953684033536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHmncV4CAAAMhze.jpg",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ZMF3eJSuVd"
    } ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 18, 26 ]
    }, {
      "text" : "Pixel",
      "indices" : [ 38, 44 ]
    }, {
      "text" : "PixelArt",
      "indices" : [ 99, 108 ]
    }, {
      "text" : "architecture",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322477046796275713",
  "text" : "RT @TommyCreenan: #Buffalo City Hall, #Pixel version! The first of (hopefully) many more pieces of #PixelArt to come! #architecture http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TommyCreenan\/status\/322472953679839232\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/ZMF3eJSuVd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BHmncV4CAAAMhze.jpg",
        "id_str" : "322472953684033536",
        "id" : 322472953684033536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHmncV4CAAAMhze.jpg",
        "sizes" : [ {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ZMF3eJSuVd"
      } ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "Pixel",
        "indices" : [ 20, 26 ]
      }, {
        "text" : "PixelArt",
        "indices" : [ 81, 90 ]
      }, {
        "text" : "architecture",
        "indices" : [ 100, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "322472953679839232",
    "text" : "#Buffalo City Hall, #Pixel version! The first of (hopefully) many more pieces of #PixelArt to come! #architecture http:\/\/t.co\/ZMF3eJSuVd",
    "id" : 322472953679839232,
    "created_at" : "2013-04-11 22:15:18 +0000",
    "user" : {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "protected" : false,
      "id_str" : "257495729",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/532272850242002944\/SAUXcbLf_normal.jpeg",
      "id" : 257495729,
      "verified" : false
    }
  },
  "id" : 322477046796275713,
  "created_at" : "2013-04-11 22:31:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322453610455773184",
  "geo" : { },
  "id_str" : "322454773649506305",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante can you email work@coworkbuffalo.com about it?",
  "id" : 322454773649506305,
  "in_reply_to_status_id" : 322453610455773184,
  "created_at" : "2013-04-11 21:03:03 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Mongeau",
      "screen_name" : "halogenandtoast",
      "indices" : [ 0, 16 ],
      "id_str" : "15428948",
      "id" : 15428948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322449115428573186",
  "geo" : { },
  "id_str" : "322449490952978432",
  "in_reply_to_user_id" : 15428948,
  "text" : "@halogenandtoast you forgot inheritance, databases, lunch options.",
  "id" : 322449490952978432,
  "in_reply_to_status_id" : 322449115428573186,
  "created_at" : "2013-04-11 20:42:04 +0000",
  "in_reply_to_screen_name" : "halogenandtoast",
  "in_reply_to_user_id_str" : "15428948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Griffey",
      "screen_name" : "briangriffey",
      "indices" : [ 0, 13 ],
      "id_str" : "24887250",
      "id" : 24887250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322448490380816386",
  "geo" : { },
  "id_str" : "322449305749307393",
  "in_reply_to_user_id" : 24887250,
  "text" : "@briangriffey bane of my existence since I started webdev in 2005 :(",
  "id" : 322449305749307393,
  "in_reply_to_status_id" : 322448490380816386,
  "created_at" : "2013-04-11 20:41:19 +0000",
  "in_reply_to_screen_name" : "briangriffey",
  "in_reply_to_user_id_str" : "24887250",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Kapp",
      "screen_name" : "happymrdave",
      "indices" : [ 0, 12 ],
      "id_str" : "15399388",
      "id" : 15399388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322448397061738496",
  "geo" : { },
  "id_str" : "322449221015965698",
  "in_reply_to_user_id" : 15399388,
  "text" : "@happymrdave you can't pass authentication headers, including cookies on IE9 with CORS.",
  "id" : 322449221015965698,
  "in_reply_to_status_id" : 322448397061738496,
  "created_at" : "2013-04-11 20:40:59 +0000",
  "in_reply_to_screen_name" : "happymrdave",
  "in_reply_to_user_id_str" : "15399388",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322448011445796864",
  "text" : "CORS is such a fucking mess. Chrome and Safari do it right, Firefox is bad and IE9\/10 are even worse.",
  "id" : 322448011445796864,
  "created_at" : "2013-04-11 20:36:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/cEcTE6YUHi",
      "expanded_url" : "http:\/\/37svn.com\/3503",
      "display_url" : "37svn.com\/3503"
    } ]
  },
  "geo" : { },
  "id_str" : "322388782148091906",
  "text" : "Despite all of these choices I'm still a bit confused. Cameras ain't easy. http:\/\/t.co\/cEcTE6YUHi",
  "id" : 322388782148091906,
  "created_at" : "2013-04-11 16:40:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin T.A. Gray",
      "screen_name" : "colinta",
      "indices" : [ 38, 46 ],
      "id_str" : "270963272",
      "id" : 270963272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/8Uz99FI03D",
      "expanded_url" : "http:\/\/blog.rubymotion.com\/post\/47542877666\/rubymotion-success-story-basecamp-for-iphone",
      "display_url" : "blog.rubymotion.com\/post\/475428776\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "322383920941383680",
  "text" : "Watch as I wave my hands around while @colinta interviews me on RubyMotion: http:\/\/t.co\/8Uz99FI03D",
  "id" : 322383920941383680,
  "created_at" : "2013-04-11 16:21:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Panic Inc",
      "screen_name" : "panic",
      "indices" : [ 0, 6 ],
      "id_str" : "6687652",
      "id" : 6687652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/6BODKEVjdZ",
      "expanded_url" : "http:\/\/example.com\/feed.xml",
      "display_url" : "example.com\/feed.xml"
    }, {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/uY7bKNwMrm",
      "expanded_url" : "http:\/\/example.com\/feed.xml\/favicon.ico",
      "display_url" : "example.com\/feed.xml\/favic\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "322378084898705408",
  "geo" : { },
  "id_str" : "322383425011068928",
  "in_reply_to_user_id" : 6687652,
  "text" : "@panic The path is actually wrong, if the feed is at http:\/\/t.co\/6BODKEVjdZ it looks for http:\/\/t.co\/uY7bKNwMrm",
  "id" : 322383425011068928,
  "in_reply_to_status_id" : 322378084898705408,
  "created_at" : "2013-04-11 16:19:32 +0000",
  "in_reply_to_screen_name" : "panic",
  "in_reply_to_user_id_str" : "6687652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 3, 14 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/AA1Qkf28mu",
      "expanded_url" : "http:\/\/blog.rubymotion.com\/post\/47542877666\/rubymotion-success-story-basecamp-for-iphone",
      "display_url" : "blog.rubymotion.com\/post\/475428776\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "322383178595700736",
  "text" : "RT @RubyMotion: RubyMotion Success Story: Basecamp for iPhone http:\/\/t.co\/AA1Qkf28mu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/AA1Qkf28mu",
        "expanded_url" : "http:\/\/blog.rubymotion.com\/post\/47542877666\/rubymotion-success-story-basecamp-for-iphone",
        "display_url" : "blog.rubymotion.com\/post\/475428776\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "322360080030916609",
    "text" : "RubyMotion Success Story: Basecamp for iPhone http:\/\/t.co\/AA1Qkf28mu",
    "id" : 322360080030916609,
    "created_at" : "2013-04-11 14:46:46 +0000",
    "user" : {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "protected" : false,
      "id_str" : "381521407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540869126445490178\/xG24kW5B_normal.png",
      "id" : 381521407,
      "verified" : false
    }
  },
  "id" : 322383178595700736,
  "created_at" : "2013-04-11 16:18:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "360 PSG",
      "screen_name" : "360PSG",
      "indices" : [ 29, 36 ],
      "id_str" : "18906882",
      "id" : 18906882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322358055759122434",
  "text" : "RT @coworkbuffalo: Team from @360psg is staging a productive code escape from their office today, with team discount. Let us know if you ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "360 PSG",
        "screen_name" : "360PSG",
        "indices" : [ 10, 17 ],
        "id_str" : "18906882",
        "id" : 18906882
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "322357238134095872",
    "text" : "Team from @360psg is staging a productive code escape from their office today, with team discount. Let us know if you'd like the same!",
    "id" : 322357238134095872,
    "created_at" : "2013-04-11 14:35:29 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 322358055759122434,
  "created_at" : "2013-04-11 14:38:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Panic Inc",
      "screen_name" : "panic",
      "indices" : [ 0, 6 ],
      "id_str" : "6687652",
      "id" : 6687652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322212488542298112",
  "geo" : { },
  "id_str" : "322213349184122880",
  "in_reply_to_user_id" : 6687652,
  "text" : "@panic Awesome! Is there any way to configure an RSS feed icon? &lt;icon&gt; and &lt;logo&gt; aren't picking up in my atom feed.",
  "id" : 322213349184122880,
  "in_reply_to_status_id" : 322212488542298112,
  "created_at" : "2013-04-11 05:03:43 +0000",
  "in_reply_to_screen_name" : "panic",
  "in_reply_to_user_id_str" : "6687652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Panic Inc",
      "screen_name" : "panic",
      "indices" : [ 16, 22 ],
      "id_str" : "6687652",
      "id" : 6687652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322210926268932096",
  "text" : "Really enjoying @panic's StatusBoard so far. My only wish: to have multiple boards. One for work, at home, etc.",
  "id" : 322210926268932096,
  "created_at" : "2013-04-11 04:54:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Panic Inc",
      "screen_name" : "panic",
      "indices" : [ 4, 10 ],
      "id_str" : "6687652",
      "id" : 6687652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322189561369358338",
  "text" : "Hey @panic, any idea how to get a logo from a custom atom feed to appear in Status Board? &lt;icon&gt; and &lt;logo&gt; won't cut it.",
  "id" : 322189561369358338,
  "created_at" : "2013-04-11 03:29:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 9, 17 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322037975208849410",
  "geo" : { },
  "id_str" : "322038482698653696",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety @jayunit yay!!!",
  "id" : 322038482698653696,
  "in_reply_to_status_id" : 322037975208849410,
  "created_at" : "2013-04-10 17:28:52 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321846504472051712",
  "geo" : { },
  "id_str" : "321846742557548545",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza phew. in any case I feel that displaying \"data\" is different than re-implementing the \"home\" experience. looks really nice!",
  "id" : 321846742557548545,
  "in_reply_to_status_id" : 321846504472051712,
  "created_at" : "2013-04-10 04:46:57 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321846060538527744",
  "geo" : { },
  "id_str" : "321846332677554176",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza did you know this by heart?",
  "id" : 321846332677554176,
  "in_reply_to_status_id" : 321846060538527744,
  "created_at" : "2013-04-10 04:45:19 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321844605802930177",
  "text" : "Cameras are expensive.",
  "id" : 321844605802930177,
  "created_at" : "2013-04-10 04:38:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321837609989054464",
  "text" : "\"Sadly, the website has opening hours. Really.\" UGH",
  "id" : 321837609989054464,
  "created_at" : "2013-04-10 04:10:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 11, 15 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321815269574078465",
  "geo" : { },
  "id_str" : "321827982664667136",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack @dhh thinking of getting a decent camera that\u2019s not an iPhone. Worth it for a noob?",
  "id" : 321827982664667136,
  "in_reply_to_status_id" : 321815269574078465,
  "created_at" : "2013-04-10 03:32:25 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WBFO",
      "screen_name" : "WBFO",
      "indices" : [ 41, 46 ],
      "id_str" : "20612109",
      "id" : 20612109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321798154003550208",
  "text" : "Lightning strike seems to have wiped out @WBFO\u2019s signal. I guess I should have donated in the last pledge drive.",
  "id" : 321798154003550208,
  "created_at" : "2013-04-10 01:33:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z80 Labs",
      "screen_name" : "Z80Labs",
      "indices" : [ 14, 22 ],
      "id_str" : "632391390",
      "id" : 632391390
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 35, 43 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321773188331745281",
  "text" : "Big thanks to @z80labs for hosting @wnyruby tonight. Really glad to bring people downtown for Ruby awesomeness!",
  "id" : 321773188331745281,
  "created_at" : "2013-04-09 23:54:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321739670167896064",
  "geo" : { },
  "id_str" : "321748361160040449",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden it's nice! Easy to drop in than a full-fledged xpac.",
  "id" : 321748361160040449,
  "in_reply_to_status_id" : 321739670167896064,
  "created_at" : "2013-04-09 22:16:01 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 36, 50 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/321739218110001153\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/ly3d4S15ve",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHcMHT4CMAA1a-i.jpg",
      "id_str" : "321739218114195456",
      "id" : 321739218114195456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHcMHT4CMAA1a-i.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ly3d4S15ve"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321739218110001153",
  "text" : "Carcassonne &amp; Goldmines earlier @coworkbuffalo http:\/\/t.co\/ly3d4S15ve",
  "id" : 321739218110001153,
  "created_at" : "2013-04-09 21:39:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321737809893408768",
  "geo" : { },
  "id_str" : "321739054003658752",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens it\u2019s not or I would be getting a flurry of pingdom alerts. ;)",
  "id" : 321739054003658752,
  "in_reply_to_status_id" : 321737809893408768,
  "created_at" : "2013-04-09 21:39:02 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/9HMvwGY9Ao",
      "expanded_url" : "http:\/\/i.minus.com\/ioU5XRyBrJTSN.gif",
      "display_url" : "i.minus.com\/ioU5XRyBrJTSN.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "321653324371853312",
  "text" : "Current status: http:\/\/t.co\/9HMvwGY9Ao",
  "id" : 321653324371853312,
  "created_at" : "2013-04-09 15:58:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chap Ambrose",
      "screen_name" : "chapambrose",
      "indices" : [ 0, 12 ],
      "id_str" : "10978282",
      "id" : 10978282
    }, {
      "name" : "Zak Kain \u262F",
      "screen_name" : "zakkain",
      "indices" : [ 13, 21 ],
      "id_str" : "15069435",
      "id" : 15069435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321637835377623040",
  "geo" : { },
  "id_str" : "321638215960383488",
  "in_reply_to_user_id" : 10978282,
  "text" : "@chapambrose @zakkain ha, two woodworking references. given I have zero physical \"craft\" skills maybe this is a bad metaphor",
  "id" : 321638215960383488,
  "in_reply_to_status_id" : 321637835377623040,
  "created_at" : "2013-04-09 14:58:21 +0000",
  "in_reply_to_screen_name" : "chapambrose",
  "in_reply_to_user_id_str" : "10978282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321637278965452800",
  "geo" : { },
  "id_str" : "321637337710858241",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej pwhat?",
  "id" : 321637337710858241,
  "in_reply_to_status_id" : 321637278965452800,
  "created_at" : "2013-04-09 14:54:51 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321636387126390785",
  "text" : "My biggest programming as a craft problem: spending time programming for the machine, not the user. Memory management is just one example.",
  "id" : 321636387126390785,
  "created_at" : "2013-04-09 14:51:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scheirman",
      "screen_name" : "subdigital",
      "indices" : [ 0, 11 ],
      "id_str" : "14133001",
      "id" : 14133001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321634134051135488",
  "geo" : { },
  "id_str" : "321634674248138753",
  "in_reply_to_user_id" : 14133001,
  "text" : "@subdigital thanks...i'm just trying to find code examples and understand better. Just feels like so much busywork.",
  "id" : 321634674248138753,
  "in_reply_to_status_id" : 321634134051135488,
  "created_at" : "2013-04-09 14:44:16 +0000",
  "in_reply_to_screen_name" : "subdigital",
  "in_reply_to_user_id_str" : "14133001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker Wightman",
      "screen_name" : "parkerwightman",
      "indices" : [ 0, 15 ],
      "id_str" : "415345747",
      "id" : 415345747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321631876852883456",
  "geo" : { },
  "id_str" : "321632558787985408",
  "in_reply_to_user_id" : 415345747,
  "text" : "@parkerwightman having never programmed in a strict C style language (C# doesn't count), I think i'm scarred permanently :(",
  "id" : 321632558787985408,
  "in_reply_to_status_id" : 321631876852883456,
  "created_at" : "2013-04-09 14:35:52 +0000",
  "in_reply_to_screen_name" : "parkerwightman",
  "in_reply_to_user_id_str" : "415345747",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scheirman",
      "screen_name" : "subdigital",
      "indices" : [ 0, 11 ],
      "id_str" : "14133001",
      "id" : 14133001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321627769597485056",
  "geo" : { },
  "id_str" : "321628759415480320",
  "in_reply_to_user_id" : 14133001,
  "text" : "@subdigital I don't get this usage. you literally don't have to deal with this with RubyMotion at *all*. know of any links that explain it?",
  "id" : 321628759415480320,
  "in_reply_to_status_id" : 321627769597485056,
  "created_at" : "2013-04-09 14:20:46 +0000",
  "in_reply_to_screen_name" : "subdigital",
  "in_reply_to_user_id_str" : "14133001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/FkedISOhC8",
      "expanded_url" : "http:\/\/www.cocoawithlove.com\/2009\/07\/rules-to-avoid-retain-cycles.html",
      "display_url" : "cocoawithlove.com\/2009\/07\/rules-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "321627003658838016",
  "text" : "Is http:\/\/t.co\/FkedISOhC8 still relevant for \"modern\" Objective-C development? This stuff feels so arcane.",
  "id" : 321627003658838016,
  "created_at" : "2013-04-09 14:13:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    }, {
      "name" : "Yannick \u2603 Schutz",
      "screen_name" : "yann_ck",
      "indices" : [ 5, 13 ],
      "id_str" : "14835545",
      "id" : 14835545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321589056536469504",
  "geo" : { },
  "id_str" : "321621926021824512",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz @yann_ck I'm quaranto on Game Center, which doesn't require a trip to Europe :)",
  "id" : 321621926021824512,
  "in_reply_to_status_id" : 321589056536469504,
  "created_at" : "2013-04-09 13:53:37 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "davidmoffitt",
      "screen_name" : "davidmoffitt",
      "indices" : [ 0, 13 ],
      "id_str" : "15101175",
      "id" : 15101175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321473869510754304",
  "geo" : { },
  "id_str" : "321474656974557184",
  "in_reply_to_user_id" : 15101175,
  "text" : "@davidmoffitt as someone who played Vanilla...it's long past its prime. Don't even bother.",
  "id" : 321474656974557184,
  "in_reply_to_status_id" : 321473869510754304,
  "created_at" : "2013-04-09 04:08:25 +0000",
  "in_reply_to_screen_name" : "davidmoffitt",
  "in_reply_to_user_id_str" : "15101175",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/9bG6ZV7LvT",
      "expanded_url" : "http:\/\/i.qkme.me\/3tscrw.jpg",
      "display_url" : "i.qkme.me\/3tscrw.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "321398260877123584",
  "text" : "Current status: http:\/\/t.co\/9bG6ZV7LvT",
  "id" : 321398260877123584,
  "created_at" : "2013-04-08 23:04:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321378725268705282",
  "geo" : { },
  "id_str" : "321379461700407296",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt well that's one reason to continue avoiding Devise :)",
  "id" : 321379461700407296,
  "in_reply_to_status_id" : 321378725268705282,
  "created_at" : "2013-04-08 21:50:09 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321352166105309184",
  "geo" : { },
  "id_str" : "321375417766383617",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt Actually on a second look this is really gross in general to use controller_name. ugh...",
  "id" : 321375417766383617,
  "in_reply_to_status_id" : 321352166105309184,
  "created_at" : "2013-04-08 21:34:05 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321351687153545217",
  "geo" : { },
  "id_str" : "321352068856160256",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt not sure if trolling. logic in views is terrible :(",
  "id" : 321352068856160256,
  "in_reply_to_status_id" : 321351687153545217,
  "created_at" : "2013-04-08 20:01:18 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321351369149788161",
  "geo" : { },
  "id_str" : "321351662361006081",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt use a helper :(",
  "id" : 321351662361006081,
  "in_reply_to_status_id" : 321351369149788161,
  "created_at" : "2013-04-08 19:59:41 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321314262377197568",
  "text" : "\"Clarence man with frog phobia wins $1.6 million verdict\" - Not a news headline from Sim City 2000.",
  "id" : 321314262377197568,
  "created_at" : "2013-04-08 17:31:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yannick \u2603 Schutz",
      "screen_name" : "yann_ck",
      "indices" : [ 0, 8 ],
      "id_str" : "14835545",
      "id" : 14835545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321266385835679745",
  "geo" : { },
  "id_str" : "321267895650877442",
  "in_reply_to_user_id" : 14835545,
  "text" : "@yann_ck Awesome!",
  "id" : 321267895650877442,
  "in_reply_to_status_id" : 321266385835679745,
  "created_at" : "2013-04-08 14:26:49 +0000",
  "in_reply_to_screen_name" : "yann_ck",
  "in_reply_to_user_id_str" : "14835545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dane Harrigan",
      "screen_name" : "daneharrigan",
      "indices" : [ 0, 13 ],
      "id_str" : "26848546",
      "id" : 26848546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321029705379753985",
  "geo" : { },
  "id_str" : "321245280970371072",
  "in_reply_to_user_id" : 26848546,
  "text" : "@daneharrigan not sure\u2026If you can open a ticket we can take a closer look",
  "id" : 321245280970371072,
  "in_reply_to_status_id" : 321029705379753985,
  "created_at" : "2013-04-08 12:56:58 +0000",
  "in_reply_to_screen_name" : "daneharrigan",
  "in_reply_to_user_id_str" : "26848546",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321010272179470336",
  "geo" : { },
  "id_str" : "321244973473345537",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr email works beat when i\u2019m offlinw",
  "id" : 321244973473345537,
  "in_reply_to_status_id" : 321010272179470336,
  "created_at" : "2013-04-08 12:55:44 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 59, 71 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320763536773103616",
  "text" : "Once again super happy that I could bring 8 folks to enjoy @AqueousBand. \uFF08\u2267\u2207\u2266\uFF09",
  "id" : 320763536773103616,
  "created_at" : "2013-04-07 05:02:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320761542498992128",
  "geo" : { },
  "id_str" : "320762946621935617",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog yes! So good.",
  "id" : 320762946621935617,
  "in_reply_to_status_id" : 320761542498992128,
  "created_at" : "2013-04-07 05:00:20 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 5, 17 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320737205922430976",
  "text" : "It\u2019s @AqueousBand time. SOON!",
  "id" : 320737205922430976,
  "created_at" : "2013-04-07 03:18:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 89, 100 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2golDj9xhd",
      "expanded_url" : "http:\/\/blog.rubygems.org\/2013\/04\/06\/postmortem.html",
      "display_url" : "blog.rubygems.org\/2013\/04\/06\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "320720719040376832",
  "text" : "RT @rubygems_status: Great writeup of why pushes (and emails) were down today. Thanks to @samkottler for writing this up! http:\/\/t.co\/2g ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Kottler",
        "screen_name" : "samkottler",
        "indices" : [ 68, 79 ],
        "id_str" : "103914540",
        "id" : 103914540
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/2golDj9xhd",
        "expanded_url" : "http:\/\/blog.rubygems.org\/2013\/04\/06\/postmortem.html",
        "display_url" : "blog.rubygems.org\/2013\/04\/06\/pos\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "320720622894333954",
    "text" : "Great writeup of why pushes (and emails) were down today. Thanks to @samkottler for writing this up! http:\/\/t.co\/2golDj9xhd",
    "id" : 320720622894333954,
    "created_at" : "2013-04-07 02:12:09 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 320720719040376832,
  "created_at" : "2013-04-07 02:12:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Koschei",
      "screen_name" : "jordankoschei",
      "indices" : [ 0, 14 ],
      "id_str" : "249887765",
      "id" : 249887765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320720394153779200",
  "geo" : { },
  "id_str" : "320720702682566656",
  "in_reply_to_user_id" : 249887765,
  "text" : "@jordankoschei field notes are nice!",
  "id" : 320720702682566656,
  "in_reply_to_status_id" : 320720394153779200,
  "created_at" : "2013-04-07 02:12:28 +0000",
  "in_reply_to_screen_name" : "jordankoschei",
  "in_reply_to_user_id_str" : "249887765",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320676355903717376",
  "geo" : { },
  "id_str" : "320676945450921985",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius yeah, the homepage needs a redo\u2026",
  "id" : 320676945450921985,
  "in_reply_to_status_id" : 320676355903717376,
  "created_at" : "2013-04-06 23:18:36 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/DiTtpQyy4N",
      "expanded_url" : "https:\/\/itun.es\/us\/43QSG.i",
      "display_url" : "itun.es\/us\/43QSG.i"
    } ]
  },
  "geo" : { },
  "id_str" : "320676791578664960",
  "text" : "Really impressed by Slayin. Basically, I\u2019ll buy any game that has a retro feel to it. https:\/\/t.co\/DiTtpQyy4N",
  "id" : 320676791578664960,
  "created_at" : "2013-04-06 23:17:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320622693034651648",
  "geo" : { },
  "id_str" : "320662728945565697",
  "in_reply_to_user_id" : 370894106,
  "text" : "@22bytes I can answer questions via email but beyond that I have limited time. Can barely keep up with everything. Sorry man.",
  "id" : 320662728945565697,
  "in_reply_to_status_id" : 320622693034651648,
  "created_at" : "2013-04-06 22:22:06 +0000",
  "in_reply_to_screen_name" : "bufferable",
  "in_reply_to_user_id_str" : "370894106",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enable Labs",
      "screen_name" : "enablelabs",
      "indices" : [ 0, 11 ],
      "id_str" : "163973956",
      "id" : 163973956
    }, {
      "name" : "Mark Menard",
      "screen_name" : "mark_menard",
      "indices" : [ 12, 24 ],
      "id_str" : "13168222",
      "id" : 13168222
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 41, 50 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320660075947651072",
  "geo" : { },
  "id_str" : "320662605687562240",
  "in_reply_to_user_id" : 163973956,
  "text" : "@enablelabs @mark_menard fwiw if you use @openhack I can find these for RTs\u2026it\u2019s one word! :)",
  "id" : 320662605687562240,
  "in_reply_to_status_id" : 320660075947651072,
  "created_at" : "2013-04-06 22:21:37 +0000",
  "in_reply_to_screen_name" : "enablelabs",
  "in_reply_to_user_id_str" : "163973956",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320625060224323584",
  "geo" : { },
  "id_str" : "320657191864508419",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin neither!",
  "id" : 320657191864508419,
  "in_reply_to_status_id" : 320625060224323584,
  "created_at" : "2013-04-06 22:00:06 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 4, 13 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 14, 29 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 44, 56 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320636128350859265",
  "text" : "Hey @LawnMemo @UnclePhilsBlog any idea when @AqueousBand kicks off tonight?",
  "id" : 320636128350859265,
  "created_at" : "2013-04-06 20:36:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320596446304944128",
  "geo" : { },
  "id_str" : "320600757609054209",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss definitely Beta\u2026but good! Rules need some clarifications though",
  "id" : 320600757609054209,
  "in_reply_to_status_id" : 320596446304944128,
  "created_at" : "2013-04-06 18:15:51 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 0, 3 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/hAaxyFryyu",
      "expanded_url" : "https:\/\/trello.com\/board\/rubygems-org\/513f9634a7ed906115000755",
      "display_url" : "trello.com\/board\/rubygems\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "320597634467389440",
  "geo" : { },
  "id_str" : "320600563500851200",
  "in_reply_to_user_id" : 937561,
  "text" : "@jm have you seen https:\/\/t.co\/hAaxyFryyu ? Every that\u2019s in my my head I put there. Also I\u2019d be more than willing to host anyone here.",
  "id" : 320600563500851200,
  "in_reply_to_status_id" : 320597634467389440,
  "created_at" : "2013-04-06 18:15:05 +0000",
  "in_reply_to_screen_name" : "jm",
  "in_reply_to_user_id_str" : "937561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nap.tld, ltd.",
      "screen_name" : "zapnap",
      "indices" : [ 0, 7 ],
      "id_str" : "1566201",
      "id" : 1566201
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 8, 20 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320595513357516800",
  "geo" : { },
  "id_str" : "320596750844968961",
  "in_reply_to_user_id" : 1566201,
  "text" : "@zapnap @bcardarella nothing is stopping employers from sponsoring people to work on it. I have no interest in doing OSS full time though",
  "id" : 320596750844968961,
  "in_reply_to_status_id" : 320595513357516800,
  "created_at" : "2013-04-06 17:59:56 +0000",
  "in_reply_to_screen_name" : "zapnap",
  "in_reply_to_user_id_str" : "1566201",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nap.tld, ltd.",
      "screen_name" : "zapnap",
      "indices" : [ 0, 7 ],
      "id_str" : "1566201",
      "id" : 1566201
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 8, 20 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Brian Rose",
      "screen_name" : "heimidal",
      "indices" : [ 114, 123 ],
      "id_str" : "1399981",
      "id" : 1399981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320594524432912384",
  "geo" : { },
  "id_str" : "320595225930256385",
  "in_reply_to_user_id" : 1566201,
  "text" : "@zapnap @bcardarella there\u2019s no staff, it\u2019s all volunteer. Just get involved, listen, be patient, contribute. \/cc @heimidal",
  "id" : 320595225930256385,
  "in_reply_to_status_id" : 320594524432912384,
  "created_at" : "2013-04-06 17:53:52 +0000",
  "in_reply_to_screen_name" : "zapnap",
  "in_reply_to_user_id_str" : "1566201",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320593318109147137",
  "geo" : { },
  "id_str" : "320593911020154883",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella that\u2019s the easy out.",
  "id" : 320593911020154883,
  "in_reply_to_status_id" : 320593318109147137,
  "created_at" : "2013-04-06 17:48:39 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320551091202838528",
  "geo" : { },
  "id_str" : "320589958123503617",
  "in_reply_to_user_id" : 370894106,
  "text" : "@22bytes everyone starts at zero :)",
  "id" : 320589958123503617,
  "in_reply_to_status_id" : 320551091202838528,
  "created_at" : "2013-04-06 17:32:56 +0000",
  "in_reply_to_screen_name" : "bufferable",
  "in_reply_to_user_id_str" : "370894106",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Scalzi",
      "screen_name" : "scalzi",
      "indices" : [ 3, 10 ],
      "id_str" : "14202817",
      "id" : 14202817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/f1KPP2GVAh",
      "expanded_url" : "http:\/\/imgur.com\/f96q6W9",
      "display_url" : "imgur.com\/f96q6W9"
    } ]
  },
  "geo" : { },
  "id_str" : "320571911321034752",
  "text" : "RT @scalzi: Whoa. http:\/\/t.co\/f1KPP2GVAh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/f1KPP2GVAh",
        "expanded_url" : "http:\/\/imgur.com\/f96q6W9",
        "display_url" : "imgur.com\/f96q6W9"
      } ]
    },
    "geo" : { },
    "id_str" : "320334929001058304",
    "text" : "Whoa. http:\/\/t.co\/f1KPP2GVAh",
    "id" : 320334929001058304,
    "created_at" : "2013-04-06 00:39:33 +0000",
    "user" : {
      "name" : "John Scalzi",
      "screen_name" : "scalzi",
      "protected" : false,
      "id_str" : "14202817",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3475245194\/59992708a306aaa836bf1699f8b47d5d_normal.png",
      "id" : 14202817,
      "verified" : true
    }
  },
  "id" : 320571911321034752,
  "created_at" : "2013-04-06 16:21:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    }, {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 7, 23 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320548306356948992",
  "geo" : { },
  "id_str" : "320548645789396992",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine @rubygems_status didn't know about CloudWatch...neat. I'll leave it up to the ops team to figure out what they want to use.",
  "id" : 320548645789396992,
  "in_reply_to_status_id" : 320548306356948992,
  "created_at" : "2013-04-06 14:48:47 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 14, 26 ],
      "id_str" : "19627341",
      "id" : 19627341
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 31, 42 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/wCsxAY8phr",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "320548128522649602",
  "text" : "Big thanks to @dwradcliffe and @samkottler for responding this morning to the http:\/\/t.co\/wCsxAY8phr issues. Time to wake up finally\u2026",
  "id" : 320548128522649602,
  "created_at" : "2013-04-06 14:46:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320547984213413888",
  "text" : "RT @rubygems_status: Disk usage was at 100% and preventing gem pushes and emails. Should be fixed now, and more alerts will be going in  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "320547947869790208",
    "text" : "Disk usage was at 100% and preventing gem pushes and emails. Should be fixed now, and more alerts will be going in tonight!",
    "id" : 320547947869790208,
    "created_at" : "2013-04-06 14:46:00 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 320547984213413888,
  "created_at" : "2013-04-06 14:46:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordi Bunster",
      "screen_name" : "notlaforge",
      "indices" : [ 0, 11 ],
      "id_str" : "11457022",
      "id" : 11457022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320543619205439488",
  "geo" : { },
  "id_str" : "320545987896672256",
  "in_reply_to_user_id" : 11457022,
  "text" : "@notlaforge the latter.",
  "id" : 320545987896672256,
  "in_reply_to_status_id" : 320543619205439488,
  "created_at" : "2013-04-06 14:38:13 +0000",
  "in_reply_to_screen_name" : "notlaforge",
  "in_reply_to_user_id_str" : "11457022",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Siener",
      "screen_name" : "gsiener",
      "indices" : [ 0, 8 ],
      "id_str" : "729623",
      "id" : 729623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320540144509779968",
  "geo" : { },
  "id_str" : "320540692671770626",
  "in_reply_to_user_id" : 729623,
  "text" : "@gsiener What?",
  "id" : 320540692671770626,
  "in_reply_to_status_id" : 320540144509779968,
  "created_at" : "2013-04-06 14:17:11 +0000",
  "in_reply_to_screen_name" : "gsiener",
  "in_reply_to_user_id_str" : "729623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/33aYAp8SaM",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "320539029936427008",
  "text" : "The http:\/\/t.co\/33aYAp8SaM Bus Factor is still 1. I don't know why I can't change this.",
  "id" : 320539029936427008,
  "created_at" : "2013-04-06 14:10:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Smith",
      "screen_name" : "benjamin_smith",
      "indices" : [ 0, 15 ],
      "id_str" : "17323187",
      "id" : 17323187
    }, {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 16, 24 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320347403351912448",
  "geo" : { },
  "id_str" : "320350503823360002",
  "in_reply_to_user_id" : 17323187,
  "text" : "@benjamin_smith @bascule once again proving my theory that rubygems is too big to rely on personal trust :(",
  "id" : 320350503823360002,
  "in_reply_to_status_id" : 320347403351912448,
  "created_at" : "2013-04-06 01:41:26 +0000",
  "in_reply_to_screen_name" : "benjamin_smith",
  "in_reply_to_user_id_str" : "17323187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Mongeau",
      "screen_name" : "halogenandtoast",
      "indices" : [ 0, 16 ],
      "id_str" : "15428948",
      "id" : 15428948
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 17, 31 ],
      "id_str" : "10293122",
      "id" : 10293122
    }, {
      "name" : "Matt Binder",
      "screen_name" : "MattBinder",
      "indices" : [ 70, 81 ],
      "id_str" : "14931637",
      "id" : 14931637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320343719867977730",
  "geo" : { },
  "id_str" : "320344071115784193",
  "in_reply_to_user_id" : 15428948,
  "text" : "@halogenandtoast @joshuaclayton oh this is just scraping the surface. @MattBinder has been dredging this shit up for months.",
  "id" : 320344071115784193,
  "in_reply_to_status_id" : 320343719867977730,
  "created_at" : "2013-04-06 01:15:52 +0000",
  "in_reply_to_screen_name" : "halogenandtoast",
  "in_reply_to_user_id_str" : "15428948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320341613056495617",
  "geo" : { },
  "id_str" : "320341831474888704",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d \u0CA0_\u0CA0",
  "id" : 320341831474888704,
  "in_reply_to_status_id" : 320341613056495617,
  "created_at" : "2013-04-06 01:06:58 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pingdom",
      "screen_name" : "pingdom",
      "indices" : [ 58, 66 ],
      "id_str" : "15674759",
      "id" : 15674759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/33aYAp8SaM",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/A2p1OwUu5o",
      "expanded_url" : "http:\/\/uptime.rubygems.org\/131647\/2013\/03",
      "display_url" : "uptime.rubygems.org\/131647\/2013\/03"
    } ]
  },
  "geo" : { },
  "id_str" : "320341412409397248",
  "text" : "100% http:\/\/t.co\/33aYAp8SaM uptime for March according to @Pingdom. Absolutely awesome stuff. http:\/\/t.co\/A2p1OwUu5o",
  "id" : 320341412409397248,
  "created_at" : "2013-04-06 01:05:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/320325951923818496\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/rI58GS2sUI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHIGwZECEAAQbAR.jpg",
      "id_str" : "320325951928012800",
      "id" : 320325951928012800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHIGwZECEAAQbAR.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rI58GS2sUI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320325951923818496",
  "text" : "Space Dice! http:\/\/t.co\/rI58GS2sUI",
  "id" : 320325951923818496,
  "created_at" : "2013-04-06 00:03:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 11, 22 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 75, 90 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320291846590967808",
  "geo" : { },
  "id_str" : "320291992162693120",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald @ashedryden We need to make sure there's a board game thing for @nickelcityruby",
  "id" : 320291992162693120,
  "in_reply_to_status_id" : 320291846590967808,
  "created_at" : "2013-04-05 21:48:56 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320290461229133824",
  "text" : "Yes, I just signed up for a social network for dogs. Yes, I feel no shame about this decision.",
  "id" : 320290461229133824,
  "created_at" : "2013-04-05 21:42:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pack",
      "screen_name" : "pack",
      "indices" : [ 57, 62 ],
      "id_str" : "1132315826",
      "id" : 1132315826
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ilovemydog",
      "indices" : [ 45, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/9DWHB0TOWa",
      "expanded_url" : "http:\/\/packlove.com\/geddy",
      "display_url" : "packlove.com\/geddy"
    } ]
  },
  "geo" : { },
  "id_str" : "320289963000356866",
  "text" : "Geddy is now on Pack! http:\/\/t.co\/9DWHB0TOWa #ilovemydog @pack",
  "id" : 320289963000356866,
  "created_at" : "2013-04-05 21:40:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "John Bintz",
      "screen_name" : "johnbintz",
      "indices" : [ 9, 19 ],
      "id_str" : "14327291",
      "id" : 14327291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/UXzxI33k5i",
      "expanded_url" : "http:\/\/guides.rubygems.org\/specification-reference\/#description",
      "display_url" : "guides.rubygems.org\/specification-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "320278207477727232",
  "geo" : { },
  "id_str" : "320278571522330624",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius @johnbintz http:\/\/t.co\/UXzxI33k5i the docs.* site is long dead...need to redirect :(",
  "id" : 320278571522330624,
  "in_reply_to_status_id" : 320278207477727232,
  "created_at" : "2013-04-05 20:55:36 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Bintz",
      "screen_name" : "johnbintz",
      "indices" : [ 0, 10 ],
      "id_str" : "14327291",
      "id" : 14327291
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 11, 19 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/33aYAp8SaM",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "320276374776598529",
  "geo" : { },
  "id_str" : "320276788628553728",
  "in_reply_to_user_id" : 14327291,
  "text" : "@johnbintz @headius personally I dont think you should have READMEs on http:\/\/t.co\/33aYAp8SaM. Let github worry about this.",
  "id" : 320276788628553728,
  "in_reply_to_status_id" : 320276374776598529,
  "created_at" : "2013-04-05 20:48:31 +0000",
  "in_reply_to_screen_name" : "johnbintz",
  "in_reply_to_user_id_str" : "14327291",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320270772264398848",
  "geo" : { },
  "id_str" : "320271513406287873",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius :( This is a mess. I don't understand why we ever started supporting this. Or why it's a thing. Just makes me sad.",
  "id" : 320271513406287873,
  "in_reply_to_status_id" : 320270772264398848,
  "created_at" : "2013-04-05 20:27:33 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/qkiOCKywDY",
      "expanded_url" : "http:\/\/api.rubyonrails.org\/classes\/ActiveSupport\/MessageVerifier.html",
      "display_url" : "api.rubyonrails.org\/classes\/Active\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "320269993306619904",
  "text" : "Going on ~5 years of Rails and still finding stuff I had no idea existed. http:\/\/t.co\/qkiOCKywDY",
  "id" : 320269993306619904,
  "created_at" : "2013-04-05 20:21:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/uqsXRCj7dG",
      "expanded_url" : "http:\/\/openhack.github.io\/",
      "display_url" : "openhack.github.io"
    } ]
  },
  "geo" : { },
  "id_str" : "320262247991615488",
  "text" : "Well, hello there http:\/\/t.co\/uqsXRCj7dG !",
  "id" : 320262247991615488,
  "created_at" : "2013-04-05 19:50:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    }, {
      "name" : "Dave Lee",
      "screen_name" : "kastiglione",
      "indices" : [ 5, 17 ],
      "id_str" : "337785394",
      "id" : 337785394
    }, {
      "name" : "Clay Allsopp",
      "screen_name" : "clayallsopp",
      "indices" : [ 18, 30 ],
      "id_str" : "48464282",
      "id" : 48464282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320233138821406722",
  "geo" : { },
  "id_str" : "320233899190013952",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz @kastiglione @clayallsopp YES! YES YES YES",
  "id" : 320233899190013952,
  "in_reply_to_status_id" : 320233138821406722,
  "created_at" : "2013-04-05 17:58:05 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320231623431946240",
  "geo" : { },
  "id_str" : "320231986964860928",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza I've been addicted to Nimble Quest...ugh.",
  "id" : 320231986964860928,
  "in_reply_to_status_id" : 320231623431946240,
  "created_at" : "2013-04-05 17:50:29 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clay Allsopp",
      "screen_name" : "clayallsopp",
      "indices" : [ 3, 15 ],
      "id_str" : "48464282",
      "id" : 48464282
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 96, 107 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/U0oSROaT6r",
      "expanded_url" : "https:\/\/github.com\/clayallsopp\/motion-require",
      "display_url" : "github.com\/clayallsopp\/mo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "320220399491227648",
  "text" : "RT @clayallsopp: Whipped up Motion-Require, a gem to replicate `require`-esque functionality in @RubyMotion https:\/\/t.co\/U0oSROaT6r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyMotion",
        "screen_name" : "RubyMotion",
        "indices" : [ 79, 90 ],
        "id_str" : "381521407",
        "id" : 381521407
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/U0oSROaT6r",
        "expanded_url" : "https:\/\/github.com\/clayallsopp\/motion-require",
        "display_url" : "github.com\/clayallsopp\/mo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "320198152361738240",
    "text" : "Whipped up Motion-Require, a gem to replicate `require`-esque functionality in @RubyMotion https:\/\/t.co\/U0oSROaT6r",
    "id" : 320198152361738240,
    "created_at" : "2013-04-05 15:36:03 +0000",
    "user" : {
      "name" : "Clay Allsopp",
      "screen_name" : "clayallsopp",
      "protected" : false,
      "id_str" : "48464282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000117720193\/f274bdf193101039d3b8c71308a4b25d_normal.jpeg",
      "id" : 48464282,
      "verified" : false
    }
  },
  "id" : 320220399491227648,
  "created_at" : "2013-04-05 17:04:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/PkNrvpKXXE",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/id599139477",
      "display_url" : "itunes.apple.com\/us\/app\/id59913\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "320220135048744960",
  "text" : "RT @jasonfried: The updated Basecamp iPhone app now supports Basecamp Classic, too: https:\/\/t.co\/PkNrvpKXXE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/PkNrvpKXXE",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/id599139477",
        "display_url" : "itunes.apple.com\/us\/app\/id59913\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "320218693789421568",
    "text" : "The updated Basecamp iPhone app now supports Basecamp Classic, too: https:\/\/t.co\/PkNrvpKXXE",
    "id" : 320218693789421568,
    "created_at" : "2013-04-05 16:57:40 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 320220135048744960,
  "created_at" : "2013-04-05 17:03:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 0, 13 ],
      "id_str" : "23820237",
      "id" : 23820237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320162534042783744",
  "geo" : { },
  "id_str" : "320218078787022848",
  "in_reply_to_user_id" : 23820237,
  "text" : "@IanCAnderson reinstalled and didn\u2019t see this. Strange!",
  "id" : 320218078787022848,
  "in_reply_to_status_id" : 320162534042783744,
  "created_at" : "2013-04-05 16:55:14 +0000",
  "in_reply_to_screen_name" : "IanCAnderson",
  "in_reply_to_user_id_str" : "23820237",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/320023471155453952\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/1PTjrUKjUM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHDzpsaCIAAQMD_.png",
      "id_str" : "320023471163842560",
      "id" : 320023471163842560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHDzpsaCIAAQMD_.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/1PTjrUKjUM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/nd3e7hhSCp",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/basecamp-official-app\/id599139477?mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/basecam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "320023471155453952",
  "text" : "Something just landed on the App Store\u2026 https:\/\/t.co\/nd3e7hhSCp http:\/\/t.co\/1PTjrUKjUM",
  "id" : 320023471155453952,
  "created_at" : "2013-04-05 04:01:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 0, 15 ],
      "id_str" : "13639982",
      "id" : 13639982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320014278100910082",
  "geo" : { },
  "id_str" : "320022016369520641",
  "in_reply_to_user_id" : 13639982,
  "text" : "@MarkVillacampa thanks, I\u2019ll take a look!",
  "id" : 320022016369520641,
  "in_reply_to_status_id" : 320014278100910082,
  "created_at" : "2013-04-05 03:56:09 +0000",
  "in_reply_to_screen_name" : "MarkVillacampa",
  "in_reply_to_user_id_str" : "13639982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 0, 9 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "Clay Allsopp",
      "screen_name" : "clayallsopp",
      "indices" : [ 10, 22 ],
      "id_str" : "48464282",
      "id" : 48464282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320018904372084737",
  "geo" : { },
  "id_str" : "320021514005147650",
  "in_reply_to_user_id" : 14881835,
  "text" : "@rubygems @clayallsopp I see what you did there!!!",
  "id" : 320021514005147650,
  "in_reply_to_status_id" : 320018904372084737,
  "created_at" : "2013-04-05 03:54:09 +0000",
  "in_reply_to_screen_name" : "rubygems",
  "in_reply_to_user_id_str" : "14881835",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel",
      "screen_name" : "JoelMcCracken",
      "indices" : [ 0, 14 ],
      "id_str" : "13053562",
      "id" : 13053562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319986631195127812",
  "geo" : { },
  "id_str" : "319986914474213376",
  "in_reply_to_user_id" : 13053562,
  "text" : "@JoelMcCracken terrible Dune movie reference. Worth a reread though!",
  "id" : 319986914474213376,
  "in_reply_to_status_id" : 319986631195127812,
  "created_at" : "2013-04-05 01:36:40 +0000",
  "in_reply_to_screen_name" : "JoelMcCracken",
  "in_reply_to_user_id_str" : "13053562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pittsburgh Ruby",
      "screen_name" : "pghrb",
      "indices" : [ 17, 23 ],
      "id_str" : "81523571",
      "id" : 81523571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319979534394998784",
  "text" : "Had a lot of fun @pghrb tonight. Hope yinz had a good time!",
  "id" : 319979534394998784,
  "created_at" : "2013-04-05 01:07:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 0, 6 ],
      "id_str" : "18673",
      "id" : 18673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319907347902365696",
  "geo" : { },
  "id_str" : "319945673330012162",
  "in_reply_to_user_id" : 18673,
  "text" : "@aeden hell YES! As a customer and fan I am really excited for you.",
  "id" : 319945673330012162,
  "in_reply_to_status_id" : 319907347902365696,
  "created_at" : "2013-04-04 22:52:47 +0000",
  "in_reply_to_screen_name" : "aeden",
  "in_reply_to_user_id_str" : "18673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    }, {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 7, 16 ],
      "id_str" : "7284122",
      "id" : 7284122
    }, {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 17, 24 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319900662055968768",
  "geo" : { },
  "id_str" : "319901342393053187",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH @fowlduck @elight SLAVES TO POSTGRES, GOD OF VIM CHAPTER IV: REIN FORTRESS",
  "id" : 319901342393053187,
  "in_reply_to_status_id" : 319900662055968768,
  "created_at" : "2013-04-04 19:56:38 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 8, 18 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319899731855818753",
  "geo" : { },
  "id_str" : "319900323651149824",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky @aquaranto actually this has toned down lately. i might be wrong though.",
  "id" : 319900323651149824,
  "in_reply_to_status_id" : 319899731855818753,
  "created_at" : "2013-04-04 19:52:35 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin R. Haskell",
      "screen_name" : "benizi",
      "indices" : [ 0, 7 ],
      "id_str" : "17979623",
      "id" : 17979623
    }, {
      "name" : "4moms",
      "screen_name" : "4moms",
      "indices" : [ 8, 14 ],
      "id_str" : "30026404",
      "id" : 30026404
    }, {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 44, 52 ],
      "id_str" : "12145232",
      "id" : 12145232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319899616340504576",
  "geo" : { },
  "id_str" : "319900199495561216",
  "in_reply_to_user_id" : 17979623,
  "text" : "@benizi @4moms this is mostly @billyist and @CDMoyer's fault...The Great State of Pennsylvania should not apologize for its...great offices.",
  "id" : 319900199495561216,
  "in_reply_to_status_id" : 319899616340504576,
  "created_at" : "2013-04-04 19:52:05 +0000",
  "in_reply_to_screen_name" : "benizi",
  "in_reply_to_user_id_str" : "17979623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Block Club",
      "screen_name" : "BlockClub",
      "indices" : [ 0, 10 ],
      "id_str" : "21003240",
      "id" : 21003240
    }, {
      "name" : "Justin Reese",
      "screen_name" : "justinxreese",
      "indices" : [ 47, 60 ],
      "id_str" : "14255877",
      "id" : 14255877
    }, {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 61, 75 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319893701616873473",
  "geo" : { },
  "id_str" : "319894327465754626",
  "in_reply_to_user_id" : 21003240,
  "text" : "@BlockClub Oh snap...I'm very close today. \/cc @justinxreese @Carols10cents",
  "id" : 319894327465754626,
  "in_reply_to_status_id" : 319893701616873473,
  "created_at" : "2013-04-04 19:28:45 +0000",
  "in_reply_to_screen_name" : "BlockClub",
  "in_reply_to_user_id_str" : "21003240",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319893702115987456",
  "text" : "boon\u00B7dog\u00B7gle [boon-dog-uh], noun, verb: work of little or no value done merely to keep or look busy.",
  "id" : 319893702115987456,
  "created_at" : "2013-04-04 19:26:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/0piDysMWUk",
      "expanded_url" : "http:\/\/www.codinghorror.com\/blog\/2005\/02\/ivory-tower-development.html",
      "display_url" : "codinghorror.com\/blog\/2005\/02\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "319893345486917633",
  "text" : "Boondoggle: the opposite of extracted (from a shipped product). Still relevant for any software library\/framework. http:\/\/t.co\/0piDysMWUk",
  "id" : 319893345486917633,
  "created_at" : "2013-04-04 19:24:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319892447738073088",
  "geo" : { },
  "id_str" : "319893078884364288",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt First i've heard of them. Neat.",
  "id" : 319893078884364288,
  "in_reply_to_status_id" : 319892447738073088,
  "created_at" : "2013-04-04 19:23:47 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 14, 28 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319891871365210112",
  "geo" : { },
  "id_str" : "319891944996220928",
  "in_reply_to_user_id" : 5743852,
  "text" : "@steveklabnik @garybernhardt Without the bun, of course.",
  "id" : 319891944996220928,
  "in_reply_to_status_id" : 319891871365210112,
  "created_at" : "2013-04-04 19:19:17 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 14, 28 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319891067757539328",
  "geo" : { },
  "id_str" : "319891871365210112",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @garybernhardt I can't hear you over the sound of digesting the protein from the steak sandwich i had for lunch",
  "id" : 319891871365210112,
  "in_reply_to_status_id" : 319891067757539328,
  "created_at" : "2013-04-04 19:19:00 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 15, 28 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/WXjCdzgJ8A",
      "expanded_url" : "http:\/\/goo.gl\/Snq9O",
      "display_url" : "goo.gl\/Snq9O"
    } ]
  },
  "in_reply_to_status_id_str" : "319886416207290370",
  "geo" : { },
  "id_str" : "319886778255437825",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt @steveklabnik i'm pretty terrible too, even on keto. http:\/\/t.co\/WXjCdzgJ8A is my guide.",
  "id" : 319886778255437825,
  "in_reply_to_status_id" : 319886416207290370,
  "created_at" : "2013-04-04 18:58:45 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Reese",
      "screen_name" : "justinxreese",
      "indices" : [ 0, 13 ],
      "id_str" : "14255877",
      "id" : 14255877
    }, {
      "name" : "Dan Carper",
      "screen_name" : "dan_carper",
      "indices" : [ 14, 25 ],
      "id_str" : "129384476",
      "id" : 129384476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319879162359869440",
  "geo" : { },
  "id_str" : "319879421022588928",
  "in_reply_to_user_id" : 14255877,
  "text" : "@justinxreese @dan_carper \u0CA0_\u0CA0",
  "id" : 319879421022588928,
  "in_reply_to_status_id" : 319879162359869440,
  "created_at" : "2013-04-04 18:29:31 +0000",
  "in_reply_to_screen_name" : "justinxreese",
  "in_reply_to_user_id_str" : "14255877",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 0, 13 ],
      "id_str" : "23820237",
      "id" : 23820237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319865193196818432",
  "geo" : { },
  "id_str" : "319868201192263680",
  "in_reply_to_user_id" : 23820237,
  "text" : "@IanCAnderson Maybe...not dozens.",
  "id" : 319868201192263680,
  "in_reply_to_status_id" : 319865193196818432,
  "created_at" : "2013-04-04 17:44:56 +0000",
  "in_reply_to_screen_name" : "IanCAnderson",
  "in_reply_to_user_id_str" : "23820237",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 11, 22 ],
      "id_str" : "14188391",
      "id" : 14188391
    }, {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 23, 34 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319656998272634880",
  "geo" : { },
  "id_str" : "319657845274599424",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @benjaminws @joefiorini I accept this devil\u2019s bargain.",
  "id" : 319657845274599424,
  "in_reply_to_status_id" : 319656998272634880,
  "created_at" : "2013-04-04 03:49:03 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dare Obasanjo",
      "screen_name" : "Carnage4Life",
      "indices" : [ 3, 16 ],
      "id_str" : "11336782",
      "id" : 11336782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/Ie2kVdVjQC",
      "expanded_url" : "http:\/\/prng.net\/blink-faq.html",
      "display_url" : "prng.net\/blink-faq.html"
    } ]
  },
  "geo" : { },
  "id_str" : "319646229497774082",
  "text" : "RT @Carnage4Life: A no-bullshit translation of today's Google Blink announcement - http:\/\/t.co\/Ie2kVdVjQC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/Ie2kVdVjQC",
        "expanded_url" : "http:\/\/prng.net\/blink-faq.html",
        "display_url" : "prng.net\/blink-faq.html"
      } ]
    },
    "geo" : { },
    "id_str" : "319621876127244288",
    "text" : "A no-bullshit translation of today's Google Blink announcement - http:\/\/t.co\/Ie2kVdVjQC",
    "id" : 319621876127244288,
    "created_at" : "2013-04-04 01:26:08 +0000",
    "user" : {
      "name" : "Dare Obasanjo",
      "screen_name" : "Carnage4Life",
      "protected" : false,
      "id_str" : "11336782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1543890640\/profile_picture_normal.jpg",
      "id" : 11336782,
      "verified" : false
    }
  },
  "id" : 319646229497774082,
  "created_at" : "2013-04-04 03:02:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 0, 11 ],
      "id_str" : "14188391",
      "id" : 14188391
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 12, 22 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 42, 53 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319605462964252672",
  "geo" : { },
  "id_str" : "319638068963459072",
  "in_reply_to_user_id" : 14188391,
  "text" : "@benjaminws @aspleenic sweet. Gonna bring @joefiorini too?",
  "id" : 319638068963459072,
  "in_reply_to_status_id" : 319605462964252672,
  "created_at" : "2013-04-04 02:30:28 +0000",
  "in_reply_to_screen_name" : "benjaminws",
  "in_reply_to_user_id_str" : "14188391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319568144039555073",
  "geo" : { },
  "id_str" : "319569165507764226",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt not trying to pry, but do you have non-programming related hobbies? :)",
  "id" : 319569165507764226,
  "in_reply_to_status_id" : 319568144039555073,
  "created_at" : "2013-04-03 21:56:41 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rey Bango",
      "screen_name" : "reybango",
      "indices" : [ 0, 9 ],
      "id_str" : "1589691",
      "id" : 1589691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319565133816934402",
  "geo" : { },
  "id_str" : "319565684080250880",
  "in_reply_to_user_id" : 1589691,
  "text" : "@reybango because after a few years of converging on webkit, things are going the other way again. Oh well. :(",
  "id" : 319565684080250880,
  "in_reply_to_status_id" : 319565133816934402,
  "created_at" : "2013-04-03 21:42:50 +0000",
  "in_reply_to_screen_name" : "reybango",
  "in_reply_to_user_id_str" : "1589691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 0, 3 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319563492090839040",
  "geo" : { },
  "id_str" : "319564727556653056",
  "in_reply_to_user_id" : 937561,
  "text" : "@jm it's all about control :(",
  "id" : 319564727556653056,
  "in_reply_to_status_id" : 319563492090839040,
  "created_at" : "2013-04-03 21:39:02 +0000",
  "in_reply_to_screen_name" : "jm",
  "in_reply_to_user_id_str" : "937561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/rMBroBOUXI",
      "expanded_url" : "http:\/\/blog.chromium.org\/2013\/04\/blink-rendering-engine-for-chromium.html",
      "display_url" : "blog.chromium.org\/2013\/04\/blink-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "319559826189471744",
  "text" : "Extreme sad: http:\/\/t.co\/rMBroBOUXI",
  "id" : 319559826189471744,
  "created_at" : "2013-04-03 21:19:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/D9TZuzPVlf",
      "expanded_url" : "http:\/\/www.brucelawson.co.uk\/2013\/hello-blink\/",
      "display_url" : "brucelawson.co.uk\/2013\/hello-bli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "319559263091580928",
  "text" : "How is Blink a good thing? http:\/\/t.co\/D9TZuzPVlf What is wrong with Webkit?",
  "id" : 319559263091580928,
  "created_at" : "2013-04-03 21:17:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319556741878657024",
  "geo" : { },
  "id_str" : "319557115859591168",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza wtf?",
  "id" : 319557115859591168,
  "in_reply_to_status_id" : 319556741878657024,
  "created_at" : "2013-04-03 21:08:48 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Kim",
      "screen_name" : "dankim",
      "indices" : [ 0, 7 ],
      "id_str" : "7979212",
      "id" : 7979212
    }, {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 8, 12 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319553549530968064",
  "geo" : { },
  "id_str" : "319554385715806209",
  "in_reply_to_user_id" : 7979212,
  "text" : "@dankim @rjs AFAIK Adium doesn't have native iOS apps...my concern was keeping conversations going across devices.",
  "id" : 319554385715806209,
  "in_reply_to_status_id" : 319553549530968064,
  "created_at" : "2013-04-03 20:57:57 +0000",
  "in_reply_to_screen_name" : "dankim",
  "in_reply_to_user_id_str" : "7979212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 0, 9 ],
      "id_str" : "57753",
      "id" : 57753
    }, {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 10, 21 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319540147559477249",
  "geo" : { },
  "id_str" : "319540972931383298",
  "in_reply_to_user_id" : 57753,
  "text" : "@blowmage @themcgruff Just don't make him don the secret service agent suit",
  "id" : 319540972931383298,
  "in_reply_to_status_id" : 319540147559477249,
  "created_at" : "2013-04-03 20:04:39 +0000",
  "in_reply_to_screen_name" : "blowmage",
  "in_reply_to_user_id_str" : "57753",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 9, 20 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 32, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/JTDvp1Gc1h",
      "expanded_url" : "http:\/\/mtnwestrubyconf.org\/",
      "display_url" : "mtnwestrubyconf.org"
    } ]
  },
  "geo" : { },
  "id_str" : "319539148685967360",
  "text" : "Watching @themcgruff kill it at #mwrc! http:\/\/t.co\/JTDvp1Gc1h",
  "id" : 319539148685967360,
  "created_at" : "2013-04-03 19:57:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Van Cleef",
      "screen_name" : "joshvc",
      "indices" : [ 0, 7 ],
      "id_str" : "15422369",
      "id" : 15422369
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 8, 23 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319524234244263937",
  "geo" : { },
  "id_str" : "319524968012582912",
  "in_reply_to_user_id" : 15422369,
  "text" : "@joshvc @nickelcityruby is September, Number One is November. It's going to be an awesome fall!",
  "id" : 319524968012582912,
  "in_reply_to_status_id" : 319524234244263937,
  "created_at" : "2013-04-03 19:01:03 +0000",
  "in_reply_to_screen_name" : "joshvc",
  "in_reply_to_user_id_str" : "15422369",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 119, 129 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319523951825002496",
  "text" : "Just realized that conference organizing is a lot like planning a wedding, except I'm the bridezilla. Thanks for this, @aquaranto.",
  "id" : 319523951825002496,
  "created_at" : "2013-04-03 18:57:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 0, 4 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319492363326193664",
  "geo" : { },
  "id_str" : "319494278843875328",
  "in_reply_to_user_id" : 10079052,
  "text" : "@rjs this is why I\u2019m back on Trillian.",
  "id" : 319494278843875328,
  "in_reply_to_status_id" : 319492363326193664,
  "created_at" : "2013-04-03 16:59:06 +0000",
  "in_reply_to_screen_name" : "rjs",
  "in_reply_to_user_id_str" : "10079052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 47, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/MO5MZT7rI6",
      "expanded_url" : "http:\/\/goo.gl\/fWT57",
      "display_url" : "goo.gl\/fWT57"
    } ]
  },
  "geo" : { },
  "id_str" : "319481810755133440",
  "text" : "Want to help some folks out with their apps at #railsconf? Sign up here to volunteer for the Helpdesk: http:\/\/t.co\/MO5MZT7rI6",
  "id" : 319481810755133440,
  "created_at" : "2013-04-03 16:09:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Priddle",
      "screen_name" : "itspriddle",
      "indices" : [ 0, 11 ],
      "id_str" : "14104108",
      "id" : 14104108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319472023145435138",
  "geo" : { },
  "id_str" : "319472133967327232",
  "in_reply_to_user_id" : 14104108,
  "text" : "@itspriddle now this is absolute bullshit. don't you remember how terrible config.gem (and before) was?",
  "id" : 319472133967327232,
  "in_reply_to_status_id" : 319472023145435138,
  "created_at" : "2013-04-03 15:31:06 +0000",
  "in_reply_to_screen_name" : "itspriddle",
  "in_reply_to_user_id_str" : "14104108",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/0C6kAZIMW8",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/5301799",
      "display_url" : "gist.github.com\/qrush\/5301799"
    } ]
  },
  "geo" : { },
  "id_str" : "319459608857022464",
  "text" : "Pipe into bash and spring clean your repos: https:\/\/t.co\/0C6kAZIMW8",
  "id" : 319459608857022464,
  "created_at" : "2013-04-03 14:41:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319266189643771904",
  "geo" : { },
  "id_str" : "319274918028124160",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan I\u2019ve seen this before and I don\u2019t know the right way of handling it still.",
  "id" : 319274918028124160,
  "in_reply_to_status_id" : 319266189643771904,
  "created_at" : "2013-04-03 02:27:26 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319246232344219650",
  "geo" : { },
  "id_str" : "319248333350793216",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek Same!",
  "id" : 319248333350793216,
  "in_reply_to_status_id" : 319246232344219650,
  "created_at" : "2013-04-03 00:41:48 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319247909684117504",
  "geo" : { },
  "id_str" : "319248175095492609",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents wat",
  "id" : 319248175095492609,
  "in_reply_to_status_id" : 319247909684117504,
  "created_at" : "2013-04-03 00:41:10 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319236482437087232",
  "text" : "Just found that pine.fm died :(",
  "id" : 319236482437087232,
  "created_at" : "2013-04-02 23:54:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    }, {
      "name" : "Philip J. Hollenback",
      "screen_name" : "philiph",
      "indices" : [ 14, 22 ],
      "id_str" : "31693",
      "id" : 31693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/ihOaabiRFY",
      "expanded_url" : "http:\/\/nethackwiki.com\/wiki\/Brainlessness",
      "display_url" : "nethackwiki.com\/wiki\/Brainless\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "319207378413309953",
  "geo" : { },
  "id_str" : "319207676154347520",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel @philiph \"Unfortunately your brain is still gone.\" hahaha: http:\/\/t.co\/ihOaabiRFY",
  "id" : 319207676154347520,
  "in_reply_to_status_id" : 319207378413309953,
  "created_at" : "2013-04-02 22:00:15 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip J. Hollenback",
      "screen_name" : "philiph",
      "indices" : [ 0, 8 ],
      "id_str" : "31693",
      "id" : 31693
    }, {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 9, 22 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319202376395415554",
  "geo" : { },
  "id_str" : "319207121612849153",
  "in_reply_to_user_id" : 31693,
  "text" : "@philiph @jordansissel The Master Mind Flayer attaches his tentacles to your head! Your brain is eaten! Your last thought fades away.",
  "id" : 319207121612849153,
  "in_reply_to_status_id" : 319202376395415554,
  "created_at" : "2013-04-02 21:58:03 +0000",
  "in_reply_to_screen_name" : "philiph",
  "in_reply_to_user_id_str" : "31693",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin",
      "screen_name" : "embrown",
      "indices" : [ 0, 8 ],
      "id_str" : "425253989",
      "id" : 425253989
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 9, 19 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319196511185534977",
  "geo" : { },
  "id_str" : "319196834348290048",
  "in_reply_to_user_id" : 425253989,
  "text" : "@embrown @aquaranto i cant favorite this hard enough",
  "id" : 319196834348290048,
  "in_reply_to_status_id" : 319196511185534977,
  "created_at" : "2013-04-02 21:17:10 +0000",
  "in_reply_to_screen_name" : "embrown",
  "in_reply_to_user_id_str" : "425253989",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonan Scheffler",
      "screen_name" : "1337807",
      "indices" : [ 0, 8 ],
      "id_str" : "117846486",
      "id" : 117846486
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 9, 19 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319189048444985345",
  "geo" : { },
  "id_str" : "319191750453387267",
  "in_reply_to_user_id" : 117846486,
  "text" : "@1337807 @aquaranto :) thanks!!",
  "id" : 319191750453387267,
  "in_reply_to_status_id" : 319189048444985345,
  "created_at" : "2013-04-02 20:56:58 +0000",
  "in_reply_to_screen_name" : "1337807",
  "in_reply_to_user_id_str" : "117846486",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/eGXo8scLrr",
      "expanded_url" : "http:\/\/37svn.com\/3494",
      "display_url" : "37svn.com\/3494"
    } ]
  },
  "geo" : { },
  "id_str" : "319191263037517824",
  "text" : "I'm in awe of this story. Shipping a real product: http:\/\/t.co\/eGXo8scLrr",
  "id" : 319191263037517824,
  "created_at" : "2013-04-02 20:55:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Bodenner",
      "screen_name" : "ralphbod",
      "indices" : [ 0, 9 ],
      "id_str" : "89854263",
      "id" : 89854263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319186777908854784",
  "geo" : { },
  "id_str" : "319186981135450114",
  "in_reply_to_user_id" : 89854263,
  "text" : "@ralphbod wow ! congrats to you too :D",
  "id" : 319186981135450114,
  "in_reply_to_status_id" : 319186777908854784,
  "created_at" : "2013-04-02 20:38:01 +0000",
  "in_reply_to_screen_name" : "ralphbod",
  "in_reply_to_user_id_str" : "89854263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319177024545636352",
  "geo" : { },
  "id_str" : "319177314959257601",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz I think I'm already starting to feel this.",
  "id" : 319177314959257601,
  "in_reply_to_status_id" : 319177024545636352,
  "created_at" : "2013-04-02 19:59:36 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Williams",
      "screen_name" : "j_m_williams",
      "indices" : [ 0, 13 ],
      "id_str" : "16210953",
      "id" : 16210953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319171857498652674",
  "geo" : { },
  "id_str" : "319172206900965378",
  "in_reply_to_user_id" : 16210953,
  "text" : "@j_m_williams Woot! You're outnumbered still.",
  "id" : 319172206900965378,
  "in_reply_to_status_id" : 319171857498652674,
  "created_at" : "2013-04-02 19:39:18 +0000",
  "in_reply_to_screen_name" : "j_m_williams",
  "in_reply_to_user_id_str" : "16210953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 0, 12 ],
      "id_str" : "10035582",
      "id" : 10035582
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 59, 69 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319166857171058689",
  "geo" : { },
  "id_str" : "319167132959133696",
  "in_reply_to_user_id" : 10035582,
  "text" : "@rocketslide @JZ Sounds like a good middle name to me. \/cc @aquaranto",
  "id" : 319167132959133696,
  "in_reply_to_status_id" : 319166857171058689,
  "created_at" : "2013-04-02 19:19:08 +0000",
  "in_reply_to_screen_name" : "rocketslide",
  "in_reply_to_user_id_str" : "10035582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319164764683112449",
  "geo" : { },
  "id_str" : "319166131124465665",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck Our theory is a jellybean, given easter.",
  "id" : 319166131124465665,
  "in_reply_to_status_id" : 319164764683112449,
  "created_at" : "2013-04-02 19:15:10 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 70, 80 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/E0ErO71zob",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/status\/316596679333785600",
      "display_url" : "twitter.com\/qrush\/status\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "319165673836269568",
  "text" : "Also, the \"amazing\" thing (https:\/\/t.co\/E0ErO71zob) was I first heard @aquaranto and mine's new addition (and heartbeat!) via FaceTime.",
  "id" : 319165673836269568,
  "created_at" : "2013-04-02 19:13:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319163674696749056",
  "geo" : { },
  "id_str" : "319164248414642178",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck haha yes :)",
  "id" : 319164248414642178,
  "in_reply_to_status_id" : 319163674696749056,
  "created_at" : "2013-04-02 19:07:41 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/319163219027558400\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/cKfPd2GV2a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BG3lQbfCAAEe6EN.jpg",
      "id_str" : "319163219031752705",
      "id" : 319163219031752705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BG3lQbfCAAEe6EN.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/cKfPd2GV2a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319163219027558400",
  "text" : ":baby: :soon: :heavy_exclamation_mark: http:\/\/t.co\/cKfPd2GV2a",
  "id" : 319163219027558400,
  "created_at" : "2013-04-02 19:03:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 9, 18 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/FJFrv7bWO3",
      "expanded_url" : "http:\/\/openhack.github.com\/buffalo\/",
      "display_url" : "openhack.github.com\/buffalo\/"
    } ]
  },
  "geo" : { },
  "id_str" : "319155261510144000",
  "text" : "Our 14th @OpenHack Buffalo meeting is tonight! http:\/\/t.co\/FJFrv7bWO3",
  "id" : 319155261510144000,
  "created_at" : "2013-04-02 18:31:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Kontny",
      "screen_name" : "natekontny",
      "indices" : [ 5, 16 ],
      "id_str" : "17386551",
      "id" : 17386551
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 25, 36 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/xDMHZA5dG9",
      "expanded_url" : "http:\/\/lifehacker.com\/5993339\/draft-is-a-writing-app-with-serious-version-and-draft-control",
      "display_url" : "lifehacker.com\/5993339\/draft-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "319149147527712768",
  "text" : "Hey, @natekontny, I told @kevinpurdy about Draft...and... http:\/\/t.co\/xDMHZA5dG9",
  "id" : 319149147527712768,
  "created_at" : "2013-04-02 18:07:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0F3C \u3064 \u25D5_\u25D5 \u0F3D\u3064",
      "screen_name" : "julienXX",
      "indices" : [ 0, 9 ],
      "id_str" : "15442621",
      "id" : 15442621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319121345185198080",
  "geo" : { },
  "id_str" : "319122006807281665",
  "in_reply_to_user_id" : 15442621,
  "text" : "@julienXX i'd take a look at the example in the repo and read the visual format syntax page. Definitely is doable!",
  "id" : 319122006807281665,
  "in_reply_to_status_id" : 319121345185198080,
  "created_at" : "2013-04-02 16:19:50 +0000",
  "in_reply_to_screen_name" : "julienXX",
  "in_reply_to_user_id_str" : "15442621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "indices" : [ 0, 13 ],
      "id_str" : "38450774",
      "id" : 38450774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319106012911120386",
  "geo" : { },
  "id_str" : "319106487110750211",
  "in_reply_to_user_id" : 38450774,
  "text" : "@robertromito Ah yes! Great. Sounds good.",
  "id" : 319106487110750211,
  "in_reply_to_status_id" : 319106012911120386,
  "created_at" : "2013-04-02 15:18:09 +0000",
  "in_reply_to_screen_name" : "robertromito",
  "in_reply_to_user_id_str" : "38450774",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "indices" : [ 0, 13 ],
      "id_str" : "38450774",
      "id" : 38450774
    }, {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "indices" : [ 39, 50 ],
      "id_str" : "7255652",
      "id" : 7255652
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 55, 65 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/kr3O9bjx8Y",
      "expanded_url" : "https:\/\/www.gittip.com\/qrush\/",
      "display_url" : "gittip.com\/qrush\/"
    } ]
  },
  "in_reply_to_status_id_str" : "319103114290540546",
  "geo" : { },
  "id_str" : "319103586594353154",
  "in_reply_to_user_id" : 38450774,
  "text" : "@robertromito we are sponsored by both @engineyard and @37signals...otherwise https:\/\/t.co\/kr3O9bjx8Y !",
  "id" : 319103586594353154,
  "in_reply_to_status_id" : 319103114290540546,
  "created_at" : "2013-04-02 15:06:38 +0000",
  "in_reply_to_screen_name" : "robertromito",
  "in_reply_to_user_id_str" : "38450774",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "indices" : [ 0, 13 ],
      "id_str" : "38450774",
      "id" : 38450774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319096766781865985",
  "geo" : { },
  "id_str" : "319097431310614528",
  "in_reply_to_user_id" : 38450774,
  "text" : "@robertromito yes!",
  "id" : 319097431310614528,
  "in_reply_to_status_id" : 319096766781865985,
  "created_at" : "2013-04-02 14:42:10 +0000",
  "in_reply_to_screen_name" : "robertromito",
  "in_reply_to_user_id_str" : "38450774",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#techismaterial",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318381406642393089",
  "geo" : { },
  "id_str" : "319095984741302272",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik I'll bring the 2 carcassonne mini xpacs if you come!",
  "id" : 319095984741302272,
  "in_reply_to_status_id" : 318381406642393089,
  "created_at" : "2013-04-02 14:36:25 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 0, 15 ],
      "id_str" : "13639982",
      "id" : 13639982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318944938177998848",
  "geo" : { },
  "id_str" : "318945140213424128",
  "in_reply_to_user_id" : 13639982,
  "text" : "@MarkVillacampa what\u2019s your email?",
  "id" : 318945140213424128,
  "in_reply_to_status_id" : 318944938177998848,
  "created_at" : "2013-04-02 04:37:01 +0000",
  "in_reply_to_screen_name" : "MarkVillacampa",
  "in_reply_to_user_id_str" : "13639982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 0, 6 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318889230204022785",
  "geo" : { },
  "id_str" : "318890326788042752",
  "in_reply_to_user_id" : 15359408,
  "text" : "@raggi i am in a constant state of this.",
  "id" : 318890326788042752,
  "in_reply_to_status_id" : 318889230204022785,
  "created_at" : "2013-04-02 00:59:13 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wheatley ",
      "screen_name" : "jon",
      "indices" : [ 33, 37 ],
      "id_str" : "10917372",
      "id" : 10917372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/LiY7fk7IkR",
      "expanded_url" : "http:\/\/b.jonw.com\/post\/46853309918\/making-a-physical-product",
      "display_url" : "b.jonw.com\/post\/468533099\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318886456657600512",
  "text" : "Absolutely stunning product from @jon. No Kickstarter. (I still have not given money to a single one). Sold. http:\/\/t.co\/LiY7fk7IkR",
  "id" : 318886456657600512,
  "created_at" : "2013-04-02 00:43:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318793763424174081",
  "geo" : { },
  "id_str" : "318859457339719682",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff I\u2019d be more than happy to give some feedback!",
  "id" : 318859457339719682,
  "in_reply_to_status_id" : 318793763424174081,
  "created_at" : "2013-04-01 22:56:33 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318837353957445633",
  "geo" : { },
  "id_str" : "318837990719885312",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense cool. are you coding at all? curious, what's the app written in?",
  "id" : 318837990719885312,
  "in_reply_to_status_id" : 318837353957445633,
  "created_at" : "2013-04-01 21:31:15 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318836701285990400",
  "geo" : { },
  "id_str" : "318836851374972930",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense nice! did you work on this?",
  "id" : 318836851374972930,
  "in_reply_to_status_id" : 318836701285990400,
  "created_at" : "2013-04-01 21:26:43 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
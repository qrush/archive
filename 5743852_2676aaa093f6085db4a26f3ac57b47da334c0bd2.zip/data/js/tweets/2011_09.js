Grailbird.data.tweets_2011_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jqcon",
      "indices" : [ 41, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119723633529729024",
  "text" : "Feeling terrible. Need to go some drugs. #jqcon not looking good, don't want to be \"that guy\"",
  "id" : 119723633529729024,
  "created_at" : "2011-09-30 10:41:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119601752617140224",
  "geo" : { },
  "id_str" : "119605903015157760",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape really hoping I can kick this sinus cold before then :( don't want to infect people",
  "id" : 119605903015157760,
  "in_reply_to_status_id" : 119601752617140224,
  "created_at" : "2011-09-30 02:54:04 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 27, 35 ],
      "id_str" : "6592472",
      "id" : 6592472
    }, {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 38, 44 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119600146345496576",
  "text" : "Why is it that I've missed @rubiety \/ @chorn confs twice now?",
  "id" : 119600146345496576,
  "created_at" : "2011-09-30 02:31:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Etienne de Bruin",
      "screen_name" : "etdebruin",
      "indices" : [ 0, 10 ],
      "id_str" : "91470514",
      "id" : 91470514
    }, {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 22, 28 ],
      "id_str" : "744613",
      "id" : 744613
    }, {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 53, 61 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119595458199945216",
  "geo" : { },
  "id_str" : "119599983765897216",
  "in_reply_to_user_id" : 91470514,
  "text" : "@etdebruin as long as @chorn doesn't feed zombies to @rubiety, it will be",
  "id" : 119599983765897216,
  "in_reply_to_status_id" : 119595458199945216,
  "created_at" : "2011-09-30 02:30:32 +0000",
  "in_reply_to_screen_name" : "etdebruin",
  "in_reply_to_user_id_str" : "91470514",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/xpyc0lYm",
      "expanded_url" : "http:\/\/yfrog.com\/nz96kkj",
      "display_url" : "yfrog.com\/nz96kkj"
    } ]
  },
  "geo" : { },
  "id_str" : "119575210860101632",
  "text" : "HELL YEAH I NEED 1667% VITAMIN C OOOOOH YEAHHHH http:\/\/t.co\/xpyc0lYm",
  "id" : 119575210860101632,
  "created_at" : "2011-09-30 00:52:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/1ZYb0Rs7",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=PuA6ZjpEJys",
      "display_url" : "youtube.com\/watch?v=PuA6Zj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "119568367295283201",
  "text" : "I wonder if Tank had anything to do with it. http:\/\/t.co\/1ZYb0Rs7",
  "id" : 119568367295283201,
  "created_at" : "2011-09-30 00:24:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/Q2SivO5F",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=J6z88ur-8bY",
      "display_url" : "youtube.com\/watch?v=J6z88u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "119534797398880256",
  "text" : "Current outside status: http:\/\/t.co\/Q2SivO5F",
  "id" : 119534797398880256,
  "created_at" : "2011-09-29 22:11:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/u4gO5Var",
      "expanded_url" : "https:\/\/gist.github.com\/ae72470bb38211ed2022",
      "display_url" : "gist.github.com\/ae72470bb38211\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "119526070365077505",
  "geo" : { },
  "id_str" : "119526690568417280",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie had this for a few minutes earlier: http:\/\/t.co\/u4gO5Var",
  "id" : 119526690568417280,
  "in_reply_to_status_id" : 119526070365077505,
  "created_at" : "2011-09-29 21:39:18 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/12zlJb2v",
      "expanded_url" : "http:\/\/aroundthesunblog.com\/wp-content\/uploads\/2009\/02\/screenhunter_01-feb-01-2124.gif",
      "display_url" : "aroundthesunblog.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "119525988047654912",
  "text" : "Heroku, GitHub, and Campfire downtime today! http:\/\/t.co\/12zlJb2v",
  "id" : 119525988047654912,
  "created_at" : "2011-09-29 21:36:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 5, 11 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/n58vLr8y",
      "expanded_url" : "http:\/\/www.jamisbuck.org\/presentations\/rubyconf2011\/index.html",
      "display_url" : "jamisbuck.org\/presentations\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "119520646022701057",
  "text" : "Wow, @jamis' talk on maze generation and algorithms makes me want to write a roguelike even more! http:\/\/t.co\/n58vLr8y",
  "id" : 119520646022701057,
  "created_at" : "2011-09-29 21:15:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119501086586449920",
  "text" : "I think I need a service to do this...chain as many url redirectors as possible.",
  "id" : 119501086586449920,
  "created_at" : "2011-09-29 19:57:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119500998095028224",
  "text" : "I wonder how many URL redirector services you could chain together to get to a single URL.",
  "id" : 119500998095028224,
  "created_at" : "2011-09-29 19:57:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roflscale Tips",
      "screen_name" : "RoflscaleTips",
      "indices" : [ 3, 17 ],
      "id_str" : "264007125",
      "id" : 264007125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119494074129588224",
  "text" : "RT @RoflscaleTips: Use alias instead of alias_method. It makes your code faster by eliminating superfluous commas",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119491520658280448",
    "text" : "Use alias instead of alias_method. It makes your code faster by eliminating superfluous commas",
    "id" : 119491520658280448,
    "created_at" : "2011-09-29 19:19:33 +0000",
    "user" : {
      "name" : "Roflscale Tips",
      "screen_name" : "RoflscaleTips",
      "protected" : false,
      "id_str" : "264007125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1268527763\/roflscale_normal.jpg",
      "id" : 264007125,
      "verified" : false
    }
  },
  "id" : 119494074129588224,
  "created_at" : "2011-09-29 19:29:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/M2diL6cT",
      "expanded_url" : "http:\/\/www.theshiznit.co.uk\/media\/Sep2011\/truthposters\/jack-and-jill.jpg",
      "display_url" : "theshiznit.co.uk\/media\/Sep2011\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "119484853099040768",
  "text" : "Current status: http:\/\/t.co\/M2diL6cT",
  "id" : 119484853099040768,
  "created_at" : "2011-09-29 18:53:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/SoYXTuV5",
      "expanded_url" : "http:\/\/git.io\/",
      "display_url" : "git.io"
    } ]
  },
  "geo" : { },
  "id_str" : "119480721000767488",
  "text" : "Noticing the fancy http:\/\/t.co\/SoYXTuV5 links popping up in Campfire...nice!",
  "id" : 119480721000767488,
  "created_at" : "2011-09-29 18:36:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Sharp",
      "screen_name" : "ajsharp",
      "indices" : [ 0, 8 ],
      "id_str" : "18071073",
      "id" : 18071073
    }, {
      "name" : "Gabriel Horner",
      "screen_name" : "cldwalker",
      "indices" : [ 21, 31 ],
      "id_str" : "19846068",
      "id" : 19846068
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 32, 39 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 43, 49 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119464138375307265",
  "geo" : { },
  "id_str" : "119473905000919041",
  "in_reply_to_user_id" : 18071073,
  "text" : "@ajsharp also, maybe @cldwalker @sferik or @cmeik are there, they can help too :)",
  "id" : 119473905000919041,
  "in_reply_to_status_id" : 119464138375307265,
  "created_at" : "2011-09-29 18:09:33 +0000",
  "in_reply_to_screen_name" : "ajsharp",
  "in_reply_to_user_id_str" : "18071073",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Sharp",
      "screen_name" : "ajsharp",
      "indices" : [ 0, 8 ],
      "id_str" : "18071073",
      "id" : 18071073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119464138375307265",
  "geo" : { },
  "id_str" : "119473314648440832",
  "in_reply_to_user_id" : 18071073,
  "text" : "@ajsharp nope, feel free to email me though! nick@quaran.to",
  "id" : 119473314648440832,
  "in_reply_to_status_id" : 119464138375307265,
  "created_at" : "2011-09-29 18:07:12 +0000",
  "in_reply_to_screen_name" : "ajsharp",
  "in_reply_to_user_id_str" : "18071073",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 0, 11 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119437760254849024",
  "geo" : { },
  "id_str" : "119438448531738624",
  "in_reply_to_user_id" : 48431692,
  "text" : "@laserlemon i still dont understand any of this syck\/psych nonsense",
  "id" : 119438448531738624,
  "in_reply_to_status_id" : 119437760254849024,
  "created_at" : "2011-09-29 15:48:39 +0000",
  "in_reply_to_screen_name" : "laserlemon",
  "in_reply_to_user_id_str" : "48431692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119427291309801472",
  "text" : "Guard: Bringing back `sudo killall ruby` to 2011.",
  "id" : 119427291309801472,
  "created_at" : "2011-09-29 15:04:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119421181429432321",
  "text" : "I wonder how many collective years have been wasted to Ruby 1.9.2's startup time.",
  "id" : 119421181429432321,
  "created_at" : "2011-09-29 14:40:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 64, 71 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 72, 79 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/VHv6MzHz",
      "expanded_url" : "http:\/\/www.youtube.com\/watch_popup?v=xdj67XknFrM",
      "display_url" : "youtube.com\/watch_popup?v=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "119262818632597504",
  "text" : "Possibly the most badass doggles ever. http:\/\/t.co\/VHv6MzHz \/cc @croaky @gabebw",
  "id" : 119262818632597504,
  "created_at" : "2011-09-29 04:10:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ryckbost",
      "screen_name" : "bryckbost",
      "indices" : [ 0, 10 ],
      "id_str" : "8494682",
      "id" : 8494682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119155151889108992",
  "geo" : { },
  "id_str" : "119171315277107200",
  "in_reply_to_user_id" : 8494682,
  "text" : "@bryckbost if any of the major apis (or the daemon start\/stopping) changed that would be nice to know about.",
  "id" : 119171315277107200,
  "in_reply_to_status_id" : 119155151889108992,
  "created_at" : "2011-09-28 22:07:10 +0000",
  "in_reply_to_screen_name" : "bryckbost",
  "in_reply_to_user_id_str" : "8494682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ryckbost",
      "screen_name" : "bryckbost",
      "indices" : [ 0, 10 ],
      "id_str" : "8494682",
      "id" : 8494682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/5qKvt3FM",
      "expanded_url" : "http:\/\/github.com\/rubygems\/rubygems.org",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "119155151889108992",
  "geo" : { },
  "id_str" : "119171083655053312",
  "in_reply_to_user_id" : 8494682,
  "text" : "@bryckbost hit us with a pull request. http:\/\/t.co\/5qKvt3FM",
  "id" : 119171083655053312,
  "in_reply_to_status_id" : 119155151889108992,
  "created_at" : "2011-09-28 22:06:15 +0000",
  "in_reply_to_screen_name" : "bryckbost",
  "in_reply_to_user_id_str" : "8494682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Churchill",
      "screen_name" : "mrchucho",
      "indices" : [ 0, 9 ],
      "id_str" : "14493190",
      "id" : 14493190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119108871779389442",
  "geo" : { },
  "id_str" : "119111539935543296",
  "in_reply_to_user_id" : 14493190,
  "text" : "@mrchucho regarding shoulda, we barely use it, and only shoulda-matchers at that",
  "id" : 119111539935543296,
  "in_reply_to_status_id" : 119108871779389442,
  "created_at" : "2011-09-28 18:09:38 +0000",
  "in_reply_to_screen_name" : "mrchucho",
  "in_reply_to_user_id_str" : "14493190",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Churchill",
      "screen_name" : "mrchucho",
      "indices" : [ 0, 9 ],
      "id_str" : "14493190",
      "id" : 14493190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119108871779389442",
  "geo" : { },
  "id_str" : "119111470226210819",
  "in_reply_to_user_id" : 14493190,
  "text" : "@mrchucho it was a major version bump for FG, plus I think that the old DSL is still supported, just deprecated",
  "id" : 119111470226210819,
  "in_reply_to_status_id" : 119108871779389442,
  "created_at" : "2011-09-28 18:09:22 +0000",
  "in_reply_to_screen_name" : "mrchucho",
  "in_reply_to_user_id_str" : "14493190",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Churchill",
      "screen_name" : "mrchucho",
      "indices" : [ 0, 9 ],
      "id_str" : "14493190",
      "id" : 14493190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119107240685871104",
  "geo" : { },
  "id_str" : "119107845374488576",
  "in_reply_to_user_id" : 14493190,
  "text" : "@mrchucho what gem were you trying to use?",
  "id" : 119107845374488576,
  "in_reply_to_status_id" : 119107240685871104,
  "created_at" : "2011-09-28 17:54:57 +0000",
  "in_reply_to_screen_name" : "mrchucho",
  "in_reply_to_user_id_str" : "14493190",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/cGjk8zrI",
      "expanded_url" : "http:\/\/sassymothereffingtextshadow.com\/",
      "display_url" : "sassymothereffingtextshadow.com"
    } ]
  },
  "geo" : { },
  "id_str" : "119075714216628225",
  "text" : "I do hate CSS, but this Sass is badass! http:\/\/t.co\/cGjk8zrI",
  "id" : 119075714216628225,
  "created_at" : "2011-09-28 15:47:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howland",
      "screen_name" : "backslash",
      "indices" : [ 0, 10 ],
      "id_str" : "8161622",
      "id" : 8161622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119058055710257152",
  "geo" : { },
  "id_str" : "119075256660000768",
  "in_reply_to_user_id" : 8161622,
  "text" : "@backslash thanks! :D",
  "id" : 119075256660000768,
  "in_reply_to_status_id" : 119058055710257152,
  "created_at" : "2011-09-28 15:45:28 +0000",
  "in_reply_to_screen_name" : "backslash",
  "in_reply_to_user_id_str" : "8161622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bills",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/A3ssCFNe",
      "expanded_url" : "https:\/\/p.twimg.com\/Aabi3aXCAAEX-v3.jpg",
      "display_url" : "p.twimg.com\/Aabi3aXCAAEX-v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "119053351227883520",
  "text" : "#Bills Stampede! http:\/\/t.co\/A3ssCFNe",
  "id" : 119053351227883520,
  "created_at" : "2011-09-28 14:18:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MBTA Assholes",
      "screen_name" : "mbtaassholes",
      "indices" : [ 58, 71 ],
      "id_str" : "275142342",
      "id" : 275142342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119037602333593600",
  "text" : "Found a twitter account to help cope with this situation: @mbtaassholes",
  "id" : 119037602333593600,
  "created_at" : "2011-09-28 13:15:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jqcon",
      "indices" : [ 72, 78 ]
    }, {
      "text" : "mbta",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119036551056465920",
  "text" : "Fitchburg commuter rail will be down this weekend, making my commute to #jqcon really painful. #mbta fail.",
  "id" : 119036551056465920,
  "created_at" : "2011-09-28 13:11:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119027321964462080",
  "text" : "Holy fuck, why are tissues edible and why do dogs love eating them",
  "id" : 119027321964462080,
  "created_at" : "2011-09-28 12:34:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118894844868444162",
  "geo" : { },
  "id_str" : "118902142261149697",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton minotaurs suck, dude :(",
  "id" : 118902142261149697,
  "in_reply_to_status_id" : 118894844868444162,
  "created_at" : "2011-09-28 04:17:34 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Chaffee",
      "screen_name" : "alexch",
      "indices" : [ 0, 7 ],
      "id_str" : "7632622",
      "id" : 7632622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118900559368560641",
  "geo" : { },
  "id_str" : "118902073667497984",
  "in_reply_to_user_id" : 7632622,
  "text" : "@alexch woot! thanks!",
  "id" : 118902073667497984,
  "in_reply_to_status_id" : 118900559368560641,
  "created_at" : "2011-09-28 04:17:18 +0000",
  "in_reply_to_screen_name" : "alexch",
  "in_reply_to_user_id_str" : "7632622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nethack",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/9M9DYIbc",
      "expanded_url" : "http:\/\/alt.org\/nethack\/userdata\/D\/DoctorNick\/dumplog\/1316748459.nh343.txt",
      "display_url" : "alt.org\/nethack\/userda\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "118901327232385025",
  "text" : "#nethack Ascension #7! http:\/\/t.co\/9M9DYIbc",
  "id" : 118901327232385025,
  "created_at" : "2011-09-28 04:14:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118894021149081602",
  "text" : "Hitting the planes right now! `telnet nethack.alt.org` and watch DoctorNick's game! See how I fuck this up!",
  "id" : 118894021149081602,
  "created_at" : "2011-09-28 03:45:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118890701898530816",
  "text" : "If you want to watch, \"telnet nethack.alt.org\", hit \"w\" to watch, then select DoctorNick's game. Going to start ascending in 5ish mins.",
  "id" : 118890701898530816,
  "created_at" : "2011-09-28 03:32:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118890483924733953",
  "text" : "Here we go. AC -23 tourist, +6 Fire Brand\/+5 Silver Saber, armed to the teeth, hitting the Elemental Planes right now.",
  "id" : 118890483924733953,
  "created_at" : "2011-09-28 03:31:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118869787404283904",
  "geo" : { },
  "id_str" : "118877663338315776",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant this...is awesome",
  "id" : 118877663338315776,
  "in_reply_to_status_id" : 118869787404283904,
  "created_at" : "2011-09-28 02:40:18 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boom Haackalacka",
      "screen_name" : "haacked",
      "indices" : [ 0, 8 ],
      "id_str" : "768197",
      "id" : 768197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118805464623484928",
  "geo" : { },
  "id_str" : "118808992553254912",
  "in_reply_to_user_id" : 768197,
  "text" : "@haacked I would quit",
  "id" : 118808992553254912,
  "in_reply_to_status_id" : 118805464623484928,
  "created_at" : "2011-09-27 22:07:25 +0000",
  "in_reply_to_screen_name" : "haacked",
  "in_reply_to_user_id_str" : "768197",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118747980068171776",
  "geo" : { },
  "id_str" : "118748336546254848",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold don't forget B00BS",
  "id" : 118748336546254848,
  "in_reply_to_status_id" : 118747980068171776,
  "created_at" : "2011-09-27 18:06:24 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Red Squirrel Tech",
      "screen_name" : "redsquirrel",
      "indices" : [ 0, 12 ],
      "id_str" : "10759712",
      "id" : 10759712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118674970049126400",
  "geo" : { },
  "id_str" : "118676546562162689",
  "in_reply_to_user_id" : 57853,
  "text" : "@redsquirrel just convert now...saves so much time and effort, and it's a joy to write",
  "id" : 118676546562162689,
  "in_reply_to_status_id" : 118674970049126400,
  "created_at" : "2011-09-27 13:21:08 +0000",
  "in_reply_to_screen_name" : "davehoover",
  "in_reply_to_user_id_str" : "57853",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 0, 11 ],
      "id_str" : "9887102",
      "id" : 9887102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117988544366116864",
  "geo" : { },
  "id_str" : "118535673077694465",
  "in_reply_to_user_id" : 9887102,
  "text" : "@metaskills yes? need help?",
  "id" : 118535673077694465,
  "in_reply_to_status_id" : 117988544366116864,
  "created_at" : "2011-09-27 04:01:21 +0000",
  "in_reply_to_screen_name" : "metaskills",
  "in_reply_to_user_id_str" : "9887102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nethack",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118532063983972352",
  "text" : "Also noticing there's a lot of crappy #nethack spoiler\/tutorial sites...I wonder if an ebook + cheat sheet would sell. + awesome searching.",
  "id" : 118532063983972352,
  "created_at" : "2011-09-27 03:47:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/gPiGYf7t",
      "expanded_url" : "http:\/\/alt.org\/nethack\/player-stats.php?player=DoctorNick",
      "display_url" : "alt.org\/nethack\/player\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "118527975342866433",
  "geo" : { },
  "id_str" : "118528436808581120",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik been playing since 2007, definitely takes a while to learn. so worth it. http:\/\/t.co\/gPiGYf7t",
  "id" : 118528436808581120,
  "in_reply_to_status_id" : 118527975342866433,
  "created_at" : "2011-09-27 03:32:36 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nethack",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118527760909078528",
  "text" : "Totally ready for a Tourist ascension in #nethack, on the door of the Sanctum. Should I livestream it tomorrow?",
  "id" : 118527760909078528,
  "created_at" : "2011-09-27 03:29:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Fayram",
      "screen_name" : "KirinDave",
      "indices" : [ 0, 10 ],
      "id_str" : "784519",
      "id" : 784519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118459621982748675",
  "geo" : { },
  "id_str" : "118460502857883648",
  "in_reply_to_user_id" : 784519,
  "text" : "@KirinDave is that a mongodb log?",
  "id" : 118460502857883648,
  "in_reply_to_status_id" : 118459621982748675,
  "created_at" : "2011-09-26 23:02:39 +0000",
  "in_reply_to_screen_name" : "KirinDave",
  "in_reply_to_user_id_str" : "784519",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Bob Martin",
      "screen_name" : "unclebobmartin",
      "indices" : [ 0, 15 ],
      "id_str" : "9505092",
      "id" : 9505092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118456115666239489",
  "geo" : { },
  "id_str" : "118459965416542208",
  "in_reply_to_user_id" : 9505092,
  "text" : "@unclebobmartin really curious, have you done this yourself or have examples of how this can be accomplished easily?",
  "id" : 118459965416542208,
  "in_reply_to_status_id" : 118456115666239489,
  "created_at" : "2011-09-26 23:00:31 +0000",
  "in_reply_to_screen_name" : "unclebobmartin",
  "in_reply_to_user_id_str" : "9505092",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jqcon",
      "indices" : [ 11, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/kwQD40Qq",
      "expanded_url" : "http:\/\/events.jquery.org\/2011\/boston\/",
      "display_url" : "events.jquery.org\/2011\/boston\/"
    } ]
  },
  "geo" : { },
  "id_str" : "118328929886027776",
  "text" : "Pumped for #jqcon this week ! http:\/\/t.co\/kwQD40Qq",
  "id" : 118328929886027776,
  "created_at" : "2011-09-26 14:19:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Chapin",
      "screen_name" : "bpchapin",
      "indices" : [ 0, 9 ],
      "id_str" : "18975240",
      "id" : 18975240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118324233846800384",
  "geo" : { },
  "id_str" : "118327938314809344",
  "in_reply_to_user_id" : 18975240,
  "text" : "@bpchapin no problem, slowly discovering tech folks in Buffalo :)",
  "id" : 118327938314809344,
  "in_reply_to_status_id" : 118324233846800384,
  "created_at" : "2011-09-26 14:15:53 +0000",
  "in_reply_to_screen_name" : "bpchapin",
  "in_reply_to_user_id_str" : "18975240",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 0, 11 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118327211878129665",
  "geo" : { },
  "id_str" : "118327806450089984",
  "in_reply_to_user_id" : 48431692,
  "text" : "@laserlemon i usually say \"q rush\" but some people say \"crusssssh\"",
  "id" : 118327806450089984,
  "in_reply_to_status_id" : 118327211878129665,
  "created_at" : "2011-09-26 14:15:22 +0000",
  "in_reply_to_screen_name" : "laserlemon",
  "in_reply_to_user_id_str" : "48431692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118323690604732416",
  "text" : "Why Does Diaspora* Have* A* Stupid* Asterisk* In* Their* Fucking* Logo* And* Name* ?",
  "id" : 118323690604732416,
  "created_at" : "2011-09-26 13:59:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/z9LO0skZ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=DbqBT1mE9Ts",
      "display_url" : "youtube.com\/watch?v=DbqBT1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "118157513458855936",
  "text" : "Current status: http:\/\/t.co\/z9LO0skZ",
  "id" : 118157513458855936,
  "created_at" : "2011-09-26 02:58:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118131033592971264",
  "text" : "Trolololololo guy on family guy. The meme circle is complete.",
  "id" : 118131033592971264,
  "created_at" : "2011-09-26 01:13:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/118112957807857664\/photo\/1",
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/ABweIkwW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AaOfG_3CEAAcQFJ.jpg",
      "id_str" : "118112957812051968",
      "id" : 118112957812051968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AaOfG_3CEAAcQFJ.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/ABweIkwW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118112957807857664",
  "text" : "Current dog status http:\/\/t.co\/ABweIkwW",
  "id" : 118112957807857664,
  "created_at" : "2011-09-26 00:01:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bills",
      "indices" : [ 24, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118057715670065152",
  "text" : "Sweet sweet justice for #Bills. 3-0!!",
  "id" : 118057715670065152,
  "created_at" : "2011-09-25 20:22:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 0, 5 ],
      "id_str" : "20941662",
      "id" : 20941662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117972167169282048",
  "geo" : { },
  "id_str" : "117996428101550081",
  "in_reply_to_user_id" : 20941662,
  "text" : "@JEG2 jersey shore",
  "id" : 117996428101550081,
  "in_reply_to_status_id" : 117972167169282048,
  "created_at" : "2011-09-25 16:18:35 +0000",
  "in_reply_to_screen_name" : "JEG2",
  "in_reply_to_user_id_str" : "20941662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/4CjLjmRf",
      "expanded_url" : "http:\/\/alt.org\/nethack\/plr.php?player=DoctorNick",
      "display_url" : "alt.org\/nethack\/plr.ph\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "117990545112043520",
  "geo" : { },
  "id_str" : "117992733649551360",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw there are colors for items, etc. Check the config file: http:\/\/t.co\/4CjLjmRf",
  "id" : 117992733649551360,
  "in_reply_to_status_id" : 117990545112043520,
  "created_at" : "2011-09-25 16:03:54 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117990545112043520",
  "geo" : { },
  "id_str" : "117992335563964416",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw nope, nethack.alt.org.",
  "id" : 117992335563964416,
  "in_reply_to_status_id" : 117990545112043520,
  "created_at" : "2011-09-25 16:02:19 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117986822474309632",
  "text" : "Aww yeah: c - the Platinum Yendorian Express Card.",
  "id" : 117986822474309632,
  "created_at" : "2011-09-25 15:40:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nethack",
      "indices" : [ 8, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/swxuvZs9",
      "expanded_url" : "https:\/\/img.skitch.com\/20110925-p45eq7yp96asy4puai16ramnia.png",
      "display_url" : "img.skitch.com\/20110925-p45eq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "117869553102491649",
  "text" : "Current #nethack status: http:\/\/t.co\/swxuvZs9 Way too tired to take on the Castle.",
  "id" : 117869553102491649,
  "created_at" : "2011-09-25 07:54:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/73lBFclh",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=-aG7EQMsP4c",
      "display_url" : "youtube.com\/watch?v=-aG7EQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "117749628065157120",
  "text" : "Current status: http:\/\/t.co\/73lBFclh",
  "id" : 117749628065157120,
  "created_at" : "2011-09-24 23:57:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sb2011",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/IT7aFtyx",
      "expanded_url" : "http:\/\/yfrog.com\/kkk7zosj",
      "display_url" : "yfrog.com\/kkk7zosj"
    } ]
  },
  "geo" : { },
  "id_str" : "117678307302060033",
  "text" : "Just fucking make something. #sb2011 http:\/\/t.co\/IT7aFtyx",
  "id" : 117678307302060033,
  "created_at" : "2011-09-24 19:14:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/YmdbzQBC",
      "expanded_url" : "http:\/\/yfrog.com\/kkw2vjcj",
      "display_url" : "yfrog.com\/kkw2vjcj"
    } ]
  },
  "geo" : { },
  "id_str" : "117645594960461824",
  "text" : "Finally at miracle of science! http:\/\/t.co\/YmdbzQBC",
  "id" : 117645594960461824,
  "created_at" : "2011-09-24 17:04:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sb2011",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117639132343304193",
  "text" : "The sheer fact that founders can't give a definite answer about how to make money makes me wonder why they're founder at all. #sb2011",
  "id" : 117639132343304193,
  "created_at" : "2011-09-24 16:38:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenn Ayres",
      "screen_name" : "ayresphoto",
      "indices" : [ 3, 14 ],
      "id_str" : "83498704",
      "id" : 83498704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/Q3HIJLaX",
      "expanded_url" : "http:\/\/fb.me\/y642b83k",
      "display_url" : "fb.me\/y642b83k"
    } ]
  },
  "geo" : { },
  "id_str" : "117623706498498560",
  "text" : "RT @ayresphoto: A favorite shot from Amanda and Nick's wedding!! \u2665 http:\/\/t.co\/Q3HIJLaX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/Q3HIJLaX",
        "expanded_url" : "http:\/\/fb.me\/y642b83k",
        "display_url" : "fb.me\/y642b83k"
      } ]
    },
    "geo" : { },
    "id_str" : "117618971259322369",
    "text" : "A favorite shot from Amanda and Nick's wedding!! \u2665 http:\/\/t.co\/Q3HIJLaX",
    "id" : 117618971259322369,
    "created_at" : "2011-09-24 15:18:42 +0000",
    "user" : {
      "name" : "Jenn Ayres",
      "screen_name" : "ayresphoto",
      "protected" : false,
      "id_str" : "83498704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3088610369\/f83b0faf8bfcb1df4cd1ca2293a16d7a_normal.jpeg",
      "id" : 83498704,
      "verified" : false
    }
  },
  "id" : 117623706498498560,
  "created_at" : "2011-09-24 15:37:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Startup Bootcamp",
      "screen_name" : "StartupBootcamp",
      "indices" : [ 16, 32 ],
      "id_str" : "50029693",
      "id" : 50029693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/sKJGercc",
      "expanded_url" : "http:\/\/playbook.thoughtbot.com",
      "display_url" : "playbook.thoughtbot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "117598246930624512",
  "text" : "RT @thoughtbot: @startupbootcamp folks: give yourself something to talk about b\/t sessions. Flip through our handbook on web startups: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Startup Bootcamp",
        "screen_name" : "StartupBootcamp",
        "indices" : [ 0, 16 ],
        "id_str" : "50029693",
        "id" : 50029693
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/sKJGercc",
        "expanded_url" : "http:\/\/playbook.thoughtbot.com",
        "display_url" : "playbook.thoughtbot.com"
      } ]
    },
    "geo" : { },
    "id_str" : "117595133574258689",
    "in_reply_to_user_id" : 50029693,
    "text" : "@startupbootcamp folks: give yourself something to talk about b\/t sessions. Flip through our handbook on web startups: http:\/\/t.co\/sKJGercc",
    "id" : 117595133574258689,
    "created_at" : "2011-09-24 13:43:59 +0000",
    "in_reply_to_screen_name" : "StartupBootcamp",
    "in_reply_to_user_id_str" : "50029693",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 117598246930624512,
  "created_at" : "2011-09-24 13:56:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "startupbootcamp",
      "indices" : [ 11, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117590404412608513",
  "text" : "Made it to #startupbootcamp!",
  "id" : 117590404412608513,
  "created_at" : "2011-09-24 13:25:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup Bootcamp",
      "screen_name" : "StartupBootcamp",
      "indices" : [ 21, 37 ],
      "id_str" : "50029693",
      "id" : 50029693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117576351350931456",
  "text" : "Woke up way late for @startupbootcamp. Oops.",
  "id" : 117576351350931456,
  "created_at" : "2011-09-24 12:29:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/P4fJLwzh",
      "expanded_url" : "http:\/\/yfrog.com\/meqdvzj",
      "display_url" : "yfrog.com\/meqdvzj"
    } ]
  },
  "geo" : { },
  "id_str" : "117417752985214976",
  "text" : "I accidentally all the Carcassonne. http:\/\/t.co\/P4fJLwzh",
  "id" : 117417752985214976,
  "created_at" : "2011-09-24 01:59:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/oG4tGaIr",
      "expanded_url" : "http:\/\/startupbootcamp.mit.edu\/",
      "display_url" : "startupbootcamp.mit.edu"
    } ]
  },
  "geo" : { },
  "id_str" : "117318082606800896",
  "text" : "Pumped for http:\/\/t.co\/oG4tGaIr tomorrow!",
  "id" : 117318082606800896,
  "created_at" : "2011-09-23 19:23:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 23 ],
      "url" : "http:\/\/t.co\/56UxVqFU",
      "expanded_url" : "http:\/\/production.s3.rubygems.org.s3-website-us-east-1.amazonaws.com\/",
      "display_url" : "\u2026rg.s3-website-us-east-1.amazonaws.com"
    } ]
  },
  "geo" : { },
  "id_str" : "117306567392624640",
  "text" : "So http:\/\/t.co\/56UxVqFU works but not production.s3.rubygems.org ? This is so stupid.",
  "id" : 117306567392624640,
  "created_at" : "2011-09-23 18:37:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boom Haackalacka",
      "screen_name" : "haacked",
      "indices" : [ 0, 8 ],
      "id_str" : "768197",
      "id" : 768197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/3WjEYEuj",
      "expanded_url" : "http:\/\/semver.org\/",
      "display_url" : "semver.org"
    } ]
  },
  "in_reply_to_status_id_str" : "117303964696969216",
  "geo" : { },
  "id_str" : "117304221405163521",
  "in_reply_to_user_id" : 768197,
  "text" : "@haacked http:\/\/t.co\/3WjEYEuj",
  "id" : 117304221405163521,
  "in_reply_to_status_id" : 117303964696969216,
  "created_at" : "2011-09-23 18:28:00 +0000",
  "in_reply_to_screen_name" : "haacked",
  "in_reply_to_user_id_str" : "768197",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 26, 36 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117303866797731840",
  "text" : "Enabled logging on all of @gemcutter's s3\/cf buckets. We'll see how that goes.",
  "id" : 117303866797731840,
  "created_at" : "2011-09-23 18:26:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Nielsen",
      "screen_name" : "xunker",
      "indices" : [ 0, 7 ],
      "id_str" : "3301611",
      "id" : 3301611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117302677662220288",
  "geo" : { },
  "id_str" : "117303629182009344",
  "in_reply_to_user_id" : 3301611,
  "text" : "@xunker there is no honor in this request",
  "id" : 117303629182009344,
  "in_reply_to_status_id" : 117302677662220288,
  "created_at" : "2011-09-23 18:25:39 +0000",
  "in_reply_to_screen_name" : "xunker",
  "in_reply_to_user_id_str" : "3301611",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincent Agnello",
      "screen_name" : "agnellvj",
      "indices" : [ 0, 9 ],
      "id_str" : "121667913",
      "id" : 121667913
    }, {
      "name" : "Jerry Chen",
      "screen_name" : "jcsalterego",
      "indices" : [ 10, 22 ],
      "id_str" : "14343561",
      "id" : 14343561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/PjGfV74X",
      "expanded_url" : "https:\/\/img.skitch.com\/20110923-x2ti3juiqij4767fmaf4rdgxag.png",
      "display_url" : "img.skitch.com\/20110923-x2ti3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "117299615321165824",
  "geo" : { },
  "id_str" : "117303060350500864",
  "in_reply_to_user_id" : 121667913,
  "text" : "@agnellvj @jcsalterego http:\/\/t.co\/PjGfV74X",
  "id" : 117303060350500864,
  "in_reply_to_status_id" : 117299615321165824,
  "created_at" : "2011-09-23 18:23:23 +0000",
  "in_reply_to_screen_name" : "agnellvj",
  "in_reply_to_user_id_str" : "121667913",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/Mwn1hnuU",
      "expanded_url" : "http:\/\/staging.cf.rubygems.org\/",
      "display_url" : "staging.cf.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "117301029636276224",
  "text" : "Looks like it works on http:\/\/t.co\/Mwn1hnuU ...why is S3's behavior different? augh.",
  "id" : 117301029636276224,
  "created_at" : "2011-09-23 18:15:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/t45FPmn1",
      "expanded_url" : "http:\/\/staging.s3.rubygems.org\/",
      "display_url" : "staging.s3.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "117298614732201985",
  "text" : "I've added an index.html to an s3 bucket, enabled website hosting, the file is public, and nothing: http:\/\/t.co\/t45FPmn1 wtf am I missing?",
  "id" : 117298614732201985,
  "created_at" : "2011-09-23 18:05:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin McCarthy",
      "screen_name" : "kmccarth",
      "indices" : [ 0, 9 ],
      "id_str" : "14353271",
      "id" : 14353271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117265537595228161",
  "geo" : { },
  "id_str" : "117267568800174085",
  "in_reply_to_user_id" : 14353271,
  "text" : "@kmccarth it's working now...not sure why",
  "id" : 117267568800174085,
  "in_reply_to_status_id" : 117265537595228161,
  "created_at" : "2011-09-23 16:02:21 +0000",
  "in_reply_to_screen_name" : "kmccarth",
  "in_reply_to_user_id_str" : "14353271",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BostInno",
      "screen_name" : "BostInno",
      "indices" : [ 0, 9 ],
      "id_str" : "16877220",
      "id" : 16877220
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117242547155386369",
  "geo" : { },
  "id_str" : "117262189223620609",
  "in_reply_to_user_id" : 142919691,
  "text" : "@BostInno your entire site is a 403 error",
  "id" : 117262189223620609,
  "in_reply_to_status_id" : 117242547155386369,
  "created_at" : "2011-09-23 15:40:59 +0000",
  "in_reply_to_screen_name" : "BostInnoCity",
  "in_reply_to_user_id_str" : "142919691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lopez",
      "screen_name" : "brianmario",
      "indices" : [ 92, 103 ],
      "id_str" : "9994542",
      "id" : 9994542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117261867935735808",
  "text" : "\"DEPRECATION WARNING: Yajl's JSON gem compatibility API is going to be removed in 2.0\" WTF? @brianmario ?",
  "id" : 117261867935735808,
  "created_at" : "2011-09-23 15:39:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/CAbowjjh",
      "expanded_url" : "http:\/\/www.jamesbritt.com\/2011\/9\/20\/ruby-doc-org-beta",
      "display_url" : "jamesbritt.com\/2011\/9\/20\/ruby\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "117246561100103681",
  "text" : "Apparently there's http:\/\/t.co\/CAbowjjh but it's still slow.",
  "id" : 117246561100103681,
  "created_at" : "2011-09-23 14:38:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117246266383138817",
  "text" : "Am I crazy for wanting to make an ad-supported version of ruby-doc.org that will be fast\/cached\/in cloudfront ?",
  "id" : 117246266383138817,
  "created_at" : "2011-09-23 14:37:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minefold",
      "screen_name" : "minefold",
      "indices" : [ 63, 72 ],
      "id_str" : "323188491",
      "id" : 323188491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117244523083595776",
  "text" : "Wow, pay by the hour minecraft with chat, live maps, and more. @minefold is going to make a killing.",
  "id" : 117244523083595776,
  "created_at" : "2011-09-23 14:30:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/sLUdCz5E",
      "expanded_url" : "http:\/\/www.minefold.com\/",
      "display_url" : "minefold.com"
    } ]
  },
  "geo" : { },
  "id_str" : "117244239817089025",
  "text" : "zomg! http:\/\/t.co\/sLUdCz5E",
  "id" : 117244239817089025,
  "created_at" : "2011-09-23 14:29:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117094123328122880",
  "geo" : { },
  "id_str" : "117101605303758848",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety rm -rf spec\/models\/scope_spec.rb",
  "id" : 117101605303758848,
  "in_reply_to_status_id" : 117094123328122880,
  "created_at" : "2011-09-23 05:02:53 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Peabody",
      "screen_name" : "alanpeabody",
      "indices" : [ 0, 12 ],
      "id_str" : "61563976",
      "id" : 61563976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117091896823779328",
  "geo" : { },
  "id_str" : "117101337933660160",
  "in_reply_to_user_id" : 61563976,
  "text" : "@alanpeabody we have him on adult food but I think it's too rich for him. Need to try other kinds.",
  "id" : 117101337933660160,
  "in_reply_to_status_id" : 117091896823779328,
  "created_at" : "2011-09-23 05:01:49 +0000",
  "in_reply_to_screen_name" : "alanpeabody",
  "in_reply_to_user_id_str" : "61563976",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117072122618187777",
  "text" : "SMELLY PUPPY FARTS ARE THE BANE OF MY EXISTENCE",
  "id" : 117072122618187777,
  "created_at" : "2011-09-23 03:05:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116988406843711488",
  "geo" : { },
  "id_str" : "116993582933614592",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt that is correct, it's in S3 still but cannot be fetched through 'gem install' etc",
  "id" : 116993582933614592,
  "in_reply_to_status_id" : 116988406843711488,
  "created_at" : "2011-09-22 21:53:38 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Bedell",
      "screen_name" : "kbedell",
      "indices" : [ 0, 8 ],
      "id_str" : "6578432",
      "id" : 6578432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116951933767524352",
  "geo" : { },
  "id_str" : "116993380650713088",
  "in_reply_to_user_id" : 6578432,
  "text" : "@kbedell haha thanks. Pumped for 1 billion!",
  "id" : 116993380650713088,
  "in_reply_to_status_id" : 116951933767524352,
  "created_at" : "2011-09-22 21:52:50 +0000",
  "in_reply_to_screen_name" : "kbedell",
  "in_reply_to_user_id_str" : "6578432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    }, {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 59, 72 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116987717979602944",
  "geo" : { },
  "id_str" : "116987932451151873",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt yes but it's hidden from the index. The faq @derickbailey linked to explains it all",
  "id" : 116987932451151873,
  "in_reply_to_status_id" : 116987717979602944,
  "created_at" : "2011-09-22 21:31:11 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/uWlfd3bK",
      "expanded_url" : "http:\/\/ubygems.org",
      "display_url" : "ubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "116949660953870336",
  "text" : "This continues to be one of the best practical jokes (of legacy code) in Ruby: http:\/\/t.co\/uWlfd3bK",
  "id" : 116949660953870336,
  "created_at" : "2011-09-22 18:59:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Suggs",
      "screen_name" : "ktheory",
      "indices" : [ 3, 11 ],
      "id_str" : "1696",
      "id" : 1696
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 66, 76 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 77, 83 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/PNbXfWjH",
      "expanded_url" : "http:\/\/ubygems.org",
      "display_url" : "ubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "116949478904307712",
  "text" : "RT @ktheory: A convenient rubygems URL: http:\/\/t.co\/PNbXfWjH\n\n\/cc @gemcutter @qrush",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gemcutter",
        "screen_name" : "gemcutter",
        "indices" : [ 53, 63 ],
        "id_str" : "42259749",
        "id" : 42259749
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 64, 70 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http:\/\/t.co\/PNbXfWjH",
        "expanded_url" : "http:\/\/ubygems.org",
        "display_url" : "ubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "116900598414188544",
    "text" : "A convenient rubygems URL: http:\/\/t.co\/PNbXfWjH\n\n\/cc @gemcutter @qrush",
    "id" : 116900598414188544,
    "created_at" : "2011-09-22 15:44:09 +0000",
    "user" : {
      "name" : "Aaron Suggs",
      "screen_name" : "ktheory",
      "protected" : false,
      "id_str" : "1696",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1079271446\/aaron-suggs-170x240_normal.jpg",
      "id" : 1696,
      "verified" : false
    }
  },
  "id" : 116949478904307712,
  "created_at" : "2011-09-22 18:58:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Larkowski",
      "screen_name" : "l4rk",
      "indices" : [ 0, 5 ],
      "id_str" : "1940",
      "id" : 1940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116935266056421376",
  "geo" : { },
  "id_str" : "116949417659084800",
  "in_reply_to_user_id" : 1940,
  "text" : "@l4rk damn!",
  "id" : 116949417659084800,
  "in_reply_to_status_id" : 116935266056421376,
  "created_at" : "2011-09-22 18:58:08 +0000",
  "in_reply_to_screen_name" : "l4rk",
  "in_reply_to_user_id_str" : "1940",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/cJ0aLp5U",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=yAGrf57LtvY",
      "display_url" : "youtube.com\/watch?v=yAGrf5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "116891093659942912",
  "text" : "Current status: http:\/\/t.co\/cJ0aLp5U",
  "id" : 116891093659942912,
  "created_at" : "2011-09-22 15:06:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/Ik0EkVmA",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/The_Ambiguously_Gay_Duo",
      "display_url" : "en.wikipedia.org\/wiki\/The_Ambig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "116888477395730432",
  "text" : "Blowing my mind right now, Stephen Colbert and Steve Carell were the voices of The Ambiguously Gay Duo. http:\/\/t.co\/Ik0EkVmA",
  "id" : 116888477395730432,
  "created_at" : "2011-09-22 14:55:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacqui Maher",
      "screen_name" : "jacqui",
      "indices" : [ 3, 10 ],
      "id_str" : "355203",
      "id" : 355203
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 29, 35 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "indices" : [ 73, 83 ],
      "id_str" : "220097555",
      "id" : 220097555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116878259236503552",
  "text" : "RT @jacqui: Public thanks to @qrush for helping me out this morning with @radishapp, responding immediately to my email. You rock!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 17, 23 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Radish",
        "screen_name" : "radishapp",
        "indices" : [ 61, 71 ],
        "id_str" : "220097555",
        "id" : 220097555
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116874973473280000",
    "text" : "Public thanks to @qrush for helping me out this morning with @radishapp, responding immediately to my email. You rock!",
    "id" : 116874973473280000,
    "created_at" : "2011-09-22 14:02:19 +0000",
    "user" : {
      "name" : "Jacqui Maher",
      "screen_name" : "jacqui",
      "protected" : false,
      "id_str" : "355203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569504959930974208\/B_FvhH1a_normal.jpeg",
      "id" : 355203,
      "verified" : false
    }
  },
  "id" : 116878259236503552,
  "created_at" : "2011-09-22 14:15:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/OEJh8kpF",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/todayilearned\/comments\/kn8os\/til_that_the_buffalo_bills_kept_kevin_everett_on\/",
      "display_url" : "reddit.com\/r\/todayilearne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "116851127177318400",
  "text" : "A Bills thread on Reddit? HELL YES. http:\/\/t.co\/OEJh8kpF",
  "id" : 116851127177318400,
  "created_at" : "2011-09-22 12:27:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116607626153955328",
  "geo" : { },
  "id_str" : "116611164032602113",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates please dont",
  "id" : 116611164032602113,
  "in_reply_to_status_id" : 116607626153955328,
  "created_at" : "2011-09-21 20:34:02 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/IxlPetHd",
      "expanded_url" : "http:\/\/www.treatstudios.com\/animation\/e4xmas.html",
      "display_url" : "treatstudios.com\/animation\/e4xm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "116582911406379008",
  "text" : "CURRENT HI-DEFINITION STATUS: http:\/\/t.co\/IxlPetHd",
  "id" : 116582911406379008,
  "created_at" : "2011-09-21 18:41:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/EJFkESTg",
      "expanded_url" : "http:\/\/i.imgur.com\/nuR4V.gif",
      "display_url" : "i.imgur.com\/nuR4V.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "116576984590581760",
  "text" : "Current status: http:\/\/t.co\/EJFkESTg",
  "id" : 116576984590581760,
  "created_at" : "2011-09-21 18:18:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robby Grossman",
      "screen_name" : "freerobby",
      "indices" : [ 0, 10 ],
      "id_str" : "15023866",
      "id" : 15023866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116511028958867456",
  "geo" : { },
  "id_str" : "116515790664105984",
  "in_reply_to_user_id" : 15023866,
  "text" : "@freerobby it's been out! please do!",
  "id" : 116515790664105984,
  "in_reply_to_status_id" : 116511028958867456,
  "created_at" : "2011-09-21 14:15:03 +0000",
  "in_reply_to_screen_name" : "freerobby",
  "in_reply_to_user_id_str" : "15023866",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/VhwGnzTb",
      "expanded_url" : "http:\/\/www.1729.com\/blog\/ExtremeNegativeCodeDocumentation.html",
      "display_url" : "1729.com\/blog\/ExtremeNe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "116511388771418112",
  "text" : "Extreme commenting, or, how not to write code: http:\/\/t.co\/VhwGnzTb",
  "id" : 116511388771418112,
  "created_at" : "2011-09-21 13:57:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Lloyd",
      "screen_name" : "chrislloyd",
      "indices" : [ 3, 14 ],
      "id_str" : "5446832",
      "id" : 5446832
    }, {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "indices" : [ 41, 51 ],
      "id_str" : "220097555",
      "id" : 220097555
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 55, 61 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116508181353594885",
  "text" : "RT @chrislloyd: For anybody using Redis, @radishapp by @qrush is the shit.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Radish",
        "screen_name" : "radishapp",
        "indices" : [ 25, 35 ],
        "id_str" : "220097555",
        "id" : 220097555
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 39, 45 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116366898022715392",
    "text" : "For anybody using Redis, @radishapp by @qrush is the shit.",
    "id" : 116366898022715392,
    "created_at" : "2011-09-21 04:23:25 +0000",
    "user" : {
      "name" : "Chris Lloyd",
      "screen_name" : "chrislloyd",
      "protected" : false,
      "id_str" : "5446832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459865462927413248\/luicO7zK_normal.png",
      "id" : 5446832,
      "verified" : false
    }
  },
  "id" : 116508181353594885,
  "created_at" : "2011-09-21 13:44:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116196802453184512",
  "geo" : { },
  "id_str" : "116354069077049344",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene seeing this, i dont think we should mandate a versioning policy, and deleting gems is a touchy issue. email me sometime :)",
  "id" : 116354069077049344,
  "in_reply_to_status_id" : 116196802453184512,
  "created_at" : "2011-09-21 03:32:26 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116164897489948672",
  "geo" : { },
  "id_str" : "116353546378678272",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene hey dude, what could we improve?",
  "id" : 116353546378678272,
  "in_reply_to_status_id" : 116164897489948672,
  "created_at" : "2011-09-21 03:30:21 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/bHBAzOmP",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=MLEdvRrwnbM",
      "display_url" : "youtube.com\/watch?v=MLEdvR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "116352141865664512",
  "text" : "One small step for dom, one giant leap for dom http:\/\/t.co\/bHBAzOmP",
  "id" : 116352141865664512,
  "created_at" : "2011-09-21 03:24:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/cmflm4Yk",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=xI5U3TOyDoI",
      "display_url" : "youtube.com\/watch?v=xI5U3T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "116340118297657344",
  "text" : "Current status: http:\/\/t.co\/cmflm4Yk",
  "id" : 116340118297657344,
  "created_at" : "2011-09-21 02:37:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 70, 82 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/cWdgUT4g",
      "expanded_url" : "http:\/\/www.theregister.co.uk\/2011\/09\/20\/pjs_every_day\/",
      "display_url" : "theregister.co.uk\/2011\/09\/20\/pjs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "116257672550031360",
  "text" : "Haha \"US survey: 1 in 5 telecommuters work an hour or less a day\" \/cc @fredyatesiv http:\/\/t.co\/cWdgUT4g",
  "id" : 116257672550031360,
  "created_at" : "2011-09-20 21:09:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116241439029084160",
  "text" : "\"Google+ is now available for everyone!\" ... \"Google+ is not yet available for Google Apps.\"",
  "id" : 116241439029084160,
  "created_at" : "2011-09-20 20:04:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "codemash",
      "screen_name" : "codemash",
      "indices" : [ 3, 12 ],
      "id_str" : "7469772",
      "id" : 7469772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/7r9Yakjd",
      "expanded_url" : "http:\/\/codemash.org\/Speakers",
      "display_url" : "codemash.org\/Speakers"
    } ]
  },
  "geo" : { },
  "id_str" : "116235731915124737",
  "text" : "RT @codemash: Hey Rubyists! Y'all are seriously slacking with your submissions to CodeMash. Get cracking! http:\/\/t.co\/7r9Yakjd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/7r9Yakjd",
        "expanded_url" : "http:\/\/codemash.org\/Speakers",
        "display_url" : "codemash.org\/Speakers"
      } ]
    },
    "geo" : { },
    "id_str" : "116226592140828672",
    "text" : "Hey Rubyists! Y'all are seriously slacking with your submissions to CodeMash. Get cracking! http:\/\/t.co\/7r9Yakjd",
    "id" : 116226592140828672,
    "created_at" : "2011-09-20 19:05:53 +0000",
    "user" : {
      "name" : "codemash",
      "screen_name" : "codemash",
      "protected" : false,
      "id_str" : "7469772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575897195\/CodeMashLogoSquare_normal.png",
      "id" : 7469772,
      "verified" : false
    }
  },
  "id" : 116235731915124737,
  "created_at" : "2011-09-20 19:42:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Letterle",
      "screen_name" : "mletterle",
      "indices" : [ 0, 10 ],
      "id_str" : "458173",
      "id" : 458173
    }, {
      "name" : "codemash",
      "screen_name" : "codemash",
      "indices" : [ 11, 20 ],
      "id_str" : "7469772",
      "id" : 7469772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116233493398306816",
  "geo" : { },
  "id_str" : "116235530131357696",
  "in_reply_to_user_id" : 458173,
  "text" : "@mletterle @codemash Done!",
  "id" : 116235530131357696,
  "in_reply_to_status_id" : 116233493398306816,
  "created_at" : "2011-09-20 19:41:24 +0000",
  "in_reply_to_screen_name" : "mletterle",
  "in_reply_to_user_id_str" : "458173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116215937887244288",
  "text" : "holy shit, why are larabars so fucking delicious",
  "id" : 116215937887244288,
  "created_at" : "2011-09-20 18:23:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hiroshi Nakamura",
      "screen_name" : "nahi",
      "indices" : [ 0, 5 ],
      "id_str" : "5626592",
      "id" : 5626592
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 6, 17 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 18, 26 ],
      "id_str" : "670283",
      "id" : 670283
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 97, 107 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115995047958282240",
  "geo" : { },
  "id_str" : "116204258990362624",
  "in_reply_to_user_id" : 5626592,
  "text" : "@nahi @tenderlove @drbrain just want to say, i'm behind this 100%. we'll make it happen from the @gemcutter side!",
  "id" : 116204258990362624,
  "in_reply_to_status_id" : 115995047958282240,
  "created_at" : "2011-09-20 17:37:08 +0000",
  "in_reply_to_screen_name" : "nahi",
  "in_reply_to_user_id_str" : "5626592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik St. Martin",
      "screen_name" : "erikstmartin",
      "indices" : [ 0, 13 ],
      "id_str" : "14689054",
      "id" : 14689054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116202192502931457",
  "geo" : { },
  "id_str" : "116203879372300288",
  "in_reply_to_user_id" : 14689054,
  "text" : "@erikstmartin got an email for this exactly today too!",
  "id" : 116203879372300288,
  "in_reply_to_status_id" : 116202192502931457,
  "created_at" : "2011-09-20 17:35:38 +0000",
  "in_reply_to_screen_name" : "erikstmartin",
  "in_reply_to_user_id_str" : "14689054",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116200430433869824",
  "text" : "LOL RECRUITERS. \"I located your resume on Google.\" \"Please send me an updated copy of your resume.\"",
  "id" : 116200430433869824,
  "created_at" : "2011-09-20 17:21:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116130773056225280",
  "geo" : { },
  "id_str" : "116137428498132992",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius damn dude. Saw people still waiting for the 800 at waltham around 815, going nowhere near the rail today",
  "id" : 116137428498132992,
  "in_reply_to_status_id" : 116130773056225280,
  "created_at" : "2011-09-20 13:11:35 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "magnus stahre",
      "screen_name" : "magnusstahre",
      "indices" : [ 0, 13 ],
      "id_str" : "16980711",
      "id" : 16980711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115982376219328512",
  "geo" : { },
  "id_str" : "115994182472048640",
  "in_reply_to_user_id" : 16980711,
  "text" : "@magnusstahre seriously, I was hoping for my first priest ascension (5 so far!)",
  "id" : 115994182472048640,
  "in_reply_to_status_id" : 115982376219328512,
  "created_at" : "2011-09-20 03:42:22 +0000",
  "in_reply_to_screen_name" : "magnusstahre",
  "in_reply_to_user_id_str" : "16980711",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nethack",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/O6Z3MTxv",
      "expanded_url" : "http:\/\/alt.org\/nethack\/userdata\/D\/DoctorNick\/dumplog\/1316389047.nh343.txt",
      "display_url" : "alt.org\/nethack\/userda\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "115981066610806784",
  "text" : "Dammit! Drowned like an idiot. :( #nethack http:\/\/t.co\/O6Z3MTxv",
  "id" : 115981066610806784,
  "created_at" : "2011-09-20 02:50:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/YFTGP9Gn",
      "expanded_url" : "http:\/\/i.imgur.com\/JUpfK.jpg",
      "display_url" : "i.imgur.com\/JUpfK.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "115933615644344320",
  "text" : "yep, it's still minecraft: http:\/\/t.co\/YFTGP9Gn",
  "id" : 115933615644344320,
  "created_at" : "2011-09-19 23:41:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Didip Kerabat",
      "screen_name" : "didip",
      "indices" : [ 0, 6 ],
      "id_str" : "21841401",
      "id" : 21841401
    }, {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 7, 23 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115917909737484288",
  "geo" : { },
  "id_str" : "115918745876180992",
  "in_reply_to_user_id" : 21841401,
  "text" : "@didip @RobotDeathSquad having a specific problem or something?",
  "id" : 115918745876180992,
  "in_reply_to_status_id" : 115917909737484288,
  "created_at" : "2011-09-19 22:42:37 +0000",
  "in_reply_to_screen_name" : "didip",
  "in_reply_to_user_id_str" : "21841401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Diaz",
      "screen_name" : "ded",
      "indices" : [ 0, 4 ],
      "id_str" : "1199081",
      "id" : 1199081
    }, {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 5, 12 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115824304809189376",
  "geo" : { },
  "id_str" : "115870652015198208",
  "in_reply_to_user_id" : 1199081,
  "text" : "@ded @bryanl what is wrong with this",
  "id" : 115870652015198208,
  "in_reply_to_status_id" : 115824304809189376,
  "created_at" : "2011-09-19 19:31:30 +0000",
  "in_reply_to_screen_name" : "ded",
  "in_reply_to_user_id_str" : "1199081",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AKA JMoney",
      "screen_name" : "soederpop",
      "indices" : [ 0, 10 ],
      "id_str" : "18176421",
      "id" : 18176421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115865334937960448",
  "geo" : { },
  "id_str" : "115869141621149696",
  "in_reply_to_user_id" : 18176421,
  "text" : "@soederpop i'm honored by this fact",
  "id" : 115869141621149696,
  "in_reply_to_status_id" : 115865334937960448,
  "created_at" : "2011-09-19 19:25:30 +0000",
  "in_reply_to_screen_name" : "soederpop",
  "in_reply_to_user_id_str" : "18176421",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/HSagBhjh",
      "expanded_url" : "http:\/\/chickswithstevebuscemeyes.tumblr.com\/",
      "display_url" : "chickswithstevebuscemeyes.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "115853215928549377",
  "text" : "NOPE NOPE NOPE NOPE NOPE http:\/\/t.co\/HSagBhjh",
  "id" : 115853215928549377,
  "created_at" : "2011-09-19 18:22:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/h4nXuNwT",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=BxhqVrbixZc",
      "display_url" : "youtube.com\/watch?v=BxhqVr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "115830730189320192",
  "text" : "Current status: http:\/\/t.co\/h4nXuNwT",
  "id" : 115830730189320192,
  "created_at" : "2011-09-19 16:52:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas",
      "screen_name" : "plukevdh",
      "indices" : [ 0, 9 ],
      "id_str" : "14103289",
      "id" : 14103289
    }, {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 10, 16 ],
      "id_str" : "12459132",
      "id" : 12459132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115803512964788225",
  "geo" : { },
  "id_str" : "115805381518819328",
  "in_reply_to_user_id" : 14103289,
  "text" : "@plukevdh @alloy to be honest, that's ok to start. dont let design be a blocker to making the damn thing work",
  "id" : 115805381518819328,
  "in_reply_to_status_id" : 115803512964788225,
  "created_at" : "2011-09-19 15:12:09 +0000",
  "in_reply_to_screen_name" : "plukevdh",
  "in_reply_to_user_id_str" : "14103289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115801471676719104",
  "geo" : { },
  "id_str" : "115801995046166528",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy definitely could use more work\/patches pushing copy into the i18n config too",
  "id" : 115801995046166528,
  "in_reply_to_status_id" : 115801471676719104,
  "created_at" : "2011-09-19 14:58:41 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115801471676719104",
  "geo" : { },
  "id_str" : "115801896337408000",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy it's all open source, yes. just please change the colors and spend *some* effort customizing it. :) there's a i18n config too",
  "id" : 115801896337408000,
  "in_reply_to_status_id" : 115801471676719104,
  "created_at" : "2011-09-19 14:58:18 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 0, 12 ],
      "id_str" : "248477732",
      "id" : 248477732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115556378843688960",
  "geo" : { },
  "id_str" : "115557827443036160",
  "in_reply_to_user_id" : 248477732,
  "text" : "@ecarlsen912 dont you already have real animals to clean poop up from?",
  "id" : 115557827443036160,
  "in_reply_to_status_id" : 115556378843688960,
  "created_at" : "2011-09-18 22:48:27 +0000",
  "in_reply_to_screen_name" : "ecarlsen912",
  "in_reply_to_user_id_str" : "248477732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 18, 25 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/Yinhn00S",
      "expanded_url" : "http:\/\/roflamao.tumblr.com\/post\/10336522411",
      "display_url" : "roflamao.tumblr.com\/post\/103365224\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "115480807249952768",
  "text" : "I'm about to make @gabebw explode: http:\/\/t.co\/Yinhn00S",
  "id" : 115480807249952768,
  "created_at" : "2011-09-18 17:42:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115467675483906048",
  "text" : "Item server for TF2 is down, so classes are actually balanced and playing as normal. Not bad!",
  "id" : 115467675483906048,
  "created_at" : "2011-09-18 16:50:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/MLO5GpsV",
      "expanded_url" : "http:\/\/pull.imgfave.netdna-cdn.com\/image_cache\/1315714997140528.jpg",
      "display_url" : "pull.imgfave.netdna-cdn.com\/image_cache\/13\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "115249617322512384",
  "text" : "Probably the only picture that makes me long for the green line. Also, awesome parents are awesome: http:\/\/t.co\/MLO5GpsV",
  "id" : 115249617322512384,
  "created_at" : "2011-09-18 02:23:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115107994383024128",
  "text" : "Playing TF2 after ~2 years of ignoring it: WTF ARE ALL OF THESE WEAPONS",
  "id" : 115107994383024128,
  "created_at" : "2011-09-17 17:00:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/LjuxLfLt",
      "expanded_url" : "http:\/\/nighthacks.com\/roller\/jag\/entry\/i_m_alive",
      "display_url" : "nighthacks.com\/roller\/jag\/ent\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "114898893686317056",
  "text" : "Holy fuck. http:\/\/t.co\/LjuxLfLt",
  "id" : 114898893686317056,
  "created_at" : "2011-09-17 03:10:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114842721553879040",
  "geo" : { },
  "id_str" : "114843363445977088",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik pretty sure I snuck a limelight reference into the rails test suite too",
  "id" : 114843363445977088,
  "in_reply_to_status_id" : 114842721553879040,
  "created_at" : "2011-09-16 23:29:26 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Flanagan",
      "screen_name" : "jflanagan",
      "indices" : [ 0, 10 ],
      "id_str" : "14440037",
      "id" : 14440037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114797519816499200",
  "geo" : { },
  "id_str" : "114798360191434752",
  "in_reply_to_user_id" : 14440037,
  "text" : "@jflanagan minecraft? :P",
  "id" : 114798360191434752,
  "in_reply_to_status_id" : 114797519816499200,
  "created_at" : "2011-09-16 20:30:36 +0000",
  "in_reply_to_screen_name" : "jflanagan",
  "in_reply_to_user_id_str" : "14440037",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114751255330562048",
  "text" : "That was easy, change current commit date to right now: git commit --amend --date=\"$(date)\"",
  "id" : 114751255330562048,
  "created_at" : "2011-09-16 17:23:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114723757142188032",
  "text" : "# TODO: REMIND ME TO HURT YOU FOR LEAVING A TODO IN CODE",
  "id" : 114723757142188032,
  "created_at" : "2011-09-16 15:34:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114722468920426496",
  "text" : "Apparently I can't code on twitter either.",
  "id" : 114722468920426496,
  "created_at" : "2011-09-16 15:29:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114721548916629505",
  "text" : "I don't mind test-unit, but I've never messed up \"expected.should == actual\" in rspec. I have to check the assert_equal docs every time.",
  "id" : 114721548916629505,
  "created_at" : "2011-09-16 15:25:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacques Frost",
      "screen_name" : "jephjacques",
      "indices" : [ 0, 12 ],
      "id_str" : "7670202",
      "id" : 7670202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114368380525494272",
  "in_reply_to_user_id" : 7670202,
  "text" : "@jephjacques about time a Rush joke showed up!",
  "id" : 114368380525494272,
  "created_at" : "2011-09-15 16:02:01 +0000",
  "in_reply_to_screen_name" : "jephjacques",
  "in_reply_to_user_id_str" : "7670202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat McDermott",
      "screen_name" : "nerdofthunder",
      "indices" : [ 3, 17 ],
      "id_str" : "14457987",
      "id" : 14457987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/0z47HpoG",
      "expanded_url" : "http:\/\/i.imgur.com\/0L8YQ.jpg",
      "display_url" : "i.imgur.com\/0L8YQ.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "114333504657035264",
  "text" : "RT @nerdofthunder: Ladies and Gentlemen, RIT http:\/\/t.co\/0z47HpoG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http:\/\/t.co\/0z47HpoG",
        "expanded_url" : "http:\/\/i.imgur.com\/0L8YQ.jpg",
        "display_url" : "i.imgur.com\/0L8YQ.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "114333191569027074",
    "text" : "Ladies and Gentlemen, RIT http:\/\/t.co\/0z47HpoG",
    "id" : 114333191569027074,
    "created_at" : "2011-09-15 13:42:11 +0000",
    "user" : {
      "name" : "Pat McDermott",
      "screen_name" : "nerdofthunder",
      "protected" : false,
      "id_str" : "14457987",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542132642196750336\/ZZqZ7fEn_normal.jpeg",
      "id" : 14457987,
      "verified" : false
    }
  },
  "id" : 114333504657035264,
  "created_at" : "2011-09-15 13:43:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 0, 12 ],
      "id_str" : "8828952",
      "id" : 8828952
    }, {
      "name" : "Elliot Winkler",
      "screen_name" : "mcmire",
      "indices" : [ 13, 20 ],
      "id_str" : "14453888",
      "id" : 14453888
    }, {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 39, 47 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114123443422773248",
  "geo" : { },
  "id_str" : "114132184280997888",
  "in_reply_to_user_id" : 8828952,
  "text" : "@codeofficer @mcmire this was locally. @ddollar owns the server.",
  "id" : 114132184280997888,
  "in_reply_to_status_id" : 114123443422773248,
  "created_at" : "2011-09-15 00:23:27 +0000",
  "in_reply_to_screen_name" : "codeofficer",
  "in_reply_to_user_id_str" : "8828952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114121334358937601",
  "text" : "Found a dungeon w\/ 2 saddles, 2 buckets quite close to my first hut\/hole in 1.8. Moved in, mossy cobble ftw!",
  "id" : 114121334358937601,
  "created_at" : "2011-09-14 23:40:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114111884852068353",
  "text" : "Also, SO MANY ANIMALS",
  "id" : 114111884852068353,
  "created_at" : "2011-09-14 23:02:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114111847350808578",
  "text" : "Sprinting in Minecraft 1.8 = warp speed ENGAGE!",
  "id" : 114111847350808578,
  "created_at" : "2011-09-14 23:02:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114108505270657025",
  "geo" : { },
  "id_str" : "114109779001098240",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant SUCCULENT RUBDOWNZZZ",
  "id" : 114109779001098240,
  "in_reply_to_status_id" : 114108505270657025,
  "created_at" : "2011-09-14 22:54:26 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    }, {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 20, 29 ],
      "id_str" : "148198686",
      "id" : 148198686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/a6sz0y6I",
      "expanded_url" : "https:\/\/dnsimple.com\/r\/35d1afbfe92d46",
      "display_url" : "dnsimple.com\/r\/35d1afbfe92d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "114079807297425408",
  "geo" : { },
  "id_str" : "114080664030162944",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv choose @dnsimple! http:\/\/t.co\/a6sz0y6I",
  "id" : 114080664030162944,
  "in_reply_to_status_id" : 114079807297425408,
  "created_at" : "2011-09-14 20:58:44 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 24 ],
      "url" : "http:\/\/t.co\/WAXqw6c",
      "expanded_url" : "http:\/\/raspberry-style.net\/",
      "display_url" : "raspberry-style.net"
    } ]
  },
  "geo" : { },
  "id_str" : "114050810266140672",
  "text" : "OWWW http:\/\/t.co\/WAXqw6c",
  "id" : 114050810266140672,
  "created_at" : "2011-09-14 19:00:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/vJ4BVCk",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=eBHHW-ijxJM#t=1m10s",
      "display_url" : "youtube.com\/watch?v=eBHHW-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "113988960002392064",
  "text" : "Current status: http:\/\/t.co\/vJ4BVCk",
  "id" : 113988960002392064,
  "created_at" : "2011-09-14 14:54:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113985751141711872",
  "text" : "Why don't database tools understand URIs? I'm looking at you, mysql, psql, redis-cli :(",
  "id" : 113985751141711872,
  "created_at" : "2011-09-14 14:41:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http:\/\/t.co\/D4vgh4L",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=F-a1PLxhuQc&feature=fvst",
      "display_url" : "youtube.com\/watch?v=F-a1PL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "113984579962023936",
  "text" : "These guys are way wacked out on coke, but they shred like beasts: http:\/\/t.co\/D4vgh4L",
  "id" : 113984579962023936,
  "created_at" : "2011-09-14 14:36:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 74 ],
      "url" : "http:\/\/t.co\/vAzZMbC",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/7271137884\/testing-cron-on-heroku",
      "display_url" : "robots.thoughtbot.com\/post\/727113788\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "113974591461924864",
  "geo" : { },
  "id_str" : "113975570433449984",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan a recent example of the right way to do this: http:\/\/t.co\/vAzZMbC",
  "id" : 113975570433449984,
  "in_reply_to_status_id" : 113974591461924864,
  "created_at" : "2011-09-14 14:01:08 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 29 ],
      "url" : "http:\/\/t.co\/BDKTPPw",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=MLEdvRrwnbM&ob=av3e",
      "display_url" : "youtube.com\/watch?v=MLEdvR\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "113955229598367744",
  "geo" : { },
  "id_str" : "113956193222918144",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant http:\/\/t.co\/BDKTPPw",
  "id" : 113956193222918144,
  "in_reply_to_status_id" : 113955229598367744,
  "created_at" : "2011-09-14 12:44:08 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 58 ],
      "url" : "http:\/\/t.co\/F8dBaKc",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=g4ouPGGLI6Q#t=1m9s",
      "display_url" : "youtube.com\/watch?v=g4ouPG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "113955976280936451",
  "text" : "Actually it's probably just this part: http:\/\/t.co\/F8dBaKc",
  "id" : 113955976280936451,
  "created_at" : "2011-09-14 12:43:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/8TJeQfe",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=g4ouPGGLI6Q",
      "display_url" : "youtube.com\/watch?v=g4ouPG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "113954358814715904",
  "text" : "Current status: http:\/\/t.co\/8TJeQfe",
  "id" : 113954358814715904,
  "created_at" : "2011-09-14 12:36:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 11, 17 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 18, 25 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Gabriel Horner",
      "screen_name" : "cldwalker",
      "indices" : [ 30, 40 ],
      "id_str" : "19846068",
      "id" : 19846068
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 66, 76 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113765320065417216",
  "text" : "Holy crap, @cmeik @sferik and @cldwalker have been kicking ass on @gemcutter the past few weeks. Contributors are awesome!",
  "id" : 113765320065417216,
  "created_at" : "2011-09-14 00:05:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 3, 12 ],
      "id_str" : "21431343",
      "id" : 21431343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113755900468137984",
  "text" : "At @bostonrb! Overall lesson so far: MOAR TESTING",
  "id" : 113755900468137984,
  "created_at" : "2011-09-13 23:28:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 0, 12 ],
      "id_str" : "517029319",
      "id" : 517029319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113751511896563712",
  "text" : "@seacreature this is called YAGNI, cmon bro",
  "id" : 113751511896563712,
  "created_at" : "2011-09-13 23:10:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Nielsen",
      "screen_name" : "xunker",
      "indices" : [ 0, 7 ],
      "id_str" : "3301611",
      "id" : 3301611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113729408212271104",
  "geo" : { },
  "id_str" : "113729529989705728",
  "in_reply_to_user_id" : 3301611,
  "text" : "@xunker relying on your application to do your work is a smell",
  "id" : 113729529989705728,
  "in_reply_to_status_id" : 113729408212271104,
  "created_at" : "2011-09-13 21:43:27 +0000",
  "in_reply_to_screen_name" : "xunker",
  "in_reply_to_user_id_str" : "3301611",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vimeo",
      "screen_name" : "Vimeo",
      "indices" : [ 30, 36 ],
      "id_str" : "14718218",
      "id" : 14718218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113726657826791425",
  "text" : "I wonder if I have to pay for @vimeo plus just to get videos to start when the page loads.",
  "id" : 113726657826791425,
  "created_at" : "2011-09-13 21:32:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 0, 4 ],
      "id_str" : "10079052",
      "id" : 10079052
    }, {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 5, 11 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113714178170175488",
  "geo" : { },
  "id_str" : "113715267141509120",
  "in_reply_to_user_id" : 10079052,
  "text" : "@rjs @jamis the whole problem is that assumption, any condition on the  association feels like a broken promise to anyone who consumes it",
  "id" : 113715267141509120,
  "in_reply_to_status_id" : 113714178170175488,
  "created_at" : "2011-09-13 20:46:47 +0000",
  "in_reply_to_screen_name" : "rjs",
  "in_reply_to_user_id_str" : "10079052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113712746666799104",
  "geo" : { },
  "id_str" : "113713894484226049",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis +1, default ordering on associations has bitten me too. one of those things you have to feel the pain first to figure out :(",
  "id" : 113713894484226049,
  "in_reply_to_status_id" : 113712746666799104,
  "created_at" : "2011-09-13 20:41:19 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113708058584170496",
  "text" : "-30 seconds of load time on a simple spec run with guard\/spork set up. This is...much better",
  "id" : 113708058584170496,
  "created_at" : "2011-09-13 20:18:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113683781059223553",
  "text" : "Realizing now if I used Sinatra instead of Jekyll for my wedding site, I could have ran `shotgun wedding.rb`. Missed the chance!",
  "id" : 113683781059223553,
  "created_at" : "2011-09-13 18:41:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Alba",
      "screen_name" : "joealba",
      "indices" : [ 0, 8 ],
      "id_str" : "9664212",
      "id" : 9664212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113570062656475136",
  "geo" : { },
  "id_str" : "113575692880461825",
  "in_reply_to_user_id" : 9664212,
  "text" : "@joealba oh wtf. Just asked on the mailing list about it, I had no idea.",
  "id" : 113575692880461825,
  "in_reply_to_status_id" : 113570062656475136,
  "created_at" : "2011-09-13 11:32:09 +0000",
  "in_reply_to_screen_name" : "joealba",
  "in_reply_to_user_id_str" : "9664212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 29, 36 ],
      "id_str" : "6505422",
      "id" : 6505422
    }, {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 37, 44 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 24 ],
      "url" : "http:\/\/t.co\/Nw6II4y",
      "expanded_url" : "http:\/\/www.masscomics.com\/",
      "display_url" : "masscomics.com"
    } ]
  },
  "geo" : { },
  "id_str" : "113470082902007808",
  "text" : "Ooh! http:\/\/t.co\/Nw6II4y \/cc @jyurek @gabebw",
  "id" : 113470082902007808,
  "created_at" : "2011-09-13 04:32:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113457335069974528",
  "geo" : { },
  "id_str" : "113469383115948033",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape pretty sure slavery is abolished bro",
  "id" : 113469383115948033,
  "in_reply_to_status_id" : 113457335069974528,
  "created_at" : "2011-09-13 04:29:43 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113382304717611008",
  "geo" : { },
  "id_str" : "113383548681064448",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant it's in such a shady area dude",
  "id" : 113383548681064448,
  "in_reply_to_status_id" : 113382304717611008,
  "created_at" : "2011-09-12 22:48:39 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113377608586113026",
  "text" : "The internet was a lot less stressful for me when I wasn't paying attention to it.",
  "id" : 113377608586113026,
  "created_at" : "2011-09-12 22:25:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Globe Support",
      "screen_name" : "GlobeSupport",
      "indices" : [ 0, 13 ],
      "id_str" : "316711342",
      "id" : 316711342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113376126927245312",
  "geo" : { },
  "id_str" : "113376939531710464",
  "in_reply_to_user_id" : 316711342,
  "text" : "@GlobeSupport at least someone there is listening, but I see no reason behing putting a sign-in wall on *EVERY* story.",
  "id" : 113376939531710464,
  "in_reply_to_status_id" : 113376126927245312,
  "created_at" : "2011-09-12 22:22:23 +0000",
  "in_reply_to_screen_name" : "GlobeSupport",
  "in_reply_to_user_id_str" : "316711342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Boston Globe",
      "screen_name" : "BostonGlobe",
      "indices" : [ 27, 39 ],
      "id_str" : "95431448",
      "id" : 95431448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http:\/\/t.co\/cP7XsSr",
      "expanded_url" : "http:\/\/www.bostonglobe.com\/eom\/SysConfig\/WebPortal\/BostonGlobe\/Framework\/regi\/coldwell-banker-new-form.jsp?sess=new",
      "display_url" : "bostonglobe.com\/eom\/SysConfig\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "113375880495108096",
  "text" : "This bullshit is not news, @BostonGlobe, no matter how much fluid CSS you have. http:\/\/t.co\/cP7XsSr",
  "id" : 113375880495108096,
  "created_at" : "2011-09-12 22:18:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http:\/\/t.co\/bL3yW0n",
      "expanded_url" : "http:\/\/oreilly.com\/images\/animals\/rabbit-toy.gif",
      "display_url" : "oreilly.com\/images\/animals\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "113341933409148928",
  "text" : "O'Reilly, I don't want your emails, or YOUR CREEPY FUCKING BUNNIES in my inbox. http:\/\/t.co\/bL3yW0n",
  "id" : 113341933409148928,
  "created_at" : "2011-09-12 20:03:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113322866300297216",
  "text" : "Yep, just ran: \"bake -D ass\"",
  "id" : 113322866300297216,
  "created_at" : "2011-09-12 18:47:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113243314114928640",
  "geo" : { },
  "id_str" : "113246440834334720",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius don't give up on your dreams dude",
  "id" : 113246440834334720,
  "in_reply_to_status_id" : 113243314114928640,
  "created_at" : "2011-09-12 13:43:50 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/d2U7jMj",
      "expanded_url" : "http:\/\/bit.ly\/q8t0qD",
      "display_url" : "bit.ly\/q8t0qD"
    } ]
  },
  "geo" : { },
  "id_str" : "113230100912291842",
  "text" : "Both of my normal inbound trains canceled, no message or warning on the track. Welcome back Monday! http:\/\/t.co\/d2U7jMj",
  "id" : 113230100912291842,
  "created_at" : "2011-09-12 12:38:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113092929123389442",
  "text" : "Starting to understand why I like Star Trek so much. Each episode is basically a 45 minute debugging session.",
  "id" : 113092929123389442,
  "created_at" : "2011-09-12 03:33:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 47, 55 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 88 ],
      "url" : "http:\/\/t.co\/IBgE2Ai",
      "expanded_url" : "http:\/\/yfrog.com\/nyoaqpyj",
      "display_url" : "yfrog.com\/nyoaqpyj"
    } ]
  },
  "geo" : { },
  "id_str" : "112626752446144512",
  "text" : "Haha, best wedding guestbook note ever. Thanks @jayunit and lindsay! http:\/\/t.co\/IBgE2Ai",
  "id" : 112626752446144512,
  "created_at" : "2011-09-10 20:41:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/2l3luDu",
      "expanded_url" : "http:\/\/27.media.tumblr.com\/tumblr_lqtpwpmRb51qcfgllo1_r1_500.gif",
      "display_url" : "27.media.tumblr.com\/tumblr_lqtpwpm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "112624667151433728",
  "text" : "Current status: http:\/\/t.co\/2l3luDu",
  "id" : 112624667151433728,
  "created_at" : "2011-09-10 20:33:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112623797802246144",
  "text" : "Apparently my jokes are RIPE FOR DISRUPTION",
  "id" : 112623797802246144,
  "created_at" : "2011-09-10 20:29:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Bedell",
      "screen_name" : "kbedell",
      "indices" : [ 0, 8 ],
      "id_str" : "6578432",
      "id" : 6578432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112622854448750592",
  "geo" : { },
  "id_str" : "112623099542896641",
  "in_reply_to_user_id" : 6578432,
  "text" : "@kbedell mine was a joke",
  "id" : 112623099542896641,
  "in_reply_to_status_id" : 112622854448750592,
  "created_at" : "2011-09-10 20:26:54 +0000",
  "in_reply_to_screen_name" : "kbedell",
  "in_reply_to_user_id_str" : "6578432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112621697491935233",
  "text" : "On my vacation, I wrote a JavaScript MVC framework, read 400 programming papers, and disrupted the restaurant industry. How was your week?",
  "id" : 112621697491935233,
  "created_at" : "2011-09-10 20:21:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112551138624151552",
  "text" : "Back in Boston, returning to normalcy...and many emails...",
  "id" : 112551138624151552,
  "created_at" : "2011-09-10 15:40:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/xUHRp9A",
      "expanded_url" : "http:\/\/yfrog.com\/h327359563j",
      "display_url" : "yfrog.com\/h327359563j"
    } ]
  },
  "in_reply_to_status_id_str" : "112318538215198721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.87675, -69.992584 ]
  },
  "id_str" : "112345288882139136",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant haha, alive and well! At the drivein. http:\/\/t.co\/xUHRp9A",
  "id" : 112345288882139136,
  "in_reply_to_status_id" : 112318538215198721,
  "created_at" : "2011-09-10 02:02:58 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/gQkMV75",
      "expanded_url" : "http:\/\/yfrog.com\/h3k3gelj",
      "display_url" : "yfrog.com\/h3k3gelj"
    } ]
  },
  "geo" : { },
  "id_str" : "110073699767558144",
  "text" : "Current status: http:\/\/t.co\/gQkMV75",
  "id" : 110073699767558144,
  "created_at" : "2011-09-03 19:36:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109872073987465216",
  "geo" : { },
  "id_str" : "109951807865880576",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu today dude!",
  "id" : 109951807865880576,
  "in_reply_to_status_id" : 109872073987465216,
  "created_at" : "2011-09-03 11:32:08 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 74, 81 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Gabriel Horner",
      "screen_name" : "cldwalker",
      "indices" : [ 82, 92 ],
      "id_str" : "19846068",
      "id" : 19846068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 66 ],
      "url" : "http:\/\/t.co\/3fiqRJC",
      "expanded_url" : "http:\/\/dalibornasevic.com\/posts\/27-rubygems-too-many-connection-resets",
      "display_url" : "dalibornasevic.com\/posts\/27-rubyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "109357258479120386",
  "text" : "Whoa, looks like we have a major issue here... http:\/\/t.co\/3fiqRJC :( \/cc @sferik @cldwalker",
  "id" : 109357258479120386,
  "created_at" : "2011-09-01 20:09:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
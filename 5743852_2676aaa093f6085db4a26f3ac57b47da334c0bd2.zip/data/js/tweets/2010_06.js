Grailbird.data.tweets_2010_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nappa",
      "screen_name" : "DBZNappa",
      "indices" : [ 30, 39 ],
      "id_str" : "89905959",
      "id" : 89905959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17454022264",
  "text" : "New favorite twitter account: @DBZNappa",
  "id" : 17454022264,
  "created_at" : "2010-07-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17492372884",
  "geo" : { },
  "id_str" : "17498536456",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini it's a work in progress: http:\/\/gist.github.com\/460079",
  "id" : 17498536456,
  "in_reply_to_status_id" : 17492372884,
  "created_at" : "2010-07-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17516290885",
  "text" : "We've been to Mars? I want to believe. http:\/\/www.youtube.com\/watch?v=Isc5cKwi3GU",
  "id" : 17516290885,
  "created_at" : "2010-07-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 0, 7 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17519672144",
  "geo" : { },
  "id_str" : "17519752521",
  "in_reply_to_user_id" : 14237099,
  "text" : "@geemus nah, require 'fog' spits out \"Loading fog...\" \"AWS servers ready\" etc etc. would love to stop that from happening.",
  "id" : 17519752521,
  "in_reply_to_status_id" : 17519672144,
  "created_at" : "2010-07-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "geemus",
  "in_reply_to_user_id_str" : "14237099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17521495672",
  "geo" : { },
  "id_str" : "17521891224",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh care to translate wtf that means in git?",
  "id" : 17521891224,
  "in_reply_to_status_id" : 17521495672,
  "created_at" : "2010-07-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17522043965",
  "geo" : { },
  "id_str" : "17522134505",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh that sounds horrifying. why wouldnt you use ftp\/dropbox?",
  "id" : 17522134505,
  "in_reply_to_status_id" : 17522043965,
  "created_at" : "2010-07-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nosqlsummer",
      "indices" : [ 3, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17527802991",
  "text" : "At #nosqlsummer Boston in the Microsoft NERD. Still the best view of Boston.",
  "id" : 17527802991,
  "created_at" : "2010-07-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla",
      "screen_name" : "mozilla",
      "indices" : [ 13, 21 ],
      "id_str" : "106682853",
      "id" : 106682853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17528616264",
  "text" : "Learning how @mozilla uses HBase and Hadoop. Big data sounds scary and exciting, as usual.",
  "id" : 17528616264,
  "created_at" : "2010-07-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17356068060",
  "geo" : { },
  "id_str" : "17372397716",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu BGREWRITEAOF",
  "id" : 17372397716,
  "in_reply_to_status_id" : 17356068060,
  "created_at" : "2010-06-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17373707782",
  "geo" : { },
  "id_str" : "17373817375",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu yeah, daily",
  "id" : 17373817375,
  "in_reply_to_status_id" : 17373707782,
  "created_at" : "2010-06-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felipe Coury",
      "screen_name" : "fcoury",
      "indices" : [ 0, 7 ],
      "id_str" : "4546681",
      "id" : 4546681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17380393828",
  "geo" : { },
  "id_str" : "17381069389",
  "in_reply_to_user_id" : 4546681,
  "text" : "@fcoury have a letter in the version number. \"1.0.0.pre\", \"3.0.0.beta.1\" etc",
  "id" : 17381069389,
  "in_reply_to_status_id" : 17380393828,
  "created_at" : "2010-06-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "fcoury",
  "in_reply_to_user_id_str" : "4546681",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17381127173",
  "text" : "tmux is great. it's like screen without the constant pain. http:\/\/tmux.sourceforge.net\/ `brew install tmux`",
  "id" : 17381127173,
  "created_at" : "2010-06-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17381801492",
  "geo" : { },
  "id_str" : "17382022380",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick so far, vertical splits without having to compile custom versions, better process info, nicer default config.",
  "id" : 17382022380,
  "in_reply_to_status_id" : 17381801492,
  "created_at" : "2010-06-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Blake",
      "screen_name" : "blaix",
      "indices" : [ 0, 6 ],
      "id_str" : "8239892",
      "id" : 8239892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17407729158",
  "geo" : { },
  "id_str" : "17408956558",
  "in_reply_to_user_id" : 8239892,
  "text" : "@blaix screen does have vsplit, you just have to apply some dude's patch and hope it works. This is way better.",
  "id" : 17408956558,
  "in_reply_to_status_id" : 17407729158,
  "created_at" : "2010-06-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "blaix",
  "in_reply_to_user_id_str" : "8239892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dannytatom",
      "screen_name" : "dannytatom",
      "indices" : [ 62, 73 ],
      "id_str" : "2500287421",
      "id" : 2500287421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17292879289",
  "text" : "I don't care. http:\/\/www.youtube.com\/watch?v=FL7yD-0pqZg (via @dannytatom)",
  "id" : 17292879289,
  "created_at" : "2010-06-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17302283418",
  "text" : "Just wrote a WEBrick servlet. That rack shit is so 2009.",
  "id" : 17302283418,
  "created_at" : "2010-06-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17303030598",
  "text" : "Wrote it because Rack::Server(:app =&gt; lambda) is broken in rack 1.2.1. WEBrick works fine, implementation isn't as messy as you think.",
  "id" : 17303030598,
  "created_at" : "2010-06-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17303394149",
  "text" : "FINALLY found a valid use for `yes`. WOOT.",
  "id" : 17303394149,
  "created_at" : "2010-06-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klondike Gold",
      "screen_name" : "Klondike",
      "indices" : [ 0, 9 ],
      "id_str" : "298070410",
      "id" : 298070410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17304927938",
  "geo" : { },
  "id_str" : "17304988371",
  "in_reply_to_user_id" : 5232171,
  "text" : "@Klondike I'm super serial, guys!",
  "id" : 17304988371,
  "in_reply_to_status_id" : 17304927938,
  "created_at" : "2010-06-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Sternal-Johnson",
      "screen_name" : "ceejayoz",
      "indices" : [ 0, 9 ],
      "id_str" : "717973",
      "id" : 717973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17304238419",
  "geo" : { },
  "id_str" : "17305049668",
  "in_reply_to_user_id" : 717973,
  "text" : "@ceejayoz `yes no`",
  "id" : 17305049668,
  "in_reply_to_status_id" : 17304238419,
  "created_at" : "2010-06-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "ceejayoz",
  "in_reply_to_user_id_str" : "717973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17305590584",
  "text" : "CURSES, WEBRICK!!! \"unsupported method `PUT'.\"",
  "id" : 17305590584,
  "created_at" : "2010-06-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17327339233",
  "text" : "SICP vs the Necronomicon: http:\/\/bit.ly\/9ZiU0h",
  "id" : 17327339233,
  "created_at" : "2010-06-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Koukoullis",
      "screen_name" : "kouky",
      "indices" : [ 0, 6 ],
      "id_str" : "7466612",
      "id" : 7466612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17327509128",
  "geo" : { },
  "id_str" : "17341117811",
  "in_reply_to_user_id" : 7466612,
  "text" : "@kouky we support open search too, so you could add it through firefox\/chrome to make it even easier. or `gem search`.",
  "id" : 17341117811,
  "in_reply_to_status_id" : 17327509128,
  "created_at" : "2010-06-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "kouky",
  "in_reply_to_user_id_str" : "7466612",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hinegardner",
      "screen_name" : "copiousfreetime",
      "indices" : [ 0, 16 ],
      "id_str" : "14601522",
      "id" : 14601522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17341706730",
  "geo" : { },
  "id_str" : "17344630360",
  "in_reply_to_user_id" : 14601522,
  "text" : "@copiousfreetime last i heard, ~12gigs. I haven't made a mirror myself lately.",
  "id" : 17344630360,
  "in_reply_to_status_id" : 17341706730,
  "created_at" : "2010-06-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "copiousfreetime",
  "in_reply_to_user_id_str" : "14601522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Silber",
      "screen_name" : "wifelette",
      "indices" : [ 0, 10 ],
      "id_str" : "11320942",
      "id" : 11320942
    }, {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 31, 42 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17365259837",
  "in_reply_to_user_id" : 11320942,
  "text" : "@wifelette congrats! say hi to @shellscape for me!",
  "id" : 17365259837,
  "created_at" : "2010-06-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "wifelette",
  "in_reply_to_user_id_str" : "11320942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17215309076",
  "text" : "RT @gemcutter: Lots of changes deployed tonight, you can finally edit your email and handle! http:\/\/is.gd\/d70Rc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "17215283546",
    "text" : "Lots of changes deployed tonight, you can finally edit your email and handle! http:\/\/is.gd\/d70Rc",
    "id" : 17215283546,
    "created_at" : "2010-06-28 02:06:44 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 17215309076,
  "created_at" : "2010-06-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 0, 9 ],
      "id_str" : "9267332",
      "id" : 9267332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17255756838",
  "geo" : { },
  "id_str" : "17256136028",
  "in_reply_to_user_id" : 9267332,
  "text" : "@rtomayko crap. looking into it.",
  "id" : 17256136028,
  "in_reply_to_status_id" : 17255756838,
  "created_at" : "2010-06-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "rtomayko",
  "in_reply_to_user_id_str" : "9267332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    }, {
      "name" : "Forrst",
      "screen_name" : "forrst",
      "indices" : [ 45, 52 ],
      "id_str" : "2596652364",
      "id" : 2596652364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17266157129",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger any chance of getting some more @forrst invites? want to hook up some bros",
  "id" : 17266157129,
  "created_at" : "2010-06-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Landau",
      "screen_name" : "brianjlandau",
      "indices" : [ 0, 13 ],
      "id_str" : "2145",
      "id" : 2145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17265896673",
  "geo" : { },
  "id_str" : "17266805851",
  "in_reply_to_user_id" : 2145,
  "text" : "@brianjlandau maybe soon? :) http:\/\/akasentai.com",
  "id" : 17266805851,
  "in_reply_to_status_id" : 17265896673,
  "created_at" : "2010-06-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "brianjlandau",
  "in_reply_to_user_id_str" : "2145",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17268081565",
  "text" : "Ok, seriously, we need to get a hold of http:\/\/github.com\/flori for http:\/\/is.gd\/d7Wvv. Who's in Germany? Is he even alive?",
  "id" : 17268081565,
  "created_at" : "2010-06-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17268822044",
  "geo" : { },
  "id_str" : "17274100753",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger thanks! trying an experiment to tag dev stuff throughout the week at work, share with coworkers.",
  "id" : 17274100753,
  "in_reply_to_status_id" : 17268822044,
  "created_at" : "2010-06-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17268822044",
  "geo" : { },
  "id_str" : "17274639219",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger speaking of this, will tag listings ever be public? hell, the whole site? :)",
  "id" : 17274639219,
  "in_reply_to_status_id" : 17268822044,
  "created_at" : "2010-06-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Gisi",
      "screen_name" : "gisikw",
      "indices" : [ 0, 7 ],
      "id_str" : "14308739",
      "id" : 14308739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17280795322",
  "geo" : { },
  "id_str" : "17281166245",
  "in_reply_to_user_id" : 14308739,
  "text" : "@gisikw about time! Congrats!",
  "id" : 17281166245,
  "in_reply_to_status_id" : 17280795322,
  "created_at" : "2010-06-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "gisikw",
  "in_reply_to_user_id_str" : "14308739",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17141738358",
  "text" : "I thought Canadians were supposed to be friendly! http:\/\/www.ctv.ca\/CTVNews\/TopStories\/20100626\/summit-protests-100626\/",
  "id" : 17141738358,
  "created_at" : "2010-06-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 42, 53 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17179136955",
  "text" : "GIANT ROBOT http:\/\/twitpic.com\/20hiwb \/cc @thoughtbot",
  "id" : 17179136955,
  "created_at" : "2010-06-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nikki graziano",
      "screen_name" : "nikkigraziano",
      "indices" : [ 0, 14 ],
      "id_str" : "12914422",
      "id" : 12914422
    }, {
      "name" : "gabegl\u00F6vesy\u00F6u",
      "screen_name" : "gabeglovesyou",
      "indices" : [ 49, 63 ],
      "id_str" : "14465929",
      "id" : 14465929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17187243485",
  "geo" : { },
  "id_str" : "17188835730",
  "in_reply_to_user_id" : 12914422,
  "text" : "@nikkigraziano http:\/\/i.imgur.com\/LnJkv.gif (via @gabeglovesyou)",
  "id" : 17188835730,
  "in_reply_to_status_id" : 17187243485,
  "created_at" : "2010-06-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "nikkigraziano",
  "in_reply_to_user_id_str" : "12914422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Wilk",
      "screen_name" : "josephwilk",
      "indices" : [ 0, 11 ],
      "id_str" : "14321259",
      "id" : 14321259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17198540493",
  "geo" : { },
  "id_str" : "17198702169",
  "in_reply_to_user_id" : 14321259,
  "text" : "@josephwilk soon maybe? :) http:\/\/akasentai.com",
  "id" : 17198702169,
  "in_reply_to_status_id" : 17198540493,
  "created_at" : "2010-06-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "josephwilk",
  "in_reply_to_user_id_str" : "14321259",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16971819165",
  "text" : "If you know, get him to look at this please! http:\/\/help.rubygems.org\/discussions\/questions\/25-java-support-for-the-json-gem",
  "id" : 16971819165,
  "created_at" : "2010-06-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dannytatom",
      "screen_name" : "dannytatom",
      "indices" : [ 0, 11 ],
      "id_str" : "2500287421",
      "id" : 2500287421
    }, {
      "name" : "Ryan Grove",
      "screen_name" : "yaypie",
      "indices" : [ 12, 19 ],
      "id_str" : "11639232",
      "id" : 11639232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16971345028",
  "geo" : { },
  "id_str" : "16972062579",
  "in_reply_to_user_id" : 17012066,
  "text" : "@dannytatom @yaypie seems to be dead, or he just doesn't respond. :(",
  "id" : 16972062579,
  "in_reply_to_status_id" : 16971345028,
  "created_at" : "2010-06-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "rabitrup",
  "in_reply_to_user_id_str" : "17012066",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paolo Perrotta",
      "screen_name" : "nusco",
      "indices" : [ 3, 9 ],
      "id_str" : "5944932",
      "id" : 5944932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17014480435",
  "text" : "RT @nusco: The New Ruby Ecosystem: http:\/\/tinyurl.com\/35vmg4r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "17005044261",
    "text" : "The New Ruby Ecosystem: http:\/\/tinyurl.com\/35vmg4r",
    "id" : 17005044261,
    "created_at" : "2010-06-25 10:48:40 +0000",
    "user" : {
      "name" : "Paolo Perrotta",
      "screen_name" : "nusco",
      "protected" : false,
      "id_str" : "5944932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480099295912153090\/cwwY7hb5_normal.jpeg",
      "id" : 5944932,
      "verified" : false
    }
  },
  "id" : 17014480435,
  "created_at" : "2010-06-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17014807635",
  "text" : "I am so bad at window management and Spaces. Loads of screen real estate, and I'm still single-window focused and only use 2 spaces.",
  "id" : 17014807635,
  "created_at" : "2010-06-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 0, 13 ],
      "id_str" : "11587602",
      "id" : 11587602
    }, {
      "name" : "Darcy Laycock",
      "screen_name" : "Sutto",
      "indices" : [ 14, 20 ],
      "id_str" : "5099921",
      "id" : 5099921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17020279390",
  "geo" : { },
  "id_str" : "17020950463",
  "in_reply_to_user_id" : 11587602,
  "text" : "@wayneeseguin @Sutto you can start by releasing 1.0.0. your 0.1.* scheme bugs the heck out of me :)",
  "id" : 17020950463,
  "in_reply_to_status_id" : 17020279390,
  "created_at" : "2010-06-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "wayneeseguin",
  "in_reply_to_user_id_str" : "11587602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17043386676",
  "text" : "THE OCARINA OF RHYME. http:\/\/8tracks.com\/teamteamwork\/the-ocarina-of-rhyme",
  "id" : 17043386676,
  "created_at" : "2010-06-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "redis",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16894724010",
  "text" : "Any streams of the #redis meetup online yet?",
  "id" : 16894724010,
  "created_at" : "2010-06-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 9, 17 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "redis",
      "indices" : [ 26, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16896144670",
  "text" : "Watching @antirez talk on #redis from afar: http:\/\/www.ustream.tv\/channel\/sf-redis-meetup",
  "id" : 16896144670,
  "created_at" : "2010-06-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "redis",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16899918226",
  "text" : "Of course, internet dies just as the #redis meetup was getting fun.",
  "id" : 16899918226,
  "created_at" : "2010-06-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 89, 101 ],
      "id_str" : "11886642",
      "id" : 11886642
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 106, 117 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16937314573",
  "text" : "RT @gemcutter: Just deployed a revamped nav\/signin area and better form styles thanks to @fredyatesiv and @thoughtbot!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fred Yates",
        "screen_name" : "fredyatesiv",
        "indices" : [ 74, 86 ],
        "id_str" : "11886642",
        "id" : 11886642
      }, {
        "name" : "thoughtbot",
        "screen_name" : "thoughtbot",
        "indices" : [ 91, 102 ],
        "id_str" : "14114392",
        "id" : 14114392
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "16937278939",
    "text" : "Just deployed a revamped nav\/signin area and better form styles thanks to @fredyatesiv and @thoughtbot!",
    "id" : 16937278939,
    "created_at" : "2010-06-24 15:28:32 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 16937314573,
  "created_at" : "2010-06-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16938104958",
  "geo" : { },
  "id_str" : "16939543705",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats how is that not different than config.gem's, if everything was vendored?",
  "id" : 16939543705,
  "in_reply_to_status_id" : 16938104958,
  "created_at" : "2010-06-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah rich",
      "screen_name" : "micahbrich",
      "indices" : [ 0, 11 ],
      "id_str" : "14566614",
      "id" : 14566614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16942101716",
  "geo" : { },
  "id_str" : "16949248626",
  "in_reply_to_user_id" : 14566614,
  "text" : "@micahbrich yeah, strange...only happens on the sign in page. definitely will look into it.",
  "id" : 16949248626,
  "in_reply_to_status_id" : 16942101716,
  "created_at" : "2010-06-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "micahbrich",
  "in_reply_to_user_id_str" : "14566614",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16971194934",
  "text" : "Does anyone know how to get a hold of the author of the json gem? http:\/\/rubygems.org\/gems\/json Seems to be completely unresponsive.",
  "id" : 16971194934,
  "created_at" : "2010-06-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16811758002",
  "geo" : { },
  "id_str" : "16811903647",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k WHOAAAAAA",
  "id" : 16811903647,
  "in_reply_to_status_id" : 16811758002,
  "created_at" : "2010-06-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 0, 12 ],
      "id_str" : "8828952",
      "id" : 8828952
    }, {
      "name" : "nap.tld, ltd.",
      "screen_name" : "zapnap",
      "indices" : [ 13, 20 ],
      "id_str" : "1566201",
      "id" : 1566201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16854946845",
  "geo" : { },
  "id_str" : "16855152704",
  "in_reply_to_user_id" : 8828952,
  "text" : "@codeofficer @zapnap are we doing lunch when you're in town?",
  "id" : 16855152704,
  "in_reply_to_status_id" : 16854946845,
  "created_at" : "2010-06-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "codeofficer",
  "in_reply_to_user_id_str" : "8828952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16864983031",
  "text" : "I fucking hate markdown.",
  "id" : 16864983031,
  "created_at" : "2010-06-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 0, 5 ],
      "id_str" : "20941662",
      "id" : 20941662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16876580503",
  "in_reply_to_user_id" : 20941662,
  "text" : "@JEG2 git rebase --skip (there were no changes)",
  "id" : 16876580503,
  "created_at" : "2010-06-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "JEG2",
  "in_reply_to_user_id_str" : "20941662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NHRuby User Group",
      "screen_name" : "nhruby",
      "indices" : [ 20, 27 ],
      "id_str" : "30851277",
      "id" : 30851277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16748475596",
  "text" : "Had a great time at @nhruby tonight, totally exhausted. Thanks folks!",
  "id" : 16748475596,
  "created_at" : "2010-06-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16766122321",
  "geo" : { },
  "id_str" : "16768657369",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel whaaat. I'll see if it survives the green line on android.",
  "id" : 16768657369,
  "in_reply_to_status_id" : 16766122321,
  "created_at" : "2010-06-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Roche",
      "screen_name" : "tedroche",
      "indices" : [ 0, 9 ],
      "id_str" : "14353681",
      "id" : 14353681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16775646581",
  "geo" : { },
  "id_str" : "16791074344",
  "in_reply_to_user_id" : 14353681,
  "text" : "@tedroche who knows what the terrorists will do next!",
  "id" : 16791074344,
  "in_reply_to_status_id" : 16775646581,
  "created_at" : "2010-06-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "tedroche",
  "in_reply_to_user_id_str" : "14353681",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 38, 49 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16791141677",
  "text" : "Loving the new blog design. As usual, @thoughtbot's shiny robots kick ass. http:\/\/robots.thoughtbot.com\/",
  "id" : 16791141677,
  "created_at" : "2010-06-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16799267282",
  "geo" : { },
  "id_str" : "16799539483",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez +1000",
  "id" : 16799539483,
  "in_reply_to_status_id" : 16799267282,
  "created_at" : "2010-06-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aka Sentai",
      "screen_name" : "akasentai",
      "indices" : [ 3, 13 ],
      "id_str" : "157781700",
      "id" : 157781700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16806350375",
  "text" : "RT @akasentai: Want to use Redis in the cloud? (Heroku? EC2? Elsewhere?) Let us know! http:\/\/akasentai.com\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "16806332714",
    "text" : "Want to use Redis in the cloud? (Heroku? EC2? Elsewhere?) Let us know! http:\/\/akasentai.com\/",
    "id" : 16806332714,
    "created_at" : "2010-06-22 23:25:24 +0000",
    "user" : {
      "name" : "Aka Sentai",
      "screen_name" : "akasentai",
      "protected" : false,
      "id_str" : "157781700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1008757707\/icon_normal.png",
      "id" : 157781700,
      "verified" : false
    }
  },
  "id" : 16806350375,
  "created_at" : "2010-06-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16691150187",
  "text" : "This morning's train ride brought to you by a busload of kids who showed up to an already full platform.",
  "id" : 16691150187,
  "created_at" : "2010-06-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16697485688",
  "text" : "This is getting a bit out of hand. http:\/\/gist.github.com\/446916 wtf are treetop and polyglot for?",
  "id" : 16697485688,
  "created_at" : "2010-06-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Roche",
      "screen_name" : "tedroche",
      "indices" : [ 0, 9 ],
      "id_str" : "14353681",
      "id" : 14353681
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 66, 76 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16721452645",
  "geo" : { },
  "id_str" : "16721880273",
  "in_reply_to_user_id" : 14353681,
  "text" : "@tedroche you're thinking of someone else, I was going to discuss @gemcutter. But if the group wants to hear Bundler I could swing it.",
  "id" : 16721880273,
  "in_reply_to_status_id" : 16721452645,
  "created_at" : "2010-06-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "tedroche",
  "in_reply_to_user_id_str" : "14353681",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 0, 12 ],
      "id_str" : "8828952",
      "id" : 8828952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16722282969",
  "geo" : { },
  "id_str" : "16725476576",
  "in_reply_to_user_id" : 8828952,
  "text" : "@codeofficer definitely, come on out!",
  "id" : 16725476576,
  "in_reply_to_status_id" : 16722282969,
  "created_at" : "2010-06-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "codeofficer",
  "in_reply_to_user_id_str" : "8828952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16584097099",
  "text" : "Toy Story time. I feel pretty old now.",
  "id" : 16584097099,
  "created_at" : "2010-06-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16591117678",
  "text" : "@IselaMariaPhoto mostly adults, a few though.",
  "id" : 16591117678,
  "created_at" : "2010-06-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Burg",
      "screen_name" : "kevinburg",
      "indices" : [ 0, 10 ],
      "id_str" : "10852412",
      "id" : 10852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16590928639",
  "geo" : { },
  "id_str" : "16591780267",
  "in_reply_to_user_id" : 10852412,
  "text" : "@kevinburg agreed, but it was sad too. Every Pixar flick manages to do this somehow.",
  "id" : 16591780267,
  "in_reply_to_status_id" : 16590928639,
  "created_at" : "2010-06-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "kevinburg",
  "in_reply_to_user_id_str" : "10852412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16645337488",
  "text" : "As usual, upgrading Ubuntu completely hosed my laptop. Can't even use the keyboard or mouse when on the login screen...great.",
  "id" : 16645337488,
  "created_at" : "2010-06-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16645737405",
  "text" : "How to destroy the earth: http:\/\/qntm.org\/destroy",
  "id" : 16645737405,
  "created_at" : "2010-06-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16650653456",
  "text" : "Literally took the Mac mini out of the closet. Second ubuntu upgrade in a row that didn't work out of the box. Am I asking too much here?",
  "id" : 16650653456,
  "created_at" : "2010-06-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Smick",
      "screen_name" : "sprsquish",
      "indices" : [ 0, 10 ],
      "id_str" : "2296675008",
      "id" : 2296675008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16569633351",
  "geo" : { },
  "id_str" : "16570484248",
  "in_reply_to_user_id" : 3732061,
  "text" : "@sprsquish sweet! I have a ton of patches lined up to merge, on my list.",
  "id" : 16570484248,
  "in_reply_to_status_id" : 16569633351,
  "created_at" : "2010-06-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrsprsquish",
  "in_reply_to_user_id_str" : "3732061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16429577501",
  "text" : "When is hockey back on?",
  "id" : 16429577501,
  "created_at" : "2010-06-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16430246742",
  "geo" : { },
  "id_str" : "16430356022",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini i think that's only in development mode",
  "id" : 16430356022,
  "in_reply_to_status_id" : 16430246742,
  "created_at" : "2010-06-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16488355784",
  "text" : "OH: \"...I don't think you should go drunk to a kids movie\"",
  "id" : 16488355784,
  "created_at" : "2010-06-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16498042582",
  "text" : "Hudson + RVM, a great combo: http:\/\/robots.thoughtbot.com\/post\/712609699\/sailing-down-the-hudson-with-rvm",
  "id" : 16498042582,
  "created_at" : "2010-06-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16505928616",
  "text" : "At the craft brew fest. So far, most beers are horrible. Some are delicious though!",
  "id" : 16505928616,
  "created_at" : "2010-06-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16352147394",
  "text" : "Wow. http:\/\/diveintomark.org\/archives\/2010\/05\/28\/of-course",
  "id" : 16352147394,
  "created_at" : "2010-06-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16362539621",
  "text" : "Current status: http:\/\/www.youtube.com\/watch?v=SMTz9nIUkGc",
  "id" : 16362539621,
  "created_at" : "2010-06-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 54, 64 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 86, 98 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16405652189",
  "text" : "A few fixes and showing most downloaded gems today on @gemcutter's homepage thanks to @tristandunn! http:\/\/rubygems.org http:\/\/is.gd\/cT3Oj",
  "id" : 16405652189,
  "created_at" : "2010-06-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16406150586",
  "geo" : { },
  "id_str" : "16406213892",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel you should build a service on top of rubygems.org's webhooks to generate these :)",
  "id" : 16406213892,
  "in_reply_to_status_id" : 16406150586,
  "created_at" : "2010-06-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16415037846",
  "text" : "Game over, this rocks. http:\/\/wiki.hudson-ci.org\/\/display\/HUDSON\/The+Continuous+Integration+Game+plugin",
  "id" : 16415037846,
  "created_at" : "2010-06-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 26, 35 ],
      "id_str" : "21431343",
      "id" : 21431343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16265848975",
  "text" : "Lots of folks out for the @bostonrb hackfest!",
  "id" : 16265848975,
  "created_at" : "2010-06-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16280196105",
  "text" : "The amount of police in downtown Boston with helmets and nightsticks was just hilarious. Must have been hundreds.",
  "id" : 16280196105,
  "created_at" : "2010-06-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keenan Brock",
      "screen_name" : "kbrock",
      "indices" : [ 0, 7 ],
      "id_str" : "623223",
      "id" : 623223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16334870598",
  "geo" : { },
  "id_str" : "16335974536",
  "in_reply_to_user_id" : 623223,
  "text" : "@kbrock thanks! Are you ever gonna make it back out for a hackfest?",
  "id" : 16335974536,
  "in_reply_to_status_id" : 16334870598,
  "created_at" : "2010-06-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "kbrock",
  "in_reply_to_user_id_str" : "623223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16335013605",
  "geo" : { },
  "id_str" : "16336020782",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck not yet, some patches are out there that I need to evaluate. Open a request on help.rubygems.org or grab me in IRC",
  "id" : 16336020782,
  "in_reply_to_status_id" : 16335013605,
  "created_at" : "2010-06-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16341569496",
  "text" : "COUCH ACQUIRED. I love Craigslist.",
  "id" : 16341569496,
  "created_at" : "2010-06-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16221218990",
  "text" : "Loving the new Redis-powered download counter on http:\/\/rubygems.org\/. More to come soon!",
  "id" : 16221218990,
  "created_at" : "2010-06-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pieter Noordhuis",
      "screen_name" : "pnoordhuis",
      "indices" : [ 0, 11 ],
      "id_str" : "14809096",
      "id" : 14809096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16221507189",
  "geo" : { },
  "id_str" : "16221639544",
  "in_reply_to_user_id" : 14809096,
  "text" : "@pnoordhuis haven't played with that yet, patches are welcome. one json endpoint polling is fast enough for now though :)",
  "id" : 16221639544,
  "in_reply_to_status_id" : 16221507189,
  "created_at" : "2010-06-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "pnoordhuis",
  "in_reply_to_user_id_str" : "14809096",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 103, 111 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16232107895",
  "text" : "\"this is why I don't talk to developers\" http:\/\/bradcolbow.com\/archive\/view\/the_brads_rake_deploy\/ \/cc @mojombo",
  "id" : 16232107895,
  "created_at" : "2010-06-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16254423523",
  "geo" : { },
  "id_str" : "16254745011",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan definitely not fair for new speakers on the block.",
  "id" : 16254745011,
  "in_reply_to_status_id" : 16254423523,
  "created_at" : "2010-06-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16254873477",
  "geo" : { },
  "id_str" : "16257572681",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan yeah there's definitely a lot of \"veterans\" but you'd think more people would step up :(",
  "id" : 16257572681,
  "in_reply_to_status_id" : 16254873477,
  "created_at" : "2010-06-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16152747623",
  "text" : "Just discovered 3 finger swipe to go back\/forward on Chrome with my new Macbook. Awesome.",
  "id" : 16152747623,
  "created_at" : "2010-06-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16181593648",
  "text" : "Current status: http:\/\/www.youtube.com\/watch?v=TyrDdmaTudo",
  "id" : 16181593648,
  "created_at" : "2010-06-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16112403741",
  "text" : "Me: \"How hard would it be to make a frappucino?\" Her: \"I accept!\" Result: DELICIOUS http:\/\/twitpic.com\/1wmb1m",
  "id" : 16112403741,
  "created_at" : "2010-06-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 19, 29 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16120170786",
  "text" : "Getting there with @gemcutter on Rails 3, application booting! http:\/\/is.gd\/cOlGR",
  "id" : 16120170786,
  "created_at" : "2010-06-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francis Fish",
      "screen_name" : "fjfish",
      "indices" : [ 0, 7 ],
      "id_str" : "48738238",
      "id" : 48738238
    }, {
      "name" : "Simon",
      "screen_name" : "Cimm",
      "indices" : [ 8, 13 ],
      "id_str" : "2561501",
      "id" : 2561501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16137050611",
  "geo" : { },
  "id_str" : "16141835238",
  "in_reply_to_user_id" : 48738238,
  "text" : "@fjfish @Cimm is it still happening? the web frontend redirects on other domains (gemcutter\/gems.rubyforge) but the gem server doesn't",
  "id" : 16141835238,
  "in_reply_to_status_id" : 16137050611,
  "created_at" : "2010-06-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "fjfish",
  "in_reply_to_user_id_str" : "48738238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 64, 73 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16037551830",
  "text" : "Brainstorming some ideas about gem webhook enabled services for @rubygems: http:\/\/wiki.github.com\/rubygems\/gemcutter\/webhooks-ideas",
  "id" : 16037551830,
  "created_at" : "2010-06-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "technomancy",
      "screen_name" : "technomancy",
      "indices" : [ 0, 12 ],
      "id_str" : "6264792",
      "id" : 6264792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16038398307",
  "geo" : { },
  "id_str" : "16042927687",
  "in_reply_to_user_id" : 6264792,
  "text" : "@technomancy you can switch the 'context' in the upper right hand corner of the dashboard.",
  "id" : 16042927687,
  "in_reply_to_status_id" : 16038398307,
  "created_at" : "2010-06-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "technomancy",
  "in_reply_to_user_id_str" : "6264792",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frozen Canuck",
      "screen_name" : "frozencanuck",
      "indices" : [ 0, 13 ],
      "id_str" : "14054953",
      "id" : 14054953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16042224271",
  "geo" : { },
  "id_str" : "16045832703",
  "in_reply_to_user_id" : 14054953,
  "text" : "@frozencanuck what's the error?",
  "id" : 16045832703,
  "in_reply_to_status_id" : 16042224271,
  "created_at" : "2010-06-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "frozencanuck",
  "in_reply_to_user_id_str" : "14054953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Boback",
      "screen_name" : "snarebyte",
      "indices" : [ 76, 86 ],
      "id_str" : "14777864",
      "id" : 14777864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16049263060",
  "text" : "Follow your dreams, play ROBOT UNICORN ATTACK! http:\/\/bit.ly\/aOxArN (thanks @snarebyte!)",
  "id" : 16049263060,
  "created_at" : "2010-06-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16057354237",
  "text" : "Futzed around for hours with iptables to do redirection\/port remapping, turns out rinetd is so much simpler. BOOM.",
  "id" : 16057354237,
  "created_at" : "2010-06-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16063740843",
  "geo" : { },
  "id_str" : "16070901453",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez is that going to be the default as of 2.0? Wondering when the release will be, esp since the 'feature freeze' months ago",
  "id" : 16070901453,
  "in_reply_to_status_id" : 16063740843,
  "created_at" : "2010-06-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF30\uFF21\uFF35\uFF2C\u3000\uFF26\uFF29\uFF33\uFF28\uFF25\uFF32",
      "screen_name" : "thetorpedodog",
      "indices" : [ 74, 88 ],
      "id_str" : "5889062",
      "id" : 5889062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15972165522",
  "text" : "I need to see this movie. http:\/\/www.youtube.com\/watch?v=dZe1AeH0Qz8 (via @thetorpedodog)",
  "id" : 15972165522,
  "created_at" : "2010-06-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16028566137",
  "geo" : { },
  "id_str" : "16030167694",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen what happened to gemandtonic?",
  "id" : 16030167694,
  "in_reply_to_status_id" : 16028566137,
  "created_at" : "2010-06-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathaniel Bibler",
      "screen_name" : "nbibler",
      "indices" : [ 0, 8 ],
      "id_str" : "14351836",
      "id" : 14351836
    }, {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 35, 47 ],
      "id_str" : "7114202",
      "id" : 7114202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15906798519",
  "geo" : { },
  "id_str" : "15910149668",
  "in_reply_to_user_id" : 14351836,
  "text" : "@nbibler make sure to hook up with @jamesarosen and his ideas with gemandtonic...if we're talking about the same thing :)",
  "id" : 15910149668,
  "in_reply_to_status_id" : 15906798519,
  "created_at" : "2010-06-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "nbibler",
  "in_reply_to_user_id_str" : "14351836",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15927955801",
  "text" : "TRAIN TO BAHSTAN SOUTH STAYSHAWN",
  "id" : 15927955801,
  "created_at" : "2010-06-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan",
      "screen_name" : "alandipert",
      "indices" : [ 0, 11 ],
      "id_str" : "40270600",
      "id" : 40270600
    }, {
      "name" : "Dan Schneiderman",
      "screen_name" : "hiteak",
      "indices" : [ 12, 19 ],
      "id_str" : "15507545",
      "id" : 15507545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15960208081",
  "geo" : { },
  "id_str" : "15961303318",
  "in_reply_to_user_id" : 40270600,
  "text" : "@alandipert @hiteak yes, and yes. Next year you both should go!",
  "id" : 15961303318,
  "in_reply_to_status_id" : 15960208081,
  "created_at" : "2010-06-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "alandipert",
  "in_reply_to_user_id_str" : "40270600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharad Jain",
      "screen_name" : "sharadjain",
      "indices" : [ 0, 11 ],
      "id_str" : "21927512",
      "id" : 21927512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15943759105",
  "geo" : { },
  "id_str" : "15962083542",
  "in_reply_to_user_id" : 21927512,
  "text" : "@sharadjain they both point to the same place, perhaps some docs haven't been updated. where are you seeing this?",
  "id" : 15962083542,
  "in_reply_to_status_id" : 15943759105,
  "created_at" : "2010-06-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "sharadjain",
  "in_reply_to_user_id_str" : "21927512",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Bob Martin",
      "screen_name" : "unclebobmartin",
      "indices" : [ 60, 75 ],
      "id_str" : "9505092",
      "id" : 9505092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15849725666",
  "text" : "Got in too late for food at #railsconf, but I couldn't miss @unclebobmartin's  keynote.",
  "id" : 15849725666,
  "created_at" : "2010-06-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15852041946",
  "text" : "I was going to plow through K&R, but switching to SICP next. #railsconf",
  "id" : 15852041946,
  "created_at" : "2010-06-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u044D\u0440\u0438 \u0441\u0430\u0430\u043A\u044F\u043D",
      "screen_name" : "ArmMer",
      "indices" : [ 0, 7 ],
      "id_str" : "369604063",
      "id" : 369604063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15857050414",
  "text" : "@armmer this is why i git fetch always. git pull seems like the cheap way out.",
  "id" : 15857050414,
  "created_at" : "2010-06-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15863449501",
  "text" : "Thanks for coming to my talk! Slides here: http:\/\/lapidary.heroku.com RubyGems on GitHub! http:\/\/github.com\/rubygems\/rubygems",
  "id" : 15863449501,
  "created_at" : "2010-06-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 13, 21 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 37, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15871793533",
  "text" : "Fired up for @garyvee to crush it at #railsconf!",
  "id" : 15871793533,
  "created_at" : "2010-06-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15877700423",
  "text" : "Hard to describe #railsconf. Excited and exhausted simultaneously.",
  "id" : 15877700423,
  "created_at" : "2010-06-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francisco ruiz",
      "screen_name" : "Paco36",
      "indices" : [ 0, 7 ],
      "id_str" : "2460224676",
      "id" : 2460224676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15878411411",
  "geo" : { },
  "id_str" : "15882031277",
  "in_reply_to_user_id" : 15198826,
  "text" : "@paco36 I hope at a rate of one drink per patch",
  "id" : 15882031277,
  "in_reply_to_status_id" : 15878411411,
  "created_at" : "2010-06-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "tmrudick",
  "in_reply_to_user_id_str" : "15198826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15883827849",
  "text" : "Finally made it to an Orioles game.... GO YANKEES! post-#railsconf",
  "id" : 15883827849,
  "created_at" : "2010-06-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 79, 92 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15744271861",
  "text" : "Thanks everyone! Next year we'll have to get three Buffalo natives to beat out @wayneeseguin and me.",
  "id" : 15744271861,
  "created_at" : "2010-06-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 0, 12 ],
      "id_str" : "8828952",
      "id" : 8828952
    }, {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 62, 75 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15753103920",
  "geo" : { },
  "id_str" : "15753506193",
  "in_reply_to_user_id" : 8828952,
  "text" : "@codeofficer i think you can do that with .rvmrc, way easier. @wayneeseguin just showed me, ask him!",
  "id" : 15753506193,
  "in_reply_to_status_id" : 15753103920,
  "created_at" : "2010-06-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "codeofficer",
  "in_reply_to_user_id_str" : "8828952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Sivers",
      "screen_name" : "sivers",
      "indices" : [ 29, 36 ],
      "id_str" : "2206131",
      "id" : 2206131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15804506342",
  "text" : "Loving the Rush music during @sivers' keynote.",
  "id" : 15804506342,
  "created_at" : "2010-06-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15702072431",
  "text" : "RT @gemcutter Site is up, but DNS is not. Working on it, temp fix: http:\/\/gist.github.com\/429688",
  "id" : 15702072431,
  "created_at" : "2010-06-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15704854155",
  "text" : "Made it to the #railsconf keynote!",
  "id" : 15704854155,
  "created_at" : "2010-06-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15706601407",
  "text" : "Is it possible to run chef on capistrano deploys? Trying to put some system level changes in place and missing Git.",
  "id" : 15706601407,
  "created_at" : "2010-06-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Newland",
      "screen_name" : "jnewland",
      "indices" : [ 0, 9 ],
      "id_str" : "13518",
      "id" : 13518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15706726782",
  "geo" : { },
  "id_str" : "15707979932",
  "in_reply_to_user_id" : 13518,
  "text" : "@jnewland we already have the servers and we're not on ec2....isn't that the point of moonshine?",
  "id" : 15707979932,
  "in_reply_to_status_id" : 15706726782,
  "created_at" : "2010-06-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "jnewland",
  "in_reply_to_user_id_str" : "13518",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Feathers",
      "screen_name" : "mfeathers",
      "indices" : [ 30, 40 ],
      "id_str" : "14253068",
      "id" : 14253068
    }, {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "indices" : [ 71, 79 ],
      "id_str" : "6532552",
      "id" : 6532552
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15708801903",
  "text" : "Spotted some Ninject calls on @mfeathers' keynote slide at #railsconf. @nkohari is here in spirit!",
  "id" : 15708801903,
  "created_at" : "2010-06-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15716692638",
  "text" : "RT @gemcutter: We should be at 100% with DNS moved over, let us know if you have more problems...refresh your cache!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "15716542023",
    "text" : "We should be at 100% with DNS moved over, let us know if you have more problems...refresh your cache!",
    "id" : 15716542023,
    "created_at" : "2010-06-08 16:20:35 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 15716692638,
  "created_at" : "2010-06-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15723047239",
  "text" : "\"rewrites your Ruby binary in memory\" *brain melts*",
  "id" : 15723047239,
  "created_at" : "2010-06-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15731768708",
  "text" : "\"I just leveled up! I'm a Night Elf Mohawk or whatever the fuck it's called\"",
  "id" : 15731768708,
  "created_at" : "2010-06-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15590060573",
  "text" : "Another train dropped people off and turned around. Fail.",
  "id" : 15590060573,
  "created_at" : "2010-06-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RailsConf 2015",
      "screen_name" : "railsconf",
      "indices" : [ 27, 37 ],
      "id_str" : "5493662",
      "id" : 5493662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15593168948",
  "text" : "Any plans for after ignite @railsconf?",
  "id" : 15593168948,
  "created_at" : "2010-06-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15601369612",
  "text" : "Ended up at Mother's...what happened to the ignite #railsconf folks?",
  "id" : 15601369612,
  "created_at" : "2010-06-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15631534647",
  "text" : "Found a buffet\/cafe across the street from the castle, er, conference center #railsconf",
  "id" : 15631534647,
  "created_at" : "2010-06-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bohconf",
      "indices" : [ 8, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15640643191",
  "text" : "So far, #bohconf is fantastic. Time to storm the castle for lunch.",
  "id" : 15640643191,
  "created_at" : "2010-06-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15654103483",
  "geo" : { },
  "id_str" : "15657604824",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey http:\/\/rubygems.org\/pages\/gem_docs#yank",
  "id" : 15657604824,
  "in_reply_to_status_id" : 15654103483,
  "created_at" : "2010-06-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15523813849",
  "geo" : { },
  "id_str" : "15524774808",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel oops is that this week?",
  "id" : 15524774808,
  "in_reply_to_status_id" : 15523813849,
  "created_at" : "2010-06-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RailsConf 2015",
      "screen_name" : "railsconf",
      "indices" : [ 16, 26 ],
      "id_str" : "5493662",
      "id" : 5493662
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 36, 47 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15568049694",
  "text" : "On the train to @railsconf with the @thoughtbot crew!",
  "id" : 15568049694,
  "created_at" : "2010-06-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15569107509",
  "text" : "Amtrak has wifi, power outlets, and tables. woot.",
  "id" : 15569107509,
  "created_at" : "2010-06-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Bazinet",
      "screen_name" : "rbazinet",
      "indices" : [ 0, 9 ],
      "id_str" : "9573202",
      "id" : 9573202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15570536866",
  "geo" : { },
  "id_str" : "15571926213",
  "in_reply_to_user_id" : 9573202,
  "text" : "@rbazinet we're on the 1:10 from boston. Look for the guys with macbooks.",
  "id" : 15571926213,
  "in_reply_to_status_id" : 15570536866,
  "created_at" : "2010-06-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "rbazinet",
  "in_reply_to_user_id_str" : "9573202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 0, 8 ],
      "id_str" : "22682102",
      "id" : 22682102
    }, {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 9, 18 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15574357831",
  "in_reply_to_user_id" : 22682102,
  "text" : "@dmansen @marcweil rollin through philly soon on the amtrak!",
  "id" : 15574357831,
  "created_at" : "2010-06-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "dmansen",
  "in_reply_to_user_id_str" : "22682102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15579228468",
  "text" : "Hi nyc! http:\/\/tweetphoto.com\/25969480",
  "id" : 15579228468,
  "created_at" : "2010-06-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15587214235",
  "text" : "OH HAI BALTIMORE",
  "id" : 15587214235,
  "created_at" : "2010-06-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15588636580",
  "text" : "Baltimore MTA is strange. Took us one stop, forced us to get off, train went in reverse. Wtf? #railsconf",
  "id" : 15588636580,
  "created_at" : "2010-06-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foodler",
      "screen_name" : "Foodler",
      "indices" : [ 10, 18 ],
      "id_str" : "18194176",
      "id" : 18194176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15510639496",
  "text" : "Just used @Foodler for the first time while in Boston. Am I a local yet?",
  "id" : 15510639496,
  "created_at" : "2010-06-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15517259661",
  "text" : "Walked around the reservoir across the street from our apartment with @ablissfulgal, great view: http:\/\/is.gd\/cE4wA",
  "id" : 15517259661,
  "created_at" : "2010-06-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarod Luebbert",
      "screen_name" : "jarodl",
      "indices" : [ 0, 7 ],
      "id_str" : "14253292",
      "id" : 14253292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15388400013",
  "geo" : { },
  "id_str" : "15388642031",
  "in_reply_to_user_id" : 14253292,
  "text" : "@jarodl sure, it looks sweet",
  "id" : 15388642031,
  "in_reply_to_status_id" : 15388400013,
  "created_at" : "2010-06-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "jarodl",
  "in_reply_to_user_id_str" : "14253292",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarod Luebbert",
      "screen_name" : "jarodl",
      "indices" : [ 0, 7 ],
      "id_str" : "14253292",
      "id" : 14253292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15388729811",
  "geo" : { },
  "id_str" : "15389219105",
  "in_reply_to_user_id" : 14253292,
  "text" : "@jarodl nice, but no android client... :(",
  "id" : 15389219105,
  "in_reply_to_status_id" : 15388729811,
  "created_at" : "2010-06-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "jarodl",
  "in_reply_to_user_id_str" : "14253292",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rdio",
      "screen_name" : "Rdio",
      "indices" : [ 13, 18 ],
      "id_str" : "54205414",
      "id" : 54205414
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 71, 85 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15389470553",
  "text" : "Oh hell yes. @rdio somehow has the new Rush singles, Caravan and BU2B. @joshuaclayton want an invite?",
  "id" : 15389470553,
  "created_at" : "2010-06-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15392561585",
  "text" : "wtf? http:\/\/www.rubygems.info\/",
  "id" : 15392561585,
  "created_at" : "2010-06-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15416189880",
  "text" : "No tickets left for http:\/\/railsconf-tmottbg.eventbrite.com\/, LAME",
  "id" : 15416189880,
  "created_at" : "2010-06-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh French",
      "screen_name" : "joshfrench",
      "indices" : [ 0, 11 ],
      "id_str" : "19110970",
      "id" : 19110970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15415597708",
  "geo" : { },
  "id_str" : "15416301009",
  "in_reply_to_user_id" : 19110970,
  "text" : "@joshfrench not yet, but ~\/.gem\/credentials is in YAML to handle this in the future. something like gem push whatever.gem -k yourcompany",
  "id" : 15416301009,
  "in_reply_to_status_id" : 15415597708,
  "created_at" : "2010-06-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshfrench",
  "in_reply_to_user_id_str" : "19110970",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15449887419",
  "text" : "That burning smell from Boston over memorial day: http:\/\/earthobservatory.nasa.gov\/IOTD\/view.php?id=44138",
  "id" : 15449887419,
  "created_at" : "2010-06-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 20, 30 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15299375148",
  "text" : "Squashed a bug with @gemcutter's indexing. Non-ruby platform gems with different latest versions wouldn't show up. Phew. http:\/\/is.gd\/cAuPq",
  "id" : 15299375148,
  "created_at" : "2010-06-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 0, 8 ],
      "id_str" : "22682102",
      "id" : 22682102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15326339376",
  "geo" : { },
  "id_str" : "15326582673",
  "in_reply_to_user_id" : 22682102,
  "text" : "@dmansen if i ever visit your place, i am never sitting down",
  "id" : 15326582673,
  "in_reply_to_status_id" : 15326339376,
  "created_at" : "2010-06-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "dmansen",
  "in_reply_to_user_id_str" : "22682102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sasha Koss",
      "screen_name" : "kossnocorp",
      "indices" : [ 0, 11 ],
      "id_str" : "16147508",
      "id" : 16147508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15299163103",
  "geo" : { },
  "id_str" : "15331321313",
  "in_reply_to_user_id" : 16147508,
  "text" : "@kossnocorp getting there, I have a ton of great patches to merge.",
  "id" : 15331321313,
  "in_reply_to_status_id" : 15299163103,
  "created_at" : "2010-06-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "kossnocorp",
  "in_reply_to_user_id_str" : "16147508",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 17, 26 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15255190618",
  "text" : "Sometimes I wish @RubyGems allowed dashes OR underscores in gem names, not both. Drives me nuts.",
  "id" : 15255190618,
  "created_at" : "2010-06-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aman Gupta",
      "screen_name" : "tmm1",
      "indices" : [ 7, 12 ],
      "id_str" : "15591045",
      "id" : 15591045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15251130954",
  "geo" : { },
  "id_str" : "15266525824",
  "in_reply_to_user_id" : 15359408,
  "text" : "@ra66i @tmm1 that's incorrect, i'm on a brand new macbook with SL. i've given up with rvm\/ree for now, it's too frustrating to debug",
  "id" : 15266525824,
  "in_reply_to_status_id" : 15251130954,
  "created_at" : "2010-06-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 24, 34 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15273324222",
  "text" : "Well, it looks like the @gemcutter redis spec with 29 million downloads translates to ~540MB in memory...agh. http:\/\/gist.github.com\/296921",
  "id" : 15273324222,
  "created_at" : "2010-06-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15273532178",
  "text" : "Definitely need to benchmark using the redis vm and paring it down to 100MB or so. Most of that data isn't going to be hit constantly.",
  "id" : 15273532178,
  "created_at" : "2010-06-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 3, 13 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15273775226",
  "text" : "RT @joeferris: come hang out with me (and the rest of thoughtbot) in Cape Cod this summer: http:\/\/capeco.de\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "15273678073",
    "text" : "come hang out with me (and the rest of thoughtbot) in Cape Cod this summer: http:\/\/capeco.de\/",
    "id" : 15273678073,
    "created_at" : "2010-06-02 20:00:18 +0000",
    "user" : {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "protected" : false,
      "id_str" : "14575143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518019567\/jferris-square_normal.jpg",
      "id" : 14575143,
      "verified" : false
    }
  },
  "id" : 15273775226,
  "created_at" : "2010-06-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pieter Noordhuis",
      "screen_name" : "pnoordhuis",
      "indices" : [ 5, 16 ],
      "id_str" : "14809096",
      "id" : 14809096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15274190755",
  "text" : "Wow, @pnoordhuis rocks. Bumped hash-max-zipmap-entries to 365 in redis.conf, Redis is down to 105MB.",
  "id" : 15274190755,
  "created_at" : "2010-06-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cloudhead",
      "screen_name" : "cloudhead",
      "indices" : [ 0, 10 ],
      "id_str" : "36156834",
      "id" : 36156834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15275661785",
  "geo" : { },
  "id_str" : "15275893374",
  "in_reply_to_user_id" : 36156834,
  "text" : "@cloudhead i think usually it'll just be a HGETALL, we actually dont use that data at all yet...so it won't be a big deal",
  "id" : 15275893374,
  "in_reply_to_status_id" : 15275661785,
  "created_at" : "2010-06-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "cloudhead",
  "in_reply_to_user_id_str" : "36156834",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
Grailbird.data.tweets_2013_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Sandofsky",
      "screen_name" : "sandofsky",
      "indices" : [ 3, 13 ],
      "id_str" : "699463",
      "id" : 699463
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/sandofsky\/status\/384845296314109952\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/HQwRGlbe93",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVc-wgOIMAAbqIx.png",
      "id_str" : "384845296167301120",
      "id" : 384845296167301120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVc-wgOIMAAbqIx.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 350
      } ],
      "display_url" : "pic.twitter.com\/HQwRGlbe93"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384845470498947072",
  "text" : "RT @sandofsky: http:\/\/t.co\/HQwRGlbe93",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/sandofsky\/status\/384845296314109952\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/HQwRGlbe93",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BVc-wgOIMAAbqIx.png",
        "id_str" : "384845296167301120",
        "id" : 384845296167301120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVc-wgOIMAAbqIx.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 350
        } ],
        "display_url" : "pic.twitter.com\/HQwRGlbe93"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384845296314109952",
    "text" : "http:\/\/t.co\/HQwRGlbe93",
    "id" : 384845296314109952,
    "created_at" : "2013-10-01 01:00:43 +0000",
    "user" : {
      "name" : "Ben Sandofsky",
      "screen_name" : "sandofsky",
      "protected" : false,
      "id_str" : "699463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559402317724655616\/AzzPv12Z_normal.jpeg",
      "id" : 699463,
      "verified" : false
    }
  },
  "id" : 384845470498947072,
  "created_at" : "2013-10-01 01:01:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Weston Platter",
      "screen_name" : "westonplatter",
      "indices" : [ 0, 14 ],
      "id_str" : "114336396",
      "id" : 114336396
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 38, 46 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 50, 58 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384834253717917696",
  "geo" : { },
  "id_str" : "384836407639818240",
  "in_reply_to_user_id" : 114336396,
  "text" : "@westonplatter not sure, sorry! maybe @evanphx or @drbrain would have better suggestions?",
  "id" : 384836407639818240,
  "in_reply_to_status_id" : 384834253717917696,
  "created_at" : "2013-10-01 00:25:24 +0000",
  "in_reply_to_screen_name" : "westonplatter",
  "in_reply_to_user_id_str" : "114336396",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384794366268551168",
  "geo" : { },
  "id_str" : "384794578114449408",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy The VFL is pretty great.",
  "id" : 384794578114449408,
  "in_reply_to_status_id" : 384794366268551168,
  "created_at" : "2013-09-30 21:39:11 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Higgins",
      "screen_name" : "RepBrianHiggins",
      "indices" : [ 3, 19 ],
      "id_str" : "33576489",
      "id" : 33576489
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EnoughAlready",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384792777722064896",
  "text" : "RT @RepBrianHiggins: America shouldn\u2019t be held hostage by a small group of extremists who don\u2019t represent the needs of the American people.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EnoughAlready",
        "indices" : [ 119, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384792339983499264",
    "text" : "America shouldn\u2019t be held hostage by a small group of extremists who don\u2019t represent the needs of the American people. #EnoughAlready",
    "id" : 384792339983499264,
    "created_at" : "2013-09-30 21:30:17 +0000",
    "user" : {
      "name" : "Brian Higgins",
      "screen_name" : "RepBrianHiggins",
      "protected" : false,
      "id_str" : "33576489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523096705030320129\/55nJtODk_normal.jpeg",
      "id" : 33576489,
      "verified" : true
    }
  },
  "id" : 384792777722064896,
  "created_at" : "2013-09-30 21:32:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/9OFkbrYHxS",
      "expanded_url" : "http:\/\/flic.kr\/p\/gh35Bv",
      "display_url" : "flic.kr\/p\/gh35Bv"
    } ]
  },
  "geo" : { },
  "id_str" : "384788998805544960",
  "text" : "Happy to be home. http:\/\/t.co\/9OFkbrYHxS",
  "id" : 384788998805544960,
  "created_at" : "2013-09-30 21:17:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384701776794230784",
  "geo" : { },
  "id_str" : "384702197616738304",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo thanks for continuing to post these. I had just started 7\/10 but flipping over! :)",
  "id" : 384702197616738304,
  "in_reply_to_status_id" : 384701776794230784,
  "created_at" : "2013-09-30 15:32:05 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384690221578993664",
  "geo" : { },
  "id_str" : "384701489534349312",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella Just do the conference here next time :P",
  "id" : 384701489534349312,
  "in_reply_to_status_id" : 384690221578993664,
  "created_at" : "2013-09-30 15:29:17 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathieu Allaire",
      "screen_name" : "allaire",
      "indices" : [ 0, 8 ],
      "id_str" : "16617671",
      "id" : 16617671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384414895812276224",
  "geo" : { },
  "id_str" : "384689574317813761",
  "in_reply_to_user_id" : 16617671,
  "text" : "@allaire sorry, no idea :(",
  "id" : 384689574317813761,
  "in_reply_to_status_id" : 384414895812276224,
  "created_at" : "2013-09-30 14:41:56 +0000",
  "in_reply_to_screen_name" : "allaire",
  "in_reply_to_user_id_str" : "16617671",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/5ctwoNcTC0",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush\/9993504353\/in\/set-72157635999395313\/lightbox\/",
      "display_url" : "flickr.com\/photos\/qrush\/9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384685046583394306",
  "text" : "Back in the real world. From the weekend, Sonoma Coast State Park. Gorgeous: http:\/\/t.co\/5ctwoNcTC0",
  "id" : 384685046583394306,
  "created_at" : "2013-09-30 14:23:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John McCaffrey",
      "screen_name" : "j_mccaffrey",
      "indices" : [ 0, 12 ],
      "id_str" : "45923602",
      "id" : 45923602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384309633751339011",
  "geo" : { },
  "id_str" : "384682945782353922",
  "in_reply_to_user_id" : 45923602,
  "text" : "@j_mccaffrey thanks!",
  "id" : 384682945782353922,
  "in_reply_to_status_id" : 384309633751339011,
  "created_at" : "2013-09-30 14:15:36 +0000",
  "in_reply_to_screen_name" : "j_mccaffrey",
  "in_reply_to_user_id_str" : "45923602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384682368658714625",
  "text" : "Home is where the Tonx is.",
  "id" : 384682368658714625,
  "created_at" : "2013-09-30 14:13:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rstevens 3.01 ",
      "screen_name" : "rstevens",
      "indices" : [ 3, 12 ],
      "id_str" : "643653",
      "id" : 643653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384483341723918336",
  "text" : "RT @rstevens: Really looking forward to the Simpsons finale tonight!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384476942415958016",
    "text" : "Really looking forward to the Simpsons finale tonight!!",
    "id" : 384476942415958016,
    "created_at" : "2013-09-30 00:37:00 +0000",
    "user" : {
      "name" : "rstevens 3.01 ",
      "screen_name" : "rstevens",
      "protected" : false,
      "id_str" : "643653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552258901958475776\/aNzACLOf_normal.jpeg",
      "id" : 643653,
      "verified" : false
    }
  },
  "id" : 384483341723918336,
  "created_at" : "2013-09-30 01:02:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/pYo4kGOi2W",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush\/9993365374\/in\/photostream\/",
      "display_url" : "flickr.com\/photos\/qrush\/9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384193613392920577",
  "text" : "Too many favorite photos from this trip. Cut down 600+ photos to 55. Need to get better at this. Good results though: http:\/\/t.co\/pYo4kGOi2W",
  "id" : 384193613392920577,
  "created_at" : "2013-09-29 05:51:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Downie",
      "screen_name" : "richdownie",
      "indices" : [ 0, 11 ],
      "id_str" : "10774712",
      "id" : 10774712
    }, {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 12, 19 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383771380191203329",
  "geo" : { },
  "id_str" : "384007648762281985",
  "in_reply_to_user_id" : 10774712,
  "text" : "@richdownie @nb3004 yep.",
  "id" : 384007648762281985,
  "in_reply_to_status_id" : 383771380191203329,
  "created_at" : "2013-09-28 17:32:12 +0000",
  "in_reply_to_screen_name" : "richdownie",
  "in_reply_to_user_id_str" : "10774712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384000751116500992",
  "geo" : { },
  "id_str" : "384007574019776512",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr been a long time since I had a car with an RIT permit :) back in my day they were square! \uD83D\uDC74",
  "id" : 384007574019776512,
  "in_reply_to_status_id" : 384000751116500992,
  "created_at" : "2013-09-28 17:31:54 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383765969455181824",
  "text" : "Napa\/Sonoma County foothill roads are the most intense, full attention driving I've ever done. Inches from certain death by falling off.",
  "id" : 383765969455181824,
  "created_at" : "2013-09-28 01:31:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383079355498233856",
  "text" : "Current status: one way lane for construction...over a mountain. Not used to hills.",
  "id" : 383079355498233856,
  "created_at" : "2013-09-26 04:03:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ (Thomas) Biddle",
      "screen_name" : "thomasjbiddle",
      "indices" : [ 0, 14 ],
      "id_str" : "215501973",
      "id" : 215501973
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 60, 68 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 72, 80 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383036366172340224",
  "geo" : { },
  "id_str" : "383039163571769345",
  "in_reply_to_user_id" : 215501973,
  "text" : "@thomasjbiddle I'm nowhere near a computer this week. Maybe @evanphx or @drbrain knows?",
  "id" : 383039163571769345,
  "in_reply_to_status_id" : 383036366172340224,
  "created_at" : "2013-09-26 01:23:47 +0000",
  "in_reply_to_screen_name" : "thomasjbiddle",
  "in_reply_to_user_id_str" : "215501973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383001833108942849",
  "geo" : { },
  "id_str" : "383006942097977344",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella I was thinking of doing some posts about running a conf and opening our books. We made out black. Keep fighting the good fight.",
  "id" : 383006942097977344,
  "in_reply_to_status_id" : 383001833108942849,
  "created_at" : "2013-09-25 23:15:45 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383000252157935617",
  "text" : "SF, we meet again. This time I will drive through you.",
  "id" : 383000252157935617,
  "created_at" : "2013-09-25 22:49:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 0, 7 ],
      "id_str" : "70702180",
      "id" : 70702180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382912803218022400",
  "geo" : { },
  "id_str" : "382913549850247168",
  "in_reply_to_user_id" : 70702180,
  "text" : "@cubosh wow, awesome.",
  "id" : 382913549850247168,
  "in_reply_to_status_id" : 382912803218022400,
  "created_at" : "2013-09-25 17:04:39 +0000",
  "in_reply_to_screen_name" : "cubosh",
  "in_reply_to_user_id_str" : "70702180",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    }, {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 8, 15 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382880056659283968",
  "geo" : { },
  "id_str" : "382883700435730432",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes @holman what is this?!",
  "id" : 382883700435730432,
  "in_reply_to_status_id" : 382880056659283968,
  "created_at" : "2013-09-25 15:06:02 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 3, 9 ],
      "id_str" : "744613",
      "id" : 744613
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 27, 42 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382873002217840640",
  "text" : "RT @chorn: I've gotta say, @nickelcityruby was so fun I might not go to any big conferences any more.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 16, 31 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382854053606068224",
    "text" : "I've gotta say, @nickelcityruby was so fun I might not go to any big conferences any more.",
    "id" : 382854053606068224,
    "created_at" : "2013-09-25 13:08:14 +0000",
    "user" : {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "protected" : false,
      "id_str" : "744613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2310147637\/niixqq7ibisfwaat2xmg_normal.png",
      "id" : 744613,
      "verified" : false
    }
  },
  "id" : 382873002217840640,
  "created_at" : "2013-09-25 14:23:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "WickedGoodRuby",
      "screen_name" : "WickedGoodRuby",
      "indices" : [ 75, 90 ],
      "id_str" : "870817116",
      "id" : 870817116
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382872683094224896",
  "text" : "RT @nickelcityruby: Not sure what to do now that #ncrc13 is over?  Head to @WickedGoodRuby and keep your ruby rolling!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WickedGoodRuby",
        "screen_name" : "WickedGoodRuby",
        "indices" : [ 55, 70 ],
        "id_str" : "870817116",
        "id" : 870817116
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 29, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382867558224769024",
    "text" : "Not sure what to do now that #ncrc13 is over?  Head to @WickedGoodRuby and keep your ruby rolling!!",
    "id" : 382867558224769024,
    "created_at" : "2013-09-25 14:01:53 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 382872683094224896,
  "created_at" : "2013-09-25 14:22:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/woQ0enfLCK",
      "expanded_url" : "http:\/\/flic.kr\/p\/g8fPw7",
      "display_url" : "flic.kr\/p\/g8fPw7"
    } ]
  },
  "geo" : { },
  "id_str" : "382721075832193024",
  "text" : "Runnin around yesterday http:\/\/t.co\/woQ0enfLCK",
  "id" : 382721075832193024,
  "created_at" : "2013-09-25 04:19:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382707294976622592",
  "geo" : { },
  "id_str" : "382708268662919168",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox Hmmmm... :trollface:",
  "id" : 382708268662919168,
  "in_reply_to_status_id" : 382707294976622592,
  "created_at" : "2013-09-25 03:28:56 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 3, 15 ],
      "id_str" : "16454301",
      "id" : 16454301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/9vcJRYJfwu",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3633-on-writing-interfaces-well",
      "display_url" : "37signals.com\/svn\/posts\/3633\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382611772684791810",
  "text" : "RT @jonasdowney: Designers need to be good writers. My new post on SvN: http:\/\/t.co\/9vcJRYJfwu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/9vcJRYJfwu",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3633-on-writing-interfaces-well",
        "display_url" : "37signals.com\/svn\/posts\/3633\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "382545390471348224",
    "text" : "Designers need to be good writers. My new post on SvN: http:\/\/t.co\/9vcJRYJfwu",
    "id" : 382545390471348224,
    "created_at" : "2013-09-24 16:41:43 +0000",
    "user" : {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "protected" : false,
      "id_str" : "16454301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000153090409\/f136c60eca258e42e43b2d1760196833_normal.jpeg",
      "id" : 16454301,
      "verified" : false
    }
  },
  "id" : 382611772684791810,
  "created_at" : "2013-09-24 21:05:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    }, {
      "name" : "Alexey",
      "screen_name" : "appplemac",
      "indices" : [ 10, 20 ],
      "id_str" : "311029627",
      "id" : 311029627
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382606737070510080",
  "geo" : { },
  "id_str" : "382606958143864832",
  "in_reply_to_user_id" : 23621187,
  "text" : "@schneems @appplemac mysql, IRB, many others too :)",
  "id" : 382606958143864832,
  "in_reply_to_status_id" : 382606737070510080,
  "created_at" : "2013-09-24 20:46:21 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    }, {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 7, 14 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382570734670725120",
  "geo" : { },
  "id_str" : "382571227136925696",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH @maddox so much nope. Baseless or not, I think not trusting it is fine. It's just not for everyone.",
  "id" : 382571227136925696,
  "in_reply_to_status_id" : 382570734670725120,
  "created_at" : "2013-09-24 18:24:23 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    }, {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 7, 14 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382570046070861824",
  "geo" : { },
  "id_str" : "382570566982828032",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH @maddox confused: you have to use it on 5S? Also I'm pretty sure feeling uneasy about it is OK. Can't be the only one.",
  "id" : 382570566982828032,
  "in_reply_to_status_id" : 382570046070861824,
  "created_at" : "2013-09-24 18:21:45 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382568570657726464",
  "geo" : { },
  "id_str" : "382568827500118016",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox just creeped out by it. Feels same level as not going through the TSA machines",
  "id" : 382568827500118016,
  "in_reply_to_status_id" : 382568570657726464,
  "created_at" : "2013-09-24 18:14:50 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382564955704532992",
  "geo" : { },
  "id_str" : "382568112803311616",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox interesting perspective. Might go with 5S and just not use the Touch",
  "id" : 382568112803311616,
  "in_reply_to_status_id" : 382564955704532992,
  "created_at" : "2013-09-24 18:12:00 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382564274180481024",
  "geo" : { },
  "id_str" : "382567865943339008",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox le",
  "id" : 382567865943339008,
  "in_reply_to_status_id" : 382564274180481024,
  "created_at" : "2013-09-24 18:11:01 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 0, 11 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382557622953455616",
  "geo" : { },
  "id_str" : "382558066794721280",
  "in_reply_to_user_id" : 38408851,
  "text" : "@Jonplussed bad times dude",
  "id" : 382558066794721280,
  "in_reply_to_status_id" : 382557622953455616,
  "created_at" : "2013-09-24 17:32:05 +0000",
  "in_reply_to_screen_name" : "Jonplussed",
  "in_reply_to_user_id_str" : "38408851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382558024386113536",
  "text" : "RT @ashedryden: In the last week, five conferences have emailed me asking for resources to increase diversity. We\u2019ll keep doing this until \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382557575863992320",
    "text" : "In the last week, five conferences have emailed me asking for resources to increase diversity. We\u2019ll keep doing this until no one needs it.",
    "id" : 382557575863992320,
    "created_at" : "2013-09-24 17:30:08 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 382558024386113536,
  "created_at" : "2013-09-24 17:31:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382518961176190976",
  "text" : "The 5C case is a huge win for me. Back of my 4S has been shattered for months now. I'd happily trade speed for durability.",
  "id" : 382518961176190976,
  "created_at" : "2013-09-24 14:56:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Van Cleef",
      "screen_name" : "joshvc",
      "indices" : [ 0, 7 ],
      "id_str" : "15422369",
      "id" : 15422369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382518604853694464",
  "geo" : { },
  "id_str" : "382518787309715456",
  "in_reply_to_user_id" : 15422369,
  "text" : "@joshvc 4S.",
  "id" : 382518787309715456,
  "in_reply_to_status_id" : 382518604853694464,
  "created_at" : "2013-09-24 14:56:00 +0000",
  "in_reply_to_screen_name" : "joshvc",
  "in_reply_to_user_id_str" : "15422369",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    }, {
      "name" : "Ben Nicholas",
      "screen_name" : "bmnic",
      "indices" : [ 62, 68 ],
      "id_str" : "21306798",
      "id" : 21306798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382517679359553536",
  "geo" : { },
  "id_str" : "382518449735356416",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman ah yeah, but don't all models support CoreMotion? \/cc @bmnic",
  "id" : 382518449735356416,
  "in_reply_to_status_id" : 382517679359553536,
  "created_at" : "2013-09-24 14:54:39 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382518294135054338",
  "text" : "Hearing mostly that the camera is the only worthy upgrade. Don't need another one to compete with the X100S :)",
  "id" : 382518294135054338,
  "created_at" : "2013-09-24 14:54:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382517036967936001",
  "text" : "Only redeeming feature of the 5S seems to be slomo. Is there anything else worth it excluding Touch ID?",
  "id" : 382517036967936001,
  "created_at" : "2013-09-24 14:49:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "indices" : [ 36, 49 ],
      "id_str" : "174958347",
      "id" : 174958347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382515149430472704",
  "text" : "Everything happens, so much. Thanks @Horse_ebooks.",
  "id" : 382515149430472704,
  "created_at" : "2013-09-24 14:41:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Upton",
      "screen_name" : "uptonic",
      "indices" : [ 0, 8 ],
      "id_str" : "14408469",
      "id" : 14408469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382514875873763329",
  "geo" : { },
  "id_str" : "382515079238791168",
  "in_reply_to_user_id" : 14408469,
  "text" : "@uptonic I'll invest!",
  "id" : 382515079238791168,
  "in_reply_to_status_id" : 382514875873763329,
  "created_at" : "2013-09-24 14:41:16 +0000",
  "in_reply_to_screen_name" : "uptonic",
  "in_reply_to_user_id_str" : "14408469",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 8, 18 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382502936645218304",
  "geo" : { },
  "id_str" : "382509602652168192",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh @aquaranto Been wanting to try this with Ged. Soon!",
  "id" : 382509602652168192,
  "in_reply_to_status_id" : 382502936645218304,
  "created_at" : "2013-09-24 14:19:30 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "ghouls, buddy!",
      "screen_name" : "AaronM",
      "indices" : [ 13, 20 ],
      "id_str" : "9194742",
      "id" : 9194742
    }, {
      "name" : "natasha allegri",
      "screen_name" : "natazilla",
      "indices" : [ 33, 43 ],
      "id_str" : "14860638",
      "id" : 14860638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382356798713241600",
  "text" : "@juliepagano @AaronM yes! I hope @natazilla makes more.",
  "id" : 382356798713241600,
  "created_at" : "2013-09-24 04:12:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/4tEaE30SBp",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/6680232",
      "display_url" : "gist.github.com\/qrush\/6680232"
    } ]
  },
  "geo" : { },
  "id_str" : "382354521097134081",
  "text" : "This API feels futuristic somehow. Like it can just...tell me things. https:\/\/t.co\/4tEaE30SBp",
  "id" : 382354521097134081,
  "created_at" : "2013-09-24 04:03:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382350135566430211",
  "geo" : { },
  "id_str" : "382350293943332864",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort Not a problem here...Just using it to transform places to lat\/long for geojson's.",
  "id" : 382350293943332864,
  "in_reply_to_status_id" : 382350135566430211,
  "created_at" : "2013-09-24 03:46:28 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/zeBisNym9o",
      "expanded_url" : "https:\/\/developers.google.com\/maps\/documentation\/geocoding\/",
      "display_url" : "developers.google.com\/maps\/documenta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382349625681661952",
  "text" : "Ridiculously awesome API...turn places into numbers. https:\/\/t.co\/zeBisNym9o",
  "id" : 382349625681661952,
  "created_at" : "2013-09-24 03:43:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 5, 9 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382344855914950657",
  "geo" : { },
  "id_str" : "382349360551313408",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh @rjs more selling points to go from 4S =&gt; 5C here...can't get over the Touch ID creepy factor.",
  "id" : 382349360551313408,
  "in_reply_to_status_id" : 382344855914950657,
  "created_at" : "2013-09-24 03:42:45 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 0, 7 ],
      "id_str" : "9038902",
      "id" : 9038902
    }, {
      "name" : "Becky Joy",
      "screen_name" : "beckyjoy",
      "indices" : [ 8, 17 ],
      "id_str" : "14260269",
      "id" : 14260269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382327065363480576",
  "geo" : { },
  "id_str" : "382327876080521216",
  "in_reply_to_user_id" : 9038902,
  "text" : "@searls @beckyjoy awesome! safe travels.",
  "id" : 382327876080521216,
  "in_reply_to_status_id" : 382327065363480576,
  "created_at" : "2013-09-24 02:17:23 +0000",
  "in_reply_to_screen_name" : "searls",
  "in_reply_to_user_id_str" : "9038902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 0, 7 ],
      "id_str" : "9038902",
      "id" : 9038902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382326226003582977",
  "geo" : { },
  "id_str" : "382326757602250752",
  "in_reply_to_user_id" : 9038902,
  "text" : "@searls Where were you!?",
  "id" : 382326757602250752,
  "in_reply_to_status_id" : 382326226003582977,
  "created_at" : "2013-09-24 02:12:56 +0000",
  "in_reply_to_screen_name" : "searls",
  "in_reply_to_user_id_str" : "9038902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 117, 126 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/6fPCjB0xf8",
      "expanded_url" : "http:\/\/www.nejm.org\/doi\/full\/10.1056\/NEJMicm1108468",
      "display_url" : "nejm.org\/doi\/full\/10.10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382326622151405568",
  "text" : "Death by barium aspiration -&gt; crazy xray with airways highlighted like fractal trees. http:\/\/t.co\/6fPCjB0xf8 (via @bquarant)",
  "id" : 382326622151405568,
  "created_at" : "2013-09-24 02:12:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382326082801647617",
  "text" : "Let's see some more #ncrc13 photos! I saw a few cameras there...",
  "id" : 382326082801647617,
  "created_at" : "2013-09-24 02:10:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u1D48\u02B3\u1D43\u1D4F\u1D4F\u02B0\u1D49\u207F",
      "screen_name" : "drakkhen",
      "indices" : [ 0, 9 ],
      "id_str" : "18176030",
      "id" : 18176030
    }, {
      "name" : "Trending Buffalo",
      "screen_name" : "TrendingBuffalo",
      "indices" : [ 10, 26 ],
      "id_str" : "519717958",
      "id" : 519717958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382281403523932160",
  "geo" : { },
  "id_str" : "382287875233955840",
  "in_reply_to_user_id" : 18176030,
  "text" : "@drakkhen @TrendingBuffalo that's the point- sarcasm ;)",
  "id" : 382287875233955840,
  "in_reply_to_status_id" : 382281403523932160,
  "created_at" : "2013-09-23 23:38:26 +0000",
  "in_reply_to_screen_name" : "drakkhen",
  "in_reply_to_user_id_str" : "18176030",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382220858108170240",
  "geo" : { },
  "id_str" : "382221594820493312",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox Rough. The VFL is so good.",
  "id" : 382221594820493312,
  "in_reply_to_status_id" : 382220858108170240,
  "created_at" : "2013-09-23 19:15:04 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trending Buffalo",
      "screen_name" : "TrendingBuffalo",
      "indices" : [ 3, 19 ],
      "id_str" : "519717958",
      "id" : 519717958
    }, {
      "name" : "Mainstreethost",
      "screen_name" : "mainstreethost",
      "indices" : [ 54, 69 ],
      "id_str" : "23595720",
      "id" : 23595720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/RDUvRVRnaD",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/09\/23\/technology\/give-yourself-4-stars-online-it-might-cost-you.html?smid=tw-nytimes&_r=2&",
      "display_url" : "nytimes.com\/2013\/09\/23\/tec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382216633671905280",
  "text" : "RT @TrendingBuffalo: Congratulations to Buffalo's own @mainstreethost on making the NEW YORK TIMES today... way to make us proud!   http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mainstreethost",
        "screen_name" : "mainstreethost",
        "indices" : [ 33, 48 ],
        "id_str" : "23595720",
        "id" : 23595720
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/RDUvRVRnaD",
        "expanded_url" : "http:\/\/www.nytimes.com\/2013\/09\/23\/technology\/give-yourself-4-stars-online-it-might-cost-you.html?smid=tw-nytimes&_r=2&",
        "display_url" : "nytimes.com\/2013\/09\/23\/tec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "382207439723962369",
    "text" : "Congratulations to Buffalo's own @mainstreethost on making the NEW YORK TIMES today... way to make us proud!   http:\/\/t.co\/RDUvRVRnaD",
    "id" : 382207439723962369,
    "created_at" : "2013-09-23 18:18:49 +0000",
    "user" : {
      "name" : "Trending Buffalo",
      "screen_name" : "TrendingBuffalo",
      "protected" : false,
      "id_str" : "519717958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3086392748\/af09c3aec0c906764bed3f02b501dd6c_normal.jpeg",
      "id" : 519717958,
      "verified" : false
    }
  },
  "id" : 382216633671905280,
  "created_at" : "2013-09-23 18:55:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382214074987458560",
  "geo" : { },
  "id_str" : "382214316725772288",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox in IB or in the VFL?",
  "id" : 382214316725772288,
  "in_reply_to_status_id" : 382214074987458560,
  "created_at" : "2013-09-23 18:46:08 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric S",
      "screen_name" : "MutualArising",
      "indices" : [ 0, 14 ],
      "id_str" : "15913837",
      "id" : 15913837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382185441275162625",
  "geo" : { },
  "id_str" : "382185691532128256",
  "in_reply_to_user_id" : 15913837,
  "text" : "@MutualArising Hoping that's going to be livestreamed. Good luck!",
  "id" : 382185691532128256,
  "in_reply_to_status_id" : 382185441275162625,
  "created_at" : "2013-09-23 16:52:24 +0000",
  "in_reply_to_screen_name" : "MutualArising",
  "in_reply_to_user_id_str" : "15913837",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana Jones",
      "screen_name" : "danabrit",
      "indices" : [ 3, 12 ],
      "id_str" : "5994002",
      "id" : 5994002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382183804586041346",
  "text" : "RT @danabrit: I'm writing code, not making diamonds. Continuing to apply more and more pressure will not produce a better outcome.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382127860753784832",
    "text" : "I'm writing code, not making diamonds. Continuing to apply more and more pressure will not produce a better outcome.",
    "id" : 382127860753784832,
    "created_at" : "2013-09-23 13:02:36 +0000",
    "user" : {
      "name" : "Dana Jones",
      "screen_name" : "danabrit",
      "protected" : false,
      "id_str" : "5994002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567762918285258753\/zIyvgheR_normal.jpeg",
      "id" : 5994002,
      "verified" : false
    }
  },
  "id" : 382183804586041346,
  "created_at" : "2013-09-23 16:44:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric S",
      "screen_name" : "MutualArising",
      "indices" : [ 0, 14 ],
      "id_str" : "15913837",
      "id" : 15913837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382183414092148736",
  "geo" : { },
  "id_str" : "382183638646812672",
  "in_reply_to_user_id" : 15913837,
  "text" : "@MutualArising oh dude! Want to go to Rochester's show next month? I have tickets.",
  "id" : 382183638646812672,
  "in_reply_to_status_id" : 382183414092148736,
  "created_at" : "2013-09-23 16:44:14 +0000",
  "in_reply_to_screen_name" : "MutualArising",
  "in_reply_to_user_id_str" : "15913837",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382179578879307777",
  "geo" : { },
  "id_str" : "382183381749882880",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan word. GL HF!",
  "id" : 382183381749882880,
  "in_reply_to_status_id" : 382179578879307777,
  "created_at" : "2013-09-23 16:43:13 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 5, 11 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/0qwT2yfYzK",
      "expanded_url" : "http:\/\/drygoods.phish.com\/Dept.aspx?cp=773_62767&src=FACENIAGARAFALLS&utm_source=facebook.com&utm_medium=referral&utm_campaign=NIAGARAFALLS",
      "display_url" : "drygoods.phish.com\/Dept.aspx?cp=7\u2026"
    }, {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/usa68FxQqX",
      "expanded_url" : "http:\/\/static.musictoday.com\/store\/bands\/840\/product_large\/PHAM320.jpg",
      "display_url" : "static.musictoday.com\/store\/bands\/84\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382182849484292096",
  "text" : "Yes! @phish is releasing a show from Niagara Falls complete with an awesome poster: http:\/\/t.co\/0qwT2yfYzK http:\/\/t.co\/usa68FxQqX",
  "id" : 382182849484292096,
  "created_at" : "2013-09-23 16:41:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382178853105324034",
  "geo" : { },
  "id_str" : "382179193389215744",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan why such a negative title? I get the meme but seems like focusing on the positive would yield a...happier feeling.",
  "id" : 382179193389215744,
  "in_reply_to_status_id" : 382178853105324034,
  "created_at" : "2013-09-23 16:26:34 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    }, {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 17, 27 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382170087417196544",
  "geo" : { },
  "id_str" : "382172397169696769",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh yes sir. @confreaks is on it.",
  "id" : 382172397169696769,
  "in_reply_to_status_id" : 382170087417196544,
  "created_at" : "2013-09-23 15:59:34 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enric Lluelles",
      "screen_name" : "enriclluelles",
      "indices" : [ 0, 14 ],
      "id_str" : "57446166",
      "id" : 57446166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382170795331821568",
  "geo" : { },
  "id_str" : "382171632283820032",
  "in_reply_to_user_id" : 57446166,
  "text" : "@enriclluelles Yes! Also thanks, I need to take that down.",
  "id" : 382171632283820032,
  "in_reply_to_status_id" : 382170795331821568,
  "created_at" : "2013-09-23 15:56:32 +0000",
  "in_reply_to_screen_name" : "enriclluelles",
  "in_reply_to_user_id_str" : "57446166",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Nicholas",
      "screen_name" : "bmnic",
      "indices" : [ 0, 6 ],
      "id_str" : "21306798",
      "id" : 21306798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382164264359718913",
  "geo" : { },
  "id_str" : "382164645466759168",
  "in_reply_to_user_id" : 21306798,
  "text" : "@bmnic You can set a full password. I tried it for a while but got tedious. Also you can set to erase after 10(?) failed attempts.",
  "id" : 382164645466759168,
  "in_reply_to_status_id" : 382164264359718913,
  "created_at" : "2013-09-23 15:28:46 +0000",
  "in_reply_to_screen_name" : "bmnic",
  "in_reply_to_user_id_str" : "21306798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/LrUMfvVWay",
      "expanded_url" : "http:\/\/www.ccc.de\/en\/updates\/2013\/ccc-breaks-apple-touchid",
      "display_url" : "ccc.de\/en\/updates\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382163208322043904",
  "text" : "Time to get a 5C? \"Biometrics [is a] technology designed for oppression and control\" http:\/\/t.co\/LrUMfvVWay",
  "id" : 382163208322043904,
  "created_at" : "2013-09-23 15:23:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382125961590108160",
  "geo" : { },
  "id_str" : "382160524055564288",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler Only 99\u00A2 to advance this slide!",
  "id" : 382160524055564288,
  "in_reply_to_status_id" : 382125961590108160,
  "created_at" : "2013-09-23 15:12:23 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382151975606812674",
  "geo" : { },
  "id_str" : "382153619945951232",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV Be honest, humble, and never stop pushing.",
  "id" : 382153619945951232,
  "in_reply_to_status_id" : 382151975606812674,
  "created_at" : "2013-09-23 14:44:57 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 17, 32 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coderetreat",
      "indices" : [ 47, 59 ]
    }, {
      "text" : "ncrc13",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/3fSrixxjXT",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush\/sets\/72157635802333945\/",
      "display_url" : "flickr.com\/photos\/qrush\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382148542027935745",
  "text" : "Some photos from @nickelcityruby Day 1 and the #coderetreat! http:\/\/t.co\/3fSrixxjXT #ncrc13",
  "id" : 382148542027935745,
  "created_at" : "2013-09-23 14:24:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 3, 15 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382146992429727744",
  "text" : "RT @SaraJChipps: It's time to make the internets.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382142787736842240",
    "text" : "It's time to make the internets.",
    "id" : 382142787736842240,
    "created_at" : "2013-09-23 14:01:55 +0000",
    "user" : {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "protected" : false,
      "id_str" : "15524875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475386075997683712\/TOSOGa0K_normal.png",
      "id" : 15524875,
      "verified" : false
    }
  },
  "id" : 382146992429727744,
  "created_at" : "2013-09-23 14:18:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Hurne",
      "screen_name" : "jthurne",
      "indices" : [ 3, 11 ],
      "id_str" : "81497521",
      "id" : 81497521
    }, {
      "name" : "Z80 Labs",
      "screen_name" : "Z80Labs",
      "indices" : [ 23, 31 ],
      "id_str" : "632391390",
      "id" : 632391390
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 56, 71 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coderetreat",
      "indices" : [ 72, 84 ]
    }, {
      "text" : "ncrc13",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382127811508453376",
  "text" : "RT @jthurne: Thank you @Z80Labs for hosting yesterday's @nickelcityruby #coderetreat! It was truly awesome. #ncrc13",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/launchpad.net\/polly\" rel=\"nofollow\"\u003EPolly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Z80 Labs",
        "screen_name" : "Z80Labs",
        "indices" : [ 10, 18 ],
        "id_str" : "632391390",
        "id" : 632391390
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 43, 58 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coderetreat",
        "indices" : [ 59, 71 ]
      }, {
        "text" : "ncrc13",
        "indices" : [ 95, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382104047094104064",
    "text" : "Thank you @Z80Labs for hosting yesterday's @nickelcityruby #coderetreat! It was truly awesome. #ncrc13",
    "id" : 382104047094104064,
    "created_at" : "2013-09-23 11:27:58 +0000",
    "user" : {
      "name" : "Jim Hurne",
      "screen_name" : "jthurne",
      "protected" : false,
      "id_str" : "81497521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1221406872\/HurneJames-Small_normal.JPG",
      "id" : 81497521,
      "verified" : false
    }
  },
  "id" : 382127811508453376,
  "created_at" : "2013-09-23 13:02:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed",
      "screen_name" : "mneorr",
      "indices" : [ 0, 7 ],
      "id_str" : "2358949105",
      "id" : 2358949105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382094506944135168",
  "geo" : { },
  "id_str" : "382109609885827072",
  "in_reply_to_user_id" : 259575244,
  "text" : "@mneorr it's 30sec right now. Mind posting a speedtest screenshot? Could try emulating via the NLC",
  "id" : 382109609885827072,
  "in_reply_to_status_id" : 382094506944135168,
  "created_at" : "2013-09-23 11:50:04 +0000",
  "in_reply_to_screen_name" : "_supermarin",
  "in_reply_to_user_id_str" : "259575244",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adarsh Pandit",
      "screen_name" : "adarshp",
      "indices" : [ 0, 8 ],
      "id_str" : "14436348",
      "id" : 14436348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382019789784236032",
  "geo" : { },
  "id_str" : "382109391190642688",
  "in_reply_to_user_id" : 14436348,
  "text" : "@adarshp this is easy: I assume everyone is a fracking Cylon.",
  "id" : 382109391190642688,
  "in_reply_to_status_id" : 382019789784236032,
  "created_at" : "2013-09-23 11:49:12 +0000",
  "in_reply_to_screen_name" : "adarshp",
  "in_reply_to_user_id_str" : "14436348",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\u3065\uFF61\u25D5\u203F\u203F\u25D5\uFF61)\u3065",
      "screen_name" : "ladyfox14",
      "indices" : [ 0, 10 ],
      "id_str" : "7795202",
      "id" : 7795202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382013580268167168",
  "geo" : { },
  "id_str" : "382109287784263680",
  "in_reply_to_user_id" : 7795202,
  "text" : "@ladyfox14 oh, that's the dog park. Derp.",
  "id" : 382109287784263680,
  "in_reply_to_status_id" : 382013580268167168,
  "created_at" : "2013-09-23 11:48:48 +0000",
  "in_reply_to_screen_name" : "ladyfox14",
  "in_reply_to_user_id_str" : "7795202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 3, 14 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc2013",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381977601318719488",
  "text" : "RT @Jonplussed: Sometimes I forget why I pursue what I pursue. It feels good to remember that even from behind a screen- it\u2019s the people. #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc2013",
        "indices" : [ 122, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381908037927071744",
    "text" : "Sometimes I forget why I pursue what I pursue. It feels good to remember that even from behind a screen- it\u2019s the people. #ncrc2013",
    "id" : 381908037927071744,
    "created_at" : "2013-09-22 22:29:06 +0000",
    "user" : {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "protected" : false,
      "id_str" : "38408851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471328341526462464\/hNg5dFGn_normal.jpeg",
      "id" : 38408851,
      "verified" : false
    }
  },
  "id" : 381977601318719488,
  "created_at" : "2013-09-23 03:05:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381972171272110080",
  "geo" : { },
  "id_str" : "381977571736301568",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents these turned out amazing. thanks so much!!",
  "id" : 381977571736301568,
  "in_reply_to_status_id" : 381972171272110080,
  "created_at" : "2013-09-23 03:05:24 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 3, 17 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/4OjDRtCjKy",
      "expanded_url" : "https:\/\/secure.flickr.com\/photos\/carolnichols\/sets\/72157635784885796\/",
      "display_url" : "secure.flickr.com\/photos\/carolni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381977015814848512",
  "text" : "RT @Carols10cents: My #ncrc13 photos: https:\/\/t.co\/4OjDRtCjKy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 3, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/4OjDRtCjKy",
        "expanded_url" : "https:\/\/secure.flickr.com\/photos\/carolnichols\/sets\/72157635784885796\/",
        "display_url" : "secure.flickr.com\/photos\/carolni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381971613828120576",
    "text" : "My #ncrc13 photos: https:\/\/t.co\/4OjDRtCjKy",
    "id" : 381971613828120576,
    "created_at" : "2013-09-23 02:41:44 +0000",
    "user" : {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "protected" : false,
      "id_str" : "194688433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446291681252364288\/_okxMUY1_normal.jpeg",
      "id" : 194688433,
      "verified" : false
    }
  },
  "id" : 381977015814848512,
  "created_at" : "2013-09-23 03:03:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/efJEkXu7Mg",
      "expanded_url" : "https:\/\/accounts.google.com\/SmsAuthConfig",
      "display_url" : "accounts.google.com\/SmsAuthConfig"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/wyDf3RIGLk",
      "expanded_url" : "http:\/\/37signals.com\/verify",
      "display_url" : "37signals.com\/verify"
    } ]
  },
  "geo" : { },
  "id_str" : "381966970821701632",
  "text" : "RT @thoughtbot: Have you set up two-factor authentication yet for your Google and 37signals accounts? https:\/\/t.co\/efJEkXu7Mg and http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/efJEkXu7Mg",
        "expanded_url" : "https:\/\/accounts.google.com\/SmsAuthConfig",
        "display_url" : "accounts.google.com\/SmsAuthConfig"
      }, {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/wyDf3RIGLk",
        "expanded_url" : "http:\/\/37signals.com\/verify",
        "display_url" : "37signals.com\/verify"
      } ]
    },
    "geo" : { },
    "id_str" : "381963681481105409",
    "text" : "Have you set up two-factor authentication yet for your Google and 37signals accounts? https:\/\/t.co\/efJEkXu7Mg and http:\/\/t.co\/wyDf3RIGLk",
    "id" : 381963681481105409,
    "created_at" : "2013-09-23 02:10:12 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 381966970821701632,
  "created_at" : "2013-09-23 02:23:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/MoBcx5GMNz",
      "expanded_url" : "http:\/\/www.thoughtbot.com\/",
      "display_url" : "thoughtbot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "381966508189958145",
  "text" : "New http:\/\/t.co\/MoBcx5GMNz looks great. That's a lot of people!",
  "id" : 381966508189958145,
  "created_at" : "2013-09-23 02:21:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Backyard Kitchen",
      "screen_name" : "BackyardSF",
      "indices" : [ 4, 15 ],
      "id_str" : "394986704",
      "id" : 394986704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381955177990742017",
  "text" : "Hey @BackyardSF, thanks for ruining my pregnant wife's night by canceling her order when she's 3000 miles away from home.",
  "id" : 381955177990742017,
  "created_at" : "2013-09-23 01:36:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381952133878120448",
  "text" : "RT @aquaranto: Big thx to the manager at the Backyard Kitchen in SF for losing my order and then deciding not to make it. I'm a sad, hungry\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381952005582774273",
    "text" : "Big thx to the manager at the Backyard Kitchen in SF for losing my order and then deciding not to make it. I'm a sad, hungry, pregnant lady.",
    "id" : 381952005582774273,
    "created_at" : "2013-09-23 01:23:49 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 381952133878120448,
  "created_at" : "2013-09-23 01:24:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 13, 25 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381944068663554048",
  "geo" : { },
  "id_str" : "381945083211169792",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines @wesgarrison definitely. Localhost requires no patience :)",
  "id" : 381945083211169792,
  "in_reply_to_status_id" : 381944068663554048,
  "created_at" : "2013-09-23 00:56:18 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 3, 9 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381936241757126656",
  "text" : "RT @chorn: Code retreat today, just about the most fun programming I've done in a decade.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381935980552286208",
    "text" : "Code retreat today, just about the most fun programming I've done in a decade.",
    "id" : 381935980552286208,
    "created_at" : "2013-09-23 00:20:08 +0000",
    "user" : {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "protected" : false,
      "id_str" : "744613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2310147637\/niixqq7ibisfwaat2xmg_normal.png",
      "id" : 744613,
      "verified" : false
    }
  },
  "id" : 381936241757126656,
  "created_at" : "2013-09-23 00:21:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Williams",
      "screen_name" : "mwilliams",
      "indices" : [ 0, 10 ],
      "id_str" : "1259861",
      "id" : 1259861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381922935386439680",
  "geo" : { },
  "id_str" : "381926743130394624",
  "in_reply_to_user_id" : 1259861,
  "text" : "@mwilliams very morbid exhibit when I saw it in Detroit. Nothing like actually handling it though.",
  "id" : 381926743130394624,
  "in_reply_to_status_id" : 381922935386439680,
  "created_at" : "2013-09-22 23:43:26 +0000",
  "in_reply_to_screen_name" : "mwilliams",
  "in_reply_to_user_id_str" : "1259861",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381888585370439680",
  "geo" : { },
  "id_str" : "381921578981679105",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn I approve of this avatar.",
  "id" : 381921578981679105,
  "in_reply_to_status_id" : 381888585370439680,
  "created_at" : "2013-09-22 23:22:54 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381921273435394048",
  "text" : "Held several (real!) human bones and a skull tonight. Nothing else gives you a perspective like seeing what's under your skin.",
  "id" : 381921273435394048,
  "created_at" : "2013-09-22 23:21:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\u3065\uFF61\u25D5\u203F\u203F\u25D5\uFF61)\u3065",
      "screen_name" : "ladyfox14",
      "indices" : [ 0, 10 ],
      "id_str" : "7795202",
      "id" : 7795202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381889635602808834",
  "geo" : { },
  "id_str" : "381920553382477824",
  "in_reply_to_user_id" : 7795202,
  "text" : "@ladyfox14 ha, that's a parkway. No backyard here!",
  "id" : 381920553382477824,
  "in_reply_to_status_id" : 381889635602808834,
  "created_at" : "2013-09-22 23:18:50 +0000",
  "in_reply_to_screen_name" : "ladyfox14",
  "in_reply_to_user_id_str" : "7795202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Hurne",
      "screen_name" : "jthurne",
      "indices" : [ 129, 137 ],
      "id_str" : "81497521",
      "id" : 81497521
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coderetreat",
      "indices" : [ 31, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381886272413134848",
  "text" : "That being said I need to do a #coderetreat when my brain isn't made of putty. Thanks for helping out the Buffalo tech community @jthurne!",
  "id" : 381886272413134848,
  "created_at" : "2013-09-22 21:02:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 66, 81 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coderetreat",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381885764520656896",
  "text" : "Lots of reflection about craft and practice of programming in the @nickelcityruby #coderetreat. Awesome to see this openly discussed.",
  "id" : 381885764520656896,
  "created_at" : "2013-09-22 21:00:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 13, 26 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/ylWBLi4C4e",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush\/8455475301\/",
      "display_url" : "flickr.com\/photos\/qrush\/8\u2026"
    }, {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/VXpa1dcbps",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush\/8569538603\/",
      "display_url" : "flickr.com\/photos\/qrush\/8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381879440218652672",
  "text" : "@juliepagano @lindseybieda ha, I'll try. For now: http:\/\/t.co\/ylWBLi4C4e http:\/\/t.co\/VXpa1dcbps",
  "id" : 381879440218652672,
  "created_at" : "2013-09-22 20:35:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381595780328325120",
  "geo" : { },
  "id_str" : "381878415902531584",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda i can confirm similar derpy husky behavior happens in deep, deep snow",
  "id" : 381878415902531584,
  "in_reply_to_status_id" : 381595780328325120,
  "created_at" : "2013-09-22 20:31:23 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 3, 16 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/5GEYsTig6z",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=7xEX-48RHCY",
      "display_url" : "youtube.com\/watch?v=7xEX-4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381875471475937280",
  "text" : "RT @lindseybieda: Happy fall here's a Siberian Husky playing in leaves: http:\/\/t.co\/5GEYsTig6z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/5GEYsTig6z",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=7xEX-48RHCY",
        "display_url" : "youtube.com\/watch?v=7xEX-4\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381595780328325120",
    "text" : "Happy fall here's a Siberian Husky playing in leaves: http:\/\/t.co\/5GEYsTig6z",
    "id" : 381595780328325120,
    "created_at" : "2013-09-22 01:48:18 +0000",
    "user" : {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "protected" : false,
      "id_str" : "14928483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569192760029089792\/zaGhTAHK_normal.jpeg",
      "id" : 14928483,
      "verified" : false
    }
  },
  "id" : 381875471475937280,
  "created_at" : "2013-09-22 20:19:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381863503931265024",
  "geo" : { },
  "id_str" : "381863628044902400",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik Ouch. Getting a 5C then?",
  "id" : 381863628044902400,
  "in_reply_to_status_id" : 381863503931265024,
  "created_at" : "2013-09-22 19:32:38 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed News",
      "screen_name" : "BuzzFeedNews",
      "indices" : [ 3, 16 ],
      "id_str" : "1020058453",
      "id" : 1020058453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/aoXUSXd9qT",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/jwherrman\/the-iphones-fingerprint-sensor-has-already-been-hacked",
      "display_url" : "buzzfeed.com\/jwherrman\/the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381863500093476864",
  "text" : "RT @BuzzFeedNews: The iPhone\u2019s Fingerprint Sensor Has Already Been Hacked http:\/\/t.co\/aoXUSXd9qT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/aoXUSXd9qT",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/jwherrman\/the-iphones-fingerprint-sensor-has-already-been-hacked",
        "display_url" : "buzzfeed.com\/jwherrman\/the-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381860241128058880",
    "text" : "The iPhone\u2019s Fingerprint Sensor Has Already Been Hacked http:\/\/t.co\/aoXUSXd9qT",
    "id" : 381860241128058880,
    "created_at" : "2013-09-22 19:19:10 +0000",
    "user" : {
      "name" : "BuzzFeed News",
      "screen_name" : "BuzzFeedNews",
      "protected" : false,
      "id_str" : "1020058453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519909714964910080\/rhpg8-d1_normal.jpeg",
      "id" : 1020058453,
      "verified" : true
    }
  },
  "id" : 381863500093476864,
  "created_at" : "2013-09-22 19:32:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 30, 45 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381854305977765889",
  "text" : "If you're posting photos from @nickelcityruby please tag them! Would love to see some more. #ncrc13",
  "id" : 381854305977765889,
  "created_at" : "2013-09-22 18:55:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381851317909483520",
  "text" : "RT @coworkbuffalo: We have pumpkin cinnamon rolls tomorrow, y'all. Pumpkin cinnamon rolls and Stumptown Chemex coffee. Fallllllll.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381851268949348352",
    "text" : "We have pumpkin cinnamon rolls tomorrow, y'all. Pumpkin cinnamon rolls and Stumptown Chemex coffee. Fallllllll.",
    "id" : 381851268949348352,
    "created_at" : "2013-09-22 18:43:31 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 381851317909483520,
  "created_at" : "2013-09-22 18:43:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 8, 16 ],
      "id_str" : "28819745",
      "id" : 28819745
    }, {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 17, 24 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381817156926582784",
  "geo" : { },
  "id_str" : "381848401740312576",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky @sikachu @gabebw he did ask if kayaking was possible.",
  "id" : 381848401740312576,
  "in_reply_to_status_id" : 381817156926582784,
  "created_at" : "2013-09-22 18:32:08 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "blake johnson",
      "screen_name" : "blake41",
      "indices" : [ 0, 8 ],
      "id_str" : "7605412",
      "id" : 7605412
    }, {
      "name" : "Joe Burgess",
      "screen_name" : "jmburges",
      "indices" : [ 9, 18 ],
      "id_str" : "47312435",
      "id" : 47312435
    }, {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "indices" : [ 19, 27 ],
      "id_str" : "304067888",
      "id" : 304067888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381841021333549056",
  "geo" : { },
  "id_str" : "381845242754134016",
  "in_reply_to_user_id" : 7605412,
  "text" : "@blake41 @jmburges @ag_dubs oh geez! Hope it turned out ok",
  "id" : 381845242754134016,
  "in_reply_to_status_id" : 381841021333549056,
  "created_at" : "2013-09-22 18:19:34 +0000",
  "in_reply_to_screen_name" : "blake41",
  "in_reply_to_user_id_str" : "7605412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381842772644229120",
  "geo" : { },
  "id_str" : "381844941099778048",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy sure did. Carried water for us.",
  "id" : 381844941099778048,
  "in_reply_to_status_id" : 381842772644229120,
  "created_at" : "2013-09-22 18:18:22 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/381841947247136768\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/mmCtgx0dCo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUyTOlCCQAAfMY0.jpg",
      "id_str" : "381841947087749120",
      "id" : 381841947087749120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUyTOlCCQAAfMY0.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/mmCtgx0dCo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381841947247136768",
  "text" : "Bringing new and returning visitors to Niagara Falls always is awesome. Oh, and a dog too. http:\/\/t.co\/mmCtgx0dCo",
  "id" : 381841947247136768,
  "created_at" : "2013-09-22 18:06:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Hurne",
      "screen_name" : "jthurne",
      "indices" : [ 3, 11 ],
      "id_str" : "81497521",
      "id" : 81497521
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 64, 71 ]
    }, {
      "text" : "coderetreat",
      "indices" : [ 72, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381785398126465024",
  "text" : "RT @jthurne: Good morning Buffalo! Getting myself ready for the #ncrc13 #coderetreat. It's going to be a great day!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/launchpad.net\/polly\" rel=\"nofollow\"\u003EPolly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 51, 58 ]
      }, {
        "text" : "coderetreat",
        "indices" : [ 59, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381751974774833152",
    "text" : "Good morning Buffalo! Getting myself ready for the #ncrc13 #coderetreat. It's going to be a great day!",
    "id" : 381751974774833152,
    "created_at" : "2013-09-22 12:08:58 +0000",
    "user" : {
      "name" : "Jim Hurne",
      "screen_name" : "jthurne",
      "protected" : false,
      "id_str" : "81497521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1221406872\/HurneJames-Small_normal.JPG",
      "id" : 81497521,
      "verified" : false
    }
  },
  "id" : 381785398126465024,
  "created_at" : "2013-09-22 14:21:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 14, 29 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381784979685912576",
  "text" : "Also making a @nickelcityruby Niagara Falls convoy trip. Heading off from the Comfort Suites at 11.",
  "id" : 381784979685912576,
  "created_at" : "2013-09-22 14:20:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 6, 21 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Z80 Labs",
      "screen_name" : "Z80Labs",
      "indices" : [ 50, 58 ],
      "id_str" : "632391390",
      "id" : 632391390
    }, {
      "name" : "Jim Hurne",
      "screen_name" : "jthurne",
      "indices" : [ 74, 82 ],
      "id_str" : "81497521",
      "id" : 81497521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381784139373883393",
  "text" : "Woot! @nickelcityruby Code Retreat is kicking off @Z80Labs. Big thanks to @jthurne for facilitating this.",
  "id" : 381784139373883393,
  "created_at" : "2013-09-22 14:16:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alagappan",
      "screen_name" : "_alagappan",
      "indices" : [ 0, 11 ],
      "id_str" : "8160872",
      "id" : 8160872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381776897015050240",
  "geo" : { },
  "id_str" : "381783832849969153",
  "in_reply_to_user_id" : 8160872,
  "text" : "@_alagappan it's just getting started now. just get here when you can!",
  "id" : 381783832849969153,
  "in_reply_to_status_id" : 381776897015050240,
  "created_at" : "2013-09-22 14:15:33 +0000",
  "in_reply_to_screen_name" : "_alagappan",
  "in_reply_to_user_id_str" : "8160872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 33, 41 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381748494387908608",
  "geo" : { },
  "id_str" : "381749801970200578",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten no, but I'm sure @sikachu can answer questions :)",
  "id" : 381749801970200578,
  "in_reply_to_status_id" : 381748494387908608,
  "created_at" : "2013-09-22 12:00:20 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381749697020297216",
  "text" : "Loving how apps are getting refreshed for iOS7. I wonder which will stay left behind though...",
  "id" : 381749697020297216,
  "created_at" : "2013-09-22 11:59:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 23, 38 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381749181926232065",
  "text" : "Almost time to get the @nickelcityruby Code Retreat started up. Almost 20 signed up!",
  "id" : 381749181926232065,
  "created_at" : "2013-09-22 11:57:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Chapman",
      "screen_name" : "byllc",
      "indices" : [ 0, 6 ],
      "id_str" : "34287352",
      "id" : 34287352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381580937928011776",
  "geo" : { },
  "id_str" : "381748442470440960",
  "in_reply_to_user_id" : 34287352,
  "text" : "@byllc huge smiles. Couldn't have done it alone. Thanks man.",
  "id" : 381748442470440960,
  "in_reply_to_status_id" : 381580937928011776,
  "created_at" : "2013-09-22 11:54:55 +0000",
  "in_reply_to_screen_name" : "byllc",
  "in_reply_to_user_id_str" : "34287352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coby Randquist",
      "screen_name" : "kobier",
      "indices" : [ 3, 10 ],
      "id_str" : "5284122",
      "id" : 5284122
    }, {
      "name" : "Neal Sales-Griffin",
      "screen_name" : "nealsales",
      "indices" : [ 12, 22 ],
      "id_str" : "13275012",
      "id" : 13275012
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc2013",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381748035266441218",
  "text" : "RT @kobier: @nealsales gave an inspiring closing keynote at #ncrc2013, I highly recommend watching it! As soon as we get them posted.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neal Sales-Griffin",
        "screen_name" : "nealsales",
        "indices" : [ 0, 10 ],
        "id_str" : "13275012",
        "id" : 13275012
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc2013",
        "indices" : [ 48, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381746813880905728",
    "in_reply_to_user_id" : 13275012,
    "text" : "@nealsales gave an inspiring closing keynote at #ncrc2013, I highly recommend watching it! As soon as we get them posted.",
    "id" : 381746813880905728,
    "created_at" : "2013-09-22 11:48:27 +0000",
    "in_reply_to_screen_name" : "nealsales",
    "in_reply_to_user_id_str" : "13275012",
    "user" : {
      "name" : "Coby Randquist",
      "screen_name" : "kobier",
      "protected" : false,
      "id_str" : "5284122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461556828866768897\/UlSQ0BLG_normal.jpeg",
      "id" : 5284122,
      "verified" : false
    }
  },
  "id" : 381748035266441218,
  "created_at" : "2013-09-22 11:53:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381719762780176385",
  "text" : "RT @aquaranto: Anyone else from #ncrc13 at the airport bright and early this morning?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 17, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381719682698739712",
    "text" : "Anyone else from #ncrc13 at the airport bright and early this morning?",
    "id" : 381719682698739712,
    "created_at" : "2013-09-22 10:00:39 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 381719762780176385,
  "created_at" : "2013-09-22 10:00:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carina C. Zona",
      "screen_name" : "cczona",
      "indices" : [ 3, 10 ],
      "id_str" : "39617149",
      "id" : 39617149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/6GHfrbdZa1",
      "expanded_url" : "https:\/\/twitter.com\/cczona\/lists\/nickel-city-rubyconf-2013",
      "display_url" : "twitter.com\/cczona\/lists\/n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381707862772174848",
  "text" : "RT @cczona: If you'd like to catch up on the #ncrc13 conversations you missed, here's over 70 attendees' streams aggregated https:\/\/t.co\/6G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 33, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/6GHfrbdZa1",
        "expanded_url" : "https:\/\/twitter.com\/cczona\/lists\/nickel-city-rubyconf-2013",
        "display_url" : "twitter.com\/cczona\/lists\/n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381688403315527680",
    "text" : "If you'd like to catch up on the #ncrc13 conversations you missed, here's over 70 attendees' streams aggregated https:\/\/t.co\/6GHfrbdZa1",
    "id" : 381688403315527680,
    "created_at" : "2013-09-22 07:56:21 +0000",
    "user" : {
      "name" : "Carina C. Zona",
      "screen_name" : "cczona",
      "protected" : false,
      "id_str" : "39617149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3448372624\/fbfdda29ff5fcee3ff0ad60e2d3932ae_normal.jpeg",
      "id" : 39617149,
      "verified" : false
    }
  },
  "id" : 381707862772174848,
  "created_at" : "2013-09-22 09:13:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/A3QlGlPZiT",
      "expanded_url" : "http:\/\/i.imgur.com\/lvTRIYo.jpg",
      "display_url" : "i.imgur.com\/lvTRIYo.jpg"
    } ]
  },
  "in_reply_to_status_id_str" : "381618185843142658",
  "geo" : { },
  "id_str" : "381618543277506561",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis http:\/\/t.co\/A3QlGlPZiT",
  "id" : 381618543277506561,
  "in_reply_to_status_id" : 381618185843142658,
  "created_at" : "2013-09-22 03:18:45 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381616970602258432",
  "geo" : { },
  "id_str" : "381617855646556162",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis totally. I want to do a real life mission - pilot separated in a room in cockpit view, mission control giving instructions via radio",
  "id" : 381617855646556162,
  "in_reply_to_status_id" : 381616970602258432,
  "created_at" : "2013-09-22 03:16:01 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381615939759767552",
  "geo" : { },
  "id_str" : "381616591730786304",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis EVA leap for the stranded Kerbol only worked because I smashed into a solar panel and ripped it off. Absolutely insane game.",
  "id" : 381616591730786304,
  "in_reply_to_status_id" : 381615939759767552,
  "created_at" : "2013-09-22 03:11:00 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/gIpmBK9YPy",
      "expanded_url" : "http:\/\/imgur.com\/a\/7fwTG",
      "display_url" : "imgur.com\/a\/7fwTG"
    } ]
  },
  "in_reply_to_status_id_str" : "381615119496536065",
  "geo" : { },
  "id_str" : "381615515774369792",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis awesome. landed on Duna but no way back...haven't figured out Eve yet. A story from the other week: http:\/\/t.co\/gIpmBK9YPy",
  "id" : 381615515774369792,
  "in_reply_to_status_id" : 381615119496536065,
  "created_at" : "2013-09-22 03:06:43 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 16, 25 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 26, 35 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381614754730885120",
  "geo" : { },
  "id_str" : "381615019508527104",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog @bquarant @LawnMemo big thanks.",
  "id" : 381615019508527104,
  "in_reply_to_status_id" : 381614754730885120,
  "created_at" : "2013-09-22 03:04:45 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381614543551471617",
  "geo" : { },
  "id_str" : "381614916068581376",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis oh man!! Land anywhere yet?",
  "id" : 381614916068581376,
  "in_reply_to_status_id" : 381614543551471617,
  "created_at" : "2013-09-22 03:04:20 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 22, 31 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 35, 50 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381606386851131392",
  "geo" : { },
  "id_str" : "381607238973919232",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant dude I hope @LawnMemo or @UnclePhilsBlog are recording this show. Too wiped to see it.",
  "id" : 381607238973919232,
  "in_reply_to_status_id" : 381606386851131392,
  "created_at" : "2013-09-22 02:33:50 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adarsh Pandit",
      "screen_name" : "adarshp",
      "indices" : [ 3, 11 ],
      "id_str" : "14436348",
      "id" : 14436348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gogaruco",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381603390427394048",
  "text" : "RT @adarshp: Sat with strangers during meals at #gogaruco. \n\nHighly recommended conference behavior.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gogaruco",
        "indices" : [ 35, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381581927708254208",
    "text" : "Sat with strangers during meals at #gogaruco. \n\nHighly recommended conference behavior.",
    "id" : 381581927708254208,
    "created_at" : "2013-09-22 00:53:15 +0000",
    "user" : {
      "name" : "Adarsh Pandit",
      "screen_name" : "adarshp",
      "protected" : false,
      "id_str" : "14436348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449407743766441984\/AfOGQ-jW_normal.jpeg",
      "id" : 14436348,
      "verified" : false
    }
  },
  "id" : 381603390427394048,
  "created_at" : "2013-09-22 02:18:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 52, 67 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Chargify",
      "screen_name" : "Chargify",
      "indices" : [ 76, 85 ],
      "id_str" : "51077652",
      "id" : 51077652
    }, {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "indices" : [ 90, 101 ],
      "id_str" : "7255652",
      "id" : 7255652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381565785824849920",
  "text" : "Afterparty at Electric Avenue (Ellicott\/Mohawk) for @nickelcityruby. Thanks @Chargify and @engineyard!",
  "id" : 381565785824849920,
  "created_at" : "2013-09-21 23:49:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "indices" : [ 67, 78 ],
      "id_str" : "7255652",
      "id" : 7255652
    }, {
      "name" : "Chargify",
      "screen_name" : "Chargify",
      "indices" : [ 81, 90 ],
      "id_str" : "51077652",
      "id" : 51077652
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381565304360673280",
  "text" : "RT @nickelcityruby: It's not over yet!! Everyone is welcome to the @engineyard \/ @chargify joint party at Electric Avenue (Ellicott and Moh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.handmark.com\" rel=\"nofollow\"\u003ETweetCaster for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Engine Yard",
        "screen_name" : "engineyard",
        "indices" : [ 47, 58 ],
        "id_str" : "7255652",
        "id" : 7255652
      }, {
        "name" : "Chargify",
        "screen_name" : "Chargify",
        "indices" : [ 61, 70 ],
        "id_str" : "51077652",
        "id" : 51077652
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381549634097020928",
    "text" : "It's not over yet!! Everyone is welcome to the @engineyard \/ @chargify joint party at Electric Avenue (Ellicott and Mohawk) #ncrc13",
    "id" : 381549634097020928,
    "created_at" : "2013-09-21 22:44:56 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 381565304360673280,
  "created_at" : "2013-09-21 23:47:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 32, 47 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381555066760888320",
  "text" : "Big thanks to everyone who made @nickelcityruby possible. Speakers, sponsors, volunteers, organizers, attendees: thank you.",
  "id" : 381555066760888320,
  "created_at" : "2013-09-21 23:06:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Lavena",
      "screen_name" : "luislavena",
      "indices" : [ 4, 15 ],
      "id_str" : "16891327",
      "id" : 16891327
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 31, 46 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381512371543371776",
  "text" : "Hey @luislavena ! \uD83D\uDC9C\uD83D\uDC99\uD83D\uDC9A\uD83D\uDC9B\u2764\uFE0F\uD83D\uDC96 from @nickelcityruby !",
  "id" : 381512371543371776,
  "created_at" : "2013-09-21 20:16:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 3, 11 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/xhwRjcb1Vz",
      "expanded_url" : "https:\/\/speakerdeck.com\/sikachu\/active-support-secrets",
      "display_url" : "speakerdeck.com\/sikachu\/active\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381509292643586048",
  "text" : "RT @sikachu: Here's the link to the slides of my \"Active Support Secrets\" lightning talk at #ncrc13! \u26A1\u26A1\u26A1 https:\/\/t.co\/xhwRjcb1Vz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 79, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/xhwRjcb1Vz",
        "expanded_url" : "https:\/\/speakerdeck.com\/sikachu\/active-support-secrets",
        "display_url" : "speakerdeck.com\/sikachu\/active\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381497355985747968",
    "text" : "Here's the link to the slides of my \"Active Support Secrets\" lightning talk at #ncrc13! \u26A1\u26A1\u26A1 https:\/\/t.co\/xhwRjcb1Vz",
    "id" : 381497355985747968,
    "created_at" : "2013-09-21 19:17:12 +0000",
    "user" : {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "protected" : false,
      "id_str" : "28819745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548464438928355328\/uUhXMR2__normal.png",
      "id" : 28819745,
      "verified" : false
    }
  },
  "id" : 381509292643586048,
  "created_at" : "2013-09-21 20:04:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Goulding",
      "screen_name" : "JakeGoulding",
      "indices" : [ 3, 16 ],
      "id_str" : "197769225",
      "id" : 197769225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/DK4pp7c55u",
      "expanded_url" : "https:\/\/github.com\/shepmaster\/rspec-search-and-destroy",
      "display_url" : "github.com\/shepmaster\/rsp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381509244228759552",
  "text" : "RT @JakeGoulding: Announcing RSpec Search-and-Destroy: automatically find test ordering bugs in RSpec. https:\/\/t.co\/DK4pp7c55u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/DK4pp7c55u",
        "expanded_url" : "https:\/\/github.com\/shepmaster\/rspec-search-and-destroy",
        "display_url" : "github.com\/shepmaster\/rsp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381502514526711808",
    "text" : "Announcing RSpec Search-and-Destroy: automatically find test ordering bugs in RSpec. https:\/\/t.co\/DK4pp7c55u",
    "id" : 381502514526711808,
    "created_at" : "2013-09-21 19:37:42 +0000",
    "user" : {
      "name" : "Jake Goulding",
      "screen_name" : "JakeGoulding",
      "protected" : false,
      "id_str" : "197769225",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1183552005\/Kirby_Standing_128x128_normal.png",
      "id" : 197769225,
      "verified" : false
    }
  },
  "id" : 381509244228759552,
  "created_at" : "2013-09-21 20:04:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neal Sales-Griffin",
      "screen_name" : "nealsales",
      "indices" : [ 3, 13 ],
      "id_str" : "13275012",
      "id" : 13275012
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 102, 117 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nealsales\/status\/381487187805487105\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/PUzbynoYZ1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUtQk3OCYAEx_Y0.jpg",
      "id_str" : "381487187671277569",
      "id" : 381487187671277569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUtQk3OCYAEx_Y0.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PUzbynoYZ1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381487415774683136",
  "text" : "RT @nealsales: This little girl is giving the most hilarious and compelling conference talk I've seen @nickelcityruby http:\/\/t.co\/PUzbynoYZ1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 87, 102 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nealsales\/status\/381487187805487105\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/PUzbynoYZ1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUtQk3OCYAEx_Y0.jpg",
        "id_str" : "381487187671277569",
        "id" : 381487187671277569,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUtQk3OCYAEx_Y0.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/PUzbynoYZ1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.8867531592, -78.8649827404 ]
    },
    "id_str" : "381487187805487105",
    "text" : "This little girl is giving the most hilarious and compelling conference talk I've seen @nickelcityruby http:\/\/t.co\/PUzbynoYZ1",
    "id" : 381487187805487105,
    "created_at" : "2013-09-21 18:36:47 +0000",
    "user" : {
      "name" : "Neal Sales-Griffin",
      "screen_name" : "nealsales",
      "protected" : false,
      "id_str" : "13275012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2567785887\/q71mw6rdkcpe8ygovbf2_normal.jpeg",
      "id" : 13275012,
      "verified" : false
    }
  },
  "id" : 381487415774683136,
  "created_at" : "2013-09-21 18:37:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bridget",
      "screen_name" : "dragonladyB17",
      "indices" : [ 3, 17 ],
      "id_str" : "158443907",
      "id" : 158443907
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/R8UXFCR49A",
      "expanded_url" : "http:\/\/tmblr.co\/Zjqyqxvd0EwQ",
      "display_url" : "tmblr.co\/Zjqyqxvd0EwQ"
    } ]
  },
  "geo" : { },
  "id_str" : "381468747363786752",
  "text" : "RT @dragonladyB17: Photo: At #ncrc13 Nickel City Ruby Conf\u2014 the morning\u2019s first speaker. (Pulled from D7100 with the wireless... http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 10, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/R8UXFCR49A",
        "expanded_url" : "http:\/\/tmblr.co\/Zjqyqxvd0EwQ",
        "display_url" : "tmblr.co\/Zjqyqxvd0EwQ"
      } ]
    },
    "geo" : { },
    "id_str" : "381445644365602816",
    "text" : "Photo: At #ncrc13 Nickel City Ruby Conf\u2014 the morning\u2019s first speaker. (Pulled from D7100 with the wireless... http:\/\/t.co\/R8UXFCR49A",
    "id" : 381445644365602816,
    "created_at" : "2013-09-21 15:51:43 +0000",
    "user" : {
      "name" : "Bridget",
      "screen_name" : "dragonladyB17",
      "protected" : false,
      "id_str" : "158443907",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1016733212\/Photo_245_normal.jpg",
      "id" : 158443907,
      "verified" : false
    }
  },
  "id" : 381468747363786752,
  "created_at" : "2013-09-21 17:23:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381468505834790912",
  "text" : "RT @nickelcityruby: Free jazz in the Library Auditorium for #ncrc13 folks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.handmark.com\" rel=\"nofollow\"\u003ETweetCaster for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 40, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381468362691596288",
    "text" : "Free jazz in the Library Auditorium for #ncrc13 folks",
    "id" : 381468362691596288,
    "created_at" : "2013-09-21 17:21:59 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 381468505834790912,
  "created_at" : "2013-09-21 17:22:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381453160109596672",
  "text" : "RT @nickelcityruby: OM NOM NOM lunch is extended until 2, please be back at the aud for then!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381453080581373952",
    "text" : "OM NOM NOM lunch is extended until 2, please be back at the aud for then!",
    "id" : 381453080581373952,
    "created_at" : "2013-09-21 16:21:16 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 381453160109596672,
  "created_at" : "2013-09-21 16:21:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0421\u0430\u0440\u044B\u0447\u0435\u0432a \u042D\u043B\u0435\u043E\u043D\u043E\u0440\u0430",
      "screen_name" : "elenawebstudio",
      "indices" : [ 3, 18 ],
      "id_str" : "2858399712",
      "id" : 2858399712
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 52, 67 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381441495926321152",
  "text" : "RT @elenawebstudio: Enjoying my first conference at @nickelcityruby today!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 32, 47 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381439969824624640",
    "text" : "Enjoying my first conference at @nickelcityruby today!",
    "id" : 381439969824624640,
    "created_at" : "2013-09-21 15:29:10 +0000",
    "user" : {
      "name" : "Lena Levine",
      "screen_name" : "lena_levine",
      "protected" : false,
      "id_str" : "439572110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1869909257\/ea228_normal.jpg",
      "id" : 439572110,
      "verified" : false
    }
  },
  "id" : 381441495926321152,
  "created_at" : "2013-09-21 15:35:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 3, 14 ],
      "id_str" : "12734002",
      "id" : 12734002
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 20, 35 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Dessa ",
      "screen_name" : "dessadarling",
      "indices" : [ 42, 55 ],
      "id_str" : "19850057",
      "id" : 19850057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381439466524528641",
  "text" : "RT @joanofdark: Hey @nickelcityruby folk, @dessadarling + crew had some computers stolen in Buffalo last night. BOLO!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 4, 19 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Dessa ",
        "screen_name" : "dessadarling",
        "indices" : [ 26, 39 ],
        "id_str" : "19850057",
        "id" : 19850057
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381438770295234562",
    "text" : "Hey @nickelcityruby folk, @dessadarling + crew had some computers stolen in Buffalo last night. BOLO!",
    "id" : 381438770295234562,
    "created_at" : "2013-09-21 15:24:24 +0000",
    "user" : {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "protected" : false,
      "id_str" : "12734002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/52337868\/76195_normal.jpeg",
      "id" : 12734002,
      "verified" : false
    }
  },
  "id" : 381439466524528641,
  "created_at" : "2013-09-21 15:27:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dessa ",
      "screen_name" : "dessadarling",
      "indices" : [ 0, 13 ],
      "id_str" : "19850057",
      "id" : 19850057
    }, {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 14, 25 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381308707789111296",
  "geo" : { },
  "id_str" : "381439446819696641",
  "in_reply_to_user_id" : 19850057,
  "text" : "@dessadarling @joanofdark I\u2019m sorry this happened\u2026our city and people are better than this",
  "id" : 381439446819696641,
  "in_reply_to_status_id" : 381308707789111296,
  "created_at" : "2013-09-21 15:27:05 +0000",
  "in_reply_to_screen_name" : "dessadarling",
  "in_reply_to_user_id_str" : "19850057",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    }, {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 9, 20 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381277470625771521",
  "geo" : { },
  "id_str" : "381435693211598848",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale @joshsusser this weekend is rough! ;)",
  "id" : 381435693211598848,
  "in_reply_to_status_id" : 381277470625771521,
  "created_at" : "2013-09-21 15:12:10 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Follow @CoralineAda",
      "screen_name" : "Bantik",
      "indices" : [ 78, 85 ],
      "id_str" : "2375715212",
      "id" : 2375715212
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381435539280650241",
  "text" : "RT @ashedryden: \u201CAsk not for whom the git blame rings, for it rings for you.\u201D @bantik #ncrc13",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Follow @CoralineAda",
        "screen_name" : "Bantik",
        "indices" : [ 62, 69 ],
        "id_str" : "2375715212",
        "id" : 2375715212
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 70, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381434764429099008",
    "text" : "\u201CAsk not for whom the git blame rings, for it rings for you.\u201D @bantik #ncrc13",
    "id" : 381434764429099008,
    "created_at" : "2013-09-21 15:08:29 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 381435539280650241,
  "created_at" : "2013-09-21 15:11:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 44, 56 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381420881685532672",
  "text" : "RT @nickelcityruby: Kicking things off with @sarajchipps and learning together #ncrc13",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.handmark.com\" rel=\"nofollow\"\u003ETweetCaster for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SaraJo",
        "screen_name" : "SaraJChipps",
        "indices" : [ 24, 36 ],
        "id_str" : "15524875",
        "id" : 15524875
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 59, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381419364014379008",
    "text" : "Kicking things off with @sarajchipps and learning together #ncrc13",
    "id" : 381419364014379008,
    "created_at" : "2013-09-21 14:07:17 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 381420881685532672,
  "created_at" : "2013-09-21 14:13:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 25, 40 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381402779002368000",
  "text" : "We are open for day 2 of @nickelcityruby! Wake up!!",
  "id" : 381402779002368000,
  "created_at" : "2013-09-21 13:01:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 0, 11 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381400724430548992",
  "geo" : { },
  "id_str" : "381402582377168897",
  "in_reply_to_user_id" : 38408851,
  "text" : "@Jonplussed you could take the bus.",
  "id" : 381402582377168897,
  "in_reply_to_status_id" : 381400724430548992,
  "created_at" : "2013-09-21 13:00:36 +0000",
  "in_reply_to_screen_name" : "Jonplussed",
  "in_reply_to_user_id_str" : "38408851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "Fuzz Leonard",
      "screen_name" : "fuzzleonard",
      "indices" : [ 85, 97 ],
      "id_str" : "351244138",
      "id" : 351244138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381386705267208196",
  "text" : "RT @zobar2: Buffalo buffalo Buffalo buffalo buffalo Buffalo buffalo buffalo. #ncrc13 @fuzzleonard",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fuzz Leonard",
        "screen_name" : "fuzzleonard",
        "indices" : [ 73, 85 ],
        "id_str" : "351244138",
        "id" : 351244138
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 65, 72 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "381166754271342592",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.95988469, -78.85062842 ]
    },
    "id_str" : "381378516253937664",
    "in_reply_to_user_id" : 351244138,
    "text" : "Buffalo buffalo Buffalo buffalo buffalo Buffalo buffalo buffalo. #ncrc13 @fuzzleonard",
    "id" : 381378516253937664,
    "in_reply_to_status_id" : 381166754271342592,
    "created_at" : "2013-09-21 11:24:58 +0000",
    "in_reply_to_screen_name" : "fuzzleonard",
    "in_reply_to_user_id_str" : "351244138",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 381386705267208196,
  "created_at" : "2013-09-21 11:57:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Wegmans Food Markets",
      "screen_name" : "Wegmans",
      "indices" : [ 117, 125 ],
      "id_str" : "66482863",
      "id" : 66482863
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381386448470937600",
  "text" : "RT @nickelcityruby: We're setting up for day 2 of #ncrc13! Today's breakfast is bagels, muffins, and croissants from @Wegmans!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wegmans Food Markets",
        "screen_name" : "Wegmans",
        "indices" : [ 97, 105 ],
        "id_str" : "66482863",
        "id" : 66482863
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 30, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381383468766486528",
    "text" : "We're setting up for day 2 of #ncrc13! Today's breakfast is bagels, muffins, and croissants from @Wegmans!",
    "id" : 381383468766486528,
    "created_at" : "2013-09-21 11:44:39 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 381386448470937600,
  "created_at" : "2013-09-21 11:56:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 11, 26 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381375127252119552",
  "text" : "Looks like @nickelcityruby broke the weather machine.",
  "id" : 381375127252119552,
  "created_at" : "2013-09-21 11:11:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 21, 36 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381233678309146624",
  "text" : "Insane first day for @nickelcityruby. Still having a hard time believing this is all happening in Buffalo. So happy it all worked out.",
  "id" : 381233678309146624,
  "created_at" : "2013-09-21 01:49:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mathiasx",
      "screen_name" : "mathiasx",
      "indices" : [ 0, 9 ],
      "id_str" : "787975",
      "id" : 787975
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 17, 31 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381212569395920896",
  "geo" : { },
  "id_str" : "381212821515931648",
  "in_reply_to_user_id" : 787975,
  "text" : "@mathiasx yes at @coworkbuffalo !",
  "id" : 381212821515931648,
  "in_reply_to_status_id" : 381212569395920896,
  "created_at" : "2013-09-21 00:26:33 +0000",
  "in_reply_to_screen_name" : "mathiasx",
  "in_reply_to_user_id_str" : "787975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 35, 42 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 117, 131 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381193029430046720",
  "text" : "RT @nickelcityruby: Don't forget!! @github drink up is at Century Grill near the corner of Pearl and Chippewa! Games @coworkbuffalo at Chip\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.handmark.com\" rel=\"nofollow\"\u003ETweetCaster for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GitHub",
        "screen_name" : "github",
        "indices" : [ 15, 22 ],
        "id_str" : "13334762",
        "id" : 13334762
      }, {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 97, 111 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381181778519928832",
    "text" : "Don't forget!! @github drink up is at Century Grill near the corner of Pearl and Chippewa! Games @coworkbuffalo at Chippewa and Delaware!!",
    "id" : 381181778519928832,
    "created_at" : "2013-09-20 22:23:12 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 381193029430046720,
  "created_at" : "2013-09-20 23:07:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Saunders",
      "screen_name" : "chris_saunders",
      "indices" : [ 0, 15 ],
      "id_str" : "19147270",
      "id" : 19147270
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 24, 38 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381172387078619136",
  "geo" : { },
  "id_str" : "381179590317973504",
  "in_reply_to_user_id" : 19147270,
  "text" : "@chris_saunders it's at @coworkbuffalo. 225 Delaware",
  "id" : 381179590317973504,
  "in_reply_to_status_id" : 381172387078619136,
  "created_at" : "2013-09-20 22:14:30 +0000",
  "in_reply_to_screen_name" : "chris_saunders",
  "in_reply_to_user_id_str" : "19147270",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 19, 33 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381179165514674177",
  "text" : "Game night tonight @coworkbuffalo \/Spot Coffee 7PM-?",
  "id" : 381179165514674177,
  "created_at" : "2013-09-20 22:12:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 3, 12 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 36, 46 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381159522158391296",
  "text" : "RT @mr_ndrsn: Hey #ncrc13, I've got @37signals and Basecamp stickers! Track me down and say \"hi\" to get one!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 22, 32 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 4, 11 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381152221641330689",
    "text" : "Hey #ncrc13, I've got @37signals and Basecamp stickers! Track me down and say \"hi\" to get one!",
    "id" : 381152221641330689,
    "created_at" : "2013-09-20 20:25:45 +0000",
    "user" : {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "protected" : false,
      "id_str" : "774032401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460857040542261248\/228nQ2PI_normal.jpeg",
      "id" : 774032401,
      "verified" : false
    }
  },
  "id" : 381159522158391296,
  "created_at" : "2013-09-20 20:54:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zzak\u3048\u30B6\u30C3\u30AF",
      "screen_name" : "_zzak",
      "indices" : [ 0, 6 ],
      "id_str" : "920539489",
      "id" : 920539489
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 7, 22 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381147769073065984",
  "geo" : { },
  "id_str" : "381149734159011840",
  "in_reply_to_user_id" : 920539489,
  "text" : "@_zzak @nickelcityruby tshirt!",
  "id" : 381149734159011840,
  "in_reply_to_status_id" : 381147769073065984,
  "created_at" : "2013-09-20 20:15:52 +0000",
  "in_reply_to_screen_name" : "_zzak",
  "in_reply_to_user_id_str" : "920539489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Pochron",
      "screen_name" : "garypochron",
      "indices" : [ 3, 15 ],
      "id_str" : "36580514",
      "id" : 36580514
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 30, 45 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381124571388461056",
  "text" : "RT @garypochron: If anyone at @nickelcityruby is a Mark Twain fan, there is an original manuscript exhibit room on the main floor of the li\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 13, 28 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381102624604717056",
    "text" : "If anyone at @nickelcityruby is a Mark Twain fan, there is an original manuscript exhibit room on the main floor of the library. #ncrc13",
    "id" : 381102624604717056,
    "created_at" : "2013-09-20 17:08:40 +0000",
    "user" : {
      "name" : "Gary Pochron",
      "screen_name" : "garypochron",
      "protected" : false,
      "id_str" : "36580514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2821294155\/ade795d65bee581aa36a565bd32bba42_normal.jpeg",
      "id" : 36580514,
      "verified" : false
    }
  },
  "id" : 381124571388461056,
  "created_at" : "2013-09-20 18:35:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 7, 22 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381123834071777280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8862587342, -78.8758830335 ]
  },
  "id_str" : "381124410788544512",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine @nickelcityruby working on it",
  "id" : 381124410788544512,
  "in_reply_to_status_id" : 381123834071777280,
  "created_at" : "2013-09-20 18:35:15 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 136, 144 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381123207333683200",
  "text" : "RT @ashedryden: \u201CIf it weren\u2019t for Apple\u2019s work to make the iPhone &amp; OS X accessible I wouldn\u2019t be standing here giving this talk.\u201D @Austin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Austin Seraphin",
        "screen_name" : "AustinSeraphin",
        "indices" : [ 120, 135 ],
        "id_str" : "16393800",
        "id" : 16393800
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 136, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381122208820895744",
    "text" : "\u201CIf it weren\u2019t for Apple\u2019s work to make the iPhone &amp; OS X accessible I wouldn\u2019t be standing here giving this talk.\u201D @AustinSeraphin #ncrc13",
    "id" : 381122208820895744,
    "created_at" : "2013-09-20 18:26:30 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 381123207333683200,
  "created_at" : "2013-09-20 18:30:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381102562490855425",
  "geo" : { },
  "id_str" : "381102825075642368",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej dude saw this. Super creepy",
  "id" : 381102825075642368,
  "in_reply_to_status_id" : 381102562490855425,
  "created_at" : "2013-09-20 17:09:28 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 3, 6 ],
      "id_str" : "1133971",
      "id" : 1133971
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 23, 38 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Speaker Corps",
      "screen_name" : "SpeakerCorps",
      "indices" : [ 91, 104 ],
      "id_str" : "1885188522",
      "id" : 1885188522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/8z99UmfQ29",
      "expanded_url" : "https:\/\/www.dropbox.com\/s\/w67gtbpb4tiqwdz\/just_be_fucking_awesome.pdf",
      "display_url" : "dropbox.com\/s\/w67gtbpb4tiq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381102608200790016",
  "text" : "RT @j3: My slides from @nickelcityruby \u201CJust Be Fucking Awesome\u201D including more info about @speakercorps: https:\/\/t.co\/8z99UmfQ29",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 15, 30 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Speaker Corps",
        "screen_name" : "SpeakerCorps",
        "indices" : [ 83, 96 ],
        "id_str" : "1885188522",
        "id" : 1885188522
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/8z99UmfQ29",
        "expanded_url" : "https:\/\/www.dropbox.com\/s\/w67gtbpb4tiqwdz\/just_be_fucking_awesome.pdf",
        "display_url" : "dropbox.com\/s\/w67gtbpb4tiq\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381086920547508224",
    "text" : "My slides from @nickelcityruby \u201CJust Be Fucking Awesome\u201D including more info about @speakercorps: https:\/\/t.co\/8z99UmfQ29",
    "id" : 381086920547508224,
    "created_at" : "2013-09-20 16:06:16 +0000",
    "user" : {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "protected" : false,
      "id_str" : "1133971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000543599975\/c63a58ff323b22a9e9ad52ffbbfb7f0a_normal.jpeg",
      "id" : 1133971,
      "verified" : false
    }
  },
  "id" : 381102608200790016,
  "created_at" : "2013-09-20 17:08:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381102469205721088",
  "text" : "RT @nickelcityruby: Hope you're enjoying lunch - remember talks start again at 1:30 :) #ncrc13",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.handmark.com\" rel=\"nofollow\"\u003ETweetCaster for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 67, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381097999281446912",
    "text" : "Hope you're enjoying lunch - remember talks start again at 1:30 :) #ncrc13",
    "id" : 381097999281446912,
    "created_at" : "2013-09-20 16:50:18 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 381102469205721088,
  "created_at" : "2013-09-20 17:08:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 5, 20 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381028732867448832",
  "text" : "It's @nickelcityruby day! Please come in the entrance on Clinton St!",
  "id" : 381028732867448832,
  "created_at" : "2013-09-20 12:15:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380890363310768128",
  "geo" : { },
  "id_str" : "380898618909020161",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald no problem man. :)",
  "id" : 380898618909020161,
  "in_reply_to_status_id" : 380890363310768128,
  "created_at" : "2013-09-20 03:38:02 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 15, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/7JNpdwS4p3",
      "expanded_url" : "http:\/\/lanyrd.com\/2013\/ncrc13",
      "display_url" : "lanyrd.com\/2013\/ncrc13"
    } ]
  },
  "geo" : { },
  "id_str" : "380894752897388544",
  "text" : "Our lanyrd for #ncrc13 is now setup! http:\/\/t.co\/7JNpdwS4p3",
  "id" : 380894752897388544,
  "created_at" : "2013-09-20 03:22:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380889793552330752",
  "geo" : { },
  "id_str" : "380889943305756672",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald :(",
  "id" : 380889943305756672,
  "in_reply_to_status_id" : 380889793552330752,
  "created_at" : "2013-09-20 03:03:33 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/t48mx4Fxme",
      "expanded_url" : "http:\/\/www.dukesbohemiangrovebar.com\/sites\/menu.html",
      "display_url" : "dukesbohemiangrovebar.com\/sites\/menu.html"
    } ]
  },
  "in_reply_to_status_id_str" : "380889702641188864",
  "geo" : { },
  "id_str" : "380889902230937600",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden haha nope. DBGB's will. http:\/\/t.co\/t48mx4Fxme",
  "id" : 380889902230937600,
  "in_reply_to_status_id" : 380889702641188864,
  "created_at" : "2013-09-20 03:03:23 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380889313841774592",
  "geo" : { },
  "id_str" : "380889478568484864",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden Order delivery from La Nova's. Get some BBQ wings too.",
  "id" : 380889478568484864,
  "in_reply_to_status_id" : 380889313841774592,
  "created_at" : "2013-09-20 03:01:42 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380884150825537536",
  "geo" : { },
  "id_str" : "380885693502742528",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden WOOOOOooooo.......",
  "id" : 380885693502742528,
  "in_reply_to_status_id" : 380884150825537536,
  "created_at" : "2013-09-20 02:46:40 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandrill",
      "screen_name" : "mandrillapp",
      "indices" : [ 14, 26 ],
      "id_str" : "540239057",
      "id" : 540239057
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380877065278328832",
  "text" : "Big thanks to @mandrillapp for treating our speakers to something special - and lots of tshirts for our attendees tomorrow! #ncrc13",
  "id" : 380877065278328832,
  "created_at" : "2013-09-20 02:12:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380876611316224000",
  "text" : "RT @nickelcityruby: The time is now!! We are ready to kick #ncrc13 into gear!! See y'all tomorrow!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.handmark.com\" rel=\"nofollow\"\u003ETweetCaster for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 39, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380875672329396225",
    "text" : "The time is now!! We are ready to kick #ncrc13 into gear!! See y'all tomorrow!!",
    "id" : 380875672329396225,
    "created_at" : "2013-09-20 02:06:51 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 380876611316224000,
  "created_at" : "2013-09-20 02:10:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 8, 15 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380849365298196480",
  "geo" : { },
  "id_str" : "380859216564858880",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw #ncrc13",
  "id" : 380859216564858880,
  "in_reply_to_status_id" : 380849365298196480,
  "created_at" : "2013-09-20 01:01:27 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 3, 10 ],
      "id_str" : "224887329",
      "id" : 224887329
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 16, 27 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Josh Steiner",
      "screen_name" : "josh_steiner",
      "indices" : [ 35, 48 ],
      "id_str" : "15841714",
      "id" : 15841714
    }, {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 50, 57 ],
      "id_str" : "6505422",
      "id" : 6505422
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 59, 67 ],
      "id_str" : "28819745",
      "id" : 28819745
    }, {
      "name" : "Melissa Xie",
      "screen_name" : "mxie",
      "indices" : [ 69, 74 ],
      "id_str" : "15522014",
      "id" : 15522014
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 94, 109 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380848615264366593",
  "text" : "RT @gabebw: The @thoughtbot crew ( @josh_steiner, @jyurek, @sikachu, @mxie) is in Buffalo for @nickelcityruby! #ncrc13",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "thoughtbot",
        "screen_name" : "thoughtbot",
        "indices" : [ 4, 15 ],
        "id_str" : "14114392",
        "id" : 14114392
      }, {
        "name" : "Josh Steiner",
        "screen_name" : "josh_steiner",
        "indices" : [ 23, 36 ],
        "id_str" : "15841714",
        "id" : 15841714
      }, {
        "name" : "Jon SJW Yurek",
        "screen_name" : "jyurek",
        "indices" : [ 38, 45 ],
        "id_str" : "6505422",
        "id" : 6505422
      }, {
        "name" : "Prem Sichanugrist",
        "screen_name" : "sikachu",
        "indices" : [ 47, 55 ],
        "id_str" : "28819745",
        "id" : 28819745
      }, {
        "name" : "Melissa Xie",
        "screen_name" : "mxie",
        "indices" : [ 57, 62 ],
        "id_str" : "15522014",
        "id" : 15522014
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 82, 97 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 99, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380817976486031361",
    "text" : "The @thoughtbot crew ( @josh_steiner, @jyurek, @sikachu, @mxie) is in Buffalo for @nickelcityruby! #ncrc13",
    "id" : 380817976486031361,
    "created_at" : "2013-09-19 22:17:35 +0000",
    "user" : {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "protected" : false,
      "id_str" : "224887329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522042513951977472\/vthKCPDr_normal.jpeg",
      "id" : 224887329,
      "verified" : false
    }
  },
  "id" : 380848615264366593,
  "created_at" : "2013-09-20 00:19:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Margaret (Serenity)",
      "screen_name" : "m_serenity",
      "indices" : [ 3, 14 ],
      "id_str" : "400531735",
      "id" : 400531735
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 52, 60 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 28, 36 ]
    }, {
      "text" : "Programmers",
      "indices" : [ 37, 49 ]
    }, {
      "text" : "nickelcityruby",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/1lRdQxhOcN",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "380848554191106048",
  "text" : "RT @m_serenity: For all the #Buffalo #Programmers - @wnyruby is having a conference. Tomorrow! You should go! http:\/\/t.co\/1lRdQxhOcN #nicke\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WNY Ruby",
        "screen_name" : "wnyruby",
        "indices" : [ 36, 44 ],
        "id_str" : "205886758",
        "id" : 205886758
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 12, 20 ]
      }, {
        "text" : "Programmers",
        "indices" : [ 21, 33 ]
      }, {
        "text" : "nickelcityruby",
        "indices" : [ 117, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/1lRdQxhOcN",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "380836558145716224",
    "text" : "For all the #Buffalo #Programmers - @wnyruby is having a conference. Tomorrow! You should go! http:\/\/t.co\/1lRdQxhOcN #nickelcityruby",
    "id" : 380836558145716224,
    "created_at" : "2013-09-19 23:31:25 +0000",
    "user" : {
      "name" : "Margaret (Serenity)",
      "screen_name" : "m_serenity",
      "protected" : false,
      "id_str" : "400531735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436244193808510976\/KU-r586M_normal.jpeg",
      "id" : 400531735,
      "verified" : false
    }
  },
  "id" : 380848554191106048,
  "created_at" : "2013-09-20 00:19:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u1D48\u02B3\u1D43\u1D4F\u1D4F\u02B0\u1D49\u207F",
      "screen_name" : "drakkhen",
      "indices" : [ 0, 9 ],
      "id_str" : "18176030",
      "id" : 18176030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380809256129544192",
  "geo" : { },
  "id_str" : "380809926626390017",
  "in_reply_to_user_id" : 18176030,
  "text" : "@drakkhen we're sharing wifi with the library, so yes...but we need to share nicely :)",
  "id" : 380809926626390017,
  "in_reply_to_status_id" : 380809256129544192,
  "created_at" : "2013-09-19 21:45:36 +0000",
  "in_reply_to_screen_name" : "drakkhen",
  "in_reply_to_user_id_str" : "18176030",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 14, 21 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380802356822024192",
  "geo" : { },
  "id_str" : "380802446257180672",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda #ncrc13",
  "id" : 380802446257180672,
  "in_reply_to_status_id" : 380802356822024192,
  "created_at" : "2013-09-19 21:15:52 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BackForty",
      "screen_name" : "InTheBackForty",
      "indices" : [ 3, 18 ],
      "id_str" : "557205761",
      "id" : 557205761
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 29, 44 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Flip Sasser",
      "screen_name" : "flipsasser",
      "indices" : [ 58, 69 ],
      "id_str" : "9144132",
      "id" : 9144132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380801801118691328",
  "text" : "RT @InTheBackForty: Going to @nickelcityruby? Say \u201CHi\u201D to @flipsasser and see his talk \u201CActually Invented Here\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 9, 24 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Flip Sasser",
        "screen_name" : "flipsasser",
        "indices" : [ 38, 49 ],
        "id_str" : "9144132",
        "id" : 9144132
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380793867718914048",
    "text" : "Going to @nickelcityruby? Say \u201CHi\u201D to @flipsasser and see his talk \u201CActually Invented Here\u201D",
    "id" : 380793867718914048,
    "created_at" : "2013-09-19 20:41:47 +0000",
    "user" : {
      "name" : "BackForty",
      "screen_name" : "InTheBackForty",
      "protected" : false,
      "id_str" : "557205761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3603802398\/ccd79f7be12a4039964a4e125275a0e1_normal.png",
      "id" : 557205761,
      "verified" : false
    }
  },
  "id" : 380801801118691328,
  "created_at" : "2013-09-19 21:13:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 3, 16 ],
      "id_str" : "14928483",
      "id" : 14928483
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 49, 64 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/lindseybieda\/status\/380801482804559872\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/5YK7cqBUy1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUjg7ljCAAAoiSB.jpg",
      "id_str" : "380801482808754176",
      "id" : 380801482808754176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUjg7ljCAAAoiSB.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/5YK7cqBUy1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380801752926150656",
  "text" : "RT @lindseybieda: Current Status: in Buffalo for @nickelcityruby http:\/\/t.co\/5YK7cqBUy1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 31, 46 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/lindseybieda\/status\/380801482804559872\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/5YK7cqBUy1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUjg7ljCAAAoiSB.jpg",
        "id_str" : "380801482808754176",
        "id" : 380801482808754176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUjg7ljCAAAoiSB.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/5YK7cqBUy1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380801482804559872",
    "text" : "Current Status: in Buffalo for @nickelcityruby http:\/\/t.co\/5YK7cqBUy1",
    "id" : 380801482804559872,
    "created_at" : "2013-09-19 21:12:03 +0000",
    "user" : {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "protected" : false,
      "id_str" : "14928483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569192760029089792\/zaGhTAHK_normal.jpeg",
      "id" : 14928483,
      "verified" : false
    }
  },
  "id" : 380801752926150656,
  "created_at" : "2013-09-19 21:13:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380785745209729024",
  "geo" : { },
  "id_str" : "380799030969659393",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn I only do illusions.",
  "id" : 380799030969659393,
  "in_reply_to_status_id" : 380785745209729024,
  "created_at" : "2013-09-19 21:02:18 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "5 Nights at Jamie's*",
      "screen_name" : "death2normalcy",
      "indices" : [ 0, 15 ],
      "id_str" : "129537034",
      "id" : 129537034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380786347297869824",
  "geo" : { },
  "id_str" : "380790784225583104",
  "in_reply_to_user_id" : 129537034,
  "text" : "@death2normalcy thanks!",
  "id" : 380790784225583104,
  "in_reply_to_status_id" : 380786347297869824,
  "created_at" : "2013-09-19 20:29:32 +0000",
  "in_reply_to_screen_name" : "death2normalcy",
  "in_reply_to_user_id_str" : "129537034",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 18, 33 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/380783796976492544\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/VgIyAZs0vQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUjQ2IuCIAA3cGJ.jpg",
      "id_str" : "380783796984881152",
      "id" : 380783796984881152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUjQ2IuCIAA3cGJ.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/VgIyAZs0vQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380783796976492544",
  "text" : "All set to go for @nickelcityruby! It's the FINAL COUNTDOWN http:\/\/t.co\/VgIyAZs0vQ",
  "id" : 380783796976492544,
  "created_at" : "2013-09-19 20:01:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/TF9eGeUZjL",
      "expanded_url" : "https:\/\/37signals.com\/svn\/posts\/3626-design-decisions-basecamp-for-iphone-ios-7",
      "display_url" : "37signals.com\/svn\/posts\/3626\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380743537199181824",
  "text" : "A look into design on iOS7 for Basecamp: https:\/\/t.co\/TF9eGeUZjL",
  "id" : 380743537199181824,
  "created_at" : "2013-09-19 17:21:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 11, 26 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Artvoice",
      "screen_name" : "artvoice",
      "indices" : [ 33, 42 ],
      "id_str" : "14334727",
      "id" : 14334727
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/380742562534793217\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/zm17iQxujn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUirV-dCIAAOSia.jpg",
      "id_str" : "380742562543181824",
      "id" : 380742562543181824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUirV-dCIAAOSia.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/zm17iQxujn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380742562534793217",
  "text" : "Looks like @nickelcityruby is in @Artvoice too! http:\/\/t.co\/zm17iQxujn",
  "id" : 380742562534793217,
  "created_at" : "2013-09-19 17:17:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NextPlex \/ Buffalo",
      "screen_name" : "nplexBUF",
      "indices" : [ 3, 12 ],
      "id_str" : "1154760426",
      "id" : 1154760426
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 19, 34 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buffalo",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/USlrLhiCbI",
      "expanded_url" : "http:\/\/bit.ly\/1aND0ZH",
      "display_url" : "bit.ly\/1aND0ZH"
    } ]
  },
  "geo" : { },
  "id_str" : "380728210930946048",
  "text" : "RT @nplexBUF: Join @nickelcityruby for NickelCityRuby 2013 tomorrow at 9:00am http:\/\/t.co\/USlrLhiCbI #buffalo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/nextplex.com\/buffalo-ny\" rel=\"nofollow\"\u003ENextPlex\/Buffalo AutoTweeter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 5, 20 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "buffalo",
        "indices" : [ 87, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/USlrLhiCbI",
        "expanded_url" : "http:\/\/bit.ly\/1aND0ZH",
        "display_url" : "bit.ly\/1aND0ZH"
      } ]
    },
    "geo" : { },
    "id_str" : "380692770622820352",
    "text" : "Join @nickelcityruby for NickelCityRuby 2013 tomorrow at 9:00am http:\/\/t.co\/USlrLhiCbI #buffalo",
    "id" : 380692770622820352,
    "created_at" : "2013-09-19 14:00:04 +0000",
    "user" : {
      "name" : "NextPlex \/ Buffalo",
      "screen_name" : "nplexBUF",
      "protected" : false,
      "id_str" : "1154760426",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3243931947\/a9e97ad47794fdc51543b1f4b5578419_normal.png",
      "id" : 1154760426,
      "verified" : false
    }
  },
  "id" : 380728210930946048,
  "created_at" : "2013-09-19 16:20:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dessy",
      "screen_name" : "dess_e",
      "indices" : [ 3, 10 ],
      "id_str" : "107498881",
      "id" : 107498881
    }, {
      "name" : "\u0417\u043E\u0442\u0438\u043A\u043E\u0432 \u041B\u0435\u043E\u043D\u0438\u0434",
      "screen_name" : "GreengageMobile",
      "indices" : [ 16, 32 ],
      "id_str" : "2668711400",
      "id" : 2668711400
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 69, 84 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380728201661534209",
  "text" : "RT @dess_e: The @GreengageMobile tech team is off on an adventure to @nickelcityruby. We're excited to meet the developers attending!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0417\u043E\u0442\u0438\u043A\u043E\u0432 \u041B\u0435\u043E\u043D\u0438\u0434",
        "screen_name" : "GreengageMobile",
        "indices" : [ 4, 20 ],
        "id_str" : "2668711400",
        "id" : 2668711400
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 57, 72 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380699328399937537",
    "text" : "The @GreengageMobile tech team is off on an adventure to @nickelcityruby. We're excited to meet the developers attending!",
    "id" : 380699328399937537,
    "created_at" : "2013-09-19 14:26:07 +0000",
    "user" : {
      "name" : "Dessy",
      "screen_name" : "dess_e",
      "protected" : false,
      "id_str" : "107498881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555953614351372288\/4Bv_nd9y_normal.jpeg",
      "id" : 107498881,
      "verified" : false
    }
  },
  "id" : 380728201661534209,
  "created_at" : "2013-09-19 16:20:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chargify",
      "screen_name" : "Chargify",
      "indices" : [ 3, 12 ],
      "id_str" : "51077652",
      "id" : 51077652
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NickelCityRuby",
      "indices" : [ 36, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 128, 144 ],
      "url" : "http:\/\/t.co\/Htq8Ms9y4g",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "380728140374351873",
  "text" : "RT @Chargify: We're helping sponsor #NickelCityRuby tomorrow &amp; Saturday in Buffalo, NY. Wish we could be there. Looks good! http:\/\/t.co\/Htq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NickelCityRuby",
        "indices" : [ 22, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Htq8Ms9y4g",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "380726494261026817",
    "text" : "We're helping sponsor #NickelCityRuby tomorrow &amp; Saturday in Buffalo, NY. Wish we could be there. Looks good! http:\/\/t.co\/Htq8Ms9y4g",
    "id" : 380726494261026817,
    "created_at" : "2013-09-19 16:14:04 +0000",
    "user" : {
      "name" : "Chargify",
      "screen_name" : "Chargify",
      "protected" : false,
      "id_str" : "51077652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545937932096266240\/f0P49l4t_normal.png",
      "id" : 51077652,
      "verified" : false
    }
  },
  "id" : 380728140374351873,
  "created_at" : "2013-09-19 16:20:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Campbell",
      "screen_name" : "paulca",
      "indices" : [ 0, 7 ],
      "id_str" : "815973",
      "id" : 815973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380721212999344128",
  "geo" : { },
  "id_str" : "380723030646743040",
  "in_reply_to_user_id" : 815973,
  "text" : "@paulca Thanks!",
  "id" : 380723030646743040,
  "in_reply_to_status_id" : 380721212999344128,
  "created_at" : "2013-09-19 16:00:18 +0000",
  "in_reply_to_screen_name" : "paulca",
  "in_reply_to_user_id_str" : "815973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tito",
      "screen_name" : "useTito",
      "indices" : [ 4, 12 ],
      "id_str" : "741445453",
      "id" : 741445453
    }, {
      "name" : "Paul Campbell",
      "screen_name" : "paulca",
      "indices" : [ 13, 20 ],
      "id_str" : "815973",
      "id" : 815973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380720478546960384",
  "text" : "Hey @useTito @paulca I had a quick question about a certain alpha feature...have a minute to check it out?",
  "id" : 380720478546960384,
  "created_at" : "2013-09-19 15:50:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank K",
      "screen_name" : "fkumro",
      "indices" : [ 0, 7 ],
      "id_str" : "14883887",
      "id" : 14883887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380708311206604801",
  "geo" : { },
  "id_str" : "380713122501128193",
  "in_reply_to_user_id" : 14883887,
  "text" : "@fkumro there's several ramps on Washington, and a few lots on Pearl\/Franklin. They all range from $7-10 a day or so.",
  "id" : 380713122501128193,
  "in_reply_to_status_id" : 380708311206604801,
  "created_at" : "2013-09-19 15:20:56 +0000",
  "in_reply_to_screen_name" : "fkumro",
  "in_reply_to_user_id_str" : "14883887",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jira Dreams of Sushi",
      "screen_name" : "t_crayford",
      "indices" : [ 0, 11 ],
      "id_str" : "14408908",
      "id" : 14408908
    }, {
      "name" : "rubynerd",
      "screen_name" : "rubynerd",
      "indices" : [ 12, 21 ],
      "id_str" : "207100150",
      "id" : 207100150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380711359438413825",
  "geo" : { },
  "id_str" : "380711538698379265",
  "in_reply_to_user_id" : 14408908,
  "text" : "@t_crayford @rubynerd had a feeling. super frustrating :(",
  "id" : 380711538698379265,
  "in_reply_to_status_id" : 380711359438413825,
  "created_at" : "2013-09-19 15:14:38 +0000",
  "in_reply_to_screen_name" : "t_crayford",
  "in_reply_to_user_id_str" : "14408908",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubynerd",
      "screen_name" : "rubynerd",
      "indices" : [ 0, 9 ],
      "id_str" : "207100150",
      "id" : 207100150
    }, {
      "name" : "Jira Dreams of Sushi",
      "screen_name" : "t_crayford",
      "indices" : [ 10, 21 ],
      "id_str" : "14408908",
      "id" : 14408908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380703581990846464",
  "geo" : { },
  "id_str" : "380709353122045952",
  "in_reply_to_user_id" : 207100150,
  "text" : "@rubynerd @t_crayford do you have 1.4.0 installed?",
  "id" : 380709353122045952,
  "in_reply_to_status_id" : 380703581990846464,
  "created_at" : "2013-09-19 15:05:57 +0000",
  "in_reply_to_screen_name" : "rubynerd",
  "in_reply_to_user_id_str" : "207100150",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucas",
      "screen_name" : "lucasefe",
      "indices" : [ 0, 9 ],
      "id_str" : "5022961",
      "id" : 5022961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380708626282733569",
  "geo" : { },
  "id_str" : "380709260935430145",
  "in_reply_to_user_id" : 5022961,
  "text" : "@lucasefe of course! Best bass player ever duh",
  "id" : 380709260935430145,
  "in_reply_to_status_id" : 380708626282733569,
  "created_at" : "2013-09-19 15:05:35 +0000",
  "in_reply_to_screen_name" : "lucasefe",
  "in_reply_to_user_id_str" : "5022961",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 29, 44 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/380685842592718848\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/73c1aqs9Bo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUh3wbLCcAAgQmK.jpg",
      "id_str" : "380685842324287488",
      "id" : 380685842324287488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUh3wbLCcAAgQmK.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/73c1aqs9Bo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380685842592718848",
  "text" : "Sadly, Geddy isn\u2019t attending @nickelcityruby. I think he counts as a mascot though. http:\/\/t.co\/73c1aqs9Bo",
  "id" : 380685842592718848,
  "created_at" : "2013-09-19 13:32:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380681670258880512",
  "geo" : { },
  "id_str" : "380683215897235456",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn might not go until later, some plans changed.",
  "id" : 380683215897235456,
  "in_reply_to_status_id" : 380681670258880512,
  "created_at" : "2013-09-19 13:22:06 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mathiasx",
      "screen_name" : "mathiasx",
      "indices" : [ 0, 9 ],
      "id_str" : "787975",
      "id" : 787975
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 10, 21 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380632939530170368",
  "geo" : { },
  "id_str" : "380668905980559360",
  "in_reply_to_user_id" : 787975,
  "text" : "@mathiasx @ashedryden woot!!",
  "id" : 380668905980559360,
  "in_reply_to_status_id" : 380632939530170368,
  "created_at" : "2013-09-19 12:25:14 +0000",
  "in_reply_to_screen_name" : "mathiasx",
  "in_reply_to_user_id_str" : "787975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    }, {
      "name" : "Patrick Muldoon",
      "screen_name" : "d00n",
      "indices" : [ 4, 9 ],
      "id_str" : "1385921",
      "id" : 1385921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380657396843950080",
  "geo" : { },
  "id_str" : "380665604224471040",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 @d00n not for the American side.",
  "id" : 380665604224471040,
  "in_reply_to_status_id" : 380657396843950080,
  "created_at" : "2013-09-19 12:12:07 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380649138745925632",
  "geo" : { },
  "id_str" : "380665487622811648",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn could wait until 2ish.",
  "id" : 380665487622811648,
  "in_reply_to_status_id" : 380649138745925632,
  "created_at" : "2013-09-19 12:11:39 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jex",
      "screen_name" : "jexmusa",
      "indices" : [ 0, 8 ],
      "id_str" : "186607581",
      "id" : 186607581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380555432088969216",
  "geo" : { },
  "id_str" : "380556149923127296",
  "in_reply_to_user_id" : 186607581,
  "text" : "@jexmusa known issue, sorry! can you try force quitting the app (slide up in the app switcher) and try again?",
  "id" : 380556149923127296,
  "in_reply_to_status_id" : 380555432088969216,
  "created_at" : "2013-09-19 04:57:11 +0000",
  "in_reply_to_screen_name" : "jexmusa",
  "in_reply_to_user_id_str" : "186607581",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 75, 90 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380552880169570304",
  "text" : "Considering a quick lunch trip to Niagara Falls tomorrow. Any folks in for @nickelcityruby up for it?",
  "id" : 380552880169570304,
  "created_at" : "2013-09-19 04:44:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380484326435348480",
  "geo" : { },
  "id_str" : "380485457366102016",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss i'll try. My main problem is that literally the entire window, context, grid changes on every crash...and I lose focus. Every. time.",
  "id" : 380485457366102016,
  "in_reply_to_status_id" : 380484326435348480,
  "created_at" : "2013-09-19 00:16:16 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380463330735177728",
  "geo" : { },
  "id_str" : "380484468818968576",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler woot! Highly suggest exploring Elmwood Village &amp; Allentown if you have some spare time :)",
  "id" : 380484468818968576,
  "in_reply_to_status_id" : 380463330735177728,
  "created_at" : "2013-09-19 00:12:21 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/HjDv9qFySl",
      "expanded_url" : "http:\/\/37svn.com\/3626",
      "display_url" : "37svn.com\/3626"
    } ]
  },
  "geo" : { },
  "id_str" : "380481563181322241",
  "text" : "Side-by-side iOS6 vs iOS7 design changes for Basecamp from @JZ: http:\/\/t.co\/HjDv9qFySl",
  "id" : 380481563181322241,
  "created_at" : "2013-09-19 00:00:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380477487945617408",
  "geo" : { },
  "id_str" : "380481071273353218",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss have a screenshot of your config? i tried but didn't work :(",
  "id" : 380481071273353218,
  "in_reply_to_status_id" : 380477487945617408,
  "created_at" : "2013-09-18 23:58:51 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/wwaNbPhXSB",
      "expanded_url" : "http:\/\/bit.ly\/18ae91R",
      "display_url" : "bit.ly\/18ae91R"
    } ]
  },
  "geo" : { },
  "id_str" : "380477291685761024",
  "text" : "RT @JZ: A short post about the details that mattered and surprises we encountered when updating Basecamp for iOS 7.\n\nhttp:\/\/t.co\/wwaNbPhXSB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/wwaNbPhXSB",
        "expanded_url" : "http:\/\/bit.ly\/18ae91R",
        "display_url" : "bit.ly\/18ae91R"
      } ]
    },
    "geo" : { },
    "id_str" : "380468221599432705",
    "text" : "A short post about the details that mattered and surprises we encountered when updating Basecamp for iOS 7.\n\nhttp:\/\/t.co\/wwaNbPhXSB",
    "id" : 380468221599432705,
    "created_at" : "2013-09-18 23:07:47 +0000",
    "user" : {
      "name" : "Jason Zimdars",
      "screen_name" : "jasonzimdars",
      "protected" : false,
      "id_str" : "896641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1849219872\/jz_monogram_blue_normal.png",
      "id" : 896641,
      "verified" : false
    }
  },
  "id" : 380477291685761024,
  "created_at" : "2013-09-18 23:43:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380449756926857217",
  "geo" : { },
  "id_str" : "380450383752986626",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz Any idea how?",
  "id" : 380450383752986626,
  "in_reply_to_status_id" : 380449756926857217,
  "created_at" : "2013-09-18 21:56:54 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380448435909840896",
  "text" : "Is there any way of keeping Xcode from jumping around after the simulator crashes? It opens up the navigator and jumps to main.m EVERY time.",
  "id" : 380448435909840896,
  "created_at" : "2013-09-18 21:49:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 3, 8 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/OjDo53Uh0m",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "380442077764390912",
  "text" : "RT @jhsu: Nickel City Ruby Conference this weekend, make sure to get your ticket! http:\/\/t.co\/OjDo53Uh0m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/OjDo53Uh0m",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "380441954544132096",
    "text" : "Nickel City Ruby Conference this weekend, make sure to get your ticket! http:\/\/t.co\/OjDo53Uh0m",
    "id" : 380441954544132096,
    "created_at" : "2013-09-18 21:23:24 +0000",
    "user" : {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "protected" : false,
      "id_str" : "33823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448859597818695680\/MySo8-P7_normal.jpeg",
      "id" : 33823,
      "verified" : false
    }
  },
  "id" : 380442077764390912,
  "created_at" : "2013-09-18 21:23:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michiel Sikkes",
      "screen_name" : "michiels",
      "indices" : [ 0, 9 ],
      "id_str" : "8731242",
      "id" : 8731242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380371345894551552",
  "geo" : { },
  "id_str" : "380419893276844032",
  "in_reply_to_user_id" : 8731242,
  "text" : "@michiels same! you should contribute something to help us figure that out. seems like it should be possible.",
  "id" : 380419893276844032,
  "in_reply_to_status_id" : 380371345894551552,
  "created_at" : "2013-09-18 19:55:45 +0000",
  "in_reply_to_screen_name" : "michiels",
  "in_reply_to_user_id_str" : "8731242",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Robertson",
      "screen_name" : "patricksroberts",
      "indices" : [ 0, 16 ],
      "id_str" : "46661605",
      "id" : 46661605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380416445194448896",
  "geo" : { },
  "id_str" : "380416515465424896",
  "in_reply_to_user_id" : 46661605,
  "text" : "@patricksroberts NOPE NOTHING TO DO AT ALL",
  "id" : 380416515465424896,
  "in_reply_to_status_id" : 380416445194448896,
  "created_at" : "2013-09-18 19:42:19 +0000",
  "in_reply_to_screen_name" : "patricksroberts",
  "in_reply_to_user_id_str" : "46661605",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/nd3e7hhSCp",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/basecamp-official-app\/id599139477?mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/basecam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380414968895524864",
  "text" : "Happy to say Basecamp for iPhone is ready for iOS7...just in time! https:\/\/t.co\/nd3e7hhSCp",
  "id" : 380414968895524864,
  "created_at" : "2013-09-18 19:36:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eunice Randall",
      "screen_name" : "RadioFreeEunice",
      "indices" : [ 0, 16 ],
      "id_str" : "1854856106",
      "id" : 1854856106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380394889739251713",
  "geo" : { },
  "id_str" : "380403058250760192",
  "in_reply_to_user_id" : 1854856106,
  "text" : "@RadioFreeEunice dang! going to be out of town?",
  "id" : 380403058250760192,
  "in_reply_to_status_id" : 380394889739251713,
  "created_at" : "2013-09-18 18:48:51 +0000",
  "in_reply_to_screen_name" : "RadioFreeEunice",
  "in_reply_to_user_id_str" : "1854856106",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 75, 89 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 119, 130 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380393962495696896",
  "text" : "@juliepagano we're also trying to get a board game night in motion as well @coworkbuffalo, but can't fit too many. \/cc @ashedryden",
  "id" : 380393962495696896,
  "created_at" : "2013-09-18 18:12:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380391448710885377",
  "text" : "@juliepagano I hope they make it! I have a feeling it will go late though.",
  "id" : 380391448710885377,
  "created_at" : "2013-09-18 18:02:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 11, 18 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/P7NNHCvU1g",
      "expanded_url" : "https:\/\/github.com\/blog\/1636-buffalo-ny-drinkup",
      "display_url" : "github.com\/blog\/1636-buff\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380390841073688576",
  "text" : "Looks like @github forgot to mention that closing time in Buffalo is 4am... https:\/\/t.co\/P7NNHCvU1g",
  "id" : 380390841073688576,
  "created_at" : "2013-09-18 18:00:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 3, 10 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/GELlGLDexu",
      "expanded_url" : "https:\/\/github.com\/blog\/1636-buffalo-ny-drinkup",
      "display_url" : "github.com\/blog\/1636-buff\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380389322983092224",
  "text" : "RT @github: Join us Friday for a drinkup in Buffalo, NY! https:\/\/t.co\/GELlGLDexu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/hubot.github.com\/\" rel=\"nofollow\"\u003EThe Danger Room\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/GELlGLDexu",
        "expanded_url" : "https:\/\/github.com\/blog\/1636-buffalo-ny-drinkup",
        "display_url" : "github.com\/blog\/1636-buff\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "380389275415883776",
    "text" : "Join us Friday for a drinkup in Buffalo, NY! https:\/\/t.co\/GELlGLDexu",
    "id" : 380389275415883776,
    "created_at" : "2013-09-18 17:54:05 +0000",
    "user" : {
      "name" : "GitHub",
      "screen_name" : "github",
      "protected" : false,
      "id_str" : "13334762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426158315781881856\/sBsvBbjY_normal.png",
      "id" : 13334762,
      "verified" : true
    }
  },
  "id" : 380389322983092224,
  "created_at" : "2013-09-18 17:54:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iosreviewtime",
      "indices" : [ 10, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380388804474859520",
  "text" : "2 days of #iosreviewtime. WOOT!",
  "id" : 380388804474859520,
  "created_at" : "2013-09-18 17:52:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Callaway",
      "screen_name" : "decalresponds",
      "indices" : [ 0, 14 ],
      "id_str" : "566231363",
      "id" : 566231363
    }, {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 20, 30 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380356934362091521",
  "geo" : { },
  "id_str" : "380360213770948608",
  "in_reply_to_user_id" : 566231363,
  "text" : "@decalresponds yes, @confreaks will be recording!",
  "id" : 380360213770948608,
  "in_reply_to_status_id" : 380356934362091521,
  "created_at" : "2013-09-18 15:58:36 +0000",
  "in_reply_to_screen_name" : "decalresponds",
  "in_reply_to_user_id_str" : "566231363",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0410\u043D\u0434\u0440\u0438\u0439\u0447\u0443\u043A \u0412\u0430\u0441\u0438\u043B\u0438\u0439",
      "screen_name" : "brickattack",
      "indices" : [ 3, 15 ],
      "id_str" : "2833581694",
      "id" : 2833581694
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 65, 80 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Brian Corrigan",
      "screen_name" : "madgloryint",
      "indices" : [ 98, 110 ],
      "id_str" : "2169360690",
      "id" : 2169360690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380360178194866176",
  "text" : "RT @brickattack: Looking forward to a short break and heading to @nickelcityruby with some of the @madgloryint crew. Hope to meet a bunch o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\/mac\" rel=\"nofollow\"\u003EOsfoora for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 48, 63 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Brian Corrigan",
        "screen_name" : "madgloryint",
        "indices" : [ 81, 93 ],
        "id_str" : "2169360690",
        "id" : 2169360690
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380357694768807936",
    "text" : "Looking forward to a short break and heading to @nickelcityruby with some of the @madgloryint crew. Hope to meet a bunch of cool folks!",
    "id" : 380357694768807936,
    "created_at" : "2013-09-18 15:48:35 +0000",
    "user" : {
      "name" : "Erik Straub",
      "screen_name" : "brkattk",
      "protected" : false,
      "id_str" : "14789935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484774254479941632\/vyADZwQ3_normal.jpeg",
      "id" : 14789935,
      "verified" : false
    }
  },
  "id" : 380360178194866176,
  "created_at" : "2013-09-18 15:58:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/aFjRz7CZm7",
      "expanded_url" : "http:\/\/mrwgifs.com\/wp-content\/uploads\/2013\/03\/Ninja-Turtle-Michelangelo-Way-Too-Excited-Gif.gif",
      "display_url" : "mrwgifs.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380356111594831872",
  "text" : "\"The status for the following app has changed to In Review.\" http:\/\/t.co\/aFjRz7CZm7",
  "id" : 380356111594831872,
  "created_at" : "2013-09-18 15:42:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 14, 26 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 123, 133 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380349607726706688",
  "geo" : { },
  "id_str" : "380354737343700992",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda @juliepagano thanks. hoping it goes well. been losing sleep for a while on it (not as good as an excuse that @aquaranto has)",
  "id" : 380354737343700992,
  "in_reply_to_status_id" : 380349607726706688,
  "created_at" : "2013-09-18 15:36:50 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Vormwald",
      "screen_name" : "vormwald",
      "indices" : [ 3, 12 ],
      "id_str" : "215800334",
      "id" : 215800334
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 50, 65 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc2013",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380354590656327680",
  "text" : "RT @Vormwald: Anybody else from Syracuse going to @nickelcityruby this week? #ncrc2013",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 36, 51 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc2013",
        "indices" : [ 63, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380346150613942272",
    "text" : "Anybody else from Syracuse going to @nickelcityruby this week? #ncrc2013",
    "id" : 380346150613942272,
    "created_at" : "2013-09-18 15:02:43 +0000",
    "user" : {
      "name" : "Mike Vormwald",
      "screen_name" : "vormwald",
      "protected" : false,
      "id_str" : "215800334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501942122531266560\/Z2mGzuuN_normal.jpeg",
      "id" : 215800334,
      "verified" : false
    }
  },
  "id" : 380354590656327680,
  "created_at" : "2013-09-18 15:36:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/n0O6fSpx2h",
      "expanded_url" : "http:\/\/www.youtube.com\/user\/notmkdev0",
      "display_url" : "youtube.com\/user\/notmkdev0"
    } ]
  },
  "in_reply_to_status_id_str" : "380351047346454528",
  "geo" : { },
  "id_str" : "380351877306531841",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik *cough* http:\/\/t.co\/n0O6fSpx2h",
  "id" : 380351877306531841,
  "in_reply_to_status_id" : 380351047346454528,
  "created_at" : "2013-09-18 15:25:28 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robby Russell ",
      "screen_name" : "robbyrussell",
      "indices" : [ 0, 13 ],
      "id_str" : "54793",
      "id" : 54793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380336449213587457",
  "geo" : { },
  "id_str" : "380336578167459840",
  "in_reply_to_user_id" : 54793,
  "text" : "@robbyrussell Stickermule.",
  "id" : 380336578167459840,
  "in_reply_to_status_id" : 380336449213587457,
  "created_at" : "2013-09-18 14:24:41 +0000",
  "in_reply_to_screen_name" : "robbyrussell",
  "in_reply_to_user_id_str" : "54793",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppSignal",
      "screen_name" : "AppSignal",
      "indices" : [ 48, 58 ],
      "id_str" : "852306672",
      "id" : 852306672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380333333080596481",
  "text" : "Stroopwafels + Coffee = CRAZY DELICIOUS (thanks @appsignal!)",
  "id" : 380333333080596481,
  "created_at" : "2013-09-18 14:11:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 10, 25 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Tito",
      "screen_name" : "useTito",
      "indices" : [ 33, 41 ],
      "id_str" : "741445453",
      "id" : 741445453
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/380328970228486144\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/Yh4ujGsGUQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUczLvDCUAAitmi.png",
      "id_str" : "380328970236874752",
      "id" : 380328970236874752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUczLvDCUAAitmi.png",
      "sizes" : [ {
        "h" : 131,
        "resize" : "fit",
        "w" : 135
      }, {
        "h" : 131,
        "resize" : "crop",
        "w" : 135
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 135
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 135
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 135
      } ],
      "display_url" : "pic.twitter.com\/Yh4ujGsGUQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380328970228486144",
  "text" : "2 days to @nickelcityruby! (Btw, @useTito is awesome) http:\/\/t.co\/Yh4ujGsGUQ",
  "id" : 380328970228486144,
  "created_at" : "2013-09-18 13:54:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/HTp3eudXbK",
      "expanded_url" : "https:\/\/vine.co\/v\/hvZeLIbdePi",
      "display_url" : "vine.co\/v\/hvZeLIbdePi"
    } ]
  },
  "geo" : { },
  "id_str" : "380302821591351296",
  "text" : "Nicolas Cage in Cold Places  https:\/\/t.co\/HTp3eudXbK",
  "id" : 380302821591351296,
  "created_at" : "2013-09-18 12:10:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Barnard",
      "screen_name" : "drbarnard",
      "indices" : [ 3, 13 ],
      "id_str" : "7826502",
      "id" : 7826502
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/drbarnard\/status\/380192905186394112\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/rRgJM2a9HJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUa3bsxCIAAajfz.jpg",
      "id_str" : "380192905060556800",
      "id" : 380192905060556800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUa3bsxCIAAajfz.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 122,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/rRgJM2a9HJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380196424173887488",
  "text" : "RT @drbarnard: \u201CiPad support, it\u2019s like 20 lines of code if you know what you are doing.\u201D http:\/\/t.co\/rRgJM2a9HJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/drbarnard\/status\/380192905186394112\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/rRgJM2a9HJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUa3bsxCIAAajfz.jpg",
        "id_str" : "380192905060556800",
        "id" : 380192905060556800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUa3bsxCIAAajfz.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 122,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/rRgJM2a9HJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380192905186394112",
    "text" : "\u201CiPad support, it\u2019s like 20 lines of code if you know what you are doing.\u201D http:\/\/t.co\/rRgJM2a9HJ",
    "id" : 380192905186394112,
    "created_at" : "2013-09-18 04:53:46 +0000",
    "user" : {
      "name" : "David Barnard",
      "screen_name" : "drbarnard",
      "protected" : false,
      "id_str" : "7826502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560526767643848704\/v2uGiog2_normal.jpeg",
      "id" : 7826502,
      "verified" : false
    }
  },
  "id" : 380196424173887488,
  "created_at" : "2013-09-18 05:07:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/aiObCRiP39",
      "expanded_url" : "https:\/\/github.com\/toolmantim\/bananajour",
      "display_url" : "github.com\/toolmantim\/ban\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "380192047141253120",
  "geo" : { },
  "id_str" : "380192920491405313",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda or...bonjour gif discovery. Git is close to gif right?  https:\/\/t.co\/aiObCRiP39",
  "id" : 380192920491405313,
  "in_reply_to_status_id" : 380192047141253120,
  "created_at" : "2013-09-18 04:53:50 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 65, 79 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380191404750045184",
  "geo" : { },
  "id_str" : "380191751522107392",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda we have many artisanal flash drives in a mason jar @coworkbuffalo. this can happen.",
  "id" : 380191751522107392,
  "in_reply_to_status_id" : 380191404750045184,
  "created_at" : "2013-09-18 04:49:11 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380190889538101248",
  "geo" : { },
  "id_str" : "380191323732471809",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda kind of want to run a gif sneakernet exchange during this to restore my collection.",
  "id" : 380191323732471809,
  "in_reply_to_status_id" : 380190889538101248,
  "created_at" : "2013-09-18 04:47:29 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 67, 73 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380145958022959105",
  "geo" : { },
  "id_str" : "380191170405490688",
  "in_reply_to_user_id" : 52102614,
  "text" : "@matheuspontome I have no time to maintain another site, sorry. :( @parkr was talking about making a Discourse to talk about similiar issues",
  "id" : 380191170405490688,
  "in_reply_to_status_id" : 380145958022959105,
  "created_at" : "2013-09-18 04:46:53 +0000",
  "in_reply_to_screen_name" : "matheusgodoycom",
  "in_reply_to_user_id_str" : "52102614",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 36, 51 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380190241388130304",
  "text" : "Wrapped up sponsor\/break slides for @nickelcityruby. Sorry, no GIFs.",
  "id" : 380190241388130304,
  "created_at" : "2013-09-18 04:43:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "indices" : [ 3, 15 ],
      "id_str" : "66666549",
      "id" : 66666549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380152428902903809",
  "text" : "RT @TweetsofOld: Beware of the many useless attachments to your telephone which are offered for sale. They cost you money and degrade your \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380152005961859073",
    "text" : "Beware of the many useless attachments to your telephone which are offered for sale. They cost you money and degrade your service. NY1915",
    "id" : 380152005961859073,
    "created_at" : "2013-09-18 02:11:15 +0000",
    "user" : {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "protected" : false,
      "id_str" : "66666549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488101282473721856\/ddsWSyyl_normal.jpeg",
      "id" : 66666549,
      "verified" : false
    }
  },
  "id" : 380152428902903809,
  "created_at" : "2013-09-18 02:12:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 11, 22 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380149082582302720",
  "geo" : { },
  "id_str" : "380151064776830976",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef @kevinpurdy Stop Going to Timmy's Ho's, Just F*ing Stop Already",
  "id" : 380151064776830976,
  "in_reply_to_status_id" : 380149082582302720,
  "created_at" : "2013-09-18 02:07:31 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 17, 32 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "BuffaloBeerWeek",
      "screen_name" : "BFLOBeerWeek",
      "indices" : [ 34, 47 ],
      "id_str" : "825188720",
      "id" : 825188720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/uwfo5fd7kK",
      "expanded_url" : "http:\/\/www.buffalobeerweek.com\/",
      "display_url" : "buffalobeerweek.com"
    } ]
  },
  "geo" : { },
  "id_str" : "380119229258665984",
  "text" : "Just in time for @nickelcityruby: @bflobeerweek! http:\/\/t.co\/uwfo5fd7kK",
  "id" : 380119229258665984,
  "created_at" : "2013-09-18 00:01:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 36, 51 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Untappd",
      "screen_name" : "untappd",
      "indices" : [ 61, 69 ],
      "id_str" : "147845476",
      "id" : 147845476
    }, {
      "name" : "BuffaloBeerWeek",
      "screen_name" : "BFLOBeerWeek",
      "indices" : [ 90, 103 ],
      "id_str" : "825188720",
      "id" : 825188720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380114457692606464",
  "text" : "RT @aspleenic: Coincidence that its @nickelcityruby time? RT @untappd: Buffalo Beer Week (@bflobeerweek) kicks off this Fri &amp; there's a new\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 21, 36 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Untappd",
        "screen_name" : "untappd",
        "indices" : [ 46, 54 ],
        "id_str" : "147845476",
        "id" : 147845476
      }, {
        "name" : "BuffaloBeerWeek",
        "screen_name" : "BFLOBeerWeek",
        "indices" : [ 75, 88 ],
        "id_str" : "825188720",
        "id" : 825188720
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "380071373227311105",
    "geo" : { },
    "id_str" : "380081452659900416",
    "in_reply_to_user_id" : 147845476,
    "text" : "Coincidence that its @nickelcityruby time? RT @untappd: Buffalo Beer Week (@bflobeerweek) kicks off this Fri &amp; there's a new badge for you",
    "id" : 380081452659900416,
    "in_reply_to_status_id" : 380071373227311105,
    "created_at" : "2013-09-17 21:30:54 +0000",
    "in_reply_to_screen_name" : "untappd",
    "in_reply_to_user_id_str" : "147845476",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 380114457692606464,
  "created_at" : "2013-09-17 23:42:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 3, 9 ],
      "id_str" : "744613",
      "id" : 744613
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 66, 81 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380114402755620864",
  "text" : "RT @chorn: I have registered for the code retreat on Sunday after @nickelcityruby. I am ready to be terrible!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 55, 70 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380106704177741824",
    "text" : "I have registered for the code retreat on Sunday after @nickelcityruby. I am ready to be terrible!",
    "id" : 380106704177741824,
    "created_at" : "2013-09-17 23:11:14 +0000",
    "user" : {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "protected" : false,
      "id_str" : "744613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2310147637\/niixqq7ibisfwaat2xmg_normal.png",
      "id" : 744613,
      "verified" : false
    }
  },
  "id" : 380114402755620864,
  "created_at" : "2013-09-17 23:41:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380080258193428480",
  "geo" : { },
  "id_str" : "380088145456295936",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow (if this is for iOS7)",
  "id" : 380088145456295936,
  "in_reply_to_status_id" : 380080258193428480,
  "created_at" : "2013-09-17 21:57:30 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380080258193428480",
  "geo" : { },
  "id_str" : "380088076761972737",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow Sounds like you'll be in line behind me. Good luck. Also, don't try to request an expedite...we got turned down.",
  "id" : 380088076761972737,
  "in_reply_to_status_id" : 380080258193428480,
  "created_at" : "2013-09-17 21:57:13 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380081462562680832",
  "geo" : { },
  "id_str" : "380087776764387328",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz yeah, i still feel there's some failed expectations here though. The IB sucks at actually Building the Interface.",
  "id" : 380087776764387328,
  "in_reply_to_status_id" : 380081462562680832,
  "created_at" : "2013-09-17 21:56:02 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380079941133418496",
  "geo" : { },
  "id_str" : "380080344432508928",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz right, but that seems to miss the point of separating design\/code, doesn't it? it's like we had to use style attributes everywhere.",
  "id" : 380080344432508928,
  "in_reply_to_status_id" : 380079941133418496,
  "created_at" : "2013-09-17 21:26:30 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380079184904605696",
  "geo" : { },
  "id_str" : "380079581522186240",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz same question: how do you handle customization of controls? seems like it's impossible without writing code. can't keep it all in IB.",
  "id" : 380079581522186240,
  "in_reply_to_status_id" : 380079184904605696,
  "created_at" : "2013-09-17 21:23:28 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380076291137220608",
  "geo" : { },
  "id_str" : "380076581076496384",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow welcome to the club!!",
  "id" : 380076581076496384,
  "in_reply_to_status_id" : 380076291137220608,
  "created_at" : "2013-09-17 21:11:33 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arnold",
      "screen_name" : "tonyarnold",
      "indices" : [ 0, 11 ],
      "id_str" : "640903",
      "id" : 640903
    }, {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 12, 19 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380071744364486657",
  "geo" : { },
  "id_str" : "380072237870510080",
  "in_reply_to_user_id" : 640903,
  "text" : "@tonyarnold @soffes cool. how do you handle customization of controls? do you still have code that styles views?",
  "id" : 380072237870510080,
  "in_reply_to_status_id" : 380071744364486657,
  "created_at" : "2013-09-17 20:54:17 +0000",
  "in_reply_to_screen_name" : "tonyarnold",
  "in_reply_to_user_id_str" : "640903",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 0, 8 ],
      "id_str" : "77673",
      "id" : 77673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380069737641701376",
  "geo" : { },
  "id_str" : "380070163325808640",
  "in_reply_to_user_id" : 77673,
  "text" : "@jwright Nice!",
  "id" : 380070163325808640,
  "in_reply_to_status_id" : 380069737641701376,
  "created_at" : "2013-09-17 20:46:02 +0000",
  "in_reply_to_screen_name" : "jwright",
  "in_reply_to_user_id_str" : "77673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chase Clemons",
      "screen_name" : "chaseclemons",
      "indices" : [ 0, 13 ],
      "id_str" : "16159121",
      "id" : 16159121
    }, {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 14, 24 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380068253600845824",
  "geo" : { },
  "id_str" : "380068314958934016",
  "in_reply_to_user_id" : 16159121,
  "text" : "@chaseclemons @asianmack \/play horror",
  "id" : 380068314958934016,
  "in_reply_to_status_id" : 380068253600845824,
  "created_at" : "2013-09-17 20:38:42 +0000",
  "in_reply_to_screen_name" : "chaseclemons",
  "in_reply_to_user_id_str" : "16159121",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380067492192063488",
  "geo" : { },
  "id_str" : "380067924892860416",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss Ouch. :(",
  "id" : 380067924892860416,
  "in_reply_to_status_id" : 380067492192063488,
  "created_at" : "2013-09-17 20:37:09 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scheirman",
      "screen_name" : "subdigital",
      "indices" : [ 0, 11 ],
      "id_str" : "14133001",
      "id" : 14133001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380067750426603520",
  "geo" : { },
  "id_str" : "380067881574076416",
  "in_reply_to_user_id" : 14133001,
  "text" : "@subdigital Same, I remember the terrible fate of the visual builder. I guess some things don't change.",
  "id" : 380067881574076416,
  "in_reply_to_status_id" : 380067750426603520,
  "created_at" : "2013-09-17 20:36:58 +0000",
  "in_reply_to_screen_name" : "subdigital",
  "in_reply_to_user_id_str" : "14133001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380066765738233857",
  "geo" : { },
  "id_str" : "380067765152792576",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow Thanks. I need to make it up to TO (or you down here!) so we can talk more about this.",
  "id" : 380067765152792576,
  "in_reply_to_status_id" : 380066765738233857,
  "created_at" : "2013-09-17 20:36:31 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scheirman",
      "screen_name" : "subdigital",
      "indices" : [ 0, 11 ],
      "id_str" : "14133001",
      "id" : 14133001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380067207843020801",
  "geo" : { },
  "id_str" : "380067407324123137",
  "in_reply_to_user_id" : 14133001,
  "text" : "@subdigital isn't that bullshit though? that's what they market it as.",
  "id" : 380067407324123137,
  "in_reply_to_status_id" : 380067207843020801,
  "created_at" : "2013-09-17 20:35:05 +0000",
  "in_reply_to_screen_name" : "subdigital",
  "in_reply_to_user_id_str" : "14133001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380066943803609088",
  "geo" : { },
  "id_str" : "380067291666194433",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss Bummer. Is it because design is split between code\/IB?",
  "id" : 380067291666194433,
  "in_reply_to_status_id" : 380066943803609088,
  "created_at" : "2013-09-17 20:34:38 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scheirman",
      "screen_name" : "subdigital",
      "indices" : [ 0, 11 ],
      "id_str" : "14133001",
      "id" : 14133001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380066379732238336",
  "geo" : { },
  "id_str" : "380066861326426112",
  "in_reply_to_user_id" : 14133001,
  "text" : "@subdigital but that's all in code, which misses the point entirely of using IB",
  "id" : 380066861326426112,
  "in_reply_to_status_id" : 380066379732238336,
  "created_at" : "2013-09-17 20:32:55 +0000",
  "in_reply_to_screen_name" : "subdigital",
  "in_reply_to_user_id_str" : "14133001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380066251718291456",
  "geo" : { },
  "id_str" : "380066619679985665",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow Even the language from WWDC seems designer-hostile. \"Here's a mock that moves it 3px over...\" Why can't the designer fix it?",
  "id" : 380066619679985665,
  "in_reply_to_status_id" : 380066251718291456,
  "created_at" : "2013-09-17 20:31:58 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scheirman",
      "screen_name" : "subdigital",
      "indices" : [ 0, 11 ],
      "id_str" : "14133001",
      "id" : 14133001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380065835856842752",
  "geo" : { },
  "id_str" : "380066155521536000",
  "in_reply_to_user_id" : 14133001,
  "text" : "@subdigital \"custom\" means \"anything else than stock\" which means \"nearly every app\". Such a copout. :(",
  "id" : 380066155521536000,
  "in_reply_to_status_id" : 380065835856842752,
  "created_at" : "2013-09-17 20:30:07 +0000",
  "in_reply_to_screen_name" : "subdigital",
  "in_reply_to_user_id_str" : "14133001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380065871789817856",
  "geo" : { },
  "id_str" : "380066025531641857",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow That seems like a terrible way to handle it. I'm amazed with such focus on design the community doesn't push for better.",
  "id" : 380066025531641857,
  "in_reply_to_status_id" : 380065871789817856,
  "created_at" : "2013-09-17 20:29:36 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380065335862636545",
  "geo" : { },
  "id_str" : "380065666566336514",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow Curious how any simple customization works. Can't use custom fonts, tried to tile a background and no go. How do people use this?",
  "id" : 380065666566336514,
  "in_reply_to_status_id" : 380065335862636545,
  "created_at" : "2013-09-17 20:28:10 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380065252299120640",
  "text" : "iOS devs: are you using IB with Xcode [REDACTED FOR 12 HOURS]? If so...I have a few questions for you.",
  "id" : 380065252299120640,
  "created_at" : "2013-09-17 20:26:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 0, 4 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380063683096756224",
  "geo" : { },
  "id_str" : "380063974110138368",
  "in_reply_to_user_id" : 10079052,
  "text" : "@rjs It would be more awesome if you didn't have to use Photoshop at all.",
  "id" : 380063974110138368,
  "in_reply_to_status_id" : 380063683096756224,
  "created_at" : "2013-09-17 20:21:27 +0000",
  "in_reply_to_screen_name" : "rjs",
  "in_reply_to_user_id_str" : "10079052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 0, 8 ],
      "id_str" : "77673",
      "id" : 77673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380014507630010369",
  "geo" : { },
  "id_str" : "380059665855299584",
  "in_reply_to_user_id" : 77673,
  "text" : "@jwright Pretty sure the Comfort Suites is booked. Let me know if you have trouble.",
  "id" : 380059665855299584,
  "in_reply_to_status_id" : 380014507630010369,
  "created_at" : "2013-09-17 20:04:20 +0000",
  "in_reply_to_screen_name" : "jwright",
  "in_reply_to_user_id_str" : "77673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380058369454637057",
  "geo" : { },
  "id_str" : "380058636422094848",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt Thursday, 1 January 1970",
  "id" : 380058636422094848,
  "in_reply_to_status_id" : 380058369454637057,
  "created_at" : "2013-09-17 20:00:14 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380038936779042816",
  "geo" : { },
  "id_str" : "380040823930245120",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella post-op Ged was pretty stupid too. It wears off after a day.",
  "id" : 380040823930245120,
  "in_reply_to_status_id" : 380038936779042816,
  "created_at" : "2013-09-17 18:49:27 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/N87pDdkPFo",
      "expanded_url" : "http:\/\/kylerichter.com\/?p=44",
      "display_url" : "kylerichter.com\/?p=44"
    } ]
  },
  "geo" : { },
  "id_str" : "380033937138921472",
  "text" : "Continually unimpressed by lack of transparency on Apple's part: http:\/\/t.co\/N87pDdkPFo",
  "id" : 380033937138921472,
  "created_at" : "2013-09-17 18:22:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/cLUA9q089T",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=SRH-Ywpz1_I",
      "display_url" : "youtube.com\/watch?v=SRH-Yw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380032413260189697",
  "text" : "Current status: http:\/\/t.co\/cLUA9q089T",
  "id" : 380032413260189697,
  "created_at" : "2013-09-17 18:16:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Matthieu",
      "screen_name" : "chrismatthieu",
      "indices" : [ 3, 17 ],
      "id_str" : "13604142",
      "id" : 13604142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380028257434730496",
  "text" : "RT @chrismatthieu: readme.io - domain free to a good open source project",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380016264464187392",
    "text" : "readme.io - domain free to a good open source project",
    "id" : 380016264464187392,
    "created_at" : "2013-09-17 17:11:52 +0000",
    "user" : {
      "name" : "Chris Matthieu",
      "screen_name" : "chrismatthieu",
      "protected" : false,
      "id_str" : "13604142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918916153\/SuperChrisSmall_normal.jpg",
      "id" : 13604142,
      "verified" : false
    }
  },
  "id" : 380028257434730496,
  "created_at" : "2013-09-17 17:59:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380025126646861824",
  "text" : "RT @bquarant: \"Q: What are common mistakes you see on the exam?\" \"A: Wrong answers\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380024963110936576",
    "text" : "\"Q: What are common mistakes you see on the exam?\" \"A: Wrong answers\"",
    "id" : 380024963110936576,
    "created_at" : "2013-09-17 17:46:26 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 380025126646861824,
  "created_at" : "2013-09-17 17:47:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Boulden",
      "screen_name" : "Spruke",
      "indices" : [ 15, 22 ],
      "id_str" : "182384817",
      "id" : 182384817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380012878503223296",
  "geo" : { },
  "id_str" : "380013531426324481",
  "in_reply_to_user_id" : 18059313,
  "text" : "@ExitMusicCory @Spruke only at Spot Delaware, I presume...",
  "id" : 380013531426324481,
  "in_reply_to_status_id" : 380012878503223296,
  "created_at" : "2013-09-17 17:01:00 +0000",
  "in_reply_to_screen_name" : "CoryMPerla",
  "in_reply_to_user_id_str" : "18059313",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Smith",
      "screen_name" : "nwjsmith",
      "indices" : [ 3, 12 ],
      "id_str" : "1692361",
      "id" : 1692361
    }, {
      "name" : "Strange Loop Conf",
      "screen_name" : "strangeloop_stl",
      "indices" : [ 36, 52 ],
      "id_str" : "28045502",
      "id" : 28045502
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 86, 101 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380012220190449664",
  "text" : "RT @nwjsmith: I'm super excited for @strangeloop_stl, but if I wasn't going I'd be at @nickelcityruby. You should go!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Strange Loop Conf",
        "screen_name" : "strangeloop_stl",
        "indices" : [ 22, 38 ],
        "id_str" : "28045502",
        "id" : 28045502
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 72, 87 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 43.6612980639, -79.3841475606 ]
    },
    "id_str" : "379730855901396992",
    "text" : "I'm super excited for @strangeloop_stl, but if I wasn't going I'd be at @nickelcityruby. You should go!",
    "id" : 379730855901396992,
    "created_at" : "2013-09-16 22:17:45 +0000",
    "user" : {
      "name" : "Nate Smith",
      "screen_name" : "nwjsmith",
      "protected" : false,
      "id_str" : "1692361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/423668305912532992\/fW9V7Hjs_normal.jpeg",
      "id" : 1692361,
      "verified" : false
    }
  },
  "id" : 380012220190449664,
  "created_at" : "2013-09-17 16:55:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 3, 12 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 67, 82 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380012197843189761",
  "text" : "RT @mr_ndrsn: Ahhh. Home at last! Only for 2days, tho, then off to @nickelcityruby!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 53, 68 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "379785278107701248",
    "text" : "Ahhh. Home at last! Only for 2days, tho, then off to @nickelcityruby!!",
    "id" : 379785278107701248,
    "created_at" : "2013-09-17 01:54:01 +0000",
    "user" : {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "protected" : false,
      "id_str" : "774032401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460857040542261248\/228nQ2PI_normal.jpeg",
      "id" : 774032401,
      "verified" : false
    }
  },
  "id" : 380012197843189761,
  "created_at" : "2013-09-17 16:55:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Daniel",
      "screen_name" : "binarycleric",
      "indices" : [ 3, 16 ],
      "id_str" : "16128472",
      "id" : 16128472
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 33, 48 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 77, 89 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380012187189665792",
  "text" : "RT @binarycleric: Folks going to @nickelcityruby should definitely check out @juliepagano's talk on Impostor Syndrome. Wish I was able to g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 15, 30 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "juliepagano",
        "screen_name" : "juliepagano",
        "indices" : [ 59, 71 ],
        "id_str" : "2874563195",
        "id" : 2874563195
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "379993007409221633",
    "text" : "Folks going to @nickelcityruby should definitely check out @juliepagano's talk on Impostor Syndrome. Wish I was able to go. :(",
    "id" : 379993007409221633,
    "created_at" : "2013-09-17 15:39:27 +0000",
    "user" : {
      "name" : "Jon Daniel",
      "screen_name" : "binarycleric",
      "protected" : false,
      "id_str" : "16128472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469666902705307648\/9eya59BC_normal.jpeg",
      "id" : 16128472,
      "verified" : false
    }
  },
  "id" : 380012187189665792,
  "created_at" : "2013-09-17 16:55:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379990564193579009",
  "text" : "Apparently iOS7 coming out tomorrow does not count as a \"Time-Sensitive Event\" if you want an expedited review. :|",
  "id" : 379990564193579009,
  "created_at" : "2013-09-17 15:29:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379987458328637440",
  "geo" : { },
  "id_str" : "379987876789764096",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh Literally one of a few cities with this problem.",
  "id" : 379987876789764096,
  "in_reply_to_status_id" : 379987458328637440,
  "created_at" : "2013-09-17 15:19:04 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike susz",
      "screen_name" : "mikesusz",
      "indices" : [ 0, 9 ],
      "id_str" : "14531472",
      "id" : 14531472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379975177645604864",
  "geo" : { },
  "id_str" : "379987349192466432",
  "in_reply_to_user_id" : 14531472,
  "text" : "@mikesusz very close! There's several lots on Washington, also one on Huron. Really any will work and are a 5-10 minute walk.",
  "id" : 379987349192466432,
  "in_reply_to_status_id" : 379975177645604864,
  "created_at" : "2013-09-17 15:16:58 +0000",
  "in_reply_to_screen_name" : "mikesusz",
  "in_reply_to_user_id_str" : "14531472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "infotechniagara",
      "screen_name" : "infotechniagara",
      "indices" : [ 3, 19 ],
      "id_str" : "16450873",
      "id" : 16450873
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 40, 48 ]
    }, {
      "text" : "Ruby",
      "indices" : [ 61, 66 ]
    }, {
      "text" : "WNYRuby",
      "indices" : [ 95, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/0jTgsR1asJ",
      "expanded_url" : "http:\/\/wp.me\/p320MR-36",
      "display_url" : "wp.me\/p320MR-36"
    } ]
  },
  "geo" : { },
  "id_str" : "379987128211349504",
  "text" : "RT @infotechniagara: Register TODAY for #Buffalo Nickel City #Ruby Conference 2013: 9\/20-9\/21  #WNYRuby http:\/\/t.co\/0jTgsR1asJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 19, 27 ]
      }, {
        "text" : "Ruby",
        "indices" : [ 40, 45 ]
      }, {
        "text" : "WNYRuby",
        "indices" : [ 74, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/0jTgsR1asJ",
        "expanded_url" : "http:\/\/wp.me\/p320MR-36",
        "display_url" : "wp.me\/p320MR-36"
      } ]
    },
    "geo" : { },
    "id_str" : "379968809643155456",
    "text" : "Register TODAY for #Buffalo Nickel City #Ruby Conference 2013: 9\/20-9\/21  #WNYRuby http:\/\/t.co\/0jTgsR1asJ",
    "id" : 379968809643155456,
    "created_at" : "2013-09-17 14:03:18 +0000",
    "user" : {
      "name" : "infotechniagara",
      "screen_name" : "infotechniagara",
      "protected" : false,
      "id_str" : "16450873",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/64732059\/itn_logo_normal.jpg",
      "id" : 16450873,
      "verified" : false
    }
  },
  "id" : 379987128211349504,
  "created_at" : "2013-09-17 15:16:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex McHale",
      "screen_name" : "alexmchale",
      "indices" : [ 0, 11 ],
      "id_str" : "13964832",
      "id" : 13964832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379981554359214080",
  "geo" : { },
  "id_str" : "379981714828689409",
  "in_reply_to_user_id" : 13964832,
  "text" : "@alexmchale nope",
  "id" : 379981714828689409,
  "in_reply_to_status_id" : 379981554359214080,
  "created_at" : "2013-09-17 14:54:35 +0000",
  "in_reply_to_screen_name" : "alexmchale",
  "in_reply_to_user_id_str" : "13964832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 3, 13 ],
      "id_str" : "15536268",
      "id" : 15536268
    }, {
      "name" : "Paddy O'Brien",
      "screen_name" : "tapi",
      "indices" : [ 63, 68 ],
      "id_str" : "10382082",
      "id" : 10382082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/vFESizSXxd",
      "expanded_url" : "http:\/\/www.engadget.com\/2013\/09\/17\/apple-ios-last-compatible-version-app-iphone-ipod-ipad\/",
      "display_url" : "engadget.com\/2013\/09\/17\/app\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379946323941658626",
  "text" : "RT @ashfurrow: Awesome that Apple told us this was coming. \/cc @tapi http:\/\/t.co\/vFESizSXxd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paddy O'Brien",
        "screen_name" : "tapi",
        "indices" : [ 48, 53 ],
        "id_str" : "10382082",
        "id" : 10382082
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/vFESizSXxd",
        "expanded_url" : "http:\/\/www.engadget.com\/2013\/09\/17\/apple-ios-last-compatible-version-app-iphone-ipod-ipad\/",
        "display_url" : "engadget.com\/2013\/09\/17\/app\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379940865885474816",
    "text" : "Awesome that Apple told us this was coming. \/cc @tapi http:\/\/t.co\/vFESizSXxd",
    "id" : 379940865885474816,
    "created_at" : "2013-09-17 12:12:16 +0000",
    "user" : {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "protected" : false,
      "id_str" : "15536268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2566171949\/ashfurrow_square_normal.jpeg",
      "id" : 15536268,
      "verified" : false
    }
  },
  "id" : 379946323941658626,
  "created_at" : "2013-09-17 12:33:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 0, 6 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379792721335967744",
  "geo" : { },
  "id_str" : "379793073439391744",
  "in_reply_to_user_id" : 205281746,
  "text" : "@ahuj9 proud resident of WASSUP here. what game is this?",
  "id" : 379793073439391744,
  "in_reply_to_status_id" : 379792721335967744,
  "created_at" : "2013-09-17 02:24:59 +0000",
  "in_reply_to_screen_name" : "ahuj9",
  "in_reply_to_user_id_str" : "205281746",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 5, 17 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379779544212705280",
  "geo" : { },
  "id_str" : "379779841119121408",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh @rocketslide basically my week, this week.",
  "id" : 379779841119121408,
  "in_reply_to_status_id" : 379779544212705280,
  "created_at" : "2013-09-17 01:32:24 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rufo Sanchez",
      "screen_name" : "rufo",
      "indices" : [ 0, 5 ],
      "id_str" : "710683",
      "id" : 710683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379777549708308481",
  "geo" : { },
  "id_str" : "379777743665123328",
  "in_reply_to_user_id" : 710683,
  "text" : "@rufo where is this?",
  "id" : 379777743665123328,
  "in_reply_to_status_id" : 379777549708308481,
  "created_at" : "2013-09-17 01:24:04 +0000",
  "in_reply_to_screen_name" : "rufo",
  "in_reply_to_user_id_str" : "710683",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379737171776647168",
  "text" : "ETOOMANYSTROOPWAFELS",
  "id" : 379737171776647168,
  "created_at" : "2013-09-16 22:42:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/mywH7ArhXx",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=P4MinL8D7A8",
      "display_url" : "youtube.com\/watch?v=P4MinL\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "379715501033021442",
  "geo" : { },
  "id_str" : "379716052793307136",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn http:\/\/t.co\/mywH7ArhXx ?",
  "id" : 379716052793307136,
  "in_reply_to_status_id" : 379715501033021442,
  "created_at" : "2013-09-16 21:18:56 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 0, 7 ],
      "id_str" : "728173",
      "id" : 728173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379710933884751873",
  "geo" : { },
  "id_str" : "379712152853938178",
  "in_reply_to_user_id" : 728173,
  "text" : "@MikeG1 Lots of patience...and silence. Closed systems suck, but when they reach so many users...",
  "id" : 379712152853938178,
  "in_reply_to_status_id" : 379710933884751873,
  "created_at" : "2013-09-16 21:03:26 +0000",
  "in_reply_to_screen_name" : "MikeG1",
  "in_reply_to_user_id_str" : "728173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/vfaeCiTT6M",
      "expanded_url" : "http:\/\/tychoish.com\/rhizome\/9-awesome-ssh-tricks\/",
      "display_url" : "tychoish.com\/rhizome\/9-awes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379704977565831168",
  "text" : "TIL about SSH ControlMaster\/Path... TL;DR, you should set it up! http:\/\/t.co\/vfaeCiTT6M",
  "id" : 379704977565831168,
  "created_at" : "2013-09-16 20:34:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric S",
      "screen_name" : "MutualArising",
      "indices" : [ 3, 17 ],
      "id_str" : "15913837",
      "id" : 15913837
    }, {
      "name" : "Bitmaker Labs",
      "screen_name" : "bitmakerlabs",
      "indices" : [ 24, 37 ],
      "id_str" : "853592048",
      "id" : 853592048
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 79, 94 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379685801203744768",
  "text" : "RT @MutualArising: Okay @bitmakerlabs peeps. I've pretty much decided to go to @nickelcityruby this weekend - who wants to come down with m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bitmaker Labs",
        "screen_name" : "bitmakerlabs",
        "indices" : [ 5, 18 ],
        "id_str" : "853592048",
        "id" : 853592048
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 60, 75 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "379685610233290753",
    "text" : "Okay @bitmakerlabs peeps. I've pretty much decided to go to @nickelcityruby this weekend - who wants to come down with me?",
    "id" : 379685610233290753,
    "created_at" : "2013-09-16 19:17:58 +0000",
    "user" : {
      "name" : "Eric S",
      "screen_name" : "MutualArising",
      "protected" : false,
      "id_str" : "15913837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000473983129\/c7b155bfe4b6374c5d3c517105d61a14_normal.jpeg",
      "id" : 15913837,
      "verified" : false
    }
  },
  "id" : 379685801203744768,
  "created_at" : "2013-09-16 19:18:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Honeybadger for Ruby",
      "screen_name" : "honeybadgerapp",
      "indices" : [ 3, 18 ],
      "id_str" : "608199309",
      "id" : 608199309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/8xHOBmZAcd",
      "expanded_url" : "http:\/\/www.rafflecopter.com\/rafl\/display\/6eb5a40\/",
      "display_url" : "rafflecopter.com\/rafl\/display\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379685761152319488",
  "text" : "RT @honeybadgerapp: Want to go to Nickel City Ruby, but don't have a ticket? We're giving ours away: http:\/\/t.co\/8xHOBmZAcd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/8xHOBmZAcd",
        "expanded_url" : "http:\/\/www.rafflecopter.com\/rafl\/display\/6eb5a40\/",
        "display_url" : "rafflecopter.com\/rafl\/display\/6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379684908496846848",
    "text" : "Want to go to Nickel City Ruby, but don't have a ticket? We're giving ours away: http:\/\/t.co\/8xHOBmZAcd",
    "id" : 379684908496846848,
    "created_at" : "2013-09-16 19:15:11 +0000",
    "user" : {
      "name" : "Honeybadger for Ruby",
      "screen_name" : "honeybadgerapp",
      "protected" : false,
      "id_str" : "608199309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459070518805553152\/2xRUkInN_normal.jpeg",
      "id" : 608199309,
      "verified" : false
    }
  },
  "id" : 379685761152319488,
  "created_at" : "2013-09-16 19:18:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "indices" : [ 3, 14 ],
      "id_str" : "1232850504",
      "id" : 1232850504
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 94, 109 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubylove",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379675662816382976",
  "text" : "RT @gdiBuffalo: Congratulations to Wendy ., Jessica L, and Crystal Es who won free tickets to @nickelcityruby! See you there this weekend! \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 78, 93 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubylove",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "379667199465517056",
    "text" : "Congratulations to Wendy ., Jessica L, and Crystal Es who won free tickets to @nickelcityruby! See you there this weekend! :) #rubylove",
    "id" : 379667199465517056,
    "created_at" : "2013-09-16 18:04:48 +0000",
    "user" : {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "protected" : false,
      "id_str" : "1232850504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3326614365\/de10a9f13010fc569fd25c1a6392366c_normal.png",
      "id" : 1232850504,
      "verified" : false
    }
  },
  "id" : 379675662816382976,
  "created_at" : "2013-09-16 18:38:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 86, 101 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379675418967945216",
  "text" : "Happy to say I just witnessed a new wifi router in the aud installed just in time for @nickelcityruby\u2026let there be internets!",
  "id" : 379675418967945216,
  "created_at" : "2013-09-16 18:37:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 3, 6 ],
      "id_str" : "1133971",
      "id" : 1133971
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 51, 66 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/cuTMnc7gWp",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "379657027120676864",
  "text" : "RT @j3: Getting excited, a bit nervous to kick off @nickelcityruby this Friday: http:\/\/t.co\/cuTMnc7gWp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 43, 58 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/cuTMnc7gWp",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "379654825043968001",
    "text" : "Getting excited, a bit nervous to kick off @nickelcityruby this Friday: http:\/\/t.co\/cuTMnc7gWp",
    "id" : 379654825043968001,
    "created_at" : "2013-09-16 17:15:38 +0000",
    "user" : {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "protected" : false,
      "id_str" : "1133971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000543599975\/c63a58ff323b22a9e9ad52ffbbfb7f0a_normal.jpeg",
      "id" : 1133971,
      "verified" : false
    }
  },
  "id" : 379657027120676864,
  "created_at" : "2013-09-16 17:24:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zzak\u3048\u30B6\u30C3\u30AF",
      "screen_name" : "_zzak",
      "indices" : [ 3, 9 ],
      "id_str" : "920539489",
      "id" : 920539489
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 15, 30 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379657019092762624",
  "text" : "RT @_zzak: OMG @nickelcityruby is this week! Do you have your ticket yet??",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 4, 19 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 43.6152369169, -72.9833949351 ]
    },
    "id_str" : "379648568971517952",
    "text" : "OMG @nickelcityruby is this week! Do you have your ticket yet??",
    "id" : 379648568971517952,
    "created_at" : "2013-09-16 16:50:47 +0000",
    "user" : {
      "name" : "zzak\u3048\u30B6\u30C3\u30AF",
      "screen_name" : "_zzak",
      "protected" : false,
      "id_str" : "920539489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000760450458\/1d14e04afe654ee43abccfce2040558e_normal.jpeg",
      "id" : 920539489,
      "verified" : false
    }
  },
  "id" : 379657019092762624,
  "created_at" : "2013-09-16 17:24:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/BDqk2CoRxf",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=eK1hmDpa8bo",
      "display_url" : "youtube.com\/watch?v=eK1hmD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379643480080785409",
  "text" : "While I'm on Rush links...here's La Villa Strangiato with no audience, and a lot of hair (and a mustache) http:\/\/t.co\/BDqk2CoRxf",
  "id" : 379643480080785409,
  "created_at" : "2013-09-16 16:30:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/bwnNSUF9La",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=joWQEtTujmI",
      "display_url" : "youtube.com\/watch?v=joWQEt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379642500878569472",
  "text" : "Lullaby renditions of Rush. Genius. http:\/\/t.co\/bwnNSUF9La",
  "id" : 379642500878569472,
  "created_at" : "2013-09-16 16:26:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 12, 25 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/ytvEeYKHxs",
      "expanded_url" : "http:\/\/awesomelyluvvie.com\/wp-content\/uploads\/2013\/06\/NOPE.gif",
      "display_url" : "awesomelyluvvie.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "379638447398330368",
  "geo" : { },
  "id_str" : "379639722957471745",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @lindseybieda http:\/\/t.co\/ytvEeYKHxs",
  "id" : 379639722957471745,
  "in_reply_to_status_id" : 379638447398330368,
  "created_at" : "2013-09-16 16:15:37 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 3, 16 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/uhyulhTqJr",
      "expanded_url" : "https:\/\/www.change.org\/petitions\/gamespot-staff-fire-carolyn-petit",
      "display_url" : "change.org\/petitions\/game\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379636828900302849",
  "text" : "RT @lindseybieda: Gamer Culture: https:\/\/t.co\/uhyulhTqJr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/uhyulhTqJr",
        "expanded_url" : "https:\/\/www.change.org\/petitions\/gamespot-staff-fire-carolyn-petit",
        "display_url" : "change.org\/petitions\/game\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379636660788400128",
    "text" : "Gamer Culture: https:\/\/t.co\/uhyulhTqJr",
    "id" : 379636660788400128,
    "created_at" : "2013-09-16 16:03:27 +0000",
    "user" : {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "protected" : false,
      "id_str" : "14928483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569192760029089792\/zaGhTAHK_normal.jpeg",
      "id" : 14928483,
      "verified" : false
    }
  },
  "id" : 379636828900302849,
  "created_at" : "2013-09-16 16:04:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 30, 41 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/nkQSx8BKxK",
      "expanded_url" : "http:\/\/www.itworld.com\/personal-tech\/372349\/7-days-google-glass",
      "display_url" : "itworld.com\/personal-tech\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379634276871856128",
  "text" : "7 days with Google Glass from @kevinpurdy, and a sneak self-appearance: http:\/\/t.co\/nkQSx8BKxK",
  "id" : 379634276871856128,
  "created_at" : "2013-09-16 15:53:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 21, 36 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "379609499733999616",
  "text" : "It's official...it's @nickelcityruby week! We have tickets available still: http:\/\/t.co\/3UAdoKZw7Q",
  "id" : 379609499733999616,
  "created_at" : "2013-09-16 14:15:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hampton",
      "screen_name" : "hcatlin",
      "indices" : [ 0, 8 ],
      "id_str" : "12986052",
      "id" : 12986052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/9DwIMktUDT",
      "expanded_url" : "http:\/\/www.beheadingboredom.com\/wp-content\/uploads\/2013\/07\/olive-garden-unlimited-breadsticks-from-laptop-trapped.jpg",
      "display_url" : "beheadingboredom.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "379468703173054464",
  "geo" : { },
  "id_str" : "379469552397975552",
  "in_reply_to_user_id" : 12986052,
  "text" : "@hcatlin http:\/\/t.co\/9DwIMktUDT",
  "id" : 379469552397975552,
  "in_reply_to_status_id" : 379468703173054464,
  "created_at" : "2013-09-16 04:59:26 +0000",
  "in_reply_to_screen_name" : "hcatlin",
  "in_reply_to_user_id_str" : "12986052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 102, 114 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/379450977192923136\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/wVy2N4XsAt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUQUpy4CAAE_R1e.png",
      "id_str" : "379450976869941249",
      "id" : 379450976869941249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUQUpy4CAAE_R1e.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/wVy2N4XsAt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379450977192923136",
  "text" : "Lost Cities added motion effects to buttons and your hand on iOS7. First use in an app I\u2019ve seen. \/cc @SteveStreza http:\/\/t.co\/wVy2N4XsAt",
  "id" : 379450977192923136,
  "created_at" : "2013-09-16 03:45:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379422797434347520",
  "geo" : { },
  "id_str" : "379425166704402433",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza maybe that's the problem...not enough designers involved, deep into Xcode, etc.",
  "id" : 379425166704402433,
  "in_reply_to_status_id" : 379422797434347520,
  "created_at" : "2013-09-16 02:03:03 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379410931731550208",
  "text" : "Has anyone seen Derek on Netflix yet? WTF is this show?",
  "id" : 379410931731550208,
  "created_at" : "2013-09-16 01:06:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379403768095199233",
  "geo" : { },
  "id_str" : "379404936137551872",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden Nyooooooo",
  "id" : 379404936137551872,
  "in_reply_to_status_id" : 379403768095199233,
  "created_at" : "2013-09-16 00:42:40 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/hubxH8hMH9",
      "expanded_url" : "http:\/\/content.time.com\/time\/magazine\/asia\/0,9263,501130916,00.html",
      "display_url" : "content.time.com\/time\/magazine\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379404889299759105",
  "text" : "RT @ggreenwald: TIME puts Putin on the cover of all its magazines - except for the US edition  http:\/\/t.co\/hubxH8hMH9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/hubxH8hMH9",
        "expanded_url" : "http:\/\/content.time.com\/time\/magazine\/asia\/0,9263,501130916,00.html",
        "display_url" : "content.time.com\/time\/magazine\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379399536277340160",
    "text" : "TIME puts Putin on the cover of all its magazines - except for the US edition  http:\/\/t.co\/hubxH8hMH9",
    "id" : 379399536277340160,
    "created_at" : "2013-09-16 00:21:13 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/418715960158068736\/Lv1oLH3A_normal.jpeg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 379404889299759105,
  "created_at" : "2013-09-16 00:42:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Schneiderman",
      "screen_name" : "hiteak",
      "indices" : [ 0, 7 ],
      "id_str" : "15507545",
      "id" : 15507545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379386563055984640",
  "geo" : { },
  "id_str" : "379387352671453184",
  "in_reply_to_user_id" : 15507545,
  "text" : "@hiteak talks will be recorded, but no stream, sorry.",
  "id" : 379387352671453184,
  "in_reply_to_status_id" : 379386563055984640,
  "created_at" : "2013-09-15 23:32:48 +0000",
  "in_reply_to_screen_name" : "hiteak",
  "in_reply_to_user_id_str" : "15507545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 0, 12 ],
      "id_str" : "156689065",
      "id" : 156689065
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 38, 53 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379379623085506560",
  "geo" : { },
  "id_str" : "379381164370186240",
  "in_reply_to_user_id" : 156689065,
  "text" : "@whereslloyd hope you'll be ready for @nickelcityruby on friday! bringing plenty of folks to Main &amp; Mohawk.",
  "id" : 379381164370186240,
  "in_reply_to_status_id" : 379379623085506560,
  "created_at" : "2013-09-15 23:08:12 +0000",
  "in_reply_to_screen_name" : "whereslloyd",
  "in_reply_to_user_id_str" : "156689065",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zachary Gershman",
      "screen_name" : "ZachGersh",
      "indices" : [ 0, 10 ],
      "id_str" : "127905827",
      "id" : 127905827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/zgeH1xExy2",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/status\/379290989233328128",
      "display_url" : "twitter.com\/qrush\/status\/3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "379378700698914817",
  "geo" : { },
  "id_str" : "379378838569893888",
  "in_reply_to_user_id" : 127905827,
  "text" : "@ZachGersh it's more like  https:\/\/t.co\/zgeH1xExy2",
  "id" : 379378838569893888,
  "in_reply_to_status_id" : 379378700698914817,
  "created_at" : "2013-09-15 22:58:58 +0000",
  "in_reply_to_screen_name" : "ZachGersh",
  "in_reply_to_user_id_str" : "127905827",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 13, 28 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379378446045949952",
  "text" : "5 days until @nickelcityruby. It's GO TIME!!!",
  "id" : 379378446045949952,
  "created_at" : "2013-09-15 22:57:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "5 Nights at Jamie's*",
      "screen_name" : "death2normalcy",
      "indices" : [ 0, 15 ],
      "id_str" : "129537034",
      "id" : 129537034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379313724966043648",
  "geo" : { },
  "id_str" : "379364785537552385",
  "in_reply_to_user_id" : 129537034,
  "text" : "@death2normalcy there's a ton of conflicts, even on our date with other conferences. Impossible not to :)",
  "id" : 379364785537552385,
  "in_reply_to_status_id" : 379313724966043648,
  "created_at" : "2013-09-15 22:03:07 +0000",
  "in_reply_to_screen_name" : "death2normalcy",
  "in_reply_to_user_id_str" : "129537034",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "R D Old",
      "screen_name" : "thatRD",
      "indices" : [ 13, 20 ],
      "id_str" : "1928924059",
      "id" : 1928924059
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 21, 36 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/qH3Er5Y83q",
      "expanded_url" : "http:\/\/i.imgur.com\/CupiM.gif",
      "display_url" : "i.imgur.com\/CupiM.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "379319120346775552",
  "geo" : { },
  "id_str" : "379338609909723136",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @thatRD @nickelcityruby also could stand for \"STUFF WE ALL GET\" http:\/\/t.co\/qH3Er5Y83q",
  "id" : 379338609909723136,
  "in_reply_to_status_id" : 379319120346775552,
  "created_at" : "2013-09-15 20:19:07 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379315421708419072",
  "geo" : { },
  "id_str" : "379315834214023169",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella also, \"2. marijuana, typically of a low grade.\"",
  "id" : 379315834214023169,
  "in_reply_to_status_id" : 379315421708419072,
  "created_at" : "2013-09-15 18:48:36 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 31, 46 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/7MZmetgv0g",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush\/9762216333\/in\/photostream\/lightbox\/",
      "display_url" : "flickr.com\/photos\/qrush\/9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379311819115880448",
  "text" : "Packing tons of swag boxes for @nickelcityruby today...we still have tickets if you can make it! http:\/\/t.co\/7MZmetgv0g",
  "id" : 379311819115880448,
  "created_at" : "2013-09-15 18:32:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/6YGHdqMR3U",
      "expanded_url" : "http:\/\/flic.kr\/p\/fSDUNH",
      "display_url" : "flic.kr\/p\/fSDUNH"
    } ]
  },
  "geo" : { },
  "id_str" : "379307726771601408",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu and the boxes http:\/\/t.co\/6YGHdqMR3U",
  "id" : 379307726771601408,
  "created_at" : "2013-09-15 18:16:23 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 32, 47 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/VHww0R2DBY",
      "expanded_url" : "http:\/\/flic.kr\/p\/fSDSWB",
      "display_url" : "flic.kr\/p\/fSDSWB"
    } ]
  },
  "geo" : { },
  "id_str" : "379307571204857856",
  "text" : "Getting some boxes together for @nickelcityruby! http:\/\/t.co\/VHww0R2DBY",
  "id" : 379307571204857856,
  "created_at" : "2013-09-15 18:15:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379290989233328128",
  "text" : "I'm like the Stress Hulk. \"What's your secret?\" \"I'm always stressed!\"",
  "id" : 379290989233328128,
  "created_at" : "2013-09-15 17:09:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379260980917981185",
  "text" : "To this car wash that has free vacuums: you have won my business forever. Thanks, a Husky owner.",
  "id" : 379260980917981185,
  "created_at" : "2013-09-15 15:10:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Somerville",
      "screen_name" : "charliesome",
      "indices" : [ 3, 15 ],
      "id_str" : "16142240",
      "id" : 16142240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/iHefQ7evCq",
      "expanded_url" : "http:\/\/javascript.spec.whatwg.org\/#comment-syntax",
      "display_url" : "javascript.spec.whatwg.org\/#comment-syntax"
    } ]
  },
  "geo" : { },
  "id_str" : "378734048429891584",
  "text" : "RT @charliesome: TIL putting --&gt; at the start of a line is a comment in JavaScript: http:\/\/t.co\/iHefQ7evCq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/iHefQ7evCq",
        "expanded_url" : "http:\/\/javascript.spec.whatwg.org\/#comment-syntax",
        "display_url" : "javascript.spec.whatwg.org\/#comment-syntax"
      } ]
    },
    "geo" : { },
    "id_str" : "378716331090001920",
    "text" : "TIL putting --&gt; at the start of a line is a comment in JavaScript: http:\/\/t.co\/iHefQ7evCq",
    "id" : 378716331090001920,
    "created_at" : "2013-09-14 03:06:24 +0000",
    "user" : {
      "name" : "Charlie Somerville",
      "screen_name" : "charliesome",
      "protected" : false,
      "id_str" : "16142240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538590678687563776\/K94MvaP4_normal.png",
      "id" : 16142240,
      "verified" : false
    }
  },
  "id" : 378734048429891584,
  "created_at" : "2013-09-14 04:16:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378658293792509952",
  "geo" : { },
  "id_str" : "378674470757466112",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 are you listening to ska?",
  "id" : 378674470757466112,
  "in_reply_to_status_id" : 378658293792509952,
  "created_at" : "2013-09-14 00:20:03 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvest",
      "screen_name" : "harvest",
      "indices" : [ 3, 11 ],
      "id_str" : "7541902",
      "id" : 7541902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/BaDXdhoz1A",
      "expanded_url" : "http:\/\/hrv.st\/14NkEJd",
      "display_url" : "hrv.st\/14NkEJd"
    } ]
  },
  "geo" : { },
  "id_str" : "378662109795856384",
  "text" : "RT @harvest: Still time to register for Nickel City Ruby next week! If you\u2019re there, be sure to say hi to our Harvest folks! http:\/\/t.co\/Ba\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/BaDXdhoz1A",
        "expanded_url" : "http:\/\/hrv.st\/14NkEJd",
        "display_url" : "hrv.st\/14NkEJd"
      } ]
    },
    "geo" : { },
    "id_str" : "378622998736928768",
    "text" : "Still time to register for Nickel City Ruby next week! If you\u2019re there, be sure to say hi to our Harvest folks! http:\/\/t.co\/BaDXdhoz1A",
    "id" : 378622998736928768,
    "created_at" : "2013-09-13 20:55:32 +0000",
    "user" : {
      "name" : "Harvest",
      "screen_name" : "harvest",
      "protected" : false,
      "id_str" : "7541902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2311152255\/053rrzypvrxxrrtwfl3t_normal.png",
      "id" : 7541902,
      "verified" : false
    }
  },
  "id" : 378662109795856384,
  "created_at" : "2013-09-13 23:30:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 59, 69 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378627525498241024",
  "geo" : { },
  "id_str" : "378634121431379968",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr I don't know if we have more room in October... \/cc @aspleenic (My November is um, well, booked)",
  "id" : 378634121431379968,
  "in_reply_to_status_id" : 378627525498241024,
  "created_at" : "2013-09-13 21:39:43 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 0, 12 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378619507750612992",
  "geo" : { },
  "id_str" : "378621461910798336",
  "in_reply_to_user_id" : 930061,
  "text" : "@ginatrapani Hopefully more awesome than awful for Basecamp :)",
  "id" : 378621461910798336,
  "in_reply_to_status_id" : 378619507750612992,
  "created_at" : "2013-09-13 20:49:25 +0000",
  "in_reply_to_screen_name" : "ginatrapani",
  "in_reply_to_user_id_str" : "930061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WickedGoodRuby",
      "screen_name" : "WickedGoodRuby",
      "indices" : [ 3, 18 ],
      "id_str" : "870817116",
      "id" : 870817116
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 64, 79 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378613794747867136",
  "text" : "RT @WickedGoodRuby: If you live in Buffalo and you don\u2019t have a @nickelcityruby ticket yet you should drop what you\u2019re doing and GO GET ONE!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 44, 59 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378611733453365248",
    "text" : "If you live in Buffalo and you don\u2019t have a @nickelcityruby ticket yet you should drop what you\u2019re doing and GO GET ONE!",
    "id" : 378611733453365248,
    "created_at" : "2013-09-13 20:10:46 +0000",
    "user" : {
      "name" : "WickedGoodRuby",
      "screen_name" : "WickedGoodRuby",
      "protected" : false,
      "id_str" : "870817116",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447321075\/22a4737f7aa69dfd4a64874de6ed8d9c_normal.png",
      "id" : 870817116,
      "verified" : false
    }
  },
  "id" : 378613794747867136,
  "created_at" : "2013-09-13 20:18:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 14, 25 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378608206584365056",
  "geo" : { },
  "id_str" : "378611008203284480",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV @kevinpurdy How to [Brew|Sell|Market] Beer in 5 minutes (only one of those!)",
  "id" : 378611008203284480,
  "in_reply_to_status_id" : 378608206584365056,
  "created_at" : "2013-09-13 20:07:53 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 3, 14 ],
      "id_str" : "38408851",
      "id" : 38408851
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 20, 35 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haskell",
      "indices" : [ 111, 119 ]
    }, {
      "text" : "ncrc2013",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378608470146023425",
  "text" : "RT @Jonplussed: Hey @nickelcityruby attendees! Anybody attending the following code retreat and want to do\/try #haskell? Let's pair! #ncrc2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 4, 19 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "haskell",
        "indices" : [ 95, 103 ]
      }, {
        "text" : "ncrc2013",
        "indices" : [ 117, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378606623226224640",
    "text" : "Hey @nickelcityruby attendees! Anybody attending the following code retreat and want to do\/try #haskell? Let's pair! #ncrc2013",
    "id" : 378606623226224640,
    "created_at" : "2013-09-13 19:50:27 +0000",
    "user" : {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "protected" : false,
      "id_str" : "38408851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471328341526462464\/hNg5dFGn_normal.jpeg",
      "id" : 38408851,
      "verified" : false
    }
  },
  "id" : 378608470146023425,
  "created_at" : "2013-09-13 19:57:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 0, 15 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/qZFU9g0B0S",
      "expanded_url" : "http:\/\/www.yelp.com\/biz\/dukes-bohemian-grove-bar-buffalo",
      "display_url" : "yelp.com\/biz\/dukes-bohe\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "378600061401575424",
  "geo" : { },
  "id_str" : "378603885931147264",
  "in_reply_to_user_id" : 16393800,
  "text" : "@AustinSeraphin DBGB's has Eggplant wings (and of course, an image for the menu) http:\/\/t.co\/qZFU9g0B0S",
  "id" : 378603885931147264,
  "in_reply_to_status_id" : 378600061401575424,
  "created_at" : "2013-09-13 19:39:35 +0000",
  "in_reply_to_screen_name" : "AustinSeraphin",
  "in_reply_to_user_id_str" : "16393800",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 0, 15 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/HlLQWn1bhI",
      "expanded_url" : "http:\/\/mergebuffalo.com\/Websites\/merge\/images\/Menus\/SUMMER_MENU_2013.pdf",
      "display_url" : "mergebuffalo.com\/Websites\/merge\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "378600061401575424",
  "geo" : { },
  "id_str" : "378603613838245888",
  "in_reply_to_user_id" : 16393800,
  "text" : "@AustinSeraphin Merge has seitan wings: http:\/\/t.co\/HlLQWn1bhI",
  "id" : 378603613838245888,
  "in_reply_to_status_id" : 378600061401575424,
  "created_at" : "2013-09-13 19:38:30 +0000",
  "in_reply_to_screen_name" : "AustinSeraphin",
  "in_reply_to_user_id_str" : "16393800",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378590966220722176",
  "text" : "NOOOO I LOST MY GIFS FOLDER",
  "id" : 378590966220722176,
  "created_at" : "2013-09-13 18:48:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirtan Patel",
      "screen_name" : "kirtan",
      "indices" : [ 3, 10 ],
      "id_str" : "14577999",
      "id" : 14577999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378580884686774272",
  "text" : "RT @kirtan: A 36-year-old spacecraft just told us that it's left our solar system over a 23-watt transmitter from over 11 billion miles awa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378353968214450176",
    "text" : "A 36-year-old spacecraft just told us that it's left our solar system over a 23-watt transmitter from over 11 billion miles away. Science.",
    "id" : 378353968214450176,
    "created_at" : "2013-09-13 03:06:30 +0000",
    "user" : {
      "name" : "Kirtan Patel",
      "screen_name" : "kirtan",
      "protected" : false,
      "id_str" : "14577999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421725544108294144\/zsVuJ0Ss_normal.jpeg",
      "id" : 14577999,
      "verified" : false
    }
  },
  "id" : 378580884686774272,
  "created_at" : "2013-09-13 18:08:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 68, 83 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378576832628412416",
  "text" : "Just learned of a small (85 people!) meetup that totally missed the @nickelcityruby news machine. How do people handle this in your city?",
  "id" : 378576832628412416,
  "created_at" : "2013-09-13 17:52:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank K",
      "screen_name" : "fkumro",
      "indices" : [ 3, 10 ],
      "id_str" : "14883887",
      "id" : 14883887
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 57, 72 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378569317304270848",
  "text" : "RT @fkumro: Hoping for some good tech talks next week at @nickelcityruby!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 45, 60 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378543865549971456",
    "text" : "Hoping for some good tech talks next week at @nickelcityruby!",
    "id" : 378543865549971456,
    "created_at" : "2013-09-13 15:41:05 +0000",
    "user" : {
      "name" : "Frank K",
      "screen_name" : "fkumro",
      "protected" : false,
      "id_str" : "14883887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2726397886\/14b04f7e9a417778e4cf1efeac186896_normal.png",
      "id" : 14883887,
      "verified" : false
    }
  },
  "id" : 378569317304270848,
  "created_at" : "2013-09-13 17:22:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 23, 38 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378543242934902784",
  "text" : "We're a week away from @nickelcityruby. If you're not coming...please pass the word on! $99 is the best conference deal you're going to get.",
  "id" : 378543242934902784,
  "created_at" : "2013-09-13 15:38:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dog Solution",
      "screen_name" : "DogSolutions",
      "indices" : [ 3, 16 ],
      "id_str" : "40343143",
      "id" : 40343143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/PEAXWBd2PF",
      "expanded_url" : "http:\/\/youtu.be\/UZE4HtLxNMY",
      "display_url" : "youtu.be\/UZE4HtLxNMY"
    } ]
  },
  "geo" : { },
  "id_str" : "378534518660923393",
  "text" : "RT @DogSolutions: WOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOOOWOWOWOOWOWOWOWOOOOWOWOWOWOWOW htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/PEAXWBd2PF",
        "expanded_url" : "http:\/\/youtu.be\/UZE4HtLxNMY",
        "display_url" : "youtu.be\/UZE4HtLxNMY"
      } ]
    },
    "geo" : { },
    "id_str" : "378534306332680192",
    "text" : "WOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOOOWOWOWOOWOWOWOWOOOOWOWOWOWOWOW http:\/\/t.co\/PEAXWBd2PF",
    "id" : 378534306332680192,
    "created_at" : "2013-09-13 15:03:06 +0000",
    "user" : {
      "name" : "Dog Solution",
      "screen_name" : "DogSolutions",
      "protected" : false,
      "id_str" : "40343143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451138333360402432\/nZ7vdu_r_normal.png",
      "id" : 40343143,
      "verified" : false
    }
  },
  "id" : 378534518660923393,
  "created_at" : "2013-09-13 15:03:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378533357086187520",
  "text" : "Seriously folks: If you don't have 2 factor auth on for apps, especially GMail, you're just asking to get owned.",
  "id" : 378533357086187520,
  "created_at" : "2013-09-13 14:59:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/yXThKceJM0",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/1595572",
      "display_url" : "gist.github.com\/qrush\/1595572"
    } ]
  },
  "geo" : { },
  "id_str" : "378526741456617472",
  "text" : "The long tail always surprises me, found this Powerline gist again, still active after 2 years: https:\/\/t.co\/yXThKceJM0",
  "id" : 378526741456617472,
  "created_at" : "2013-09-13 14:33:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phillip anderson",
      "screen_name" : "phillipanderson",
      "indices" : [ 3, 19 ],
      "id_str" : "2211081",
      "id" : 2211081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/rjFoozlE3B",
      "expanded_url" : "http:\/\/politicalwire.com\/archives\/2013\/09\/13\/best_political_ad_of_the_year_so_far.html",
      "display_url" : "politicalwire.com\/archives\/2013\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378524641909698560",
  "text" : "RT @phillipanderson: Amazing. http:\/\/t.co\/rjFoozlE3B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 31 ],
        "url" : "http:\/\/t.co\/rjFoozlE3B",
        "expanded_url" : "http:\/\/politicalwire.com\/archives\/2013\/09\/13\/best_political_ad_of_the_year_so_far.html",
        "display_url" : "politicalwire.com\/archives\/2013\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "378522599577649152",
    "text" : "Amazing. http:\/\/t.co\/rjFoozlE3B",
    "id" : 378522599577649152,
    "created_at" : "2013-09-13 14:16:35 +0000",
    "user" : {
      "name" : "phillip anderson",
      "screen_name" : "phillipanderson",
      "protected" : false,
      "id_str" : "2211081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2754603027\/7fe6dd56c16fe781f8233f0521ffe3e1_normal.jpeg",
      "id" : 2211081,
      "verified" : false
    }
  },
  "id" : 378524641909698560,
  "created_at" : "2013-09-13 14:24:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 25, 40 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378519397247488000",
  "text" : "Officially one week from @nickelcityruby. Plans within plans within plans!",
  "id" : 378519397247488000,
  "created_at" : "2013-09-13 14:03:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roy Tomeij",
      "screen_name" : "roy",
      "indices" : [ 3, 7 ],
      "id_str" : "8837982",
      "id" : 8837982
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 32, 47 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "AppSignal",
      "screen_name" : "AppSignal",
      "indices" : [ 85, 95 ],
      "id_str" : "852306672",
      "id" : 852306672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378519166778900480",
  "text" : "RT @roy: Anyone I know going to @nickelcityruby? Just so you know: STROOPWAFELS from @AppSignal.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 23, 38 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "AppSignal",
        "screen_name" : "AppSignal",
        "indices" : [ 76, 86 ],
        "id_str" : "852306672",
        "id" : 852306672
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378503882839949313",
    "text" : "Anyone I know going to @nickelcityruby? Just so you know: STROOPWAFELS from @AppSignal.",
    "id" : 378503882839949313,
    "created_at" : "2013-09-13 13:02:12 +0000",
    "user" : {
      "name" : "Roy Tomeij",
      "screen_name" : "roy",
      "protected" : false,
      "id_str" : "8837982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2062457724\/roy_square_normal.jpg",
      "id" : 8837982,
      "verified" : false
    }
  },
  "id" : 378519166778900480,
  "created_at" : "2013-09-13 14:02:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378396228104368128",
  "geo" : { },
  "id_str" : "378396494543323136",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt MoTD: RIP GBXGramps ~Avatar of Legend~",
  "id" : 378396494543323136,
  "in_reply_to_status_id" : 378396228104368128,
  "created_at" : "2013-09-13 05:55:29 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378393248148250624",
  "geo" : { },
  "id_str" : "378395410911358976",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt I hope over PMs. And maybe a ghost account.\n\n(I need a double favorite button)",
  "id" : 378395410911358976,
  "in_reply_to_status_id" : 378393248148250624,
  "created_at" : "2013-09-13 05:51:10 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378337670285369344",
  "geo" : { },
  "id_str" : "378392807796256770",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt please tell me you changed his sig.",
  "id" : 378392807796256770,
  "in_reply_to_status_id" : 378337670285369344,
  "created_at" : "2013-09-13 05:40:50 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 45, 53 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/UbgqYTpkuJ",
      "expanded_url" : "http:\/\/bmbflo.com\/",
      "display_url" : "bmbflo.com"
    } ]
  },
  "in_reply_to_status_id_str" : "378391475983114240",
  "geo" : { },
  "id_str" : "378391978838216704",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr how\u2019s this deal: you talk at a future @wnyruby, and I\u2019ll take you to http:\/\/t.co\/UbgqYTpkuJ",
  "id" : 378391978838216704,
  "in_reply_to_status_id" : 378391475983114240,
  "created_at" : "2013-09-13 05:37:32 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 0, 15 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378370493373755392",
  "geo" : { },
  "id_str" : "378390793804713984",
  "in_reply_to_user_id" : 16393800,
  "text" : "@AustinSeraphin alright I have some leads. I\u2019ll look into it more tomorrow!",
  "id" : 378390793804713984,
  "in_reply_to_status_id" : 378370493373755392,
  "created_at" : "2013-09-13 05:32:50 +0000",
  "in_reply_to_screen_name" : "AustinSeraphin",
  "in_reply_to_user_id_str" : "16393800",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    }, {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 43, 51 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378389994680754177",
  "geo" : { },
  "id_str" : "378390214181273600",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking totally this. Smells funny. \/cc @patio11",
  "id" : 378390214181273600,
  "in_reply_to_status_id" : 378389994680754177,
  "created_at" : "2013-09-13 05:30:31 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 0, 8 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378384654023159808",
  "geo" : { },
  "id_str" : "378387232559599616",
  "in_reply_to_user_id" : 20844341,
  "text" : "@patio11 oof to both comments and article :\/",
  "id" : 378387232559599616,
  "in_reply_to_status_id" : 378384654023159808,
  "created_at" : "2013-09-13 05:18:40 +0000",
  "in_reply_to_screen_name" : "patio11",
  "in_reply_to_user_id_str" : "20844341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/UxQKVA5e2B",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=mbyzgeee2mg",
      "display_url" : "youtube.com\/watch?v=mbyzge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378383623432323072",
  "text" : "\"Technolojai\" https:\/\/t.co\/UxQKVA5e2B",
  "id" : 378383623432323072,
  "created_at" : "2013-09-13 05:04:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 0, 15 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378370493373755392",
  "geo" : { },
  "id_str" : "378381020120117248",
  "in_reply_to_user_id" : 16393800,
  "text" : "@AustinSeraphin off the top of my head at 1AM, no! I can ask around though.",
  "id" : 378381020120117248,
  "in_reply_to_status_id" : 378370493373755392,
  "created_at" : "2013-09-13 04:53:59 +0000",
  "in_reply_to_screen_name" : "AustinSeraphin",
  "in_reply_to_user_id_str" : "16393800",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378359068634533888",
  "geo" : { },
  "id_str" : "378359515705397248",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan Thanks :D",
  "id" : 378359515705397248,
  "in_reply_to_status_id" : 378359068634533888,
  "created_at" : "2013-09-13 03:28:32 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378359105343086592",
  "geo" : { },
  "id_str" : "378359321681088512",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr Surprised there's no internal visibility for this - shame those who aren't up to date.",
  "id" : 378359321681088512,
  "in_reply_to_status_id" : 378359105343086592,
  "created_at" : "2013-09-13 03:27:46 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378358767831617536",
  "geo" : { },
  "id_str" : "378358956042620928",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr is *everyone* running it? Sounds like it might be opt-in only.",
  "id" : 378358956042620928,
  "in_reply_to_status_id" : 378358767831617536,
  "created_at" : "2013-09-13 03:26:19 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Warshak",
      "screen_name" : "iwarshak",
      "indices" : [ 0, 9 ],
      "id_str" : "892371",
      "id" : 892371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378358137981378562",
  "geo" : { },
  "id_str" : "378358702035587073",
  "in_reply_to_user_id" : 892371,
  "text" : "@iwarshak Just installed in 2-3 mins? I think the bottles are way better.",
  "id" : 378358702035587073,
  "in_reply_to_status_id" : 378358137981378562,
  "created_at" : "2013-09-13 03:25:18 +0000",
  "in_reply_to_screen_name" : "iwarshak",
  "in_reply_to_user_id_str" : "892371",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378358191131615232",
  "geo" : { },
  "id_str" : "378358465883680768",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr also mind you with 40 people this is way easier...than 209 :)",
  "id" : 378358465883680768,
  "in_reply_to_status_id" : 378358191131615232,
  "created_at" : "2013-09-13 03:24:22 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378358191131615232",
  "geo" : { },
  "id_str" : "378358391485116416",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr How often? And for what reasons? Java security problems, etc? Is there a way to figure out who's not upgraded (potentially a hole?)",
  "id" : 378358391485116416,
  "in_reply_to_status_id" : 378358191131615232,
  "created_at" : "2013-09-13 03:24:04 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378357375796641792",
  "geo" : { },
  "id_str" : "378358035116064768",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr i think for security policy\/checks it makes sense. Curious to hear github's approach on this actually - is there a forced upgrade?",
  "id" : 378358035116064768,
  "in_reply_to_status_id" : 378357375796641792,
  "created_at" : "2013-09-13 03:22:39 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Warshak",
      "screen_name" : "iwarshak",
      "indices" : [ 0, 9 ],
      "id_str" : "892371",
      "id" : 892371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378357769344008192",
  "geo" : { },
  "id_str" : "378357882103681024",
  "in_reply_to_user_id" : 892371,
  "text" : "@iwarshak Fuck! Thanks.",
  "id" : 378357882103681024,
  "in_reply_to_status_id" : 378357769344008192,
  "created_at" : "2013-09-13 03:22:03 +0000",
  "in_reply_to_screen_name" : "iwarshak",
  "in_reply_to_user_id_str" : "892371",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378356826267340800",
  "geo" : { },
  "id_str" : "378357210750783488",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr you're barking up the wrong tree :) I'm all for automation but I don't see this as a worthy problem. Builds, deploys, sure.",
  "id" : 378357210750783488,
  "in_reply_to_status_id" : 378356826267340800,
  "created_at" : "2013-09-13 03:19:23 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378356150300708864",
  "geo" : { },
  "id_str" : "378356579105382400",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr really the 'automation' I should have had in place is time machine. :(",
  "id" : 378356579105382400,
  "in_reply_to_status_id" : 378356150300708864,
  "created_at" : "2013-09-13 03:16:52 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378356150300708864",
  "geo" : { },
  "id_str" : "378356254147489792",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr I've had to do this three times total in almost 2 years...doesn't seem worth it. Also, it took 5-10 minutes.",
  "id" : 378356254147489792,
  "in_reply_to_status_id" : 378356150300708864,
  "created_at" : "2013-09-13 03:15:35 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378355870385451008",
  "geo" : { },
  "id_str" : "378356035003494400",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr not a fan of puppet\/boxen.",
  "id" : 378356035003494400,
  "in_reply_to_status_id" : 378355870385451008,
  "created_at" : "2013-09-13 03:14:42 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bipolar Fleece",
      "screen_name" : "porkbelt",
      "indices" : [ 0, 9 ],
      "id_str" : "614019653",
      "id" : 614019653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378355321116188672",
  "geo" : { },
  "id_str" : "378355634128687104",
  "in_reply_to_user_id" : 614019653,
  "text" : "@porkbelt Did ya hear about it on The Hacker News?",
  "id" : 378355634128687104,
  "in_reply_to_status_id" : 378355321116188672,
  "created_at" : "2013-09-13 03:13:07 +0000",
  "in_reply_to_screen_name" : "porkbelt",
  "in_reply_to_user_id_str" : "614019653",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378355454444728320",
  "text" : "LOL TTYL $ brew install ack git memcached mysql postgresql tree redis rbenv wget zsh",
  "id" : 378355454444728320,
  "created_at" : "2013-09-13 03:12:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin",
      "screen_name" : "plsch",
      "indices" : [ 0, 6 ],
      "id_str" : "61565013",
      "id" : 61565013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378353228951588864",
  "geo" : { },
  "id_str" : "378353792502087680",
  "in_reply_to_user_id" : 61565013,
  "text" : "@plsch one can dream...",
  "id" : 378353792502087680,
  "in_reply_to_status_id" : 378353228951588864,
  "created_at" : "2013-09-13 03:05:48 +0000",
  "in_reply_to_screen_name" : "plsch",
  "in_reply_to_user_id_str" : "61565013",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378352609804824576",
  "text" : "`gem push` is on OSX 10.8 fresh installs, and that's still very hard to believe...",
  "id" : 378352609804824576,
  "created_at" : "2013-09-13 03:01:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike MacDonald",
      "screen_name" : "Crazy_MYKL",
      "indices" : [ 0, 11 ],
      "id_str" : "707774726",
      "id" : 707774726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378351131195621376",
  "geo" : { },
  "id_str" : "378351408342265856",
  "in_reply_to_user_id" : 707774726,
  "text" : "@Crazy_MYKL despite doing iOS development for a year my brain does not think that way (yet)",
  "id" : 378351408342265856,
  "in_reply_to_status_id" : 378351131195621376,
  "created_at" : "2013-09-13 02:56:19 +0000",
  "in_reply_to_screen_name" : "Crazy_MYKL",
  "in_reply_to_user_id_str" : "707774726",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobi L\u00FCtke",
      "screen_name" : "tobi",
      "indices" : [ 0, 5 ],
      "id_str" : "676573",
      "id" : 676573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378347203263479808",
  "geo" : { },
  "id_str" : "378350746288148480",
  "in_reply_to_user_id" : 676573,
  "text" : "@tobi Ironically, I want to share this on Facebook too, but I feel that would be missing the point...",
  "id" : 378350746288148480,
  "in_reply_to_status_id" : 378347203263479808,
  "created_at" : "2013-09-13 02:53:41 +0000",
  "in_reply_to_screen_name" : "tobi",
  "in_reply_to_user_id_str" : "676573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Quint",
      "screen_name" : "aq",
      "indices" : [ 0, 3 ],
      "id_str" : "1178441",
      "id" : 1178441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378348119161053184",
  "geo" : { },
  "id_str" : "378349239182446592",
  "in_reply_to_user_id" : 1178441,
  "text" : "@aq Congrats man!!",
  "id" : 378349239182446592,
  "in_reply_to_status_id" : 378348119161053184,
  "created_at" : "2013-09-13 02:47:42 +0000",
  "in_reply_to_screen_name" : "aq",
  "in_reply_to_user_id_str" : "1178441",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 8, 23 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "The Buffalo News",
      "screen_name" : "TheBuffaloNews",
      "indices" : [ 45, 60 ],
      "id_str" : "43805270",
      "id" : 43805270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/JjLoWmYSlH",
      "expanded_url" : "http:\/\/www.buffalonews.com\/business\/ruby-programming-conference-set-20130911",
      "display_url" : "buffalonews.com\/business\/ruby-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378349132995244033",
  "text" : "Booyah! @nickelcityruby had a little spot in @TheBuffaloNews today: http:\/\/t.co\/JjLoWmYSlH (Please ignore huge interstitial ad...)",
  "id" : 378349132995244033,
  "created_at" : "2013-09-13 02:47:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobi L\u00FCtke",
      "screen_name" : "tobi",
      "indices" : [ 50, 55 ],
      "id_str" : "676573",
      "id" : 676573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/ZzggYrAPHz",
      "expanded_url" : "http:\/\/www.waitbutwhy.com\/2013\/09\/why-generation-y-yuppies-are-unhappy.html?spref=tw",
      "display_url" : "waitbutwhy.com\/2013\/09\/why-ge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378348216049086464",
  "text" : "\"You're not special.\" http:\/\/t.co\/ZzggYrAPHz (via @tobi)",
  "id" : 378348216049086464,
  "created_at" : "2013-09-13 02:43:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378344981049925632",
  "geo" : { },
  "id_str" : "378345697201750016",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn Scroll up to go \"up\"",
  "id" : 378345697201750016,
  "in_reply_to_status_id" : 378344981049925632,
  "created_at" : "2013-09-13 02:33:38 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/rji0mlIc3E",
      "expanded_url" : "http:\/\/www.crushable.com\/wp-content\/uploads\/2013\/05\/Buster-Bluth.gif",
      "display_url" : "crushable.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "378344963861262336",
  "geo" : { },
  "id_str" : "378345548551450624",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH http:\/\/t.co\/rji0mlIc3E",
  "id" : 378345548551450624,
  "in_reply_to_status_id" : 378344963861262336,
  "created_at" : "2013-09-13 02:33:02 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378344750912241664",
  "text" : "Proud that I use \"unnatural\" scrolling on OSX.",
  "id" : 378344750912241664,
  "created_at" : "2013-09-13 02:29:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378329315638652928",
  "geo" : { },
  "id_str" : "378340010333708288",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant \"All I see are fish\"",
  "id" : 378340010333708288,
  "in_reply_to_status_id" : 378329315638652928,
  "created_at" : "2013-09-13 02:11:02 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378320125671526400",
  "geo" : { },
  "id_str" : "378320471193698305",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton this is too early to teach vim",
  "id" : 378320471193698305,
  "in_reply_to_status_id" : 378320125671526400,
  "created_at" : "2013-09-13 00:53:23 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378301078464262144",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded Incoming!",
  "id" : 378301078464262144,
  "created_at" : "2013-09-12 23:36:20 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Odin Dutton",
      "screen_name" : "twe4ked",
      "indices" : [ 0, 8 ],
      "id_str" : "5172201",
      "id" : 5172201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378286671545909248",
  "geo" : { },
  "id_str" : "378288515517136896",
  "in_reply_to_user_id" : 5172201,
  "text" : "@twe4ked Flat earth society!!!",
  "id" : 378288515517136896,
  "in_reply_to_status_id" : 378286671545909248,
  "created_at" : "2013-09-12 22:46:25 +0000",
  "in_reply_to_screen_name" : "twe4ked",
  "in_reply_to_user_id_str" : "5172201",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 3, 17 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378284855013810176",
  "text" : "RT @garybernhardt: Stop whining. E-notes accepted.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378284732653391872",
    "text" : "Stop whining. E-notes accepted.",
    "id" : 378284732653391872,
    "created_at" : "2013-09-12 22:31:23 +0000",
    "user" : {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "protected" : false,
      "id_str" : "809685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1170938305\/twitter_headshot_normal.png",
      "id" : 809685,
      "verified" : false
    }
  },
  "id" : 378284855013810176,
  "created_at" : "2013-09-12 22:31:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Perriault",
      "screen_name" : "n1k0",
      "indices" : [ 3, 8 ],
      "id_str" : "6619162",
      "id" : 6619162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/xO3tZMpznV",
      "expanded_url" : "https:\/\/i.cloudup.com\/YTMd2VkRWl-2000x2000.jpeg",
      "display_url" : "i.cloudup.com\/YTMd2VkRWl-200\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378284770863505409",
  "text" : "RT @n1k0: oh dear https:\/\/t.co\/xO3tZMpznV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 31 ],
        "url" : "https:\/\/t.co\/xO3tZMpznV",
        "expanded_url" : "https:\/\/i.cloudup.com\/YTMd2VkRWl-2000x2000.jpeg",
        "display_url" : "i.cloudup.com\/YTMd2VkRWl-200\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "378280950045483008",
    "text" : "oh dear https:\/\/t.co\/xO3tZMpznV",
    "id" : 378280950045483008,
    "created_at" : "2013-09-12 22:16:21 +0000",
    "user" : {
      "name" : "Nicolas Perriault",
      "screen_name" : "n1k0",
      "protected" : false,
      "id_str" : "6619162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570640187156209664\/YxHJxjkK_normal.png",
      "id" : 6619162,
      "verified" : false
    }
  },
  "id" : 378284770863505409,
  "created_at" : "2013-09-12 22:31:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Millions",
      "screen_name" : "evil_trout",
      "indices" : [ 0, 11 ],
      "id_str" : "2494449480",
      "id" : 2494449480
    }, {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 12, 25 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378282472426831873",
  "geo" : { },
  "id_str" : "378282979228778497",
  "in_reply_to_user_id" : 16712921,
  "text" : "@evil_trout @codinghorror what hosers",
  "id" : 378282979228778497,
  "in_reply_to_status_id" : 378282472426831873,
  "created_at" : "2013-09-12 22:24:25 +0000",
  "in_reply_to_screen_name" : "eviltrout",
  "in_reply_to_user_id_str" : "16712921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/378282499106807808\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/z4zwQrW0uN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT_t7cBCIAAVNNb.jpg",
      "id_str" : "378282499111002112",
      "id" : 378282499111002112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT_t7cBCIAAVNNb.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/z4zwQrW0uN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378282499106807808",
  "text" : "Whelp, this is the first time I've seen this neato spinny globe animation on OSX... http:\/\/t.co\/z4zwQrW0uN",
  "id" : 378282499106807808,
  "created_at" : "2013-09-12 22:22:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    }, {
      "name" : "Dean Parry",
      "screen_name" : "deanparry",
      "indices" : [ 8, 18 ],
      "id_str" : "30320327",
      "id" : 30320327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378280315367616512",
  "geo" : { },
  "id_str" : "378280758600691712",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes @DeanParry Fuck. So hard restarting is a bad idea at this point probably?",
  "id" : 378280758600691712,
  "in_reply_to_status_id" : 378280315367616512,
  "created_at" : "2013-09-12 22:15:35 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378279851020410880",
  "text" : "How long does Disk Utility's Repair Disk usually take? 120GB partition has been beachballing for 6+ hours.",
  "id" : 378279851020410880,
  "created_at" : "2013-09-12 22:11:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378276899124158464",
  "text" : "RT @coworkbuffalo: What has a sans-serif font in its logo and 5 pounds of Stumptown coffee to grind and brew over the next few weeks? THIS \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378114689588154368",
    "text" : "What has a sans-serif font in its logo and 5 pounds of Stumptown coffee to grind and brew over the next few weeks? THIS SPACE.",
    "id" : 378114689588154368,
    "created_at" : "2013-09-12 11:15:41 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 378276899124158464,
  "created_at" : "2013-09-12 22:00:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 0, 6 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378267321900343296",
  "geo" : { },
  "id_str" : "378267872855732224",
  "in_reply_to_user_id" : 8000842,
  "text" : "@tpope Did I Twerk That?",
  "id" : 378267872855732224,
  "in_reply_to_status_id" : 378267321900343296,
  "created_at" : "2013-09-12 21:24:23 +0000",
  "in_reply_to_screen_name" : "tpope",
  "in_reply_to_user_id_str" : "8000842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Downie",
      "screen_name" : "richdownie",
      "indices" : [ 3, 14 ],
      "id_str" : "10774712",
      "id" : 10774712
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 16, 31 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rustbelt",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378267231706025984",
  "text" : "RT @richdownie: @nickelcityruby  \nIt's happening. 8 days. \n#rustbelt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 0, 15 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rustbelt",
        "indices" : [ 43, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378265602034778112",
    "in_reply_to_user_id" : 1067596351,
    "text" : "@nickelcityruby  \nIt's happening. 8 days. \n#rustbelt",
    "id" : 378265602034778112,
    "created_at" : "2013-09-12 21:15:22 +0000",
    "in_reply_to_screen_name" : "nickelcityruby",
    "in_reply_to_user_id_str" : "1067596351",
    "user" : {
      "name" : "Rich Downie",
      "screen_name" : "richdownie",
      "protected" : false,
      "id_str" : "10774712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558639851176603649\/3qXKrGpA_normal.jpeg",
      "id" : 10774712,
      "verified" : false
    }
  },
  "id" : 378267231706025984,
  "created_at" : "2013-09-12 21:21:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378262315121905664",
  "text" : "Can I trade some shares for Failwhale? That's got to be worth something.",
  "id" : 378262315121905664,
  "created_at" : "2013-09-12 21:02:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "wolax",
      "indices" : [ 0, 6 ],
      "id_str" : "8029562",
      "id" : 8029562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378257055338868736",
  "geo" : { },
  "id_str" : "378258123644866560",
  "in_reply_to_user_id" : 8029562,
  "text" : "@wolax ...how do you plug it into another computer? via usb?",
  "id" : 378258123644866560,
  "in_reply_to_status_id" : 378257055338868736,
  "created_at" : "2013-09-12 20:45:39 +0000",
  "in_reply_to_screen_name" : "wolax",
  "in_reply_to_user_id_str" : "8029562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "wolax",
      "indices" : [ 0, 6 ],
      "id_str" : "8029562",
      "id" : 8029562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378254187361861632",
  "geo" : { },
  "id_str" : "378256640782245888",
  "in_reply_to_user_id" : 8029562,
  "text" : "@wolax Have a link about this?",
  "id" : 378256640782245888,
  "in_reply_to_status_id" : 378254187361861632,
  "created_at" : "2013-09-12 20:39:45 +0000",
  "in_reply_to_screen_name" : "wolax",
  "in_reply_to_user_id_str" : "8029562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1Password",
      "screen_name" : "1Password",
      "indices" : [ 0, 10 ],
      "id_str" : "793926",
      "id" : 793926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378238990123409408",
  "geo" : { },
  "id_str" : "378250940664385536",
  "in_reply_to_user_id" : 793926,
  "text" : "@1Password Not helpful if the disk is basically dead, and it wasn't in Dropbox. Obviously my fault, didn't know I could hook it up there :(",
  "id" : 378250940664385536,
  "in_reply_to_status_id" : 378238990123409408,
  "created_at" : "2013-09-12 20:17:06 +0000",
  "in_reply_to_screen_name" : "1Password",
  "in_reply_to_user_id_str" : "793926",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378246627762659328",
  "geo" : { },
  "id_str" : "378247862166884352",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz nope. :[",
  "id" : 378247862166884352,
  "in_reply_to_status_id" : 378246627762659328,
  "created_at" : "2013-09-12 20:04:52 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1Password",
      "screen_name" : "1Password",
      "indices" : [ 0, 10 ],
      "id_str" : "793926",
      "id" : 793926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378237011577958400",
  "geo" : { },
  "id_str" : "378238299883585536",
  "in_reply_to_user_id" : 793926,
  "text" : "@1Password unless if you keep magical backups of my data, nothing will help",
  "id" : 378238299883585536,
  "in_reply_to_status_id" : 378237011577958400,
  "created_at" : "2013-09-12 19:26:52 +0000",
  "in_reply_to_screen_name" : "1Password",
  "in_reply_to_user_id_str" : "793926",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 39, 54 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/uUDG6iQpoZ",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#travel",
      "display_url" : "nickelcityruby.com\/#travel"
    } ]
  },
  "geo" : { },
  "id_str" : "378233296104083456",
  "text" : "Our group rate hotel is still good for @nickelcityruby. Get yourself a room! http:\/\/t.co\/uUDG6iQpoZ",
  "id" : 378233296104083456,
  "created_at" : "2013-09-12 19:06:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 3, 8 ],
      "id_str" : "33823",
      "id" : 33823
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 27, 42 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "indices" : [ 54, 65 ],
      "id_str" : "1232850504",
      "id" : 1232850504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378227310295392256",
  "text" : "RT @jhsu: glad to supply 3 @nickelcityruby tickets to @gdiBuffalo for a raffle, good luck and hope to see you all there",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 17, 32 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Girl Develop It Bflo",
        "screen_name" : "gdiBuffalo",
        "indices" : [ 44, 55 ],
        "id_str" : "1232850504",
        "id" : 1232850504
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378223499216556032",
    "text" : "glad to supply 3 @nickelcityruby tickets to @gdiBuffalo for a raffle, good luck and hope to see you all there",
    "id" : 378223499216556032,
    "created_at" : "2013-09-12 18:28:03 +0000",
    "user" : {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "protected" : false,
      "id_str" : "33823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448859597818695680\/MySo8-P7_normal.jpeg",
      "id" : 33823,
      "verified" : false
    }
  },
  "id" : 378227310295392256,
  "created_at" : "2013-09-12 18:43:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/4zHtrJZ9YN",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=v5Lmkm5EF5E",
      "display_url" : "youtube.com\/watch?v=v5Lmkm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378222510090641408",
  "text" : "Current status: http:\/\/t.co\/4zHtrJZ9YN",
  "id" : 378222510090641408,
  "created_at" : "2013-09-12 18:24:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo\/Erie Library",
      "screen_name" : "buffalolibrary",
      "indices" : [ 32, 47 ],
      "id_str" : "34322946",
      "id" : 34322946
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 52, 67 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378214835474812928",
  "text" : "All set with our awesome venue, @buffalolibrary for @nickelcityruby. It's conference time!!",
  "id" : 378214835474812928,
  "created_at" : "2013-09-12 17:53:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat McDermott",
      "screen_name" : "nerdofthunder",
      "indices" : [ 0, 14 ],
      "id_str" : "14457987",
      "id" : 14457987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378194804644909056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8889943197, -78.8753845559 ]
  },
  "id_str" : "378197085398786049",
  "in_reply_to_user_id" : 14457987,
  "text" : "@nerdofthunder it is!",
  "id" : 378197085398786049,
  "in_reply_to_status_id" : 378194804644909056,
  "created_at" : "2013-09-12 16:43:06 +0000",
  "in_reply_to_screen_name" : "nerdofthunder",
  "in_reply_to_user_id_str" : "14457987",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378180421621927936",
  "geo" : { },
  "id_str" : "378193118924795904",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting Emailed.",
  "id" : 378193118924795904,
  "in_reply_to_status_id" : 378180421621927936,
  "created_at" : "2013-09-12 16:27:20 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "FastCoLabs",
      "screen_name" : "FastCoLabs",
      "indices" : [ 22, 33 ],
      "id_str" : "1114932710",
      "id" : 1114932710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/aFIvwvPSgv",
      "expanded_url" : "http:\/\/www.fastcolabs.com\/3017170\/how-three-non-designers-made-the-most-beautiful-weather-app-weve-ever-seen",
      "display_url" : "fastcolabs.com\/3017170\/how-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378190240835330048",
  "text" : "RT @kevinpurdy: Up on @FastCoLabs: 3 guys from Troy, NY made \"the most beautiful weather app we've ever seen\": http:\/\/t.co\/aFIvwvPSgv (hint\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FastCoLabs",
        "screen_name" : "FastCoLabs",
        "indices" : [ 6, 17 ],
        "id_str" : "1114932710",
        "id" : 1114932710
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/aFIvwvPSgv",
        "expanded_url" : "http:\/\/www.fastcolabs.com\/3017170\/how-three-non-designers-made-the-most-beautiful-weather-app-weve-ever-seen",
        "display_url" : "fastcolabs.com\/3017170\/how-th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "378180728095141888",
    "text" : "Up on @FastCoLabs: 3 guys from Troy, NY made \"the most beautiful weather app we've ever seen\": http:\/\/t.co\/aFIvwvPSgv (hint: forecast.io)",
    "id" : 378180728095141888,
    "created_at" : "2013-09-12 15:38:06 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 378190240835330048,
  "created_at" : "2013-09-12 16:15:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "matt culpepper",
      "screen_name" : "_mculp",
      "indices" : [ 5, 12 ],
      "id_str" : "21530821",
      "id" : 21530821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378182663808380928",
  "geo" : { },
  "id_str" : "378184065184063489",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh @_mculp Same! Usually just use it to check in quickly, so join\/leaves arent a problem.",
  "id" : 378184065184063489,
  "in_reply_to_status_id" : 378182663808380928,
  "created_at" : "2013-09-12 15:51:22 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Block Club",
      "screen_name" : "BlockClub",
      "indices" : [ 3, 13 ],
      "id_str" : "21003240",
      "id" : 21003240
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 28, 43 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/wY6dXHw6u9",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "378178796370661376",
  "text" : "RT @BlockClub: Next Friday, @nickelcityruby takes #Buffalo! More here: http:\/\/t.co\/wY6dXHw6u9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 13, 28 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 35, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/wY6dXHw6u9",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "378172756002488320",
    "text" : "Next Friday, @nickelcityruby takes #Buffalo! More here: http:\/\/t.co\/wY6dXHw6u9",
    "id" : 378172756002488320,
    "created_at" : "2013-09-12 15:06:25 +0000",
    "user" : {
      "name" : "Block Club",
      "screen_name" : "BlockClub",
      "protected" : false,
      "id_str" : "21003240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1793193474\/bc_icon_normal.png",
      "id" : 21003240,
      "verified" : false
    }
  },
  "id" : 378178796370661376,
  "created_at" : "2013-09-12 15:30:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 35, 50 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/XU2DykyUqu",
      "expanded_url" : "http:\/\/ignitebuffalo.com\/",
      "display_url" : "ignitebuffalo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "378178434075086848",
  "text" : "We're one week away from the first @nickelcityruby event, Ignite Buffalo! It's FREEEEE http:\/\/t.co\/XU2DykyUqu",
  "id" : 378178434075086848,
  "created_at" : "2013-09-12 15:28:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378178048777924608",
  "text" : "Back up an running on a late 2008 15\" Pro. Meanwhile, Disk Utility is beachballing on the busted 10.9 install during a repair. :|",
  "id" : 378178048777924608,
  "created_at" : "2013-09-12 15:27:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/U1fBUeQnGv",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "378176117493858305",
  "text" : "RT @nickelcityruby: We are 8 days away from NickelCityRuby and there are still some tickets available! Get yourself to Buffalo! http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/U1fBUeQnGv",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "378156134009298946",
    "text" : "We are 8 days away from NickelCityRuby and there are still some tickets available! Get yourself to Buffalo! http:\/\/t.co\/U1fBUeQnGv",
    "id" : 378156134009298946,
    "created_at" : "2013-09-12 14:00:22 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 378176117493858305,
  "created_at" : "2013-09-12 15:19:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zachary Gershman",
      "screen_name" : "ZachGersh",
      "indices" : [ 0, 10 ],
      "id_str" : "127905827",
      "id" : 127905827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378155820589916160",
  "geo" : { },
  "id_str" : "378156088580780032",
  "in_reply_to_user_id" : 127905827,
  "text" : "@ZachGersh what a preposterous idea!",
  "id" : 378156088580780032,
  "in_reply_to_status_id" : 378155820589916160,
  "created_at" : "2013-09-12 14:00:11 +0000",
  "in_reply_to_screen_name" : "ZachGersh",
  "in_reply_to_user_id_str" : "127905827",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/378155669167157248\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/oFigZsbr7A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT96k8bCAAA-LjP.jpg",
      "id_str" : "378155668835794944",
      "id" : 378155668835794944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT96k8bCAAA-LjP.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/oFigZsbr7A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378155669167157248",
  "text" : "Current sadness: http:\/\/t.co\/oFigZsbr7A",
  "id" : 378155669167157248,
  "created_at" : "2013-09-12 13:58:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378153055209783297",
  "text" : "There is an alternate universe where I signed into my computer this morning and got amazing breakfast w\/ friends. This is not that universe.",
  "id" : 378153055209783297,
  "created_at" : "2013-09-12 13:48:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deegs",
      "screen_name" : "DieselDeegs",
      "indices" : [ 0, 12 ],
      "id_str" : "45068191",
      "id" : 45068191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378148305454497793",
  "geo" : { },
  "id_str" : "378148478741786624",
  "in_reply_to_user_id" : 45068191,
  "text" : "@DieselDeegs didn\u2019t have a backup. Didn\u2019t even think about it.",
  "id" : 378148478741786624,
  "in_reply_to_status_id" : 378148305454497793,
  "created_at" : "2013-09-12 13:29:57 +0000",
  "in_reply_to_screen_name" : "DieselDeegs",
  "in_reply_to_user_id_str" : "45068191",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378143258536185857",
  "geo" : { },
  "id_str" : "378144967350161409",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden nope. :(",
  "id" : 378144967350161409,
  "in_reply_to_status_id" : 378143258536185857,
  "created_at" : "2013-09-12 13:16:00 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378139157823893504",
  "text" : "And thanks to 1password I am locked out of nearly every account I own. &gt;:|",
  "id" : 378139157823893504,
  "created_at" : "2013-09-12 12:52:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378135218395164673",
  "text" : "This is what I get for upgrading mavericks and just leaving my computer to figure it outz",
  "id" : 378135218395164673,
  "created_at" : "2013-09-12 12:37:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378134946797211648",
  "text" : "Fuck me. Still stuck on the gray screen after a safe boot, single user boot, and NVRAM reset.",
  "id" : 378134946797211648,
  "created_at" : "2013-09-12 12:36:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubynerd",
      "screen_name" : "rubynerd",
      "indices" : [ 0, 9 ],
      "id_str" : "207100150",
      "id" : 207100150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378131543019249664",
  "geo" : { },
  "id_str" : "378131646660104192",
  "in_reply_to_user_id" : 207100150,
  "text" : "@rubynerd any ideas how to get out of this? Logging in won\u2019t work :(",
  "id" : 378131646660104192,
  "in_reply_to_status_id" : 378131543019249664,
  "created_at" : "2013-09-12 12:23:04 +0000",
  "in_reply_to_screen_name" : "rubynerd",
  "in_reply_to_user_id_str" : "207100150",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/378130821179121664\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/ETmd08FEAh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT9j-mKCcAAHfoj.jpg",
      "id_str" : "378130820768100352",
      "id" : 378130820768100352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT9j-mKCcAAHfoj.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/ETmd08FEAh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378130821179121664",
  "text" : "Don\u2019t upgrade to the latest Mavericks release. Stuck on this screen after update and can\u2019t log in now. http:\/\/t.co\/ETmd08FEAh",
  "id" : 378130821179121664,
  "created_at" : "2013-09-12 12:19:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 3, 16 ],
      "id_str" : "5875112",
      "id" : 5875112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/teJPHU2L69",
      "expanded_url" : "http:\/\/pocket.co\/szMJA",
      "display_url" : "pocket.co\/szMJA"
    } ]
  },
  "geo" : { },
  "id_str" : "378025063728951296",
  "text" : "RT @stevenharman: As a soon-to-be-father do a son, THIS: \"Seeing a Woman: A conversation between a father and son.\" http:\/\/t.co\/teJPHU2L69",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/read-it-later-pro\/id309601447?mt=8&uo=4\" rel=\"nofollow\"\u003EPocket for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/teJPHU2L69",
        "expanded_url" : "http:\/\/pocket.co\/szMJA",
        "display_url" : "pocket.co\/szMJA"
      } ]
    },
    "geo" : { },
    "id_str" : "377997120609202176",
    "text" : "As a soon-to-be-father do a son, THIS: \"Seeing a Woman: A conversation between a father and son.\" http:\/\/t.co\/teJPHU2L69",
    "id" : 377997120609202176,
    "created_at" : "2013-09-12 03:28:31 +0000",
    "user" : {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "protected" : false,
      "id_str" : "5875112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459360260528955392\/RKh4M2x2_normal.jpeg",
      "id" : 5875112,
      "verified" : false
    }
  },
  "id" : 378025063728951296,
  "created_at" : "2013-09-12 05:19:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul",
      "screen_name" : "p9k",
      "indices" : [ 3, 7 ],
      "id_str" : "14912665",
      "id" : 14912665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/BXcsvpqkrx",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/worldnews\/comments\/1m74w1\/snowden_releases_information_on_us_giving_israel\/cc6hdof",
      "display_url" : "reddit.com\/r\/worldnews\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377986320330522624",
  "text" : "RT @p9k: Reddit comment summarizes the crimes of the NSA against the American people who fund it: http:\/\/t.co\/BXcsvpqkrx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/BXcsvpqkrx",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/worldnews\/comments\/1m74w1\/snowden_releases_information_on_us_giving_israel\/cc6hdof",
        "display_url" : "reddit.com\/r\/worldnews\/co\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377978373277892608",
    "text" : "Reddit comment summarizes the crimes of the NSA against the American people who fund it: http:\/\/t.co\/BXcsvpqkrx",
    "id" : 377978373277892608,
    "created_at" : "2013-09-12 02:14:01 +0000",
    "user" : {
      "name" : "Paul",
      "screen_name" : "p9k",
      "protected" : false,
      "id_str" : "14912665",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543190714054479872\/UC1YQ8OD_normal.jpeg",
      "id" : 14912665,
      "verified" : false
    }
  },
  "id" : 377986320330522624,
  "created_at" : "2013-09-12 02:45:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377977631649443840",
  "geo" : { },
  "id_str" : "377979686703222786",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant the lizards are rustling today",
  "id" : 377979686703222786,
  "in_reply_to_status_id" : 377977631649443840,
  "created_at" : "2013-09-12 02:19:14 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Nielsen",
      "screen_name" : "xunker",
      "indices" : [ 3, 10 ],
      "id_str" : "3301611",
      "id" : 3301611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377965101606653953",
  "text" : "RT @xunker: A programmers' spouse isn't their \"significant other\", they are their \"most significant bit.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377964803467145216",
    "text" : "A programmers' spouse isn't their \"significant other\", they are their \"most significant bit.\"",
    "id" : 377964803467145216,
    "created_at" : "2013-09-12 01:20:06 +0000",
    "user" : {
      "name" : "Matthew Nielsen",
      "screen_name" : "xunker",
      "protected" : false,
      "id_str" : "3301611",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1689551049\/twitter_normal.png",
      "id" : 3301611,
      "verified" : false
    }
  },
  "id" : 377965101606653953,
  "created_at" : "2013-09-12 01:21:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arseniy Ivanov",
      "screen_name" : "freeatnet",
      "indices" : [ 0, 10 ],
      "id_str" : "17272091",
      "id" : 17272091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/1pgbsZ4S9w",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/09\/12\/opinion\/putin-plea-for-caution-from-russia-on-syria.html?src=twr&_r=4&&pagewanted=print",
      "display_url" : "nytimes.com\/2013\/09\/12\/opi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "377963313230913536",
  "geo" : { },
  "id_str" : "377963376996913152",
  "in_reply_to_user_id" : 17272091,
  "text" : "@freeatnet http:\/\/t.co\/1pgbsZ4S9w",
  "id" : 377963376996913152,
  "in_reply_to_status_id" : 377963313230913536,
  "created_at" : "2013-09-12 01:14:25 +0000",
  "in_reply_to_screen_name" : "freeatnet",
  "in_reply_to_user_id_str" : "17272091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Serwer",
      "screen_name" : "AdamSerwer",
      "indices" : [ 3, 14 ],
      "id_str" : "16326882",
      "id" : 16326882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/tBPbQP56FC",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/09\/12\/opinion\/putin-plea-for-caution-from-russia-on-syria.html?src=twr&_r=3&",
      "display_url" : "nytimes.com\/2013\/09\/12\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377962317213753344",
  "text" : "RT @AdamSerwer: Putin just won the world champion belt in concern trolling http:\/\/t.co\/tBPbQP56FC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/tBPbQP56FC",
        "expanded_url" : "http:\/\/www.nytimes.com\/2013\/09\/12\/opinion\/putin-plea-for-caution-from-russia-on-syria.html?src=twr&_r=3&",
        "display_url" : "nytimes.com\/2013\/09\/12\/opi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377957733451829248",
    "text" : "Putin just won the world champion belt in concern trolling http:\/\/t.co\/tBPbQP56FC",
    "id" : 377957733451829248,
    "created_at" : "2013-09-12 00:52:00 +0000",
    "user" : {
      "name" : "Adam Serwer",
      "screen_name" : "AdamSerwer",
      "protected" : false,
      "id_str" : "16326882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565907134441738240\/RN4zvvqB_normal.png",
      "id" : 16326882,
      "verified" : true
    }
  },
  "id" : 377962317213753344,
  "created_at" : "2013-09-12 01:10:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377962105141358592",
  "text" : "Literal LOL at Putin invoking we're all created equal in the NYT",
  "id" : 377962105141358592,
  "created_at" : "2013-09-12 01:09:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "indices" : [ 3, 15 ],
      "id_str" : "588743",
      "id" : 588743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/BYSFIcJAgT",
      "expanded_url" : "http:\/\/jenmyers.net\/things-ive-learned-in-life.html",
      "display_url" : "jenmyers.net\/things-ive-lea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377959701545099264",
  "text" : "RT @antiheroine: 34 things I've learned in life that I want to tell my daughter. http:\/\/t.co\/BYSFIcJAgT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/BYSFIcJAgT",
        "expanded_url" : "http:\/\/jenmyers.net\/things-ive-learned-in-life.html",
        "display_url" : "jenmyers.net\/things-ive-lea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377957548457877505",
    "text" : "34 things I've learned in life that I want to tell my daughter. http:\/\/t.co\/BYSFIcJAgT",
    "id" : 377957548457877505,
    "created_at" : "2013-09-12 00:51:16 +0000",
    "user" : {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "protected" : false,
      "id_str" : "588743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528165243961102337\/6SEpv7ld_normal.png",
      "id" : 588743,
      "verified" : false
    }
  },
  "id" : 377959701545099264,
  "created_at" : "2013-09-12 00:59:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377938931930902530",
  "geo" : { },
  "id_str" : "377947941324853248",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella \u0CA0_\u0CA0",
  "id" : 377947941324853248,
  "in_reply_to_status_id" : 377938931930902530,
  "created_at" : "2013-09-12 00:13:05 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377947792540332032",
  "text" : "@AlMehltretter break a leg! I need to make it down there sometime.",
  "id" : 377947792540332032,
  "created_at" : "2013-09-12 00:12:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 52, 67 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/jVzH0ylxuE",
      "expanded_url" : "http:\/\/blogs.wsj.com\/speakeasy\/2013\/09\/11\/how-buffalos-lafayette-hotel-went-from-fleabag-to-fabulous\/?mod=WSJ_hpp_MIDDLE_Video_second",
      "display_url" : "blogs.wsj.com\/speakeasy\/2013\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377946980862812160",
  "text" : "Hosting Ignite Buffalo &amp; one of our lunches for @nickelcityruby, The Hotel Lafayette: http:\/\/t.co\/jVzH0ylxuE",
  "id" : 377946980862812160,
  "created_at" : "2013-09-12 00:09:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 48, 63 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377931919625048065",
  "geo" : { },
  "id_str" : "377935469268717568",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting instead how about a reminder for @nickelcityruby ? One week away!!",
  "id" : 377935469268717568,
  "in_reply_to_status_id" : 377931919625048065,
  "created_at" : "2013-09-11 23:23:32 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/xSsfIlJ6ny",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ysmLA5TqbIY",
      "display_url" : "youtube.com\/watch?v=ysmLA5\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "377910345655779328",
  "geo" : { },
  "id_str" : "377911037158105088",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant http:\/\/t.co\/xSsfIlJ6ny",
  "id" : 377911037158105088,
  "in_reply_to_status_id" : 377910345655779328,
  "created_at" : "2013-09-11 21:46:27 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 12, 24 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 25, 38 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377904083161845760",
  "geo" : { },
  "id_str" : "377906853922877440",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @juliepagano @lindseybieda ~5 min drive or 10 min bus ride from downtown, awesome area to explore (and we live there!)",
  "id" : 377906853922877440,
  "in_reply_to_status_id" : 377904083161845760,
  "created_at" : "2013-09-11 21:29:49 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 12, 24 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 25, 38 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/eZDZ0iEMVt",
      "expanded_url" : "http:\/\/www.elmwoodvillage.org\/clientuploads\/Visit_2.0_AS\/EVGuide2012-13.jpg",
      "display_url" : "elmwoodvillage.org\/clientuploads\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "377901480130654208",
  "geo" : { },
  "id_str" : "377903061999423490",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @juliepagano @lindseybieda sounds like some exploring of Elmwood Village is in store... http:\/\/t.co\/eZDZ0iEMVt",
  "id" : 377903061999423490,
  "in_reply_to_status_id" : 377901480130654208,
  "created_at" : "2013-09-11 21:14:45 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "TEDxBuffalo",
      "screen_name" : "TEDxBuffalo",
      "indices" : [ 25, 37 ],
      "id_str" : "140515765",
      "id" : 140515765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/ykx7rcuLs9",
      "expanded_url" : "http:\/\/www.tedxbuffalo.com\/speakers\/",
      "display_url" : "tedxbuffalo.com\/speakers\/"
    } ]
  },
  "geo" : { },
  "id_str" : "377888868621496320",
  "text" : "RT @kevinpurdy: The full @tedxbuffalo list: http:\/\/t.co\/ykx7rcuLs9 15 speakers. 16 people. This is gonna be a thing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TEDxBuffalo",
        "screen_name" : "TEDxBuffalo",
        "indices" : [ 9, 21 ],
        "id_str" : "140515765",
        "id" : 140515765
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/ykx7rcuLs9",
        "expanded_url" : "http:\/\/www.tedxbuffalo.com\/speakers\/",
        "display_url" : "tedxbuffalo.com\/speakers\/"
      } ]
    },
    "geo" : { },
    "id_str" : "377888512085090304",
    "text" : "The full @tedxbuffalo list: http:\/\/t.co\/ykx7rcuLs9 15 speakers. 16 people. This is gonna be a thing.",
    "id" : 377888512085090304,
    "created_at" : "2013-09-11 20:16:56 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 377888868621496320,
  "created_at" : "2013-09-11 20:18:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flip Sasser",
      "screen_name" : "flipsasser",
      "indices" : [ 13, 24 ],
      "id_str" : "9144132",
      "id" : 9144132
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 38, 53 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/CPHL5nPJrn",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#schedule",
      "display_url" : "nickelcityruby.com\/#schedule"
    } ]
  },
  "geo" : { },
  "id_str" : "377887863242637312",
  "text" : "Happy to say @flipsasser is headed to @nickelcityruby next week! http:\/\/t.co\/CPHL5nPJrn (Have your tickets yet?!)",
  "id" : 377887863242637312,
  "created_at" : "2013-09-11 20:14:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flip Sasser",
      "screen_name" : "flipsasser",
      "indices" : [ 3, 14 ],
      "id_str" : "9144132",
      "id" : 9144132
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 51, 66 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377887700411371520",
  "text" : "RT @flipsasser: Hey so guess what? I'm speaking at @nickelcityruby next weekend. Things you should do:\n\n1. Come hear me speak",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 35, 50 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377886128411803648",
    "text" : "Hey so guess what? I'm speaking at @nickelcityruby next weekend. Things you should do:\n\n1. Come hear me speak",
    "id" : 377886128411803648,
    "created_at" : "2013-09-11 20:07:28 +0000",
    "user" : {
      "name" : "Flip Sasser",
      "screen_name" : "flipsasser",
      "protected" : false,
      "id_str" : "9144132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1516213518\/07813141-BFA8-4953-9CDE-30C6896FBD65_normal",
      "id" : 9144132,
      "verified" : false
    }
  },
  "id" : 377887700411371520,
  "created_at" : "2013-09-11 20:13:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/lIvbkbfC58",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=oavMtUWDBTM",
      "display_url" : "youtube.com\/watch?v=oavMtU\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "377857175546101760",
  "geo" : { },
  "id_str" : "377882671537348609",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k Don't you guys already have an apprenticeship program? http:\/\/t.co\/lIvbkbfC58",
  "id" : 377882671537348609,
  "in_reply_to_status_id" : 377857175546101760,
  "created_at" : "2013-09-11 19:53:44 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Christina DesMarais",
      "screen_name" : "salubriousdish",
      "indices" : [ 56, 71 ],
      "id_str" : "138144382",
      "id" : 138144382
    }, {
      "name" : "Inc. ",
      "screen_name" : "Inc",
      "indices" : [ 77, 81 ],
      "id_str" : "16896485",
      "id" : 16896485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/9Mhz5Bg7Aj",
      "expanded_url" : "http:\/\/www.inc.com\/christina-desmarais\/3-fallacies-about-working-from-home.html",
      "display_url" : "inc.com\/christina-desm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377875171127730176",
  "text" : "RT @dhh: Great review of REMOTE: Office Not Required by @salubriousdish from @inc, http:\/\/t.co\/9Mhz5Bg7Aj - release just 6 weeks away now!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christina DesMarais",
        "screen_name" : "salubriousdish",
        "indices" : [ 47, 62 ],
        "id_str" : "138144382",
        "id" : 138144382
      }, {
        "name" : "Inc. ",
        "screen_name" : "Inc",
        "indices" : [ 68, 72 ],
        "id_str" : "16896485",
        "id" : 16896485
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/9Mhz5Bg7Aj",
        "expanded_url" : "http:\/\/www.inc.com\/christina-desmarais\/3-fallacies-about-working-from-home.html",
        "display_url" : "inc.com\/christina-desm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377874861261352960",
    "text" : "Great review of REMOTE: Office Not Required by @salubriousdish from @inc, http:\/\/t.co\/9Mhz5Bg7Aj - release just 6 weeks away now!",
    "id" : 377874861261352960,
    "created_at" : "2013-09-11 19:22:42 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 377875171127730176,
  "created_at" : "2013-09-11 19:23:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377857711746334720",
  "geo" : { },
  "id_str" : "377857870919790592",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman Yep. :)",
  "id" : 377857870919790592,
  "in_reply_to_status_id" : 377857711746334720,
  "created_at" : "2013-09-11 18:15:11 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 3, 10 ],
      "id_str" : "11322372",
      "id" : 11322372
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 33, 43 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377857769191141376",
  "text" : "RT @holman: Hardly anyone at the @37signals office today. The famously remote company works remote. Not sure what I expected. Actual camp f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 21, 31 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377857711746334720",
    "text" : "Hardly anyone at the @37signals office today. The famously remote company works remote. Not sure what I expected. Actual camp fires, maybe.",
    "id" : 377857711746334720,
    "created_at" : "2013-09-11 18:14:33 +0000",
    "user" : {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "protected" : false,
      "id_str" : "11322372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550019686230794240\/gWlpdYw2_normal.png",
      "id" : 11322372,
      "verified" : false
    }
  },
  "id" : 377857769191141376,
  "created_at" : "2013-09-11 18:14:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/8CR0zGdETk",
      "expanded_url" : "https:\/\/basecamp.com\/verify",
      "display_url" : "basecamp.com\/verify"
    } ]
  },
  "geo" : { },
  "id_str" : "377853766323552256",
  "text" : "RT @37signals: Basecamp: Stronger security with mobile phone verification\nhttps:\/\/t.co\/8CR0zGdETk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/8CR0zGdETk",
        "expanded_url" : "https:\/\/basecamp.com\/verify",
        "display_url" : "basecamp.com\/verify"
      } ]
    },
    "geo" : { },
    "id_str" : "377828545264766976",
    "text" : "Basecamp: Stronger security with mobile phone verification\nhttps:\/\/t.co\/8CR0zGdETk",
    "id" : 377828545264766976,
    "created_at" : "2013-09-11 16:18:39 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 377853766323552256,
  "created_at" : "2013-09-11 17:58:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377843019921489920",
  "geo" : { },
  "id_str" : "377843463024156672",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil Should have credited you, sorry!",
  "id" : 377843463024156672,
  "in_reply_to_status_id" : 377843019921489920,
  "created_at" : "2013-09-11 17:17:56 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/AG1CYfWJnW",
      "expanded_url" : "http:\/\/html9responsiveboilerstrapjs.com\/",
      "display_url" : "html9responsiveboilerstrapjs.com"
    } ]
  },
  "geo" : { },
  "id_str" : "377842803281125376",
  "text" : "\"It works in RubeGoldberg 2.2 but will not autocompile freeway buttmonkey merge svn commitshare javahunk.\" http:\/\/t.co\/AG1CYfWJnW",
  "id" : 377842803281125376,
  "created_at" : "2013-09-11 17:15:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Feathers",
      "screen_name" : "mfeathers",
      "indices" : [ 3, 13 ],
      "id_str" : "14253068",
      "id" : 14253068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377835390171758594",
  "text" : "RT @mfeathers: It would be cool if there was a bakery called 'Carbs Against Humanity'",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377835253177782272",
    "text" : "It would be cool if there was a bakery called 'Carbs Against Humanity'",
    "id" : 377835253177782272,
    "created_at" : "2013-09-11 16:45:18 +0000",
    "user" : {
      "name" : "Michael Feathers",
      "screen_name" : "mfeathers",
      "protected" : false,
      "id_str" : "14253068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540680066460434432\/K2Jgz4OQ_normal.jpeg",
      "id" : 14253068,
      "verified" : false
    }
  },
  "id" : 377835390171758594,
  "created_at" : "2013-09-11 16:45:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Evans \u2603",
      "screen_name" : "m_evans10",
      "indices" : [ 0, 10 ],
      "id_str" : "388421834",
      "id" : 388421834
    }, {
      "name" : "Flip Sasser",
      "screen_name" : "flipsasser",
      "indices" : [ 11, 22 ],
      "id_str" : "9144132",
      "id" : 9144132
    }, {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 28, 38 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377794673101651968",
  "geo" : { },
  "id_str" : "377801205788835840",
  "in_reply_to_user_id" : 388421834,
  "text" : "@m_evans10 @flipsasser yes, @confreaks will be here!",
  "id" : 377801205788835840,
  "in_reply_to_status_id" : 377794673101651968,
  "created_at" : "2013-09-11 14:30:01 +0000",
  "in_reply_to_screen_name" : "m_evans10",
  "in_reply_to_user_id_str" : "388421834",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toronto Ruby Brigade",
      "screen_name" : "torontorb",
      "indices" : [ 18, 28 ],
      "id_str" : "154543290",
      "id" : 154543290
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 91, 106 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377792646934036480",
  "text" : "Big thanks to the @torontorb organizers for having me up yesterday! (and get down here for @nickelcityruby!)",
  "id" : 377792646934036480,
  "created_at" : "2013-09-11 13:56:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matias Korhonen",
      "screen_name" : "matiaskorhonen",
      "indices" : [ 0, 15 ],
      "id_str" : "86729866",
      "id" : 86729866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377779717518426112",
  "geo" : { },
  "id_str" : "377791278324277248",
  "in_reply_to_user_id" : 86729866,
  "text" : "@matiaskorhonen Yep, wasnt sure how to fix. Seemed like a broken CSS page.",
  "id" : 377791278324277248,
  "in_reply_to_status_id" : 377779717518426112,
  "created_at" : "2013-09-11 13:50:34 +0000",
  "in_reply_to_screen_name" : "matiaskorhonen",
  "in_reply_to_user_id_str" : "86729866",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377784446742953985",
  "text" : "RT @kevinpurdy: If I lived in a European worker management game, I could trade a dozen 30-pin connectors for roast meats and breads. Alas, \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377781379167420416",
    "text" : "If I lived in a European worker management game, I could trade a dozen 30-pin connectors for roast meats and breads. Alas, I live just here.",
    "id" : 377781379167420416,
    "created_at" : "2013-09-11 13:11:14 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 377784446742953985,
  "created_at" : "2013-09-11 13:23:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    }, {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 15, 23 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377772759172272128",
  "geo" : { },
  "id_str" : "377773160839798785",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting @paulehr \u201CI\u2019ll sleep when I\u2019m dead\u201D - James Bond",
  "id" : 377773160839798785,
  "in_reply_to_status_id" : 377772759172272128,
  "created_at" : "2013-09-11 12:38:34 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 82, 97 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377771946475552769",
  "text" : "RT @aspleenic: I don't mean to be *that* guy...but if you don't have a ticket for @nickelcityruby you are almost out of time!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 67, 82 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377756388090728448",
    "text" : "I don't mean to be *that* guy...but if you don't have a ticket for @nickelcityruby you are almost out of time!!",
    "id" : 377756388090728448,
    "created_at" : "2013-09-11 11:31:55 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 377771946475552769,
  "created_at" : "2013-09-11 12:33:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew McGregor",
      "screen_name" : "andmcgregor",
      "indices" : [ 3, 15 ],
      "id_str" : "64707168",
      "id" : 64707168
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 37, 52 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377771877890265089",
  "text" : "RT @andmcgregor: Just registered for @nickelcityruby conference!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 20, 35 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377674110639165440",
    "text" : "Just registered for @nickelcityruby conference!",
    "id" : 377674110639165440,
    "created_at" : "2013-09-11 06:04:59 +0000",
    "user" : {
      "name" : "Andrew McGregor",
      "screen_name" : "andmcgregor",
      "protected" : false,
      "id_str" : "64707168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000536130599\/434e52f5a7bff15db94a562ac18d8da4_normal.png",
      "id" : 64707168,
      "verified" : false
    }
  },
  "id" : 377771877890265089,
  "created_at" : "2013-09-11 12:33:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matias Korhonen",
      "screen_name" : "matiaskorhonen",
      "indices" : [ 0, 15 ],
      "id_str" : "86729866",
      "id" : 86729866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377771582451884032",
  "geo" : { },
  "id_str" : "377771776086118400",
  "in_reply_to_user_id" : 86729866,
  "text" : "@matiaskorhonen ah. PR me !",
  "id" : 377771776086118400,
  "in_reply_to_status_id" : 377771582451884032,
  "created_at" : "2013-09-11 12:33:04 +0000",
  "in_reply_to_screen_name" : "matiaskorhonen",
  "in_reply_to_user_id_str" : "86729866",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matias Korhonen",
      "screen_name" : "matiaskorhonen",
      "indices" : [ 0, 15 ],
      "id_str" : "86729866",
      "id" : 86729866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377751332431859712",
  "geo" : { },
  "id_str" : "377771477808197632",
  "in_reply_to_user_id" : 86729866,
  "text" : "@matiaskorhonen been considering just removing this. Been broken for a while :(",
  "id" : 377771477808197632,
  "in_reply_to_status_id" : 377751332431859712,
  "created_at" : "2013-09-11 12:31:53 +0000",
  "in_reply_to_screen_name" : "matiaskorhonen",
  "in_reply_to_user_id_str" : "86729866",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377663591090233344",
  "geo" : { },
  "id_str" : "377664553242624000",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting luckily our ops team is so badass, it\u2019s rarely an issue. When a new iOS drops in a week though\u2026",
  "id" : 377664553242624000,
  "in_reply_to_status_id" : 377663591090233344,
  "created_at" : "2013-09-11 05:27:00 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377662664472002560",
  "text" : "The world has begun to conspire against me sleeping. Strong feelings this will last for several years.",
  "id" : 377662664472002560,
  "created_at" : "2013-09-11 05:19:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 4, 18 ],
      "id_str" : "5795572",
      "id" : 5795572
    }, {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 19, 32 ],
      "id_str" : "5911122",
      "id" : 5911122
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 49, 64 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377509847643590656",
  "text" : "Hey @buffalopundit @ChrisSmithAV, how can we get @nickelcityruby covered in AV's next issue? Emailed events@, no response.",
  "id" : 377509847643590656,
  "created_at" : "2013-09-10 19:12:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick DiRienzo",
      "screen_name" : "nickdirienzo",
      "indices" : [ 0, 13 ],
      "id_str" : "101859945",
      "id" : 101859945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377506753056751616",
  "geo" : { },
  "id_str" : "377509696644476928",
  "in_reply_to_user_id" : 101859945,
  "text" : "@nickdirienzo Nope! Not at all. You can edit who the tickets belong to later, too.",
  "id" : 377509696644476928,
  "in_reply_to_status_id" : 377506753056751616,
  "created_at" : "2013-09-10 19:11:40 +0000",
  "in_reply_to_screen_name" : "nickdirienzo",
  "in_reply_to_user_id_str" : "101859945",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick DiRienzo",
      "screen_name" : "nickdirienzo",
      "indices" : [ 0, 13 ],
      "id_str" : "101859945",
      "id" : 101859945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377504408172388352",
  "geo" : { },
  "id_str" : "377504975208710144",
  "in_reply_to_user_id" : 101859945,
  "text" : "@nickdirienzo We'll accept purchases day of...but you're killing me smalls.",
  "id" : 377504975208710144,
  "in_reply_to_status_id" : 377504408172388352,
  "created_at" : "2013-09-10 18:52:54 +0000",
  "in_reply_to_screen_name" : "nickdirienzo",
  "in_reply_to_user_id_str" : "101859945",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick DiRienzo",
      "screen_name" : "nickdirienzo",
      "indices" : [ 0, 13 ],
      "id_str" : "101859945",
      "id" : 101859945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377501862817050624",
  "geo" : { },
  "id_str" : "377503725201260544",
  "in_reply_to_user_id" : 101859945,
  "text" : "@nickdirienzo Awesome. Let me know what I can do to help.",
  "id" : 377503725201260544,
  "in_reply_to_status_id" : 377501862817050624,
  "created_at" : "2013-09-10 18:47:56 +0000",
  "in_reply_to_screen_name" : "nickdirienzo",
  "in_reply_to_user_id_str" : "101859945",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377497418608041984",
  "geo" : { },
  "id_str" : "377497517618782208",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded ugh!!! why didn't I buy any :(",
  "id" : 377497517618782208,
  "in_reply_to_status_id" : 377497418608041984,
  "created_at" : "2013-09-10 18:23:16 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e3 Conf Videos",
      "screen_name" : "e3_Conf",
      "indices" : [ 0, 8 ],
      "id_str" : "1046993612",
      "id" : 1046993612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377491105844957184",
  "geo" : { },
  "id_str" : "377494677466804225",
  "in_reply_to_user_id" : 1046993612,
  "text" : "@e3_Conf yes, sorry.",
  "id" : 377494677466804225,
  "in_reply_to_status_id" : 377491105844957184,
  "created_at" : "2013-09-10 18:11:59 +0000",
  "in_reply_to_screen_name" : "e3_Conf",
  "in_reply_to_user_id_str" : "1046993612",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377491299051388928",
  "text" : "I can't wait for the first app to steal your fingerprint!",
  "id" : 377491299051388928,
  "created_at" : "2013-09-10 17:58:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HeatherAnneCampbell",
      "screen_name" : "heathercampbell",
      "indices" : [ 3, 19 ],
      "id_str" : "14103834",
      "id" : 14103834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377490054966296576",
  "text" : "RT @heathercampbell: Rich People: Here's your gold iPhone. Poor People: Here's a plastic iPhone wrapped in a Laundry Basket.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377485952655958016",
    "text" : "Rich People: Here's your gold iPhone. Poor People: Here's a plastic iPhone wrapped in a Laundry Basket.",
    "id" : 377485952655958016,
    "created_at" : "2013-09-10 17:37:19 +0000",
    "user" : {
      "name" : "HeatherAnneCampbell",
      "screen_name" : "heathercampbell",
      "protected" : false,
      "id_str" : "14103834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2386053694\/s8e3p8qwztfgoll2mg9l_normal.jpeg",
      "id" : 14103834,
      "verified" : true
    }
  },
  "id" : 377490054966296576,
  "created_at" : "2013-09-10 17:53:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 3, 15 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377481849372540928",
  "text" : "RT @SteveStreza: One week.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/play.google.com\/store\/apps\/details?id=com.dwdesign.tweetings&hl=en\" rel=\"nofollow\"\u003ETweetings for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7933451, -122.3942133 ]
    },
    "id_str" : "377481052479963136",
    "text" : "One week.",
    "id" : 377481052479963136,
    "created_at" : "2013-09-10 17:17:50 +0000",
    "user" : {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "protected" : false,
      "id_str" : "658643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540811650727550976\/b7RvPDiF_normal.jpeg",
      "id" : 658643,
      "verified" : false
    }
  },
  "id" : 377481849372540928,
  "created_at" : "2013-09-10 17:21:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/XnjsTtujwj",
      "expanded_url" : "https:\/\/github.com\/MiniCodeMonkey\/Sophie-Tracker-3000",
      "display_url" : "github.com\/MiniCodeMonkey\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377468829934186496",
  "text" : "Crazy smart newborn data tracking. Thinking of wiring this up... https:\/\/t.co\/XnjsTtujwj",
  "id" : 377468829934186496,
  "created_at" : "2013-09-10 16:29:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toronto Ruby Brigade",
      "screen_name" : "torontorb",
      "indices" : [ 45, 55 ],
      "id_str" : "154543290",
      "id" : 154543290
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 78, 93 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377457841193226240",
  "text" : "Excited to head up to Toronto today to speak @torontorb...and yell more about @nickelcityruby!",
  "id" : 377457841193226240,
  "created_at" : "2013-09-10 15:45:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick DiRienzo",
      "screen_name" : "nickdirienzo",
      "indices" : [ 0, 13 ],
      "id_str" : "101859945",
      "id" : 101859945
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 29, 44 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377441382547607553",
  "geo" : { },
  "id_str" : "377442317709242368",
  "in_reply_to_user_id" : 101859945,
  "text" : "@nickdirienzo please mention @nickelcityruby (and the student discount!)",
  "id" : 377442317709242368,
  "in_reply_to_status_id" : 377441382547607553,
  "created_at" : "2013-09-10 14:43:55 +0000",
  "in_reply_to_screen_name" : "nickdirienzo",
  "in_reply_to_user_id_str" : "101859945",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377305451076915202",
  "geo" : { },
  "id_str" : "377305887854952448",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 congrats!! Also, awesome name \uD83D\uDC4D",
  "id" : 377305887854952448,
  "in_reply_to_status_id" : 377305451076915202,
  "created_at" : "2013-09-10 05:41:48 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandor Weisz",
      "screen_name" : "santheo",
      "indices" : [ 0, 8 ],
      "id_str" : "755414",
      "id" : 755414
    }, {
      "name" : "BornYet",
      "screen_name" : "bornyet",
      "indices" : [ 20, 28 ],
      "id_str" : "48389133",
      "id" : 48389133
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377277678174216192",
  "in_reply_to_user_id" : 755414,
  "text" : "@santheo Thanks for @bornyet. Posted to \/r\/predaddit, hopefully this catches on! :)",
  "id" : 377277678174216192,
  "created_at" : "2013-09-10 03:49:42 +0000",
  "in_reply_to_screen_name" : "santheo",
  "in_reply_to_user_id_str" : "755414",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377269830987943936",
  "geo" : { },
  "id_str" : "377272016438448128",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule Curious, what's next? :)",
  "id" : 377272016438448128,
  "in_reply_to_status_id" : 377269830987943936,
  "created_at" : "2013-09-10 03:27:12 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ren\u00E9e H.",
      "screen_name" : "gigglegirl4e",
      "indices" : [ 0, 13 ],
      "id_str" : "133486420",
      "id" : 133486420
    }, {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 14, 27 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377269818090868736",
  "geo" : { },
  "id_str" : "377270394303967232",
  "in_reply_to_user_id" : 133486420,
  "text" : "@gigglegirl4e @lindseybieda no, in fact they are awesome, and kill spiders.",
  "id" : 377270394303967232,
  "in_reply_to_status_id" : 377269818090868736,
  "created_at" : "2013-09-10 03:20:46 +0000",
  "in_reply_to_screen_name" : "gigglegirl4e",
  "in_reply_to_user_id_str" : "133486420",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/pus5n5qTdK",
      "expanded_url" : "http:\/\/is.babyq.bornyet.com\/",
      "display_url" : "is.babyq.bornyet.com"
    } ]
  },
  "geo" : { },
  "id_str" : "377269923724005376",
  "text" : "Awesome idea, and I wanted to make something similar. Well worth $10!  http:\/\/t.co\/pus5n5qTdK",
  "id" : 377269923724005376,
  "created_at" : "2013-09-10 03:18:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 29, 44 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "377230344446963712",
  "text" : "We're nearly a week out from @nickelcityruby. Plenty of tickets available still! http:\/\/t.co\/3UAdoKZw7Q",
  "id" : 377230344446963712,
  "created_at" : "2013-09-10 00:41:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/pXS9efj6Ec",
      "expanded_url" : "http:\/\/blog.rubygems.org\/2013\/09\/09\/CVE-2013-4287.html",
      "display_url" : "blog.rubygems.org\/2013\/09\/09\/CVE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377227191265681408",
  "text" : "Upgrade your RubyGems: http:\/\/t.co\/pXS9efj6Ec",
  "id" : 377227191265681408,
  "created_at" : "2013-09-10 00:29:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 3, 11 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/gcmODPqkcQ",
      "expanded_url" : "http:\/\/bit.ly\/CVE-2013-4287",
      "display_url" : "bit.ly\/CVE-2013-4287"
    } ]
  },
  "geo" : { },
  "id_str" : "377226750339461120",
  "text" : "RT @drbrain: If you use bundler to install gems from git you should update RubyGems to fix http:\/\/t.co\/gcmODPqkcQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/gcmODPqkcQ",
        "expanded_url" : "http:\/\/bit.ly\/CVE-2013-4287",
        "display_url" : "bit.ly\/CVE-2013-4287"
      } ]
    },
    "geo" : { },
    "id_str" : "377226724133847040",
    "text" : "If you use bundler to install gems from git you should update RubyGems to fix http:\/\/t.co\/gcmODPqkcQ",
    "id" : 377226724133847040,
    "created_at" : "2013-09-10 00:27:14 +0000",
    "user" : {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "protected" : false,
      "id_str" : "670283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472446327373053952\/oJXOO4GL_normal.jpeg",
      "id" : 670283,
      "verified" : false
    }
  },
  "id" : 377226750339461120,
  "created_at" : "2013-09-10 00:27:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 3, 11 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/gcmODPqkcQ",
      "expanded_url" : "http:\/\/bit.ly\/CVE-2013-4287",
      "display_url" : "bit.ly\/CVE-2013-4287"
    } ]
  },
  "geo" : { },
  "id_str" : "377226619619799041",
  "text" : "RT @drbrain: RubyGems 2.1.0, 2.0.8, 1.8.26, 1.8.23.1 for CVE-2031-4287, backtracking regexp in version validation: http:\/\/t.co\/gcmODPqkcQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/gcmODPqkcQ",
        "expanded_url" : "http:\/\/bit.ly\/CVE-2013-4287",
        "display_url" : "bit.ly\/CVE-2013-4287"
      } ]
    },
    "geo" : { },
    "id_str" : "377226183597121536",
    "text" : "RubyGems 2.1.0, 2.0.8, 1.8.26, 1.8.23.1 for CVE-2031-4287, backtracking regexp in version validation: http:\/\/t.co\/gcmODPqkcQ",
    "id" : 377226183597121536,
    "created_at" : "2013-09-10 00:25:05 +0000",
    "user" : {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "protected" : false,
      "id_str" : "670283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472446327373053952\/oJXOO4GL_normal.jpeg",
      "id" : 670283,
      "verified" : false
    }
  },
  "id" : 377226619619799041,
  "created_at" : "2013-09-10 00:26:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377217577241419776",
  "geo" : { },
  "id_str" : "377220794868195328",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz you wouldn't believe the amount of delete requests we get, still. :(",
  "id" : 377220794868195328,
  "in_reply_to_status_id" : 377217577241419776,
  "created_at" : "2013-09-10 00:03:40 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377219950999396352",
  "geo" : { },
  "id_str" : "377220357704282113",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr Yep.",
  "id" : 377220357704282113,
  "in_reply_to_status_id" : 377219950999396352,
  "created_at" : "2013-09-10 00:01:56 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377204559807934465",
  "geo" : { },
  "id_str" : "377217747823783936",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr I got nothing!",
  "id" : 377217747823783936,
  "in_reply_to_status_id" : 377204559807934465,
  "created_at" : "2013-09-09 23:51:34 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/y5PiWafNNx",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=oavMtUWDBTM&desktop_uri=%2Fwatch%3Fv%3DoavMtUWDBTM",
      "display_url" : "m.youtube.com\/watch?v=oavMtU\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "377172568706265089",
  "geo" : { },
  "id_str" : "377174015682826241",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo 1. Woo 2. Woo!! http:\/\/t.co\/y5PiWafNNx",
  "id" : 377174015682826241,
  "in_reply_to_status_id" : 377172568706265089,
  "created_at" : "2013-09-09 20:57:47 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/cQtvu7uXFT",
      "expanded_url" : "http:\/\/docs.rubygems.org",
      "display_url" : "docs.rubygems.org"
    }, {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/2tVaQ2zStD",
      "expanded_url" : "http:\/\/guides.rubygems.org",
      "display_url" : "guides.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "377171313959256064",
  "text" : "Super happy that http:\/\/t.co\/cQtvu7uXFT is dead today... viva la http:\/\/t.co\/2tVaQ2zStD !",
  "id" : 377171313959256064,
  "created_at" : "2013-09-09 20:47:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377153964044587008",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt Haha, far from it. Sounds like \"World's Best Hot Dog\"",
  "id" : 377153964044587008,
  "created_at" : "2013-09-09 19:38:06 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Aimonetti",
      "screen_name" : "mattetti",
      "indices" : [ 0, 9 ],
      "id_str" : "16476741",
      "id" : 16476741
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 10, 25 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "in_reply_to_status_id_str" : "377141556371021824",
  "geo" : { },
  "id_str" : "377144101348462592",
  "in_reply_to_user_id" : 16476741,
  "text" : "@mattetti @nickelcityruby 9\/20-21 http:\/\/t.co\/3UAdoKZw7Q (events on 9\/19 and 9\/22 as well!)",
  "id" : 377144101348462592,
  "in_reply_to_status_id" : 377141556371021824,
  "created_at" : "2013-09-09 18:58:55 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 0, 8 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377133503143354368",
  "geo" : { },
  "id_str" : "377133693669605377",
  "in_reply_to_user_id" : 670283,
  "text" : "@drbrain SHIP IT",
  "id" : 377133693669605377,
  "in_reply_to_status_id" : 377133503143354368,
  "created_at" : "2013-09-09 18:17:34 +0000",
  "in_reply_to_screen_name" : "drbrain",
  "in_reply_to_user_id_str" : "670283",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 3, 11 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/rh5Yc8hoA4",
      "expanded_url" : "http:\/\/docs.rubygems.org",
      "display_url" : "docs.rubygems.org"
    }, {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/nZeP221QX1",
      "expanded_url" : "http:\/\/guides.rubygems.org",
      "display_url" : "guides.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "377133666666704896",
  "text" : "RT @drbrain: Today's TODO list: RubyGems 2.1, formally retire http:\/\/t.co\/rh5Yc8hoA4 in favor of http:\/\/t.co\/nZeP221QX1, [REDACTED]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/rh5Yc8hoA4",
        "expanded_url" : "http:\/\/docs.rubygems.org",
        "display_url" : "docs.rubygems.org"
      }, {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/nZeP221QX1",
        "expanded_url" : "http:\/\/guides.rubygems.org",
        "display_url" : "guides.rubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "377133503143354368",
    "text" : "Today's TODO list: RubyGems 2.1, formally retire http:\/\/t.co\/rh5Yc8hoA4 in favor of http:\/\/t.co\/nZeP221QX1, [REDACTED]",
    "id" : 377133503143354368,
    "created_at" : "2013-09-09 18:16:48 +0000",
    "user" : {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "protected" : false,
      "id_str" : "670283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472446327373053952\/oJXOO4GL_normal.jpeg",
      "id" : 670283,
      "verified" : false
    }
  },
  "id" : 377133666666704896,
  "created_at" : "2013-09-09 18:17:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Aimonetti",
      "screen_name" : "mattetti",
      "indices" : [ 0, 9 ],
      "id_str" : "16476741",
      "id" : 16476741
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 50, 65 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377131967713923072",
  "geo" : { },
  "id_str" : "377132633567662082",
  "in_reply_to_user_id" : 16476741,
  "text" : "@mattetti nice! going to come over to Buffalo for @nickelcityruby? Not as far as San Diego this time :)",
  "id" : 377132633567662082,
  "in_reply_to_status_id" : 377131967713923072,
  "created_at" : "2013-09-09 18:13:21 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/uK9m9GHlrc",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3615-share-everything",
      "display_url" : "37signals.com\/svn\/posts\/3615\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377130590312476672",
  "text" : "RT @wilderemily: Mentoring as a company value: http:\/\/t.co\/uK9m9GHlrc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/uK9m9GHlrc",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3615-share-everything",
        "display_url" : "37signals.com\/svn\/posts\/3615\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377130077110022144",
    "text" : "Mentoring as a company value: http:\/\/t.co\/uK9m9GHlrc",
    "id" : 377130077110022144,
    "created_at" : "2013-09-09 18:03:11 +0000",
    "user" : {
      "name" : "Emily Triplett Lentz",
      "screen_name" : "emilytlentz",
      "protected" : false,
      "id_str" : "55330075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442792521177894913\/2s9xRuFD_normal.jpeg",
      "id" : 55330075,
      "verified" : false
    }
  },
  "id" : 377130590312476672,
  "created_at" : "2013-09-09 18:05:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 23, 37 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377130134559395842",
  "text" : "Yet another packed day @coworkbuffalo. Love it when the tables are full.",
  "id" : 377130134559395842,
  "created_at" : "2013-09-09 18:03:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377092555491381248",
  "text" : "Sorting through who added me in G+ feels like playing Plinko with friends.",
  "id" : 377092555491381248,
  "created_at" : "2013-09-09 15:34:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 0, 7 ],
      "id_str" : "34953",
      "id" : 34953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377087282110398465",
  "geo" : { },
  "id_str" : "377087744700198913",
  "in_reply_to_user_id" : 34953,
  "text" : "@nathos What's a PC?",
  "id" : 377087744700198913,
  "in_reply_to_status_id" : 377087282110398465,
  "created_at" : "2013-09-09 15:14:58 +0000",
  "in_reply_to_screen_name" : "nathos",
  "in_reply_to_user_id_str" : "34953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 100, 104 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/uFY3qgrppj",
      "expanded_url" : "http:\/\/www.asymco.com\/2013\/09\/09\/game-over\/",
      "display_url" : "asymco.com\/2013\/09\/09\/gam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377086175082582016",
  "text" : "I didn't plan on buying any of the next-gen consoles anyway. Game over: http:\/\/t.co\/uFY3qgrppj (via @rjs)",
  "id" : 377086175082582016,
  "created_at" : "2013-09-09 15:08:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "TEDxBuffalo",
      "screen_name" : "TEDxBuffalo",
      "indices" : [ 59, 71 ],
      "id_str" : "140515765",
      "id" : 140515765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/mEFwdC9hQU",
      "expanded_url" : "http:\/\/www.tedxbuffalo.com\/tedxbuffalo-2013\/attend\/",
      "display_url" : "tedxbuffalo.com\/tedxbuffalo-20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377073662542635008",
  "text" : "RT @kevinpurdy: Now **today** is the last day to apply for @TEDxBuffalo on Oct. 15. Free ticket, but you gotta jump in the pool: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TEDxBuffalo",
        "screen_name" : "TEDxBuffalo",
        "indices" : [ 43, 55 ],
        "id_str" : "140515765",
        "id" : 140515765
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/mEFwdC9hQU",
        "expanded_url" : "http:\/\/www.tedxbuffalo.com\/tedxbuffalo-2013\/attend\/",
        "display_url" : "tedxbuffalo.com\/tedxbuffalo-20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377068352251768833",
    "text" : "Now **today** is the last day to apply for @TEDxBuffalo on Oct. 15. Free ticket, but you gotta jump in the pool: http:\/\/t.co\/mEFwdC9hQU",
    "id" : 377068352251768833,
    "created_at" : "2013-09-09 13:57:55 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 377073662542635008,
  "created_at" : "2013-09-09 14:19:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Corrigan",
      "screen_name" : "madgloryint",
      "indices" : [ 3, 15 ],
      "id_str" : "2169360690",
      "id" : 2169360690
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 36, 51 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Brian Corrigan",
      "screen_name" : "madgloryint",
      "indices" : [ 61, 73 ],
      "id_str" : "2169360690",
      "id" : 2169360690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "meetup",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377050442624024576",
  "text" : "RT @MadGloryInt: Looking forward to @NickelCityRuby with the @MadGloryInt crew. Anybody else heading out to Buffalo? #meetup",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 19, 34 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Brian Corrigan",
        "screen_name" : "madgloryint",
        "indices" : [ 44, 56 ],
        "id_str" : "2169360690",
        "id" : 2169360690
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "meetup",
        "indices" : [ 100, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "376920108418879488",
    "text" : "Looking forward to @NickelCityRuby with the @MadGloryInt crew. Anybody else heading out to Buffalo? #meetup",
    "id" : 376920108418879488,
    "created_at" : "2013-09-09 04:08:51 +0000",
    "user" : {
      "name" : "MadGlory",
      "screen_name" : "madglory",
      "protected" : false,
      "id_str" : "632527417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428559080953626625\/fqZiJ6TQ_normal.png",
      "id" : 632527417,
      "verified" : false
    }
  },
  "id" : 377050442624024576,
  "created_at" : "2013-09-09 12:46:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/QVNUTAoC9V",
      "expanded_url" : "http:\/\/i.imgur.com\/5bYcLPX.png",
      "display_url" : "i.imgur.com\/5bYcLPX.png"
    } ]
  },
  "geo" : { },
  "id_str" : "376919335060520960",
  "text" : "Touchdown on Eve. As for getting back though... http:\/\/t.co\/QVNUTAoC9V",
  "id" : 376919335060520960,
  "created_at" : "2013-09-09 04:05:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 13, 25 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376878599670075393",
  "geo" : { },
  "id_str" : "376898800725422080",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps @juliepagano thanks! :D",
  "id" : 376898800725422080,
  "in_reply_to_status_id" : 376878599670075393,
  "created_at" : "2013-09-09 02:44:11 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376877043083771904",
  "text" : "Lots of hard emails going out tonight. Conferences ain't easy.",
  "id" : 376877043083771904,
  "created_at" : "2013-09-09 01:17:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 0, 8 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376857193191964673",
  "geo" : { },
  "id_str" : "376876885277290496",
  "in_reply_to_user_id" : 15029296,
  "text" : "@zedshaw Yes, seems excessive. I don't object to making packaging approachable for beginners...but in the first parts of the book is much",
  "id" : 376876885277290496,
  "in_reply_to_status_id" : 376857193191964673,
  "created_at" : "2013-09-09 01:17:06 +0000",
  "in_reply_to_screen_name" : "zedshaw",
  "in_reply_to_user_id_str" : "15029296",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 0, 8 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "376856571457708032",
  "geo" : { },
  "id_str" : "376856769332396032",
  "in_reply_to_user_id" : 15029296,
  "text" : "@zedshaw we have hundreds of test gems like this on http:\/\/t.co\/2bA9BVLhWr. So what?",
  "id" : 376856769332396032,
  "in_reply_to_status_id" : 376856571457708032,
  "created_at" : "2013-09-08 23:57:10 +0000",
  "in_reply_to_screen_name" : "zedshaw",
  "in_reply_to_user_id_str" : "15029296",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376824230643396608",
  "geo" : { },
  "id_str" : "376855340068794368",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr there's plenty of tutorials to follow on youtube.",
  "id" : 376855340068794368,
  "in_reply_to_status_id" : 376824230643396608,
  "created_at" : "2013-09-08 23:51:29 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376822696387940354",
  "text" : "KSP is fun, but dear god it's a total bear to run. Turned down graphics settings and it still stutters every 5-10 seconds.",
  "id" : 376822696387940354,
  "created_at" : "2013-09-08 21:41:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 0, 7 ],
      "id_str" : "638323",
      "id" : 638323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376790512306360321",
  "geo" : { },
  "id_str" : "376790811649642496",
  "in_reply_to_user_id" : 638323,
  "text" : "@kneath cool. i'm finding it sucks in low light... going through Understanding Exposure to try and grok it deeper.",
  "id" : 376790811649642496,
  "in_reply_to_status_id" : 376790512306360321,
  "created_at" : "2013-09-08 19:35:04 +0000",
  "in_reply_to_screen_name" : "kneath",
  "in_reply_to_user_id_str" : "638323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 0, 7 ],
      "id_str" : "638323",
      "id" : 638323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376789907152183296",
  "geo" : { },
  "id_str" : "376790332693688320",
  "in_reply_to_user_id" : 638323,
  "text" : "@kneath awesome. are these on manual or auto? Still learning how to use mine.",
  "id" : 376790332693688320,
  "in_reply_to_status_id" : 376789907152183296,
  "created_at" : "2013-09-08 19:33:10 +0000",
  "in_reply_to_screen_name" : "kneath",
  "in_reply_to_user_id_str" : "638323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/gIpmBK9YPy",
      "expanded_url" : "http:\/\/imgur.com\/a\/7fwTG",
      "display_url" : "imgur.com\/a\/7fwTG"
    } ]
  },
  "geo" : { },
  "id_str" : "376780159279316992",
  "text" : "Fun mission to Mun and back today. The facial expressions on Kerbals are hilarious. http:\/\/t.co\/gIpmBK9YPy",
  "id" : 376780159279316992,
  "created_at" : "2013-09-08 18:52:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376692155089051648",
  "geo" : { },
  "id_str" : "376693592816754688",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow Safe travels! We need to talk iOS sometime. :)",
  "id" : 376693592816754688,
  "in_reply_to_status_id" : 376692155089051648,
  "created_at" : "2013-09-08 13:08:45 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 0, 10 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376679765857419264",
  "geo" : { },
  "id_str" : "376690110151933952",
  "in_reply_to_user_id" : 15536268,
  "text" : "@ashfurrow you in Buffalo today? I'd love to buy you some coffee if so!",
  "id" : 376690110151933952,
  "in_reply_to_status_id" : 376679765857419264,
  "created_at" : "2013-09-08 12:54:55 +0000",
  "in_reply_to_screen_name" : "ashfurrow",
  "in_reply_to_user_id_str" : "15536268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "blake",
      "screen_name" : "Leemanish",
      "indices" : [ 3, 13 ],
      "id_str" : "322837809",
      "id" : 322837809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376519196076564480",
  "text" : "RT @Leemanish: Built a TV news desk in the living room. Area wife very upset.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372393680872558592",
    "text" : "Built a TV news desk in the living room. Area wife very upset.",
    "id" : 372393680872558592,
    "created_at" : "2013-08-27 16:22:26 +0000",
    "user" : {
      "name" : "blake",
      "screen_name" : "Leemanish",
      "protected" : false,
      "id_str" : "322837809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1816678062\/01b_normal.jpg",
      "id" : 322837809,
      "verified" : false
    }
  },
  "id" : 376519196076564480,
  "created_at" : "2013-09-08 01:35:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/Kv8BrOzmhn",
      "expanded_url" : "http:\/\/www.recordsale.de\/cdpix\/k\/kenny_loggins-keep_the_fire(1).jpg",
      "display_url" : "recordsale.de\/cdpix\/k\/kenny_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376502809505439744",
  "text" : "Current status: http:\/\/t.co\/Kv8BrOzmhn",
  "id" : 376502809505439744,
  "created_at" : "2013-09-08 00:30:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "indices" : [ 0, 13 ],
      "id_str" : "29200620",
      "id" : 29200620
    }, {
      "name" : "Paul Simpson",
      "screen_name" : "prsimp",
      "indices" : [ 14, 21 ],
      "id_str" : "14789292",
      "id" : 14789292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376440394495430656",
  "geo" : { },
  "id_str" : "376495716928987137",
  "in_reply_to_user_id" : 29200620,
  "text" : "@TheOtherZach @prsimp i hope you'll still make it!",
  "id" : 376495716928987137,
  "in_reply_to_status_id" : 376440394495430656,
  "created_at" : "2013-09-08 00:02:28 +0000",
  "in_reply_to_screen_name" : "TheOtherZach",
  "in_reply_to_user_id_str" : "29200620",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/UKwVXkU1P7",
      "expanded_url" : "http:\/\/dtsironis.net\/posts\/making-engaging-presentations\/",
      "display_url" : "dtsironis.net\/posts\/making-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376495312115757057",
  "text" : "Huge +1 to this post: I usually try to nail down a color scheme + font before starting on slide content. http:\/\/t.co\/UKwVXkU1P7",
  "id" : 376495312115757057,
  "created_at" : "2013-09-08 00:00:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe May",
      "screen_name" : "j0emay",
      "indices" : [ 0, 7 ],
      "id_str" : "22459900",
      "id" : 22459900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376174447666802688",
  "geo" : { },
  "id_str" : "376405527401861120",
  "in_reply_to_user_id" : 22459900,
  "text" : "@j0emay we\u2019ll be ready for launch. Not supporting beta iOS right now.",
  "id" : 376405527401861120,
  "in_reply_to_status_id" : 376174447666802688,
  "created_at" : "2013-09-07 18:04:05 +0000",
  "in_reply_to_screen_name" : "j0emay",
  "in_reply_to_user_id_str" : "22459900",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 12, 27 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Kids Ruby",
      "screen_name" : "KidsRuby",
      "indices" : [ 91, 100 ],
      "id_str" : "238055076",
      "id" : 238055076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376405080020615168",
  "text" : "Pretty sure @nickelcityruby is the only conference to feature someone who learned Ruby via @KidsRuby. Can\u2019t wait to see it!",
  "id" : 376405080020615168,
  "created_at" : "2013-09-07 18:02:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 63, 78 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376403930772959232",
  "text" : "RT @aspleenic: Just finished helping Katie with her slides for @nickelcityruby - minds will be blown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 48, 63 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "376403827701719040",
    "text" : "Just finished helping Katie with her slides for @nickelcityruby - minds will be blown",
    "id" : 376403827701719040,
    "created_at" : "2013-09-07 17:57:20 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 376403930772959232,
  "created_at" : "2013-09-07 17:57:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 9, 22 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/33aYAoRhje",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "376398551737069568",
  "geo" : { },
  "id_str" : "376399126180937728",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale @steveklabnik existing ones too. I\u2019d happily use this for http:\/\/t.co\/33aYAoRhje.",
  "id" : 376399126180937728,
  "in_reply_to_status_id" : 376398551737069568,
  "created_at" : "2013-09-07 17:38:39 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 3, 11 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376397094627840000",
  "text" : "RT @rubiety: Next 12 days: ROC-IAD-IAH-SAN-LAS-IAH-BOS-EWR-IAH-LAS-EWR-BOS-IAH-LAS-CLT-MSY-IAH-BOS-IAD-LAS-IAH-BOS-IAH-MSY-PHL-ROC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "376396170093813760",
    "text" : "Next 12 days: ROC-IAD-IAH-SAN-LAS-IAH-BOS-EWR-IAH-LAS-EWR-BOS-IAH-LAS-CLT-MSY-IAH-BOS-IAD-LAS-IAH-BOS-IAH-MSY-PHL-ROC",
    "id" : 376396170093813760,
    "created_at" : "2013-09-07 17:26:54 +0000",
    "user" : {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "protected" : false,
      "id_str" : "6592472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549691657881264128\/BiVkh3eS_normal.jpeg",
      "id" : 6592472,
      "verified" : false
    }
  },
  "id" : 376397094627840000,
  "created_at" : "2013-09-07 17:30:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376395033345548288",
  "text" : "Oh yes, Stumptown pourover in Buffalo. Where is your Portland now?!",
  "id" : 376395033345548288,
  "created_at" : "2013-09-07 17:22:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Chevalier",
      "screen_name" : "JamesChevalier",
      "indices" : [ 0, 15 ],
      "id_str" : "19874511",
      "id" : 19874511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376357128015200256",
  "geo" : { },
  "id_str" : "376384562081054720",
  "in_reply_to_user_id" : 19874511,
  "text" : "@JamesChevalier cool. Not sure of plans yet but thanks!",
  "id" : 376384562081054720,
  "in_reply_to_status_id" : 376357128015200256,
  "created_at" : "2013-09-07 16:40:47 +0000",
  "in_reply_to_screen_name" : "JamesChevalier",
  "in_reply_to_user_id_str" : "19874511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 64, 79 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/YJWat2Hg3F",
      "expanded_url" : "http:\/\/nickelcityruby.com\/bus\/",
      "display_url" : "nickelcityruby.com\/bus\/"
    } ]
  },
  "geo" : { },
  "id_str" : "376370017970839552",
  "text" : "Ruby Central is helping us bring people from NYC to Buffalo for @nickelcityruby, why aren't you on this? http:\/\/t.co\/YJWat2Hg3F",
  "id" : 376370017970839552,
  "created_at" : "2013-09-07 15:42:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "WindyCityRails",
      "screen_name" : "WindyCityRails",
      "indices" : [ 41, 56 ],
      "id_str" : "16104710",
      "id" : 16104710
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 76, 91 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376369267467239425",
  "text" : "RT @aspleenic: Not sure what to do after @WindyCityRails next week? Come to @nickelcityruby &amp; it will be awesome!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WindyCityRails",
        "screen_name" : "WindyCityRails",
        "indices" : [ 26, 41 ],
        "id_str" : "16104710",
        "id" : 16104710
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 61, 76 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "376368826176118785",
    "text" : "Not sure what to do after @WindyCityRails next week? Come to @nickelcityruby &amp; it will be awesome!",
    "id" : 376368826176118785,
    "created_at" : "2013-09-07 15:38:15 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 376369267467239425,
  "created_at" : "2013-09-07 15:40:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 86, 101 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/0hWijIh9nX",
      "expanded_url" : "http:\/\/bit.ly\/14rVcsz",
      "display_url" : "bit.ly\/14rVcsz"
    } ]
  },
  "geo" : { },
  "id_str" : "376368541659717632",
  "text" : "RT @ashedryden: NYC friends: take a fully loaded, wifi-enabled, power outlet'd bus to @nickelcityruby for $125 included conf ticket: http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 70, 85 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/0hWijIh9nX",
        "expanded_url" : "http:\/\/bit.ly\/14rVcsz",
        "display_url" : "bit.ly\/14rVcsz"
      } ]
    },
    "geo" : { },
    "id_str" : "376314416910045184",
    "text" : "NYC friends: take a fully loaded, wifi-enabled, power outlet'd bus to @nickelcityruby for $125 included conf ticket: http:\/\/t.co\/0hWijIh9nX",
    "id" : 376314416910045184,
    "created_at" : "2013-09-07 12:02:03 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 376368541659717632,
  "created_at" : "2013-09-07 15:37:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 28, 43 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "WickedGoodRuby",
      "screen_name" : "WickedGoodRuby",
      "indices" : [ 55, 70 ],
      "id_str" : "870817116",
      "id" : 870817116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376368531857612800",
  "text" : "RT @aspleenic: So you go to @nickelcityruby then what? @WickedGoodRuby - that's what!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 13, 28 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "WickedGoodRuby",
        "screen_name" : "WickedGoodRuby",
        "indices" : [ 40, 55 ],
        "id_str" : "870817116",
        "id" : 870817116
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "376354621444587521",
    "geo" : { },
    "id_str" : "376355203974316032",
    "in_reply_to_user_id" : 870817116,
    "text" : "So you go to @nickelcityruby then what? @WickedGoodRuby - that's what!!",
    "id" : 376355203974316032,
    "in_reply_to_status_id" : 376354621444587521,
    "created_at" : "2013-09-07 14:44:07 +0000",
    "in_reply_to_screen_name" : "WickedGoodRuby",
    "in_reply_to_user_id_str" : "870817116",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 376368531857612800,
  "created_at" : "2013-09-07 15:37:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 3, 11 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/bascule\/status\/376127225814196224\/photo\/1",
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/Jequ4cGYHo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BThFuAWCcAMwWoA.jpg",
      "id_str" : "376127225554169859",
      "id" : 376127225554169859,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BThFuAWCcAMwWoA.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/Jequ4cGYHo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376136143978635264",
  "text" : "RT @bascule: Github may have a replica of the oval office, but Square has an ice sculpture with an embedded working beer bong: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/bascule\/status\/376127225814196224\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Jequ4cGYHo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BThFuAWCcAMwWoA.jpg",
        "id_str" : "376127225554169859",
        "id" : 376127225554169859,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BThFuAWCcAMwWoA.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/Jequ4cGYHo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "376127225814196224",
    "text" : "Github may have a replica of the oval office, but Square has an ice sculpture with an embedded working beer bong: http:\/\/t.co\/Jequ4cGYHo",
    "id" : 376127225814196224,
    "created_at" : "2013-09-06 23:38:13 +0000",
    "user" : {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "protected" : false,
      "id_str" : "6083342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450061818606522368\/pjDTHFB9_normal.jpeg",
      "id" : 6083342,
      "verified" : false
    }
  },
  "id" : 376136143978635264,
  "created_at" : "2013-09-07 00:13:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9210217751, -78.8801047089 ]
  },
  "id_str" : "376126533208793088",
  "text" : "@juliepagano what is this, a pizza for ants?!",
  "id" : 376126533208793088,
  "created_at" : "2013-09-06 23:35:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 26, 41 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 45, 52 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/376121087022874624\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/uQGjGg8OdK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BThAIsLIIAAal_-.jpg",
      "id_str" : "376121086926397440",
      "id" : 376121086926397440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BThAIsLIIAAal_-.jpg",
      "sizes" : [ {
        "h" : 660,
        "resize" : "fit",
        "w" : 495
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 495
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 495
      } ],
      "display_url" : "pic.twitter.com\/uQGjGg8OdK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376121087022874624",
  "text" : "Getting letterpressed for @nickelcityruby by @zobar2: http:\/\/t.co\/uQGjGg8OdK",
  "id" : 376121087022874624,
  "created_at" : "2013-09-06 23:13:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 78, 85 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/376117006443225088\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/zM207wT77S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTg8bK7IQAA5whK.jpg",
      "id_str" : "376117006371930112",
      "id" : 376117006371930112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTg8bK7IQAA5whK.jpg",
      "sizes" : [ {
        "h" : 660,
        "resize" : "fit",
        "w" : 495
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 495
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 495
      } ],
      "display_url" : "pic.twitter.com\/zM207wT77S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376117074042429440",
  "text" : "RT @nickelcityruby: Preparing something awesome for our attendees! (thanks to @zobar2) http:\/\/t.co\/zM207wT77S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David P Kleinschmidt",
        "screen_name" : "zobar2",
        "indices" : [ 58, 65 ],
        "id_str" : "22627592",
        "id" : 22627592
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/376117006443225088\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/zM207wT77S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BTg8bK7IQAA5whK.jpg",
        "id_str" : "376117006371930112",
        "id" : 376117006371930112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTg8bK7IQAA5whK.jpg",
        "sizes" : [ {
          "h" : 660,
          "resize" : "fit",
          "w" : 495
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 495
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 495
        } ],
        "display_url" : "pic.twitter.com\/zM207wT77S"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "376117006443225088",
    "text" : "Preparing something awesome for our attendees! (thanks to @zobar2) http:\/\/t.co\/zM207wT77S",
    "id" : 376117006443225088,
    "created_at" : "2013-09-06 22:57:36 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 376117074042429440,
  "created_at" : "2013-09-06 22:57:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 3, 15 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376090823672078336",
  "text" : "RT @marcoarment: Are you going to be proud to tell your grandchildren what you did for a living?\n\nWill you look back and say, \u201CI added valu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "376089411865554944",
    "text" : "Are you going to be proud to tell your grandchildren what you did for a living?\n\nWill you look back and say, \u201CI added value to the world\u201D?",
    "id" : 376089411865554944,
    "created_at" : "2013-09-06 21:07:57 +0000",
    "user" : {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "protected" : false,
      "id_str" : "14231571",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1282173124\/untitled-158-2_normal.jpg",
      "id" : 14231571,
      "verified" : false
    }
  },
  "id" : 376090823672078336,
  "created_at" : "2013-09-06 21:13:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 3, 12 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/XYysg6iMmb",
      "expanded_url" : "http:\/\/ignitebuffalo.com\/",
      "display_url" : "ignitebuffalo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "376087377799700481",
  "text" : "RT @sabiddle: Scheduled to talk at http:\/\/t.co\/XYysg6iMmb You should sign up to talk too",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/XYysg6iMmb",
        "expanded_url" : "http:\/\/ignitebuffalo.com\/",
        "display_url" : "ignitebuffalo.com"
      } ]
    },
    "geo" : { },
    "id_str" : "376086793818750977",
    "text" : "Scheduled to talk at http:\/\/t.co\/XYysg6iMmb You should sign up to talk too",
    "id" : 376086793818750977,
    "created_at" : "2013-09-06 20:57:33 +0000",
    "user" : {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "protected" : false,
      "id_str" : "20531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2696016475\/32aa0b0b3249511f0e106601d87bab01_normal.png",
      "id" : 20531902,
      "verified" : false
    }
  },
  "id" : 376087377799700481,
  "created_at" : "2013-09-06 20:59:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 9, 22 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376086211741224961",
  "geo" : { },
  "id_str" : "376086749346156544",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan @steveklabnik I hit favorite so hard on this tweet I wanted to punch my monitor",
  "id" : 376086749346156544,
  "in_reply_to_status_id" : 376086211741224961,
  "created_at" : "2013-09-06 20:57:23 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/G7m2wpFqiu",
      "expanded_url" : "http:\/\/www.theverge.com\/2013\/9\/5\/4698966\/listen-to-vocals-only-track-of-the-beatles-abbey-road-medley",
      "display_url" : "theverge.com\/2013\/9\/5\/46989\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376078986746396672",
  "text" : "Abbey Road with vocals only is a little mind melting: http:\/\/t.co\/G7m2wpFqiu",
  "id" : 376078986746396672,
  "created_at" : "2013-09-06 20:26:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Curry",
      "screen_name" : "adamcurry",
      "indices" : [ 3, 13 ],
      "id_str" : "2062801",
      "id" : 2062801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/z9NIS1z7P0",
      "expanded_url" : "http:\/\/l.curry.com\/4Ro",
      "display_url" : "l.curry.com\/4Ro"
    } ]
  },
  "geo" : { },
  "id_str" : "376074259929387008",
  "text" : "RT @adamcurry: Poll: Majority Of Americans Approve Of Sending Congress To Syria http:\/\/t.co\/z9NIS1z7P0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/curry.com\/\" rel=\"nofollow\"\u003ECart-AC\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/z9NIS1z7P0",
        "expanded_url" : "http:\/\/l.curry.com\/4Ro",
        "display_url" : "l.curry.com\/4Ro"
      } ]
    },
    "geo" : { },
    "id_str" : "376068279535955968",
    "text" : "Poll: Majority Of Americans Approve Of Sending Congress To Syria http:\/\/t.co\/z9NIS1z7P0",
    "id" : 376068279535955968,
    "created_at" : "2013-09-06 19:43:59 +0000",
    "user" : {
      "name" : "Adam Curry",
      "screen_name" : "adamcurry",
      "protected" : false,
      "id_str" : "2062801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526204616979918848\/vx6WS1Rn_normal.png",
      "id" : 2062801,
      "verified" : false
    }
  },
  "id" : 376074259929387008,
  "created_at" : "2013-09-06 20:07:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacobstructionist",
      "screen_name" : "jacobian",
      "indices" : [ 80, 89 ],
      "id_str" : "18824526",
      "id" : 18824526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/TMaJyQfH8r",
      "expanded_url" : "http:\/\/www.chesnok.com\/daily\/2011\/03\/30\/where-meritocracy-fails\/",
      "display_url" : "chesnok.com\/daily\/2011\/03\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376072409293393920",
  "text" : "Really good post on \"meritocracy\" and how it fails: http:\/\/t.co\/TMaJyQfH8r (via @jacobian)",
  "id" : 376072409293393920,
  "created_at" : "2013-09-06 20:00:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 3, 13 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/22udWfvPOT",
      "expanded_url" : "http:\/\/octodex.github.com\/octoliberty\/",
      "display_url" : "octodex.github.com\/octoliberty\/"
    } ]
  },
  "geo" : { },
  "id_str" : "376067885442949120",
  "text" : "RT @raganwald: Bring me your tired, your poor, your huddled code libraries... http:\/\/t.co\/22udWfvPOT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/22udWfvPOT",
        "expanded_url" : "http:\/\/octodex.github.com\/octoliberty\/",
        "display_url" : "octodex.github.com\/octoliberty\/"
      } ]
    },
    "geo" : { },
    "id_str" : "376064992329494528",
    "text" : "Bring me your tired, your poor, your huddled code libraries... http:\/\/t.co\/22udWfvPOT",
    "id" : 376064992329494528,
    "created_at" : "2013-09-06 19:30:55 +0000",
    "user" : {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "protected" : false,
      "id_str" : "18137723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525649735856570368\/MvtI3PJj_normal.png",
      "id" : 18137723,
      "verified" : false
    }
  },
  "id" : 376067885442949120,
  "created_at" : "2013-09-06 19:42:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 3, 9 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376066654041427968",
  "text" : "RT @vrunt: say, theres an idea.. a blog about food! has this ever been done before?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "376066486852263936",
    "text" : "say, theres an idea.. a blog about food! has this ever been done before?",
    "id" : 376066486852263936,
    "created_at" : "2013-09-06 19:36:52 +0000",
    "user" : {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "protected" : false,
      "id_str" : "15062828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566801374143586305\/yApDWRcm_normal.jpeg",
      "id" : 15062828,
      "verified" : false
    }
  },
  "id" : 376066654041427968,
  "created_at" : "2013-09-06 19:37:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salem Sayed",
      "screen_name" : "salemsayed",
      "indices" : [ 0, 11 ],
      "id_str" : "14569462",
      "id" : 14569462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376057446860865536",
  "geo" : { },
  "id_str" : "376059120249339904",
  "in_reply_to_user_id" : 14569462,
  "text" : "@salemsayed well aware, more than most :)",
  "id" : 376059120249339904,
  "in_reply_to_status_id" : 376057446860865536,
  "created_at" : "2013-09-06 19:07:35 +0000",
  "in_reply_to_screen_name" : "salemsayed",
  "in_reply_to_user_id_str" : "14569462",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Sanheim",
      "screen_name" : "rsanheim",
      "indices" : [ 3, 12 ],
      "id_str" : "6141442",
      "id" : 6141442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/QfLuODMzpW",
      "expanded_url" : "http:\/\/instagram.com\/p\/d7YdUGwglW\/",
      "display_url" : "instagram.com\/p\/d7YdUGwglW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "376057750448373760",
  "text" : "RT @rsanheim: Yeah, can't get over this.  GitHub Oval Office @ GitHub HQ 3.0 http:\/\/t.co\/QfLuODMzpW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/QfLuODMzpW",
        "expanded_url" : "http:\/\/instagram.com\/p\/d7YdUGwglW\/",
        "display_url" : "instagram.com\/p\/d7YdUGwglW\/"
      } ]
    },
    "geo" : { },
    "id_str" : "376038755721019392",
    "text" : "Yeah, can't get over this.  GitHub Oval Office @ GitHub HQ 3.0 http:\/\/t.co\/QfLuODMzpW",
    "id" : 376038755721019392,
    "created_at" : "2013-09-06 17:46:40 +0000",
    "user" : {
      "name" : "Rob Sanheim",
      "screen_name" : "rsanheim",
      "protected" : false,
      "id_str" : "6141442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2099222922\/rob-jruby-shirt_normal.jpeg",
      "id" : 6141442,
      "verified" : false
    }
  },
  "id" : 376057750448373760,
  "created_at" : "2013-09-06 19:02:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Mangold",
      "screen_name" : "andymangold",
      "indices" : [ 0, 12 ],
      "id_str" : "14144438",
      "id" : 14144438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376057543791226880",
  "geo" : { },
  "id_str" : "376057678759350274",
  "in_reply_to_user_id" : 14144438,
  "text" : "@andymangold I perceived snark :)",
  "id" : 376057678759350274,
  "in_reply_to_status_id" : 376057543791226880,
  "created_at" : "2013-09-06 19:01:52 +0000",
  "in_reply_to_screen_name" : "andymangold",
  "in_reply_to_user_id_str" : "14144438",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376057306804277248",
  "text" : "Killed last tweet. Overly snarky.",
  "id" : 376057306804277248,
  "created_at" : "2013-09-06 19:00:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 0, 9 ],
      "id_str" : "15946976",
      "id" : 15946976
    }, {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 10, 23 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376056039059111938",
  "geo" : { },
  "id_str" : "376056555977707520",
  "in_reply_to_user_id" : 15946976,
  "text" : "@tinybaby @moonpolysoft what. the. fuck.",
  "id" : 376056555977707520,
  "in_reply_to_status_id" : 376056039059111938,
  "created_at" : "2013-09-06 18:57:24 +0000",
  "in_reply_to_screen_name" : "tinybaby",
  "in_reply_to_user_id_str" : "15946976",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Yun",
      "screen_name" : "dougyun",
      "indices" : [ 0, 8 ],
      "id_str" : "324160285",
      "id" : 324160285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376053970986233856",
  "geo" : { },
  "id_str" : "376054284942450688",
  "in_reply_to_user_id" : 324160285,
  "text" : "@DougYun or...don't. My notifications are a fraction FFS",
  "id" : 376054284942450688,
  "in_reply_to_status_id" : 376053970986233856,
  "created_at" : "2013-09-06 18:48:22 +0000",
  "in_reply_to_screen_name" : "dougyun",
  "in_reply_to_user_id_str" : "324160285",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 46, 61 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/YJWat2Hg3F",
      "expanded_url" : "http:\/\/nickelcityruby.com\/bus\/",
      "display_url" : "nickelcityruby.com\/bus\/"
    } ]
  },
  "geo" : { },
  "id_str" : "376052845067264000",
  "text" : "There are plenty of seats left on the bus for @nickelcityruby from NYC. Help us fill it! http:\/\/t.co\/YJWat2Hg3F",
  "id" : 376052845067264000,
  "created_at" : "2013-09-06 18:42:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarcLyon",
      "screen_name" : "MarcLyon",
      "indices" : [ 0, 9 ],
      "id_str" : "16843390",
      "id" : 16843390
    }, {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 10, 18 ],
      "id_str" : "77673",
      "id" : 77673
    }, {
      "name" : "mathiasx",
      "screen_name" : "mathiasx",
      "indices" : [ 19, 28 ],
      "id_str" : "787975",
      "id" : 787975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376015852190986240",
  "geo" : { },
  "id_str" : "376017968762593280",
  "in_reply_to_user_id" : 16843390,
  "text" : "@MarcLyon @jwright @mathiasx saying it's a Rails-only conf is very false. I think any software env will get a lot out of it!",
  "id" : 376017968762593280,
  "in_reply_to_status_id" : 376015852190986240,
  "created_at" : "2013-09-06 16:24:04 +0000",
  "in_reply_to_screen_name" : "MarcLyon",
  "in_reply_to_user_id_str" : "16843390",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 33, 43 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376010814400249856",
  "geo" : { },
  "id_str" : "376010932985417732",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden Thanks! This is also @aquaranto's fault :)",
  "id" : 376010932985417732,
  "in_reply_to_status_id" : 376010814400249856,
  "created_at" : "2013-09-06 15:56:07 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376000952953626624",
  "text" : "I finally learned how to use guides in Pixelmator last night! Don't judge.",
  "id" : 376000952953626624,
  "created_at" : "2013-09-06 15:16:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Kasper",
      "screen_name" : "dkasper",
      "indices" : [ 0, 8 ],
      "id_str" : "14070588",
      "id" : 14070588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375977744670027776",
  "geo" : { },
  "id_str" : "375978402445922304",
  "in_reply_to_user_id" : 14070588,
  "text" : "@dkasper that we know about...",
  "id" : 375978402445922304,
  "in_reply_to_status_id" : 375977744670027776,
  "created_at" : "2013-09-06 13:46:51 +0000",
  "in_reply_to_screen_name" : "dkasper",
  "in_reply_to_user_id_str" : "14070588",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/0f8VChmxiO",
      "expanded_url" : "http:\/\/thenextweb.com\/shareables\/2013\/09\/05\/elon-musk-shows-off-iron-man-inspired-gesture-control-for-designing-rockets\/",
      "display_url" : "thenextweb.com\/shareables\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375976559779147778",
  "text" : "Elon Musk continues to prove to be Tony Stark: http:\/\/t.co\/0f8VChmxiO",
  "id" : 375976559779147778,
  "created_at" : "2013-09-06 13:39:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 17, 27 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375969848284954624",
  "geo" : { },
  "id_str" : "375973858907394048",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle Thanks. @aquaranto deserves more credit here!",
  "id" : 375973858907394048,
  "in_reply_to_status_id" : 375969848284954624,
  "created_at" : "2013-09-06 13:28:47 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 24, 39 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/AM8IVnwSOy",
      "expanded_url" : "http:\/\/i.imgur.com\/6MURIPQ.gif",
      "display_url" : "i.imgur.com\/6MURIPQ.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "375968632007716864",
  "text" : "Officially 2 weeks from @nickelcityruby! http:\/\/t.co\/AM8IVnwSOy",
  "id" : 375968632007716864,
  "created_at" : "2013-09-06 13:08:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 51, 66 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyists",
      "indices" : [ 24, 33 ]
    }, {
      "text" : "urug",
      "indices" : [ 34, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375968079366209537",
  "text" : "RT @bretthammond13: Any #rubyists #urug heading to @nickelcityruby from Utah?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 31, 46 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubyists",
        "indices" : [ 4, 13 ]
      }, {
        "text" : "urug",
        "indices" : [ 14, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375843279104770048",
    "text" : "Any #rubyists #urug heading to @nickelcityruby from Utah?",
    "id" : 375843279104770048,
    "created_at" : "2013-09-06 04:49:55 +0000",
    "user" : {
      "name" : "Brett Hammond",
      "screen_name" : "brettmhammond",
      "protected" : false,
      "id_str" : "116056816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2165370996\/274409_639250170_1757180450_q_normal.jpg",
      "id" : 116056816,
      "verified" : false
    }
  },
  "id" : 375968079366209537,
  "created_at" : "2013-09-06 13:05:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Hammond",
      "screen_name" : "LindsHammond",
      "indices" : [ 16, 29 ],
      "id_str" : "410520164",
      "id" : 410520164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375842405917814784",
  "geo" : { },
  "id_str" : "375968065948635136",
  "in_reply_to_user_id" : 116056816,
  "text" : "@bretthammond13 @LindsHammond awesome! Visiting any local stuff while you're here? (the Falls?)",
  "id" : 375968065948635136,
  "in_reply_to_status_id" : 375842405917814784,
  "created_at" : "2013-09-06 13:05:46 +0000",
  "in_reply_to_screen_name" : "brettmhammond",
  "in_reply_to_user_id_str" : "116056816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 0, 8 ],
      "id_str" : "752673",
      "id" : 752673
    }, {
      "name" : "Aaron Quint",
      "screen_name" : "aq",
      "indices" : [ 9, 12 ],
      "id_str" : "1178441",
      "id" : 1178441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375808087115849729",
  "geo" : { },
  "id_str" : "375808145848684545",
  "in_reply_to_user_id" : 752673,
  "text" : "@jeresig @aq YES",
  "id" : 375808145848684545,
  "in_reply_to_status_id" : 375808087115849729,
  "created_at" : "2013-09-06 02:30:18 +0000",
  "in_reply_to_screen_name" : "jeresig",
  "in_reply_to_user_id_str" : "752673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375802043002540032",
  "geo" : { },
  "id_str" : "375802442836742144",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 Hurray!",
  "id" : 375802442836742144,
  "in_reply_to_status_id" : 375802043002540032,
  "created_at" : "2013-09-06 02:07:39 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 53, 68 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375784925640675328",
  "text" : "RT @ashedryden: How are there still tickets left for @nickelcityruby?! You realize it's only $99, right? Come hang out with me, nerds.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 37, 52 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375783764686684161",
    "text" : "How are there still tickets left for @nickelcityruby?! You realize it's only $99, right? Come hang out with me, nerds.",
    "id" : 375783764686684161,
    "created_at" : "2013-09-06 00:53:25 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 375784925640675328,
  "created_at" : "2013-09-06 00:58:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick DiRienzo",
      "screen_name" : "nickdirienzo",
      "indices" : [ 0, 13 ],
      "id_str" : "101859945",
      "id" : 101859945
    }, {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 14, 29 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375763508777857024",
  "geo" : { },
  "id_str" : "375771449178333184",
  "in_reply_to_user_id" : 101859945,
  "text" : "@nickdirienzo @ChrisVanPatten I wasn't aware of that. We're going to have discounted tickets for students setup soon.",
  "id" : 375771449178333184,
  "in_reply_to_status_id" : 375763508777857024,
  "created_at" : "2013-09-06 00:04:29 +0000",
  "in_reply_to_screen_name" : "nickdirienzo",
  "in_reply_to_user_id_str" : "101859945",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "Nick DiRienzo",
      "screen_name" : "nickdirienzo",
      "indices" : [ 31, 44 ],
      "id_str" : "101859945",
      "id" : 101859945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375751857005551616",
  "geo" : { },
  "id_str" : "375754350317928448",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten We have bugged @nickdirienzo and ACM but haven't heard of anything bus-wise. We would love to have one.",
  "id" : 375754350317928448,
  "in_reply_to_status_id" : 375751857005551616,
  "created_at" : "2013-09-05 22:56:32 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 0, 15 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375737112416780288",
  "geo" : { },
  "id_str" : "375745751504019456",
  "in_reply_to_user_id" : 16393800,
  "text" : "@AustinSeraphin trying to get the word out :)",
  "id" : 375745751504019456,
  "in_reply_to_status_id" : 375737112416780288,
  "created_at" : "2013-09-05 22:22:22 +0000",
  "in_reply_to_screen_name" : "AustinSeraphin",
  "in_reply_to_user_id_str" : "16393800",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 3, 18 ],
      "id_str" : "16393800",
      "id" : 16393800
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 87, 93 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 112, 127 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/N7IPX5C0M8",
      "expanded_url" : "http:\/\/gitready.com",
      "display_url" : "gitready.com"
    } ]
  },
  "geo" : { },
  "id_str" : "375745703399538688",
  "text" : "RT @AustinSeraphin: Wow! I wanted some info on git and found http:\/\/t.co\/N7IPX5C0M8 by @qrush with a banner for @nickelcityruby! Small worl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 67, 73 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 92, 107 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/N7IPX5C0M8",
        "expanded_url" : "http:\/\/gitready.com",
        "display_url" : "gitready.com"
      } ]
    },
    "geo" : { },
    "id_str" : "375737112416780288",
    "text" : "Wow! I wanted some info on git and found http:\/\/t.co\/N7IPX5C0M8 by @qrush with a banner for @nickelcityruby! Small world.",
    "id" : 375737112416780288,
    "created_at" : "2013-09-05 21:48:03 +0000",
    "user" : {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "protected" : false,
      "id_str" : "16393800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/382052821\/cib8blue_normal.jpg",
      "id" : 16393800,
      "verified" : false
    }
  },
  "id" : 375745703399538688,
  "created_at" : "2013-09-05 22:22:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 11, 22 ],
      "id_str" : "15445975",
      "id" : 15445975
    }, {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "indices" : [ 23, 34 ],
      "id_str" : "1232850504",
      "id" : 1232850504
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 54, 64 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375745389862719489",
  "geo" : { },
  "id_str" : "375745661863350272",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @paddyforan @gdiBuffalo I can bet you that @magnachef knows through WNY CSTA",
  "id" : 375745661863350272,
  "in_reply_to_status_id" : 375745389862719489,
  "created_at" : "2013-09-05 22:22:01 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Wolgamott",
      "screen_name" : "jwo",
      "indices" : [ 3, 7 ],
      "id_str" : "2723051",
      "id" : 2723051
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 10, 25 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/QU2Uz5cD8h",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "375742338741465090",
  "text" : "RT @jwo: .@nickelcityruby looks hella-good (Sept 20\/21). NYC area devs: read the talk descriptions (http:\/\/t.co\/QU2Uz5cD8h). I'd go if not \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 1, 16 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/QU2Uz5cD8h",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "375742170852249600",
    "text" : ".@nickelcityruby looks hella-good (Sept 20\/21). NYC area devs: read the talk descriptions (http:\/\/t.co\/QU2Uz5cD8h). I'd go if not for Texas.",
    "id" : 375742170852249600,
    "created_at" : "2013-09-05 22:08:09 +0000",
    "user" : {
      "name" : "Jesse Wolgamott",
      "screen_name" : "jwo",
      "protected" : false,
      "id_str" : "2723051",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544506545669558274\/ejL_6WW6_normal.jpeg",
      "id" : 2723051,
      "verified" : false
    }
  },
  "id" : 375742338741465090,
  "created_at" : "2013-09-05 22:08:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jin Yang",
      "screen_name" : "jzy",
      "indices" : [ 3, 7 ],
      "id_str" : "14971237",
      "id" : 14971237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/K8dBnxY4eP",
      "expanded_url" : "http:\/\/i.imgur.com\/2VorNff.jpg",
      "display_url" : "i.imgur.com\/2VorNff.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "375736168538578944",
  "text" : "RT @jzy: If the authors of computer programming books wrote arithmetic textbooks http:\/\/t.co\/K8dBnxY4eP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/K8dBnxY4eP",
        "expanded_url" : "http:\/\/i.imgur.com\/2VorNff.jpg",
        "display_url" : "i.imgur.com\/2VorNff.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "375201828469608448",
    "text" : "If the authors of computer programming books wrote arithmetic textbooks http:\/\/t.co\/K8dBnxY4eP",
    "id" : 375201828469608448,
    "created_at" : "2013-09-04 10:21:01 +0000",
    "user" : {
      "name" : "Jin Yang",
      "screen_name" : "jzy",
      "protected" : false,
      "id_str" : "14971237",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1180150530\/jin-madmen_normal.png",
      "id" : 14971237,
      "verified" : false
    }
  },
  "id" : 375736168538578944,
  "created_at" : "2013-09-05 21:44:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375728947683524608",
  "text" : "I refuse to change my twitter header image. I don't even know what fits there.",
  "id" : 375728947683524608,
  "created_at" : "2013-09-05 21:15:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Hopper",
      "screen_name" : "tdhopper",
      "indices" : [ 3, 12 ],
      "id_str" : "89249164",
      "id" : 89249164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Aetk2qUQFP",
      "expanded_url" : "http:\/\/i.imgur.com\/n3dlzAf.png",
      "display_url" : "i.imgur.com\/n3dlzAf.png"
    } ]
  },
  "geo" : { },
  "id_str" : "375727860629004288",
  "text" : "RT @tdhopper: The NSA's password length restriction on their job application website cracks me up http:\/\/t.co\/Aetk2qUQFP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/Aetk2qUQFP",
        "expanded_url" : "http:\/\/i.imgur.com\/n3dlzAf.png",
        "display_url" : "i.imgur.com\/n3dlzAf.png"
      } ]
    },
    "geo" : { },
    "id_str" : "375716567629045760",
    "text" : "The NSA's password length restriction on their job application website cracks me up http:\/\/t.co\/Aetk2qUQFP",
    "id" : 375716567629045760,
    "created_at" : "2013-09-05 20:26:24 +0000",
    "user" : {
      "name" : "Tim Hopper",
      "screen_name" : "tdhopper",
      "protected" : false,
      "id_str" : "89249164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3575028263\/8d7f2979a2219245dfbd2bfc399128d6_normal.jpeg",
      "id" : 89249164,
      "verified" : false
    }
  },
  "id" : 375727860629004288,
  "created_at" : "2013-09-05 21:11:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/h1Alp0CtJS",
      "expanded_url" : "http:\/\/www.schneier.com\/blog\/archives\/2013\/09\/the_nsa_is_brea.html",
      "display_url" : "schneier.com\/blog\/archives\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375714623619477505",
  "text" : "\"The math is good, but math has no agency. Code has agency, and the code has been subverted.\" http:\/\/t.co\/h1Alp0CtJS",
  "id" : 375714623619477505,
  "created_at" : "2013-09-05 20:18:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geezeo",
      "screen_name" : "Geezeo",
      "indices" : [ 3, 10 ],
      "id_str" : "5555822",
      "id" : 5555822
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 69, 84 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ruby",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375711492022468609",
  "text" : "RT @Geezeo: We're looking forward to having some of our folks attend @nickelcityruby in a couple of weeks. #Ruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 57, 72 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ruby",
        "indices" : [ 95, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375647511949492224",
    "text" : "We're looking forward to having some of our folks attend @nickelcityruby in a couple of weeks. #Ruby",
    "id" : 375647511949492224,
    "created_at" : "2013-09-05 15:52:00 +0000",
    "user" : {
      "name" : "Geezeo",
      "screen_name" : "Geezeo",
      "protected" : false,
      "id_str" : "5555822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3622629227\/27503070d1a389ddbd27b941f544d73b_normal.jpeg",
      "id" : 5555822,
      "verified" : false
    }
  },
  "id" : 375711492022468609,
  "created_at" : "2013-09-05 20:06:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ketan Deshmukh",
      "screen_name" : "ketandeshmukh",
      "indices" : [ 3, 17 ],
      "id_str" : "59896282",
      "id" : 59896282
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 43, 58 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Chargify",
      "screen_name" : "Chargify",
      "indices" : [ 88, 97 ],
      "id_str" : "51077652",
      "id" : 51077652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375711467410325504",
  "text" : "RT @ketandeshmukh: Super excited about the @nickelcityruby event on 20th sept\nthank you @Chargify for sponsoring me for the event !!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 24, 39 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Chargify",
        "screen_name" : "Chargify",
        "indices" : [ 69, 78 ],
        "id_str" : "51077652",
        "id" : 51077652
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375638809557233664",
    "text" : "Super excited about the @nickelcityruby event on 20th sept\nthank you @Chargify for sponsoring me for the event !!",
    "id" : 375638809557233664,
    "created_at" : "2013-09-05 15:17:25 +0000",
    "user" : {
      "name" : "Ketan Deshmukh",
      "screen_name" : "ketandeshmukh",
      "protected" : false,
      "id_str" : "59896282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000415322723\/6da351af60a9b039542d4389f36a82cd_normal.jpeg",
      "id" : 59896282,
      "verified" : false
    }
  },
  "id" : 375711467410325504,
  "created_at" : "2013-09-05 20:06:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 3, 11 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375711243296071680",
  "text" : "RT @fending: \"I can't :q! you.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375707811092508672",
    "text" : "\"I can't :q! you.\"",
    "id" : 375707811092508672,
    "created_at" : "2013-09-05 19:51:37 +0000",
    "user" : {
      "name" : "fending",
      "screen_name" : "fending",
      "protected" : false,
      "id_str" : "14672651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468101796\/ed9f5bca1aff3f91233b2986acb0fd4e_normal.jpeg",
      "id" : 14672651,
      "verified" : false
    }
  },
  "id" : 375711243296071680,
  "created_at" : "2013-09-05 20:05:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Ignite Buffalo",
      "screen_name" : "IgniteBflo",
      "indices" : [ 45, 56 ],
      "id_str" : "1201910654",
      "id" : 1201910654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/mvalW4cEc7",
      "expanded_url" : "http:\/\/ignitebuffalo.com\/",
      "display_url" : "ignitebuffalo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "375694902077579266",
  "text" : "RT @kevinpurdy: Buffalo types: 2 weeks until @IgniteBflo. It's free to attend, and we'd love to have more speakers. De-TAILS: http:\/\/t.co\/m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ignite Buffalo",
        "screen_name" : "IgniteBflo",
        "indices" : [ 29, 40 ],
        "id_str" : "1201910654",
        "id" : 1201910654
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/mvalW4cEc7",
        "expanded_url" : "http:\/\/ignitebuffalo.com\/",
        "display_url" : "ignitebuffalo.com"
      } ]
    },
    "geo" : { },
    "id_str" : "375694243181756416",
    "text" : "Buffalo types: 2 weeks until @IgniteBflo. It's free to attend, and we'd love to have more speakers. De-TAILS: http:\/\/t.co\/mvalW4cEc7",
    "id" : 375694243181756416,
    "created_at" : "2013-09-05 18:57:42 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 375694902077579266,
  "created_at" : "2013-09-05 19:00:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conferenshish",
      "screen_name" : "tundal45",
      "indices" : [ 3, 12 ],
      "id_str" : "5573992",
      "id" : 5573992
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 61, 76 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/yc2IMHBDOI",
      "expanded_url" : "http:\/\/nickelcityruby.com\/bus\/",
      "display_url" : "nickelcityruby.com\/bus\/"
    } ]
  },
  "geo" : { },
  "id_str" : "375632839129055233",
  "text" : "RT @tundal45: Any rubyists that I know from NYC, do not miss @nickelcityruby. They event have a bus from NYC! http:\/\/t.co\/yc2IMHBDOI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 47, 62 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/yc2IMHBDOI",
        "expanded_url" : "http:\/\/nickelcityruby.com\/bus\/",
        "display_url" : "nickelcityruby.com\/bus\/"
      } ]
    },
    "geo" : { },
    "id_str" : "375630921375817728",
    "text" : "Any rubyists that I know from NYC, do not miss @nickelcityruby. They event have a bus from NYC! http:\/\/t.co\/yc2IMHBDOI",
    "id" : 375630921375817728,
    "created_at" : "2013-09-05 14:46:05 +0000",
    "user" : {
      "name" : "conferenshish",
      "screen_name" : "tundal45",
      "protected" : false,
      "id_str" : "5573992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573190389802258432\/y6CEeQ3C_normal.jpeg",
      "id" : 5573992,
      "verified" : false
    }
  },
  "id" : 375632839129055233,
  "created_at" : "2013-09-05 14:53:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 62, 77 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/YJWat2Hg3F",
      "expanded_url" : "http:\/\/nickelcityruby.com\/bus\/",
      "display_url" : "nickelcityruby.com\/bus\/"
    } ]
  },
  "geo" : { },
  "id_str" : "375621857946247169",
  "text" : "There are plenty of seats left on the bus from NYC to BUF for @nickelcityruby. What are you waiting for!? http:\/\/t.co\/YJWat2Hg3F",
  "id" : 375621857946247169,
  "created_at" : "2013-09-05 14:10:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "indices" : [ 27, 38 ],
      "id_str" : "7255652",
      "id" : 7255652
    }, {
      "name" : "Synacor",
      "screen_name" : "Synacor",
      "indices" : [ 39, 47 ],
      "id_str" : "19976046",
      "id" : 19976046
    }, {
      "name" : "Chargify",
      "screen_name" : "Chargify",
      "indices" : [ 48, 57 ],
      "id_str" : "51077652",
      "id" : 51077652
    }, {
      "name" : "Mandrill",
      "screen_name" : "mandrillapp",
      "indices" : [ 64, 76 ],
      "id_str" : "540239057",
      "id" : 540239057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375483477279264768",
  "text" : "RT @nickelcityruby: Thanks @engineyard @synacor @Chargify &amp; @mandrillapp for donating tickets for students!  Your support makes this conf a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Engine Yard",
        "screen_name" : "engineyard",
        "indices" : [ 7, 18 ],
        "id_str" : "7255652",
        "id" : 7255652
      }, {
        "name" : "Synacor",
        "screen_name" : "Synacor",
        "indices" : [ 19, 27 ],
        "id_str" : "19976046",
        "id" : 19976046
      }, {
        "name" : "Chargify",
        "screen_name" : "Chargify",
        "indices" : [ 28, 37 ],
        "id_str" : "51077652",
        "id" : 51077652
      }, {
        "name" : "Mandrill",
        "screen_name" : "mandrillapp",
        "indices" : [ 44, 56 ],
        "id_str" : "540239057",
        "id" : 540239057
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375351599834472448",
    "text" : "Thanks @engineyard @synacor @Chargify &amp; @mandrillapp for donating tickets for students!  Your support makes this conf and learning possible",
    "id" : 375351599834472448,
    "created_at" : "2013-09-04 20:16:09 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 375483477279264768,
  "created_at" : "2013-09-05 05:00:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Munroe",
      "screen_name" : "mikepmunroe",
      "indices" : [ 0, 12 ],
      "id_str" : "13440",
      "id" : 13440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375463105608052736",
  "geo" : { },
  "id_str" : "375483249075568640",
  "in_reply_to_user_id" : 13440,
  "text" : "@mikepmunroe dang. Our first due in November\u2026hoping next ear will be easier post baby, doubtful! :)",
  "id" : 375483249075568640,
  "in_reply_to_status_id" : 375463105608052736,
  "created_at" : "2013-09-05 04:59:17 +0000",
  "in_reply_to_screen_name" : "mikepmunroe",
  "in_reply_to_user_id_str" : "13440",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "friendly catduck\u2122",
      "screen_name" : "duckinator",
      "indices" : [ 14, 25 ],
      "id_str" : "28650670",
      "id" : 28650670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375468663433723904",
  "geo" : { },
  "id_str" : "375483054552145920",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @duckinator hotel rooms on special rate, code is on the site.",
  "id" : 375483054552145920,
  "in_reply_to_status_id" : 375468663433723904,
  "created_at" : "2013-09-05 04:58:31 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Rodler",
      "screen_name" : "JRodl3r",
      "indices" : [ 0, 8 ],
      "id_str" : "256957084",
      "id" : 256957084
    }, {
      "name" : "3rd Learning",
      "screen_name" : "3rdLearning",
      "indices" : [ 9, 21 ],
      "id_str" : "701662915",
      "id" : 701662915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375446551570575361",
  "geo" : { },
  "id_str" : "375458095985467392",
  "in_reply_to_user_id" : 256957084,
  "text" : "@JRodl3r @3rdLearning awesome! Spreading the word to local companies\/people would be huge.",
  "id" : 375458095985467392,
  "in_reply_to_status_id" : 375446551570575361,
  "created_at" : "2013-09-05 03:19:20 +0000",
  "in_reply_to_screen_name" : "JRodl3r",
  "in_reply_to_user_id_str" : "256957084",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul  Kalupnieks ",
      "screen_name" : "kalupa",
      "indices" : [ 3, 10 ],
      "id_str" : "2355",
      "id" : 2355
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 43, 58 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375453057682644992",
  "text" : "RT @kalupa: Anyone on Toronto should go to @nickelcityruby ! I'd go but I am literally moving tomorrow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 31, 46 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375444167599460352",
    "text" : "Anyone on Toronto should go to @nickelcityruby ! I'd go but I am literally moving tomorrow",
    "id" : 375444167599460352,
    "created_at" : "2013-09-05 02:23:59 +0000",
    "user" : {
      "name" : "Paul  Kalupnieks ",
      "screen_name" : "kalupa",
      "protected" : false,
      "id_str" : "2355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553043411234983938\/epZyY953_normal.png",
      "id" : 2355,
      "verified" : false
    }
  },
  "id" : 375453057682644992,
  "created_at" : "2013-09-05 02:59:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 3, 14 ],
      "id_str" : "15445975",
      "id" : 15445975
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 66, 81 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375424091227824129",
  "text" : "RT @paddyforan: I freaking HATE Ruby, and I'd *still* be going to @NickelCityRuby if I had a spare $99. There are some great, non-Ruby-spec\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 50, 65 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375423170615853056",
    "text" : "I freaking HATE Ruby, and I'd *still* be going to @NickelCityRuby if I had a spare $99. There are some great, non-Ruby-specific talks.",
    "id" : 375423170615853056,
    "created_at" : "2013-09-05 01:00:33 +0000",
    "user" : {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "protected" : false,
      "id_str" : "15445975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433766988179963904\/MjnoKMzP_normal.jpeg",
      "id" : 15445975,
      "verified" : false
    }
  },
  "id" : 375424091227824129,
  "created_at" : "2013-09-05 01:04:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "travis jeffery",
      "screen_name" : "travisjeffery",
      "indices" : [ 0, 14 ],
      "id_str" : "679103",
      "id" : 679103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375413812066668544",
  "geo" : { },
  "id_str" : "375414160357474304",
  "in_reply_to_user_id" : 679103,
  "text" : "@travisjeffery WELCOME TO THE JAM",
  "id" : 375414160357474304,
  "in_reply_to_status_id" : 375413812066668544,
  "created_at" : "2013-09-05 00:24:45 +0000",
  "in_reply_to_screen_name" : "travisjeffery",
  "in_reply_to_user_id_str" : "679103",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/CxcF72Eowa",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/comeonandslam",
      "display_url" : "reddit.com\/r\/comeonandslam"
    }, {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/3APIJlx722",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=9ZUAyp4MO3s",
      "display_url" : "youtube.com\/watch?v=9ZUAyp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375411687081275392",
  "text" : "And today I learned about http:\/\/t.co\/CxcF72Eowa Nothing is safe. https:\/\/t.co\/3APIJlx722",
  "id" : 375411687081275392,
  "created_at" : "2013-09-05 00:14:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375400971989299200",
  "geo" : { },
  "id_str" : "375410711570046976",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan PaddyConf",
  "id" : 375410711570046976,
  "in_reply_to_status_id" : 375400971989299200,
  "created_at" : "2013-09-05 00:11:03 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375390876450574336",
  "geo" : { },
  "id_str" : "375408652435206144",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 you did volunteer!",
  "id" : 375408652435206144,
  "in_reply_to_status_id" : 375390876450574336,
  "created_at" : "2013-09-05 00:02:52 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 3, 14 ],
      "id_str" : "15445975",
      "id" : 15445975
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 57, 72 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375404425214316544",
  "text" : "RT @paddyforan: Reminder to people considering attending @nickelcityruby: If cost is a concern, you can crash at my place and I'll drive yo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 41, 56 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375400971989299200",
    "text" : "Reminder to people considering attending @nickelcityruby: If cost is a concern, you can crash at my place and I'll drive you to the event.",
    "id" : 375400971989299200,
    "created_at" : "2013-09-04 23:32:20 +0000",
    "user" : {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "protected" : false,
      "id_str" : "15445975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433766988179963904\/MjnoKMzP_normal.jpeg",
      "id" : 15445975,
      "verified" : false
    }
  },
  "id" : 375404425214316544,
  "created_at" : "2013-09-04 23:46:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375379482497912832",
  "geo" : { },
  "id_str" : "375404049907986432",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman Do want.",
  "id" : 375404049907986432,
  "in_reply_to_status_id" : 375379482497912832,
  "created_at" : "2013-09-04 23:44:34 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dessy",
      "screen_name" : "dess_e",
      "indices" : [ 3, 10 ],
      "id_str" : "107498881",
      "id" : 107498881
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 17, 32 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375385134192553984",
  "text" : "RT @dess_e: Ooh, @nickelcityruby sounds interesting. Smaller conferences come with many benefits. Any developers out there in TO planning t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 5, 20 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375368545414025216",
    "text" : "Ooh, @nickelcityruby sounds interesting. Smaller conferences come with many benefits. Any developers out there in TO planning to attend?",
    "id" : 375368545414025216,
    "created_at" : "2013-09-04 21:23:29 +0000",
    "user" : {
      "name" : "Dessy",
      "screen_name" : "dess_e",
      "protected" : false,
      "id_str" : "107498881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555953614351372288\/4Bv_nd9y_normal.jpeg",
      "id" : 107498881,
      "verified" : false
    }
  },
  "id" : 375385134192553984,
  "created_at" : "2013-09-04 22:29:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seanita tolliver",
      "screen_name" : "seanita",
      "indices" : [ 3, 11 ],
      "id_str" : "15916364",
      "id" : 15916364
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 105, 120 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375361671427923968",
  "text" : "RT @seanita: Fellow Rubyists - NickelCityRuby conference in Buffalo, Sept 19-22.  Bus included for $125. @nickelcityruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 92, 107 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375323479421112320",
    "text" : "Fellow Rubyists - NickelCityRuby conference in Buffalo, Sept 19-22.  Bus included for $125. @nickelcityruby",
    "id" : 375323479421112320,
    "created_at" : "2013-09-04 18:24:25 +0000",
    "user" : {
      "name" : "seanita tolliver",
      "screen_name" : "seanita",
      "protected" : false,
      "id_str" : "15916364",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501864868438224896\/GeGo16uy_normal.jpeg",
      "id" : 15916364,
      "verified" : false
    }
  },
  "id" : 375361671427923968,
  "created_at" : "2013-09-04 20:56:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mathiasx",
      "screen_name" : "mathiasx",
      "indices" : [ 3, 12 ],
      "id_str" : "787975",
      "id" : 787975
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 34, 49 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/0pOl9rbcfB",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "375361627362566144",
  "text" : "RT @mathiasx: I'll be speaking at @nickelcityruby, will you be there? http:\/\/t.co\/0pOl9rbcfB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 20, 35 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/0pOl9rbcfB",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "375343431138041856",
    "text" : "I'll be speaking at @nickelcityruby, will you be there? http:\/\/t.co\/0pOl9rbcfB",
    "id" : 375343431138041856,
    "created_at" : "2013-09-04 19:43:42 +0000",
    "user" : {
      "name" : "mathiasx",
      "screen_name" : "mathiasx",
      "protected" : false,
      "id_str" : "787975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2929427530\/437cf4819236d33fb9847bfa7d7fa9f8_normal.jpeg",
      "id" : 787975,
      "verified" : false
    }
  },
  "id" : 375361627362566144,
  "created_at" : "2013-09-04 20:56:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 3, 11 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375351767967342592",
  "text" : "RT @capotej: take me down to incident city \/ where the graphs arent green \/ and its not pretty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375351647364325376",
    "text" : "take me down to incident city \/ where the graphs arent green \/ and its not pretty",
    "id" : 375351647364325376,
    "created_at" : "2013-09-04 20:16:21 +0000",
    "user" : {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "protected" : false,
      "id_str" : "8898642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497932410890510337\/i-8d5ayf_normal.jpeg",
      "id" : 8898642,
      "verified" : false
    }
  },
  "id" : 375351767967342592,
  "created_at" : "2013-09-04 20:16:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375293325621731328",
  "geo" : { },
  "id_str" : "375310941430116352",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 Sweet!",
  "id" : 375310941430116352,
  "in_reply_to_status_id" : 375293325621731328,
  "created_at" : "2013-09-04 17:34:36 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jorji Costava",
      "screen_name" : "ArstotzkaJorji",
      "indices" : [ 3, 18 ],
      "id_str" : "1724577432",
      "id" : 1724577432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375282767908442112",
  "text" : "RT @ArstotzkaJorji: I have made twitter account! Is good website.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374785628895858688",
    "text" : "I have made twitter account! Is good website.",
    "id" : 374785628895858688,
    "created_at" : "2013-09-03 06:47:11 +0000",
    "user" : {
      "name" : "Jorji Costava",
      "screen_name" : "ArstotzkaJorji",
      "protected" : false,
      "id_str" : "1724577432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000404040870\/82be97c42708f7aa33b10bc6c04292b6_normal.png",
      "id" : 1724577432,
      "verified" : false
    }
  },
  "id" : 375282767908442112,
  "created_at" : "2013-09-04 15:42:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375281566861099008",
  "geo" : { },
  "id_str" : "375282706126356480",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 leaving midday Thursday 9\/19, returning early Sunday 9\/22. Exact times TBD",
  "id" : 375282706126356480,
  "in_reply_to_status_id" : 375281566861099008,
  "created_at" : "2013-09-04 15:42:24 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "infotechniagara",
      "screen_name" : "infotechniagara",
      "indices" : [ 3, 19 ],
      "id_str" : "16450873",
      "id" : 16450873
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 93, 108 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffaloTech",
      "indices" : [ 109, 121 ]
    }, {
      "text" : "WNYRuby",
      "indices" : [ 122, 130 ]
    }, {
      "text" : "TechMeetUp",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/0jTgsR1asJ",
      "expanded_url" : "http:\/\/wp.me\/p320MR-36",
      "display_url" : "wp.me\/p320MR-36"
    } ]
  },
  "geo" : { },
  "id_str" : "375266503739731968",
  "text" : "RT @infotechniagara: Nickel City Ruby Conference 2013: 9\/20-9\/21  http:\/\/t.co\/0jTgsR1asJ via @nickelcityruby #BuffaloTech #WNYRuby #TechMee\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 72, 87 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuffaloTech",
        "indices" : [ 88, 100 ]
      }, {
        "text" : "WNYRuby",
        "indices" : [ 101, 109 ]
      }, {
        "text" : "TechMeetUp",
        "indices" : [ 110, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/0jTgsR1asJ",
        "expanded_url" : "http:\/\/wp.me\/p320MR-36",
        "display_url" : "wp.me\/p320MR-36"
      } ]
    },
    "geo" : { },
    "id_str" : "375260670448500736",
    "text" : "Nickel City Ruby Conference 2013: 9\/20-9\/21  http:\/\/t.co\/0jTgsR1asJ via @nickelcityruby #BuffaloTech #WNYRuby #TechMeetUp",
    "id" : 375260670448500736,
    "created_at" : "2013-09-04 14:14:50 +0000",
    "user" : {
      "name" : "infotechniagara",
      "screen_name" : "infotechniagara",
      "protected" : false,
      "id_str" : "16450873",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/64732059\/itn_logo_normal.jpg",
      "id" : 16450873,
      "verified" : false
    }
  },
  "id" : 375266503739731968,
  "created_at" : "2013-09-04 14:38:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hack Upstate",
      "screen_name" : "hackupstate",
      "indices" : [ 3, 15 ],
      "id_str" : "1160598210",
      "id" : 1160598210
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 142, 143 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375266466175537152",
  "text" : "RT @hackupstate: Take a fully-loaded, wifi-enabled, power-outlet equipped bus from NYC to Buffalo. Departing NYC 9\/19, returning 9\/22. CC &gt;\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 130, 145 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375262345489969152",
    "text" : "Take a fully-loaded, wifi-enabled, power-outlet equipped bus from NYC to Buffalo. Departing NYC 9\/19, returning 9\/22. CC &gt;&gt; @nickelcityruby",
    "id" : 375262345489969152,
    "created_at" : "2013-09-04 14:21:29 +0000",
    "user" : {
      "name" : "Hack Upstate",
      "screen_name" : "hackupstate",
      "protected" : false,
      "id_str" : "1160598210",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571005161720381440\/tZzEl-OO_normal.png",
      "id" : 1160598210,
      "verified" : false
    }
  },
  "id" : 375266466175537152,
  "created_at" : "2013-09-04 14:37:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 14, 28 ],
      "id_str" : "5896952",
      "id" : 5896952
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 42, 57 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/Oi0UDrDM5x",
      "expanded_url" : "http:\/\/buffalorising.com\/2013\/09\/nickel-city-ruby-2013\/",
      "display_url" : "buffalorising.com\/2013\/09\/nickel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375259266350735360",
  "text" : "Big thanks to @BuffaloRising for covering @nickelcityruby ! http:\/\/t.co\/Oi0UDrDM5x",
  "id" : 375259266350735360,
  "created_at" : "2013-09-04 14:09:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 3, 16 ],
      "id_str" : "257495729",
      "id" : 257495729
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 35, 50 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 54, 68 ],
      "id_str" : "5896952",
      "id" : 5896952
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 79, 85 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/MHZAeOzAGQ",
      "expanded_url" : "http:\/\/buffalorising.com\/2013\/09\/nickel-city-ruby-2013\/",
      "display_url" : "buffalorising.com\/2013\/09\/nickel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375259161614749696",
  "text" : "RT @TommyCreenan: Great article on @nickelcityruby in @BuffaloRising! Congrats @qrush! http:\/\/t.co\/MHZAeOzAGQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 17, 32 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Buffalo Rising",
        "screen_name" : "BuffaloRising",
        "indices" : [ 36, 50 ],
        "id_str" : "5896952",
        "id" : 5896952
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 61, 67 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/MHZAeOzAGQ",
        "expanded_url" : "http:\/\/buffalorising.com\/2013\/09\/nickel-city-ruby-2013\/",
        "display_url" : "buffalorising.com\/2013\/09\/nickel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "375241495982665729",
    "text" : "Great article on @nickelcityruby in @BuffaloRising! Congrats @qrush! http:\/\/t.co\/MHZAeOzAGQ",
    "id" : 375241495982665729,
    "created_at" : "2013-09-04 12:58:38 +0000",
    "user" : {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "protected" : false,
      "id_str" : "257495729",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/532272850242002944\/SAUXcbLf_normal.jpeg",
      "id" : 257495729,
      "verified" : false
    }
  },
  "id" : 375259161614749696,
  "created_at" : "2013-09-04 14:08:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 3, 14 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/yJwzJJx7jB",
      "expanded_url" : "https:\/\/basecamp.com\/help\/guides\/you\/phone-verification",
      "display_url" : "basecamp.com\/help\/guides\/yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375258807573549057",
  "text" : "RT @themcgruff: Github isn't the only one deploying improved security this week... https:\/\/t.co\/yJwzJJx7jB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/yJwzJJx7jB",
        "expanded_url" : "https:\/\/basecamp.com\/help\/guides\/you\/phone-verification",
        "display_url" : "basecamp.com\/help\/guides\/yo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "375258763713728512",
    "text" : "Github isn't the only one deploying improved security this week... https:\/\/t.co\/yJwzJJx7jB",
    "id" : 375258763713728512,
    "created_at" : "2013-09-04 14:07:15 +0000",
    "user" : {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "protected" : false,
      "id_str" : "13984262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539946640417619968\/0wwEYfHi_normal.png",
      "id" : 13984262,
      "verified" : false
    }
  },
  "id" : 375258807573549057,
  "created_at" : "2013-09-04 14:07:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375034007576408064",
  "text" : "Gay Men\u2019s Choir rehearsal and drum circle both audible from my house makes for an interesting mashup.",
  "id" : 375034007576408064,
  "created_at" : "2013-09-03 23:14:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 3, 12 ],
      "id_str" : "21431343",
      "id" : 21431343
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 58, 73 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375030838926520320",
  "text" : "RT @bostonrb: I'd like to take the time to point out that @nickelcityruby is only 17 days away, totally bitchin, and only a few hours away.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 44, 59 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375013235944341504",
    "text" : "I'd like to take the time to point out that @nickelcityruby is only 17 days away, totally bitchin, and only a few hours away. Attend!",
    "id" : 375013235944341504,
    "created_at" : "2013-09-03 21:51:37 +0000",
    "user" : {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "protected" : false,
      "id_str" : "21431343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1585980633\/bostonrblogo_500x500_normal.png",
      "id" : 21431343,
      "verified" : false
    }
  },
  "id" : 375030838926520320,
  "created_at" : "2013-09-03 23:01:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Remarkable Labs",
      "screen_name" : "remarkablelabs",
      "indices" : [ 3, 18 ],
      "id_str" : "790594868",
      "id" : 790594868
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 37, 52 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/UsNsWmWHs4",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "375030823491489792",
  "text" : "RT @remarkablelabs: We are attending @nickelcityruby on September 20th-21st. It\u2019s going to be an amazing conference! http:\/\/t.co\/UsNsWmWHs4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 17, 32 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/UsNsWmWHs4",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "375013686781693952",
    "text" : "We are attending @nickelcityruby on September 20th-21st. It\u2019s going to be an amazing conference! http:\/\/t.co\/UsNsWmWHs4",
    "id" : 375013686781693952,
    "created_at" : "2013-09-03 21:53:25 +0000",
    "user" : {
      "name" : "Remarkable Labs",
      "screen_name" : "remarkablelabs",
      "protected" : false,
      "id_str" : "790594868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545238382071148544\/lP6d_BJy_normal.jpeg",
      "id" : 790594868,
      "verified" : false
    }
  },
  "id" : 375030823491489792,
  "created_at" : "2013-09-03 23:01:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Joyce",
      "screen_name" : "chris_joyce",
      "indices" : [ 0, 12 ],
      "id_str" : "15686931",
      "id" : 15686931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375027310354628609",
  "geo" : { },
  "id_str" : "375027552735092736",
  "in_reply_to_user_id" : 15686931,
  "text" : "@chris_joyce yeah looks like it :( I\u2019d love to revisit but dog is going insane.",
  "id" : 375027552735092736,
  "in_reply_to_status_id" : 375027310354628609,
  "created_at" : "2013-09-03 22:48:30 +0000",
  "in_reply_to_screen_name" : "chris_joyce",
  "in_reply_to_user_id_str" : "15686931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Joyce",
      "screen_name" : "chris_joyce",
      "indices" : [ 0, 12 ],
      "id_str" : "15686931",
      "id" : 15686931
    }, {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 25, 32 ],
      "id_str" : "70702180",
      "id" : 70702180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375023295223324673",
  "geo" : { },
  "id_str" : "375023443294838784",
  "in_reply_to_user_id" : 15686931,
  "text" : "@chris_joyce thanks! \/cc @cubosh",
  "id" : 375023443294838784,
  "in_reply_to_status_id" : 375023295223324673,
  "created_at" : "2013-09-03 22:32:11 +0000",
  "in_reply_to_screen_name" : "chris_joyce",
  "in_reply_to_user_id_str" : "15686931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Joyce",
      "screen_name" : "chris_joyce",
      "indices" : [ 0, 12 ],
      "id_str" : "15686931",
      "id" : 15686931
    }, {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 13, 20 ],
      "id_str" : "70702180",
      "id" : 70702180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375023202554380288",
  "in_reply_to_user_id" : 15686931,
  "text" : "@chris_joyce @cubosh mind opening your gates? I have a follower that wants to visit another town",
  "id" : 375023202554380288,
  "created_at" : "2013-09-03 22:31:13 +0000",
  "in_reply_to_screen_name" : "chris_joyce",
  "in_reply_to_user_id_str" : "15686931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Faustino",
      "screen_name" : "kfaustino",
      "indices" : [ 3, 13 ],
      "id_str" : "14846554",
      "id" : 14846554
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 62, 77 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375011460377624576",
  "text" : "RT @kfaustino: To my fellow Toronto Rubyists, just a reminder @nickelcityruby is only 17 days away and it\u2019s only a 2 hour drive to Buffalo.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 47, 62 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375011369344847872",
    "text" : "To my fellow Toronto Rubyists, just a reminder @nickelcityruby is only 17 days away and it\u2019s only a 2 hour drive to Buffalo. Don\u2019t miss out!",
    "id" : 375011369344847872,
    "created_at" : "2013-09-03 21:44:12 +0000",
    "user" : {
      "name" : "Kevin Faustino",
      "screen_name" : "kfaustino",
      "protected" : false,
      "id_str" : "14846554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410761741\/9a1d70c6af6138529cd46da64f9a5922_normal.jpeg",
      "id" : 14846554,
      "verified" : false
    }
  },
  "id" : 375011460377624576,
  "created_at" : "2013-09-03 21:44:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Handsome",
      "screen_name" : "Millennial_Dave",
      "indices" : [ 0, 16 ],
      "id_str" : "60185021",
      "id" : 60185021
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 17, 31 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 51, 66 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375007464304803841",
  "geo" : { },
  "id_str" : "375008447609044992",
  "in_reply_to_user_id" : 60185021,
  "text" : "@Millennial_Dave @coworkbuffalo On hold here until @nickelcityruby is over.",
  "id" : 375008447609044992,
  "in_reply_to_status_id" : 375007464304803841,
  "created_at" : "2013-09-03 21:32:35 +0000",
  "in_reply_to_screen_name" : "Millennial_Dave",
  "in_reply_to_user_id_str" : "60185021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375008324866945024",
  "text" : "RT @nickelcityruby: Want to help some people get to NickelCityRuby? Contact the organizers to sponsor a student: nickelcityruby(at)gmail(do\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375008227634593792",
    "text" : "Want to help some people get to NickelCityRuby? Contact the organizers to sponsor a student: nickelcityruby(at)gmail(dot)com",
    "id" : 375008227634593792,
    "created_at" : "2013-09-03 21:31:43 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 375008324866945024,
  "created_at" : "2013-09-03 21:32:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 57, 72 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375005138949124096",
  "text" : "It's Tuesday again, and we have lots of tickets left for @nickelcityruby. If you're running a code related group tonight please mention it!",
  "id" : 375005138949124096,
  "created_at" : "2013-09-03 21:19:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Shanley",
      "screen_name" : "PeterShanley",
      "indices" : [ 3, 16 ],
      "id_str" : "87522543",
      "id" : 87522543
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 24, 39 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/oTTvpgpmEe",
      "expanded_url" : "http:\/\/www.neo.com\/jobs",
      "display_url" : "neo.com\/jobs"
    } ]
  },
  "geo" : { },
  "id_str" : "375004968081555457",
  "text" : "RT @PeterShanley: howdy @nickelcityruby we're hiring in our NYC, Columbus + San Francisco offices. I'm from Buffalo = culture fit FTW!! htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 6, 21 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/oTTvpgpmEe",
        "expanded_url" : "http:\/\/www.neo.com\/jobs",
        "display_url" : "neo.com\/jobs"
      } ]
    },
    "geo" : { },
    "id_str" : "375000185849397248",
    "text" : "howdy @nickelcityruby we're hiring in our NYC, Columbus + San Francisco offices. I'm from Buffalo = culture fit FTW!! http:\/\/t.co\/oTTvpgpmEe",
    "id" : 375000185849397248,
    "created_at" : "2013-09-03 20:59:46 +0000",
    "user" : {
      "name" : "Peter Shanley",
      "screen_name" : "PeterShanley",
      "protected" : false,
      "id_str" : "87522543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459877070655348736\/jMaw9EIK_normal.jpeg",
      "id" : 87522543,
      "verified" : false
    }
  },
  "id" : 375004968081555457,
  "created_at" : "2013-09-03 21:18:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 29, 44 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374995569753595904",
  "text" : "RT @aspleenic: Can't believe @nickelcityruby is this month already! Looking forward to seeing all the people",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 14, 29 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374987146056437760",
    "text" : "Can't believe @nickelcityruby is this month already! Looking forward to seeing all the people",
    "id" : 374987146056437760,
    "created_at" : "2013-09-03 20:07:57 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 374995569753595904,
  "created_at" : "2013-09-03 20:41:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Gatesman",
      "screen_name" : "12protons",
      "indices" : [ 30, 40 ],
      "id_str" : "1075535245",
      "id" : 1075535245
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 69, 83 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/374982312712491009\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/J01aQfxN0S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTQ0bSsIIAApXPi.jpg",
      "id_str" : "374982312456626176",
      "id" : 374982312456626176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTQ0bSsIIAApXPi.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/J01aQfxN0S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374982312712491009",
  "text" : "Trolling resident Android dev @12protons with some product placement @coworkbuffalo http:\/\/t.co\/J01aQfxN0S",
  "id" : 374982312712491009,
  "created_at" : "2013-09-03 19:48:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Hayes",
      "screen_name" : "michaelhayes",
      "indices" : [ 0, 13 ],
      "id_str" : "7764332",
      "id" : 7764332
    }, {
      "name" : "Raf Sanchez",
      "screen_name" : "rafsanchez",
      "indices" : [ 14, 25 ],
      "id_str" : "18426419",
      "id" : 18426419
    }, {
      "name" : "Dan Roberts",
      "screen_name" : "RobertsDan",
      "indices" : [ 26, 37 ],
      "id_str" : "25491788",
      "id" : 25491788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/NnrbGWmE3b",
      "expanded_url" : "http:\/\/www.verminsupreme.com\/",
      "display_url" : "verminsupreme.com"
    } ]
  },
  "in_reply_to_status_id_str" : "374961212028911616",
  "geo" : { },
  "id_str" : "374962217784860672",
  "in_reply_to_user_id" : 7764332,
  "text" : "@michaelhayes @rafsanchez @RobertsDan Is this Vermin Supreme? http:\/\/t.co\/NnrbGWmE3b",
  "id" : 374962217784860672,
  "in_reply_to_status_id" : 374961212028911616,
  "created_at" : "2013-09-03 18:28:53 +0000",
  "in_reply_to_screen_name" : "michaelhayes",
  "in_reply_to_user_id_str" : "7764332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Brian Barrett",
      "screen_name" : "brbarrett",
      "indices" : [ 12, 22 ],
      "id_str" : "106419866",
      "id" : 106419866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374955997564911616",
  "geo" : { },
  "id_str" : "374956553821904896",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake @brbarrett oh man, Oreos and Payday are good.",
  "id" : 374956553821904896,
  "in_reply_to_status_id" : 374955997564911616,
  "created_at" : "2013-09-03 18:06:23 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Duncan Davidson",
      "screen_name" : "duncan",
      "indices" : [ 12, 19 ],
      "id_str" : "823098",
      "id" : 823098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/vONl0xUtYK",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/status\/374941001057456128",
      "display_url" : "twitter.com\/qrush\/status\/3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "374951337223413761",
  "geo" : { },
  "id_str" : "374952539839414272",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake @duncan Did you just yank that from https:\/\/t.co\/vONl0xUtYK ? Would appreciate a credit if so :)",
  "id" : 374952539839414272,
  "in_reply_to_status_id" : 374951337223413761,
  "created_at" : "2013-09-03 17:50:26 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Higgins",
      "screen_name" : "RepBrianHiggins",
      "indices" : [ 3, 19 ],
      "id_str" : "33576489",
      "id" : 33576489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/6Vu6bnoHIU",
      "expanded_url" : "http:\/\/go.usa.gov\/DgQ4",
      "display_url" : "go.usa.gov\/DgQ4"
    } ]
  },
  "geo" : { },
  "id_str" : "374952176381992961",
  "text" : "RT @RepBrianHiggins: I will oppose American military intervention in Syria. Read my full statement here: http:\/\/t.co\/6Vu6bnoHIU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/6Vu6bnoHIU",
        "expanded_url" : "http:\/\/go.usa.gov\/DgQ4",
        "display_url" : "go.usa.gov\/DgQ4"
      } ]
    },
    "geo" : { },
    "id_str" : "374950474505404416",
    "text" : "I will oppose American military intervention in Syria. Read my full statement here: http:\/\/t.co\/6Vu6bnoHIU",
    "id" : 374950474505404416,
    "created_at" : "2013-09-03 17:42:14 +0000",
    "user" : {
      "name" : "Brian Higgins",
      "screen_name" : "RepBrianHiggins",
      "protected" : false,
      "id_str" : "33576489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523096705030320129\/55nJtODk_normal.jpeg",
      "id" : 33576489,
      "verified" : true
    }
  },
  "id" : 374952176381992961,
  "created_at" : "2013-09-03 17:48:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374944139101474816",
  "geo" : { },
  "id_str" : "374944501657124864",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV I feel there's some missing stats on finding parking downtown here",
  "id" : 374944501657124864,
  "in_reply_to_status_id" : 374944139101474816,
  "created_at" : "2013-09-03 17:18:29 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/wu5rKZDgX2",
      "expanded_url" : "https:\/\/github.com\/sstephenson\/s",
      "display_url" : "github.com\/sstephenson\/s"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/BPvXzOeTko",
      "expanded_url" : "http:\/\/sstephenson.github.io\/s\/",
      "display_url" : "sstephenson.github.io\/s\/"
    } ]
  },
  "geo" : { },
  "id_str" : "374944142729555968",
  "text" : "RT @sstephenson: Weekend hack: a baby Scheme interpreter with tail calls and call\/cc, written in CoffeeScript. https:\/\/t.co\/wu5rKZDgX2\nhttp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/wu5rKZDgX2",
        "expanded_url" : "https:\/\/github.com\/sstephenson\/s",
        "display_url" : "github.com\/sstephenson\/s"
      }, {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BPvXzOeTko",
        "expanded_url" : "http:\/\/sstephenson.github.io\/s\/",
        "display_url" : "sstephenson.github.io\/s\/"
      } ]
    },
    "geo" : { },
    "id_str" : "374943559087947777",
    "text" : "Weekend hack: a baby Scheme interpreter with tail calls and call\/cc, written in CoffeeScript. https:\/\/t.co\/wu5rKZDgX2\nhttp:\/\/t.co\/BPvXzOeTko",
    "id" : 374943559087947777,
    "created_at" : "2013-09-03 17:14:45 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 374944142729555968,
  "created_at" : "2013-09-03 17:17:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374941001057456128",
  "text" : "Android KitKat. Android Little Debbies. Android M&amp;Ms. Android Nutella.",
  "id" : 374941001057456128,
  "created_at" : "2013-09-03 17:04:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechValley RB",
      "screen_name" : "tvrb",
      "indices" : [ 3, 8 ],
      "id_str" : "138056822",
      "id" : 138056822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/Go4sSidq8c",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#schedule",
      "display_url" : "nickelcityruby.com\/#schedule"
    }, {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/cKQeZBMa0a",
      "expanded_url" : "http:\/\/bit.ly\/15pMrtS",
      "display_url" : "bit.ly\/15pMrtS"
    } ]
  },
  "geo" : { },
  "id_str" : "374934935334694912",
  "text" : "RT @tvrb: Nickel City Ruby: Hi Everyone,The schedule for Nickel City Ruby is up: http:\/\/t.co\/Go4sSidq8c The... http:\/\/t.co\/cKQeZBMa0a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/Go4sSidq8c",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#schedule",
        "display_url" : "nickelcityruby.com\/#schedule"
      }, {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/cKQeZBMa0a",
        "expanded_url" : "http:\/\/bit.ly\/15pMrtS",
        "display_url" : "bit.ly\/15pMrtS"
      } ]
    },
    "geo" : { },
    "id_str" : "374924214907576320",
    "text" : "Nickel City Ruby: Hi Everyone,The schedule for Nickel City Ruby is up: http:\/\/t.co\/Go4sSidq8c The... http:\/\/t.co\/cKQeZBMa0a",
    "id" : 374924214907576320,
    "created_at" : "2013-09-03 15:57:53 +0000",
    "user" : {
      "name" : "TechValley RB",
      "screen_name" : "tvrb",
      "protected" : false,
      "id_str" : "138056822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1596294659\/TVRBLogo-egg_normal.jpg",
      "id" : 138056822,
      "verified" : false
    }
  },
  "id" : 374934935334694912,
  "created_at" : "2013-09-03 16:40:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Menard",
      "screen_name" : "mark_menard",
      "indices" : [ 3, 15 ],
      "id_str" : "13168222",
      "id" : 13168222
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 33, 48 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374918686517100544",
  "text" : "RT @mark_menard: Got my room for @nickelcityruby. There are still discounted rooms available. Get yours now.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 16, 31 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374917923930116096",
    "text" : "Got my room for @nickelcityruby. There are still discounted rooms available. Get yours now.",
    "id" : 374917923930116096,
    "created_at" : "2013-09-03 15:32:53 +0000",
    "user" : {
      "name" : "Mark Menard",
      "screen_name" : "mark_menard",
      "protected" : false,
      "id_str" : "13168222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444487338647769088\/bXO_JEA6_normal.jpeg",
      "id" : 13168222,
      "verified" : false
    }
  },
  "id" : 374918686517100544,
  "created_at" : "2013-09-03 15:35:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avi Flombaum",
      "screen_name" : "aviflombaum",
      "indices" : [ 0, 12 ],
      "id_str" : "2085091",
      "id" : 2085091
    }, {
      "name" : "Flatiron School",
      "screen_name" : "FlatironSchool",
      "indices" : [ 30, 45 ],
      "id_str" : "702354494",
      "id" : 702354494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/YJWat2Hg3F",
      "expanded_url" : "http:\/\/nickelcityruby.com\/bus\/",
      "display_url" : "nickelcityruby.com\/bus\/"
    } ]
  },
  "in_reply_to_status_id_str" : "374916781082542080",
  "geo" : { },
  "id_str" : "374917025123934209",
  "in_reply_to_user_id" : 2085091,
  "text" : "@aviflombaum Thanks! I'm sure @FlatironSchool could use the field trip too... http:\/\/t.co\/YJWat2Hg3F",
  "id" : 374917025123934209,
  "in_reply_to_status_id" : 374916781082542080,
  "created_at" : "2013-09-03 15:29:19 +0000",
  "in_reply_to_screen_name" : "aviflombaum",
  "in_reply_to_user_id_str" : "2085091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avi Flombaum",
      "screen_name" : "aviflombaum",
      "indices" : [ 0, 12 ],
      "id_str" : "2085091",
      "id" : 2085091
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 41, 56 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374916548684550145",
  "in_reply_to_user_id" : 2085091,
  "text" : "@aviflombaum hey, I sent a message about @nickelcityruby to the NYC on Rails list. I'd appreciate a bump :)",
  "id" : 374916548684550145,
  "created_at" : "2013-09-03 15:27:25 +0000",
  "in_reply_to_screen_name" : "aviflombaum",
  "in_reply_to_user_id_str" : "2085091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Millions",
      "screen_name" : "evil_trout",
      "indices" : [ 0, 11 ],
      "id_str" : "2494449480",
      "id" : 2494449480
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 12, 20 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 87, 97 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374888332615876608",
  "geo" : { },
  "id_str" : "374900282817138688",
  "in_reply_to_user_id" : 16712921,
  "text" : "@evil_trout @wnyruby Awesome, maybe for October's meeting (if we have space left)? \/cc @aspleenic (Also, Village Beer Merchant FTW)",
  "id" : 374900282817138688,
  "in_reply_to_status_id" : 374888332615876608,
  "created_at" : "2013-09-03 14:22:47 +0000",
  "in_reply_to_screen_name" : "eviltrout",
  "in_reply_to_user_id_str" : "16712921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Ypn2v03PoI",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "374900069079584768",
  "text" : "RT @nickelcityruby: Just 17 days remain until NickelCityRuby!! Why don't you have a ticket yet? http:\/\/t.co\/Ypn2v03PoI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/Ypn2v03PoI",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "374893896477581312",
    "text" : "Just 17 days remain until NickelCityRuby!! Why don't you have a ticket yet? http:\/\/t.co\/Ypn2v03PoI",
    "id" : 374893896477581312,
    "created_at" : "2013-09-03 13:57:24 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 374900069079584768,
  "created_at" : "2013-09-03 14:21:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374856593395167232",
  "geo" : { },
  "id_str" : "374875331930234880",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton @melissadclayton most are just blurry or over\/under exposed. Blergh!",
  "id" : 374875331930234880,
  "in_reply_to_status_id" : 374856593395167232,
  "created_at" : "2013-09-03 12:43:38 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/dqH0l8iCoV",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=lQpOT2CclF8",
      "display_url" : "youtube.com\/watch?v=lQpOT2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374738364567543808",
  "text" : "\"Cool\" http:\/\/t.co\/dqH0l8iCoV",
  "id" : 374738364567543808,
  "created_at" : "2013-09-03 03:39:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Millions",
      "screen_name" : "evil_trout",
      "indices" : [ 0, 11 ],
      "id_str" : "2494449480",
      "id" : 2494449480
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 96, 104 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374716504761040896",
  "geo" : { },
  "id_str" : "374735428055621632",
  "in_reply_to_user_id" : 16712921,
  "text" : "@evil_trout Dang. Offer is open anytime then. Maybe we could get you to talk about Discourse at @wnyruby?",
  "id" : 374735428055621632,
  "in_reply_to_status_id" : 374716504761040896,
  "created_at" : "2013-09-03 03:27:42 +0000",
  "in_reply_to_screen_name" : "eviltrout",
  "in_reply_to_user_id_str" : "16712921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374732456932696064",
  "geo" : { },
  "id_str" : "374733466086027265",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal just got my first serious camera, so just learning by doing for now.",
  "id" : 374733466086027265,
  "in_reply_to_status_id" : 374732456932696064,
  "created_at" : "2013-09-03 03:19:55 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/uTmKRV57tu",
      "expanded_url" : "http:\/\/flic.kr\/p\/fHtsfa",
      "display_url" : "flic.kr\/p\/fHtsfa"
    } ]
  },
  "geo" : { },
  "id_str" : "374732368507969537",
  "text" : "Colors under UV light are a lot of fun.  http:\/\/t.co\/uTmKRV57tu",
  "id" : 374732368507969537,
  "created_at" : "2013-09-03 03:15:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374732021475459072",
  "geo" : { },
  "id_str" : "374732177583251456",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal Not an option! :)",
  "id" : 374732177583251456,
  "in_reply_to_status_id" : 374732021475459072,
  "created_at" : "2013-09-03 03:14:47 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/qHa94bNeep",
      "expanded_url" : "http:\/\/inspiringtechquotes.info\/",
      "display_url" : "inspiringtechquotes.info"
    } ]
  },
  "geo" : { },
  "id_str" : "374730882533179392",
  "text" : "This is pretty genius: http:\/\/t.co\/qHa94bNeep",
  "id" : 374730882533179392,
  "created_at" : "2013-09-03 03:09:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374730385768210432",
  "text" : "86 photos taken today, happy with 4 of them. Depressing ratio.",
  "id" : 374730385768210432,
  "created_at" : "2013-09-03 03:07:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Millions",
      "screen_name" : "evil_trout",
      "indices" : [ 0, 11 ],
      "id_str" : "2494449480",
      "id" : 2494449480
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 30, 45 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374681799458172928",
  "geo" : { },
  "id_str" : "374697295532417025",
  "in_reply_to_user_id" : 16712921,
  "text" : "@evil_trout are you coming to @nickelcityruby ? I\u2019d love to talk about this. And maybe treat you to some froyo (with sprinkles)",
  "id" : 374697295532417025,
  "in_reply_to_status_id" : 374681799458172928,
  "created_at" : "2013-09-03 00:56:11 +0000",
  "in_reply_to_screen_name" : "eviltrout",
  "in_reply_to_user_id_str" : "16712921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 3, 17 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 19, 25 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 26, 41 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/79uv6aPG5K",
      "expanded_url" : "http:\/\/blog.ccbcmd.edu\/rcoradin\/files\/2011\/04\/spongebob-ready.jpg",
      "display_url" : "blog.ccbcmd.edu\/rcoradin\/files\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374670434978902018",
  "text" : "RT @Carols10cents: @qrush @nickelcityruby http:\/\/t.co\/79uv6aPG5K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 7, 22 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/79uv6aPG5K",
        "expanded_url" : "http:\/\/blog.ccbcmd.edu\/rcoradin\/files\/2011\/04\/spongebob-ready.jpg",
        "display_url" : "blog.ccbcmd.edu\/rcoradin\/files\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "374600255289192448",
    "geo" : { },
    "id_str" : "374665344314400768",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush @nickelcityruby http:\/\/t.co\/79uv6aPG5K",
    "id" : 374665344314400768,
    "in_reply_to_status_id" : 374600255289192448,
    "created_at" : "2013-09-02 22:49:13 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "protected" : false,
      "id_str" : "194688433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446291681252364288\/_okxMUY1_normal.jpeg",
      "id" : 194688433,
      "verified" : false
    }
  },
  "id" : 374670434978902018,
  "created_at" : "2013-09-02 23:09:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 29, 44 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374600255289192448",
  "text" : "Getting closer and closer to @nickelcityruby! Are you ready yet?",
  "id" : 374600255289192448,
  "created_at" : "2013-09-02 18:30:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374561361021644800",
  "geo" : { },
  "id_str" : "374562744584138752",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox we did a lot of this the past few weeks. Refreshing!",
  "id" : 374562744584138752,
  "in_reply_to_status_id" : 374561361021644800,
  "created_at" : "2013-09-02 16:01:32 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 65, 72 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/HhvDAgal2W",
      "expanded_url" : "http:\/\/bit.ly\/14jQsQs",
      "display_url" : "bit.ly\/14jQsQs"
    } ]
  },
  "geo" : { },
  "id_str" : "374549995313045504",
  "text" : "Ladies and gentlemen, Nicholas Cage. http:\/\/t.co\/HhvDAgal2W (via @lsegal)",
  "id" : 374549995313045504,
  "created_at" : "2013-09-02 15:10:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/374396868274315265\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/Shr2cJ1xXh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTIf99MCYAAwg7f.png",
      "id_str" : "374396868282703872",
      "id" : 374396868282703872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTIf99MCYAAwg7f.png",
      "sizes" : [ {
        "h" : 251,
        "resize" : "fit",
        "w" : 411
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 251,
        "resize" : "fit",
        "w" : 411
      }, {
        "h" : 251,
        "resize" : "fit",
        "w" : 411
      } ],
      "display_url" : "pic.twitter.com\/Shr2cJ1xXh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374396868274315265",
  "text" : "What did I do to Chrome to deserve this awful URL bar behavior? http:\/\/t.co\/Shr2cJ1xXh",
  "id" : 374396868274315265,
  "created_at" : "2013-09-02 05:02:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Eskildsen",
      "screen_name" : "Sirupsen",
      "indices" : [ 0, 9 ],
      "id_str" : "29170474",
      "id" : 29170474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374393914351841281",
  "geo" : { },
  "id_str" : "374394577504845824",
  "in_reply_to_user_id" : 29170474,
  "text" : "@Sirupsen Should be!",
  "id" : 374394577504845824,
  "in_reply_to_status_id" : 374393914351841281,
  "created_at" : "2013-09-02 04:53:17 +0000",
  "in_reply_to_screen_name" : "Sirupsen",
  "in_reply_to_user_id_str" : "29170474",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 115, 124 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "374393027650793473",
  "text" : "New http:\/\/t.co\/2bA9BVLhWr LB's log was stuck, stopping pushes for a few hours. Writeup coming. Sorry everyone. :( @rubygems feed is alive!",
  "id" : 374393027650793473,
  "created_at" : "2013-09-02 04:47:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 0, 9 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "James Cox",
      "screen_name" : "imajes",
      "indices" : [ 10, 17 ],
      "id_str" : "75533",
      "id" : 75533
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 18, 25 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 26, 34 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374388490722500608",
  "geo" : { },
  "id_str" : "374389217599565824",
  "in_reply_to_user_id" : 5743852,
  "text" : "@indirect @imajes @hone02 @evanphx no errors in production.log, none in NewRelic, no AWS issues, but lots of reports of problems. WTF?",
  "id" : 374389217599565824,
  "in_reply_to_status_id" : 374388490722500608,
  "created_at" : "2013-09-02 04:31:59 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 0, 9 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "James Cox",
      "screen_name" : "imajes",
      "indices" : [ 10, 17 ],
      "id_str" : "75533",
      "id" : 75533
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 18, 25 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 26, 34 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374386308623261696",
  "geo" : { },
  "id_str" : "374388490722500608",
  "in_reply_to_user_id" : 5743852,
  "text" : "@indirect @imajes @hone02 @evanphx on IRC now if you guys are on. something's fucky.",
  "id" : 374388490722500608,
  "in_reply_to_status_id" : 374386308623261696,
  "created_at" : "2013-09-02 04:29:06 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374387294389960705",
  "geo" : { },
  "id_str" : "374387574665531392",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler trying to bring more folks in :) also ugh the hide button.",
  "id" : 374387574665531392,
  "in_reply_to_status_id" : 374387294389960705,
  "created_at" : "2013-09-02 04:25:28 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 0, 9 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "James Cox",
      "screen_name" : "imajes",
      "indices" : [ 10, 17 ],
      "id_str" : "75533",
      "id" : 75533
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 18, 25 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "374382458877140992",
  "geo" : { },
  "id_str" : "374386308623261696",
  "in_reply_to_user_id" : 5674672,
  "text" : "@indirect @imajes @hone02 seeing a lot of 500 reports on help &amp; on twitter search for http:\/\/t.co\/2bA9BVLhWr",
  "id" : 374386308623261696,
  "in_reply_to_status_id" : 374382458877140992,
  "created_at" : "2013-09-02 04:20:26 +0000",
  "in_reply_to_screen_name" : "indirect",
  "in_reply_to_user_id_str" : "5674672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374374931553058816",
  "geo" : { },
  "id_str" : "374375937606836224",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler woot woot",
  "id" : 374375937606836224,
  "in_reply_to_status_id" : 374374931553058816,
  "created_at" : "2013-09-02 03:39:13 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 3, 14 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374375918568865793",
  "text" : "RT @samkottler: Presentation for nickel city ruby is done \u2603 \u2665 \uD83D\uDE31",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374374931553058816",
    "text" : "Presentation for nickel city ruby is done \u2603 \u2665 \uD83D\uDE31",
    "id" : 374374931553058816,
    "created_at" : "2013-09-02 03:35:13 +0000",
    "user" : {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "protected" : false,
      "id_str" : "103914540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572808884675301376\/whqN3Ix2_normal.jpeg",
      "id" : 103914540,
      "verified" : false
    }
  },
  "id" : 374375918568865793,
  "created_at" : "2013-09-02 03:39:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/KyYMBNw0VJ",
      "expanded_url" : "http:\/\/flic.kr\/p\/fGVE7u",
      "display_url" : "flic.kr\/p\/fGVE7u"
    } ]
  },
  "geo" : { },
  "id_str" : "374373780203663361",
  "text" : "Having too much fun with this camera's advanced filters: http:\/\/t.co\/KyYMBNw0VJ",
  "id" : 374373780203663361,
  "created_at" : "2013-09-02 03:30:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Cox",
      "screen_name" : "imajes",
      "indices" : [ 0, 7 ],
      "id_str" : "75533",
      "id" : 75533
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 26, 35 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 36, 43 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374257122739245056",
  "geo" : { },
  "id_str" : "374272968261509120",
  "in_reply_to_user_id" : 75533,
  "text" : "@imajes not around today\u2026 @indirect @hone02 any ideas?",
  "id" : 374272968261509120,
  "in_reply_to_status_id" : 374257122739245056,
  "created_at" : "2013-09-01 20:50:03 +0000",
  "in_reply_to_screen_name" : "imajes",
  "in_reply_to_user_id_str" : "75533",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Stucki",
      "screen_name" : "brianstucki",
      "indices" : [ 0, 12 ],
      "id_str" : "14448894",
      "id" : 14448894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373563394730627072",
  "geo" : { },
  "id_str" : "374208482796269568",
  "in_reply_to_user_id" : 14448894,
  "text" : "@brianstucki what's wrong with the iOS app for you? I can help!",
  "id" : 374208482796269568,
  "in_reply_to_status_id" : 373563394730627072,
  "created_at" : "2013-09-01 16:33:49 +0000",
  "in_reply_to_screen_name" : "brianstucki",
  "in_reply_to_user_id_str" : "14448894",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 13, 24 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374203779299557376",
  "text" : "@juliepagano @ashedryden curious, what event is this happening to?",
  "id" : 374203779299557376,
  "created_at" : "2013-09-01 16:15:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374197870859399169",
  "text" : "RT @ashedryden: You have to be thinking about it when writing your policies, deciding on your proposal process, and doing outreach.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374197121714364417",
    "text" : "You have to be thinking about it when writing your policies, deciding on your proposal process, and doing outreach.",
    "id" : 374197121714364417,
    "created_at" : "2013-09-01 15:48:40 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 374197870859399169,
  "created_at" : "2013-09-01 15:51:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374197850810621952",
  "text" : "RT @ashedryden: I appreciate that people are seeing lack of diversity at confs as more of a problem, but you can't tack it on at the end as\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374196937739616256",
    "text" : "I appreciate that people are seeing lack of diversity at confs as more of a problem, but you can't tack it on at the end as an after-thought",
    "id" : 374196937739616256,
    "created_at" : "2013-09-01 15:47:56 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 374197850810621952,
  "created_at" : "2013-09-01 15:51:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 3, 16 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374197825888092160",
  "text" : "RT @lindseybieda: Whose job is it to make sure your CFPs gets diverse respondents? Yours. If you build it they will come doesn't work with \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373935826905731072",
    "text" : "Whose job is it to make sure your CFPs gets diverse respondents? Yours. If you build it they will come doesn't work with minorities.",
    "id" : 373935826905731072,
    "created_at" : "2013-08-31 22:30:23 +0000",
    "user" : {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "protected" : false,
      "id_str" : "14928483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569192760029089792\/zaGhTAHK_normal.jpeg",
      "id" : 14928483,
      "verified" : false
    }
  },
  "id" : 374197825888092160,
  "created_at" : "2013-09-01 15:51:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/2ARCzAED6w",
      "expanded_url" : "https:\/\/www.seas.harvard.edu\/news\/2013\/08\/transparent-artificial-muscle-plays-grieg-to-prove-point",
      "display_url" : "seas.harvard.edu\/news\/2013\/08\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374019243475365888",
  "text" : "Transparent speakers, I want one: https:\/\/t.co\/2ARCzAED6w",
  "id" : 374019243475365888,
  "created_at" : "2013-09-01 04:01:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
Grailbird.data.tweets_2014_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dudley Lunch ",
      "screen_name" : "wutanggoku",
      "indices" : [ 3, 14 ],
      "id_str" : "119145557",
      "id" : 119145557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461698870494625792",
  "text" : "RT @wutanggoku: \"it is time to perform Surgery\" *doc pours 20oz bottle of Surge into patients fresh incision*",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57163356146106368",
    "text" : "\"it is time to perform Surgery\" *doc pours 20oz bottle of Surge into patients fresh incision*",
    "id" : 57163356146106368,
    "created_at" : "2011-04-10 19:29:40 +0000",
    "user" : {
      "name" : "Dudley Lunch ",
      "screen_name" : "wutanggoku",
      "protected" : false,
      "id_str" : "119145557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573487043461783556\/WWXmLHso_normal.png",
      "id" : 119145557,
      "verified" : false
    }
  },
  "id" : 461698870494625792,
  "created_at" : "2014-05-01 02:49:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 47, 56 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/j3LWbIOgwe",
      "expanded_url" : "http:\/\/ffffound.com\/image\/9bf40b04a01fc58c6a6274390bccc96449277289?c=10436916",
      "display_url" : "ffffound.com\/image\/9bf40b04\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "461652500005654528",
  "geo" : { },
  "id_str" : "461661976587173888",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove At the very least, make a gif like @shildner did. You might be (more) internet famous for it too. http:\/\/t.co\/j3LWbIOgwe",
  "id" : 461661976587173888,
  "in_reply_to_status_id" : 461652500005654528,
  "created_at" : "2014-05-01 00:22:47 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Miller",
      "screen_name" : "jqr",
      "indices" : [ 0, 4 ],
      "id_str" : "14351457",
      "id" : 14351457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461564889467600896",
  "geo" : { },
  "id_str" : "461565429576519680",
  "in_reply_to_user_id" : 14351457,
  "text" : "@jqr The former. And it's a local business (Rochester).",
  "id" : 461565429576519680,
  "in_reply_to_status_id" : 461564889467600896,
  "created_at" : "2014-04-30 17:59:08 +0000",
  "in_reply_to_screen_name" : "jqr",
  "in_reply_to_user_id_str" : "14351457",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/yYO94QMUwM",
      "expanded_url" : "http:\/\/www.thesnuggery.org\/rates_services.html",
      "display_url" : "thesnuggery.org\/rates_services\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461563621902778368",
  "text" : "It's that time again! Consultant\/freelancer friends, a reminder: The Double Snuggle is $120\/hour. http:\/\/t.co\/yYO94QMUwM",
  "id" : 461563621902778368,
  "created_at" : "2014-04-30 17:51:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Martek",
      "screen_name" : "cregatron",
      "indices" : [ 0, 10 ],
      "id_str" : "16892522",
      "id" : 16892522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461562968157589505",
  "geo" : { },
  "id_str" : "461563482710609920",
  "in_reply_to_user_id" : 16892522,
  "text" : "@cregatron oh good! Time for the reminder.",
  "id" : 461563482710609920,
  "in_reply_to_status_id" : 461562968157589505,
  "created_at" : "2014-04-30 17:51:24 +0000",
  "in_reply_to_screen_name" : "cregatron",
  "in_reply_to_user_id_str" : "16892522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461493429810114561",
  "text" : "RT @dhh: When did trolling get redefined as \"any position I disagree with\"?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461206530889883648",
    "text" : "When did trolling get redefined as \"any position I disagree with\"?",
    "id" : 461206530889883648,
    "created_at" : "2014-04-29 18:13:00 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 461493429810114561,
  "created_at" : "2014-04-30 13:13:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 62, 68 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/bquarant\/status\/461365398789558272\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/7mRTObyXHd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmcZX45IEAAyM01.jpg",
      "id_str" : "461365385028440064",
      "id" : 461365385028440064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmcZX45IEAAyM01.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7mRTObyXHd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461369352336723968",
  "text" : "RT @bquarant: Found a vintage recliner across the street from @qrush http:\/\/t.co\/7mRTObyXHd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 48, 54 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/bquarant\/status\/461365398789558272\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/7mRTObyXHd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmcZX45IEAAyM01.jpg",
        "id_str" : "461365385028440064",
        "id" : 461365385028440064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmcZX45IEAAyM01.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7mRTObyXHd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461365398789558272",
    "text" : "Found a vintage recliner across the street from @qrush http:\/\/t.co\/7mRTObyXHd",
    "id" : 461365398789558272,
    "created_at" : "2014-04-30 04:44:17 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 461369352336723968,
  "created_at" : "2014-04-30 05:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461365398789558272",
  "geo" : { },
  "id_str" : "461369308338470912",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant DUDE",
  "id" : 461369308338470912,
  "in_reply_to_status_id" : 461365398789558272,
  "created_at" : "2014-04-30 04:59:49 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/461359708733861888\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/QuWRS966wm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmcUNfFCcAAxD7l.png",
      "id_str" : "461359708742250496",
      "id" : 461359708742250496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmcUNfFCcAAxD7l.png",
      "sizes" : [ {
        "h" : 118,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 2016
      }, {
        "h" : 208,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QuWRS966wm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461359708733861888",
  "text" : "One more d3 error that turned out wild: http:\/\/t.co\/QuWRS966wm",
  "id" : 461359708733861888,
  "created_at" : "2014-04-30 04:21:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461344933920505856",
  "geo" : { },
  "id_str" : "461345153391656960",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove can I crowdfund you?",
  "id" : 461345153391656960,
  "in_reply_to_status_id" : 461344933920505856,
  "created_at" : "2014-04-30 03:23:50 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 8, 19 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/COwDvwgOaK",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=XTe0h53tH24",
      "display_url" : "youtube.com\/watch?v=XTe0h5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461343999232442368",
  "text" : "I found @tenderlove's next speaking outfit https:\/\/t.co\/COwDvwgOaK",
  "id" : 461343999232442368,
  "created_at" : "2014-04-30 03:19:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/461343796907634688\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/L6tK4UZFpI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmcFvS5CcAAQhWk.png",
      "id_str" : "461343796911828992",
      "id" : 461343796911828992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmcFvS5CcAAQhWk.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1640
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/L6tK4UZFpI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461343796907634688",
  "text" : "Errors when using d3 are works of art sometimes. http:\/\/t.co\/L6tK4UZFpI",
  "id" : 461343796907634688,
  "created_at" : "2014-04-30 03:18:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/mDgTTVlijl",
      "expanded_url" : "https:\/\/analytics.twitter.com\/",
      "display_url" : "analytics.twitter.com"
    } ]
  },
  "geo" : { },
  "id_str" : "461333336187621377",
  "text" : "Ok, now this is awesome: https:\/\/t.co\/mDgTTVlijl",
  "id" : 461333336187621377,
  "created_at" : "2014-04-30 02:36:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/JDabHk7uzx",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Gabe_Berke-Williams",
      "display_url" : "en.wikipedia.org\/wiki\/Gabe_Berk\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "461330059274776577",
  "geo" : { },
  "id_str" : "461330542781136896",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw yep. http:\/\/t.co\/JDabHk7uzx",
  "id" : 461330542781136896,
  "in_reply_to_status_id" : 461330059274776577,
  "created_at" : "2014-04-30 02:25:47 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 0, 12 ],
      "id_str" : "156708162",
      "id" : 156708162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461296614481481729",
  "geo" : { },
  "id_str" : "461303903011614720",
  "in_reply_to_user_id" : 156708162,
  "text" : "@barelyknown totally agreed! maybe in a few weeks? email me - nick [at] quaran.to",
  "id" : 461303903011614720,
  "in_reply_to_status_id" : 461296614481481729,
  "created_at" : "2014-04-30 00:39:55 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elijah geis",
      "screen_name" : "ziggyfluff",
      "indices" : [ 0, 11 ],
      "id_str" : "976500703",
      "id" : 976500703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461303770299654144",
  "in_reply_to_user_id" : 976500703,
  "text" : "@ziggyfluff hey, I think it's you...got an email? :)",
  "id" : 461303770299654144,
  "created_at" : "2014-04-30 00:39:24 +0000",
  "in_reply_to_screen_name" : "ziggyfluff",
  "in_reply_to_user_id_str" : "976500703",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 0, 12 ],
      "id_str" : "156708162",
      "id" : 156708162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461284177531269121",
  "geo" : { },
  "id_str" : "461296013219594240",
  "in_reply_to_user_id" : 156708162,
  "text" : "@barelyknown huh! that'd be a first. I'd have to think about it. It's mostly in beta still :) Curious...why?",
  "id" : 461296013219594240,
  "in_reply_to_status_id" : 461284177531269121,
  "created_at" : "2014-04-30 00:08:34 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461273172440932352",
  "text" : "Some days Software Wizards are more like Software Ice Kings.",
  "id" : 461273172440932352,
  "created_at" : "2014-04-29 22:37:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461181831837003777",
  "text" : "RT @rubygems_status: In an effort to improve and fix issues with gems, we've switched everyone over to using Cloudfront. Let us know if you\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461181721103192064",
    "text" : "In an effort to improve and fix issues with gems, we've switched everyone over to using Cloudfront. Let us know if you see issues!",
    "id" : 461181721103192064,
    "created_at" : "2014-04-29 16:34:25 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 461181831837003777,
  "created_at" : "2014-04-29 16:34:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/tmjJwC6A1A",
      "expanded_url" : "http:\/\/1.bp.blogspot.com\/-LxhtsNgYWmo\/TvMoNWhrreI\/AAAAAAAAB9E\/YcZ8zD6GjsI\/s1600\/hypercyube+torus.gif",
      "display_url" : "1.bp.blogspot.com\/-LxhtsNgYWmo\/T\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "461148151424892928",
  "geo" : { },
  "id_str" : "461148604619448321",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove too slow. we're already on Hypercubical Rails 4.D: http:\/\/t.co\/tmjJwC6A1A",
  "id" : 461148604619448321,
  "in_reply_to_status_id" : 461148151424892928,
  "created_at" : "2014-04-29 14:22:49 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461146423954644992",
  "text" : "RT @dhh: Basecamp by the numbers: ~70 million Rails requests\/day, 1.5 terabyte database, half a petabyte of file storage, 100 physical mach\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461145907095166976",
    "text" : "Basecamp by the numbers: ~70 million Rails requests\/day, 1.5 terabyte database, half a petabyte of file storage, 100 physical machines.",
    "id" : 461145907095166976,
    "created_at" : "2014-04-29 14:12:06 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 461146423954644992,
  "created_at" : "2014-04-29 14:14:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Buffalo News",
      "screen_name" : "TheBuffaloNews",
      "indices" : [ 64, 79 ],
      "id_str" : "43805270",
      "id" : 43805270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/ErLatDg8Ln",
      "expanded_url" : "https:\/\/www.syncaccess.net\/bh\/bn\/Content\/themes\/base\/images\/default\/default\/2.png",
      "display_url" : "syncaccess.net\/bh\/bn\/Content\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461130456553906176",
  "text" : "This is quite possibly the worst stock photography I've seen on @TheBuffaloNews: https:\/\/t.co\/ErLatDg8Ln",
  "id" : 461130456553906176,
  "created_at" : "2014-04-29 13:10:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/oHpkN7xmQW",
      "expanded_url" : "http:\/\/clrlv.rs\/1nAgyMe",
      "display_url" : "clrlv.rs\/1nAgyMe"
    } ]
  },
  "geo" : { },
  "id_str" : "460945153734103040",
  "text" : "An aptly named color: \"Lake Erie\" http:\/\/t.co\/oHpkN7xmQW",
  "id" : 460945153734103040,
  "created_at" : "2014-04-29 00:54:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/460909048389308416\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/PWsa1guBBb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmV6VlxCMAA5dl4.jpg",
      "id_str" : "460909048208961536",
      "id" : 460909048208961536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmV6VlxCMAA5dl4.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PWsa1guBBb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1949404406, -80.560129228 ]
  },
  "id_str" : "460909048389308416",
  "text" : "Something tells me this is against Twitter\u2019s brand guidelines. http:\/\/t.co\/PWsa1guBBb",
  "id" : 460909048389308416,
  "created_at" : "2014-04-28 22:30:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 0, 7 ],
      "id_str" : "9038902",
      "id" : 9038902
    }, {
      "name" : "THAT isaac",
      "screen_name" : "izs",
      "indices" : [ 8, 12 ],
      "id_str" : "8038312",
      "id" : 8038312
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 13, 21 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460870298745966592",
  "geo" : { },
  "id_str" : "460882342999887872",
  "in_reply_to_user_id" : 9038902,
  "text" : "@searls @izs @evanphx thanks, I really needed this today.",
  "id" : 460882342999887872,
  "in_reply_to_status_id" : 460870298745966592,
  "created_at" : "2014-04-28 20:44:48 +0000",
  "in_reply_to_screen_name" : "searls",
  "in_reply_to_user_id_str" : "9038902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 3, 10 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Godfrey Chan",
      "screen_name" : "chancancode",
      "indices" : [ 121, 133 ],
      "id_str" : "55032805",
      "id" : 55032805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/EUhgQWdkAK",
      "expanded_url" : "https:\/\/github.com\/rails\/rails\/pull\/14811\/files",
      "display_url" : "github.com\/rails\/rails\/pu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "460804729329573888",
  "text" : "RT @sferik: Rails is no longer opinionated about whether you should work from coffee shops. https:\/\/t.co\/EUhgQWdkAK (via @chancancode\u2019s Rai\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Godfrey Chan",
        "screen_name" : "chancancode",
        "indices" : [ 109, 121 ],
        "id_str" : "55032805",
        "id" : 55032805
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/EUhgQWdkAK",
        "expanded_url" : "https:\/\/github.com\/rails\/rails\/pull\/14811\/files",
        "display_url" : "github.com\/rails\/rails\/pu\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 52.541068843, 13.4071364172 ]
    },
    "id_str" : "460686706363363328",
    "text" : "Rails is no longer opinionated about whether you should work from coffee shops. https:\/\/t.co\/EUhgQWdkAK (via @chancancode\u2019s Rails Weekly)",
    "id" : 460686706363363328,
    "created_at" : "2014-04-28 07:47:24 +0000",
    "user" : {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "protected" : false,
      "id_str" : "7505382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567932260847206401\/ErQwT5za_normal.jpeg",
      "id" : 7505382,
      "verified" : false
    }
  },
  "id" : 460804729329573888,
  "created_at" : "2014-04-28 15:36:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beardo",
      "screen_name" : "Mechaphil",
      "indices" : [ 0, 10 ],
      "id_str" : "250785234",
      "id" : 250785234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/PviV5ob24O",
      "expanded_url" : "https:\/\/ifttt.com\/recipes\/147701-text-me-erie-county-ny-buffalo-weather-alerts-from-national-weather-service",
      "display_url" : "ifttt.com\/recipes\/147701\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "460804184955056129",
  "geo" : { },
  "id_str" : "460804372973096960",
  "in_reply_to_user_id" : 250785234,
  "text" : "@Mechaphil https:\/\/t.co\/PviV5ob24O",
  "id" : 460804372973096960,
  "in_reply_to_status_id" : 460804184955056129,
  "created_at" : "2014-04-28 15:34:58 +0000",
  "in_reply_to_screen_name" : "Mechaphil",
  "in_reply_to_user_id_str" : "250785234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Williams",
      "screen_name" : "j_m_williams",
      "indices" : [ 0, 13 ],
      "id_str" : "16210953",
      "id" : 16210953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460791678257750017",
  "geo" : { },
  "id_str" : "460792263887450112",
  "in_reply_to_user_id" : 16210953,
  "text" : "@j_m_williams About time!",
  "id" : 460792263887450112,
  "in_reply_to_status_id" : 460791678257750017,
  "created_at" : "2014-04-28 14:46:51 +0000",
  "in_reply_to_screen_name" : "j_m_williams",
  "in_reply_to_user_id_str" : "16210953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/I70nr6LZTr",
      "expanded_url" : "http:\/\/aqueousband.net\/songs",
      "display_url" : "aqueousband.net\/songs"
    } ]
  },
  "geo" : { },
  "id_str" : "460772222408196096",
  "text" : "(ICYMI) Sparklines in d3 are an awesome way to quickly show tons of data: http:\/\/t.co\/I70nr6LZTr",
  "id" : 460772222408196096,
  "created_at" : "2014-04-28 13:27:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460633989930180608",
  "text" : "OOM memory issues fixed by retuning cache_key (for Memcache). Ironic?",
  "id" : 460633989930180608,
  "created_at" : "2014-04-28 04:17:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460609077370818560",
  "text" : "And of course, horking up Heroku: \"Error R14 (Memory quota exceeded)\"",
  "id" : 460609077370818560,
  "created_at" : "2014-04-28 02:38:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/I70nr6LZTr",
      "expanded_url" : "http:\/\/aqueousband.net\/songs",
      "display_url" : "aqueousband.net\/songs"
    } ]
  },
  "geo" : { },
  "id_str" : "460608727494557696",
  "text" : "d3 is always fun to play around with (and hard to optimize). Simple sparklines for songs played at a show: http:\/\/t.co\/I70nr6LZTr",
  "id" : 460608727494557696,
  "created_at" : "2014-04-28 02:37:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carly Weiser",
      "screen_name" : "Cult_Carly",
      "indices" : [ 0, 11 ],
      "id_str" : "386018013",
      "id" : 386018013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460545293159649280",
  "geo" : { },
  "id_str" : "460578030948466688",
  "in_reply_to_user_id" : 386018013,
  "text" : "@Cult_Carly random rest area on I-80E in Ohio.",
  "id" : 460578030948466688,
  "in_reply_to_status_id" : 460545293159649280,
  "created_at" : "2014-04-28 00:35:34 +0000",
  "in_reply_to_screen_name" : "Cult_Carly",
  "in_reply_to_user_id_str" : "386018013",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/460531883349397505\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/CzK5tpfprf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmQjTsUIIAAIHsn.jpg",
      "id_str" : "460531883118698496",
      "id" : 460531883118698496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmQjTsUIIAAIHsn.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/CzK5tpfprf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.3777797082, -82.2252223931 ]
  },
  "id_str" : "460531883349397505",
  "text" : "Only 50\u00A2 to attend the World Cup (\u201894), wow! http:\/\/t.co\/CzK5tpfprf",
  "id" : 460531883349397505,
  "created_at" : "2014-04-27 21:32:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460294777716473856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8893239781, -87.6220224847 ]
  },
  "id_str" : "460295460494643200",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant are you playing minecraft?",
  "id" : 460295460494643200,
  "in_reply_to_status_id" : 460294777716473856,
  "created_at" : "2014-04-27 05:52:44 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bradford do\u00A3\u00A3a sign",
      "screen_name" : "LusciousPear",
      "indices" : [ 0, 13 ],
      "id_str" : "15829680",
      "id" : 15829680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460293864654254082",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8891643596, -87.6215816701 ]
  },
  "id_str" : "460294665825030145",
  "in_reply_to_user_id" : 15829680,
  "text" : "@LusciousPear Randy has a shirt (and pants) on!",
  "id" : 460294665825030145,
  "in_reply_to_status_id" : 460293864654254082,
  "created_at" : "2014-04-27 05:49:34 +0000",
  "in_reply_to_screen_name" : "LusciousPear",
  "in_reply_to_user_id_str" : "15829680",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Burdette",
      "screen_name" : "AaronBurdette",
      "indices" : [ 3, 17 ],
      "id_str" : "14467743",
      "id" : 14467743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460291881654444032",
  "text" : "RT @AaronBurdette: Mario returns from another day of golfing, karting and tennis. \"Did you do any plumbing today?\" his wife asks. A hungry \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "272213107454128129",
    "text" : "Mario returns from another day of golfing, karting and tennis. \"Did you do any plumbing today?\" his wife asks. A hungry baby cries.",
    "id" : 272213107454128129,
    "created_at" : "2012-11-24 05:40:36 +0000",
    "user" : {
      "name" : "Aaron Burdette",
      "screen_name" : "AaronBurdette",
      "protected" : false,
      "id_str" : "14467743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3188900926\/abc07b568007e4180dd3521fa1ff7015_normal.jpeg",
      "id" : 14467743,
      "verified" : false
    }
  },
  "id" : 460291881654444032,
  "created_at" : "2014-04-27 05:38:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/ylbCJ7XBNS",
      "expanded_url" : "http:\/\/aqueousband.net\/shows\/2014-04-26",
      "display_url" : "aqueousband.net\/shows\/2014-04-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "460253534143791104",
  "text" : "Missing out on my favorite hometown band but catching set list updates from the floor live: awesome. http:\/\/t.co\/ylbCJ7XBNS",
  "id" : 460253534143791104,
  "created_at" : "2014-04-27 03:06:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Clay Shafer",
      "screen_name" : "littleidea",
      "indices" : [ 0, 11 ],
      "id_str" : "14079705",
      "id" : 14079705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/wCsxAXRmfr",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "460248578351722497",
  "geo" : { },
  "id_str" : "460252157711634432",
  "in_reply_to_user_id" : 14079705,
  "text" : "@littleidea http:\/\/t.co\/wCsxAXRmfr was TDD\u2019d with cukes too. Total pain to maintain those now.",
  "id" : 460252157711634432,
  "in_reply_to_status_id" : 460248578351722497,
  "created_at" : "2014-04-27 03:00:40 +0000",
  "in_reply_to_screen_name" : "littleidea",
  "in_reply_to_user_id_str" : "14079705",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Becker",
      "screen_name" : "veganstraightedge",
      "indices" : [ 0, 18 ],
      "id_str" : "641013",
      "id" : 641013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460233194768318465",
  "geo" : { },
  "id_str" : "460233573727870976",
  "in_reply_to_user_id" : 641013,
  "text" : "@veganstraightedge Cool. The bear is great, but it would be nice if it said that.",
  "id" : 460233573727870976,
  "in_reply_to_status_id" : 460233194768318465,
  "created_at" : "2014-04-27 01:46:49 +0000",
  "in_reply_to_screen_name" : "veganstraightedge",
  "in_reply_to_user_id_str" : "641013",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Source Offsets",
      "screen_name" : "opensource",
      "indices" : [ 0, 11 ],
      "id_str" : "419159838",
      "id" : 419159838
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 12, 20 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Melissa Severini",
      "screen_name" : "luckiestmonkey",
      "indices" : [ 21, 36 ],
      "id_str" : "7141792",
      "id" : 7141792
    }, {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 37, 46 ],
      "id_str" : "14164724",
      "id" : 14164724
    }, {
      "name" : "Matt Kern",
      "screen_name" : "lightcap",
      "indices" : [ 47, 56 ],
      "id_str" : "667803",
      "id" : 667803
    }, {
      "name" : "Ian McFarland",
      "screen_name" : "imf",
      "indices" : [ 57, 61 ],
      "id_str" : "1260941",
      "id" : 1260941
    }, {
      "name" : "Shane Becker",
      "screen_name" : "veganstraightedge",
      "indices" : [ 62, 80 ],
      "id_str" : "641013",
      "id" : 641013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460227105578426372",
  "geo" : { },
  "id_str" : "460232989461340160",
  "in_reply_to_user_id" : 419159838,
  "text" : "@opensource @evanphx @luckiestmonkey @sarahmei @lightcap @imf @veganstraightedge what is this?",
  "id" : 460232989461340160,
  "in_reply_to_status_id" : 460227105578426372,
  "created_at" : "2014-04-27 01:44:30 +0000",
  "in_reply_to_screen_name" : "opensource",
  "in_reply_to_user_id_str" : "419159838",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/jynsxlg9VQ",
      "expanded_url" : "https:\/\/flic.kr\/p\/nkqRhd",
      "display_url" : "flic.kr\/p\/nkqRhd"
    } ]
  },
  "geo" : { },
  "id_str" : "460220617841991680",
  "text" : "Tilt-shift filter on the X100S feels like cheating. Awesome cheating. https:\/\/t.co\/jynsxlg9VQ",
  "id" : 460220617841991680,
  "created_at" : "2014-04-27 00:55:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Evans",
      "screen_name" : "b0rk",
      "indices" : [ 3, 8 ],
      "id_str" : "6603532",
      "id" : 6603532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/lUW7QeTjRx",
      "expanded_url" : "http:\/\/jvns.ca\/blog\/2014\/04\/26\/i-dont-feel-guilty-about-not-contributing-to-open-source\/",
      "display_url" : "jvns.ca\/blog\/2014\/04\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "460176983163285504",
  "text" : "RT @b0rk: Don\u2019t feel guilty about not contributing to open source  http:\/\/t.co\/lUW7QeTjRx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/lUW7QeTjRx",
        "expanded_url" : "http:\/\/jvns.ca\/blog\/2014\/04\/26\/i-dont-feel-guilty-about-not-contributing-to-open-source\/",
        "display_url" : "jvns.ca\/blog\/2014\/04\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "460088011821027328",
    "text" : "Don\u2019t feel guilty about not contributing to open source  http:\/\/t.co\/lUW7QeTjRx",
    "id" : 460088011821027328,
    "created_at" : "2014-04-26 16:08:24 +0000",
    "user" : {
      "name" : "Julia Evans",
      "screen_name" : "b0rk",
      "protected" : false,
      "id_str" : "6603532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500666963756982273\/KGCoCe4y_normal.jpeg",
      "id" : 6603532,
      "verified" : false
    }
  },
  "id" : 460176983163285504,
  "created_at" : "2014-04-26 22:01:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.889513594, -87.6195033076 ]
  },
  "id_str" : "460173002861076481",
  "text" : "Just invented a new parenting technique: Pair Pram Pushing. PPP. Let the book offers roll in.",
  "id" : 460173002861076481,
  "created_at" : "2014-04-26 21:46:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea LaRowe",
      "screen_name" : "alarowe",
      "indices" : [ 0, 8 ],
      "id_str" : "270917610",
      "id" : 270917610
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 9, 19 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460139843268276224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8892614093, -87.6217397039 ]
  },
  "id_str" : "460159721068969986",
  "in_reply_to_user_id" : 270917610,
  "text" : "@alarowe @aquaranto it was great, thanks for tagging along!",
  "id" : 460159721068969986,
  "in_reply_to_status_id" : 460139843268276224,
  "created_at" : "2014-04-26 20:53:21 +0000",
  "in_reply_to_screen_name" : "alarowe",
  "in_reply_to_user_id_str" : "270917610",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/253BUDSsGV",
      "expanded_url" : "http:\/\/game.notch.net\/drowning\/#",
      "display_url" : "game.notch.net\/drowning\/#"
    } ]
  },
  "geo" : { },
  "id_str" : "460157498079457281",
  "text" : "Solve. http:\/\/t.co\/253BUDSsGV",
  "id" : 460157498079457281,
  "created_at" : "2014-04-26 20:44:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Q",
      "screen_name" : "itsJonQ",
      "indices" : [ 3, 11 ],
      "id_str" : "168203608",
      "id" : 168203608
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 62, 72 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "Shawnimals",
      "screen_name" : "shawnimals",
      "indices" : [ 73, 84 ],
      "id_str" : "17295737",
      "id" : 17295737
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/itsJonQ\/status\/460093087251828736\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/T0RkmsyjpJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmKUOaXCEAAOmcv.jpg",
      "id_str" : "460093087260217344",
      "id" : 460093087260217344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmKUOaXCEAAOmcv.jpg",
      "sizes" : [ {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/T0RkmsyjpJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460136345722032128",
  "text" : "RT @itsJonQ: Happy Sherpa bein' happy - even when it snows :) @37signals @shawnimals http:\/\/t.co\/T0RkmsyjpJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 49, 59 ],
        "id_str" : "11132462",
        "id" : 11132462
      }, {
        "name" : "Shawnimals",
        "screen_name" : "shawnimals",
        "indices" : [ 60, 71 ],
        "id_str" : "17295737",
        "id" : 17295737
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/itsJonQ\/status\/460093087251828736\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/T0RkmsyjpJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmKUOaXCEAAOmcv.jpg",
        "id_str" : "460093087260217344",
        "id" : 460093087260217344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmKUOaXCEAAOmcv.jpg",
        "sizes" : [ {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/T0RkmsyjpJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "460093087251828736",
    "text" : "Happy Sherpa bein' happy - even when it snows :) @37signals @shawnimals http:\/\/t.co\/T0RkmsyjpJ",
    "id" : 460093087251828736,
    "created_at" : "2014-04-26 16:28:34 +0000",
    "user" : {
      "name" : "Jon Q",
      "screen_name" : "itsJonQ",
      "protected" : false,
      "id_str" : "168203608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515198790379110400\/zEwjWTi1_normal.png",
      "id" : 168203608,
      "verified" : false
    }
  },
  "id" : 460136345722032128,
  "created_at" : "2014-04-26 19:20:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "C2E2",
      "screen_name" : "c2e2",
      "indices" : [ 47, 52 ],
      "id_str" : "29477388",
      "id" : 29477388
    }, {
      "name" : "Shawnimals",
      "screen_name" : "shawnimals",
      "indices" : [ 63, 74 ],
      "id_str" : "17295737",
      "id" : 17295737
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/37signals\/status\/460072905993248769\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/CGtBii7cL5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmKB3sNCUAAFrzn.jpg",
      "id_str" : "460072905703837696",
      "id" : 460072905703837696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmKB3sNCUAAFrzn.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1632,
        "resize" : "fit",
        "w" : 2448
      } ],
      "display_url" : "pic.twitter.com\/CGtBii7cL5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460136321088909312",
  "text" : "RT @37signals: And don\u2019t forget to pick up our @c2e2 exclusive @shawnimals + Basecamp Happy Sherpa too! http:\/\/t.co\/CGtBii7cL5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "C2E2",
        "screen_name" : "c2e2",
        "indices" : [ 32, 37 ],
        "id_str" : "29477388",
        "id" : 29477388
      }, {
        "name" : "Shawnimals",
        "screen_name" : "shawnimals",
        "indices" : [ 48, 59 ],
        "id_str" : "17295737",
        "id" : 17295737
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/37signals\/status\/460072905993248769\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/CGtBii7cL5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmKB3sNCUAAFrzn.jpg",
        "id_str" : "460072905703837696",
        "id" : 460072905703837696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmKB3sNCUAAFrzn.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1632,
          "resize" : "fit",
          "w" : 2448
        } ],
        "display_url" : "pic.twitter.com\/CGtBii7cL5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "460072905993248769",
    "text" : "And don\u2019t forget to pick up our @c2e2 exclusive @shawnimals + Basecamp Happy Sherpa too! http:\/\/t.co\/CGtBii7cL5",
    "id" : 460072905993248769,
    "created_at" : "2014-04-26 15:08:23 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 460136321088909312,
  "created_at" : "2014-04-26 19:20:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8748256751, -87.620445164 ]
  },
  "id_str" : "460129655593250816",
  "text" : "Who are cabbies always on the phone with?",
  "id" : 460129655593250816,
  "created_at" : "2014-04-26 18:53:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eunice Randall",
      "screen_name" : "RadioFreeEunice",
      "indices" : [ 3, 19 ],
      "id_str" : "1854856106",
      "id" : 1854856106
    }, {
      "name" : "BarCamp Buffalo",
      "screen_name" : "BarCampBuffalo",
      "indices" : [ 79, 94 ],
      "id_str" : "19735370",
      "id" : 19735370
    }, {
      "name" : "The Foundry",
      "screen_name" : "FoundryBuffalo",
      "indices" : [ 95, 110 ],
      "id_str" : "1442209033",
      "id" : 1442209033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RadioFreeEunice\/status\/460061774419861504\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/4Au30xAaP1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmJ3vruIEAAT-S6.jpg",
      "id_str" : "460061773018959872",
      "id" : 460061773018959872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmJ3vruIEAAT-S6.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4Au30xAaP1"
    } ],
    "hashtags" : [ {
      "text" : "barcampbuffalo",
      "indices" : [ 63, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460069359885357056",
  "text" : "RT @RadioFreeEunice: Woah look at all the awesome talks today! #barcampbuffalo @BarCampBuffalo @FoundryBuffalo http:\/\/t.co\/4Au30xAaP1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BarCamp Buffalo",
        "screen_name" : "BarCampBuffalo",
        "indices" : [ 58, 73 ],
        "id_str" : "19735370",
        "id" : 19735370
      }, {
        "name" : "The Foundry",
        "screen_name" : "FoundryBuffalo",
        "indices" : [ 74, 89 ],
        "id_str" : "1442209033",
        "id" : 1442209033
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RadioFreeEunice\/status\/460061774419861504\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/4Au30xAaP1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmJ3vruIEAAT-S6.jpg",
        "id_str" : "460061773018959872",
        "id" : 460061773018959872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmJ3vruIEAAT-S6.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/4Au30xAaP1"
      } ],
      "hashtags" : [ {
        "text" : "barcampbuffalo",
        "indices" : [ 42, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "460061774419861504",
    "text" : "Woah look at all the awesome talks today! #barcampbuffalo @BarCampBuffalo @FoundryBuffalo http:\/\/t.co\/4Au30xAaP1",
    "id" : 460061774419861504,
    "created_at" : "2014-04-26 14:24:09 +0000",
    "user" : {
      "name" : "Eunice Randall",
      "screen_name" : "RadioFreeEunice",
      "protected" : false,
      "id_str" : "1854856106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464436975617847296\/05bkMAtT_normal.jpeg",
      "id" : 1854856106,
      "verified" : false
    }
  },
  "id" : 460069359885357056,
  "created_at" : "2014-04-26 14:54:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460007322186973184",
  "geo" : { },
  "id_str" : "460026531918512129",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss Actually had plenty last night. Burned through the cards so quickly nothing good came up.",
  "id" : 460026531918512129,
  "in_reply_to_status_id" : 460007322186973184,
  "created_at" : "2014-04-26 12:04:06 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/1Bb2l3nZbA",
      "expanded_url" : "http:\/\/instagram.com\/p\/QSEoYQsqTJ\/",
      "display_url" : "instagram.com\/p\/QSEoYQsqTJ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8891192312, -87.6215573261 ]
  },
  "id_str" : "459917995121205248",
  "text" : "@juliepagano use sticker mule. They are awesome and the print has lasted almost 2 years in the sun here: http:\/\/t.co\/1Bb2l3nZbA",
  "id" : 459917995121205248,
  "created_at" : "2014-04-26 04:52:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TIPZ",
      "indices" : [ 6, 11 ]
    }, {
      "text" : "ARENA",
      "indices" : [ 28, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459912478193770497",
  "text" : "TOP 3 #TIPZ FOR HEARTHSTONE #ARENA:\n\n1) ASSEMBLE A DECK. LOSE.\n2) LOSE\n3) LOSE",
  "id" : 459912478193770497,
  "created_at" : "2014-04-26 04:30:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/jaEliDYL5Z",
      "expanded_url" : "http:\/\/api.rubyonrails.org\/classes\/ActiveModel\/Model.html",
      "display_url" : "api.rubyonrails.org\/classes\/Active\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459881679222345730",
  "text" : "ActiveModel::Model is something I've wanted for a while - mix into a class, and use form helpers. Huge win: http:\/\/t.co\/jaEliDYL5Z",
  "id" : 459881679222345730,
  "created_at" : "2014-04-26 02:28:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/mvzzq0jOiE",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=kQFKtI6gn9Y",
      "display_url" : "youtube.com\/watch?v=kQFKtI\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "459842539257094145",
  "geo" : { },
  "id_str" : "459843078270894080",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale https:\/\/t.co\/mvzzq0jOiE",
  "id" : 459843078270894080,
  "in_reply_to_status_id" : 459842539257094145,
  "created_at" : "2014-04-25 23:55:07 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 3, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459842429802123264",
  "text" : "My #railsconf takeaway: Everyone has opinions, none of them are right, no one knows what really matters, have fun anyway.",
  "id" : 459842429802123264,
  "created_at" : "2014-04-25 23:52:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459842269999542272",
  "text" : "Having kids is like playing a video game that is on 24\/7, you can't pause, is insanely difficult, but worth every second.",
  "id" : 459842269999542272,
  "created_at" : "2014-04-25 23:51:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Baugues",
      "screen_name" : "greggyb",
      "indices" : [ 1, 9 ],
      "id_str" : "15048829",
      "id" : 15048829
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 12, 23 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/greggyb\/status\/459803831165915136\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/4Jhl8Dd4Vl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmGNJcYCIAAEFeY.jpg",
      "id_str" : "459803830343835648",
      "id" : 459803830343835648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmGNJcYCIAAEFeY.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/4Jhl8Dd4Vl"
    } ],
    "hashtags" : [ {
      "text" : "railsconf2014",
      "indices" : [ 44, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8893617813, -87.6196540092 ]
  },
  "id_str" : "459804216169484288",
  "text" : "\u201C@greggyb: .@tenderlove about to close down #railsconf2014 http:\/\/t.co\/4Jhl8Dd4Vl\u201D another Buffalo Bills fan?!",
  "id" : 459804216169484288,
  "created_at" : "2014-04-25 21:20:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Haruska",
      "screen_name" : "haruska",
      "indices" : [ 0, 8 ],
      "id_str" : "9865602",
      "id" : 9865602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459798738303995905",
  "geo" : { },
  "id_str" : "459799178390941696",
  "in_reply_to_user_id" : 9865602,
  "text" : "@haruska already got back!",
  "id" : 459799178390941696,
  "in_reply_to_status_id" : 459798738303995905,
  "created_at" : "2014-04-25 21:00:41 +0000",
  "in_reply_to_screen_name" : "haruska",
  "in_reply_to_user_id_str" : "9865602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 70, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.855543856, -87.6223662957 ]
  },
  "id_str" : "459783224332279808",
  "text" : "C2E2 is huge. Any nerds that are in town tonight or this weekend from #railsconf need to stop by.",
  "id" : 459783224332279808,
  "created_at" : "2014-04-25 19:57:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459510425978023936",
  "geo" : { },
  "id_str" : "459510695231365120",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant Sounds useful for research.",
  "id" : 459510695231365120,
  "in_reply_to_status_id" : 459510425978023936,
  "created_at" : "2014-04-25 01:54:21 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 51, 63 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/ZFuaJKp7LN",
      "expanded_url" : "http:\/\/aqueousband.net\/shows\/2014-04-24",
      "display_url" : "aqueousband.net\/shows\/2014-04-\u2026"
    }, {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/76H12bN4J4",
      "expanded_url" : "http:\/\/static.gamespot.com\/uploads\/original\/391\/3912151\/2441702-0720251747-origi.gif",
      "display_url" : "static.gamespot.com\/uploads\/origin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459509892265426944",
  "text" : "Excited to see live setlist updates rolling in for @AqueousBand from fans on the floor: http:\/\/t.co\/ZFuaJKp7LN http:\/\/t.co\/76H12bN4J4",
  "id" : 459509892265426944,
  "created_at" : "2014-04-25 01:51:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/EmUiG90kOd",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/xyHNO8klGw",
      "expanded_url" : "http:\/\/guides.rubygems.org\/publishing\/#serving-your-own-gems",
      "display_url" : "guides.rubygems.org\/publishing\/#se\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459509227191414784",
  "text" : "If you have a private gem server, please help http:\/\/t.co\/EmUiG90kOd out and set allowed_push_host: http:\/\/t.co\/xyHNO8klGw",
  "id" : 459509227191414784,
  "created_at" : "2014-04-25 01:48:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459508267941908480",
  "geo" : { },
  "id_str" : "459508593092349952",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant Congrats!!!",
  "id" : 459508593092349952,
  "in_reply_to_status_id" : 459508267941908480,
  "created_at" : "2014-04-25 01:46:00 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Chevalier",
      "screen_name" : "JamesChevalier",
      "indices" : [ 0, 15 ],
      "id_str" : "19874511",
      "id" : 19874511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459506285831282689",
  "geo" : { },
  "id_str" : "459507836309880832",
  "in_reply_to_user_id" : 19874511,
  "text" : "@JamesChevalier Congrats!! and thanks!",
  "id" : 459507836309880832,
  "in_reply_to_status_id" : 459506285831282689,
  "created_at" : "2014-04-25 01:43:00 +0000",
  "in_reply_to_screen_name" : "JamesChevalier",
  "in_reply_to_user_id_str" : "19874511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/EmUiG90kOd",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "459504836690464768",
  "text" : "Finally dug to the bottom of the http:\/\/t.co\/EmUiG90kOd support queue. Feeling exhausted as usual after doing that. :\\",
  "id" : 459504836690464768,
  "created_at" : "2014-04-25 01:31:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Neukirchen",
      "screen_name" : "chneukirchen",
      "indices" : [ 0, 13 ],
      "id_str" : "1879351",
      "id" : 1879351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459495469836537856",
  "in_reply_to_user_id" : 1879351,
  "text" : "@chneukirchen Have a minute to check your email about some rubygems stuff? :)",
  "id" : 459495469836537856,
  "created_at" : "2014-04-25 00:53:51 +0000",
  "in_reply_to_screen_name" : "chneukirchen",
  "in_reply_to_user_id_str" : "1879351",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 93, 105 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AQband",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/51ZG2wVfKO",
      "expanded_url" : "http:\/\/aqueousband.net",
      "display_url" : "aqueousband.net"
    } ]
  },
  "geo" : { },
  "id_str" : "459493675584602112",
  "text" : "RT @UnclePhilsBlog: Keep an eye on the http:\/\/t.co\/51ZG2wVfKO page tonight folks, first ever @aqueousband live setlist updates on the new p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 73, 85 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AQband",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/51ZG2wVfKO",
        "expanded_url" : "http:\/\/aqueousband.net",
        "display_url" : "aqueousband.net"
      } ]
    },
    "geo" : { },
    "id_str" : "459482595525271552",
    "text" : "Keep an eye on the http:\/\/t.co\/51ZG2wVfKO page tonight folks, first ever @aqueousband live setlist updates on the new page! #AQband",
    "id" : 459482595525271552,
    "created_at" : "2014-04-25 00:02:42 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 459493675584602112,
  "created_at" : "2014-04-25 00:46:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459475613296775168",
  "text" : "Less than 10 minutes from *starting* a call to Jimmy John's to receiving the order. Why does no other chain do this right?",
  "id" : 459475613296775168,
  "created_at" : "2014-04-24 23:34:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Xie",
      "screen_name" : "mxie",
      "indices" : [ 0, 5 ],
      "id_str" : "15522014",
      "id" : 15522014
    }, {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 6, 13 ],
      "id_str" : "6505422",
      "id" : 6505422
    }, {
      "name" : "Caleb Thompson",
      "screen_name" : "thompson_caleb",
      "indices" : [ 14, 29 ],
      "id_str" : "2770102409",
      "id" : 2770102409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459421201811521537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8888598809, -87.619881145 ]
  },
  "id_str" : "459421396620177408",
  "in_reply_to_user_id" : 15522014,
  "text" : "@mxie @jyurek @thompson_caleb lobby! On my way soonly",
  "id" : 459421396620177408,
  "in_reply_to_status_id" : 459421201811521537,
  "created_at" : "2014-04-24 19:59:31 +0000",
  "in_reply_to_screen_name" : "mxie",
  "in_reply_to_user_id_str" : "15522014",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    }, {
      "name" : "Caleb Thompson",
      "screen_name" : "thompson_caleb",
      "indices" : [ 8, 23 ],
      "id_str" : "2770102409",
      "id" : 2770102409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459414498923671552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8879219419, -87.6199651059 ]
  },
  "id_str" : "459419562811727872",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek @thompson_caleb how about around now? (Brown cow)",
  "id" : 459419562811727872,
  "in_reply_to_status_id" : 459414498923671552,
  "created_at" : "2014-04-24 19:52:14 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Nagel",
      "screen_name" : "ericnagel",
      "indices" : [ 0, 10 ],
      "id_str" : "2522211",
      "id" : 2522211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459391083458613248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8897702014, -87.617714089 ]
  },
  "id_str" : "459398985921204224",
  "in_reply_to_user_id" : 2522211,
  "text" : "@ericnagel it\u2019s like UberX except with obnoxiously huge pink mustaches on cars",
  "id" : 459398985921204224,
  "in_reply_to_status_id" : 459391083458613248,
  "created_at" : "2014-04-24 18:30:28 +0000",
  "in_reply_to_screen_name" : "ericnagel",
  "in_reply_to_user_id_str" : "2522211",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    }, {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 14, 28 ],
      "id_str" : "145294977",
      "id" : 145294977
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 75, 89 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459371009330528256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.9068384044, -87.6213456754 ]
  },
  "id_str" : "459371769325821952",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV @communitybeer does this do home delivery, and can we slap a @coworkbuffalo sticker on? :)",
  "id" : 459371769325821952,
  "in_reply_to_status_id" : 459371009330528256,
  "created_at" : "2014-04-24 16:42:19 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8870136756, -87.6209059966 ]
  },
  "id_str" : "459337875150995457",
  "text" : "Congrats to this year\u2019s Ruby Heroes! Don\u2019t like the github contributions graphs up and center though. Not all OSS contributions are commits.",
  "id" : 459337875150995457,
  "created_at" : "2014-04-24 14:27:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh J. O'Donnell",
      "screen_name" : "hatchingphoenix",
      "indices" : [ 0, 16 ],
      "id_str" : "51985606",
      "id" : 51985606
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 17, 31 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459089244426731520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8898132505, -87.6263779008 ]
  },
  "id_str" : "459194279840079872",
  "in_reply_to_user_id" : 51985606,
  "text" : "@hatchingphoenix @coworkbuffalo   Thanks! Found it off DeviantArt too :) with permission of course.",
  "id" : 459194279840079872,
  "in_reply_to_status_id" : 459089244426731520,
  "created_at" : "2014-04-24 04:57:02 +0000",
  "in_reply_to_screen_name" : "hatchingphoenix",
  "in_reply_to_user_id_str" : "51985606",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459192358320357376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.889144915, -87.6292990889 ]
  },
  "id_str" : "459192710721581058",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense does it evolve into Gengar?",
  "id" : 459192710721581058,
  "in_reply_to_status_id" : 459192358320357376,
  "created_at" : "2014-04-24 04:50:48 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Pomeroy",
      "screen_name" : "xxv",
      "indices" : [ 0, 4 ],
      "id_str" : "7061802",
      "id" : 7061802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459191718815227904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8890724061, -87.6285989004 ]
  },
  "id_str" : "459192329375858688",
  "in_reply_to_user_id" : 7061802,
  "text" : "@xxv I have asked for twitter handles but this doesn\u2019t always work either.",
  "id" : 459192329375858688,
  "in_reply_to_status_id" : 459191718815227904,
  "created_at" : "2014-04-24 04:49:17 +0000",
  "in_reply_to_screen_name" : "xxv",
  "in_reply_to_user_id_str" : "7061802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459190974791434241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8893440897, -87.6204657295 ]
  },
  "id_str" : "459191531966980096",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms doesn\u2019t seem to work.",
  "id" : 459191531966980096,
  "in_reply_to_status_id" : 459190974791434241,
  "created_at" : "2014-04-24 04:46:07 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb Thompson",
      "screen_name" : "thompson_caleb",
      "indices" : [ 0, 15 ],
      "id_str" : "2770102409",
      "id" : 2770102409
    }, {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 16, 23 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459088130591969280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8899080716, -87.623887444 ]
  },
  "id_str" : "459191462173761538",
  "in_reply_to_user_id" : 290866979,
  "text" : "@thompson_caleb @jyurek sorry this fizzled. Saw you walking out too. Gah!",
  "id" : 459191462173761538,
  "in_reply_to_status_id" : 459088130591969280,
  "created_at" : "2014-04-24 04:45:50 +0000",
  "in_reply_to_screen_name" : "calebthompson",
  "in_reply_to_user_id_str" : "290866979",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8913153281, -87.6218135845 ]
  },
  "id_str" : "459190275118596096",
  "text" : "I am terrible with names. I feel guilty about this constantly.",
  "id" : 459190275118596096,
  "created_at" : "2014-04-24 04:41:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Suggs",
      "screen_name" : "ktheory",
      "indices" : [ 0, 8 ],
      "id_str" : "1696",
      "id" : 1696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459036647984603136",
  "geo" : { },
  "id_str" : "459039593761759232",
  "in_reply_to_user_id" : 1696,
  "text" : "@ktheory on dad duty for a bit, sorry!",
  "id" : 459039593761759232,
  "in_reply_to_status_id" : 459036647984603136,
  "created_at" : "2014-04-23 18:42:22 +0000",
  "in_reply_to_screen_name" : "ktheory",
  "in_reply_to_user_id_str" : "1696",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GO Bike Buffalo",
      "screen_name" : "GOBuffalo",
      "indices" : [ 3, 13 ],
      "id_str" : "23592729",
      "id" : 23592729
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GOBuffalo\/status\/459002023392706561\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/FXUw1zhPuW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl6z6IvCAAA5lwz.jpg",
      "id_str" : "459002023396900864",
      "id" : 459002023396900864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl6z6IvCAAA5lwz.jpg",
      "sizes" : [ {
        "h" : 627,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 313,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FXUw1zhPuW"
    } ],
    "hashtags" : [ {
      "text" : "skyride",
      "indices" : [ 19, 27 ]
    }, {
      "text" : "bicycleBFLO",
      "indices" : [ 70, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459017825202360320",
  "text" : "RT @GOBuffalo: The #skyride is on! And yes, we will be riding over it #bicycleBFLO http:\/\/t.co\/FXUw1zhPuW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GOBuffalo\/status\/459002023392706561\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/FXUw1zhPuW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl6z6IvCAAA5lwz.jpg",
        "id_str" : "459002023396900864",
        "id" : 459002023396900864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl6z6IvCAAA5lwz.jpg",
        "sizes" : [ {
          "h" : 627,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 313,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/FXUw1zhPuW"
      } ],
      "hashtags" : [ {
        "text" : "skyride",
        "indices" : [ 4, 12 ]
      }, {
        "text" : "bicycleBFLO",
        "indices" : [ 55, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "459002023392706561",
    "text" : "The #skyride is on! And yes, we will be riding over it #bicycleBFLO http:\/\/t.co\/FXUw1zhPuW",
    "id" : 459002023392706561,
    "created_at" : "2014-04-23 16:13:05 +0000",
    "user" : {
      "name" : "GO Bike Buffalo",
      "screen_name" : "GOBuffalo",
      "protected" : false,
      "id_str" : "23592729",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565282106238971904\/_Ssyiorc_normal.png",
      "id" : 23592729,
      "verified" : false
    }
  },
  "id" : 459017825202360320,
  "created_at" : "2014-04-23 17:15:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "Jason Haruska",
      "screen_name" : "haruska",
      "indices" : [ 8, 16 ],
      "id_str" : "9865602",
      "id" : 9865602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458997612071649281",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8889885724, -87.6196121428 ]
  },
  "id_str" : "459002885078933504",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats @haruska tweeted before the jobs videos started!",
  "id" : 459002885078933504,
  "in_reply_to_status_id" : 458997612071649281,
  "created_at" : "2014-04-23 16:16:30 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    }, {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 11, 20 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458978783995764736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8894627657, -87.6197522244 ]
  },
  "id_str" : "458979840633634816",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald @schneems there\u2019s also metal detectors with no gun signs on them",
  "id" : 458979840633634816,
  "in_reply_to_status_id" : 458978783995764736,
  "created_at" : "2014-04-23 14:44:56 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 8, 15 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8890273619, -87.6198176392 ]
  },
  "id_str" : "458979475430989824",
  "text" : "Viewing @wycats\u2019 argument on defaults from an ObjC\/iOS lens is frustrating: there\u2019s barely any  conventions.",
  "id" : 458979475430989824,
  "created_at" : "2014-04-23 14:43:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 3, 10 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458973297447686144",
  "text" : "RT @bryanl: It's 2014 and there are still testing debates in ruby land. \n\nNot testing is the path to the dark side. Test first or test last\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "458969641814343680",
    "text" : "It's 2014 and there are still testing debates in ruby land. \n\nNot testing is the path to the dark side. Test first or test last; just test.",
    "id" : 458969641814343680,
    "created_at" : "2014-04-23 14:04:24 +0000",
    "user" : {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "protected" : false,
      "id_str" : "659933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573327799135559680\/GiTRW1Hw_normal.jpeg",
      "id" : 659933,
      "verified" : false
    }
  },
  "id" : 458973297447686144,
  "created_at" : "2014-04-23 14:18:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Pretzlaw",
      "screen_name" : "FXRMP",
      "indices" : [ 0, 6 ],
      "id_str" : "489227283",
      "id" : 489227283
    }, {
      "name" : "Jo Liss",
      "screen_name" : "jo_liss",
      "indices" : [ 16, 24 ],
      "id_str" : "223422672",
      "id" : 223422672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458954720116502528",
  "geo" : { },
  "id_str" : "458963972742332416",
  "in_reply_to_user_id" : 489227283,
  "text" : "@FXRMP actually @jo_liss wrote that one :)",
  "id" : 458963972742332416,
  "in_reply_to_status_id" : 458954720116502528,
  "created_at" : "2014-04-23 13:41:52 +0000",
  "in_reply_to_screen_name" : "FXRMP",
  "in_reply_to_user_id_str" : "489227283",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR News",
      "screen_name" : "nprnews",
      "indices" : [ 4, 12 ],
      "id_str" : "5392522",
      "id" : 5392522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/NY8I6eP71U",
      "expanded_url" : "http:\/\/n.pr\/QCQMsX",
      "display_url" : "n.pr\/QCQMsX"
    } ]
  },
  "geo" : { },
  "id_str" : "458963825220276224",
  "text" : "Via @nprnews: 45 People Were Shot In Chicago Over The Weekend http:\/\/t.co\/NY8I6eP71U",
  "id" : 458963825220276224,
  "created_at" : "2014-04-23 13:41:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/p3TE9TbxQv",
      "expanded_url" : "https:\/\/github.com\/qrush\/skyway",
      "display_url" : "github.com\/qrush\/skyway"
    } ]
  },
  "geo" : { },
  "id_str" : "458950829941080064",
  "text" : "Code's here if you're interested. Happy to use some simple caching to make things fast :) https:\/\/t.co\/p3TE9TbxQv",
  "id" : 458950829941080064,
  "created_at" : "2014-04-23 12:49:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/YTY5bnC51i",
      "expanded_url" : "http:\/\/aqueousband.net\/",
      "display_url" : "aqueousband.net"
    } ]
  },
  "geo" : { },
  "id_str" : "458950259930968064",
  "text" : "Shipped a Rails 4 little side project in honor of #railsconf - a stats site for my favorite hometown band: http:\/\/t.co\/YTY5bnC51i",
  "id" : 458950259930968064,
  "created_at" : "2014-04-23 12:47:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458909306868346880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8891123744, -87.6207684464 ]
  },
  "id_str" : "458931845262888961",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal NetHack mostly works this way. Clearing the Castle of soldiers leaves piles and piles of useless loot",
  "id" : 458931845262888961,
  "in_reply_to_status_id" : 458909306868346880,
  "created_at" : "2014-04-23 11:34:13 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RailsConf 2015",
      "screen_name" : "railsconf",
      "indices" : [ 20, 30 ],
      "id_str" : "5493662",
      "id" : 5493662
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/458804334042423296\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/QfBj1223IC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl4AHFwCQAE1TSB.jpg",
      "id_str" : "458804333841104897",
      "id" : 458804333841104897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl4AHFwCQAE1TSB.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QfBj1223IC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8877834565, -87.6199943339 ]
  },
  "id_str" : "458804334042423296",
  "text" : "Castle Panic\u2019ing at @railsconf! http:\/\/t.co\/QfBj1223IC",
  "id" : 458804334042423296,
  "created_at" : "2014-04-23 03:07:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458785385360142336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8889519345, -87.6209953045 ]
  },
  "id_str" : "458786345373007875",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn be down in a few!",
  "id" : 458786345373007875,
  "in_reply_to_status_id" : 458785385360142336,
  "created_at" : "2014-04-23 01:56:03 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458784708990488576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8888629452, -87.6209240633 ]
  },
  "id_str" : "458785067494825984",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn lobby in 10?",
  "id" : 458785067494825984,
  "in_reply_to_status_id" : 458784708990488576,
  "created_at" : "2014-04-23 01:50:58 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8883567554, -87.6210029284 ]
  },
  "id_str" : "458783998483787776",
  "text" : "Anyone at the Sheraton up for some games of boards? Can\u2019t go far tonight.",
  "id" : 458783998483787776,
  "created_at" : "2014-04-23 01:46:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Prior",
      "screen_name" : "derekprior",
      "indices" : [ 0, 11 ],
      "id_str" : "1658511",
      "id" : 1658511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458772599297028096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8886883137, -87.6209037583 ]
  },
  "id_str" : "458774643848273920",
  "in_reply_to_user_id" : 1658511,
  "text" : "@derekprior Headquarters. Passed you guys on the way back from Gino\u2019s. Enjoy!",
  "id" : 458774643848273920,
  "in_reply_to_status_id" : 458772599297028096,
  "created_at" : "2014-04-23 01:09:33 +0000",
  "in_reply_to_screen_name" : "derekprior",
  "in_reply_to_user_id_str" : "1658511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458770295097020416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8957882689, -87.6230201572 ]
  },
  "id_str" : "458770446352019456",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano big star and velvet hour are amazing. Won\u2019t hit on this trip with the kiddo sadly.",
  "id" : 458770446352019456,
  "in_reply_to_status_id" : 458770295097020416,
  "created_at" : "2014-04-23 00:52:52 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458769612021067776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8957972544, -87.6230728565 ]
  },
  "id_str" : "458770178160209922",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano this was closest!",
  "id" : 458770178160209922,
  "in_reply_to_status_id" : 458769612021067776,
  "created_at" : "2014-04-23 00:51:48 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ochonicki",
      "screen_name" : "fromonesrc",
      "indices" : [ 0, 11 ],
      "id_str" : "14420513",
      "id" : 14420513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8957911669, -87.6231572465 ]
  },
  "id_str" : "458769561819430912",
  "in_reply_to_user_id" : 14420513,
  "text" : "@fromonesrc was it you I met outside? I am terrible with names and better with avatars\/handles.",
  "id" : 458769561819430912,
  "created_at" : "2014-04-23 00:49:21 +0000",
  "in_reply_to_screen_name" : "fromonesrc",
  "in_reply_to_user_id_str" : "14420513",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8957879693, -87.6230669335 ]
  },
  "id_str" : "458769180825628672",
  "text" : "First Gino\u2019s carry out. I think they need some paint.",
  "id" : 458769180825628672,
  "created_at" : "2014-04-23 00:47:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458750520702664705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8897999252, -87.6210656281 ]
  },
  "id_str" : "458762316138708993",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines you can opt into it now\u2026where are you this week anyway?",
  "id" : 458762316138708993,
  "in_reply_to_status_id" : 458750520702664705,
  "created_at" : "2014-04-23 00:20:34 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Einar J\u00F3nsson",
      "screen_name" : "einarj",
      "indices" : [ 0, 7 ],
      "id_str" : "20422920",
      "id" : 20422920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/Ac2b2qWAGf",
      "expanded_url" : "https:\/\/m.flickr.com\/#\/photos\/qrush\/9993368915\/in\/set-72157635999395313\/",
      "display_url" : "m.flickr.com\/#\/photos\/qrush\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "458754278078025728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8887186406, -87.6226356305 ]
  },
  "id_str" : "458755431272177664",
  "in_reply_to_user_id" : 20422920,
  "text" : "@einarj thanks! If you want it: https:\/\/t.co\/Ac2b2qWAGf",
  "id" : 458755431272177664,
  "in_reply_to_status_id" : 458754278078025728,
  "created_at" : "2014-04-22 23:53:12 +0000",
  "in_reply_to_screen_name" : "einarj",
  "in_reply_to_user_id_str" : "20422920",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DevChix",
      "screen_name" : "DevChix",
      "indices" : [ 14, 22 ],
      "id_str" : "14095631",
      "id" : 14095631
    }, {
      "name" : "Ministry of Velocity",
      "screen_name" : "minifast",
      "indices" : [ 27, 36 ],
      "id_str" : "1638346088",
      "id" : 1638346088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8888226787, -87.6208031474 ]
  },
  "id_str" : "458754038105137152",
  "text" : "Big thanks to @devchix and @minifast for hosting the 3 Q\u2019s, even if bedtime approached an hour earlier than normal. Time zones!!",
  "id" : 458754038105137152,
  "created_at" : "2014-04-22 23:47:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/8urCYi7cmt",
      "expanded_url" : "https:\/\/twitter.com\/qrush",
      "display_url" : "twitter.com\/qrush"
    } ]
  },
  "geo" : { },
  "id_str" : "458727726489165825",
  "text" : "Haters gonna hate. New twitter profiles look great: https:\/\/t.co\/8urCYi7cmt",
  "id" : 458727726489165825,
  "created_at" : "2014-04-22 22:03:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asher Vollmer",
      "screen_name" : "AsherVo",
      "indices" : [ 0, 8 ],
      "id_str" : "16741826",
      "id" : 16741826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458724134365982720",
  "geo" : { },
  "id_str" : "458724281862459392",
  "in_reply_to_user_id" : 16741826,
  "text" : "@AsherVo What game is this?",
  "id" : 458724281862459392,
  "in_reply_to_status_id" : 458724134365982720,
  "created_at" : "2014-04-22 21:49:26 +0000",
  "in_reply_to_screen_name" : "AsherVo",
  "in_reply_to_user_id_str" : "16741826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458703296413171712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.887719224, -87.6196638889 ]
  },
  "id_str" : "458714706568429568",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove tomorrow is basecamp party night! :(",
  "id" : 458714706568429568,
  "in_reply_to_status_id" : 458703296413171712,
  "created_at" : "2014-04-22 21:11:23 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RailsConf 2015",
      "screen_name" : "railsconf",
      "indices" : [ 8, 18 ],
      "id_str" : "5493662",
      "id" : 5493662
    }, {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 41, 48 ],
      "id_str" : "6505422",
      "id" : 6505422
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 49, 57 ],
      "id_str" : "14060922",
      "id" : 14060922
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 58, 69 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458689678812934144",
  "text" : "When is @railsconf board game night? \/cc @jyurek @mperham @tenderlove",
  "id" : 458689678812934144,
  "created_at" : "2014-04-22 19:31:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/bBph4vsyMw",
      "expanded_url" : "https:\/\/thedistance.com\/",
      "display_url" : "thedistance.com"
    } ]
  },
  "geo" : { },
  "id_str" : "458656266878214144",
  "text" : "THE DISTANCE is coming: https:\/\/t.co\/bBph4vsyMw",
  "id" : 458656266878214144,
  "created_at" : "2014-04-22 17:19:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Buffalo News",
      "screen_name" : "TheBuffaloNews",
      "indices" : [ 57, 72 ],
      "id_str" : "43805270",
      "id" : 43805270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/mTYwf9XoMo",
      "expanded_url" : "http:\/\/projects.buffalonews.com\/buffalo-boe\/index.html",
      "display_url" : "projects.buffalonews.com\/buffalo-boe\/in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "458643706766036994",
  "text" : "Stunned by the simple and useful information design from @TheBuffaloNews here (MORE PLEASE!): http:\/\/t.co\/mTYwf9XoMo",
  "id" : 458643706766036994,
  "created_at" : "2014-04-22 16:29:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458624908168155137",
  "text" : "RT @coworkbuffalo: We upped our internet speeds a bit at the space. Watching cautiously as 3 remote workers with VPNs kick the tires.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "458623232737046528",
    "text" : "We upped our internet speeds a bit at the space. Watching cautiously as 3 remote workers with VPNs kick the tires.",
    "id" : 458623232737046528,
    "created_at" : "2014-04-22 15:07:54 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 458624908168155137,
  "created_at" : "2014-04-22 15:14:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 22, 26 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/jVRhgrxJyt",
      "expanded_url" : "http:\/\/www.justin.tv\/confreaks",
      "display_url" : "justin.tv\/confreaks"
    } ]
  },
  "geo" : { },
  "id_str" : "458608758227079170",
  "text" : "RT @jasonfried: Watch @dhh's RailsConf opening keynote at 9:15am central this morning at http:\/\/t.co\/jVRhgrxJyt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DHH",
        "screen_name" : "dhh",
        "indices" : [ 6, 10 ],
        "id_str" : "14561327",
        "id" : 14561327
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/jVRhgrxJyt",
        "expanded_url" : "http:\/\/www.justin.tv\/confreaks",
        "display_url" : "justin.tv\/confreaks"
      } ]
    },
    "geo" : { },
    "id_str" : "458598928045199360",
    "text" : "Watch @dhh's RailsConf opening keynote at 9:15am central this morning at http:\/\/t.co\/jVRhgrxJyt",
    "id" : 458598928045199360,
    "created_at" : "2014-04-22 13:31:19 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 458608758227079170,
  "created_at" : "2014-04-22 14:10:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458598774458556416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8877646459, -87.6196372153 ]
  },
  "id_str" : "458607141197070336",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove did you try any Mal\u00F6rt yet?",
  "id" : 458607141197070336,
  "in_reply_to_status_id" : 458598774458556416,
  "created_at" : "2014-04-22 14:03:57 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458467094523154432",
  "text" : "Correction: BARELY any tests.",
  "id" : 458467094523154432,
  "created_at" : "2014-04-22 04:47:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458466923538178048",
  "text" : "Spent all night messing around with a new Rails 4 app and writing no tests. \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 458466923538178048,
  "created_at" : "2014-04-22 04:46:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458436273242640384",
  "geo" : { },
  "id_str" : "458436726868811777",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps XVim with lots of patience",
  "id" : 458436726868811777,
  "in_reply_to_status_id" : 458436273242640384,
  "created_at" : "2014-04-22 02:46:47 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sommers",
      "screen_name" : "kellabyte",
      "indices" : [ 0, 10 ],
      "id_str" : "47494539",
      "id" : 47494539
    }, {
      "name" : "Scott Koon",
      "screen_name" : "lazycoder",
      "indices" : [ 11, 21 ],
      "id_str" : "697163",
      "id" : 697163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458429632174624768",
  "geo" : { },
  "id_str" : "458429947866906624",
  "in_reply_to_user_id" : 47494539,
  "text" : "@kellabyte @lazycoder Disagree - sometimes the social, mental hurdles are way higher for large projects. They don't always correlate.",
  "id" : 458429947866906624,
  "in_reply_to_status_id" : 458429632174624768,
  "created_at" : "2014-04-22 02:19:51 +0000",
  "in_reply_to_screen_name" : "kellabyte",
  "in_reply_to_user_id_str" : "47494539",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Koon",
      "screen_name" : "lazycoder",
      "indices" : [ 0, 10 ],
      "id_str" : "697163",
      "id" : 697163
    }, {
      "name" : "Kelly Sommers",
      "screen_name" : "kellabyte",
      "indices" : [ 11, 21 ],
      "id_str" : "47494539",
      "id" : 47494539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458429380264341505",
  "geo" : { },
  "id_str" : "458429529434775552",
  "in_reply_to_user_id" : 697163,
  "text" : "@lazycoder @kellabyte This...requires immense amounts of effort too. Not sure of many who do this.",
  "id" : 458429529434775552,
  "in_reply_to_status_id" : 458429380264341505,
  "created_at" : "2014-04-22 02:18:11 +0000",
  "in_reply_to_screen_name" : "lazycoder",
  "in_reply_to_user_id_str" : "697163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ara T. Howard",
      "screen_name" : "drawohara",
      "indices" : [ 0, 10 ],
      "id_str" : "17058191",
      "id" : 17058191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458428612882886656",
  "geo" : { },
  "id_str" : "458429419992801280",
  "in_reply_to_user_id" : 17058191,
  "text" : "@drawohara Yes! Look for 5 month old. Will be super happy to meet you finally.",
  "id" : 458429419992801280,
  "in_reply_to_status_id" : 458428612882886656,
  "created_at" : "2014-04-22 02:17:45 +0000",
  "in_reply_to_screen_name" : "drawohara",
  "in_reply_to_user_id_str" : "17058191",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    }, {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 7, 17 ],
      "id_str" : "14620798",
      "id" : 14620798
    }, {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 72, 81 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458422918406356992",
  "geo" : { },
  "id_str" : "458423135604199424",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis @zachwaugh my second: V for Vendetta. Then, Sweet Tooth. I blame @shildner for that last one.",
  "id" : 458423135604199424,
  "in_reply_to_status_id" : 458422918406356992,
  "created_at" : "2014-04-22 01:52:47 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 0, 10 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458417784423469056",
  "geo" : { },
  "id_str" : "458422076664053760",
  "in_reply_to_user_id" : 14620798,
  "text" : "@zachwaugh Start with Watchmen.",
  "id" : 458422076664053760,
  "in_reply_to_status_id" : 458417784423469056,
  "created_at" : "2014-04-22 01:48:34 +0000",
  "in_reply_to_screen_name" : "zachwaugh",
  "in_reply_to_user_id_str" : "14620798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/GeRe5q8PrB",
      "expanded_url" : "http:\/\/api.rubyonrails.org\/classes\/ActionView\/Helpers\/FormHelper.html#method-i-date_field",
      "display_url" : "api.rubyonrails.org\/classes\/Action\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "458417202488963073",
  "text" : "Didn't know &lt;input type='date'&gt; was a thing on desktop browsers like Chrome. Awesome: http:\/\/t.co\/GeRe5q8PrB",
  "id" : 458417202488963073,
  "created_at" : "2014-04-22 01:29:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 0, 8 ],
      "id_str" : "77673",
      "id" : 77673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458414345064415232",
  "geo" : { },
  "id_str" : "458415366494887936",
  "in_reply_to_user_id" : 77673,
  "text" : "@jwright hey! we stopped way too many times with the little dude. Ohio's rest stops are 1000% better than Indiana's.",
  "id" : 458415366494887936,
  "in_reply_to_status_id" : 458414345064415232,
  "created_at" : "2014-04-22 01:21:54 +0000",
  "in_reply_to_screen_name" : "jwright",
  "in_reply_to_user_id_str" : "77673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sommers",
      "screen_name" : "kellabyte",
      "indices" : [ 3, 13 ],
      "id_str" : "47494539",
      "id" : 47494539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458413403791687680",
  "text" : "RT @kellabyte: IMO we value too much OSS devs as heroes who create repo after repo. True OSS heroes are the ones who cooperate as large pro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "457025793454243840",
    "text" : "IMO we value too much OSS devs as heroes who create repo after repo. True OSS heroes are the ones who cooperate as large productive groups.",
    "id" : 457025793454243840,
    "created_at" : "2014-04-18 05:20:14 +0000",
    "user" : {
      "name" : "Kelly Sommers",
      "screen_name" : "kellabyte",
      "protected" : false,
      "id_str" : "47494539",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2808005971\/b81b99287e78b1cd6cbd0e5cbfb3295c_normal.png",
      "id" : 47494539,
      "verified" : false
    }
  },
  "id" : 458413403791687680,
  "created_at" : "2014-04-22 01:14:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JorDan\u00E9e Key",
      "screen_name" : "JorDaneeKey",
      "indices" : [ 0, 12 ],
      "id_str" : "258063176",
      "id" : 258063176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458390703882899456",
  "geo" : { },
  "id_str" : "458411120424796160",
  "in_reply_to_user_id" : 258063176,
  "text" : "@JorDaneeKey Seriously! We need to get some people on that.",
  "id" : 458411120424796160,
  "in_reply_to_status_id" : 458390703882899456,
  "created_at" : "2014-04-22 01:05:02 +0000",
  "in_reply_to_screen_name" : "JorDaneeKey",
  "in_reply_to_user_id_str" : "258063176",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan McGeary",
      "screen_name" : "rmm5t",
      "indices" : [ 0, 6 ],
      "id_str" : "11645552",
      "id" : 11645552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/EG8xy9eqvk",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=sBsi5FGbY2Y",
      "display_url" : "m.youtube.com\/watch?v=sBsi5F\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "458404296581996545",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8875619049, -87.6271977091 ]
  },
  "id_str" : "458405597595983872",
  "in_reply_to_user_id" : 11645552,
  "text" : "@rmm5t I\u2019ll just leave this here http:\/\/t.co\/EG8xy9eqvk",
  "id" : 458405597595983872,
  "in_reply_to_status_id" : 458404296581996545,
  "created_at" : "2014-04-22 00:43:05 +0000",
  "in_reply_to_screen_name" : "rmm5t",
  "in_reply_to_user_id_str" : "11645552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8880844849, -87.6195764946 ]
  },
  "id_str" : "458390298977005568",
  "text" : "At the Sheraton bar for probably just a few more minutes. Come say hi!",
  "id" : 458390298977005568,
  "created_at" : "2014-04-21 23:42:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Goebel",
      "screen_name" : "dreamer3",
      "indices" : [ 35, 44 ],
      "id_str" : "14973933",
      "id" : 14973933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8876451929, -87.6266108939 ]
  },
  "id_str" : "458379420269416448",
  "text" : "Took 3 seconds in the lobby before @dreamer3 found us. ZOMG hi Railsconf!",
  "id" : 458379420269416448,
  "created_at" : "2014-04-21 22:59:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Nagel",
      "screen_name" : "ericnagel",
      "indices" : [ 0, 10 ],
      "id_str" : "2522211",
      "id" : 2522211
    }, {
      "name" : "Chris Campbell",
      "screen_name" : "chrisrcampbell",
      "indices" : [ 11, 26 ],
      "id_str" : "18078614",
      "id" : 18078614
    }, {
      "name" : "SWBuffalo",
      "screen_name" : "SWBuffalo",
      "indices" : [ 27, 37 ],
      "id_str" : "611972038",
      "id" : 611972038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458341270818414592",
  "geo" : { },
  "id_str" : "458361233117171712",
  "in_reply_to_user_id" : 2522211,
  "text" : "@ericnagel @chrisrcampbell @SWBuffalo look for the baby.",
  "id" : 458361233117171712,
  "in_reply_to_status_id" : 458341270818414592,
  "created_at" : "2014-04-21 21:46:48 +0000",
  "in_reply_to_screen_name" : "ericnagel",
  "in_reply_to_user_id_str" : "2522211",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458360163880034304",
  "text" : "Hello Chicago!",
  "id" : 458360163880034304,
  "created_at" : "2014-04-21 21:42:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.5884146518, -87.2172233016 ]
  },
  "id_str" : "458337410670030848",
  "text" : "Have to admit, best part of this road trip was crossing the CST line and watching my phone automatically update. FUTURE! \uD83D\uDE80",
  "id" : 458337410670030848,
  "created_at" : "2014-04-21 20:12:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1496112956, -80.6989765734 ]
  },
  "id_str" : "458238561163026432",
  "text" : "Roadtripping to Railsconf! This feels strange yet familiar.",
  "id" : 458238561163026432,
  "created_at" : "2014-04-21 13:39:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PROTOPLOT",
      "screen_name" : "protoplot",
      "indices" : [ 3, 13 ],
      "id_str" : "425223212",
      "id" : 425223212
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/protoplot\/status\/357489358762278914\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/VFNZArRU69",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPYOrYCCAAEXbGp.jpg",
      "id_str" : "357489358770667521",
      "id" : 357489358770667521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPYOrYCCAAEXbGp.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/VFNZArRU69"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458200301460148225",
  "text" : "RT @protoplot: Niagara Falls geology cross-section - http:\/\/t.co\/VFNZArRU69",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/protoplot\/status\/357489358762278914\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/VFNZArRU69",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BPYOrYCCAAEXbGp.jpg",
        "id_str" : "357489358770667521",
        "id" : 357489358770667521,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPYOrYCCAAEXbGp.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/VFNZArRU69"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357489358762278914",
    "text" : "Niagara Falls geology cross-section - http:\/\/t.co\/VFNZArRU69",
    "id" : 357489358762278914,
    "created_at" : "2013-07-17 13:17:59 +0000",
    "user" : {
      "name" : "PROTOPLOT",
      "screen_name" : "protoplot",
      "protected" : false,
      "id_str" : "425223212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3755382163\/22fc8303603f2e390800a9345646ad9d_normal.jpeg",
      "id" : 425223212,
      "verified" : false
    }
  },
  "id" : 458200301460148225,
  "created_at" : "2014-04-21 11:07:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asher Vollmer",
      "screen_name" : "AsherVo",
      "indices" : [ 53, 61 ],
      "id_str" : "16741826",
      "id" : 16741826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.192060934, -80.5592201408 ]
  },
  "id_str" : "457975306804928512",
  "text" : "Why can\u2019t I pay 99\u00A2 for undo in Threes and why isn\u2019t @AsherVo a millionaire for this yet?",
  "id" : 457975306804928512,
  "created_at" : "2014-04-20 20:13:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest W. Durbin III",
      "screen_name" : "EWDurbin",
      "indices" : [ 3, 12 ],
      "id_str" : "14590010",
      "id" : 14590010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/tzGMYWDXPh",
      "expanded_url" : "http:\/\/i.imgur.com\/XUNs4Ke.gif",
      "display_url" : "i.imgur.com\/XUNs4Ke.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "457894508714135553",
  "text" : "RT @EWDurbin: your average production software system http:\/\/t.co\/tzGMYWDXPh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/tzGMYWDXPh",
        "expanded_url" : "http:\/\/i.imgur.com\/XUNs4Ke.gif",
        "display_url" : "i.imgur.com\/XUNs4Ke.gif"
      } ]
    },
    "geo" : { },
    "id_str" : "457886739088957440",
    "text" : "your average production software system http:\/\/t.co\/tzGMYWDXPh",
    "id" : 457886739088957440,
    "created_at" : "2014-04-20 14:21:20 +0000",
    "user" : {
      "name" : "Ernest W. Durbin III",
      "screen_name" : "EWDurbin",
      "protected" : false,
      "id_str" : "14590010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572903830775472128\/a_6Z37mZ_normal.jpeg",
      "id" : 14590010,
      "verified" : false
    }
  },
  "id" : 457894508714135553,
  "created_at" : "2014-04-20 14:52:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1927743869, -80.5592114116 ]
  },
  "id_str" : "457708266252804096",
  "text" : "Just received my first Bitcoin tip for a one sentence removal patch to docrails. Does this mean I\u2019m rich now?",
  "id" : 457708266252804096,
  "created_at" : "2014-04-20 02:32:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Ada Initiative",
      "screen_name" : "adainitiative",
      "indices" : [ 3, 17 ],
      "id_str" : "242645565",
      "id" : 242645565
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 22, 36 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/C4vK7I9jg4",
      "expanded_url" : "http:\/\/geekfeminism.wikia.com\/wiki\/Conference_anti-harassment\/Adoption#Coworking_Spaces",
      "display_url" : "geekfeminism.wikia.com\/wiki\/Conferenc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "457694194086064128",
  "text" : "RT @adainitiative: Is @coworkbuffalo the only co-working space with an anti-harassment policy? Add your co-working space to this list http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 3, 17 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/C4vK7I9jg4",
        "expanded_url" : "http:\/\/geekfeminism.wikia.com\/wiki\/Conference_anti-harassment\/Adoption#Coworking_Spaces",
        "display_url" : "geekfeminism.wikia.com\/wiki\/Conferenc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "457390693959626752",
    "text" : "Is @coworkbuffalo the only co-working space with an anti-harassment policy? Add your co-working space to this list http:\/\/t.co\/C4vK7I9jg4",
    "id" : 457390693959626752,
    "created_at" : "2014-04-19 05:30:14 +0000",
    "user" : {
      "name" : "The Ada Initiative",
      "screen_name" : "adainitiative",
      "protected" : false,
      "id_str" : "242645565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1237659527\/avatar-adainitiative2_normal.png",
      "id" : 242645565,
      "verified" : true
    }
  },
  "id" : 457694194086064128,
  "created_at" : "2014-04-20 01:36:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/457688219681693696\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/mLBMD9qRS9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BloJAqxCIAAiwO2.jpg",
      "id_str" : "457688219216125952",
      "id" : 457688219216125952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BloJAqxCIAAiwO2.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/mLBMD9qRS9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.192819844, -80.5589017086 ]
  },
  "id_str" : "457688219681693696",
  "text" : "What happens when I get to play with fire when dyeing eggs. http:\/\/t.co\/mLBMD9qRS9",
  "id" : 457688219681693696,
  "created_at" : "2014-04-20 01:12:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mlmmlmmlm",
      "screen_name" : "mlmmlmmlm",
      "indices" : [ 3, 13 ],
      "id_str" : "2649875233",
      "id" : 2649875233
    }, {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 20, 26 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/yerpalmildsauce\/status\/457413562835537920\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/X1xJ3QSG1s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlkPNfPCYAAveJl.jpg",
      "id_str" : "457413561552101376",
      "id" : 457413561552101376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlkPNfPCYAAveJl.jpg",
      "sizes" : [ {
        "h" : 459,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/X1xJ3QSG1s"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457674623887605760",
  "text" : "RT @mlmmlmmlm: Attn @vrunt: as promised http:\/\/t.co\/X1xJ3QSG1s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nate \u2615\uFE0F",
        "screen_name" : "vrunt",
        "indices" : [ 5, 11 ],
        "id_str" : "15062828",
        "id" : 15062828
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/yerpalmildsauce\/status\/457413562835537920\/photo\/1",
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/X1xJ3QSG1s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BlkPNfPCYAAveJl.jpg",
        "id_str" : "457413561552101376",
        "id" : 457413561552101376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlkPNfPCYAAveJl.jpg",
        "sizes" : [ {
          "h" : 459,
          "resize" : "fit",
          "w" : 816
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 816
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/X1xJ3QSG1s"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "457413562835537920",
    "text" : "Attn @vrunt: as promised http:\/\/t.co\/X1xJ3QSG1s",
    "id" : 457413562835537920,
    "created_at" : "2014-04-19 07:01:06 +0000",
    "user" : {
      "name" : "The Intelligencer",
      "screen_name" : "yerpalmildsauce",
      "protected" : false,
      "id_str" : "758848272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573407481436774400\/5bfFMKgB_normal.jpeg",
      "id" : 758848272,
      "verified" : false
    }
  },
  "id" : 457674623887605760,
  "created_at" : "2014-04-20 00:18:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/457655220823019520\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/xjipIdp2Ca",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Blnq_5LCQAAT1B1.jpg",
      "id_str" : "457655220554579968",
      "id" : 457655220554579968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Blnq_5LCQAAT1B1.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xjipIdp2Ca"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1886100751, -80.5607043207 ]
  },
  "id_str" : "457655220823019520",
  "text" : "Fracking sites are creepy. http:\/\/t.co\/xjipIdp2Ca",
  "id" : 457655220823019520,
  "created_at" : "2014-04-19 23:01:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/7ZXT9EPnW1",
      "expanded_url" : "https:\/\/github.com\/rails\/rails\/pull\/14811",
      "display_url" : "github.com\/rails\/rails\/pu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "457613756642521088",
  "text" : "Saw a line in the Rails guides that bugged me. Any +1's? https:\/\/t.co\/7ZXT9EPnW1",
  "id" : 457613756642521088,
  "created_at" : "2014-04-19 20:16:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457253617448550400",
  "geo" : { },
  "id_str" : "457261108726726656",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn Monday!",
  "id" : 457261108726726656,
  "in_reply_to_status_id" : 457253617448550400,
  "created_at" : "2014-04-18 20:55:18 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242529724, -78.8792185134 ]
  },
  "id_str" : "457236965646020608",
  "text" : "Bringing an entire suitcase of games for #railsconf. Be ready.",
  "id" : 457236965646020608,
  "created_at" : "2014-04-18 19:19:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 3, 18 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 56, 70 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buffalo",
      "indices" : [ 83, 91 ]
    }, {
      "text" : "mainstreet",
      "indices" : [ 92, 103 ]
    }, {
      "text" : "coffee",
      "indices" : [ 104, 111 ]
    }, {
      "text" : "espresso",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/PrkENlc6dZ",
      "expanded_url" : "http:\/\/instagram.com\/p\/m76Zi5sOWK\/",
      "display_url" : "instagram.com\/p\/m76Zi5sOWK\/"
    } ]
  },
  "geo" : { },
  "id_str" : "457178300146655233",
  "text" : "RT @PublicEspresso: Delivering four pounds of coffee to @coworkbuffalo with Archer #buffalo #mainstreet #coffee #espresso\u2026 http:\/\/t.co\/PrkE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 36, 50 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "buffalo",
        "indices" : [ 63, 71 ]
      }, {
        "text" : "mainstreet",
        "indices" : [ 72, 83 ]
      }, {
        "text" : "coffee",
        "indices" : [ 84, 91 ]
      }, {
        "text" : "espresso",
        "indices" : [ 92, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/PrkENlc6dZ",
        "expanded_url" : "http:\/\/instagram.com\/p\/m76Zi5sOWK\/",
        "display_url" : "instagram.com\/p\/m76Zi5sOWK\/"
      } ]
    },
    "geo" : { },
    "id_str" : "457178114272276480",
    "text" : "Delivering four pounds of coffee to @coworkbuffalo with Archer #buffalo #mainstreet #coffee #espresso\u2026 http:\/\/t.co\/PrkENlc6dZ",
    "id" : 457178114272276480,
    "created_at" : "2014-04-18 15:25:31 +0000",
    "user" : {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "protected" : false,
      "id_str" : "1472209542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550509321445191680\/PwiO5VPn_normal.jpeg",
      "id" : 1472209542,
      "verified" : false
    }
  },
  "id" : 457178300146655233,
  "created_at" : "2014-04-18 15:26:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Nagelhout",
      "screen_name" : "goosesroost",
      "indices" : [ 0, 12 ],
      "id_str" : "21283898",
      "id" : 21283898
    }, {
      "name" : "The Defenseman",
      "screen_name" : "TheDefenseman",
      "indices" : [ 13, 27 ],
      "id_str" : "543918403",
      "id" : 543918403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457164216508903424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242221139, -78.879095471 ]
  },
  "id_str" : "457173576232083457",
  "in_reply_to_user_id" : 21283898,
  "text" : "@goosesroost @TheDefenseman why do you subject yourselves to this drivel?",
  "id" : 457173576232083457,
  "in_reply_to_status_id" : 457164216508903424,
  "created_at" : "2014-04-18 15:07:29 +0000",
  "in_reply_to_screen_name" : "goosesroost",
  "in_reply_to_user_id_str" : "21283898",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457016824035426304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242155668, -78.8792560205 ]
  },
  "id_str" : "457017089631350785",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant WAKE UP SHEEPLE!",
  "id" : 457017089631350785,
  "in_reply_to_status_id" : 457016824035426304,
  "created_at" : "2014-04-18 04:45:39 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yannick \u2603 Schutz",
      "screen_name" : "yann_ck",
      "indices" : [ 0, 8 ],
      "id_str" : "14835545",
      "id" : 14835545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456807467918180352",
  "geo" : { },
  "id_str" : "456809581394812928",
  "in_reply_to_user_id" : 14835545,
  "text" : "@yann_ck sweet! Not sure of any dinner time plans yet with the little one, especially being an hour off his time zone.",
  "id" : 456809581394812928,
  "in_reply_to_status_id" : 456807467918180352,
  "created_at" : "2014-04-17 15:01:05 +0000",
  "in_reply_to_screen_name" : "yann_ck",
  "in_reply_to_user_id_str" : "14835545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 51, 61 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456800306308083713",
  "text" : "ZOMG it's almost #railsconf week. Look out for me, @aquaranto, and a booth baby.",
  "id" : 456800306308083713,
  "created_at" : "2014-04-17 14:24:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Levi Neuland",
      "screen_name" : "levineuland",
      "indices" : [ 0, 12 ],
      "id_str" : "15387091",
      "id" : 15387091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/XAiz2rGsGi",
      "expanded_url" : "http:\/\/www.ashedryden.com\/blog\/codes-of-conduct-101-faq",
      "display_url" : "ashedryden.com\/blog\/codes-of-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "456528766227869697",
  "geo" : { },
  "id_str" : "456560743580565504",
  "in_reply_to_user_id" : 15387091,
  "text" : "@levineuland Lots of great info here: http:\/\/t.co\/XAiz2rGsGi",
  "id" : 456560743580565504,
  "in_reply_to_status_id" : 456528766227869697,
  "created_at" : "2014-04-16 22:32:18 +0000",
  "in_reply_to_screen_name" : "levineuland",
  "in_reply_to_user_id_str" : "15387091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 0, 9 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/BOnjXrvyBV",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=gGk9_mANdSM&index=6&list=PLB2EF2428860FF833",
      "display_url" : "youtube.com\/watch?v=gGk9_m\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "456524427014832128",
  "geo" : { },
  "id_str" : "456525451708469248",
  "in_reply_to_user_id" : 15946976,
  "text" : "@tinybaby \"the cop starts breakdancing\" https:\/\/t.co\/BOnjXrvyBV",
  "id" : 456525451708469248,
  "in_reply_to_status_id" : 456524427014832128,
  "created_at" : "2014-04-16 20:12:04 +0000",
  "in_reply_to_screen_name" : "tinybaby",
  "in_reply_to_user_id_str" : "15946976",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/tAHwQSSDZt",
      "expanded_url" : "https:\/\/soundcloud.com\/unclephilsblog\/sets\/aqueous-mixer",
      "display_url" : "soundcloud.com\/unclephilsblog\u2026"
    }, {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/Vl0dEPmfjB",
      "expanded_url" : "http:\/\/kck.st\/1ix9pb8",
      "display_url" : "kck.st\/1ix9pb8"
    } ]
  },
  "geo" : { },
  "id_str" : "456512495725707266",
  "text" : "Your tasks for today: Queue up https:\/\/t.co\/tAHwQSSDZt, kick back, then donate for more: http:\/\/t.co\/Vl0dEPmfjB",
  "id" : 456512495725707266,
  "created_at" : "2014-04-16 19:20:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Alex Sharp",
      "screen_name" : "ajsharp",
      "indices" : [ 84, 92 ],
      "id_str" : "18071073",
      "id" : 18071073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/B7iNjX25m7",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/issues\/424",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "456482595769835520",
  "geo" : { },
  "id_str" : "456482958556139520",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr please read https:\/\/t.co\/B7iNjX25m7 and let's move this discussion there \/cc @ajsharp",
  "id" : 456482958556139520,
  "in_reply_to_status_id" : 456482595769835520,
  "created_at" : "2014-04-16 17:23:13 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456482162926424064",
  "geo" : { },
  "id_str" : "456482357197799424",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr S3 space is barely a cost concern compared to bandwidth\/hosting in general.",
  "id" : 456482357197799424,
  "in_reply_to_status_id" : 456482162926424064,
  "created_at" : "2014-04-16 17:20:49 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456481908046983168",
  "geo" : { },
  "id_str" : "456482146324979712",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr primary motivation is to stop private gems from being pushed. Claim would only be for the initial push of a gem.",
  "id" : 456482146324979712,
  "in_reply_to_status_id" : 456481908046983168,
  "created_at" : "2014-04-16 17:19:59 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/JyyTjWumoX",
      "expanded_url" : "http:\/\/help.rubygems.org\/users\/173779",
      "display_url" : "help.rubygems.org\/users\/173779"
    } ]
  },
  "geo" : { },
  "id_str" : "456472379674206208",
  "text" : "Recently passed 2,000 replies. Support is the rarest talked about part of OSS, yet hardest. (queue is still 70+ deep) http:\/\/t.co\/JyyTjWumoX",
  "id" : 456472379674206208,
  "created_at" : "2014-04-16 16:41:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456468428136923136",
  "geo" : { },
  "id_str" : "456469822390288384",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr people already \"claim\" swaths of gems by just pushing blank or mostly empty gems.",
  "id" : 456469822390288384,
  "in_reply_to_status_id" : 456468428136923136,
  "created_at" : "2014-04-16 16:31:01 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Alex Sharp",
      "screen_name" : "ajsharp",
      "indices" : [ 9, 17 ],
      "id_str" : "18071073",
      "id" : 18071073
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 18, 26 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/B7iNjX25m7",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/issues\/424",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "456467424473137152",
  "geo" : { },
  "id_str" : "456467869660770304",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @ajsharp @drbrain https:\/\/t.co\/B7iNjX25m7",
  "id" : 456467869660770304,
  "in_reply_to_status_id" : 456467424473137152,
  "created_at" : "2014-04-16 16:23:15 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 9, 17 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456465766259253248",
  "geo" : { },
  "id_str" : "456466315444621312",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @drbrain Definitely. We need some clones. Or more people interested.",
  "id" : 456466315444621312,
  "in_reply_to_status_id" : 456465766259253248,
  "created_at" : "2014-04-16 16:17:04 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 123, 131 ],
      "id_str" : "670283",
      "id" : 670283
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 132, 140 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/jCQq69vvN6",
      "expanded_url" : "http:\/\/guides.rubygems.org\/publishing\/#serving_your_own_gems",
      "display_url" : "guides.rubygems.org\/publishing\/#se\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "456465664858128384",
  "text" : "What if all gemspecs required a allowed_push_host? Would that cut the # of private gems pushed? http:\/\/t.co\/jCQq69vvN6 \/cc @drbrain @evanphx",
  "id" : 456465664858128384,
  "created_at" : "2014-04-16 16:14:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Handsome",
      "screen_name" : "Millennial_Dave",
      "indices" : [ 0, 16 ],
      "id_str" : "60185021",
      "id" : 60185021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456458232437805056",
  "geo" : { },
  "id_str" : "456460579197030401",
  "in_reply_to_user_id" : 60185021,
  "text" : "@Millennial_Dave this is on purpose, an old fb\/instagram feud. :(",
  "id" : 456460579197030401,
  "in_reply_to_status_id" : 456458232437805056,
  "created_at" : "2014-04-16 15:54:17 +0000",
  "in_reply_to_screen_name" : "Millennial_Dave",
  "in_reply_to_user_id_str" : "60185021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/XnkCyARYbU",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/theapothecary\/2014\/04\/15\/how-a-nobel-economist-ruined-the-residency-matching-system-for-newly-minted-m-d-s\/",
      "display_url" : "forbes.com\/sites\/theapoth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "456447299019763713",
  "text" : "RT @bquarant: How a Nobel Economist Ruined The Residency Matching System For Newly Minted M.D.'s http:\/\/t.co\/XnkCyARYbU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/XnkCyARYbU",
        "expanded_url" : "http:\/\/www.forbes.com\/sites\/theapothecary\/2014\/04\/15\/how-a-nobel-economist-ruined-the-residency-matching-system-for-newly-minted-m-d-s\/",
        "display_url" : "forbes.com\/sites\/theapoth\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "456445123669135360",
    "text" : "How a Nobel Economist Ruined The Residency Matching System For Newly Minted M.D.'s http:\/\/t.co\/XnkCyARYbU",
    "id" : 456445123669135360,
    "created_at" : "2014-04-16 14:52:52 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 456447299019763713,
  "created_at" : "2014-04-16 15:01:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456163056335077376",
  "geo" : { },
  "id_str" : "456169144937766913",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic Yes, Patrick.",
  "id" : 456169144937766913,
  "in_reply_to_status_id" : 456163056335077376,
  "created_at" : "2014-04-15 20:36:14 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456157152357269505",
  "geo" : { },
  "id_str" : "456157269017645057",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda DON'T ANSWER!!! RESPOND!!!",
  "id" : 456157269017645057,
  "in_reply_to_status_id" : 456157152357269505,
  "created_at" : "2014-04-15 19:49:02 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nadim Kobeissi ",
      "screen_name" : "kaepora",
      "indices" : [ 0, 8 ],
      "id_str" : "11728992",
      "id" : 11728992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456126080920084480",
  "geo" : { },
  "id_str" : "456126839887769600",
  "in_reply_to_user_id" : 11728992,
  "text" : "@kaepora it's wonderful. Just keep backups ;)",
  "id" : 456126839887769600,
  "in_reply_to_status_id" : 456126080920084480,
  "created_at" : "2014-04-15 17:48:07 +0000",
  "in_reply_to_screen_name" : "kaepora",
  "in_reply_to_user_id_str" : "11728992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 0, 6 ],
      "id_str" : "24425454",
      "id" : 24425454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456094386338529281",
  "geo" : { },
  "id_str" : "456100022526832642",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgmnz what bugs me most is minor usability\/syntax differences with mysql. Too hard to switch. Simple stuff like `show tables;`",
  "id" : 456100022526832642,
  "in_reply_to_status_id" : 456094386338529281,
  "created_at" : "2014-04-15 16:01:33 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/36pUusi5Jd",
      "expanded_url" : "http:\/\/signalvnoise.com\/posts\/3734-dragons-on-the-far-side-of-the-histogram",
      "display_url" : "signalvnoise.com\/posts\/3734-dra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "456090612505133056",
  "text" : "I need some dragon-slayer business cards: http:\/\/t.co\/36pUusi5Jd",
  "id" : 456090612505133056,
  "created_at" : "2014-04-15 15:24:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "RailsConf 2015",
      "screen_name" : "railsconf",
      "indices" : [ 36, 46 ],
      "id_str" : "5493662",
      "id" : 5493662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/e15Vny33Cs",
      "expanded_url" : "https:\/\/www.eventbrite.com\/e\/basecamp-open-house-tickets-11317070663",
      "display_url" : "eventbrite.com\/e\/basecamp-ope\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "456090377624506368",
  "text" : "RT @dhh: Basecamp Open House during @RailsConf: https:\/\/t.co\/e15Vny33Cs \u2014 Space is limited to 300. Wed night from 7:30-9:30pm. Come say hi!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RailsConf 2015",
        "screen_name" : "railsconf",
        "indices" : [ 27, 37 ],
        "id_str" : "5493662",
        "id" : 5493662
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/e15Vny33Cs",
        "expanded_url" : "https:\/\/www.eventbrite.com\/e\/basecamp-open-house-tickets-11317070663",
        "display_url" : "eventbrite.com\/e\/basecamp-ope\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "456090323450466304",
    "text" : "Basecamp Open House during @RailsConf: https:\/\/t.co\/e15Vny33Cs \u2014 Space is limited to 300. Wed night from 7:30-9:30pm. Come say hi!",
    "id" : 456090323450466304,
    "created_at" : "2014-04-15 15:23:01 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 456090377624506368,
  "created_at" : "2014-04-15 15:23:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455882906175406080",
  "text" : "WAT? You can run irb inside of irb.",
  "id" : 455882906175406080,
  "created_at" : "2014-04-15 01:38:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Nagel",
      "screen_name" : "ericnagel",
      "indices" : [ 0, 10 ],
      "id_str" : "2522211",
      "id" : 2522211
    }, {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 22, 30 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455839920511143936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9910429242, -78.8395575342 ]
  },
  "id_str" : "455841004969807872",
  "in_reply_to_user_id" : 2522211,
  "text" : "@ericnagel if you and @patio11 are both there please say hi! Sounds like a great conf.",
  "id" : 455841004969807872,
  "in_reply_to_status_id" : 455839920511143936,
  "created_at" : "2014-04-14 22:52:19 +0000",
  "in_reply_to_screen_name" : "ericnagel",
  "in_reply_to_user_id_str" : "2522211",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy Sandora-Nastyn",
      "screen_name" : "BillybobN",
      "indices" : [ 0, 10 ],
      "id_str" : "97221495",
      "id" : 97221495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455834709033897984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9908673233, -78.8395364118 ]
  },
  "id_str" : "455836602187939840",
  "in_reply_to_user_id" : 97221495,
  "text" : "@BillybobN La Nova!",
  "id" : 455836602187939840,
  "in_reply_to_status_id" : 455834709033897984,
  "created_at" : "2014-04-14 22:34:49 +0000",
  "in_reply_to_screen_name" : "BillybobN",
  "in_reply_to_user_id_str" : "97221495",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9909805628, -78.8395155408 ]
  },
  "id_str" : "455828759875448832",
  "text" : "Shout out to the guy biking on the 190N-290E interchange. Sweet ride.",
  "id" : 455828759875448832,
  "created_at" : "2014-04-14 22:03:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 0, 12 ],
      "id_str" : "158098704",
      "id" : 158098704
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 13, 27 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455686006243483649",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242766368, -78.8792093881 ]
  },
  "id_str" : "455694838109716480",
  "in_reply_to_user_id" : 158098704,
  "text" : "@mikemikemac @coworkbuffalo there\u2019s plenty of galleries in Allentown if one of our members wants to do a show",
  "id" : 455694838109716480,
  "in_reply_to_status_id" : 455686006243483649,
  "created_at" : "2014-04-14 13:11:30 +0000",
  "in_reply_to_screen_name" : "mikemikemac",
  "in_reply_to_user_id_str" : "158098704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455490233300430848",
  "geo" : { },
  "id_str" : "455508070635167746",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel we can still use require_tree for Basecamp, with plenty of Backbone code. Just feels strange to go against the grain.",
  "id" : 455508070635167746,
  "in_reply_to_status_id" : 455490233300430848,
  "created_at" : "2014-04-14 00:49:21 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455487377533059072",
  "geo" : { },
  "id_str" : "455488520023330816",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel and no, just whining. Also Refills gem doesn't work with Rails 4, but copying the snippets in does :)",
  "id" : 455488520023330816,
  "in_reply_to_status_id" : 455487377533059072,
  "created_at" : "2014-04-13 23:31:40 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455487377533059072",
  "geo" : { },
  "id_str" : "455488390708740096",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel just sucks that you can't drop stuff into \u007Bapp,vendor,lib\u007D\/assets\/stylesheets and it just *works*. Import is way too manual.",
  "id" : 455488390708740096,
  "in_reply_to_status_id" : 455487377533059072,
  "created_at" : "2014-04-13 23:31:09 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/qJqNlrJXKd",
      "expanded_url" : "https:\/\/github.com\/thoughtbot\/bourbon#install-for-rails-31",
      "display_url" : "github.com\/thoughtbot\/bou\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "455485386828316672",
  "geo" : { },
  "id_str" : "455486356886548480",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel first instruction for bourbon, neat, etc is still remove require_tree: https:\/\/t.co\/qJqNlrJXKd",
  "id" : 455486356886548480,
  "in_reply_to_status_id" : 455485386828316672,
  "created_at" : "2014-04-13 23:23:04 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/8Keh8rKgnm",
      "expanded_url" : "http:\/\/bourbon.io",
      "display_url" : "bourbon.io"
    } ]
  },
  "geo" : { },
  "id_str" : "455484984401215488",
  "text" : "I really wish http:\/\/t.co\/8Keh8rKgnm worked with sprockets. It's like going back in Rails time.",
  "id" : 455484984401215488,
  "created_at" : "2014-04-13 23:17:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "indices" : [ 0, 13 ],
      "id_str" : "9887162",
      "id" : 9887162
    }, {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 14, 25 ],
      "id_str" : "9887102",
      "id" : 9887102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455366135295512576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244815186, -78.87931793 ]
  },
  "id_str" : "455367005911003137",
  "in_reply_to_user_id" : 9887162,
  "text" : "@markimbriaco @metaskills it was a joy at the airport. You can just unzip, lay it flat and not remove the laptop. No complaints from the TSA",
  "id" : 455367005911003137,
  "in_reply_to_status_id" : 455366135295512576,
  "created_at" : "2014-04-13 15:28:49 +0000",
  "in_reply_to_screen_name" : "markimbriaco",
  "in_reply_to_user_id_str" : "9887162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 28, 38 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9222412409, -78.8799660817 ]
  },
  "id_str" : "455170137209860096",
  "text" : "Current status: introducing @aquaranto to Braveheart and drinking Laphroaig. Appropriate.",
  "id" : 455170137209860096,
  "created_at" : "2014-04-13 02:26:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Eats",
      "screen_name" : "BuffaloEats",
      "indices" : [ 0, 12 ],
      "id_str" : "21758029",
      "id" : 21758029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455096831752425472",
  "geo" : { },
  "id_str" : "455098791700344832",
  "in_reply_to_user_id" : 21758029,
  "text" : "@BuffaloEats wow, what took so long?",
  "id" : 455098791700344832,
  "in_reply_to_status_id" : 455096831752425472,
  "created_at" : "2014-04-12 21:43:01 +0000",
  "in_reply_to_screen_name" : "BuffaloEats",
  "in_reply_to_user_id_str" : "21758029",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455068037918781440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240069201, -78.8791807153 ]
  },
  "id_str" : "455069684442730496",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden there\u2019s a great diner around the corner there.",
  "id" : 455069684442730496,
  "in_reply_to_status_id" : 455068037918781440,
  "created_at" : "2014-04-12 19:47:22 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "dom",
      "screen_name" : "dddagradi",
      "indices" : [ 12, 22 ],
      "id_str" : "13237062",
      "id" : 13237062
    }, {
      "name" : "Lukas Blakk",
      "screen_name" : "lsblakk",
      "indices" : [ 23, 31 ],
      "id_str" : "15649355",
      "id" : 15649355
    }, {
      "name" : "kat",
      "screen_name" : "wirehead2501",
      "indices" : [ 32, 45 ],
      "id_str" : "11797632",
      "id" : 11797632
    }, {
      "name" : "Liene Verzemnieks",
      "screen_name" : "li3n3",
      "indices" : [ 46, 52 ],
      "id_str" : "498467901",
      "id" : 498467901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/8fsamADfIP",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/qrush\/8298219421\/",
      "display_url" : "flickr.com\/photos\/qrush\/8\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "455064351603699712",
  "geo" : { },
  "id_str" : "455065194788425729",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @dddagradi @lsblakk @wirehead2501 @li3n3 @kmrhb this one? https:\/\/t.co\/8fsamADfIP",
  "id" : 455065194788425729,
  "in_reply_to_status_id" : 455064351603699712,
  "created_at" : "2014-04-12 19:29:31 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9238019833, -78.8794020979 ]
  },
  "id_str" : "455027619688226816",
  "text" : "I\u2019m sure by this point that the writers of House have some kind of needle puncture fetish. That has to be a thing right? (DO NOT REPLY)",
  "id" : 455027619688226816,
  "created_at" : "2014-04-12 17:00:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 18, 32 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/079SdfHh11",
      "expanded_url" : "http:\/\/buffalorising.com\/2014\/04\/genesee-gateway-lands-restaurant-tenant\/",
      "display_url" : "buffalorising.com\/2014\/04\/genese\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "455002028435963904",
  "text" : "Lunch options for @coworkbuffalo keep getting better and better: http:\/\/t.co\/079SdfHh11",
  "id" : 455002028435963904,
  "created_at" : "2014-04-12 15:18:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/nN1tqCBqY0",
      "expanded_url" : "http:\/\/www.zenspider.com\/Languages\/Ruby\/QuickRef.html#pre-defined-variables",
      "display_url" : "zenspider.com\/Languages\/Ruby\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454985364986273792",
  "text" : "Reminded this morning of $` and $'. Lots of Regexp goodies here: http:\/\/t.co\/nN1tqCBqY0",
  "id" : 454985364986273792,
  "created_at" : "2014-04-12 14:12:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "indices" : [ 0, 13 ],
      "id_str" : "9887162",
      "id" : 9887162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454961727483162624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241475389, -78.879125557 ]
  },
  "id_str" : "454965527987769344",
  "in_reply_to_user_id" : 9887162,
  "text" : "@markimbriaco just got a new one in 9 (!) years. The TSA compliant one is really great.",
  "id" : 454965527987769344,
  "in_reply_to_status_id" : 454961727483162624,
  "created_at" : "2014-04-12 12:53:29 +0000",
  "in_reply_to_screen_name" : "markimbriaco",
  "in_reply_to_user_id_str" : "9887162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454815712620843008",
  "geo" : { },
  "id_str" : "454816244886016000",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn Not sure! Little guy will be in tow. No idea what our plans are, but sanity and sleep are high on the list.",
  "id" : 454816244886016000,
  "in_reply_to_status_id" : 454815712620843008,
  "created_at" : "2014-04-12 03:00:17 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/454811198790201344\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/wpe1KIVhcy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk_QYCgCcAAFuX0.png",
      "id_str" : "454811198794395648",
      "id" : 454811198794395648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk_QYCgCcAAFuX0.png",
      "sizes" : [ {
        "h" : 587,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 950,
        "resize" : "fit",
        "w" : 1655
      }, {
        "h" : 195,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wpe1KIVhcy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454811198790201344",
  "text" : "Randomized FireRed has just started, and it's already ridiculous. Have a strong feeling this will be the best yet. http:\/\/t.co\/wpe1KIVhcy",
  "id" : 454811198790201344,
  "created_at" : "2014-04-12 02:40:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/thXUqOroes",
      "expanded_url" : "http:\/\/www.twitch.tv\/twitchplayspokemon",
      "display_url" : "twitch.tv\/twitchplayspok\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454800272758296576",
  "text" : "4 minutes to the start of another 3-4 weeks of accidentally jumping over ledges http:\/\/t.co\/thXUqOroes",
  "id" : 454800272758296576,
  "created_at" : "2014-04-12 01:56:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454798411049357312",
  "text" : "Can I watch a version of House without all of the sudden needle punctures?",
  "id" : 454798411049357312,
  "created_at" : "2014-04-12 01:49:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454767244200140800",
  "geo" : { },
  "id_str" : "454777925603053568",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz A little unfair given your location.",
  "id" : 454777925603053568,
  "in_reply_to_status_id" : 454767244200140800,
  "created_at" : "2014-04-12 00:28:01 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454764887869108224",
  "text" : "Summer: Mojitos, Fall: Kraken &amp; Cider, Winter: White Russian, Spring: ??? (Any suggestions?)",
  "id" : 454764887869108224,
  "created_at" : "2014-04-11 23:36:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Menard",
      "screen_name" : "mark_menard",
      "indices" : [ 0, 12 ],
      "id_str" : "13168222",
      "id" : 13168222
    }, {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 13, 23 ],
      "id_str" : "1949721",
      "id" : 1949721
    }, {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 24, 31 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454730534997213184",
  "geo" : { },
  "id_str" : "454763651363119104",
  "in_reply_to_user_id" : 13168222,
  "text" : "@mark_menard @listrophy @zobar2 it was outside at Shea's.",
  "id" : 454763651363119104,
  "in_reply_to_status_id" : 454730534997213184,
  "created_at" : "2014-04-11 23:31:18 +0000",
  "in_reply_to_screen_name" : "mark_menard",
  "in_reply_to_user_id_str" : "13168222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/454755037487443969\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/R3q1trRTUU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk-dTAlCQAAst7S.png",
      "id_str" : "454755037286121472",
      "id" : 454755037286121472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk-dTAlCQAAst7S.png",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/R3q1trRTUU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924126402, -78.8789713412 ]
  },
  "id_str" : "454755037487443969",
  "text" : "Emerald down! Somehow a mob of people have beaten three games so far. http:\/\/t.co\/R3q1trRTUU",
  "id" : 454755037487443969,
  "created_at" : "2014-04-11 22:57:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 8, 22 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454730153755566080",
  "text" : "Current @coworkbuffalo status: Wedding party of 18 + 4 kids taking photos, random guy shows up with a 30 rack in a king's cape.",
  "id" : 454730153755566080,
  "created_at" : "2014-04-11 21:18:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/ajYvX8Lq9E",
      "expanded_url" : "http:\/\/www.sec.gov\/Archives\/edgar\/data\/1018724\/000119312514137753\/d702518dex991.htm",
      "display_url" : "sec.gov\/Archives\/edgar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454718519372832768",
  "text" : "\"109 Maydays have been customers asking for assistance with ordering a pizza.\" http:\/\/t.co\/ajYvX8Lq9E",
  "id" : 454718519372832768,
  "created_at" : "2014-04-11 20:31:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/SXpASYNlpe",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Kas6akz1jWU",
      "display_url" : "youtube.com\/watch?v=Kas6ak\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454715281286246400",
  "text" : "Current status: https:\/\/t.co\/SXpASYNlpe",
  "id" : 454715281286246400,
  "created_at" : "2014-04-11 20:19:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 11, 25 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/454709913260793856\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/OgnsNJRtb5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk90QbsCMAATQUS.jpg",
      "id_str" : "454709913046888448",
      "id" : 454709913046888448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk90QbsCMAATQUS.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OgnsNJRtb5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454709913260793856",
  "text" : "Shadows of @coworkbuffalo http:\/\/t.co\/OgnsNJRtb5",
  "id" : 454709913260793856,
  "created_at" : "2014-04-11 19:57:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 47, 61 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241244675, -78.8791149223 ]
  },
  "id_str" : "454462160497033217",
  "text" : "Hoping tomorrow will be my first biking day to @coworkbuffalo. Hoping I\u2019m not jynxing myself right now.",
  "id" : 454462160497033217,
  "created_at" : "2014-04-11 03:33:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica McKellar",
      "screen_name" : "jessicamckellar",
      "indices" : [ 0, 16 ],
      "id_str" : "24945605",
      "id" : 24945605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413009020522221568",
  "geo" : { },
  "id_str" : "454449451872944128",
  "in_reply_to_user_id" : 24945605,
  "text" : "@jessicamckellar awesome. would love to know what changed to make this happen!",
  "id" : 454449451872944128,
  "in_reply_to_status_id" : 413009020522221568,
  "created_at" : "2014-04-11 02:42:47 +0000",
  "in_reply_to_screen_name" : "jessicamckellar",
  "in_reply_to_user_id_str" : "24945605",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tristan O\u2019Tierney",
      "screen_name" : "tristan",
      "indices" : [ 0, 8 ],
      "id_str" : "712733",
      "id" : 712733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454437601458794496",
  "geo" : { },
  "id_str" : "454437952328712192",
  "in_reply_to_user_id" : 712733,
  "text" : "@tristan very glad this wasn't a thing when I was at RIT. Hots was enough. did you move back?",
  "id" : 454437952328712192,
  "in_reply_to_status_id" : 454437601458794496,
  "created_at" : "2014-04-11 01:57:05 +0000",
  "in_reply_to_screen_name" : "tristan",
  "in_reply_to_user_id_str" : "712733",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1Password",
      "screen_name" : "1Password",
      "indices" : [ 3, 13 ],
      "id_str" : "793926",
      "id" : 793926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454426418194030592",
  "text" : "RT @1Password: Heartbleed is breaking my pixelated heart into bits. \n\nWe\u2019re offering a 50% discount across all platforms, to make recovery \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454419417695531009",
    "text" : "Heartbleed is breaking my pixelated heart into bits. \n\nWe\u2019re offering a 50% discount across all platforms, to make recovery a little easier.",
    "id" : 454419417695531009,
    "created_at" : "2014-04-11 00:43:26 +0000",
    "user" : {
      "name" : "1Password",
      "screen_name" : "1Password",
      "protected" : false,
      "id_str" : "793926",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571442447289315328\/4hqeQrc2_normal.png",
      "id" : 793926,
      "verified" : false
    }
  },
  "id" : 454426418194030592,
  "created_at" : "2014-04-11 01:11:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Rosen",
      "screen_name" : "rosenboy",
      "indices" : [ 0, 9 ],
      "id_str" : "11215972",
      "id" : 11215972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454403219092148225",
  "geo" : { },
  "id_str" : "454403481055416320",
  "in_reply_to_user_id" : 11215972,
  "text" : "@rosenboy Wegmans &gt; *",
  "id" : 454403481055416320,
  "in_reply_to_status_id" : 454403219092148225,
  "created_at" : "2014-04-10 23:40:06 +0000",
  "in_reply_to_screen_name" : "rosenboy",
  "in_reply_to_user_id_str" : "11215972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil",
      "screen_name" : "phil_wade",
      "indices" : [ 0, 10 ],
      "id_str" : "59245756",
      "id" : 59245756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454287096484990977",
  "geo" : { },
  "id_str" : "454402757865132032",
  "in_reply_to_user_id" : 59245756,
  "text" : "@phil_wade thanks! just tried to make it simple and work well on mobile.",
  "id" : 454402757865132032,
  "in_reply_to_status_id" : 454287096484990977,
  "created_at" : "2014-04-10 23:37:14 +0000",
  "in_reply_to_screen_name" : "phil_wade",
  "in_reply_to_user_id_str" : "59245756",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil",
      "screen_name" : "phil_wade",
      "indices" : [ 3, 13 ],
      "id_str" : "59245756",
      "id" : 59245756
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 70, 84 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/X6OJPTVPcc",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food\/",
      "display_url" : "coworkbuffalo.com\/food\/"
    } ]
  },
  "geo" : { },
  "id_str" : "454402646447624193",
  "text" : "RT @phil_wade: There are like eight buffalo food truck sites, yet the @coworkbuffalo food truck page is the most helpful http:\/\/t.co\/X6OJPT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 55, 69 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/X6OJPTVPcc",
        "expanded_url" : "http:\/\/coworkbuffalo.com\/food\/",
        "display_url" : "coworkbuffalo.com\/food\/"
      } ]
    },
    "geo" : { },
    "id_str" : "454287096484990977",
    "text" : "There are like eight buffalo food truck sites, yet the @coworkbuffalo food truck page is the most helpful http:\/\/t.co\/X6OJPTVPcc go figure?",
    "id" : 454287096484990977,
    "created_at" : "2014-04-10 15:57:38 +0000",
    "user" : {
      "name" : "Phil",
      "screen_name" : "phil_wade",
      "protected" : false,
      "id_str" : "59245756",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/496119255796969472\/-T1sGPoR_normal.jpeg",
      "id" : 59245756,
      "verified" : false
    }
  },
  "id" : 454402646447624193,
  "created_at" : "2014-04-10 23:36:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    }, {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 11, 24 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454371255785779200",
  "geo" : { },
  "id_str" : "454371975683506176",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik @lindseybieda HOW IS JOBBY FORMED?",
  "id" : 454371975683506176,
  "in_reply_to_status_id" : 454371255785779200,
  "created_at" : "2014-04-10 21:34:55 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454370163094482944",
  "geo" : { },
  "id_str" : "454370303519387648",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik this is what networking\/conferences are for :)",
  "id" : 454370303519387648,
  "in_reply_to_status_id" : 454370163094482944,
  "created_at" : "2014-04-10 21:28:16 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Gravert",
      "screen_name" : "egravert",
      "indices" : [ 3, 12 ],
      "id_str" : "14461699",
      "id" : 14461699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454343597744082944",
  "text" : "RT @egravert: Favorite term of the day:\n\"Porkbarrel Pull Request\": To hide a change the other devs hate in a huge, high priority pull reque\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454065329359310848",
    "text" : "Favorite term of the day:\n\"Porkbarrel Pull Request\": To hide a change the other devs hate in a huge, high priority pull request.",
    "id" : 454065329359310848,
    "created_at" : "2014-04-10 01:16:25 +0000",
    "user" : {
      "name" : "Eric Gravert",
      "screen_name" : "egravert",
      "protected" : false,
      "id_str" : "14461699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53317731\/funny-pictures-peep-show-easter-candy_normal.jpg",
      "id" : 14461699,
      "verified" : false
    }
  },
  "id" : 454343597744082944,
  "created_at" : "2014-04-10 19:42:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caius Durling",
      "screen_name" : "Caius",
      "indices" : [ 3, 9 ],
      "id_str" : "5857812",
      "id" : 5857812
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 11, 17 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454304229591486464",
  "text" : "RT @Caius: @qrush neat trick I found recently\u2014`sponge` (brew install moreutils) saves the .new\/mv trick. `git stripspace &lt; $i | sponge $i`",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "454300840623210496",
    "geo" : { },
    "id_str" : "454302923154272256",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush neat trick I found recently\u2014`sponge` (brew install moreutils) saves the .new\/mv trick. `git stripspace &lt; $i | sponge $i`",
    "id" : 454302923154272256,
    "in_reply_to_status_id" : 454300840623210496,
    "created_at" : "2014-04-10 17:00:32 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Caius Durling",
      "screen_name" : "Caius",
      "protected" : false,
      "id_str" : "5857812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539377622825070592\/MgkNo-5j_normal.jpeg",
      "id" : 5857812,
      "verified" : false
    }
  },
  "id" : 454304229591486464,
  "created_at" : "2014-04-10 17:05:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/QnEOUImBdp",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/10401517",
      "display_url" : "gist.github.com\/qrush\/10401517"
    } ]
  },
  "geo" : { },
  "id_str" : "454300840623210496",
  "text" : "Learned about git-stripspace today: https:\/\/t.co\/QnEOUImBdp",
  "id" : 454300840623210496,
  "created_at" : "2014-04-10 16:52:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy Sandora-Nastyn",
      "screen_name" : "BillybobN",
      "indices" : [ 17, 27 ],
      "id_str" : "97221495",
      "id" : 97221495
    }, {
      "name" : "Pat Sandora-Nastyn",
      "screen_name" : "PatSandora",
      "indices" : [ 32, 43 ],
      "id_str" : "21421691",
      "id" : 21421691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/YOLGXBgUrQ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=s5A91TYt5yQ",
      "display_url" : "youtube.com\/watch?v=s5A91T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454256985651679232",
  "text" : "A big welcome to @billybobn and @PatSandora to Buffalo! Love seeing more people moving here. https:\/\/t.co\/YOLGXBgUrQ",
  "id" : 454256985651679232,
  "created_at" : "2014-04-10 13:57:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 0, 14 ],
      "id_str" : "45490102",
      "id" : 45490102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454254674351517696",
  "geo" : { },
  "id_str" : "454255724148031489",
  "in_reply_to_user_id" : 45490102,
  "text" : "@markpoloncarz Captain Erie County. Now you just need a shield.",
  "id" : 454255724148031489,
  "in_reply_to_status_id" : 454254674351517696,
  "created_at" : "2014-04-10 13:52:58 +0000",
  "in_reply_to_screen_name" : "markpoloncarz",
  "in_reply_to_user_id_str" : "45490102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454244862779355137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9238025433, -78.8794005739 ]
  },
  "id_str" : "454245618899116032",
  "in_reply_to_user_id" : 896641,
  "text" : "@JZ yikes, wtf. Did you spot any wells close by?",
  "id" : 454245618899116032,
  "in_reply_to_status_id" : 454244862779355137,
  "created_at" : "2014-04-10 13:12:49 +0000",
  "in_reply_to_screen_name" : "jasonzimdars",
  "in_reply_to_user_id_str" : "896641",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 3, 14 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454221579275100160",
  "text" : "RT @samkottler: Reverse heartbleed is more scary than the original issue because the attack surface is significantly larger.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 27.4223294315, 89.6512457024 ]
    },
    "id_str" : "454208902318399488",
    "text" : "Reverse heartbleed is more scary than the original issue because the attack surface is significantly larger.",
    "id" : 454208902318399488,
    "created_at" : "2014-04-10 10:46:55 +0000",
    "user" : {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "protected" : false,
      "id_str" : "103914540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572808884675301376\/whqN3Ix2_normal.jpeg",
      "id" : 103914540,
      "verified" : false
    }
  },
  "id" : 454221579275100160,
  "created_at" : "2014-04-10 11:37:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 3, 14 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/qAFBbEZksl",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "454221570026659842",
  "text" : "RT @samkottler: http:\/\/t.co\/qAFBbEZksl received advanced notice of 'reverse heartbleed' attack (client issue) and rolled out a fix late las\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/qAFBbEZksl",
        "expanded_url" : "http:\/\/RubyGems.org",
        "display_url" : "RubyGems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "454202198381961217",
    "text" : "http:\/\/t.co\/qAFBbEZksl received advanced notice of 'reverse heartbleed' attack (client issue) and rolled out a fix late last night.",
    "id" : 454202198381961217,
    "created_at" : "2014-04-10 10:20:17 +0000",
    "user" : {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "protected" : false,
      "id_str" : "103914540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572808884675301376\/whqN3Ix2_normal.jpeg",
      "id" : 103914540,
      "verified" : false
    }
  },
  "id" : 454221570026659842,
  "created_at" : "2014-04-10 11:37:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Kapp",
      "screen_name" : "happymrdave",
      "indices" : [ 0, 12 ],
      "id_str" : "15399388",
      "id" : 15399388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454217312996823040",
  "geo" : { },
  "id_str" : "454219240027852800",
  "in_reply_to_user_id" : 15399388,
  "text" : "@happymrdave I'd just rather play those games! :)",
  "id" : 454219240027852800,
  "in_reply_to_status_id" : 454217312996823040,
  "created_at" : "2014-04-10 11:28:00 +0000",
  "in_reply_to_screen_name" : "happymrdave",
  "in_reply_to_user_id_str" : "15399388",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Kapp",
      "screen_name" : "happymrdave",
      "indices" : [ 0, 12 ],
      "id_str" : "15399388",
      "id" : 15399388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454216130375061504",
  "geo" : { },
  "id_str" : "454216540485718016",
  "in_reply_to_user_id" : 15399388,
  "text" : "@happymrdave was the first one good? holding out still from both.",
  "id" : 454216540485718016,
  "in_reply_to_status_id" : 454216130375061504,
  "created_at" : "2014-04-10 11:17:16 +0000",
  "in_reply_to_screen_name" : "happymrdave",
  "in_reply_to_user_id_str" : "15399388",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 8, 15 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454203313144475648",
  "geo" : { },
  "id_str" : "454204251963543552",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel @Croaky cool. also, congrats on the launch. more products! :)",
  "id" : 454204251963543552,
  "in_reply_to_status_id" : 454203313144475648,
  "created_at" : "2014-04-10 10:28:27 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 0, 11 ],
      "id_str" : "137891464",
      "id" : 137891464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454089531000909824",
  "geo" : { },
  "id_str" : "454089781740179456",
  "in_reply_to_user_id" : 137891464,
  "text" : "@nickelcity I will pay for this. Also g diapers are great for no branding and fuss.",
  "id" : 454089781740179456,
  "in_reply_to_status_id" : 454089531000909824,
  "created_at" : "2014-04-10 02:53:35 +0000",
  "in_reply_to_screen_name" : "nickelcity",
  "in_reply_to_user_id_str" : "137891464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 0, 11 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 12, 19 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453951834546515968",
  "geo" : { },
  "id_str" : "454089232781299712",
  "in_reply_to_user_id" : 14114392,
  "text" : "@thoughtbot @Croaky for the love of everything that is holy please don\u2019t sic Hound on every repo like that stupid white space bot",
  "id" : 454089232781299712,
  "in_reply_to_status_id" : 453951834546515968,
  "created_at" : "2014-04-10 02:51:24 +0000",
  "in_reply_to_screen_name" : "thoughtbot",
  "in_reply_to_user_id_str" : "14114392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 0, 12 ],
      "id_str" : "16454301",
      "id" : 16454301
    }, {
      "name" : "Dan Kim",
      "screen_name" : "dankim",
      "indices" : [ 13, 20 ],
      "id_str" : "7979212",
      "id" : 7979212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454076894904725504",
  "geo" : { },
  "id_str" : "454086708741812224",
  "in_reply_to_user_id" : 16454301,
  "text" : "@jonasdowney @dankim what is wrong with you people",
  "id" : 454086708741812224,
  "in_reply_to_status_id" : 454076894904725504,
  "created_at" : "2014-04-10 02:41:22 +0000",
  "in_reply_to_screen_name" : "jonasdowney",
  "in_reply_to_user_id_str" : "16454301",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wCsxAXRmfr",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    }, {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/9GiTT0nebA",
      "expanded_url" : "http:\/\/blog.rubygems.org\/2014\/04\/09\/heartbleed.html",
      "display_url" : "blog.rubygems.org\/2014\/04\/09\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454085414173696001",
  "text" : "http:\/\/t.co\/wCsxAXRmfr Heartbleed response: http:\/\/t.co\/9GiTT0nebA",
  "id" : 454085414173696001,
  "created_at" : "2014-04-10 02:36:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 3, 14 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/qAFBbEZksl",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    }, {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/KZWaUdmQS9",
      "expanded_url" : "http:\/\/blog.rubygems.org\/2014\/04\/09\/heartbleed.html",
      "display_url" : "blog.rubygems.org\/2014\/04\/09\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454085291888762880",
  "text" : "RT @samkottler: I wrote a quick blog post about how the http:\/\/t.co\/qAFBbEZksl team responded to CVE-2014-0160. http:\/\/t.co\/KZWaUdmQS9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/qAFBbEZksl",
        "expanded_url" : "http:\/\/RubyGems.org",
        "display_url" : "RubyGems.org"
      }, {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/KZWaUdmQS9",
        "expanded_url" : "http:\/\/blog.rubygems.org\/2014\/04\/09\/heartbleed.html",
        "display_url" : "blog.rubygems.org\/2014\/04\/09\/hea\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 27.3979945, 89.66088583 ]
    },
    "id_str" : "454080485187006464",
    "text" : "I wrote a quick blog post about how the http:\/\/t.co\/qAFBbEZksl team responded to CVE-2014-0160. http:\/\/t.co\/KZWaUdmQS9",
    "id" : 454080485187006464,
    "created_at" : "2014-04-10 02:16:38 +0000",
    "user" : {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "protected" : false,
      "id_str" : "103914540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572808884675301376\/whqN3Ix2_normal.jpeg",
      "id" : 103914540,
      "verified" : false
    }
  },
  "id" : 454085291888762880,
  "created_at" : "2014-04-10 02:35:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/P4F85fXvDu",
      "expanded_url" : "http:\/\/www.objc.io\/issue-9\/unicode.html",
      "display_url" : "objc.io\/issue-9\/unicod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454084826539098112",
  "text" : "Extremely detailed and clear article about Unicode: http:\/\/t.co\/P4F85fXvDu I wish there were more articles like this for other langs.",
  "id" : 454084826539098112,
  "created_at" : "2014-04-10 02:33:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 17, 29 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/rTiTnqBQvq",
      "expanded_url" : "https:\/\/www.kickstarter.com\/projects\/aqueous\/aqueous-new-studio-album?ref=card",
      "display_url" : "kickstarter.com\/projects\/aqueo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454076461482115072",
  "text" : "My hometown boys @AqueousBand are halfway there with halfway to go. Help Kickstart Buffalo's next great band: https:\/\/t.co\/rTiTnqBQvq",
  "id" : 454076461482115072,
  "created_at" : "2014-04-10 02:00:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Borncamp",
      "screen_name" : "borncamp",
      "indices" : [ 0, 9 ],
      "id_str" : "1002573926",
      "id" : 1002573926
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 10, 24 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 25, 33 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453925855685652482",
  "geo" : { },
  "id_str" : "454074224752091136",
  "in_reply_to_user_id" : 1002573926,
  "text" : "@borncamp @coworkbuffalo @wnyruby Woot!",
  "id" : 454074224752091136,
  "in_reply_to_status_id" : 453925855685652482,
  "created_at" : "2014-04-10 01:51:46 +0000",
  "in_reply_to_screen_name" : "borncamp",
  "in_reply_to_user_id_str" : "1002573926",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454001001666990080",
  "text" : "@juliepagano where did this come from!!!!",
  "id" : 454001001666990080,
  "created_at" : "2014-04-09 21:00:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "heartbleed",
      "indices" : [ 35, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453987106193674240",
  "text" : "My dad just texted me to ask about #heartbleed. This thing is really huge.",
  "id" : 453987106193674240,
  "created_at" : "2014-04-09 20:05:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinboard",
      "screen_name" : "Pinboard",
      "indices" : [ 3, 12 ],
      "id_str" : "55525953",
      "id" : 55525953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/lqSpx11irt",
      "expanded_url" : "http:\/\/goo.gl\/jAnJC",
      "display_url" : "goo.gl\/jAnJC"
    } ]
  },
  "geo" : { },
  "id_str" : "453958659748286466",
  "text" : "RT @Pinboard: A good time to re-read this key article on Internet security, which is still the best advice I\u2019ve seen: http:\/\/t.co\/lqSpx11irt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/lqSpx11irt",
        "expanded_url" : "http:\/\/goo.gl\/jAnJC",
        "display_url" : "goo.gl\/jAnJC"
      } ]
    },
    "geo" : { },
    "id_str" : "453957939821170688",
    "text" : "A good time to re-read this key article on Internet security, which is still the best advice I\u2019ve seen: http:\/\/t.co\/lqSpx11irt",
    "id" : 453957939821170688,
    "created_at" : "2014-04-09 18:09:41 +0000",
    "user" : {
      "name" : "Pinboard",
      "screen_name" : "Pinboard",
      "protected" : false,
      "id_str" : "55525953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494414965\/logo_normal.png",
      "id" : 55525953,
      "verified" : false
    }
  },
  "id" : 453958659748286466,
  "created_at" : "2014-04-09 18:12:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Roes",
      "screen_name" : "jroes",
      "indices" : [ 0, 6 ],
      "id_str" : "1431461",
      "id" : 1431461
    }, {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 37, 49 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453627969089441792",
  "geo" : { },
  "id_str" : "453628335588114432",
  "in_reply_to_user_id" : 1431461,
  "text" : "@jroes Haven't had the time. I think @tristandunn has done some work on it lately.",
  "id" : 453628335588114432,
  "in_reply_to_status_id" : 453627969089441792,
  "created_at" : "2014-04-08 20:19:57 +0000",
  "in_reply_to_screen_name" : "jroes",
  "in_reply_to_user_id_str" : "1431461",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453618750672363520",
  "text" : "RT @dhh: It really is special that we can still be going so incredibly strong with Rails after a decade. Keep thinking we'll slow down. Nop\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "453617243901812736",
    "text" : "It really is special that we can still be going so incredibly strong with Rails after a decade. Keep thinking we'll slow down. Nope.",
    "id" : 453617243901812736,
    "created_at" : "2014-04-08 19:35:53 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 453618750672363520,
  "created_at" : "2014-04-08 19:41:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Troy Davis",
      "screen_name" : "troyd",
      "indices" : [ 0, 6 ],
      "id_str" : "14701738",
      "id" : 14701738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/AgxW0oDlkp",
      "expanded_url" : "http:\/\/hayeshomeroast.com\/",
      "display_url" : "hayeshomeroast.com"
    } ]
  },
  "in_reply_to_status_id_str" : "453347236391317505",
  "geo" : { },
  "id_str" : "453348312469352449",
  "in_reply_to_user_id" : 14701738,
  "text" : "@troyd Also http:\/\/t.co\/AgxW0oDlkp",
  "id" : 453348312469352449,
  "in_reply_to_status_id" : 453347236391317505,
  "created_at" : "2014-04-08 01:47:15 +0000",
  "in_reply_to_screen_name" : "troyd",
  "in_reply_to_user_id_str" : "14701738",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Troy Davis",
      "screen_name" : "troyd",
      "indices" : [ 0, 6 ],
      "id_str" : "14701738",
      "id" : 14701738
    }, {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 14, 29 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    }, {
      "name" : "Joe Bean Roasters",
      "screen_name" : "JoeBeanRoasters",
      "indices" : [ 34, 50 ],
      "id_str" : "83895391",
      "id" : 83895391
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 54, 68 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453347236391317505",
  "geo" : { },
  "id_str" : "453348204738641921",
  "in_reply_to_user_id" : 14701738,
  "text" : "@troyd we use @PublicEspresso and @JoeBeanRoasters at @coworkbuffalo, and it's time to support them at home too. Change of pace!",
  "id" : 453348204738641921,
  "in_reply_to_status_id" : 453347236391317505,
  "created_at" : "2014-04-08 01:46:49 +0000",
  "in_reply_to_screen_name" : "troyd",
  "in_reply_to_user_id_str" : "14701738",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453336526693212161",
  "geo" : { },
  "id_str" : "453337267470209024",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza definitely does, use it extensively for Basecamp for iPhone. seems to have trouble with custom container controllers though.",
  "id" : 453337267470209024,
  "in_reply_to_status_id" : 453336526693212161,
  "created_at" : "2014-04-08 01:03:21 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453333569834737664",
  "geo" : { },
  "id_str" : "453333852870557696",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 at this rate I need to start generating some ad revenue",
  "id" : 453333852870557696,
  "in_reply_to_status_id" : 453333569834737664,
  "created_at" : "2014-04-08 00:49:47 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TONX",
      "screen_name" : "tonxcoffee",
      "indices" : [ 54, 65 ],
      "id_str" : "288854366",
      "id" : 288854366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/6hEx1cvIp5",
      "expanded_url" : "http:\/\/ourincrediblejourney.tumblr.com\/",
      "display_url" : "ourincrediblejourney.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "453277355218583555",
  "text" : "Looks like another entry for http:\/\/t.co\/6hEx1cvIp5 : @tonxcoffee. Canceling my sub and supporting a smaller, local roaster.",
  "id" : 453277355218583555,
  "created_at" : "2014-04-07 21:05:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Guy",
      "screen_name" : "thenickguy",
      "indices" : [ 0, 11 ],
      "id_str" : "12304192",
      "id" : 12304192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453160306408042496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8920708757, -78.8729104265 ]
  },
  "id_str" : "453215609338470400",
  "in_reply_to_user_id" : 12304192,
  "text" : "@thenickguy bringing one in? :)",
  "id" : 453215609338470400,
  "in_reply_to_status_id" : 453160306408042496,
  "created_at" : "2014-04-07 16:59:56 +0000",
  "in_reply_to_screen_name" : "thenickguy",
  "in_reply_to_user_id_str" : "12304192",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "TEDxBuffalo",
      "screen_name" : "TEDxBuffalo",
      "indices" : [ 65, 77 ],
      "id_str" : "140515765",
      "id" : 140515765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/3fJEARYvMZ",
      "expanded_url" : "http:\/\/www.tedxbuffalo.com\/speak\/",
      "display_url" : "tedxbuffalo.com\/speak\/"
    } ]
  },
  "geo" : { },
  "id_str" : "453214345196228608",
  "text" : "RT @kevinpurdy: it bears repeating: anyone can apply to speak at @TEDxBuffalo 2014. 2 minutes of looking into a phone\/webcam: http:\/\/t.co\/3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TEDxBuffalo",
        "screen_name" : "TEDxBuffalo",
        "indices" : [ 49, 61 ],
        "id_str" : "140515765",
        "id" : 140515765
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/3fJEARYvMZ",
        "expanded_url" : "http:\/\/www.tedxbuffalo.com\/speak\/",
        "display_url" : "tedxbuffalo.com\/speak\/"
      } ]
    },
    "geo" : { },
    "id_str" : "453214211745656833",
    "text" : "it bears repeating: anyone can apply to speak at @TEDxBuffalo 2014. 2 minutes of looking into a phone\/webcam: http:\/\/t.co\/3fJEARYvMZ",
    "id" : 453214211745656833,
    "created_at" : "2014-04-07 16:54:23 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 453214345196228608,
  "created_at" : "2014-04-07 16:54:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Sterner",
      "screen_name" : "fermion",
      "indices" : [ 0, 8 ],
      "id_str" : "6568582",
      "id" : 6568582
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 9, 13 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453186191504859136",
  "geo" : { },
  "id_str" : "453186310644060160",
  "in_reply_to_user_id" : 6568582,
  "text" : "@fermion @dhh exactly. we're already there! :)",
  "id" : 453186310644060160,
  "in_reply_to_status_id" : 453186191504859136,
  "created_at" : "2014-04-07 15:03:30 +0000",
  "in_reply_to_screen_name" : "fermion",
  "in_reply_to_user_id_str" : "6568582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Sterner",
      "screen_name" : "fermion",
      "indices" : [ 0, 8 ],
      "id_str" : "6568582",
      "id" : 6568582
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 9, 13 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453183127557386240",
  "geo" : { },
  "id_str" : "453185045012807680",
  "in_reply_to_user_id" : 6568582,
  "text" : "@fermion @dhh RM is great, but it's no excuse for not understanding ObjC or the platform. The real magic is the hybrid nav\/HTML combo.",
  "id" : 453185045012807680,
  "in_reply_to_status_id" : 453183127557386240,
  "created_at" : "2014-04-07 14:58:29 +0000",
  "in_reply_to_screen_name" : "fermion",
  "in_reply_to_user_id_str" : "6568582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    }, {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 9, 19 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453159348983054337",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243326141, -78.8791830652 ]
  },
  "id_str" : "453162084130623488",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo @ngauthier NoahRelic is awesome. (Needs a new blog post I think!) \uD83D\uDE01",
  "id" : 453162084130623488,
  "in_reply_to_status_id" : 453159348983054337,
  "created_at" : "2014-04-07 13:27:14 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452800189653585920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924120708, -78.8792360247 ]
  },
  "id_str" : "452817492310646784",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss it also triggers based on time AFAIK",
  "id" : 452817492310646784,
  "in_reply_to_status_id" : 452800189653585920,
  "created_at" : "2014-04-06 14:37:57 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452800189653585920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924120708, -78.8792360247 ]
  },
  "id_str" : "452817302036037632",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss it sure does, because that\u2019s the only way we found to actually get positive reviews regularly. It\u2019s built into Crittercism.",
  "id" : 452817302036037632,
  "in_reply_to_status_id" : 452800189653585920,
  "created_at" : "2014-04-06 14:37:12 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 70, 82 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/dLp7rYFY0J",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=oabcM9SOF-E",
      "display_url" : "m.youtube.com\/watch?v=oabcM9\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0002461364, -78.8221327472 ]
  },
  "id_str" : "452516882982404096",
  "text" : "Sad Charlie Brown music played in my head as I walked away just after @whereslloyd closed up shop on Hertel today. http:\/\/t.co\/dLp7rYFY0J",
  "id" : 452516882982404096,
  "created_at" : "2014-04-05 18:43:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/452483429003976704\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/dxF3lmLDBc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkeLR_uIQAASaKU.jpg",
      "id_str" : "452483428852973568",
      "id" : 452483428852973568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkeLR_uIQAASaKU.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dxF3lmLDBc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9219066485, -78.8818212653 ]
  },
  "id_str" : "452483429003976704",
  "text" : "This looks like a very unique and original logo http:\/\/t.co\/dxF3lmLDBc",
  "id" : 452483429003976704,
  "created_at" : "2014-04-05 16:30:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 3, 11 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/TxZG7Vw04X",
      "expanded_url" : "http:\/\/amazon.com\/b\/?_encoding=UTF8&camp=1789&creative=9325&linkCode=ur2&node=8887135011&pf_rd_i=20&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=1740370942&pf_rd_r=07YVWP4DC9XNYFEBAYVR&pf_rd_s=left-new-1&pf_rd_t=701&smid=ATVPDKIKX0DER&tag=schedule-20",
      "display_url" : "amazon.com\/b\/?_encoding=U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "452467001718759424",
  "text" : "RT @jeresig: A ton of great Amazon board game deals today: http:\/\/t.co\/TxZG7Vw04X Most 40%+ off, including Eclipse and Dominion!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/TxZG7Vw04X",
        "expanded_url" : "http:\/\/amazon.com\/b\/?_encoding=UTF8&camp=1789&creative=9325&linkCode=ur2&node=8887135011&pf_rd_i=20&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=1740370942&pf_rd_r=07YVWP4DC9XNYFEBAYVR&pf_rd_s=left-new-1&pf_rd_t=701&smid=ATVPDKIKX0DER&tag=schedule-20",
        "display_url" : "amazon.com\/b\/?_encoding=U\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "452447953035468800",
    "text" : "A ton of great Amazon board game deals today: http:\/\/t.co\/TxZG7Vw04X Most 40%+ off, including Eclipse and Dominion!",
    "id" : 452447953035468800,
    "created_at" : "2014-04-05 14:09:32 +0000",
    "user" : {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "protected" : false,
      "id_str" : "752673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453551474711097345\/tXmNE9Cj_normal.jpeg",
      "id" : 752673,
      "verified" : true
    }
  },
  "id" : 452467001718759424,
  "created_at" : "2014-04-05 15:25:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452451767272235008",
  "text" : "Advance Wars and Metroid Fusion on WiiU Virtual Console...Nintendo is burning a hole in my wallet.",
  "id" : 452451767272235008,
  "created_at" : "2014-04-05 14:24:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452185854623363072",
  "text" : "RT @dhh: We'll make a point to share the play book we've developed doing the hybrid app approach for Basecamp iOS\/Android soon. Lots of nea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "452185517413527552",
    "text" : "We'll make a point to share the play book we've developed doing the hybrid app approach for Basecamp iOS\/Android soon. Lots of neat tricks.",
    "id" : 452185517413527552,
    "created_at" : "2014-04-04 20:46:43 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 452185854623363072,
  "created_at" : "2014-04-04 20:48:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452185211980488704",
  "text" : "RT @dhh: Modern techniques for creating solid, compelling native-HTML hybrid apps for mobile seem to be the best kept secret in IT atm.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "452183251524657152",
    "text" : "Modern techniques for creating solid, compelling native-HTML hybrid apps for mobile seem to be the best kept secret in IT atm.",
    "id" : 452183251524657152,
    "created_at" : "2014-04-04 20:37:42 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 452185211980488704,
  "created_at" : "2014-04-04 20:45:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/452171188731916288\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/d7FJTWivDz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkZvTOEIMAEC_NU.jpg",
      "id_str" : "452171188580921345",
      "id" : 452171188580921345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkZvTOEIMAEC_NU.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/d7FJTWivDz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9911223427, -78.89529082 ]
  },
  "id_str" : "452171188731916288",
  "text" : "Stuff of nightmares. http:\/\/t.co\/d7FJTWivDz",
  "id" : 452171188731916288,
  "created_at" : "2014-04-04 19:49:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 3, 11 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451924885783080960",
  "text" : "RT @drbrain: MORE ADVENTURE TIME ON NETFLIX\u203C\uFE0F\u203C\uFE0F\u203C\uFE0F\u203C\uFE0F\u203C\uFE0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451924711446818816",
    "text" : "MORE ADVENTURE TIME ON NETFLIX\u203C\uFE0F\u203C\uFE0F\u203C\uFE0F\u203C\uFE0F\u203C\uFE0F",
    "id" : 451924711446818816,
    "created_at" : "2014-04-04 03:30:22 +0000",
    "user" : {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "protected" : false,
      "id_str" : "670283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472446327373053952\/oJXOO4GL_normal.jpeg",
      "id" : 670283,
      "verified" : false
    }
  },
  "id" : 451924885783080960,
  "created_at" : "2014-04-04 03:31:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 0, 8 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451924711446818816",
  "geo" : { },
  "id_str" : "451924863947526145",
  "in_reply_to_user_id" : 670283,
  "text" : "@drbrain oh\n\nmy\n\nglob.",
  "id" : 451924863947526145,
  "in_reply_to_status_id" : 451924711446818816,
  "created_at" : "2014-04-04 03:30:58 +0000",
  "in_reply_to_screen_name" : "drbrain",
  "in_reply_to_user_id_str" : "670283",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/PELWl1sILA",
      "expanded_url" : "https:\/\/appsto.re\/us\/HaoAR.i",
      "display_url" : "appsto.re\/us\/HaoAR.i"
    } ]
  },
  "geo" : { },
  "id_str" : "451918308384964608",
  "text" : "Wow.  https:\/\/t.co\/PELWl1sILA",
  "id" : 451918308384964608,
  "created_at" : "2014-04-04 03:04:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "indices" : [ 0, 15 ],
      "id_str" : "81525784",
      "id" : 81525784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451853599425847296",
  "geo" : { },
  "id_str" : "451853706930028545",
  "in_reply_to_user_id" : 81525784,
  "text" : "@franklinwebber how about trollinators?",
  "id" : 451853706930028545,
  "in_reply_to_status_id" : 451853599425847296,
  "created_at" : "2014-04-03 22:48:13 +0000",
  "in_reply_to_screen_name" : "franklinwebber",
  "in_reply_to_user_id_str" : "81525784",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    }, {
      "name" : "Tobi L\u00FCtke",
      "screen_name" : "tobi",
      "indices" : [ 7, 12 ],
      "id_str" : "676573",
      "id" : 676573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451852243432525824",
  "geo" : { },
  "id_str" : "451852911610322944",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH @tobi oh no it's out!?",
  "id" : 451852911610322944,
  "in_reply_to_status_id" : 451852243432525824,
  "created_at" : "2014-04-03 22:45:03 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Sternbergh",
      "screen_name" : "sternbergh",
      "indices" : [ 3, 14 ],
      "id_str" : "66822783",
      "id" : 66822783
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/urbandata\/status\/450958872883511296\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/urrstFI8YS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkIgtJiIQAAzQ3Q.jpg",
      "id_str" : "450958872715739136",
      "id" : 450958872715739136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkIgtJiIQAAzQ3Q.jpg",
      "sizes" : [ {
        "h" : 256,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/urrstFI8YS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451848565128957952",
  "text" : "RT @sternbergh: After I retweeted this, an American replied \"50 weeks?!?\" and a Canadian replied \"0 weeks?!?\" https:\/\/t.co\/urrstFI8YS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/urbandata\/status\/450958872883511296\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/urrstFI8YS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkIgtJiIQAAzQ3Q.jpg",
        "id_str" : "450958872715739136",
        "id" : 450958872715739136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkIgtJiIQAAzQ3Q.jpg",
        "sizes" : [ {
          "h" : 256,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/urrstFI8YS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451764537247924224",
    "text" : "After I retweeted this, an American replied \"50 weeks?!?\" and a Canadian replied \"0 weeks?!?\" https:\/\/t.co\/urrstFI8YS",
    "id" : 451764537247924224,
    "created_at" : "2014-04-03 16:53:53 +0000",
    "user" : {
      "name" : "Adam Sternbergh",
      "screen_name" : "sternbergh",
      "protected" : false,
      "id_str" : "66822783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560449934323748864\/1ivXLQay_normal.jpeg",
      "id" : 66822783,
      "verified" : false
    }
  },
  "id" : 451848565128957952,
  "created_at" : "2014-04-03 22:27:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03BB Calrissian",
      "screen_name" : "mattpodwysocki",
      "indices" : [ 0, 15 ],
      "id_str" : "12699642",
      "id" : 12699642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451846422686883840",
  "geo" : { },
  "id_str" : "451847045758738432",
  "in_reply_to_user_id" : 12699642,
  "text" : "@mattpodwysocki I've been out of the MS radar for a while...what? I thought Iron* died long ago.",
  "id" : 451847045758738432,
  "in_reply_to_status_id" : 451846422686883840,
  "created_at" : "2014-04-03 22:21:45 +0000",
  "in_reply_to_screen_name" : "mattpodwysocki",
  "in_reply_to_user_id_str" : "12699642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03BB Calrissian",
      "screen_name" : "mattpodwysocki",
      "indices" : [ 0, 15 ],
      "id_str" : "12699642",
      "id" : 12699642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451845478142193664",
  "geo" : { },
  "id_str" : "451845693838065665",
  "in_reply_to_user_id" : 12699642,
  "text" : "@mattpodwysocki Honestly, most people who would have cared, moved on long ago.",
  "id" : 451845693838065665,
  "in_reply_to_status_id" : 451845478142193664,
  "created_at" : "2014-04-03 22:16:22 +0000",
  "in_reply_to_screen_name" : "mattpodwysocki",
  "in_reply_to_user_id_str" : "12699642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M Magnuson",
      "screen_name" : "m_magnuson",
      "indices" : [ 0, 11 ],
      "id_str" : "355041948",
      "id" : 355041948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451841755911294977",
  "geo" : { },
  "id_str" : "451843255349436417",
  "in_reply_to_user_id" : 355041948,
  "text" : "@m_magnuson i've had that before too. Putzed around for a half hour. Didn't expect New Orleans\/Southern style rules in an airport though!",
  "id" : 451843255349436417,
  "in_reply_to_status_id" : 451841755911294977,
  "created_at" : "2014-04-03 22:06:41 +0000",
  "in_reply_to_screen_name" : "m_magnuson",
  "in_reply_to_user_id_str" : "355041948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451835088301346816",
  "text" : "Dealing with ORD just got better: you can get to-go beers from vendors and walk around the airport with it.",
  "id" : 451835088301346816,
  "created_at" : "2014-04-03 21:34:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451739624063258624",
  "geo" : { },
  "id_str" : "451752466040619008",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines Creepy.",
  "id" : 451752466040619008,
  "in_reply_to_status_id" : 451739624063258624,
  "created_at" : "2014-04-03 16:05:55 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie",
      "screen_name" : "ntljk",
      "indices" : [ 3, 9 ],
      "id_str" : "21778760",
      "id" : 21778760
    }, {
      "name" : "Wailin Wong",
      "screen_name" : "VelocityWong",
      "indices" : [ 130, 140 ],
      "id_str" : "15222743",
      "id" : 15222743
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 139, 140 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451745825287585792",
  "text" : "RT @ntljk: \"feminist taco blog\" - pics of tacos with \"check your privilege\" under each taco. Workshopping ideas with @wilderemily @Velocity\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wailin Wong",
        "screen_name" : "VelocityWong",
        "indices" : [ 119, 132 ],
        "id_str" : "15222743",
        "id" : 15222743
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 133, 139 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451726478460219393",
    "text" : "\"feminist taco blog\" - pics of tacos with \"check your privilege\" under each taco. Workshopping ideas with @wilderemily @VelocityWong @qrush",
    "id" : 451726478460219393,
    "created_at" : "2014-04-03 14:22:39 +0000",
    "user" : {
      "name" : "Natalie",
      "screen_name" : "ntljk",
      "protected" : false,
      "id_str" : "21778760",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565071117442752512\/O3tZFvH8_normal.png",
      "id" : 21778760,
      "verified" : false
    }
  },
  "id" : 451745825287585792,
  "created_at" : "2014-04-03 15:39:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 48, 54 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451509065345024000",
  "text" : "It\u2019s been an honor and a privilege working with @jamis these past few years. Good luck on your next adventure!",
  "id" : 451509065345024000,
  "created_at" : "2014-04-02 23:58:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451317898267852800",
  "geo" : { },
  "id_str" : "451404162967019520",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy of course, I've missed you again. Next time?",
  "id" : 451404162967019520,
  "in_reply_to_status_id" : 451317898267852800,
  "created_at" : "2014-04-02 17:01:53 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Souperman",
      "screen_name" : "Buffalucci",
      "indices" : [ 0, 11 ],
      "id_str" : "16256129",
      "id" : 16256129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451355153351081985",
  "geo" : { },
  "id_str" : "451404067391410176",
  "in_reply_to_user_id" : 16256129,
  "text" : "@Buffalucci awesome. Welcome!",
  "id" : 451404067391410176,
  "in_reply_to_status_id" : 451355153351081985,
  "created_at" : "2014-04-02 17:01:31 +0000",
  "in_reply_to_screen_name" : "Buffalucci",
  "in_reply_to_user_id_str" : "16256129",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cooper Daigle",
      "screen_name" : "cooperdaigle",
      "indices" : [ 0, 13 ],
      "id_str" : "2240858239",
      "id" : 2240858239
    }, {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 14, 22 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451347250812551168",
  "geo" : { },
  "id_str" : "451347750722875392",
  "in_reply_to_user_id" : 2240858239,
  "text" : "@cooperdaigle @kdaigle not a joke! congrats and welcome!",
  "id" : 451347750722875392,
  "in_reply_to_status_id" : 451347250812551168,
  "created_at" : "2014-04-02 13:17:44 +0000",
  "in_reply_to_screen_name" : "cooperdaigle",
  "in_reply_to_user_id_str" : "2240858239",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/JNSE3sXo6k",
      "expanded_url" : "https:\/\/ifttt.com\/p\/qrush#shared",
      "display_url" : "ifttt.com\/p\/qrush#shared"
    } ]
  },
  "geo" : { },
  "id_str" : "451336778323329024",
  "text" : "I love having this stuff automated. Baseball scores, GIF vacuuming, weather alerting. More soon, hopefully. https:\/\/t.co\/JNSE3sXo6k",
  "id" : 451336778323329024,
  "created_at" : "2014-04-02 12:34:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Sxply03F0P",
      "expanded_url" : "http:\/\/i.imgur.com\/rdi3rZj.png",
      "display_url" : "i.imgur.com\/rdi3rZj.png"
    }, {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/Vcko2Fguz2",
      "expanded_url" : "https:\/\/ifttt.com\/recipes\/158143-share-final-baseball-scores-in-campfire",
      "display_url" : "ifttt.com\/recipes\/158143\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "451333945917837312",
  "text" : "Push final baseball scores into Campfire: http:\/\/t.co\/Sxply03F0P via: https:\/\/t.co\/Vcko2Fguz2",
  "id" : 451333945917837312,
  "created_at" : "2014-04-02 12:22:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 50, 57 ],
      "id_str" : "14432203",
      "id" : 14432203
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/451111334403244032\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/JzTwqXEdHV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkKrXkVCcAANqTt.jpg",
      "id_str" : "451111334067728384",
      "id" : 451111334067728384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkKrXkVCcAANqTt.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/JzTwqXEdHV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451111334403244032",
  "text" : "First person ping pong ball retrieval courtesy of @will_j http:\/\/t.co\/JzTwqXEdHV",
  "id" : 451111334403244032,
  "created_at" : "2014-04-01 21:38:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M Magnuson",
      "screen_name" : "m_magnuson",
      "indices" : [ 3, 14 ],
      "id_str" : "355041948",
      "id" : 355041948
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/m_magnuson\/status\/450950145723887616\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/XEXQntRBx2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkIYxKHIIAAEaRC.jpg",
      "id_str" : "450950145497374720",
      "id" : 450950145497374720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkIYxKHIIAAEaRC.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XEXQntRBx2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451105652039876608",
  "text" : "RT @m_magnuson: I shut down chem rooms in school today because of a dihydrogen monoxide spill. http:\/\/t.co\/XEXQntRBx2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.handmark.com\" rel=\"nofollow\"\u003ETweetCaster for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/m_magnuson\/status\/450950145723887616\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/XEXQntRBx2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkIYxKHIIAAEaRC.jpg",
        "id_str" : "450950145497374720",
        "id" : 450950145497374720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkIYxKHIIAAEaRC.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 764
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 764
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 804,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/XEXQntRBx2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "450950145723887616",
    "text" : "I shut down chem rooms in school today because of a dihydrogen monoxide spill. http:\/\/t.co\/XEXQntRBx2",
    "id" : 450950145723887616,
    "created_at" : "2014-04-01 10:57:47 +0000",
    "user" : {
      "name" : "M Magnuson",
      "screen_name" : "m_magnuson",
      "protected" : false,
      "id_str" : "355041948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535761199682445312\/qNPEiNXy_normal.jpeg",
      "id" : 355041948,
      "verified" : false
    }
  },
  "id" : 451105652039876608,
  "created_at" : "2014-04-01 21:15:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451103668058615808",
  "geo" : { },
  "id_str" : "451103897117933569",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove bcuz leet haxxors do",
  "id" : 451103897117933569,
  "in_reply_to_status_id" : 451103668058615808,
  "created_at" : "2014-04-01 21:08:44 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451082134585749504",
  "text" : "Why hasn't anyone figured out how to mine cryptocurrency in JS? Drop it on a page for a high-traffic game, generate $LOLBUX",
  "id" : 451082134585749504,
  "created_at" : "2014-04-01 19:42:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 36, 44 ],
      "id_str" : "807095",
      "id" : 807095
    }, {
      "name" : "Netflix US",
      "screen_name" : "netflix",
      "indices" : [ 86, 94 ],
      "id_str" : "16573941",
      "id" : 16573941
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/37signals\/status\/451076728379555840\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/OS6ZDGqxTR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkKL5PWCUAAMp7u.jpg",
      "id_str" : "451076728178233344",
      "id" : 451076728178233344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkKL5PWCUAAMp7u.jpg",
      "sizes" : [ {
        "h" : 459,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 810,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1297,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 1297,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/OS6ZDGqxTR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/upKyvSrXbJ",
      "expanded_url" : "http:\/\/signalvnoise.com\/posts\/3732-another-chapter",
      "display_url" : "signalvnoise.com\/posts\/3732-ano\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "451080960776224768",
  "text" : "RT @37signals: Another Chapter: Our @nytimes bestselling book REWORK is going to be a @netflix Original. http:\/\/t.co\/upKyvSrXbJ http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 21, 29 ],
        "id_str" : "807095",
        "id" : 807095
      }, {
        "name" : "Netflix US",
        "screen_name" : "netflix",
        "indices" : [ 71, 79 ],
        "id_str" : "16573941",
        "id" : 16573941
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/37signals\/status\/451076728379555840\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/OS6ZDGqxTR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkKL5PWCUAAMp7u.jpg",
        "id_str" : "451076728178233344",
        "id" : 451076728178233344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkKL5PWCUAAMp7u.jpg",
        "sizes" : [ {
          "h" : 459,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 810,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1297,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 1297,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/OS6ZDGqxTR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/upKyvSrXbJ",
        "expanded_url" : "http:\/\/signalvnoise.com\/posts\/3732-another-chapter",
        "display_url" : "signalvnoise.com\/posts\/3732-ano\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "451076728379555840",
    "text" : "Another Chapter: Our @nytimes bestselling book REWORK is going to be a @netflix Original. http:\/\/t.co\/upKyvSrXbJ http:\/\/t.co\/OS6ZDGqxTR",
    "id" : 451076728379555840,
    "created_at" : "2014-04-01 19:20:47 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 451080960776224768,
  "created_at" : "2014-04-01 19:37:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/451022188368252928\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/J8qZ5m5eUk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkJaSmwCUAARX1Z.png",
      "id_str" : "451022188376641536",
      "id" : 451022188376641536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkJaSmwCUAARX1Z.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1030,
        "resize" : "fit",
        "w" : 1674
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/J8qZ5m5eUk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451022188368252928",
  "text" : "Windows 98 strongbad theme is actually a working theme (with timestamps from 2001!) http:\/\/t.co\/J8qZ5m5eUk",
  "id" : 451022188368252928,
  "created_at" : "2014-04-01 15:44:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/JtEN4JXuf6",
      "expanded_url" : "http:\/\/www.homestarrunner.com\/",
      "display_url" : "homestarrunner.com"
    } ]
  },
  "geo" : { },
  "id_str" : "451021701677993984",
  "text" : "Where can I kickstart more new episodes of Homestar? Also, new episode (and Flash animation is still a thing):  http:\/\/t.co\/JtEN4JXuf6",
  "id" : 451021701677993984,
  "created_at" : "2014-04-01 15:42:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451011655506595840",
  "text" : "error: src refspec msater does not match any.",
  "id" : 451011655506595840,
  "created_at" : "2014-04-01 15:02:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/451009806757683201\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/GFqWv3isGR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkJPB4fCEAAk8vE.png",
      "id_str" : "451009806451478528",
      "id" : 451009806451478528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkJPB4fCEAAk8vE.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GFqWv3isGR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451009806757683201",
  "text" : "A good choice for Niagara Falls http:\/\/t.co\/GFqWv3isGR",
  "id" : 451009806757683201,
  "created_at" : "2014-04-01 14:54:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/xTn7zLlHa9",
      "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/shouts\/2014\/03\/libertarian-police-department.html",
      "display_url" : "newyorker.com\/online\/blogs\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "451005920940920832",
  "text" : "\u201CSubway\u2122 Eat Fresh and Freeze, Scumbag!\u00AE\u201D I yelled.   http:\/\/t.co\/xTn7zLlHa9",
  "id" : 451005920940920832,
  "created_at" : "2014-04-01 14:39:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 3, 15 ],
      "id_str" : "16454301",
      "id" : 16454301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/zJJ8mIKh8q",
      "expanded_url" : "https:\/\/signalvnoise.com\/posts\/3731-basecamp-goes-back-to-basics",
      "display_url" : "signalvnoise.com\/posts\/3731-bas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "451001739249201153",
  "text" : "RT @jonasdowney: Basecamp goes back to basics: https:\/\/t.co\/zJJ8mIKh8q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/zJJ8mIKh8q",
        "expanded_url" : "https:\/\/signalvnoise.com\/posts\/3731-basecamp-goes-back-to-basics",
        "display_url" : "signalvnoise.com\/posts\/3731-bas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "451001601982210048",
    "text" : "Basecamp goes back to basics: https:\/\/t.co\/zJJ8mIKh8q",
    "id" : 451001601982210048,
    "created_at" : "2014-04-01 14:22:15 +0000",
    "user" : {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "protected" : false,
      "id_str" : "16454301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000153090409\/f136c60eca258e42e43b2d1760196833_normal.jpeg",
      "id" : 16454301,
      "verified" : false
    }
  },
  "id" : 451001739249201153,
  "created_at" : "2014-04-01 14:22:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 9, 19 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/450983354871992320\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/vfGuHj3r7v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkI2-L0CMAAQDhi.jpg",
      "id_str" : "450983354641297408",
      "id" : 450983354641297408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkI2-L0CMAAQDhi.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/vfGuHj3r7v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450983354871992320",
  "text" : "From the @37signals office and my message to the internet today: http:\/\/t.co\/vfGuHj3r7v",
  "id" : 450983354871992320,
  "created_at" : "2014-04-01 13:09:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
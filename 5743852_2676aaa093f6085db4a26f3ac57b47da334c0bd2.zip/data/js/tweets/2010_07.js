Grailbird.data.tweets_2010_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bil Simser",
      "screen_name" : "bsimser",
      "indices" : [ 0, 8 ],
      "id_str" : "11273572",
      "id" : 11273572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20066122683",
  "geo" : { },
  "id_str" : "20067373626",
  "in_reply_to_user_id" : 11273572,
  "text" : "@bsimser not that i'm aware of. post your gemspec on http:\/\/help.rubygems.org and we'll figure it out",
  "id" : 20067373626,
  "in_reply_to_status_id" : 20066122683,
  "created_at" : "2010-08-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "bsimser",
  "in_reply_to_user_id_str" : "11273572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20082244295",
  "text" : "http:\/\/rubyconf.org GOGOGOGO",
  "id" : 20082244295,
  "created_at" : "2010-08-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19961975856",
  "text" : "Starting to not bother signing up for sites where I can't get my normal username. Not worth it.",
  "id" : 19961975856,
  "created_at" : "2010-07-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19969904128",
  "text" : "http:\/\/scottmeetsfamilycircus.tumblr.com\/",
  "id" : 19969904128,
  "created_at" : "2010-07-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20024316852",
  "text" : "Current status: http:\/\/twitpic.com\/2ahn5w",
  "id" : 20024316852,
  "created_at" : "2010-07-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19795999552",
  "text" : "I'm glad Yegge's back and killing it. Need more bloggers like this. http:\/\/is.gd\/dPX5g",
  "id" : 19795999552,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19796688143",
  "text" : "The only reason I might use Bing Maps. (If this ever gets released). http:\/\/is.gd\/dPXXI",
  "id" : 19796688143,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19797336871",
  "text" : "My kind of commit: 18 files changed, 105 insertions(+), 351 deletions(-)",
  "id" : 19797336871,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BradfordW",
      "screen_name" : "bradfordw",
      "indices" : [ 0, 10 ],
      "id_str" : "14640131",
      "id" : 14640131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19746097699",
  "geo" : { },
  "id_str" : "19797418083",
  "in_reply_to_user_id" : 14640131,
  "text" : "@bradfordw For what URL? Not seeing anything in particular.",
  "id" : 19797418083,
  "in_reply_to_status_id" : 19746097699,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "bradfordw",
  "in_reply_to_user_id_str" : "14640131",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19718006584",
  "geo" : { },
  "id_str" : "19798222896",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg so kind of like a dry run for `gem update` ? hit me on irc.",
  "id" : 19798222896,
  "in_reply_to_status_id" : 19718006584,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19799516772",
  "geo" : { },
  "id_str" : "19799779121",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek WE DIDN'T LISTEN!!!!",
  "id" : 19799779121,
  "in_reply_to_status_id" : 19799516772,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BradfordW",
      "screen_name" : "bradfordw",
      "indices" : [ 0, 10 ],
      "id_str" : "14640131",
      "id" : 14640131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19828627163",
  "geo" : { },
  "id_str" : "19841118436",
  "in_reply_to_user_id" : 14640131,
  "text" : "@bradfordw can you clear your cookies\/cache?",
  "id" : 19841118436,
  "in_reply_to_status_id" : 19828627163,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "bradfordw",
  "in_reply_to_user_id_str" : "14640131",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mogotest",
      "screen_name" : "mogotest",
      "indices" : [ 5, 14 ],
      "id_str" : "96202157",
      "id" : 96202157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19848153310",
  "text" : "Yep, @mogotest is fucking cool: https:\/\/mogotest.com\/sites\/rubygems-org\/groups\/wrevha\/tests\/n1\/documents\/385867",
  "id" : 19848153310,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19848498455",
  "text" : "CORRECTION: Mogotest is fucking cool. http:\/\/img.skitch.com\/20100729-mahc8t49q275jibkijr4cbcbcj.jpg",
  "id" : 19848498455,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19861666609",
  "text" : "Starting to fill in for nosqlsummer...and filling up with pizza.",
  "id" : 19861666609,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19709940594",
  "text" : "One way to get nothing done: queue up Doctor Who on Netflix.",
  "id" : 19709940594,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19748773446",
  "text" : "Hey construction guy smoking while spreading http:\/\/en.wikipedia.org\/wiki\/Xylene around, that's really cool.",
  "id" : 19748773446,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobi L\u00FCtke",
      "screen_name" : "tobi",
      "indices" : [ 0, 5 ],
      "id_str" : "676573",
      "id" : 676573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19623308355",
  "geo" : { },
  "id_str" : "19627520789",
  "in_reply_to_user_id" : 676573,
  "text" : "@tobi I really have been enjoying Go. My main problem: not sure what real world thing to write with it.",
  "id" : 19627520789,
  "in_reply_to_status_id" : 19623308355,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "tobi",
  "in_reply_to_user_id_str" : "676573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19667867940",
  "text" : "Who says you need starcraft 2? http:\/\/twitpic.com\/296j0d",
  "id" : 19667867940,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19687284784",
  "text" : "wtf happened to http:\/\/twictur.es\/ ?",
  "id" : 19687284784,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19694983392",
  "geo" : { },
  "id_str" : "19695894637",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton lol 2.99 and over 100 megs...wtf is in there?",
  "id" : 19695894637,
  "in_reply_to_status_id" : 19694983392,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19572899810",
  "text" : "Girl on the train is reading Twilight fanfiction. Better or worse than a smelly hobo standing next to you?",
  "id" : 19572899810,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19589661588",
  "text" : "Loving the styleguide. http:\/\/robots.thoughtbot.com\/post\/762048192\/flutie",
  "id" : 19589661588,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19610752717",
  "text" : "bundle viz is pretty sweet: http:\/\/img.skitch.com\/20100726-rdn5fwiskkpgemr7r6tqqcdpjx.jpg",
  "id" : 19610752717,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19468171878",
  "text" : "New way to teach recursion to CS kids: watch Inception.",
  "id" : 19468171878,
  "created_at" : "2010-07-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19437365561",
  "text" : "INTERNETS!!!",
  "id" : 19437365561,
  "created_at" : "2010-07-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19438771555",
  "text" : "Video: KEYBOARD RON http:\/\/tumblr.com\/x17e458fc",
  "id" : 19438771555,
  "created_at" : "2010-07-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19216942647",
  "text" : "Warmer in my apartment than outside. Sadface.",
  "id" : 19216942647,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19225543431",
  "text" : "% ruby -Itest test\/unit\/cutter_test.rb\n\"OH WTF\"\n#&lt;G\u240A\u2514::P\u2592\u240C\u2510\u2592\u00B1\u240A::F\u23BA\u23BC\u2514\u2592\u251CE\u23BC\u23BC\u23BA\u23BC: N\u23BA \u2514\u240A\u251C\u2592\u240D\u2592\u251C\u2592 \u00B0\u23BA\u2524\u253C\u240D!&gt;\n\n...it's time for bed.",
  "id" : 19225543431,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Kern",
      "screen_name" : "lightcap",
      "indices" : [ 0, 9 ],
      "id_str" : "667803",
      "id" : 667803
    }, {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 10, 13 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19287002211",
  "geo" : { },
  "id_str" : "19287997496",
  "in_reply_to_user_id" : 667803,
  "text" : "@lightcap @jm starting think about how much having gem subdomains matter when bundler makes specifying a git repo so easy",
  "id" : 19287997496,
  "in_reply_to_status_id" : 19287002211,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "lightcap",
  "in_reply_to_user_id_str" : "667803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Bohlen",
      "screen_name" : "sbohlen",
      "indices" : [ 0, 8 ],
      "id_str" : "18153336",
      "id" : 18153336
    }, {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 9, 22 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19334161071",
  "geo" : { },
  "id_str" : "19336199291",
  "in_reply_to_user_id" : 9645312,
  "text" : "@sbohlen @ferventcoder sure, without documentation it is. At least in Rails that's covered.",
  "id" : 19336199291,
  "in_reply_to_status_id" : 19334161071,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "ferventcoder",
  "in_reply_to_user_id_str" : "9645312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eaton",
      "screen_name" : "mjeaton",
      "indices" : [ 0, 8 ],
      "id_str" : "6440892",
      "id" : 6440892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19344676827",
  "geo" : { },
  "id_str" : "19344892820",
  "in_reply_to_user_id" : 6440892,
  "text" : "@mjeaton BOOOOOOOOO",
  "id" : 19344892820,
  "in_reply_to_status_id" : 19344676827,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mjeaton",
  "in_reply_to_user_id_str" : "6440892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19343487858",
  "geo" : { },
  "id_str" : "19344961342",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl how about \"TATFT Soup for the Soul\" instead",
  "id" : 19344961342,
  "in_reply_to_status_id" : 19343487858,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 6, 16 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19366067898",
  "text" : "BOOM! @gemcutter (http:\/\/rubygems.org) now running on Rails 3. What's your excuse now?",
  "id" : 19366067898,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaroslav Markin",
      "screen_name" : "yaroslav",
      "indices" : [ 0, 9 ],
      "id_str" : "7605802",
      "id" : 7605802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19367233421",
  "geo" : { },
  "id_str" : "19367320503",
  "in_reply_to_user_id" : 7605802,
  "text" : "@yaroslav REE 2010.02. Patches welcome if you want to get it working on 1.9 :)",
  "id" : 19367320503,
  "in_reply_to_status_id" : 19367233421,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "yaroslav",
  "in_reply_to_user_id_str" : "7605802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19370785906",
  "text" : "\"You'll play through 20-25 minutes of Rush...\" YESSSSS http:\/\/is.gd\/dDPej",
  "id" : 19370785906,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 37, 47 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19042567337",
  "text" : "FUCK YEAH. Full green test suite for @gemcutter on Rails 3.",
  "id" : 19042567337,
  "created_at" : "2010-07-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19053056491",
  "text" : "The new router DSL is so clean. Takes a bit to get used to, but worth it. http:\/\/is.gd\/dAhNr",
  "id" : 19053056491,
  "created_at" : "2010-07-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Sharp",
      "screen_name" : "ajsharp",
      "indices" : [ 0, 8 ],
      "id_str" : "18071073",
      "id" : 18071073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18953162498",
  "geo" : { },
  "id_str" : "18956727550",
  "in_reply_to_user_id" : 18071073,
  "text" : "@ajsharp help.hoptoadapp.com",
  "id" : 18956727550,
  "in_reply_to_status_id" : 18953162498,
  "created_at" : "2010-07-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ajsharp",
  "in_reply_to_user_id_str" : "18071073",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "redis",
      "indices" : [ 75, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18958379712",
  "text" : "Ok, I think WATCH + MULTI\/EXEC finally just clicked in my head. Hell yeah. #redis",
  "id" : 18958379712,
  "created_at" : "2010-07-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 34, 44 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18967941235",
  "text" : "Getting closer to a green rails 3 @gemcutter...hard to avoid refactoring when so many new shortcuts\/idioms are cleaner",
  "id" : 18967941235,
  "created_at" : "2010-07-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 0, 13 ],
      "id_str" : "9645312",
      "id" : 9645312
    }, {
      "name" : "Steve Bohlen",
      "screen_name" : "sbohlen",
      "indices" : [ 14, 22 ],
      "id_str" : "18153336",
      "id" : 18153336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18993757929",
  "geo" : { },
  "id_str" : "18995184215",
  "in_reply_to_user_id" : 9645312,
  "text" : "@ferventcoder @sbohlen maybe it should be a specific platform instead, then the .net\/ruby version could live in the same namespace",
  "id" : 18995184215,
  "in_reply_to_status_id" : 18993757929,
  "created_at" : "2010-07-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ferventcoder",
  "in_reply_to_user_id_str" : "9645312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    }, {
      "name" : "Alex McHale",
      "screen_name" : "alexmchale",
      "indices" : [ 54, 65 ],
      "id_str" : "13964832",
      "id" : 13964832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18876017437",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen yo dawg I herd you like oauth so I found @alexmchale so you can authenticate while you authenticate",
  "id" : 18876017437,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Delta",
      "screen_name" : "Delta",
      "indices" : [ 86, 92 ],
      "id_str" : "5920532",
      "id" : 5920532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18877128072",
  "text" : "Stuck on the tarmac for 30 minutes now at ATL after an already delayed flight, thanks @Delta. Most likely missing the flight back to BOS.",
  "id" : 18877128072,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18911135141",
  "text" : "From a real blog post comment: \"I don't do unit testing because I prefer to code intelligently.\"",
  "id" : 18911135141,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18950430407",
  "text" : "Redis' EXPIRE semantics have yet again confused and boggled me. It should spit out warnings when you modify expiring keys.",
  "id" : 18950430407,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubymidwest",
      "indices" : [ 55, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18847932407",
  "text" : "Ended up at the Roasterie, if anyone is left over from #rubymidwest come on down!",
  "id" : 18847932407,
  "created_at" : "2010-07-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18850614276",
  "text" : "\"DEPRECATION WARNING: save(false) is deprecated\" YAY! ...\"please give save(:validate =&gt; false) instead\" awwww.",
  "id" : 18850614276,
  "created_at" : "2010-07-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18863652783",
  "text" : "Flight out of MCI delayed. Boo.",
  "id" : 18863652783,
  "created_at" : "2010-07-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 0, 12 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18865652160",
  "geo" : { },
  "id_str" : "18865708137",
  "in_reply_to_user_id" : 5716862,
  "text" : "@tristandunn you win, delayed from 10pm to 12:10am. :[",
  "id" : 18865708137,
  "in_reply_to_status_id" : 18865652160,
  "created_at" : "2010-07-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "tristandunn",
  "in_reply_to_user_id_str" : "5716862",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 23, 33 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18865955295",
  "text" : "Unit tests passing for @gemcutter on Rails 3! Functionals and cuke suite next...",
  "id" : 18865955295,
  "created_at" : "2010-07-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18870788972",
  "text" : "New summer blockbuster: GEMS ON A PLANE",
  "id" : 18870788972,
  "created_at" : "2010-07-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u043C\u044B Gray",
      "screen_name" : "melgray",
      "indices" : [ 0, 8 ],
      "id_str" : "8344942",
      "id" : 8344942
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 17, 25 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18746243987",
  "geo" : { },
  "id_str" : "18764004423",
  "in_reply_to_user_id" : 8344942,
  "text" : "@melgray I think @jayunit got it somewhere off istockphoto",
  "id" : 18764004423,
  "in_reply_to_status_id" : 18746243987,
  "created_at" : "2010-07-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "melgray",
  "in_reply_to_user_id_str" : "8344942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18764062822",
  "text" : "The Chrome default starting page does not react well to font size increasing.",
  "id" : 18764062822,
  "created_at" : "2010-07-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18768688303",
  "text" : "So it begins.... using gems with .NET: http:\/\/is.gd\/dvLyO",
  "id" : 18768688303,
  "created_at" : "2010-07-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 6, 13 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18782678570",
  "text" : "Woot! @jyurek's patch to fix some wacky integration test behavior in 2.3 with multipart forms got merged. http:\/\/is.gd\/dvYcb",
  "id" : 18782678570,
  "created_at" : "2010-07-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 0, 13 ],
      "id_str" : "9645312",
      "id" : 9645312
    }, {
      "name" : "Will Green",
      "screen_name" : "hotgazpacho",
      "indices" : [ 14, 26 ],
      "id_str" : "10687942",
      "id" : 10687942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18702804253",
  "geo" : { },
  "id_str" : "18784067623",
  "in_reply_to_user_id" : 9645312,
  "text" : "@ferventcoder @hotgazpacho starting to think it would benefit you guys to run your own gemcutter for .net stuff. hit me on email about this.",
  "id" : 18784067623,
  "in_reply_to_status_id" : 18702804253,
  "created_at" : "2010-07-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ferventcoder",
  "in_reply_to_user_id_str" : "9645312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 0, 13 ],
      "id_str" : "9645312",
      "id" : 9645312
    }, {
      "name" : "Will Green",
      "screen_name" : "hotgazpacho",
      "indices" : [ 14, 26 ],
      "id_str" : "10687942",
      "id" : 10687942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18784130221",
  "in_reply_to_user_id" : 9645312,
  "text" : "@ferventcoder @hotgazpacho mostly that you could focus design\/copy towards that community instead of ours. http:\/\/is.gd\/dvZLS",
  "id" : 18784130221,
  "created_at" : "2010-07-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ferventcoder",
  "in_reply_to_user_id_str" : "9645312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03BB Calrissian",
      "screen_name" : "mattpodwysocki",
      "indices" : [ 0, 15 ],
      "id_str" : "12699642",
      "id" : 12699642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18774710490",
  "geo" : { },
  "id_str" : "18784260774",
  "in_reply_to_user_id" : 12699642,
  "text" : "@mattpodwysocki right. a few won't hurt, but it would make more sense to start a separate site that runs the gemcutter codebase longer term",
  "id" : 18784260774,
  "in_reply_to_status_id" : 18774710490,
  "created_at" : "2010-07-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "mattpodwysocki",
  "in_reply_to_user_id_str" : "12699642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubymidwest",
      "indices" : [ 9, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18785502358",
  "text" : "Day 2 of #rubymidwest is going swell, plenty of hacking to be found. Anyone up for the Royals game?",
  "id" : 18785502358,
  "created_at" : "2010-07-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pelaez T.",
      "screen_name" : "davidpelaez",
      "indices" : [ 0, 12 ],
      "id_str" : "15303686",
      "id" : 15303686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18792668301",
  "geo" : { },
  "id_str" : "18793656869",
  "in_reply_to_user_id" : 15303686,
  "text" : "@davidpelaez open up a request on http:\/\/help.rubygems.org, we'll get it sorted out",
  "id" : 18793656869,
  "in_reply_to_status_id" : 18792668301,
  "created_at" : "2010-07-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "davidpelaez",
  "in_reply_to_user_id_str" : "15303686",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubymidwest",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18797600498",
  "text" : "Way too hot out. #rubymidwest was good times!",
  "id" : 18797600498,
  "created_at" : "2010-07-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18642740938",
  "text" : "Ridiculous best buy vending machine. You can order a DSi! http:\/\/twitpic.com\/25mm71",
  "id" : 18642740938,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Bleigh",
      "screen_name" : "mbleigh",
      "indices" : [ 37, 45 ],
      "id_str" : "12025282",
      "id" : 12025282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18651342243",
  "text" : "Can I get some OMGWTFBBQ today? Cmon @mbleigh make it happen.",
  "id" : 18651342243,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubymidwest",
      "indices" : [ 11, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18687393656",
  "text" : "Arrived at #rubymidwest. Say hi to the guy in the robot shirt.",
  "id" : 18687393656,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "indices" : [ 0, 8 ],
      "id_str" : "713263",
      "id" : 713263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18694665418",
  "geo" : { },
  "id_str" : "18695158564",
  "in_reply_to_user_id" : 713263,
  "text" : "@defunkt there's a SIMBL plugin called megazoomer that can do that.",
  "id" : 18695158564,
  "in_reply_to_status_id" : 18694665418,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "defunkt",
  "in_reply_to_user_id_str" : "713263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Green",
      "screen_name" : "hotgazpacho",
      "indices" : [ 0, 12 ],
      "id_str" : "10687942",
      "id" : 10687942
    }, {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 13, 26 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18695916753",
  "geo" : { },
  "id_str" : "18696859281",
  "in_reply_to_user_id" : 10687942,
  "text" : "@hotgazpacho @ferventcoder just imagine the chicks you'll get for ending DLL hell.",
  "id" : 18696859281,
  "in_reply_to_status_id" : 18695916753,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "hotgazpacho",
  "in_reply_to_user_id_str" : "10687942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Curious Mind",
      "screen_name" : "drusellers",
      "indices" : [ 0, 11 ],
      "id_str" : "9238852",
      "id" : 9238852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18695874860",
  "geo" : { },
  "id_str" : "18696932934",
  "in_reply_to_user_id" : 9238852,
  "text" : "@drusellers you can install built gems locally. rubygems.org just makes it easier for OSS projects. lots of places run internal servers.",
  "id" : 18696932934,
  "in_reply_to_status_id" : 18695874860,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "drusellers",
  "in_reply_to_user_id_str" : "9238852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Curious Mind",
      "screen_name" : "drusellers",
      "indices" : [ 0, 11 ],
      "id_str" : "9238852",
      "id" : 9238852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18695874860",
  "geo" : { },
  "id_str" : "18697004248",
  "in_reply_to_user_id" : 9238852,
  "text" : "@drusellers gem build whatever.gemspec; gem install whatever-0.0.0.gem",
  "id" : 18697004248,
  "in_reply_to_status_id" : 18695874860,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "drusellers",
  "in_reply_to_user_id_str" : "9238852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 0, 13 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18697200529",
  "geo" : { },
  "id_str" : "18697345972",
  "in_reply_to_user_id" : 9645312,
  "text" : "@ferventcoder yeah that's a bug i've been meaning to fix. for now, crack open a request at http:\/\/help.rubygems.org",
  "id" : 18697345972,
  "in_reply_to_status_id" : 18697200529,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ferventcoder",
  "in_reply_to_user_id_str" : "9645312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 0, 13 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18697662140",
  "geo" : { },
  "id_str" : "18698097287",
  "in_reply_to_user_id" : 9645312,
  "text" : "@ferventcoder that's by design, so mirrors don't get out of sync and versioning stays sane a la http:\/\/semver.org",
  "id" : 18698097287,
  "in_reply_to_status_id" : 18697662140,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ferventcoder",
  "in_reply_to_user_id_str" : "9645312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 0, 13 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18698205604",
  "geo" : { },
  "id_str" : "18698449933",
  "in_reply_to_user_id" : 9645312,
  "text" : "@ferventcoder you're not going to run out of version numbers, there's a lot of them :) feel free to ping me in IRC or email, &gt; 140 chars",
  "id" : 18698449933,
  "in_reply_to_status_id" : 18698205604,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ferventcoder",
  "in_reply_to_user_id_str" : "9645312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Green",
      "screen_name" : "hotgazpacho",
      "indices" : [ 0, 12 ],
      "id_str" : "10687942",
      "id" : 10687942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18707055348",
  "geo" : { },
  "id_str" : "18707703461",
  "in_reply_to_user_id" : 10687942,
  "text" : "@hotgazpacho yeah, I tend to recommend http:\/\/github.com\/cwninja\/geminabox unless if you're sharing 1000's of gems",
  "id" : 18707703461,
  "in_reply_to_status_id" : 18707055348,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "hotgazpacho",
  "in_reply_to_user_id_str" : "10687942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18710461076",
  "text" : "I'm going to start my own VC firm for bros only. BroCombinator.",
  "id" : 18710461076,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18717868148",
  "text" : "My slides from Redis: Persistence POWER! (With way more examples than I could cover!) http:\/\/scr.bi\/redispower",
  "id" : 18717868148,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 0, 8 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18722636996",
  "geo" : { },
  "id_str" : "18724047116",
  "in_reply_to_user_id" : 5502392,
  "text" : "@mojombo oh man, then you could use acme and plumb! And fossil to store repos! It's the future!!",
  "id" : 18724047116,
  "in_reply_to_status_id" : 18722636996,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "mojombo",
  "in_reply_to_user_id_str" : "5502392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby Midwest",
      "screen_name" : "RubyMidwest",
      "indices" : [ 24, 36 ],
      "id_str" : "97356520",
      "id" : 97356520
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 85, 96 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18565102372",
  "text" : "Friday's Redis talk for @rubymidwest clocking in within the limit. Huge thanks to my @thoughtbot coworkers for helping me make it better.",
  "id" : 18565102372,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18568705490",
  "text" : "Ok, now that's clever. http:\/\/mashable.com\/2010\/07\/14\/old-spice-proposal\/",
  "id" : 18568705490,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Nesbitt",
      "screen_name" : "joshnesbitt",
      "indices" : [ 0, 12 ],
      "id_str" : "15652424",
      "id" : 15652424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18589375618",
  "geo" : { },
  "id_str" : "18597256556",
  "in_reply_to_user_id" : 15652424,
  "text" : "@joshnesbitt yeah, I want to deploy a fix today for it. Internets were too spotty at home yesterday.",
  "id" : 18597256556,
  "in_reply_to_status_id" : 18589375618,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshnesbitt",
  "in_reply_to_user_id_str" : "15652424",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18600076051",
  "text" : "SILVERFISH HANDCATCH http:\/\/www.youtube.com\/watch?v=nFDqvKtPgZo",
  "id" : 18600076051,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "masone",
      "screen_name" : "masone",
      "indices" : [ 0, 7 ],
      "id_str" : "12436502",
      "id" : 12436502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18616291793",
  "in_reply_to_user_id" : 12436502,
  "text" : "@masone that's rails a whole. 21k downloads of the beta.",
  "id" : 18616291793,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "masone",
  "in_reply_to_user_id_str" : "12436502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18618229710",
  "text" : "Rails 3, you're cool and all, but sometimes I just want to use Sinatra. http:\/\/gist.github.com\/477234",
  "id" : 18618229710,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18619187254",
  "text" : "Awesome. http:\/\/www.oldspicevoicemail.com\/",
  "id" : 18619187254,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18619706085",
  "text" : "Just got bit majorly by Ruby 1.9.2 taking out \".\" from $LOAD_PATH. Not cool, guys.",
  "id" : 18619706085,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 34, 47 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18625451291",
  "text" : "Never really said \"rubies\" before @wayneeseguin made it easy to run a bunch on your machine. Thanks again dude.",
  "id" : 18625451291,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18625517652",
  "geo" : { },
  "id_str" : "18625560397",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh one of many reasons I use zshkit, it push\/popd's on every directory you cd into, giving you a virtual history you can use",
  "id" : 18625560397,
  "in_reply_to_status_id" : 18625517652,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18627071051",
  "text" : "Seriously, are they trying to make sure no one uses Ruby 1.9.2? What a ridiculous change.",
  "id" : 18627071051,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Haddox",
      "screen_name" : "stevenhaddox",
      "indices" : [ 0, 13 ],
      "id_str" : "2563828880",
      "id" : 2563828880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18627094744",
  "text" : "@stevenhaddox unless if you're serving 1000s of gems, I wouldn't. use http:\/\/github.com\/cwninja\/geminabox",
  "id" : 18627094744,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18628788018",
  "geo" : { },
  "id_str" : "18629047530",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything please explain how makes life better. Is there a changelog or reasoning behind it?",
  "id" : 18629047530,
  "in_reply_to_status_id" : 18628788018,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18631276804",
  "text" : "Having a nostalgic moment. I loved Link's Awakening, and Oracle of Ages\/Seasons. http:\/\/is.gd\/dtqqJ",
  "id" : 18631276804,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18639172885",
  "geo" : { },
  "id_str" : "18640324245",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz those should be going to the rdoc.info docs instead...probably missed a few :\/",
  "id" : 18640324245,
  "in_reply_to_status_id" : 18639172885,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubymidwest",
      "indices" : [ 32, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18640392711",
  "text" : "Wheels down CLE, next stop MCI! #rubymidwest",
  "id" : 18640392711,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curt Micol",
      "screen_name" : "asenchi",
      "indices" : [ 3, 11 ],
      "id_str" : "12448492",
      "id" : 12448492
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 139, 140 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18561979672",
  "text" : "RT @asenchi: Rubyists: If you know flori, the json maintainer, please get him to respond on github or irc. The gem has easily fixable bu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evan Phoenix",
        "screen_name" : "evanphx",
        "indices" : [ 132, 140 ],
        "id_str" : "5444392",
        "id" : 5444392
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "18555818441",
    "text" : "Rubyists: If you know flori, the json maintainer, please get him to respond on github or irc. The gem has easily fixable bugs. \/via @evanphx",
    "id" : 18555818441,
    "created_at" : "2010-07-14 23:13:17 +0000",
    "user" : {
      "name" : "Curt Micol",
      "screen_name" : "asenchi",
      "protected" : false,
      "id_str" : "12448492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/417307856023465984\/tqkq_2MQ_normal.jpeg",
      "id" : 12448492,
      "verified" : false
    }
  },
  "id" : 18561979672,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18561990954",
  "text" : "Rush FFFFFFFUUUUU http:\/\/i.imgur.com\/hbyBD.png",
  "id" : 18561990954,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18492675421",
  "text" : "Bird, you can't ride the T. http:\/\/twitpic.com\/2541eg",
  "id" : 18492675421,
  "created_at" : "2010-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 0, 7 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18494786910",
  "in_reply_to_user_id" : 14237099,
  "text" : "@geemus we need to discuss both this weekend in KC. Omgwtfbbq, clouds, Rush, can't get much better than that!",
  "id" : 18494786910,
  "created_at" : "2010-07-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "geemus",
  "in_reply_to_user_id_str" : "14237099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18518049337",
  "geo" : { },
  "id_str" : "18519510296",
  "in_reply_to_user_id" : 15359408,
  "text" : "@ra66i ruby has a command line flag to make it faster? What?",
  "id" : 18519510296,
  "in_reply_to_status_id" : 18518049337,
  "created_at" : "2010-07-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Lerche",
      "screen_name" : "carllerche",
      "indices" : [ 0, 11 ],
      "id_str" : "3763061",
      "id" : 3763061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18519721251",
  "in_reply_to_user_id" : 3763061,
  "text" : "@carllerche yes, textmate's shortcuts never jived with me. Rails.vim is worth it.",
  "id" : 18519721251,
  "created_at" : "2010-07-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "carllerche",
  "in_reply_to_user_id_str" : "3763061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Hill",
      "screen_name" : "leshill",
      "indices" : [ 0, 8 ],
      "id_str" : "12495752",
      "id" : 12495752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18534702759",
  "geo" : { },
  "id_str" : "18534830311",
  "in_reply_to_user_id" : 12495752,
  "text" : "@leshill yeah :( going to deploy a fix for that tonight.",
  "id" : 18534830311,
  "in_reply_to_status_id" : 18534702759,
  "created_at" : "2010-07-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "leshill",
  "in_reply_to_user_id_str" : "12495752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18539316310",
  "text" : "lol: http:\/\/www.ericsink.com\/entries\/veracity_early.html",
  "id" : 18539316310,
  "created_at" : "2010-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Beck",
      "screen_name" : "_frommetoyou",
      "indices" : [ 0, 13 ],
      "id_str" : "1378382443",
      "id" : 1378382443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18546488147",
  "geo" : { },
  "id_str" : "18546988234",
  "in_reply_to_user_id" : 25283065,
  "text" : "@_FromMeToYou thanks!",
  "id" : 18546988234,
  "in_reply_to_status_id" : 18546488147,
  "created_at" : "2010-07-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnnStreetStudio",
  "in_reply_to_user_id_str" : "25283065",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Avery",
      "screen_name" : "averyj",
      "indices" : [ 0, 7 ],
      "id_str" : "6967822",
      "id" : 6967822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18551750123",
  "geo" : { },
  "id_str" : "18552481632",
  "in_reply_to_user_id" : 6967822,
  "text" : "@averyj haha oh man. You'll blow their minds away, its too easy compared to setting up IIS!",
  "id" : 18552481632,
  "in_reply_to_status_id" : 18551750123,
  "created_at" : "2010-07-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "averyj",
  "in_reply_to_user_id_str" : "6967822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18395630584",
  "text" : "Huh. http:\/\/api.rubyonrails.org\/classes\/ActiveRecord\/Locking\/Optimistic.html",
  "id" : 18395630584,
  "created_at" : "2010-07-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18396577285",
  "text" : "New theory: all technical problems can be sufficiently explained via ragetoons.",
  "id" : 18396577285,
  "created_at" : "2010-07-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18412518407",
  "text" : "Paring down content for a talk is HARD. Shorter talks are definitely more difficult than longer ones.",
  "id" : 18412518407,
  "created_at" : "2010-07-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Bob Martin",
      "screen_name" : "unclebobmartin",
      "indices" : [ 0, 15 ],
      "id_str" : "9505092",
      "id" : 9505092
    }, {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 76, 85 ],
      "id_str" : "21431343",
      "id" : 21431343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18321913789",
  "in_reply_to_user_id" : 9505092,
  "text" : "@unclebobmartin if you're in town tuesday night, please feel free to attend @bostonrb! http:\/\/bostonrb.org\/events\/135",
  "id" : 18321913789,
  "created_at" : "2010-07-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "unclebobmartin",
  "in_reply_to_user_id_str" : "9505092",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esp",
      "indices" : [ 84, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18322403608",
  "text" : "@daniel_amselem BBBZBZBZBZBBBZBBBBBTBTBTBBTBBZBBZBBZZBBBBBBTBTBTBBTBTT (congrats!!! #esp)",
  "id" : 18322403608,
  "created_at" : "2010-07-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18350941752",
  "text" : "Japanese business culture explained: http:\/\/bit.ly\/d0m0hy",
  "id" : 18350941752,
  "created_at" : "2010-07-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18361231940",
  "text" : "At least 4 RIT hockey games within driving distance from Boston this year. Woot! http:\/\/www.ritathletics.com\/schedule.aspx?path=mhock",
  "id" : 18361231940,
  "created_at" : "2010-07-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xavier Noria",
      "screen_name" : "fxn",
      "indices" : [ 0, 4 ],
      "id_str" : "11253302",
      "id" : 11253302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18369867412",
  "geo" : { },
  "id_str" : "18370263904",
  "in_reply_to_user_id" : 11253302,
  "text" : "@fxn why??! it's like they're intentionally causing headaches now. :[",
  "id" : 18370263904,
  "in_reply_to_status_id" : 18369867412,
  "created_at" : "2010-07-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "fxn",
  "in_reply_to_user_id_str" : "11253302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gh33da",
      "screen_name" : "gh33da",
      "indices" : [ 0, 7 ],
      "id_str" : "16468950",
      "id" : 16468950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18232091580",
  "geo" : { },
  "id_str" : "18232297959",
  "in_reply_to_user_id" : 16468950,
  "text" : "@gh33da did you just rewrite `ping google.com -t` ?",
  "id" : 18232297959,
  "in_reply_to_status_id" : 18232091580,
  "created_at" : "2010-07-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "gh33da",
  "in_reply_to_user_id_str" : "16468950",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Campbell",
      "screen_name" : "paulca",
      "indices" : [ 0, 7 ],
      "id_str" : "815973",
      "id" : 815973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18233279898",
  "geo" : { },
  "id_str" : "18233708934",
  "in_reply_to_user_id" : 815973,
  "text" : "@paulca oh those end ones are hilarious. +1",
  "id" : 18233708934,
  "in_reply_to_status_id" : 18233279898,
  "created_at" : "2010-07-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "paulca",
  "in_reply_to_user_id_str" : "815973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18298011695",
  "text" : "Watching golf is more interesting than watching the world cup finals right now.",
  "id" : 18298011695,
  "created_at" : "2010-07-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USA",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "USA",
      "indices" : [ 6, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18301396705",
  "text" : "#USA! #USA! oh wait.",
  "id" : 18301396705,
  "created_at" : "2010-07-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18162278446",
  "text" : "Turns out asking @ablissfulgal was easier than I thought. http:\/\/twitpic.com\/23wem0",
  "id" : 18162278446,
  "created_at" : "2010-07-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18201073319",
  "text" : "Thanks everyone! Definitely excited.",
  "id" : 18201073319,
  "created_at" : "2010-07-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18082477681",
  "text" : "Sometimes I wish I had an iPhone. http:\/\/www.epicwinapp.com\/",
  "id" : 18082477681,
  "created_at" : "2010-07-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18082834479",
  "text" : "Crazy idea: write an iOS emulation layer on top of Android so you can run all of the iPhone apps. Go. Do that.",
  "id" : 18082834479,
  "created_at" : "2010-07-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELLIOTTCABLE",
      "screen_name" : "ELLIOTTCABLE",
      "indices" : [ 0, 13 ],
      "id_str" : "771681",
      "id" : 771681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18082925039",
  "geo" : { },
  "id_str" : "18083087324",
  "in_reply_to_user_id" : 771681,
  "text" : "@elliottcable I've got a Droid now....UPGRAYEDD",
  "id" : 18083087324,
  "in_reply_to_status_id" : 18082925039,
  "created_at" : "2010-07-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "ELLIOTTCABLE",
  "in_reply_to_user_id_str" : "771681",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18115920485",
  "geo" : { },
  "id_str" : "18116466766",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu haha what. i don't have logins to your fancy diggs",
  "id" : 18116466766,
  "in_reply_to_status_id" : 18115920485,
  "created_at" : "2010-07-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17996272283",
  "text" : "Hunting for Redis use case examples...already found the popular ones and blog posts. If you've heard\/seen\/written new ones, let me know!",
  "id" : 17996272283,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damian Janowski",
      "screen_name" : "djanowski",
      "indices" : [ 73, 83 ],
      "id_str" : "10317382",
      "id" : 10317382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "redis",
      "indices" : [ 62, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18006731719",
  "text" : "This is probably a stupid idea. http:\/\/gist.github.com\/467620 #redis \/cc @djanowski",
  "id" : 18006731719,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18007332060",
  "text" : "Bah, that won't work at all without sets since there's no delete\/insert in a redis string.",
  "id" : 18007332060,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18072330750",
  "text" : "Comments like this are why after years, I'm still going back to Reddit. http:\/\/is.gd\/dkF9F",
  "id" : 18072330750,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17915186956",
  "text" : "I'm at Parish Cafe and Bar (361 Boylston St, Boston) w\/ 4 others. http:\/\/4sq.com\/8Pp5aQ",
  "id" : 17915186956,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "indices" : [ 0, 8 ],
      "id_str" : "6532552",
      "id" : 6532552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17948627033",
  "geo" : { },
  "id_str" : "17949128413",
  "in_reply_to_user_id" : 6532552,
  "text" : "@nkohari THEY TUKK OUR JOOOORRRRBS!!!",
  "id" : 17949128413,
  "in_reply_to_status_id" : 17948627033,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "nkohari",
  "in_reply_to_user_id_str" : "6532552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "indices" : [ 0, 8 ],
      "id_str" : "6532552",
      "id" : 6532552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17948927262",
  "geo" : { },
  "id_str" : "17950196133",
  "in_reply_to_user_id" : 6532552,
  "text" : "@nkohari seriously though, that's embarrassing to my generation, and everyone who worked hard to get that kid to that point",
  "id" : 17950196133,
  "in_reply_to_status_id" : 17948927262,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "nkohari",
  "in_reply_to_user_id_str" : "6532552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17954492892",
  "geo" : { },
  "id_str" : "17954695680",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv http:\/\/is.gd\/diN7x",
  "id" : 17954695680,
  "in_reply_to_status_id" : 17954492892,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17954730471",
  "geo" : { },
  "id_str" : "17955000954",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv or get some lame paintings from thrift stores, and do this: http:\/\/i.imgur.com\/k07Oy.jpg",
  "id" : 17955000954,
  "in_reply_to_status_id" : 17954730471,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17962534065",
  "geo" : { },
  "id_str" : "17962598900",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey \/etc\/hosts",
  "id" : 17962598900,
  "in_reply_to_status_id" : 17962534065,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17988428092",
  "geo" : { },
  "id_str" : "17988463795",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh holy crap, congrats!",
  "id" : 17988463795,
  "in_reply_to_status_id" : 17988428092,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17831101571",
  "text" : "Current status: http:\/\/www.youtube.com\/watch?v=w_kqWwC67cI",
  "id" : 17831101571,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 0, 10 ],
      "id_str" : "9980812",
      "id" : 9980812
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chunk",
      "indices" : [ 46, 52 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17832965477",
  "geo" : { },
  "id_str" : "17833192173",
  "in_reply_to_user_id" : 9980812,
  "text" : "@igrigorik wow, lots of wacky stuff in there. #chunk is cool.",
  "id" : 17833192173,
  "in_reply_to_status_id" : 17832965477,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "igrigorik",
  "in_reply_to_user_id_str" : "9980812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blake Mizerany",
      "screen_name" : "bmizerany",
      "indices" : [ 0, 10 ],
      "id_str" : "2379441",
      "id" : 2379441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lameircreference",
      "indices" : [ 91, 108 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17838837812",
  "geo" : { },
  "id_str" : "17839735594",
  "in_reply_to_user_id" : 2379441,
  "text" : "@bmizerany hot pockets are great and all, but what about jalapeno poppers? or bagel bites? #lameircreference",
  "id" : 17839735594,
  "in_reply_to_status_id" : 17838837812,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "bmizerany",
  "in_reply_to_user_id_str" : "2379441",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo DiNardi",
      "screen_name" : "adinardi",
      "indices" : [ 0, 9 ],
      "id_str" : "781929",
      "id" : 781929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17890460867",
  "geo" : { },
  "id_str" : "17890685549",
  "in_reply_to_user_id" : 781929,
  "text" : "@adinardi no one said \"building 8\" anyway, it's all \"70\" or \"8\" anyway. i'm not sure why either of us cares though, we're far away now :)",
  "id" : 17890685549,
  "in_reply_to_status_id" : 17890460867,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "adinardi",
  "in_reply_to_user_id_str" : "781929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Envy Labs",
      "screen_name" : "envylabs",
      "indices" : [ 58, 67 ],
      "id_str" : "54593077",
      "id" : 54593077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17898078887",
  "text" : "http:\/\/rubytracker.com\/ is looking fantastic. great work, @envylabs!",
  "id" : 17898078887,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17901388783",
  "text" : "Whats the name of that beta invite service thing?",
  "id" : 17901388783,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17901583535",
  "text" : "Correction: Looking for the service that provides a beta invite service for your web application. Not for free beta invite codes.",
  "id" : 17901583535,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELLIOTTCABLE",
      "screen_name" : "ELLIOTTCABLE",
      "indices" : [ 0, 13 ],
      "id_str" : "771681",
      "id" : 771681
    }, {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 14, 21 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17791303510",
  "geo" : { },
  "id_str" : "17794106120",
  "in_reply_to_user_id" : 771681,
  "text" : "@elliottcable @peterc good enough :)",
  "id" : 17794106120,
  "in_reply_to_status_id" : 17791303510,
  "created_at" : "2010-07-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "ELLIOTTCABLE",
  "in_reply_to_user_id_str" : "771681",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17688547535",
  "text" : "Still not sure where to go see the fireworks tomorrow in Boston. Any suggestions?",
  "id" : 17688547535,
  "created_at" : "2010-07-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17728036718",
  "text" : "AMERICA! FUCK YEAH",
  "id" : 17728036718,
  "created_at" : "2010-07-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Anttila",
      "screen_name" : "aanttila",
      "indices" : [ 26, 35 ],
      "id_str" : "14148170",
      "id" : 14148170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17681278681",
  "text" : "Video: VUVUZELA HERO (via @aanttila) http:\/\/tumblr.com\/x17coktk4",
  "id" : 17681278681,
  "created_at" : "2010-07-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17530386704",
  "text" : "Seeing the metrics behind Firefox's plugin hanging causing a virtual famine in Farmville the other week using Ganglia. Crazy.",
  "id" : 17530386704,
  "created_at" : "2010-07-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 0, 7 ],
      "id_str" : "728173",
      "id" : 728173
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 57, 67 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17535203566",
  "geo" : { },
  "id_str" : "17535418759",
  "in_reply_to_user_id" : 728173,
  "text" : "@MikeG1 what isn't playing nicely? We use that combo for @gemcutter and it's been fine",
  "id" : 17535418759,
  "in_reply_to_status_id" : 17535203566,
  "created_at" : "2010-07-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "MikeG1",
  "in_reply_to_user_id_str" : "728173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17545486724",
  "text" : "Walked from Inman to Lechmere...what a mistake. Should have just gone Central to Park.",
  "id" : 17545486724,
  "created_at" : "2010-07-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17546715029",
  "geo" : { },
  "id_str" : "17568870539",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton did you guys drive to MI?",
  "id" : 17568870539,
  "in_reply_to_status_id" : 17546715029,
  "created_at" : "2010-07-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17595183631",
  "geo" : { },
  "id_str" : "17595485663",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza where you going to?",
  "id" : 17595485663,
  "in_reply_to_status_id" : 17595183631,
  "created_at" : "2010-07-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17595506224",
  "geo" : { },
  "id_str" : "17598841972",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza congrats, sounds like fun! moving too?",
  "id" : 17598841972,
  "in_reply_to_status_id" : 17595506224,
  "created_at" : "2010-07-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17599590342",
  "geo" : { },
  "id_str" : "17599960107",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats makes me wonder why we're bundling rubygems with ruby now. this shouldn't happen.",
  "id" : 17599960107,
  "in_reply_to_status_id" : 17599590342,
  "created_at" : "2010-07-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
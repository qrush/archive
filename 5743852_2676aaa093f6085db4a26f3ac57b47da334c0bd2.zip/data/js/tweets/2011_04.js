Grailbird.data.tweets_2011_04 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "follow @mattetti",
      "screen_name" : "merbist",
      "indices" : [ 0, 8 ],
      "id_str" : "1549117117",
      "id" : 1549117117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64414326093656065",
  "in_reply_to_user_id" : 16476741,
  "text" : "@merbist preparing some fun for #railsconf!",
  "id" : 64414326093656065,
  "created_at" : "2011-04-30 19:42:26 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "follow @mattetti",
      "screen_name" : "merbist",
      "indices" : [ 0, 8 ],
      "id_str" : "1549117117",
      "id" : 1549117117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64398969731678208",
  "geo" : { },
  "id_str" : "64401830108610560",
  "in_reply_to_user_id" : 16476741,
  "text" : "@merbist yep.",
  "id" : 64401830108610560,
  "in_reply_to_status_id" : 64398969731678208,
  "created_at" : "2011-04-30 18:52:47 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64396218750607360",
  "text" : "Current status: http:\/\/i.imgur.com\/mOqdJ.jpg",
  "id" : 64396218750607360,
  "created_at" : "2011-04-30 18:30:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Redlist",
      "screen_name" : "redlist",
      "indices" : [ 0, 8 ],
      "id_str" : "14982648",
      "id" : 14982648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64345562501230592",
  "geo" : { },
  "id_str" : "64349075864162305",
  "in_reply_to_user_id" : 14982648,
  "text" : "@redlist everyone is still learning. use other people's configs, if you ever repeat yourself learn a better way to automate it",
  "id" : 64349075864162305,
  "in_reply_to_status_id" : 64345562501230592,
  "created_at" : "2011-04-30 15:23:09 +0000",
  "in_reply_to_screen_name" : "redlist",
  "in_reply_to_user_id_str" : "14982648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64183178759385088",
  "text" : "Dumb question, who came up with \"production\" and \"staging\" ?",
  "id" : 64183178759385088,
  "created_at" : "2011-04-30 04:23:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64106293257969664",
  "text" : "I bet you wish you had the metabolism to drink this! Hater, I'm 10 years old! http:\/\/www.youtube.com\/watch?v=oisn08wMLMU",
  "id" : 64106293257969664,
  "created_at" : "2011-04-29 23:18:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64055395739635712",
  "text" : "Dear my generation: Quidditch is not an acceptable public activity or sport. Stop it, please.",
  "id" : 64055395739635712,
  "created_at" : "2011-04-29 19:56:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 0, 8 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64050059276337152",
  "geo" : { },
  "id_str" : "64050497593679872",
  "in_reply_to_user_id" : 15029296,
  "text" : "@zedshaw THATS SO MUCH CLEARER!!!",
  "id" : 64050497593679872,
  "in_reply_to_status_id" : 64050059276337152,
  "created_at" : "2011-04-29 19:36:43 +0000",
  "in_reply_to_screen_name" : "zedshaw",
  "in_reply_to_user_id_str" : "15029296",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 0, 6 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64035676160655360",
  "geo" : { },
  "id_str" : "64043944169836544",
  "in_reply_to_user_id" : 8000842,
  "text" : "@tpope a test gem i made, i have a few for making sure `gem push` works when we change things massively. do you need that namespace?",
  "id" : 64043944169836544,
  "in_reply_to_status_id" : 64035676160655360,
  "created_at" : "2011-04-29 19:10:40 +0000",
  "in_reply_to_screen_name" : "tpope",
  "in_reply_to_user_id_str" : "8000842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64043030570737664",
  "text" : "I can't tell if this is a sick joke, or real. (Bonus fact, you need C# to make it work)  http:\/\/www.fructoselang.org\/",
  "id" : 64043030570737664,
  "created_at" : "2011-04-29 19:07:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 0, 5 ],
      "id_str" : "20941662",
      "id" : 20941662
    }, {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 6, 13 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63976415053357056",
  "geo" : { },
  "id_str" : "63984740339953664",
  "in_reply_to_user_id" : 20941662,
  "text" : "@JEG2 @peterc hurray! thanks!",
  "id" : 63984740339953664,
  "in_reply_to_status_id" : 63976415053357056,
  "created_at" : "2011-04-29 15:15:25 +0000",
  "in_reply_to_screen_name" : "JEG2",
  "in_reply_to_user_id_str" : "20941662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63973862244749312",
  "text" : "Now whenever I think of the DOM I think of http:\/\/www.youtube.com\/watch?v=F8nSHzAE5CQ",
  "id" : 63973862244749312,
  "created_at" : "2011-04-29 14:32:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63794522320158721",
  "geo" : { },
  "id_str" : "63803097553698816",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc whaaaaaat",
  "id" : 63803097553698816,
  "in_reply_to_status_id" : 63794522320158721,
  "created_at" : "2011-04-29 03:13:38 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Chelimsky",
      "screen_name" : "dchelimsky",
      "indices" : [ 88, 99 ],
      "id_str" : "14107142",
      "id" : 14107142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63793899260481536",
  "text" : "Why is the RSpec site still listing 1.3.x as the latest version? http:\/\/rspec.info\/ \/cc @dchelimsky",
  "id" : 63793899260481536,
  "created_at" : "2011-04-29 02:37:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63759403521810433",
  "text" : "Current status: http:\/\/www.youtube.com\/watch?v=Fow7iUaKrq4",
  "id" : 63759403521810433,
  "created_at" : "2011-04-29 00:20:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 18, 25 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63747079570325504",
  "geo" : { },
  "id_str" : "63748429884571648",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella wha? @wycats is in town?",
  "id" : 63748429884571648,
  "in_reply_to_status_id" : 63747079570325504,
  "created_at" : "2011-04-28 23:36:24 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63730372151742464",
  "geo" : { },
  "id_str" : "63731835066253312",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv start DESIGNER FIGHT CLUB. Argue about px vs em and throw punches.",
  "id" : 63731835066253312,
  "in_reply_to_status_id" : 63730372151742464,
  "created_at" : "2011-04-28 22:30:28 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63718733113331712",
  "geo" : { },
  "id_str" : "63718996683403265",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps Awesome. Except the PHP ;) thanks!!",
  "id" : 63718996683403265,
  "in_reply_to_status_id" : 63718733113331712,
  "created_at" : "2011-04-28 21:39:27 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63695576377737217",
  "geo" : { },
  "id_str" : "63718338462883840",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps bingo. anything.",
  "id" : 63718338462883840,
  "in_reply_to_status_id" : 63695576377737217,
  "created_at" : "2011-04-28 21:36:50 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Champion",
      "screen_name" : "graysky",
      "indices" : [ 0, 8 ],
      "id_str" : "364",
      "id" : 364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63695239793221632",
  "geo" : { },
  "id_str" : "63717307645558784",
  "in_reply_to_user_id" : 364,
  "text" : "@graysky LOL THANKS. HOW IS PROGRAM FORMED?",
  "id" : 63717307645558784,
  "in_reply_to_status_id" : 63695239793221632,
  "created_at" : "2011-04-28 21:32:44 +0000",
  "in_reply_to_screen_name" : "graysky",
  "in_reply_to_user_id_str" : "364",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63695029646008320",
  "geo" : { },
  "id_str" : "63716489349443584",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez hacker news\/proggit is a good idea, but i meant videos, tutorials, stuff to *learn*",
  "id" : 63716489349443584,
  "in_reply_to_status_id" : 63695029646008320,
  "created_at" : "2011-04-28 21:29:29 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63715682575069184",
  "geo" : { },
  "id_str" : "63716365311287296",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox yep, got that. SICP would be fun.",
  "id" : 63716365311287296,
  "in_reply_to_status_id" : 63715682575069184,
  "created_at" : "2011-04-28 21:28:59 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63694704134459392",
  "text" : "Hey, what are some good resources for programming newbies?",
  "id" : 63694704134459392,
  "created_at" : "2011-04-28 20:02:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Cox",
      "screen_name" : "imajes",
      "indices" : [ 80, 87 ],
      "id_str" : "75533",
      "id" : 75533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63632001885929472",
  "text" : "Ah, the internet. http:\/\/www.peopleinpizzaslicecostumesbecomingpizzas.com\/ (via @imajes)",
  "id" : 63632001885929472,
  "created_at" : "2011-04-28 15:53:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 0, 9 ],
      "id_str" : "148198686",
      "id" : 148198686
    }, {
      "name" : "andy walker",
      "screen_name" : "walkeran",
      "indices" : [ 10, 19 ],
      "id_str" : "16563342",
      "id" : 16563342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63613695586078720",
  "geo" : { },
  "id_str" : "63617851646414848",
  "in_reply_to_user_id" : 148198686,
  "text" : "@dnsimple @walkeran http:\/\/www.reddit.com\/r\/ruby\/comments\/gz8jc\/gem_is_not_working_at_all\/",
  "id" : 63617851646414848,
  "in_reply_to_status_id" : 63613695586078720,
  "created_at" : "2011-04-28 14:57:32 +0000",
  "in_reply_to_screen_name" : "dnsimple",
  "in_reply_to_user_id_str" : "148198686",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andy walker",
      "screen_name" : "walkeran",
      "indices" : [ 0, 9 ],
      "id_str" : "16563342",
      "id" : 16563342
    }, {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 48, 57 ],
      "id_str" : "148198686",
      "id" : 148198686
    }, {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 58, 64 ],
      "id_str" : "18673",
      "id" : 18673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63597577253294080",
  "geo" : { },
  "id_str" : "63613355323170816",
  "in_reply_to_user_id" : 16563342,
  "text" : "@walkeran I'm not seeing any DNS flakiness. Hey @dnsimple @aeden whats up?",
  "id" : 63613355323170816,
  "in_reply_to_status_id" : 63597577253294080,
  "created_at" : "2011-04-28 14:39:40 +0000",
  "in_reply_to_screen_name" : "walkeran",
  "in_reply_to_user_id_str" : "16563342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xavier Noria",
      "screen_name" : "fxn",
      "indices" : [ 0, 4 ],
      "id_str" : "11253302",
      "id" : 11253302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63598966457106432",
  "geo" : { },
  "id_str" : "63606314823188482",
  "in_reply_to_user_id" : 11253302,
  "text" : "@fxn not good :( what docs hook?",
  "id" : 63606314823188482,
  "in_reply_to_status_id" : 63598966457106432,
  "created_at" : "2011-04-28 14:11:41 +0000",
  "in_reply_to_screen_name" : "fxn",
  "in_reply_to_user_id_str" : "11253302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 0, 7 ],
      "id_str" : "6118872",
      "id" : 6118872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63597210192982016",
  "geo" : { },
  "id_str" : "63606244803485696",
  "in_reply_to_user_id" : 6118872,
  "text" : "@zoomba congrats (?)",
  "id" : 63606244803485696,
  "in_reply_to_status_id" : 63597210192982016,
  "created_at" : "2011-04-28 14:11:25 +0000",
  "in_reply_to_screen_name" : "zoomba",
  "in_reply_to_user_id_str" : "6118872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63589649796448257",
  "geo" : { },
  "id_str" : "63595408294813697",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape nice. Too bad I don't own a PC anymore ;)",
  "id" : 63595408294813697,
  "in_reply_to_status_id" : 63589649796448257,
  "created_at" : "2011-04-28 13:28:21 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 0, 7 ],
      "id_str" : "6118872",
      "id" : 6118872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63594129145348097",
  "geo" : { },
  "id_str" : "63595307228860416",
  "in_reply_to_user_id" : 6118872,
  "text" : "@zoomba whoa! Where are you headed?",
  "id" : 63595307228860416,
  "in_reply_to_status_id" : 63594129145348097,
  "created_at" : "2011-04-28 13:27:57 +0000",
  "in_reply_to_screen_name" : "zoomba",
  "in_reply_to_user_id_str" : "6118872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Santiago Pastorino",
      "screen_name" : "spastorino",
      "indices" : [ 3, 14 ],
      "id_str" : "19661139",
      "id" : 19661139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63432196882563072",
  "text" : "RT @spastorino: Rails issues are now http:\/\/bit.ly\/kuX4Xb no more LightHouse :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63425314818240512",
    "text" : "Rails issues are now http:\/\/bit.ly\/kuX4Xb no more LightHouse :)",
    "id" : 63425314818240512,
    "created_at" : "2011-04-28 02:12:28 +0000",
    "user" : {
      "name" : "Santiago Pastorino",
      "screen_name" : "spastorino",
      "protected" : false,
      "id_str" : "19661139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543960868589821952\/6aUT2q0g_normal.jpeg",
      "id" : 19661139,
      "verified" : false
    }
  },
  "id" : 63432196882563072,
  "created_at" : "2011-04-28 02:39:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 0, 6 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63255103561404416",
  "geo" : { },
  "id_str" : "63301967291760640",
  "in_reply_to_user_id" : 8000842,
  "text" : "@tpope heh, i'll look into it, no idea it had that.",
  "id" : 63301967291760640,
  "in_reply_to_status_id" : 63255103561404416,
  "created_at" : "2011-04-27 18:02:19 +0000",
  "in_reply_to_screen_name" : "tpope",
  "in_reply_to_user_id_str" : "8000842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63301334497112064",
  "geo" : { },
  "id_str" : "63301677775716352",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold imagine that! :)",
  "id" : 63301677775716352,
  "in_reply_to_status_id" : 63301334497112064,
  "created_at" : "2011-04-27 18:01:10 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63289671387578369",
  "text" : "Current status: http:\/\/www.youtube.com\/watch?v=F8nSHzAE5CQ",
  "id" : 63289671387578369,
  "created_at" : "2011-04-27 17:13:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tyler_jennings",
      "screen_name" : "tyler_jennings",
      "indices" : [ 41, 56 ],
      "id_str" : "10249342",
      "id" : 10249342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63251452780482561",
  "text" : ":GitGrep is way faster than :Ack. Thanks @tyler_jennings! https:\/\/github.com\/tjennings\/git-grep-vim",
  "id" : 63251452780482561,
  "created_at" : "2011-04-27 14:41:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63250279134543872",
  "geo" : { },
  "id_str" : "63250486777741312",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh rm",
  "id" : 63250486777741312,
  "in_reply_to_status_id" : 63250279134543872,
  "created_at" : "2011-04-27 14:37:45 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 0, 9 ],
      "id_str" : "14925480",
      "id" : 14925480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63092591742296064",
  "geo" : { },
  "id_str" : "63092934584700928",
  "in_reply_to_user_id" : 14925480,
  "text" : "@nirvdrum we need more community benchmarks to make it happen. no one seems interested in speed.",
  "id" : 63092934584700928,
  "in_reply_to_status_id" : 63092591742296064,
  "created_at" : "2011-04-27 04:11:42 +0000",
  "in_reply_to_screen_name" : "nirvdrum",
  "in_reply_to_user_id_str" : "14925480",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 12, 20 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63090283759407105",
  "text" : "Er, I meant @capotej...derp",
  "id" : 63090283759407105,
  "created_at" : "2011-04-27 04:01:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 0, 10 ],
      "id_str" : "23830105",
      "id" : 23830105
    }, {
      "name" : "juliocapote",
      "screen_name" : "juliocapote",
      "indices" : [ 11, 23 ],
      "id_str" : "14073982",
      "id" : 14073982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62955348599906305",
  "geo" : { },
  "id_str" : "63090089957392384",
  "in_reply_to_user_id" : 23830105,
  "text" : "@joedamato @juliocapote I read that whole post in a russian accent in my head, and now it's way better",
  "id" : 63090089957392384,
  "in_reply_to_status_id" : 62955348599906305,
  "created_at" : "2011-04-27 04:00:24 +0000",
  "in_reply_to_screen_name" : "joedamato",
  "in_reply_to_user_id_str" : "23830105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 60, 71 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63077703129104384",
  "text" : "Truman Show for Puppies. http:\/\/www.ustream.tv\/sfshiba (via @tenderlove)",
  "id" : 63077703129104384,
  "created_at" : "2011-04-27 03:11:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Barron",
      "screen_name" : "rubyist",
      "indices" : [ 0, 8 ],
      "id_str" : "819302",
      "id" : 819302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63055647117279232",
  "geo" : { },
  "id_str" : "63077625207328768",
  "in_reply_to_user_id" : 819302,
  "text" : "@rubyist NICE. thanks!!!",
  "id" : 63077625207328768,
  "in_reply_to_status_id" : 63055647117279232,
  "created_at" : "2011-04-27 03:10:52 +0000",
  "in_reply_to_screen_name" : "rubyist",
  "in_reply_to_user_id_str" : "819302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 0, 9 ],
      "id_str" : "14925480",
      "id" : 14925480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63070018929295363",
  "geo" : { },
  "id_str" : "63075442768347136",
  "in_reply_to_user_id" : 14925480,
  "text" : "@nirvdrum that's because the GC is actually doing something ;)",
  "id" : 63075442768347136,
  "in_reply_to_status_id" : 63070018929295363,
  "created_at" : "2011-04-27 03:02:12 +0000",
  "in_reply_to_screen_name" : "nirvdrum",
  "in_reply_to_user_id_str" : "14925480",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63054753856356352",
  "geo" : { },
  "id_str" : "63055049634484224",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety I hope they remember how to land",
  "id" : 63055049634484224,
  "in_reply_to_status_id" : 63054753856356352,
  "created_at" : "2011-04-27 01:41:09 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63054733845348352",
  "text" : "Stupid and crazy thought: when will nightvision be cheap (and not green) enough that we can replace most street\/outdoor night lighting?",
  "id" : 63054733845348352,
  "created_at" : "2011-04-27 01:39:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Barron",
      "screen_name" : "rubyist",
      "indices" : [ 0, 8 ],
      "id_str" : "819302",
      "id" : 819302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63050140243595264",
  "geo" : { },
  "id_str" : "63054057429925888",
  "in_reply_to_user_id" : 819302,
  "text" : "@rubyist damn dude. Got a recipe to share?",
  "id" : 63054057429925888,
  "in_reply_to_status_id" : 63050140243595264,
  "created_at" : "2011-04-27 01:37:13 +0000",
  "in_reply_to_screen_name" : "rubyist",
  "in_reply_to_user_id_str" : "819302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 23, 30 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 37, 46 ],
      "id_str" : "6980232",
      "id" : 6980232
    }, {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 104, 111 ],
      "id_str" : "638323",
      "id" : 638323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63021671283564544",
  "text" : "Designers should &lt;3 @github too! (@ubuwaits showing off pull requests) http:\/\/yfrog.com\/h2ej7koj \/cc @kneath",
  "id" : 63021671283564544,
  "created_at" : "2011-04-26 23:28:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 27, 36 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photo",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3615961229, -71.0816180706 ]
  },
  "id_str" : "63018579276218368",
  "text" : "At Refresh Boston watching @ubuwaits ! @ Microsoft NERD Center  http:\/\/gowal.la\/p\/dQZv #photo",
  "id" : 63018579276218368,
  "created_at" : "2011-04-26 23:16:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 0, 9 ],
      "id_str" : "9267332",
      "id" : 9267332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63012702133563392",
  "geo" : { },
  "id_str" : "63014420774780928",
  "in_reply_to_user_id" : 9267332,
  "text" : "@rtomayko SHIP SHIP SHIP",
  "id" : 63014420774780928,
  "in_reply_to_status_id" : 63012702133563392,
  "created_at" : "2011-04-26 22:59:43 +0000",
  "in_reply_to_screen_name" : "rtomayko",
  "in_reply_to_user_id_str" : "9267332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mattwynne",
      "screen_name" : "mattwynne",
      "indices" : [ 0, 10 ],
      "id_str" : "15994184",
      "id" : 15994184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62808936327294976",
  "geo" : { },
  "id_str" : "62910318317285376",
  "in_reply_to_user_id" : 15994184,
  "text" : "@mattwynne nope, lol. :)",
  "id" : 62910318317285376,
  "in_reply_to_status_id" : 62808936327294976,
  "created_at" : "2011-04-26 16:06:03 +0000",
  "in_reply_to_screen_name" : "mattwynne",
  "in_reply_to_user_id_str" : "15994184",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Jarvis",
      "screen_name" : "lee_jarvis",
      "indices" : [ 0, 11 ],
      "id_str" : "137640366",
      "id" : 137640366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62819963420950528",
  "geo" : { },
  "id_str" : "62889850348642304",
  "in_reply_to_user_id" : 137640366,
  "text" : "@lee_jarvis yes :(",
  "id" : 62889850348642304,
  "in_reply_to_status_id" : 62819963420950528,
  "created_at" : "2011-04-26 14:44:43 +0000",
  "in_reply_to_screen_name" : "lee_jarvis",
  "in_reply_to_user_id_str" : "137640366",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Speicher",
      "screen_name" : "rspeicher",
      "indices" : [ 0, 10 ],
      "id_str" : "15929592",
      "id" : 15929592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62713509477232640",
  "geo" : { },
  "id_str" : "62728589640081408",
  "in_reply_to_user_id" : 15929592,
  "text" : "@rspeicher we wouldn't show github watchers\/forks but we could link to you.",
  "id" : 62728589640081408,
  "in_reply_to_status_id" : 62713509477232640,
  "created_at" : "2011-04-26 04:03:55 +0000",
  "in_reply_to_screen_name" : "rspeicher",
  "in_reply_to_user_id_str" : "15929592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Speicher",
      "screen_name" : "rspeicher",
      "indices" : [ 0, 10 ],
      "id_str" : "15929592",
      "id" : 15929592
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 38, 45 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62713509477232640",
  "geo" : { },
  "id_str" : "62728520434073601",
  "in_reply_to_user_id" : 15929592,
  "text" : "@rspeicher how did you get that data? @sferik and i were working on a query to add that into rubygems.org itself",
  "id" : 62728520434073601,
  "in_reply_to_status_id" : 62713509477232640,
  "created_at" : "2011-04-26 04:03:39 +0000",
  "in_reply_to_screen_name" : "rspeicher",
  "in_reply_to_user_id_str" : "15929592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62649707255709696",
  "geo" : { },
  "id_str" : "62650309641646080",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt I don't know why --all isn't the default :(",
  "id" : 62650309641646080,
  "in_reply_to_status_id" : 62649707255709696,
  "created_at" : "2011-04-25 22:52:52 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 3, 12 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62612214187704322",
  "text" : "RT @mittense: I'M JUST SO GODDAMN MOTIVATED RIGHT NOW http:\/\/is.gd\/D6nX72",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.destroytwitter.com\" rel=\"nofollow\"\u003EDestroyTwitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62610755836575744",
    "text" : "I'M JUST SO GODDAMN MOTIVATED RIGHT NOW http:\/\/is.gd\/D6nX72",
    "id" : 62610755836575744,
    "created_at" : "2011-04-25 20:15:42 +0000",
    "user" : {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "protected" : false,
      "id_str" : "14237677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499217483832627200\/MXMbNU6E_normal.jpeg",
      "id" : 14237677,
      "verified" : false
    }
  },
  "id" : 62612214187704322,
  "created_at" : "2011-04-25 20:21:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 41, 48 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62546896580907009",
  "text" : "Fixed the problem with my app, it wasn't @heroku's fault. Go figure :)",
  "id" : 62546896580907009,
  "created_at" : "2011-04-25 16:01:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 10, 17 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62540656500940800",
  "text" : "Anyone at @heroku awake yet? I still have an app that's down.",
  "id" : 62540656500940800,
  "created_at" : "2011-04-25 15:37:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62531179244568576",
  "text" : "Of course, the only piece of MS software I install on this Mac requires me to reboot. :(",
  "id" : 62531179244568576,
  "created_at" : "2011-04-25 14:59:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Altara Michelle",
      "screen_name" : "FROMMETOYOU",
      "indices" : [ 11, 23 ],
      "id_str" : "21054650",
      "id" : 21054650
    }, {
      "name" : "Kevin Burg",
      "screen_name" : "kevinburg",
      "indices" : [ 68, 78 ],
      "id_str" : "10852412",
      "id" : 10852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62505129873637376",
  "text" : "Woke up to @frommetoyou on top of Reddit. Worlds are colliding! \/cc @kevinburg",
  "id" : 62505129873637376,
  "created_at" : "2011-04-25 13:15:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "keiki",
      "screen_name" : "angelicism",
      "indices" : [ 0, 11 ],
      "id_str" : "26816492",
      "id" : 26816492
    }, {
      "name" : "Martin",
      "screen_name" : "mynyml",
      "indices" : [ 12, 19 ],
      "id_str" : "15689114",
      "id" : 15689114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62304474131202048",
  "geo" : { },
  "id_str" : "62329879315755008",
  "in_reply_to_user_id" : 26816492,
  "text" : "@angelicism @mynyml Ticket to Ride Europe",
  "id" : 62329879315755008,
  "in_reply_to_status_id" : 62304474131202048,
  "created_at" : "2011-04-25 01:39:35 +0000",
  "in_reply_to_screen_name" : "angelicism",
  "in_reply_to_user_id_str" : "26816492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62301404462727169",
  "text" : "Finally won! Super close game, 135-134-133-127. http:\/\/yfrog.com\/h3f36igj",
  "id" : 62301404462727169,
  "created_at" : "2011-04-24 23:46:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62243193751748608",
  "text" : "Sabres on boston TV! YESSSSS",
  "id" : 62243193751748608,
  "created_at" : "2011-04-24 19:55:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62212130400780288",
  "text" : "Current status: http:\/\/i.imgur.com\/rL3Q4.gif",
  "id" : 62212130400780288,
  "created_at" : "2011-04-24 17:51:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Blake",
      "screen_name" : "blaix",
      "indices" : [ 0, 6 ],
      "id_str" : "8239892",
      "id" : 8239892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62122183639564288",
  "geo" : { },
  "id_str" : "62141733634441216",
  "in_reply_to_user_id" : 8239892,
  "text" : "@blaix I couldn't recover my account when I got a new phone :(",
  "id" : 62141733634441216,
  "in_reply_to_status_id" : 62122183639564288,
  "created_at" : "2011-04-24 13:11:58 +0000",
  "in_reply_to_screen_name" : "blaix",
  "in_reply_to_user_id_str" : "8239892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61970604017987584",
  "geo" : { },
  "id_str" : "61985023896723456",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit write javascript instead? http:\/\/is.gd\/yJ9sku",
  "id" : 61985023896723456,
  "in_reply_to_status_id" : 61970604017987584,
  "created_at" : "2011-04-24 02:49:15 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61935354726453249",
  "text" : "Current status: Ass kicked by @ablissfulgal in Ticket to Ride Europe. I still can't win :(",
  "id" : 61935354726453249,
  "created_at" : "2011-04-23 23:31:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61897375584763904",
  "text" : "Still can't push myself to play vulgar words on WordFeud vs family. I won't hold back against you though, play me: qrush40",
  "id" : 61897375584763904,
  "created_at" : "2011-04-23 21:00:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 40, 47 ],
      "id_str" : "14237099",
      "id" : 14237099
    }, {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 52, 57 ],
      "id_str" : "20941662",
      "id" : 20941662
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 89, 103 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rdrc2",
      "indices" : [ 25, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61642327357263873",
  "text" : "Apparently losers win at #rdrc2! Thanks @geemus and @JEG2! http:\/\/yfrog.com\/hsjavmmj \/cc @joshuaclayton",
  "id" : 61642327357263873,
  "created_at" : "2011-04-23 04:07:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josiah Kiehl",
      "screen_name" : "bluepojo",
      "indices" : [ 0, 9 ],
      "id_str" : "327477172",
      "id" : 327477172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61620932032208896",
  "geo" : { },
  "id_str" : "61621497365676032",
  "in_reply_to_user_id" : 14464631,
  "text" : "@BluePojo yes. New api is \/api\/v1\/gems. Check http:\/\/rubygems.org\/pages\/api_docs",
  "id" : 61621497365676032,
  "in_reply_to_status_id" : 61620932032208896,
  "created_at" : "2011-04-23 02:44:44 +0000",
  "in_reply_to_screen_name" : "CapoFerro",
  "in_reply_to_user_id_str" : "14464631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61604055369265152",
  "geo" : { },
  "id_str" : "61605341070229504",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton next year then! This has been pretty awesome.",
  "id" : 61605341070229504,
  "in_reply_to_status_id" : 61604055369265152,
  "created_at" : "2011-04-23 01:40:32 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61602823112105984",
  "geo" : { },
  "id_str" : "61603485585653760",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton actually switched to ticket to ride...will have to try dominion still!",
  "id" : 61603485585653760,
  "in_reply_to_status_id" : 61602823112105984,
  "created_at" : "2011-04-23 01:33:10 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rdrc2",
      "indices" : [ 68, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61603481127092224",
  "text" : "Change of plans! Ticket to Ride instead. http:\/\/yfrog.com\/h2v7cthmj #rdrc2",
  "id" : 61603481127092224,
  "created_at" : "2011-04-23 01:33:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 40, 54 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rdrc2",
      "indices" : [ 55, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61601650816724992",
  "text" : "Dominion! http:\/\/yfrog.com\/hsw7dsfj \/cc @joshuaclayton #rdrc2",
  "id" : 61601650816724992,
  "created_at" : "2011-04-23 01:25:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "My Info",
      "screen_name" : "TKocurek",
      "indices" : [ 0, 9 ],
      "id_str" : "2523735806",
      "id" : 2523735806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61590058179899392",
  "geo" : { },
  "id_str" : "61590716874371072",
  "in_reply_to_user_id" : 16450691,
  "text" : "@tkocurek that would be fun. Pull down random repos, show viz. http:\/\/code.google.com\/p\/gource\/",
  "id" : 61590716874371072,
  "in_reply_to_status_id" : 61590058179899392,
  "created_at" : "2011-04-23 00:42:25 +0000",
  "in_reply_to_screen_name" : "trentkocurek",
  "in_reply_to_user_id_str" : "16450691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Alcorn",
      "screen_name" : "micahalcorn",
      "indices" : [ 0, 12 ],
      "id_str" : "21257545",
      "id" : 21257545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61585418663112705",
  "geo" : { },
  "id_str" : "61587337771102208",
  "in_reply_to_user_id" : 21257545,
  "text" : "@micahalcorn it's Gource, very sped up http:\/\/code.google.com\/p\/gource\/",
  "id" : 61587337771102208,
  "in_reply_to_status_id" : 61585418663112705,
  "created_at" : "2011-04-23 00:29:00 +0000",
  "in_reply_to_screen_name" : "micahalcorn",
  "in_reply_to_user_id_str" : "21257545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tyler_jennings",
      "screen_name" : "tyler_jennings",
      "indices" : [ 0, 15 ],
      "id_str" : "10249342",
      "id" : 10249342
    }, {
      "name" : "\u2B50 Daniel Lucraft",
      "screen_name" : "danlucraft",
      "indices" : [ 83, 94 ],
      "id_str" : "13094142",
      "id" : 13094142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61585804631343104",
  "geo" : { },
  "id_str" : "61587060863139840",
  "in_reply_to_user_id" : 10249342,
  "text" : "@tyler_jennings I suppose we could write vim bindings for redcar? Is that possible @danlucraft?",
  "id" : 61587060863139840,
  "in_reply_to_status_id" : 61585804631343104,
  "created_at" : "2011-04-23 00:27:54 +0000",
  "in_reply_to_screen_name" : "tyler_jennings",
  "in_reply_to_user_id_str" : "10249342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Gorshing",
      "screen_name" : "cgorshing",
      "indices" : [ 3, 13 ],
      "id_str" : "18455900",
      "id" : 18455900
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rdrc2",
      "indices" : [ 39, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61583505578131456",
  "text" : "RT @cgorshing: \"Always be committing!\" #rdrc2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rdrc2",
        "indices" : [ 24, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61576689586671616",
    "text" : "\"Always be committing!\" #rdrc2",
    "id" : 61576689586671616,
    "created_at" : "2011-04-22 23:46:41 +0000",
    "user" : {
      "name" : "Chad Gorshing",
      "screen_name" : "cgorshing",
      "protected" : false,
      "id_str" : "18455900",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438145171109052416\/m-6fX5oR_normal.jpeg",
      "id" : 18455900,
      "verified" : false
    }
  },
  "id" : 61583505578131456,
  "created_at" : "2011-04-23 00:13:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rdrc2",
      "indices" : [ 32, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61583210647257088",
  "text" : "Sabres up 3-0 and talk given at #rdrc2. Will get the slides up soon, thanks for coming!",
  "id" : 61583210647257088,
  "created_at" : "2011-04-23 00:12:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61556611277266944",
  "geo" : { },
  "id_str" : "61566813024174080",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh are you going to fix the cloud?",
  "id" : 61566813024174080,
  "in_reply_to_status_id" : 61556611277266944,
  "created_at" : "2011-04-22 23:07:26 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61539697243078656",
  "geo" : { },
  "id_str" : "61561466083491840",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight decently fast too, tried it on a few of these https:\/\/gist.github.com\/937736",
  "id" : 61561466083491840,
  "in_reply_to_status_id" : 61539697243078656,
  "created_at" : "2011-04-22 22:46:11 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 52, 57 ],
      "id_str" : "20941662",
      "id" : 20941662
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rdrc2",
      "indices" : [ 59, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61561003120406528",
  "text" : "Pumped for some live conference refactoring, thanks @JEG2! #rdrc2",
  "id" : 61561003120406528,
  "created_at" : "2011-04-22 22:44:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rdrc2",
      "indices" : [ 76, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61544293852135424",
  "text" : "Looks like haml-edge wins with 332 versions! https:\/\/gist.github.com\/937736 #rdrc2",
  "id" : 61544293852135424,
  "created_at" : "2011-04-22 21:37:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seana q.",
      "screen_name" : "ladysauce",
      "indices" : [ 0, 10 ],
      "id_str" : "14955094",
      "id" : 14955094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61527932778201089",
  "geo" : { },
  "id_str" : "61528319312662528",
  "in_reply_to_user_id" : 14955094,
  "text" : "@ladysauce while you're at it: http:\/\/en.wikipedia.org\/wiki\/Flat_Earth_Society",
  "id" : 61528319312662528,
  "in_reply_to_status_id" : 61527932778201089,
  "created_at" : "2011-04-22 20:34:29 +0000",
  "in_reply_to_screen_name" : "ladysauce",
  "in_reply_to_user_id_str" : "14955094",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.2431569104, -97.4779772758 ]
  },
  "id_str" : "61474464638058497",
  "text" : "Day 2! @ Red Dirt RubyConf http:\/\/gowal.la\/c\/44tUw",
  "id" : 61474464638058497,
  "created_at" : "2011-04-22 17:00:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 3, 11 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61467914410266624",
  "text" : "RT @mperham: There are still too many developers who work with Open Source and not enough Open Source developers.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61459124273168384",
    "text" : "There are still too many developers who work with Open Source and not enough Open Source developers.",
    "id" : 61459124273168384,
    "created_at" : "2011-04-22 15:59:31 +0000",
    "user" : {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "protected" : false,
      "id_str" : "14060922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519271188569128960\/i2t9GfcA_normal.jpeg",
      "id" : 14060922,
      "verified" : false
    }
  },
  "id" : 61467914410266624,
  "created_at" : "2011-04-22 16:34:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61251554879086593",
  "text" : "Moved THE GEM WHISPERER to http:\/\/gem.heroku.com, much easier to remember! Nice mobile layout for the latest gems released!",
  "id" : 61251554879086593,
  "created_at" : "2011-04-22 02:14:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 0, 9 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61243553766064129",
  "geo" : { },
  "id_str" : "61246745404899328",
  "in_reply_to_user_id" : 5674672,
  "text" : "@indirect I have quaran.to for a reason! :P",
  "id" : 61246745404899328,
  "in_reply_to_status_id" : 61243553766064129,
  "created_at" : "2011-04-22 01:55:36 +0000",
  "in_reply_to_screen_name" : "indirect",
  "in_reply_to_user_id_str" : "5674672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martyn Loughran",
      "screen_name" : "mloughran",
      "indices" : [ 0, 10 ],
      "id_str" : "6869822",
      "id" : 6869822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61207628600184832",
  "geo" : { },
  "id_str" : "61225214805164032",
  "in_reply_to_user_id" : 6869822,
  "text" : "@mloughran thanks for the merge! left a comment as well.",
  "id" : 61225214805164032,
  "in_reply_to_status_id" : 61207628600184832,
  "created_at" : "2011-04-22 00:30:03 +0000",
  "in_reply_to_screen_name" : "mloughran",
  "in_reply_to_user_id_str" : "6869822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micheil (Em) Smith",
      "screen_name" : "miksago",
      "indices" : [ 0, 8 ],
      "id_str" : "14063149",
      "id" : 14063149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61210461407940608",
  "geo" : { },
  "id_str" : "61212767759241216",
  "in_reply_to_user_id" : 14063149,
  "text" : "@miksago the style I'm used to is curly braces only for one-liner blocks, otherwise do\/end. This isn't JS, or Go, or C, or Java, or... ;)",
  "id" : 61212767759241216,
  "in_reply_to_status_id" : 61210461407940608,
  "created_at" : "2011-04-21 23:40:35 +0000",
  "in_reply_to_screen_name" : "miksago",
  "in_reply_to_user_id_str" : "14063149",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noel Rappin",
      "screen_name" : "noelrap",
      "indices" : [ 75, 83 ],
      "id_str" : "1515231",
      "id" : 1515231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61187650694029312",
  "text" : "This is awesome. We need more of this pushing JS testing forward, kudos to @noelrap. https:\/\/github.com\/noelrappin\/summer_breeze",
  "id" : 61187650694029312,
  "created_at" : "2011-04-21 22:00:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rdrc",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61171779716124672",
  "text" : "Ice cream AND beef jerky. I don't think this conference food can get any better. #rdrc",
  "id" : 61171779716124672,
  "created_at" : "2011-04-21 20:57:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ziromr",
      "screen_name" : "ziromr",
      "indices" : [ 0, 7 ],
      "id_str" : "9689352",
      "id" : 9689352
    }, {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 8, 15 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61165939642740736",
  "geo" : { },
  "id_str" : "61166974910218240",
  "in_reply_to_user_id" : 9689352,
  "text" : "@ziromr @jyurek we should definitely be using Shellwords...:(",
  "id" : 61166974910218240,
  "in_reply_to_status_id" : 61165939642740736,
  "created_at" : "2011-04-21 20:38:37 +0000",
  "in_reply_to_screen_name" : "ziromr",
  "in_reply_to_user_id_str" : "9689352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ziromr",
      "screen_name" : "ziromr",
      "indices" : [ 0, 7 ],
      "id_str" : "9689352",
      "id" : 9689352
    }, {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 51, 58 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61163617390821376",
  "geo" : { },
  "id_str" : "61165465589919744",
  "in_reply_to_user_id" : 9689352,
  "text" : "@ziromr wha? is there something we're missing? \/cc @jyurek",
  "id" : 61165465589919744,
  "in_reply_to_status_id" : 61163617390821376,
  "created_at" : "2011-04-21 20:32:38 +0000",
  "in_reply_to_screen_name" : "ziromr",
  "in_reply_to_user_id_str" : "9689352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Chaffee",
      "screen_name" : "alexch",
      "indices" : [ 0, 7 ],
      "id_str" : "7632622",
      "id" : 7632622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61160433943457792",
  "geo" : { },
  "id_str" : "61161696252801024",
  "in_reply_to_user_id" : 7632622,
  "text" : "@alexch you're missing the point. this lets designers write HTML. get the logic out of the views.",
  "id" : 61161696252801024,
  "in_reply_to_status_id" : 61160433943457792,
  "created_at" : "2011-04-21 20:17:39 +0000",
  "in_reply_to_screen_name" : "alexch",
  "in_reply_to_user_id_str" : "7632622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61159689882320896",
  "text" : "The more ERB and HAML I see, the more I want to use https:\/\/github.com\/jferris\/effigy. Views. Fuck 'em.",
  "id" : 61159689882320896,
  "created_at" : "2011-04-21 20:09:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61144705760641024",
  "text" : "Trying out Gowalla for the first time in a year...their android app is really damn good.",
  "id" : 61144705760641024,
  "created_at" : "2011-04-21 19:10:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61131010301100032",
  "text" : "Story of my life: the tests are harder to write than the implementation.",
  "id" : 61131010301100032,
  "created_at" : "2011-04-21 18:15:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rdrc",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61106961218936832",
  "text" : "Damn. jerky.com as a snack sponsor at #rdrc = BEST conference snack ever.",
  "id" : 61106961218936832,
  "created_at" : "2011-04-21 16:40:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Bock",
      "screen_name" : "bnjmnbck",
      "indices" : [ 0, 9 ],
      "id_str" : "29160478",
      "id" : 29160478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61105731553857536",
  "geo" : { },
  "id_str" : "61105887615520768",
  "in_reply_to_user_id" : 29160478,
  "text" : "@bnjmnbck i mean for the core ruby docs",
  "id" : 61105887615520768,
  "in_reply_to_status_id" : 61105731553857536,
  "created_at" : "2011-04-21 16:35:53 +0000",
  "in_reply_to_screen_name" : "bnjmnbck",
  "in_reply_to_user_id_str" : "29160478",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John E. Vincent",
      "screen_name" : "lusis",
      "indices" : [ 0, 6 ],
      "id_str" : "14586723",
      "id" : 14586723
    }, {
      "name" : "Martyn Loughran",
      "screen_name" : "mloughran",
      "indices" : [ 7, 17 ],
      "id_str" : "6869822",
      "id" : 6869822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61061060999905280",
  "geo" : { },
  "id_str" : "61101304050745344",
  "in_reply_to_user_id" : 14586723,
  "text" : "@lusis @mloughran i'd also be willing to help with maintaing the em-hiredis gem. so much nicer than em-redis. :) let me know!",
  "id" : 61101304050745344,
  "in_reply_to_status_id" : 61061060999905280,
  "created_at" : "2011-04-21 16:17:40 +0000",
  "in_reply_to_screen_name" : "lusis",
  "in_reply_to_user_id_str" : "14586723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61093280607240192",
  "text" : "Does anyone else feel like the ruby-doc.org styles feel straight out of 2001?",
  "id" : 61093280607240192,
  "created_at" : "2011-04-21 15:45:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 3, 11 ],
      "id_str" : "11374142",
      "id" : 11374142
    }, {
      "name" : "Christopher Warren",
      "screen_name" : "cdwarren",
      "indices" : [ 18, 27 ],
      "id_str" : "12226202",
      "id" : 12226202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61079057881759744",
  "text" : "RT @bphogan: zomg @cdwarren hit it on the head.... S3 is down... Skynet has begun its attack!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christopher Warren",
        "screen_name" : "cdwarren",
        "indices" : [ 5, 14 ],
        "id_str" : "12226202",
        "id" : 12226202
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61078401326395392",
    "text" : "zomg @cdwarren hit it on the head.... S3 is down... Skynet has begun its attack!",
    "id" : 61078401326395392,
    "created_at" : "2011-04-21 14:46:40 +0000",
    "user" : {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "protected" : false,
      "id_str" : "11374142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477448204909174785\/xcuKMs6E_normal.jpeg",
      "id" : 11374142,
      "verified" : false
    }
  },
  "id" : 61079057881759744,
  "created_at" : "2011-04-21 14:49:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John E. Vincent",
      "screen_name" : "lusis",
      "indices" : [ 0, 6 ],
      "id_str" : "14586723",
      "id" : 14586723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61061143011147776",
  "geo" : { },
  "id_str" : "61061908547121154",
  "in_reply_to_user_id" : 14586723,
  "text" : "@lusis most of them have been adapted from em-redis and redis-rb. great artists steal ;)",
  "id" : 61061908547121154,
  "in_reply_to_status_id" : 61061143011147776,
  "created_at" : "2011-04-21 13:41:08 +0000",
  "in_reply_to_screen_name" : "lusis",
  "in_reply_to_user_id_str" : "14586723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martyn Loughran",
      "screen_name" : "mloughran",
      "indices" : [ 4, 14 ],
      "id_str" : "6869822",
      "id" : 6869822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61060955609632768",
  "text" : "Hey @mloughran, a new more awesome pull request for you: https:\/\/github.com\/mloughran\/em-hiredis\/pull\/3",
  "id" : 61060955609632768,
  "created_at" : "2011-04-21 13:37:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Stefano",
      "screen_name" : "virtstaticvoid",
      "indices" : [ 0, 15 ],
      "id_str" : "14182673",
      "id" : 14182673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61053633474723840",
  "geo" : { },
  "id_str" : "61056860664504320",
  "in_reply_to_user_id" : 14182673,
  "text" : "@virtstaticvoid I didn't see any pingdom notifications, what was not working?",
  "id" : 61056860664504320,
  "in_reply_to_status_id" : 61053633474723840,
  "created_at" : "2011-04-21 13:21:04 +0000",
  "in_reply_to_screen_name" : "virtstaticvoid",
  "in_reply_to_user_id_str" : "14182673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Red Dirt RubyConf",
      "screen_name" : "RedDirtRubyConf",
      "indices" : [ 11, 27 ],
      "id_str" : "110027552",
      "id" : 110027552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61054313480470528",
  "text" : "Pumped for @reddirtrubyconf to get started!",
  "id" : 61054313480470528,
  "created_at" : "2011-04-21 13:10:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60886107616849920",
  "geo" : { },
  "id_str" : "60890194160795649",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson not sure that jeweler is the problem here :(",
  "id" : 60890194160795649,
  "in_reply_to_status_id" : 60886107616849920,
  "created_at" : "2011-04-21 02:18:48 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60794412564885504",
  "text" : "OKC so far: warm, and lots of oil rigs. Didn't expect the latter.",
  "id" : 60794412564885504,
  "created_at" : "2011-04-20 19:58:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60755669451685888",
  "geo" : { },
  "id_str" : "60787919018921984",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit CODE!",
  "id" : 60787919018921984,
  "in_reply_to_status_id" : 60755669451685888,
  "created_at" : "2011-04-20 19:32:23 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60770338534989824",
  "geo" : { },
  "id_str" : "60787872617345024",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu yep, found this out today too. Daikon is going under a big rewrite, will fix",
  "id" : 60787872617345024,
  "in_reply_to_status_id" : 60770338534989824,
  "created_at" : "2011-04-20 19:32:12 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 7, 20 ],
      "id_str" : "11587602",
      "id" : 11587602
    }, {
      "name" : "Red Dirt RubyConf",
      "screen_name" : "RedDirtRubyConf",
      "indices" : [ 50, 66 ],
      "id_str" : "110027552",
      "id" : 110027552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60741388194684928",
  "text" : "A wild @wayneeseguin appears at ORD on the way to @RedDirtRubyConf!",
  "id" : 60741388194684928,
  "created_at" : "2011-04-20 16:27:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60379089491607552",
  "geo" : { },
  "id_str" : "60387885249069056",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu link. Way cheaper.",
  "id" : 60387885249069056,
  "in_reply_to_status_id" : 60379089491607552,
  "created_at" : "2011-04-19 17:02:48 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sabres",
      "indices" : [ 23, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60133324072558592",
  "text" : "FFFFFFFFFFFFFUUUUUUUUU #sabres :(",
  "id" : 60133324072558592,
  "created_at" : "2011-04-19 00:11:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John E. Vincent",
      "screen_name" : "lusis",
      "indices" : [ 0, 6 ],
      "id_str" : "14586723",
      "id" : 14586723
    }, {
      "name" : "Martyn Loughran",
      "screen_name" : "mloughran",
      "indices" : [ 7, 17 ],
      "id_str" : "6869822",
      "id" : 6869822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59993896767332352",
  "geo" : { },
  "id_str" : "59998379366821888",
  "in_reply_to_user_id" : 14586723,
  "text" : "@lusis @mloughran +1's encouraged, let's get this merged! :)",
  "id" : 59998379366821888,
  "in_reply_to_status_id" : 59993896767332352,
  "created_at" : "2011-04-18 15:15:03 +0000",
  "in_reply_to_screen_name" : "lusis",
  "in_reply_to_user_id_str" : "14586723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martyn Loughran",
      "screen_name" : "mloughran",
      "indices" : [ 4, 14 ],
      "id_str" : "6869822",
      "id" : 6869822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59993264274673664",
  "text" : "Hey @mloughran, got a pull request for you: https:\/\/github.com\/mloughran\/em-hiredis\/pull\/2",
  "id" : 59993264274673664,
  "created_at" : "2011-04-18 14:54:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59803540452945920",
  "geo" : { },
  "id_str" : "59816714849886208",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton if you have anything than rubygems.org (which you dont even need a .gemrc for) it's making extra requests. add on -V to see",
  "id" : 59816714849886208,
  "in_reply_to_status_id" : 59803540452945920,
  "created_at" : "2011-04-18 03:13:10 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59800807041798144",
  "geo" : { },
  "id_str" : "59801537131720704",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight of all time: Red Barchetta. early days, definitely Fly by Night, beyond that, Subdivisions, Between the Wheels...the list goes on!",
  "id" : 59801537131720704,
  "in_reply_to_status_id" : 59800807041798144,
  "created_at" : "2011-04-18 02:12:52 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 0, 10 ],
      "id_str" : "9980812",
      "id" : 9980812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59799037217484800",
  "geo" : { },
  "id_str" : "59799641595715584",
  "in_reply_to_user_id" : 9980812,
  "text" : "@igrigorik yeah dude, just install QT from their binaries. not worth the source install (just did the same for capybara-webkit)",
  "id" : 59799641595715584,
  "in_reply_to_status_id" : 59799037217484800,
  "created_at" : "2011-04-18 02:05:20 +0000",
  "in_reply_to_screen_name" : "igrigorik",
  "in_reply_to_user_id_str" : "9980812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "--fast",
      "screen_name" : "adman65",
      "indices" : [ 0, 8 ],
      "id_str" : "16663905",
      "id" : 16663905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59384611712663553",
  "geo" : { },
  "id_str" : "59799353560285184",
  "in_reply_to_user_id" : 16663905,
  "text" : "@Adman65 whoa, have you seen http:\/\/test.rubygems.org ? I don't fully understand the \"rating\"",
  "id" : 59799353560285184,
  "in_reply_to_status_id" : 59384611712663553,
  "created_at" : "2011-04-18 02:04:11 +0000",
  "in_reply_to_screen_name" : "adman65",
  "in_reply_to_user_id_str" : "16663905",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 0, 8 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59381792590925824",
  "geo" : { },
  "id_str" : "59799121330044928",
  "in_reply_to_user_id" : 5502392,
  "text" : "@mojombo i agree, there's some patches out for it that i need to evaluate.",
  "id" : 59799121330044928,
  "in_reply_to_status_id" : 59381792590925824,
  "created_at" : "2011-04-18 02:03:16 +0000",
  "in_reply_to_screen_name" : "mojombo",
  "in_reply_to_user_id_str" : "5502392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59797743773814784",
  "geo" : { },
  "id_str" : "59798962902806529",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove go outside of the US? *selfburn* :(",
  "id" : 59798962902806529,
  "in_reply_to_status_id" : 59797743773814784,
  "created_at" : "2011-04-18 02:02:38 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59797610675961856",
  "text" : "General PSA: You don't need gems.github.com or gems.rubyforge.org in your ~\/.gemrc anymore, and that's making your gem installs slower.",
  "id" : 59797610675961856,
  "created_at" : "2011-04-18 01:57:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 3, 14 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Red Dirt RubyConf",
      "screen_name" : "RedDirtRubyConf",
      "indices" : [ 30, 46 ],
      "id_str" : "110027552",
      "id" : 110027552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59797153350025217",
  "text" : "RT @tenderlove: Excited about @RedDirtRubyConf!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Red Dirt RubyConf",
        "screen_name" : "RedDirtRubyConf",
        "indices" : [ 14, 30 ],
        "id_str" : "110027552",
        "id" : 110027552
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59797085943382016",
    "text" : "Excited about @RedDirtRubyConf!",
    "id" : 59797085943382016,
    "created_at" : "2011-04-18 01:55:10 +0000",
    "user" : {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "protected" : false,
      "id_str" : "14761655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000325798111\/ca48276f8ebbbbac9c6ce83aac3c8548_normal.jpeg",
      "id" : 14761655,
      "verified" : false
    }
  },
  "id" : 59797153350025217,
  "created_at" : "2011-04-18 01:55:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59418103897001984",
  "text" : "Source Code wasn't about GitHub at all. Someone should have warned me.",
  "id" : 59418103897001984,
  "created_at" : "2011-04-17 00:49:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59347492860469248",
  "geo" : { },
  "id_str" : "59355427976118272",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza it died? Why? RIT's article was hilarious.",
  "id" : 59355427976118272,
  "in_reply_to_status_id" : 59347492860469248,
  "created_at" : "2011-04-16 20:40:11 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59078576770777089",
  "geo" : { },
  "id_str" : "59300211129991168",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej how odd i'm not seeing this on http:\/\/gemwhisperer.heroku.com\/ (what runs the twitter feed)",
  "id" : 59300211129991168,
  "in_reply_to_status_id" : 59078576770777089,
  "created_at" : "2011-04-16 17:00:46 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59078105578479616",
  "geo" : { },
  "id_str" : "59089016594771968",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej fuuuuu :(",
  "id" : 59089016594771968,
  "in_reply_to_status_id" : 59078105578479616,
  "created_at" : "2011-04-16 03:01:34 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "howfuckedisthet",
      "indices" : [ 53, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59039527137853440",
  "text" : "New record, 2 disabled trains at park in one week :( #howfuckedisthet",
  "id" : 59039527137853440,
  "created_at" : "2011-04-15 23:44:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 0, 12 ],
      "id_str" : "517029319",
      "id" : 517029319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59038539421188098",
  "text" : "@seacreature are you in town?",
  "id" : 59038539421188098,
  "created_at" : "2011-04-15 23:40:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58768988158697472",
  "geo" : { },
  "id_str" : "58769451960639488",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant ahaha. Ridiculous night from forever ago... fall 2008? Geez.",
  "id" : 58769451960639488,
  "in_reply_to_status_id" : 58768988158697472,
  "created_at" : "2011-04-15 05:51:43 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 49, 58 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58737662303027200",
  "geo" : { },
  "id_str" : "58768141551017984",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox I was not around at all...stayed with @bquarant at BC. Someone else bailed your ass out",
  "id" : 58768141551017984,
  "in_reply_to_status_id" : 58737662303027200,
  "created_at" : "2011-04-15 05:46:31 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sabres",
      "indices" : [ 11, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58712945462484992",
  "text" : "Keep it up #sabres! &lt;\/fanboy&gt;",
  "id" : 58712945462484992,
  "created_at" : "2011-04-15 02:07:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58705745813848064",
  "geo" : { },
  "id_str" : "58706003469942785",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 so many boos from Flyers fans, i love it.",
  "id" : 58706003469942785,
  "in_reply_to_status_id" : 58705745813848064,
  "created_at" : "2011-04-15 01:39:36 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SABRES",
      "indices" : [ 13, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58705923597799424",
  "text" : "KALETA!!!!!! #SABRES!!!",
  "id" : 58705923597799424,
  "created_at" : "2011-04-15 01:39:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58683892172980225",
  "geo" : { },
  "id_str" : "58684047701970944",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic got my jersey on now, so yes.",
  "id" : 58684047701970944,
  "in_reply_to_status_id" : 58683892172980225,
  "created_at" : "2011-04-15 00:12:21 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58682533113630720",
  "text" : "Listening to the game on http:\/\/www.wgr550.com\/ !",
  "id" : 58682533113630720,
  "created_at" : "2011-04-15 00:06:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sabres",
      "indices" : [ 3, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58681741094830080",
  "text" : "Go #sabres!!!",
  "id" : 58681741094830080,
  "created_at" : "2011-04-15 00:03:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 0, 10 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58643175639756800",
  "geo" : { },
  "id_str" : "58661302683435008",
  "in_reply_to_user_id" : 23830105,
  "text" : "@joedamato this doesn't trouble me. does it bother you?",
  "id" : 58661302683435008,
  "in_reply_to_status_id" : 58643175639756800,
  "created_at" : "2011-04-14 22:41:59 +0000",
  "in_reply_to_screen_name" : "joedamato",
  "in_reply_to_user_id_str" : "23830105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 0, 10 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58641508093534208",
  "geo" : { },
  "id_str" : "58642310757490688",
  "in_reply_to_user_id" : 23830105,
  "text" : "@joedamato dude sounds like a 12 year old boy",
  "id" : 58642310757490688,
  "in_reply_to_status_id" : 58641508093534208,
  "created_at" : "2011-04-14 21:26:31 +0000",
  "in_reply_to_screen_name" : "joedamato",
  "in_reply_to_user_id_str" : "23830105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58364850455318529",
  "geo" : { },
  "id_str" : "58397368105709568",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv dude YES. If you haven't seen adventure time yet that shit is awesome",
  "id" : 58397368105709568,
  "in_reply_to_status_id" : 58364850455318529,
  "created_at" : "2011-04-14 05:13:12 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 3, 16 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58397017923256321",
  "text" : "RT @moonpolysoft: `I'm pretty sure the most reported bug in JavaScript is \"help, this language is bullshit\"` http:\/\/bit.ly\/epvggv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58373475185860608",
    "text" : "`I'm pretty sure the most reported bug in JavaScript is \"help, this language is bullshit\"` http:\/\/bit.ly\/epvggv",
    "id" : 58373475185860608,
    "created_at" : "2011-04-14 03:38:15 +0000",
    "user" : {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "protected" : false,
      "id_str" : "14204623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535708867254956032\/9TysCR2t_normal.jpeg",
      "id" : 14204623,
      "verified" : false
    }
  },
  "id" : 58397017923256321,
  "created_at" : "2011-04-14 05:11:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poul Stevens",
      "screen_name" : "louisck",
      "indices" : [ 11, 19 ],
      "id_str" : "2218092372",
      "id" : 2218092372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58356725639680001",
  "text" : "Seriously, @LOUISCK is the man. http:\/\/i.imgur.com\/FYhlH.png",
  "id" : 58356725639680001,
  "created_at" : "2011-04-14 02:31:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58307281409941504",
  "geo" : { },
  "id_str" : "58312784043188224",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius UNITE!!!!",
  "id" : 58312784043188224,
  "in_reply_to_status_id" : 58307281409941504,
  "created_at" : "2011-04-13 23:37:05 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58271626118168576",
  "text" : "&lt;\/nerdrage&gt; Look folks, it's not hard to get involved in OSS. Make some patches if you want to see change.",
  "id" : 58271626118168576,
  "created_at" : "2011-04-13 20:53:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58270768659836928",
  "geo" : { },
  "id_str" : "58271464524218368",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan there's a reason the fork button exists dude",
  "id" : 58271464524218368,
  "in_reply_to_status_id" : 58270768659836928,
  "created_at" : "2011-04-13 20:52:54 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blake Mizerany",
      "screen_name" : "bmizerany",
      "indices" : [ 0, 10 ],
      "id_str" : "2379441",
      "id" : 2379441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58269519088599040",
  "geo" : { },
  "id_str" : "58269980004859904",
  "in_reply_to_user_id" : 2379441,
  "text" : "@bmizerany awesome, i need to read this over, I need more Go in my life. no idea what this is useful for yet though :)",
  "id" : 58269980004859904,
  "in_reply_to_status_id" : 58269519088599040,
  "created_at" : "2011-04-13 20:47:00 +0000",
  "in_reply_to_screen_name" : "bmizerany",
  "in_reply_to_user_id_str" : "2379441",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58268565140287488",
  "text" : "Current Rails community status: http:\/\/blog.ezyang.com\/img\/wrong-on-the-internet\/argument.jpg",
  "id" : 58268565140287488,
  "created_at" : "2011-04-13 20:41:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58261914488291328",
  "text" : "Days like today are where you get to see the difference between blowhards and those who actually work hard on OSS.",
  "id" : 58261914488291328,
  "created_at" : "2011-04-13 20:14:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58261309539618817",
  "text" : "FFS, it's ONE LINE to remove CoffeeScript. Adapt or die, or fuck off and use something else.",
  "id" : 58261309539618817,
  "created_at" : "2011-04-13 20:12:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58261141700349952",
  "text" : "Write your own web framework, you can make the rules. Unless if you're contributing, STFU.",
  "id" : 58261141700349952,
  "created_at" : "2011-04-13 20:11:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58256655204364288",
  "geo" : { },
  "id_str" : "58257301341081600",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal dude have you tried GIRP? http:\/\/www.foddy.net\/GIRP.html",
  "id" : 58257301341081600,
  "in_reply_to_status_id" : 58256655204364288,
  "created_at" : "2011-04-13 19:56:37 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 10, 20 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58227556784144385",
  "text" : "As usual, @joeferris strikes again with some awesome OSS: http:\/\/robots.thoughtbot.com\/post\/4583605733\/capybara-webkit",
  "id" : 58227556784144385,
  "created_at" : "2011-04-13 17:58:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dubstepza",
      "screen_name" : "Dubstepza",
      "indices" : [ 31, 41 ],
      "id_str" : "141272123",
      "id" : 141272123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58217626677153792",
  "text" : "The bass isn't up high enough. @dubstepza what have you done to me :(",
  "id" : 58217626677153792,
  "created_at" : "2011-04-13 17:18:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Jarvis",
      "screen_name" : "lee_jarvis",
      "indices" : [ 0, 11 ],
      "id_str" : "137640366",
      "id" : 137640366
    }, {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 12, 18 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58187423028490241",
  "geo" : { },
  "id_str" : "58187592100880384",
  "in_reply_to_user_id" : 137640366,
  "text" : "@lee_jarvis @wfarr http:\/\/stackoverflow.com\/questions\/171563\/whats-in-your-zshrc\/904023#904023",
  "id" : 58187592100880384,
  "in_reply_to_status_id" : 58187423028490241,
  "created_at" : "2011-04-13 15:19:37 +0000",
  "in_reply_to_screen_name" : "lee_jarvis",
  "in_reply_to_user_id_str" : "137640366",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58186884710547456",
  "text" : "Current zsh status: https:\/\/img.skitch.com\/20110413-jbqxbtn5xw5f1nrxaatn8x3rya.gif",
  "id" : 58186884710547456,
  "created_at" : "2011-04-13 15:16:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby Inside",
      "screen_name" : "RubyInside",
      "indices" : [ 0, 11 ],
      "id_str" : "15851832",
      "id" : 15851832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57985182178885632",
  "geo" : { },
  "id_str" : "57986585534271488",
  "in_reply_to_user_id" : 15851832,
  "text" : "@RubyInside be a jerk",
  "id" : 57986585534271488,
  "in_reply_to_status_id" : 57985182178885632,
  "created_at" : "2011-04-13 02:00:53 +0000",
  "in_reply_to_screen_name" : "RubyInside",
  "in_reply_to_user_id_str" : "15851832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57974925822148608",
  "geo" : { },
  "id_str" : "57975364277903360",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza i dont have the proper headphones for this",
  "id" : 57975364277903360,
  "in_reply_to_status_id" : 57974925822148608,
  "created_at" : "2011-04-13 01:16:18 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Walsh",
      "screen_name" : "evanwalsh",
      "indices" : [ 0, 10 ],
      "id_str" : "1684831",
      "id" : 1684831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57947495501791232",
  "geo" : { },
  "id_str" : "57975100921753601",
  "in_reply_to_user_id" : 1684831,
  "text" : "@evanwalsh i'm totally getting that tshirt. preparing for halloween already.",
  "id" : 57975100921753601,
  "in_reply_to_status_id" : 57947495501791232,
  "created_at" : "2011-04-13 01:15:15 +0000",
  "in_reply_to_screen_name" : "evanwalsh",
  "in_reply_to_user_id_str" : "1684831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 87, 99 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57973869759307776",
  "text" : "Alright what is this dubstep nonsense and what should I listen to? I'm looking at you, @SteveStreza.",
  "id" : 57973869759307776,
  "created_at" : "2011-04-13 01:10:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Epic Meal Time",
      "screen_name" : "EpicMealTime",
      "indices" : [ 21, 34 ],
      "id_str" : "209169572",
      "id" : 209169572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57945556567334913",
  "text" : "Dude spotted with an @EpicMealTime shirt in this bar. Fuckin' smart.",
  "id" : 57945556567334913,
  "created_at" : "2011-04-12 23:17:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Roche",
      "screen_name" : "tedroche",
      "indices" : [ 0, 9 ],
      "id_str" : "14353681",
      "id" : 14353681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57895930543874048",
  "geo" : { },
  "id_str" : "57896584960151555",
  "in_reply_to_user_id" : 14353681,
  "text" : "@tedroche That's terrible.",
  "id" : 57896584960151555,
  "in_reply_to_status_id" : 57895930543874048,
  "created_at" : "2011-04-12 20:03:16 +0000",
  "in_reply_to_screen_name" : "tedroche",
  "in_reply_to_user_id_str" : "14353681",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57895529572614144",
  "text" : "Current status: http:\/\/www.youtube.com\/watch?v=GlKL_EpnSp8",
  "id" : 57895529572614144,
  "created_at" : "2011-04-12 19:59:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57831815616016384",
  "geo" : { },
  "id_str" : "57833260306272256",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu not sure how one would deduce that :)",
  "id" : 57833260306272256,
  "in_reply_to_status_id" : 57831815616016384,
  "created_at" : "2011-04-12 15:51:38 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57831815616016384",
  "geo" : { },
  "id_str" : "57833204811431936",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu it doesn't",
  "id" : 57833204811431936,
  "in_reply_to_status_id" : 57831815616016384,
  "created_at" : "2011-04-12 15:51:25 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57826449473810432",
  "geo" : { },
  "id_str" : "57828353935290368",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu Wha?",
  "id" : 57828353935290368,
  "in_reply_to_status_id" : 57826449473810432,
  "created_at" : "2011-04-12 15:32:08 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57824414988902400",
  "geo" : { },
  "id_str" : "57825375560024064",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier https:\/\/www.apptrajectory.com\/plans looks like we need to link to this more prominently :)",
  "id" : 57825375560024064,
  "in_reply_to_status_id" : 57824414988902400,
  "created_at" : "2011-04-12 15:20:18 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57824930485649408",
  "geo" : { },
  "id_str" : "57825144713916416",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh https:\/\/www.apptrajectory.com\/plans",
  "id" : 57825144713916416,
  "in_reply_to_status_id" : 57824930485649408,
  "created_at" : "2011-04-12 15:19:23 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 118 ],
      "url" : "http:\/\/t.co\/0dgfwS4",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/4212265966\/launching-trajectory-communication-builds-better",
      "display_url" : "robots.thoughtbot.com\/post\/421226596\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "57823594444632064",
  "text" : "RT @thoughtbot: We're pleased to announce Trajectory, the project communication and planning tool. http:\/\/t.co\/0dgfwS4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 102 ],
        "url" : "http:\/\/t.co\/0dgfwS4",
        "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/4212265966\/launching-trajectory-communication-builds-better",
        "display_url" : "robots.thoughtbot.com\/post\/421226596\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "57822801528233984",
    "text" : "We're pleased to announce Trajectory, the project communication and planning tool. http:\/\/t.co\/0dgfwS4",
    "id" : 57822801528233984,
    "created_at" : "2011-04-12 15:10:04 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 57823594444632064,
  "created_at" : "2011-04-12 15:13:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57815840673902592",
  "geo" : { },
  "id_str" : "57818230819008513",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu ah, disregard then!",
  "id" : 57818230819008513,
  "in_reply_to_status_id" : 57815840673902592,
  "created_at" : "2011-04-12 14:51:55 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57815156394176513",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu why did he *rewrite*. more folks need to understand what Ruby gives them already :(",
  "id" : 57815156394176513,
  "created_at" : "2011-04-12 14:39:42 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57814738377252867",
  "geo" : { },
  "id_str" : "57815051922448384",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu cool, keep me posted on how it goes!",
  "id" : 57815051922448384,
  "in_reply_to_status_id" : 57814738377252867,
  "created_at" : "2011-04-12 14:39:17 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57814562895953920",
  "geo" : { },
  "id_str" : "57814873681301506",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu why did he write Rack::Directory? *facepalm*",
  "id" : 57814873681301506,
  "in_reply_to_status_id" : 57814562895953920,
  "created_at" : "2011-04-12 14:38:34 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Behrens",
      "screen_name" : "AskedRelic",
      "indices" : [ 0, 11 ],
      "id_str" : "5539522",
      "id" : 5539522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57790125400260608",
  "geo" : { },
  "id_str" : "57793017876201472",
  "in_reply_to_user_id" : 5539522,
  "text" : "@AskedRelic CHAI'HULUD!",
  "id" : 57793017876201472,
  "in_reply_to_status_id" : 57790125400260608,
  "created_at" : "2011-04-12 13:11:43 +0000",
  "in_reply_to_screen_name" : "AskedRelic",
  "in_reply_to_user_id_str" : "5539522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Graham",
      "screen_name" : "grahams",
      "indices" : [ 0, 8 ],
      "id_str" : "758727",
      "id" : 758727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57627662314782720",
  "geo" : { },
  "id_str" : "57627838408425472",
  "in_reply_to_user_id" : 758727,
  "text" : "@grahams yeah, moving to Waltham soon. today was a nightmare with the sox game.",
  "id" : 57627838408425472,
  "in_reply_to_status_id" : 57627662314782720,
  "created_at" : "2011-04-12 02:15:22 +0000",
  "in_reply_to_screen_name" : "grahams",
  "in_reply_to_user_id_str" : "758727",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Graham",
      "screen_name" : "grahams",
      "indices" : [ 3, 11 ],
      "id_str" : "758727",
      "id" : 758727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57627470979010560",
  "text" : "RT @grahams: http:\/\/howfuckedisthet.com\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57627248831889408",
    "text" : "http:\/\/howfuckedisthet.com\/",
    "id" : 57627248831889408,
    "created_at" : "2011-04-12 02:13:01 +0000",
    "user" : {
      "name" : "Sean Graham",
      "screen_name" : "grahams",
      "protected" : false,
      "id_str" : "758727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1759661499\/image1326737842_normal.png",
      "id" : 758727,
      "verified" : false
    }
  },
  "id" : 57627470979010560,
  "created_at" : "2011-04-12 02:13:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Graham",
      "screen_name" : "grahams",
      "indices" : [ 0, 8 ],
      "id_str" : "758727",
      "id" : 758727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57627248831889408",
  "geo" : { },
  "id_str" : "57627453786558465",
  "in_reply_to_user_id" : 758727,
  "text" : "@grahams LOL at the green line!!",
  "id" : 57627453786558465,
  "in_reply_to_status_id" : 57627248831889408,
  "created_at" : "2011-04-12 02:13:50 +0000",
  "in_reply_to_screen_name" : "grahams",
  "in_reply_to_user_id_str" : "758727",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Chamberlin",
      "screen_name" : "FunkyLarma",
      "indices" : [ 0, 11 ],
      "id_str" : "24923",
      "id" : 24923
    }, {
      "name" : "A Curious Mind",
      "screen_name" : "drusellers",
      "indices" : [ 76, 87 ],
      "id_str" : "9238852",
      "id" : 9238852
    }, {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 92, 105 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57456060826525697",
  "geo" : { },
  "id_str" : "57627377173405696",
  "in_reply_to_user_id" : 24923,
  "text" : "@FunkyLarma Nothing wrong with some friendly inspiration! besides, I bugged @drusellers and @ferventcoder enough about it :)",
  "id" : 57627377173405696,
  "in_reply_to_status_id" : 57456060826525697,
  "created_at" : "2011-04-12 02:13:32 +0000",
  "in_reply_to_screen_name" : "FunkyLarma",
  "in_reply_to_user_id_str" : "24923",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57570712776482816",
  "text" : "Oh look, it's red sox season again.",
  "id" : 57570712776482816,
  "created_at" : "2011-04-11 22:28:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    }, {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 11, 20 ],
      "id_str" : "148198686",
      "id" : 148198686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57553245253537793",
  "geo" : { },
  "id_str" : "57559691114463232",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh @dnsimple hands down.",
  "id" : 57559691114463232,
  "in_reply_to_status_id" : 57553245253537793,
  "created_at" : "2011-04-11 21:44:34 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57498395983613952",
  "geo" : { },
  "id_str" : "57512999614808065",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant hahah WELCOME TO REAL LIFE",
  "id" : 57512999614808065,
  "in_reply_to_status_id" : 57498395983613952,
  "created_at" : "2011-04-11 18:39:02 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57507443881684992",
  "text" : "I wish I could fork Pandora stations. I don't want a new artist to mess up what I have if it turns out poorly.",
  "id" : 57507443881684992,
  "created_at" : "2011-04-11 18:16:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Keepers",
      "screen_name" : "bkeepers",
      "indices" : [ 0, 9 ],
      "id_str" : "697893",
      "id" : 697893
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 10, 16 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57453200487350272",
  "geo" : { },
  "id_str" : "57455025659711488",
  "in_reply_to_user_id" : 697893,
  "text" : "@bkeepers @cmeik \"It was conceived in August, 2009 during a whiskey-induced evening...\" actually explains a lot about it :(",
  "id" : 57455025659711488,
  "in_reply_to_status_id" : 57453200487350272,
  "created_at" : "2011-04-11 14:48:40 +0000",
  "in_reply_to_screen_name" : "bkeepers",
  "in_reply_to_user_id_str" : "697893",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57446543380320256",
  "text" : "Current status: http:\/\/28.media.tumblr.com\/tumblr_ljh0b5LSyK1qzh5gno1_500.jpg",
  "id" : 57446543380320256,
  "created_at" : "2011-04-11 14:14:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57434023844265984",
  "geo" : { },
  "id_str" : "57435491569631232",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek 'rvm gem install' will do that",
  "id" : 57435491569631232,
  "in_reply_to_status_id" : 57434023844265984,
  "created_at" : "2011-04-11 13:31:02 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Guterl",
      "screen_name" : "mguterl",
      "indices" : [ 0, 8 ],
      "id_str" : "15404880",
      "id" : 15404880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57423075460919296",
  "geo" : { },
  "id_str" : "57433345855991808",
  "in_reply_to_user_id" : 15404880,
  "text" : "@mguterl yeah, I wonder if a service could be even easier.",
  "id" : 57433345855991808,
  "in_reply_to_status_id" : 57423075460919296,
  "created_at" : "2011-04-11 13:22:31 +0000",
  "in_reply_to_screen_name" : "mguterl",
  "in_reply_to_user_id_str" : "15404880",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57278286086156288",
  "text" : "More for redirecting subdomains, other sites, google juice...not 302's, 301's",
  "id" : 57278286086156288,
  "created_at" : "2011-04-11 03:06:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57278069504868352",
  "text" : "How often have you written an HTTP redirector?",
  "id" : 57278069504868352,
  "created_at" : "2011-04-11 03:05:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Remolt",
      "screen_name" : "mremolt",
      "indices" : [ 0, 8 ],
      "id_str" : "55243438",
      "id" : 55243438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57184804436836352",
  "geo" : { },
  "id_str" : "57196297568010240",
  "in_reply_to_user_id" : 55243438,
  "text" : "@mremolt terrified I would like it! Not sold yet. I need to look more into node or erlang",
  "id" : 57196297568010240,
  "in_reply_to_status_id" : 57184804436836352,
  "created_at" : "2011-04-10 21:40:34 +0000",
  "in_reply_to_screen_name" : "mremolt",
  "in_reply_to_user_id_str" : "55243438",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57181209322733568",
  "text" : "That site is going to be really boring, as I'm not paying extra to keep the tweets streamin'. The `tweetstream` gem is awesome though.",
  "id" : 57181209322733568,
  "created_at" : "2011-04-10 20:40:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bcb6",
      "indices" : [ 3, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57180966686425090",
  "text" : "My #bcb6 programming contest entry: http:\/\/nathanlanevsraptor.heroku.com\/ https:\/\/github.com\/qrush\/nathanlanevsraptor",
  "id" : 57180966686425090,
  "created_at" : "2011-04-10 20:39:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57157041843744768",
  "text" : "The amount of duplication of efforts in different languages, especially with web frameworks, is frightening.",
  "id" : 57157041843744768,
  "created_at" : "2011-04-10 19:04:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bcb6",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57151276294733824",
  "text" : "Learning about django at #bcb6...slightly terrified!",
  "id" : 57151276294733824,
  "created_at" : "2011-04-10 18:41:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bcb6",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57120352827998208",
  "text" : "Learning about XMPP at #bcb6. Slowly learning I should never write my own messaging protocol.",
  "id" : 57120352827998208,
  "created_at" : "2011-04-10 16:38:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57110993033109504",
  "geo" : { },
  "id_str" : "57120227741274112",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant sweet! pumped, we should play",
  "id" : 57120227741274112,
  "in_reply_to_status_id" : 57110993033109504,
  "created_at" : "2011-04-10 16:38:18 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bcb6",
      "indices" : [ 46, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57096505730924545",
  "text" : "Debating if I should reprise a Redis talk for #bcb6...anyone interested?",
  "id" : 57096505730924545,
  "created_at" : "2011-04-10 15:04:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57065771515392000",
  "geo" : { },
  "id_str" : "57081902468833280",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez do you have a public list somewhere of what you have already? Would love to help out.",
  "id" : 57081902468833280,
  "in_reply_to_status_id" : 57065771515392000,
  "created_at" : "2011-04-10 14:06:00 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bcb6",
      "indices" : [ 15, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57078590398939136",
  "text" : "Heading out to #bcb6! Holy crap it's nice out!",
  "id" : 57078590398939136,
  "created_at" : "2011-04-10 13:52:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Denneen",
      "screen_name" : "cdenneen",
      "indices" : [ 0, 9 ],
      "id_str" : "9485892",
      "id" : 9485892
    }, {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 14, 23 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56949248352190464",
  "geo" : { },
  "id_str" : "57071343522430976",
  "in_reply_to_user_id" : 9485892,
  "text" : "@cdenneen for @gitready? not sure what site you're talking about. feel free to email me (nick@quaran.to) about this",
  "id" : 57071343522430976,
  "in_reply_to_status_id" : 56949248352190464,
  "created_at" : "2011-04-10 13:24:03 +0000",
  "in_reply_to_screen_name" : "cdenneen",
  "in_reply_to_user_id_str" : "9485892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Denneen",
      "screen_name" : "cdenneen",
      "indices" : [ 0, 9 ],
      "id_str" : "9485892",
      "id" : 9485892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56911189388697600",
  "geo" : { },
  "id_str" : "56936317090672640",
  "in_reply_to_user_id" : 9485892,
  "text" : "@cdenneen what?",
  "id" : 56936317090672640,
  "in_reply_to_status_id" : 56911189388697600,
  "created_at" : "2011-04-10 04:27:30 +0000",
  "in_reply_to_screen_name" : "cdenneen",
  "in_reply_to_user_id_str" : "9485892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56873814893662208",
  "text" : "EPIC CUSTOM SWEET POTATO FRIES TIME http:\/\/yfrog.com\/h23j4npj",
  "id" : 56873814893662208,
  "created_at" : "2011-04-10 00:19:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56872844184915968",
  "text" : "RT @bquarant: Today, my dad learned that raisins are dried grapes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56872135687278592",
    "text" : "Today, my dad learned that raisins are dried grapes",
    "id" : 56872135687278592,
    "created_at" : "2011-04-10 00:12:28 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 56872844184915968,
  "created_at" : "2011-04-10 00:15:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56601281275494400",
  "text" : "Really sick of this fucking bug. Time series and graphing is mind-numbingly hard.",
  "id" : 56601281275494400,
  "created_at" : "2011-04-09 06:16:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56580049700265984",
  "geo" : { },
  "id_str" : "56580754423025664",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant good luck dude!",
  "id" : 56580754423025664,
  "in_reply_to_status_id" : 56580049700265984,
  "created_at" : "2011-04-09 04:54:37 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56579501500547072",
  "text" : "I am so sick of this bug. It's one of these terrible ones :(",
  "id" : 56579501500547072,
  "created_at" : "2011-04-09 04:49:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56568020776136704",
  "geo" : { },
  "id_str" : "56568832944386048",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits Home. ALLLLLLLLLRIGHT GIGGITY",
  "id" : 56568832944386048,
  "in_reply_to_status_id" : 56568020776136704,
  "created_at" : "2011-04-09 04:07:15 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56556582502268928",
  "text" : "Holy shit, I need to pay more attention to the Sabres.",
  "id" : 56556582502268928,
  "created_at" : "2011-04-09 03:18:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56540351850229761",
  "text" : "Anyone else pumped for BarCampBoston tomorrow? Who's going?",
  "id" : 56540351850229761,
  "created_at" : "2011-04-09 02:14:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dannytatom",
      "screen_name" : "dannytatom",
      "indices" : [ 0, 11 ],
      "id_str" : "2500287421",
      "id" : 2500287421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56446906049630208",
  "geo" : { },
  "id_str" : "56506515686834176",
  "in_reply_to_user_id" : 17012066,
  "text" : "@dannytatom why not contribute to hubdroid?",
  "id" : 56506515686834176,
  "in_reply_to_status_id" : 56446906049630208,
  "created_at" : "2011-04-08 23:59:37 +0000",
  "in_reply_to_screen_name" : "rabitrup",
  "in_reply_to_user_id_str" : "17012066",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56351649018548224",
  "text" : "Current git status: http:\/\/30.media.tumblr.com\/tumblr_ljb7dbfNr11qba9rro1_500.gif",
  "id" : 56351649018548224,
  "created_at" : "2011-04-08 13:44:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Donnelly",
      "screen_name" : "dunalar",
      "indices" : [ 49, 57 ],
      "id_str" : "32317282",
      "id" : 32317282
    }, {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 97, 109 ],
      "id_str" : "248477732",
      "id" : 248477732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56209182403215360",
  "text" : "Watching question boxes and trees popping out of @dunalar's chest! (fixed!!) http:\/\/is.gd\/XaIxvS @ecarlsen912 this is awesome!!",
  "id" : 56209182403215360,
  "created_at" : "2011-04-08 04:18:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56187616730693632",
  "text" : "FUCK YEAH FILED MY TAXES LIKE A GROWN UP",
  "id" : 56187616730693632,
  "created_at" : "2011-04-08 02:52:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dannytatom",
      "screen_name" : "dannytatom",
      "indices" : [ 0, 11 ],
      "id_str" : "2500287421",
      "id" : 2500287421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56161254397583360",
  "geo" : { },
  "id_str" : "56163383048798208",
  "in_reply_to_user_id" : 17012066,
  "text" : "@dannytatom flipped to straight up java.",
  "id" : 56163383048798208,
  "in_reply_to_status_id" : 56161254397583360,
  "created_at" : "2011-04-08 01:16:08 +0000",
  "in_reply_to_screen_name" : "rabitrup",
  "in_reply_to_user_id_str" : "17012066",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56152284186415105",
  "text" : "Current status: http:\/\/29.media.tumblr.com\/tumblr_ljahg2Dj9Z1qzz0iho1_500.jpg",
  "id" : 56152284186415105,
  "created_at" : "2011-04-08 00:32:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56069747611140096",
  "geo" : { },
  "id_str" : "56072275744669696",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson Thanks making uninstall easy, not many devs think of that. I'd love to see it work :)",
  "id" : 56072275744669696,
  "in_reply_to_status_id" : 56069747611140096,
  "created_at" : "2011-04-07 19:14:06 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 0, 9 ],
      "id_str" : "616163",
      "id" : 616163
    }, {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 10, 22 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56068487629639680",
  "geo" : { },
  "id_str" : "56069246370856960",
  "in_reply_to_user_id" : 616163,
  "text" : "@joshpeek @sstephenson also, explain to me again why running rails apps requires node?",
  "id" : 56069246370856960,
  "in_reply_to_status_id" : 56068487629639680,
  "created_at" : "2011-04-07 19:02:04 +0000",
  "in_reply_to_screen_name" : "joshpeek",
  "in_reply_to_user_id_str" : "616163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56066314866929664",
  "geo" : { },
  "id_str" : "56069169745100802",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson yep, nothing after reboot",
  "id" : 56069169745100802,
  "in_reply_to_status_id" : 56066314866929664,
  "created_at" : "2011-04-07 19:01:46 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56066314866929664",
  "geo" : { },
  "id_str" : "56068161170186240",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson those files exist. i would have much preferred this to be in \/usr\/local, but whatevs. maybe i'll try rebooting.",
  "id" : 56068161170186240,
  "in_reply_to_status_id" : 56066314866929664,
  "created_at" : "2011-04-07 18:57:45 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56065355910623232",
  "geo" : { },
  "id_str" : "56065843179683840",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson Nope. how do you start it? There's no \"pow\" on my PATH...this needs a homebrew recipe :( https:\/\/gist.github.com\/908417",
  "id" : 56065843179683840,
  "in_reply_to_status_id" : 56065355910623232,
  "created_at" : "2011-04-07 18:48:33 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56062306118934528",
  "geo" : { },
  "id_str" : "56063001408716800",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson Nothing is running as \"pow\" on my machine, neither of those ports respond to HTTP. pow's files: https:\/\/gist.github.com\/908397",
  "id" : 56063001408716800,
  "in_reply_to_status_id" : 56062306118934528,
  "created_at" : "2011-04-07 18:37:15 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56055859716956160",
  "geo" : { },
  "id_str" : "56061844334452736",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson installed, symlinked, dropped an rvmrc, but *.dev isn't resolving. what gives?",
  "id" : 56061844334452736,
  "in_reply_to_status_id" : 56055859716956160,
  "created_at" : "2011-04-07 18:32:39 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55587451363799040",
  "geo" : { },
  "id_str" : "55609018525302785",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez http:\/\/redis.io\/commands\/object 404'd!",
  "id" : 55609018525302785,
  "in_reply_to_status_id" : 55587451363799040,
  "created_at" : "2011-04-06 12:33:17 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55490513075310593",
  "geo" : { },
  "id_str" : "55491771202945024",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith shareable :( and i really hate most osx desktop apps.",
  "id" : 55491771202945024,
  "in_reply_to_status_id" : 55490513075310593,
  "created_at" : "2011-04-06 04:47:23 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55324948448808960",
  "geo" : { },
  "id_str" : "55491691339202560",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik just put it in the gemcutter gem?",
  "id" : 55491691339202560,
  "in_reply_to_status_id" : 55324948448808960,
  "created_at" : "2011-04-06 04:47:04 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robby Grossman",
      "screen_name" : "freerobby",
      "indices" : [ 0, 10 ],
      "id_str" : "15023866",
      "id" : 15023866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55359961898811392",
  "geo" : { },
  "id_str" : "55488966811598848",
  "in_reply_to_user_id" : 15023866,
  "text" : "@freerobby VICTORY",
  "id" : 55488966811598848,
  "in_reply_to_status_id" : 55359961898811392,
  "created_at" : "2011-04-06 04:36:15 +0000",
  "in_reply_to_screen_name" : "freerobby",
  "in_reply_to_user_id_str" : "15023866",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55488791854592000",
  "text" : "Meant to also say, want to share it with someone else as well.",
  "id" : 55488791854592000,
  "created_at" : "2011-04-06 04:35:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55487853530071040",
  "text" : "Looking for a stupidly simple task manager with a calendar (or milestones). Any suggestions?",
  "id" : 55487853530071040,
  "created_at" : "2011-04-06 04:31:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 17, 28 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55357280052449280",
  "text" : "I found out what @tenderlove does when not maintaining nokogiri http:\/\/www.youtube.com\/watch?v=GaoLU6zKaws",
  "id" : 55357280052449280,
  "created_at" : "2011-04-05 19:52:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55305446298353664",
  "geo" : { },
  "id_str" : "55322915780034561",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik There's not reverse deps yet, several pull requests i need to evaluate first",
  "id" : 55322915780034561,
  "in_reply_to_status_id" : 55305446298353664,
  "created_at" : "2011-04-05 17:36:25 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55299508317339648",
  "text" : "As usual, Dune WINS. http:\/\/danmeth.com\/post\/4365873423\/sandworms",
  "id" : 55299508317339648,
  "created_at" : "2011-04-05 16:03:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Howell",
      "screen_name" : "mxcl",
      "indices" : [ 0, 5 ],
      "id_str" : "3374231",
      "id" : 3374231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55259957939011584",
  "geo" : { },
  "id_str" : "55264752028487680",
  "in_reply_to_user_id" : 3374231,
  "text" : "@mxcl interesting, but won't the dots overrun the space given up there? Especially on vertical vs horizontal",
  "id" : 55264752028487680,
  "in_reply_to_status_id" : 55259957939011584,
  "created_at" : "2011-04-05 13:45:18 +0000",
  "in_reply_to_screen_name" : "mxcl",
  "in_reply_to_user_id_str" : "3374231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Howell",
      "screen_name" : "mxcl",
      "indices" : [ 0, 5 ],
      "id_str" : "3374231",
      "id" : 3374231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55258497507524609",
  "in_reply_to_user_id" : 3374231,
  "text" : "@mxcl is there a limit on how many columns the android tweetdeck column can have?",
  "id" : 55258497507524609,
  "created_at" : "2011-04-05 13:20:27 +0000",
  "in_reply_to_screen_name" : "mxcl",
  "in_reply_to_user_id_str" : "3374231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55257308871131136",
  "geo" : { },
  "id_str" : "55258296956878848",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant sweet dude, let me know!",
  "id" : 55258296956878848,
  "in_reply_to_status_id" : 55257308871131136,
  "created_at" : "2011-04-05 13:19:39 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55101509288996865",
  "geo" : { },
  "id_str" : "55135106934915072",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant yeah dude, it's awesome. :) need some help with it?",
  "id" : 55135106934915072,
  "in_reply_to_status_id" : 55101509288996865,
  "created_at" : "2011-04-05 05:10:08 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 50, 55 ],
      "id_str" : "734493",
      "id" : 734493
    }, {
      "name" : "Woot-Off!",
      "screen_name" : "wootoff",
      "indices" : [ 69, 77 ],
      "id_str" : "20557892",
      "id" : 20557892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55132971639906304",
  "text" : "Why is it the nights I linger on just to see what @woot has are when @wootoff's happen?",
  "id" : 55132971639906304,
  "created_at" : "2011-04-05 05:01:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Hart",
      "screen_name" : "Hates_",
      "indices" : [ 0, 7 ],
      "id_str" : "6328872",
      "id" : 6328872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55023383452205056",
  "geo" : { },
  "id_str" : "55025637592793089",
  "in_reply_to_user_id" : 6328872,
  "text" : "@Hates_ nope ;)",
  "id" : 55025637592793089,
  "in_reply_to_status_id" : 55023383452205056,
  "created_at" : "2011-04-04 21:55:08 +0000",
  "in_reply_to_screen_name" : "Hates_",
  "in_reply_to_user_id_str" : "6328872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Boback",
      "screen_name" : "snarebyte",
      "indices" : [ 0, 10 ],
      "id_str" : "14777864",
      "id" : 14777864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54991127748689920",
  "geo" : { },
  "id_str" : "54991691744153600",
  "in_reply_to_user_id" : 14777864,
  "text" : "@snarebyte SHUFFLIN SHUFFLINSHUFFLINSHUFFLIN SHUFFLIN SHUFFLIN",
  "id" : 54991691744153600,
  "in_reply_to_status_id" : 54991127748689920,
  "created_at" : "2011-04-04 19:40:15 +0000",
  "in_reply_to_screen_name" : "snarebyte",
  "in_reply_to_user_id_str" : "14777864",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Fromm",
      "screen_name" : "frommww",
      "indices" : [ 0, 8 ],
      "id_str" : "20617489",
      "id" : 20617489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54969721333882880",
  "geo" : { },
  "id_str" : "54970695838478336",
  "in_reply_to_user_id" : 20617489,
  "text" : "@frommww there's no vendor lock-in for most of heroku's addons, you can run them in an OSS manner outside of heroku with barely any pain",
  "id" : 54970695838478336,
  "in_reply_to_status_id" : 54969721333882880,
  "created_at" : "2011-04-04 18:16:49 +0000",
  "in_reply_to_screen_name" : "frommww",
  "in_reply_to_user_id_str" : "20617489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Fromm",
      "screen_name" : "frommww",
      "indices" : [ 0, 8 ],
      "id_str" : "20617489",
      "id" : 20617489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54969721333882880",
  "geo" : { },
  "id_str" : "54970561041936384",
  "in_reply_to_user_id" : 20617489,
  "text" : "@frommww my #1 concern is making sure the jobs i would write work on systems outside of yours, injecting custom code is the wrong way to go",
  "id" : 54970561041936384,
  "in_reply_to_status_id" : 54969721333882880,
  "created_at" : "2011-04-04 18:16:17 +0000",
  "in_reply_to_screen_name" : "frommww",
  "in_reply_to_user_id_str" : "20617489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Fromm",
      "screen_name" : "frommww",
      "indices" : [ 0, 8 ],
      "id_str" : "20617489",
      "id" : 20617489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54969721333882880",
  "geo" : { },
  "id_str" : "54970452958920704",
  "in_reply_to_user_id" : 20617489,
  "text" : "@frommww that feature looks terrifying. why can't you support bundler instead of some custom Kernel hack?",
  "id" : 54970452958920704,
  "in_reply_to_status_id" : 54969721333882880,
  "created_at" : "2011-04-04 18:15:51 +0000",
  "in_reply_to_screen_name" : "frommww",
  "in_reply_to_user_id_str" : "20617489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Fromm",
      "screen_name" : "frommww",
      "indices" : [ 0, 8 ],
      "id_str" : "20617489",
      "id" : 20617489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54966465249554432",
  "geo" : { },
  "id_str" : "54968318855094274",
  "in_reply_to_user_id" : 20617489,
  "text" : "@frommww signed up, did the hello world example, ran it, uploaded, failed. something about \"code.zip\" not found",
  "id" : 54968318855094274,
  "in_reply_to_status_id" : 54966465249554432,
  "created_at" : "2011-04-04 18:07:23 +0000",
  "in_reply_to_screen_name" : "frommww",
  "in_reply_to_user_id_str" : "20617489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54889789534638080",
  "geo" : { },
  "id_str" : "54894262969569280",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek have you tried FF4's? It's even worse.",
  "id" : 54894262969569280,
  "in_reply_to_status_id" : 54889789534638080,
  "created_at" : "2011-04-04 13:13:06 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54767693630423040",
  "text" : "The CompSci of knitting: http:\/\/bit.ly\/f3nVUn totally have seen the patterns\/similarities with @ablissfulgal's craftmania",
  "id" : 54767693630423040,
  "created_at" : "2011-04-04 04:50:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freddie Wong",
      "screen_name" : "fwong",
      "indices" : [ 0, 6 ],
      "id_str" : "18963070",
      "id" : 18963070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54760057916755968",
  "geo" : { },
  "id_str" : "54767070059040768",
  "in_reply_to_user_id" : 18963070,
  "text" : "@fwong oh hell yes. Ace rockola traffic and weather! 69 DEGREES! Drew, please.",
  "id" : 54767070059040768,
  "in_reply_to_status_id" : 54760057916755968,
  "created_at" : "2011-04-04 04:47:41 +0000",
  "in_reply_to_screen_name" : "fwong",
  "in_reply_to_user_id_str" : "18963070",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54752775644516352",
  "text" : "This is just beyond cool. http:\/\/jtnimoy.net\/workviewer.php?q=178",
  "id" : 54752775644516352,
  "created_at" : "2011-04-04 03:50:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54696078494277632",
  "geo" : { },
  "id_str" : "54697222733955073",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser cool! can you make sure it's alright with stupidly huge gem names on most browsers? There's css hacks to handle it already :(",
  "id" : 54697222733955073,
  "in_reply_to_status_id" : 54696078494277632,
  "created_at" : "2011-04-04 00:10:08 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54692428086657026",
  "text" : "Just saw a Prius with neon blaring rap music. A Prius.",
  "id" : 54692428086657026,
  "created_at" : "2011-04-03 23:51:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54676995308654592",
  "geo" : { },
  "id_str" : "54689333843730432",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv FUCKIN SMART",
  "id" : 54689333843730432,
  "in_reply_to_status_id" : 54676995308654592,
  "created_at" : "2011-04-03 23:38:47 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Evans",
      "screen_name" : "deadprogram",
      "indices" : [ 0, 12 ],
      "id_str" : "9885222",
      "id" : 9885222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54568046127353859",
  "geo" : { },
  "id_str" : "54572984001757184",
  "in_reply_to_user_id" : 9885222,
  "text" : "@deadprogram didn't even know you could run resque on heroku: http:\/\/blog.redistogo.com\/2010\/07\/26\/resque-with-redis-to-go\/ awesome.",
  "id" : 54572984001757184,
  "in_reply_to_status_id" : 54568046127353859,
  "created_at" : "2011-04-03 15:56:27 +0000",
  "in_reply_to_screen_name" : "deadprogram",
  "in_reply_to_user_id_str" : "9885222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Evans",
      "screen_name" : "deadprogram",
      "indices" : [ 0, 12 ],
      "id_str" : "9885222",
      "id" : 9885222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54568046127353859",
  "geo" : { },
  "id_str" : "54570838783049728",
  "in_reply_to_user_id" : 9885222,
  "text" : "@deadprogram i keep forgetting, heroku's workers are just a process that runs jobs:work and keeps it alive. so it could just be a rake task!",
  "id" : 54570838783049728,
  "in_reply_to_status_id" : 54568046127353859,
  "created_at" : "2011-04-03 15:47:56 +0000",
  "in_reply_to_screen_name" : "deadprogram",
  "in_reply_to_user_id_str" : "9885222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Evans",
      "screen_name" : "deadprogram",
      "indices" : [ 0, 12 ],
      "id_str" : "9885222",
      "id" : 9885222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54566871831289857",
  "geo" : { },
  "id_str" : "54567612478271490",
  "in_reply_to_user_id" : 9885222,
  "text" : "@deadprogram how would that work though? how would you requeue constantly? There's repeated_job as well but that sucks.",
  "id" : 54567612478271490,
  "in_reply_to_status_id" : 54566871831289857,
  "created_at" : "2011-04-03 15:35:07 +0000",
  "in_reply_to_screen_name" : "deadprogram",
  "in_reply_to_user_id_str" : "9885222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 58, 65 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54566751735791616",
  "text" : "I need to run something every minute in the background on @heroku. What are my options? SimpleWorker's helloworld doesn't even work.",
  "id" : 54566751735791616,
  "created_at" : "2011-04-03 15:31:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dogfish Head Brewery",
      "screen_name" : "dogfishbeer",
      "indices" : [ 11, 23 ],
      "id_str" : "16721886",
      "id" : 16721886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54350612783054848",
  "text" : "Awww yeah, @dogfishbeer 60 minute in a Sam Adams science glass (dubbed by @techpickes) is so good",
  "id" : 54350612783054848,
  "created_at" : "2011-04-03 01:12:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54349528509317120",
  "text" : "Oh this takes me back. http:\/\/www.youtube.com\/watch?v=rKCvhA0xWss Some seriously talented dudes on marimba, check out the other videos too!",
  "id" : 54349528509317120,
  "created_at" : "2011-04-03 01:08:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Lavena",
      "screen_name" : "luislavena",
      "indices" : [ 0, 11 ],
      "id_str" : "16891327",
      "id" : 16891327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53960855028629504",
  "geo" : { },
  "id_str" : "54315834830635008",
  "in_reply_to_user_id" : 16891327,
  "text" : "@luislavena i'm standing with evan's call on it. it's ridiculous to me how one person can cause so many headaches, but he's not dead\/MIA :\/",
  "id" : 54315834830635008,
  "in_reply_to_status_id" : 53960855028629504,
  "created_at" : "2011-04-02 22:54:38 +0000",
  "in_reply_to_screen_name" : "luislavena",
  "in_reply_to_user_id_str" : "16891327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54310351528919040",
  "geo" : { },
  "id_str" : "54311030184091648",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser yep, it's definitely the defacto source since anyone can edit it. will add a link to the readme.",
  "id" : 54311030184091648,
  "in_reply_to_status_id" : 54310351528919040,
  "created_at" : "2011-04-02 22:35:33 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54307947253211136",
  "geo" : { },
  "id_str" : "54309907675099136",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser we also have publicly available psql\/redis dumps, I can link to them from that wiki page. Will be on irc shortly.",
  "id" : 54309907675099136,
  "in_reply_to_status_id" : 54307947253211136,
  "created_at" : "2011-04-02 22:31:05 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54302968647921664",
  "geo" : { },
  "id_str" : "54309641169014784",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser there's an entire wiki page for this. Maybe we should link to it from the readme",
  "id" : 54309641169014784,
  "in_reply_to_status_id" : 54302968647921664,
  "created_at" : "2011-04-02 22:30:02 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54044283417796608",
  "text" : "The Android game market is full of uninspired, terribly designed crap. I need more hours in the day to fix this.",
  "id" : 54044283417796608,
  "created_at" : "2011-04-02 04:55:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53794343256997888",
  "text" : "What a great day to be standing in freezing rain with 100 other folks that can't get on the green line.",
  "id" : 53794343256997888,
  "created_at" : "2011-04-01 12:22:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Rudy Jacobs",
      "screen_name" : "matthewrudy",
      "indices" : [ 0, 12 ],
      "id_str" : "7291692",
      "id" : 7291692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53668379986370561",
  "geo" : { },
  "id_str" : "53778482928418816",
  "in_reply_to_user_id" : 7291692,
  "text" : "@matthewrudy ah ha, there is an email. But still...its a volunteer\/community run service dude. :\/",
  "id" : 53778482928418816,
  "in_reply_to_status_id" : 53668379986370561,
  "created_at" : "2011-04-01 11:19:24 +0000",
  "in_reply_to_screen_name" : "matthewrudy",
  "in_reply_to_user_id_str" : "7291692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sinatra",
      "screen_name" : "sinatra",
      "indices" : [ 3, 11 ],
      "id_str" : "19694454",
      "id" : 19694454
    }, {
      "name" : "Blake Mizerany",
      "screen_name" : "bmizerany",
      "indices" : [ 95, 105 ],
      "id_str" : "2379441",
      "id" : 2379441
    }, {
      "name" : "Ruby on Rails",
      "screen_name" : "rails",
      "indices" : [ 114, 120 ],
      "id_str" : "3116191",
      "id" : 3116191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/GCVIHaQ",
      "expanded_url" : "http:\/\/tinyurl.com\/y8b6rtr",
      "display_url" : "tinyurl.com\/y8b6rtr"
    } ]
  },
  "geo" : { },
  "id_str" : "53777616498470913",
  "text" : "RT @sinatra: After Merb, now Sinatra: Uniting the forces - Sinatra gets merged into Rails 3.2! @bmizerany to join @rails core team: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Blake Mizerany",
        "screen_name" : "bmizerany",
        "indices" : [ 82, 92 ],
        "id_str" : "2379441",
        "id" : 2379441
      }, {
        "name" : "Ruby on Rails",
        "screen_name" : "rails",
        "indices" : [ 101, 107 ],
        "id_str" : "3116191",
        "id" : 3116191
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 138 ],
        "url" : "http:\/\/t.co\/GCVIHaQ",
        "expanded_url" : "http:\/\/tinyurl.com\/y8b6rtr",
        "display_url" : "tinyurl.com\/y8b6rtr"
      } ]
    },
    "geo" : { },
    "id_str" : "53738039947706368",
    "text" : "After Merb, now Sinatra: Uniting the forces - Sinatra gets merged into Rails 3.2! @bmizerany to join @rails core team: http:\/\/t.co\/GCVIHaQ",
    "id" : 53738039947706368,
    "created_at" : "2011-04-01 08:38:41 +0000",
    "user" : {
      "name" : "Sinatra",
      "screen_name" : "sinatra",
      "protected" : false,
      "id_str" : "19694454",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/80388980\/logo_normal.png",
      "id" : 19694454,
      "verified" : false
    }
  },
  "id" : 53777616498470913,
  "created_at" : "2011-04-01 11:15:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Rudy Jacobs",
      "screen_name" : "matthewrudy",
      "indices" : [ 0, 12 ],
      "id_str" : "7291692",
      "id" : 7291692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53777124368199680",
  "in_reply_to_user_id" : 7291692,
  "text" : "@matthewrudy  thanks, I wish you would have just emailed this or submitted a github issue. No need to publicize it.",
  "id" : 53777124368199680,
  "created_at" : "2011-04-01 11:14:00 +0000",
  "in_reply_to_screen_name" : "matthewrudy",
  "in_reply_to_user_id_str" : "7291692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
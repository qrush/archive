Grailbird.data.tweets_2015_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "friendly catduck\u2122",
      "screen_name" : "duckinator",
      "indices" : [ 0, 11 ],
      "id_str" : "28650670",
      "id" : 28650670
    }, {
      "name" : "Elizabeth Wetton",
      "screen_name" : "FluffyPira",
      "indices" : [ 12, 23 ],
      "id_str" : "15384197",
      "id" : 15384197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/biwDqHL2ML",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "in_reply_to_status_id_str" : "571832201832239104",
  "geo" : { },
  "id_str" : "571835527005011968",
  "in_reply_to_user_id" : 28650670,
  "text" : "@duckinator @FluffyPira would gladly welcome more railways on http:\/\/t.co\/biwDqHL2ML!",
  "id" : 571835527005011968,
  "in_reply_to_status_id" : 571832201832239104,
  "created_at" : "2015-03-01 00:53:08 +0000",
  "in_reply_to_screen_name" : "duckinator",
  "in_reply_to_user_id_str" : "28650670",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Smith",
      "screen_name" : "Noahpinion",
      "indices" : [ 3, 14 ],
      "id_str" : "281877818",
      "id" : 281877818
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/andrewchen\/status\/571406694627958784\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/rL0Kj30GGE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-4LXG1UAAAAZFx.png",
      "id_str" : "571406694321750016",
      "id" : 571406694321750016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-4LXG1UAAAAZFx.png",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 735
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 735
      } ],
      "display_url" : "pic.twitter.com\/rL0Kj30GGE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571708732662530048",
  "text" : "RT @Noahpinion: Best argument I've ever seen for self-driving cars and public transit: http:\/\/t.co\/rL0Kj30GGE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/andrewchen\/status\/571406694627958784\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/rL0Kj30GGE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-4LXG1UAAAAZFx.png",
        "id_str" : "571406694321750016",
        "id" : 571406694321750016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-4LXG1UAAAAZFx.png",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 735
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 735
        } ],
        "display_url" : "pic.twitter.com\/rL0Kj30GGE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571408263226507264",
    "text" : "Best argument I've ever seen for self-driving cars and public transit: http:\/\/t.co\/rL0Kj30GGE",
    "id" : 571408263226507264,
    "created_at" : "2015-02-27 20:35:20 +0000",
    "user" : {
      "name" : "Noah Smith",
      "screen_name" : "Noahpinion",
      "protected" : false,
      "id_str" : "281877818",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563230651785043970\/dBCw3FAM_normal.jpeg",
      "id" : 281877818,
      "verified" : false
    }
  },
  "id" : 571708732662530048,
  "created_at" : "2015-02-28 16:29:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slack",
      "screen_name" : "SlackHQ",
      "indices" : [ 19, 27 ],
      "id_str" : "1305940272",
      "id" : 1305940272
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571682169787039744\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/HbUD0ZaTdg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-8F5xYUsAE5Ne0.png",
      "id_str" : "571682167765381121",
      "id" : 571682167765381121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-8F5xYUsAE5Ne0.png",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1324
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/HbUD0ZaTdg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/biwDqHL2ML",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "571682169787039744",
  "text" : "The \"bot\" style on @SlackHQ now looks a lot cleaner on http:\/\/t.co\/biwDqHL2ML http:\/\/t.co\/HbUD0ZaTdg",
  "id" : 571682169787039744,
  "created_at" : "2015-02-28 14:43:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Summer Ray",
      "screen_name" : "SummerRay",
      "indices" : [ 3, 13 ],
      "id_str" : "20446632",
      "id" : 20446632
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SummerRay\/status\/452759202084442112\/photo\/1",
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/N6flOl2Wc7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkiGGGYIUAAjIe-.jpg",
      "id_str" : "452759201899892736",
      "id" : 452759201899892736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkiGGGYIUAAjIe-.jpg",
      "sizes" : [ {
        "h" : 1097,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 1060
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/N6flOl2Wc7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571666983399247873",
  "text" : "RT @SummerRay: Stuck for a name for your band? Type nonsense into your iPhone text box and let autocorrect work its magic. http:\/\/t.co\/N6fl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SummerRay\/status\/452759202084442112\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/N6flOl2Wc7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkiGGGYIUAAjIe-.jpg",
        "id_str" : "452759201899892736",
        "id" : 452759201899892736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkiGGGYIUAAjIe-.jpg",
        "sizes" : [ {
          "h" : 1097,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 1060
        }, {
          "h" : 364,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 643,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/N6flOl2Wc7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "452759202084442112",
    "text" : "Stuck for a name for your band? Type nonsense into your iPhone text box and let autocorrect work its magic. http:\/\/t.co\/N6flOl2Wc7",
    "id" : 452759202084442112,
    "created_at" : "2014-04-06 10:46:20 +0000",
    "user" : {
      "name" : "Summer Ray",
      "screen_name" : "SummerRay",
      "protected" : false,
      "id_str" : "20446632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564879064562147328\/i_rcKSLW_normal.jpeg",
      "id" : 20446632,
      "verified" : false
    }
  },
  "id" : 571666983399247873,
  "created_at" : "2015-02-28 13:43:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571509665214824448\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/K8Woz8fJNi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-5pAn3UsAIhhfn.jpg",
      "id_str" : "571509662144573442",
      "id" : 571509662144573442,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-5pAn3UsAIhhfn.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/K8Woz8fJNi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571509665214824448",
  "text" : "Packed continent http:\/\/t.co\/K8Woz8fJNi",
  "id" : 571509665214824448,
  "created_at" : "2015-02-28 03:18:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 3, 9 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/phish\/status\/571475738920009728\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/LDTFY1dVKI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-5KJx-VIAED5pv.jpg",
      "id_str" : "571475734616678401",
      "id" : 571475734616678401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-5KJx-VIAED5pv.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/LDTFY1dVKI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571476990747807744",
  "text" : "RT @phish: http:\/\/t.co\/LDTFY1dVKI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/phish\/status\/571475738920009728\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/LDTFY1dVKI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-5KJx-VIAED5pv.jpg",
        "id_str" : "571475734616678401",
        "id" : 571475734616678401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-5KJx-VIAED5pv.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/LDTFY1dVKI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571475738920009728",
    "text" : "http:\/\/t.co\/LDTFY1dVKI",
    "id" : 571475738920009728,
    "created_at" : "2015-02-28 01:03:28 +0000",
    "user" : {
      "name" : "Phish",
      "screen_name" : "phish",
      "protected" : false,
      "id_str" : "14503997",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524599876630216704\/KczioeHn_normal.jpeg",
      "id" : 14503997,
      "verified" : true
    }
  },
  "id" : 571476990747807744,
  "created_at" : "2015-02-28 01:08:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/BqFdNe7Av1",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=AGF5ROpjRAU",
      "display_url" : "youtube.com\/watch?v=AGF5RO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571358415580233728",
  "text" : "RIP https:\/\/t.co\/BqFdNe7Av1",
  "id" : 571358415580233728,
  "created_at" : "2015-02-27 17:17:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USCGNortheast",
      "screen_name" : "USCGNortheast",
      "indices" : [ 3, 17 ],
      "id_str" : "17648905",
      "id" : 17648905
    }, {
      "name" : "FOX 25 News Boston",
      "screen_name" : "fox25news",
      "indices" : [ 88, 98 ],
      "id_str" : "19665244",
      "id" : 19665244
    }, {
      "name" : "WBUR",
      "screen_name" : "WBUR",
      "indices" : [ 99, 104 ],
      "id_str" : "2996801",
      "id" : 2996801
    }, {
      "name" : "USCG (Official)",
      "screen_name" : "USCG",
      "indices" : [ 105, 110 ],
      "id_str" : "15113565",
      "id" : 15113565
    }, {
      "name" : "necn",
      "screen_name" : "NECN",
      "indices" : [ 117, 122 ],
      "id_str" : "9907172",
      "id" : 9907172
    }, {
      "name" : "The Boston Globe",
      "screen_name" : "BostonGlobe",
      "indices" : [ 123, 135 ],
      "id_str" : "95431448",
      "id" : 95431448
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/USCGNortheast\/status\/571298711571017729\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/kKK8eKehYj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-2pJT-UIAAvKgF.jpg",
      "id_str" : "571298705191477248",
      "id" : 571298705191477248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-2pJT-UIAAvKgF.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kKK8eKehYj"
    } ],
    "hashtags" : [ {
      "text" : "BostonHarbor",
      "indices" : [ 60, 73 ]
    }, {
      "text" : "uscg",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571316604169908224",
  "text" : "RT @USCGNortheast: ICYMI Coast Guard Cutter spots COYOTE in #BostonHarbor, near Quincy. @fox25news @WBUR @USCG #uscg @NECN @BostonGlobe htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FOX 25 News Boston",
        "screen_name" : "fox25news",
        "indices" : [ 69, 79 ],
        "id_str" : "19665244",
        "id" : 19665244
      }, {
        "name" : "WBUR",
        "screen_name" : "WBUR",
        "indices" : [ 80, 85 ],
        "id_str" : "2996801",
        "id" : 2996801
      }, {
        "name" : "USCG (Official)",
        "screen_name" : "USCG",
        "indices" : [ 86, 91 ],
        "id_str" : "15113565",
        "id" : 15113565
      }, {
        "name" : "necn",
        "screen_name" : "NECN",
        "indices" : [ 98, 103 ],
        "id_str" : "9907172",
        "id" : 9907172
      }, {
        "name" : "The Boston Globe",
        "screen_name" : "BostonGlobe",
        "indices" : [ 104, 116 ],
        "id_str" : "95431448",
        "id" : 95431448
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/USCGNortheast\/status\/571298711571017729\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/kKK8eKehYj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-2pJT-UIAAvKgF.jpg",
        "id_str" : "571298705191477248",
        "id" : 571298705191477248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-2pJT-UIAAvKgF.jpg",
        "sizes" : [ {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kKK8eKehYj"
      } ],
      "hashtags" : [ {
        "text" : "BostonHarbor",
        "indices" : [ 41, 54 ]
      }, {
        "text" : "uscg",
        "indices" : [ 92, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571298711571017729",
    "text" : "ICYMI Coast Guard Cutter spots COYOTE in #BostonHarbor, near Quincy. @fox25news @WBUR @USCG #uscg @NECN @BostonGlobe http:\/\/t.co\/kKK8eKehYj",
    "id" : 571298711571017729,
    "created_at" : "2015-02-27 13:20:01 +0000",
    "user" : {
      "name" : "USCGNortheast",
      "screen_name" : "USCGNortheast",
      "protected" : false,
      "id_str" : "17648905",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492290586188058624\/1Je6I-aa_normal.jpeg",
      "id" : 17648905,
      "verified" : true
    }
  },
  "id" : 571316604169908224,
  "created_at" : "2015-02-27 14:31:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/571040274060701696\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/vKaRVCwTa8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-y-Gj7UYAESw-Y.jpg",
      "id_str" : "571040272701743105",
      "id" : 571040272701743105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-y-Gj7UYAESw-Y.jpg",
      "sizes" : [ {
        "h" : 759,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 444,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 780,
        "resize" : "fit",
        "w" : 1052
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vKaRVCwTa8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571298357869547520",
  "text" : "RT @coworkbuffalo: Communal email anxiety board. http:\/\/t.co\/vKaRVCwTa8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/571040274060701696\/photo\/1",
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/vKaRVCwTa8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-y-Gj7UYAESw-Y.jpg",
        "id_str" : "571040272701743105",
        "id" : 571040272701743105,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-y-Gj7UYAESw-Y.jpg",
        "sizes" : [ {
          "h" : 759,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 444,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 780,
          "resize" : "fit",
          "w" : 1052
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/vKaRVCwTa8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571040274060701696",
    "text" : "Communal email anxiety board. http:\/\/t.co\/vKaRVCwTa8",
    "id" : 571040274060701696,
    "created_at" : "2015-02-26 20:13:05 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 571298357869547520,
  "created_at" : "2015-02-27 13:18:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacky",
      "screen_name" : "jackyalcine",
      "indices" : [ 0, 12 ],
      "id_str" : "44119449",
      "id" : 44119449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571293600966959104",
  "geo" : { },
  "id_str" : "571296514309431296",
  "in_reply_to_user_id" : 44119449,
  "text" : "@jackyalcine for years! Not on github for all that though",
  "id" : 571296514309431296,
  "in_reply_to_status_id" : 571293600966959104,
  "created_at" : "2015-02-27 13:11:17 +0000",
  "in_reply_to_screen_name" : "jackyalcine",
  "in_reply_to_user_id_str" : "44119449",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "alterconf",
      "indices" : [ 6, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/RHz438gc8Q",
      "expanded_url" : "http:\/\/www.alterconf.com\/news\/pain-and-hope-alterconf-sfoakland",
      "display_url" : "alterconf.com\/news\/pain-and-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571287387919118336",
  "text" : "Great #alterconf roundup\/recap from Oakland. Looks like it was fantastic. http:\/\/t.co\/RHz438gc8Q",
  "id" : 571287387919118336,
  "created_at" : "2015-02-27 12:35:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/zrjyJGun6N",
      "expanded_url" : "http:\/\/bit.ly\/1thHjXA",
      "display_url" : "bit.ly\/1thHjXA"
    } ]
  },
  "geo" : { },
  "id_str" : "571287247447724032",
  "text" : "RT @ashedryden: I've got some \u2728paid\u2728 speaking opportunities for marginalized people in tech or gaming. No exp req'd. Spread the word! http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/zrjyJGun6N",
        "expanded_url" : "http:\/\/bit.ly\/1thHjXA",
        "display_url" : "bit.ly\/1thHjXA"
      } ]
    },
    "geo" : { },
    "id_str" : "570400263149727745",
    "text" : "I've got some \u2728paid\u2728 speaking opportunities for marginalized people in tech or gaming. No exp req'd. Spread the word! http:\/\/t.co\/zrjyJGun6N",
    "id" : 570400263149727745,
    "created_at" : "2015-02-25 01:49:54 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 571287247447724032,
  "created_at" : "2015-02-27 12:34:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/wnnVz3GIXQ",
      "expanded_url" : "http:\/\/imgur.com\/a\/jlWDH",
      "display_url" : "imgur.com\/a\/jlWDH"
    } ]
  },
  "geo" : { },
  "id_str" : "571283202221809664",
  "text" : "All my weird dress GIFs in one album. My favorite is solitaire dress. http:\/\/t.co\/wnnVz3GIXQ",
  "id" : 571283202221809664,
  "created_at" : "2015-02-27 12:18:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Swinden",
      "screen_name" : "AdamSwinden",
      "indices" : [ 0, 12 ],
      "id_str" : "112266546",
      "id" : 112266546
    }, {
      "name" : "Simon Willison",
      "screen_name" : "simonw",
      "indices" : [ 13, 20 ],
      "id_str" : "12497",
      "id" : 12497
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571182763258195969\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/B2T9shsW8I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-0_seRUUAEa9wW.jpg",
      "id_str" : "571182761018413057",
      "id" : 571182761018413057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-0_seRUUAEa9wW.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/B2T9shsW8I"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570976064710844416",
  "geo" : { },
  "id_str" : "571182763258195969",
  "in_reply_to_user_id" : 112266546,
  "text" : "@AdamSwinden @simonw I think Big Ben is telling the right time too? http:\/\/t.co\/B2T9shsW8I",
  "id" : 571182763258195969,
  "in_reply_to_status_id" : 570976064710844416,
  "created_at" : "2015-02-27 05:39:17 +0000",
  "in_reply_to_screen_name" : "AdamSwinden",
  "in_reply_to_user_id_str" : "112266546",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571174326906417152\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/gxgmirE2Xk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-04BahVIAA71DN.png",
      "id_str" : "571174324696064000",
      "id" : 571174324696064000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-04BahVIAA71DN.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gxgmirE2Xk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571174326906417152",
  "text" : "At 54 the pancake evolved to a burger http:\/\/t.co\/gxgmirE2Xk",
  "id" : 571174326906417152,
  "created_at" : "2015-02-27 05:05:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571171452302413824\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/iRqpJ3cc5G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-01aGeVIAEpqP8.png",
      "id_str" : "571171450276618241",
      "id" : 571171450276618241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-01aGeVIAEpqP8.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/iRqpJ3cc5G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571171452302413824",
  "text" : "Heartbreak edge http:\/\/t.co\/iRqpJ3cc5G",
  "id" : 571171452302413824,
  "created_at" : "2015-02-27 04:54:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571167044831350784",
  "text" : "To my daughter(?) i bequeath your mothers patience and \uFF47\uFF49\uFF47\uFF41\uFF42\uFF59\uFF54\uFF45\uFF53 \uFF4F\uFF46 \uFF27\uFF29\uFF26\uFF53 \uFF53\uFF4F\uFF52\uFF54\uFF45\uFF44 \uFF42\uFF59 \uFF45\uFF4D\uFF4F\uFF54\uFF49\uFF4F\uFF4E",
  "id" : 571167044831350784,
  "created_at" : "2015-02-27 04:36:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571166001636597760",
  "text" : "To my son(s) I bequeath my gifs folder and weird text generators. May they bring you h\u032A\u0324\u0330\u0324\u0326\u0347a\u032B\u0329\u031E\u034D\u032A\u0359\u032Cp\u032C\u0331\u0348\u0319\u032Ep\u0356\u0347\u0332\u0348\u0354i\u0348n\u0355\u031C\u0348\u032F\u0326\u032Be\u032Es\u032E\u0348\u0326\u034D\u0326\u0355\u032Es\u0318\u031E\u0347\u0349\u0345",
  "id" : 571166001636597760,
  "created_at" : "2015-02-27 04:32:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571162054159151104",
  "geo" : { },
  "id_str" : "571162630305353730",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents a dry ice factory!",
  "id" : 571162630305353730,
  "in_reply_to_status_id" : 571162054159151104,
  "created_at" : "2015-02-27 04:19:17 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571162435584815105\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/OPfawPrTq5",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0tNPgUMAAyxGQ.png",
      "id_str" : "571162433269542912",
      "id" : 571162433269542912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0tNPgUMAAyxGQ.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/OPfawPrTq5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571162435584815105",
  "text" : "\u0E2C\u0452\u0E04t \u03C2\u0E4Fl\u0E4F\u0433 \u0E40\u0E23 t\u0452\u0E40\u0E23 \u0E54\u0433\u0454\u0E23\u0E23 http:\/\/t.co\/OPfawPrTq5",
  "id" : 571162435584815105,
  "created_at" : "2015-02-27 04:18:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571156504167845889\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/fQdSwEWVJl",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0n0D_UMAAT0G1.png",
      "id_str" : "571156503123472384",
      "id" : 571156503123472384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0n0D_UMAAT0G1.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 200
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 200
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 200
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 200
      } ],
      "display_url" : "pic.twitter.com\/fQdSwEWVJl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571156504167845889",
  "text" : "w\u0336h\u0336a\u0336t\u0336 \u0336c\u0336o\u0336l\u0336o\u0336r\u0336 \u0336i\u0336s\u0336 \u0336t\u0336h\u0336i\u0336s\u0336 \u0336d\u0336r\u0336e\u0336s\u0336s\u0336 http:\/\/t.co\/fQdSwEWVJl",
  "id" : 571156504167845889,
  "created_at" : "2015-02-27 03:54:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571152790719848450\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/l138LqLM13",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0kb6CUAAAXzlP.png",
      "id_str" : "571152789599944704",
      "id" : 571152789599944704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0kb6CUAAAXzlP.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 526
      } ],
      "display_url" : "pic.twitter.com\/l138LqLM13"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571152790719848450",
  "text" : "\u02B7\u02B0\u1D43\u1D57 \u1D9C\u1D52\u1DAB\u1D52\u02B3 \u1DA6\u02E2 \u1D57\u02B0\u1DA6\u02E2 \u1D48\u02B3\u1D49\u02E2\u02E2 http:\/\/t.co\/l138LqLM13",
  "id" : 571152790719848450,
  "created_at" : "2015-02-27 03:40:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571150479763206145\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/Y1kGqKkZCv",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0iVQdUAAEj5Zl.png",
      "id_str" : "571150476336431105",
      "id" : 571150476336431105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0iVQdUAAEj5Zl.png",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 264
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 264
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 264
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 264
      } ],
      "display_url" : "pic.twitter.com\/Y1kGqKkZCv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571150479763206145",
  "text" : "ss\u04D9\u0279p s!\u10A1\u0287 s! \u0279o\u10A8o\u0254 \u0287\u0250\u10A1\u028D http:\/\/t.co\/Y1kGqKkZCv",
  "id" : 571150479763206145,
  "created_at" : "2015-02-27 03:31:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571149272978223104\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/FDTZhsQUnt",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0hO-AUEAAOVyO.png",
      "id_str" : "571149268792119296",
      "id" : 571149268792119296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0hO-AUEAAOVyO.png",
      "sizes" : [ {
        "h" : 264,
        "resize" : "fit",
        "w" : 264
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 264
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 264
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 264
      } ],
      "display_url" : "pic.twitter.com\/FDTZhsQUnt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571149272978223104",
  "text" : "\uD835\uDCCC\uD835\uDCBD\uD835\uDCB6\uD835\uDCC9 \uD835\uDCB8\uD835\uDC5C\uD835\uDCC1\uD835\uDC5C\uD835\uDCC7 \uD835\uDCBE\uD835\uDCC8 \uD835\uDCC9\uD835\uDCBD\uD835\uDCBE\uD835\uDCC8 \uD835\uDCB9\uD835\uDCC7\uD835\uDC52\uD835\uDCC8\uD835\uDCC8 http:\/\/t.co\/FDTZhsQUnt",
  "id" : 571149272978223104,
  "created_at" : "2015-02-27 03:26:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571147848323969024\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/eRnFyNNV2K",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0f8EAUMAI79Vy.png",
      "id_str" : "571147844473597954",
      "id" : 571147844473597954,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0f8EAUMAI79Vy.png",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 264
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 264
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 264
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 264
      } ],
      "display_url" : "pic.twitter.com\/eRnFyNNV2K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571147848323969024",
  "text" : "\u24E6\u24D7\u24D0\u24E3 \u24D2\u24DE\u24DB\u24DE\u24E1 \u24D8\u24E2 \u24E3\u24D7\u24D8\u24E2 \u24D3\u24E1\u24D4\u24E2\u24E2 http:\/\/t.co\/eRnFyNNV2K",
  "id" : 571147848323969024,
  "created_at" : "2015-02-27 03:20:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571147429661184000\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/J7bzEBWnvz",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0fjzrUUAAIiar.png",
      "id_str" : "571147427773698048",
      "id" : 571147427773698048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0fjzrUUAAIiar.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/J7bzEBWnvz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571147429661184000",
  "text" : "W\u0321\u035D\u0322h\u034Fa\u0341\u035Ct\u035D\u0489 \u031B\u0361c\u0335o\u0337\u035F\u0338l\u0315o\u0327\u0340r\u0361 \u035E\u0361is\u035E \u0337\u035Eth\u0360is\u035F \u0321\u035Dd\u0335re\u0358\u035Fs\u0361s\u0341\u0341\u0358? http:\/\/t.co\/J7bzEBWnvz",
  "id" : 571147429661184000,
  "created_at" : "2015-02-27 03:18:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571146700288495616\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/YEwqqr42fm",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0e5V7UsAAcKw2.png",
      "id_str" : "571146698233262080",
      "id" : 571146698233262080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B-0e5V7UsAAcKw2.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 526
      } ],
      "display_url" : "pic.twitter.com\/YEwqqr42fm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571146700288495616",
  "text" : "What color is this dress? http:\/\/t.co\/YEwqqr42fm",
  "id" : 571146700288495616,
  "created_at" : "2015-02-27 03:15:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacky",
      "screen_name" : "jackyalcine",
      "indices" : [ 0, 12 ],
      "id_str" : "44119449",
      "id" : 44119449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571144385947164672",
  "geo" : { },
  "id_str" : "571144764923314176",
  "in_reply_to_user_id" : 44119449,
  "text" : "@jackyalcine sign up!",
  "id" : 571144764923314176,
  "in_reply_to_status_id" : 571144385947164672,
  "created_at" : "2015-02-27 03:08:17 +0000",
  "in_reply_to_screen_name" : "jackyalcine",
  "in_reply_to_user_id_str" : "44119449",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571144001820037120\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/WwCYxsQkIK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-0ccS1VIAAgduu.png",
      "id_str" : "571144000163356672",
      "id" : 571144000163356672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-0ccS1VIAAgduu.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/WwCYxsQkIK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/biwDqHL2ML",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "571144001820037120",
  "text" : "Weekend 13 of http:\/\/t.co\/biwDqHL2ML starts tomorrow. I liked this map of downtown someone made in-game: http:\/\/t.co\/WwCYxsQkIK",
  "id" : 571144001820037120,
  "created_at" : "2015-02-27 03:05:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571137577404796928",
  "geo" : { },
  "id_str" : "571138455536734208",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant just dont text her about femoral-head dislocations please",
  "id" : 571138455536734208,
  "in_reply_to_status_id" : 571137577404796928,
  "created_at" : "2015-02-27 02:43:13 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571137362924666882\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/OAOXhzfE6C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-0WZ0SVEAA3Unh.png",
      "id_str" : "571137360533983232",
      "id" : 571137360533983232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-0WZ0SVEAA3Unh.png",
      "sizes" : [ {
        "h" : 222,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 93,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 165,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OAOXhzfE6C"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571137362924666882",
  "text" : "My youngest cousin texted me about the dress hoax and she's learning the truth early http:\/\/t.co\/OAOXhzfE6C",
  "id" : 571137362924666882,
  "created_at" : "2015-02-27 02:38:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dusty Burwell",
      "screen_name" : "dustyburwell",
      "indices" : [ 0, 13 ],
      "id_str" : "21663430",
      "id" : 21663430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571131149461946368",
  "geo" : { },
  "id_str" : "571135291525693440",
  "in_reply_to_user_id" : 21663430,
  "text" : "@dustyburwell There Will Be Pancake",
  "id" : 571135291525693440,
  "in_reply_to_status_id" : 571131149461946368,
  "created_at" : "2015-02-27 02:30:39 +0000",
  "in_reply_to_screen_name" : "dustyburwell",
  "in_reply_to_user_id_str" : "21663430",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Neufeld",
      "screen_name" : "rkneufeld",
      "indices" : [ 0, 10 ],
      "id_str" : "15728996",
      "id" : 15728996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571132511943700480",
  "geo" : { },
  "id_str" : "571135234743209984",
  "in_reply_to_user_id" : 15728996,
  "text" : "@rkneufeld 45 now",
  "id" : 571135234743209984,
  "in_reply_to_status_id" : 571132511943700480,
  "created_at" : "2015-02-27 02:30:25 +0000",
  "in_reply_to_screen_name" : "rkneufeld",
  "in_reply_to_user_id_str" : "15728996",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/iXCm6Tbf8e",
      "expanded_url" : "http:\/\/tilde.club\/~qrush\/counter\/dealwithit.gif",
      "display_url" : "tilde.club\/~qrush\/counter\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "571123743273160704",
  "geo" : { },
  "id_str" : "571124290428362754",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 http:\/\/t.co\/iXCm6Tbf8e",
  "id" : 571124290428362754,
  "in_reply_to_status_id" : 571123743273160704,
  "created_at" : "2015-02-27 01:46:56 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/fKVa2yIjAn",
      "expanded_url" : "http:\/\/buffalo.craigslist.org\/ele\/4898806899.html",
      "display_url" : "buffalo.craigslist.org\/ele\/4898806899\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571120869893779457",
  "text" : "\"It would make a perfect gift for that hipster that wants to rock a vintage calculator.\"  http:\/\/t.co\/fKVa2yIjAn",
  "id" : 571120869893779457,
  "created_at" : "2015-02-27 01:33:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 13, 23 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571097913713041408\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/asOVLLtjuh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-zyhlFUsAErt2n.png",
      "id_str" : "571097911473254401",
      "id" : 571097911473254401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-zyhlFUsAErt2n.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/asOVLLtjuh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571097913713041408",
  "text" : "37 flips for @37signals http:\/\/t.co\/asOVLLtjuh",
  "id" : 571097913713041408,
  "created_at" : "2015-02-27 00:02:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571092946298105856",
  "text" : "Cupcake War is Peace.\nFreedom is Slavery.\nIgnorance is Strength.\n\nGeorge Orwell\n1984",
  "id" : 571092946298105856,
  "created_at" : "2015-02-26 23:42:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571091819930365952",
  "text" : "Cry 'Havoc,' and let slip the cupcakes of war; \nThat this foul deed shall smell above the earth \nWith carrion men, groaning for burial.",
  "id" : 571091819930365952,
  "created_at" : "2015-02-26 23:37:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571091414710292480",
  "text" : "Cupcake war does not determine who is right - only who is left",
  "id" : 571091414710292480,
  "created_at" : "2015-02-26 23:36:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571091048883040258",
  "text" : "How many cupcakes have been lost in the Cupcake Wars?",
  "id" : 571091048883040258,
  "created_at" : "2015-02-26 23:34:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Maggard",
      "screen_name" : "cmaggard",
      "indices" : [ 0, 9 ],
      "id_str" : "13643732",
      "id" : 13643732
    }, {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 10, 16 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571044199858114560",
  "geo" : { },
  "id_str" : "571045121409593344",
  "in_reply_to_user_id" : 13643732,
  "text" : "@cmaggard @jamis PANCAKE: THE GAME",
  "id" : 571045121409593344,
  "in_reply_to_status_id" : 571044199858114560,
  "created_at" : "2015-02-26 20:32:21 +0000",
  "in_reply_to_screen_name" : "cmaggard",
  "in_reply_to_user_id_str" : "13643732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571037884821549056",
  "geo" : { },
  "id_str" : "571038067949236224",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis 22!!!",
  "id" : 571038067949236224,
  "in_reply_to_status_id" : 571037884821549056,
  "created_at" : "2015-02-26 20:04:19 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571032945722564611\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/jjW5iOjVKN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-y3b_FWkAIcbsV.png",
      "id_str" : "571032944187445250",
      "id" : 571032944187445250,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-y3b_FWkAIcbsV.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/jjW5iOjVKN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571032945722564611",
  "text" : "Day 4: the pancake has self actualized http:\/\/t.co\/jjW5iOjVKN",
  "id" : 571032945722564611,
  "created_at" : "2015-02-26 19:43:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/571012288666337280\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/ZlHpmk1ccU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-ykpn1WoAAXRZx.png",
      "id_str" : "571012287743565824",
      "id" : 571012287743565824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-ykpn1WoAAXRZx.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 396,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 199,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 112,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZlHpmk1ccU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571012288666337280",
  "text" : "Hard-hitting journalism http:\/\/t.co\/ZlHpmk1ccU",
  "id" : 571012288666337280,
  "created_at" : "2015-02-26 18:21:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 20, 32 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/t3Hz86axrf",
      "expanded_url" : "http:\/\/aqueousband.com\/shows\/2014-02-26",
      "display_url" : "aqueousband.com\/shows\/2014-02-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571003017723555840",
  "text" : "One year ago today, @AqueousBand covered a ton of Beatles and it was fantastic: http:\/\/t.co\/t3Hz86axrf",
  "id" : 571003017723555840,
  "created_at" : "2015-02-26 17:45:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Robinson",
      "screen_name" : "drobby",
      "indices" : [ 0, 7 ],
      "id_str" : "17189491",
      "id" : 17189491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570980462010732546",
  "geo" : { },
  "id_str" : "570980640444833794",
  "in_reply_to_user_id" : 17189491,
  "text" : "@drobby $SYNC steak sounds delicious",
  "id" : 570980640444833794,
  "in_reply_to_status_id" : 570980462010732546,
  "created_at" : "2015-02-26 16:16:07 +0000",
  "in_reply_to_screen_name" : "drobby",
  "in_reply_to_user_id_str" : "17189491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renae Bair",
      "screen_name" : "renaebair",
      "indices" : [ 0, 10 ],
      "id_str" : "14945269",
      "id" : 14945269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570960961479290880",
  "geo" : { },
  "id_str" : "570979796810911744",
  "in_reply_to_user_id" : 14945269,
  "text" : "@renaebair that's awful and we're going to reach out to them about it",
  "id" : 570979796810911744,
  "in_reply_to_status_id" : 570960961479290880,
  "created_at" : "2015-02-26 16:12:46 +0000",
  "in_reply_to_screen_name" : "renaebair",
  "in_reply_to_user_id_str" : "14945269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Leigh Latislaw",
      "screen_name" : "corey_latislaw",
      "indices" : [ 0, 15 ],
      "id_str" : "16487505",
      "id" : 16487505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570977985349738496",
  "geo" : { },
  "id_str" : "570978113691262976",
  "in_reply_to_user_id" : 16487505,
  "text" : "@corey_latislaw Dayquil: Not Even Once",
  "id" : 570978113691262976,
  "in_reply_to_status_id" : 570977985349738496,
  "created_at" : "2015-02-26 16:06:05 +0000",
  "in_reply_to_screen_name" : "corey_latislaw",
  "in_reply_to_user_id_str" : "16487505",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Broderick",
      "screen_name" : "broderick",
      "indices" : [ 3, 13 ],
      "id_str" : "18205531",
      "id" : 18205531
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/broderick\/status\/570961648791334912\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/8XkJ4vROBP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-w4KOoWsAA4agS.jpg",
      "id_str" : "570893001146413056",
      "id" : 570893001146413056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-w4KOoWsAA4agS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/8XkJ4vROBP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570977581236953091",
  "text" : "RT @broderick: \u266C All around me are familiar faces, worn out places, worn out faces \u266C http:\/\/t.co\/8XkJ4vROBP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/broderick\/status\/570961648791334912\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/8XkJ4vROBP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-w4KOoWsAA4agS.jpg",
        "id_str" : "570893001146413056",
        "id" : 570893001146413056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-w4KOoWsAA4agS.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/8XkJ4vROBP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570961648791334912",
    "text" : "\u266C All around me are familiar faces, worn out places, worn out faces \u266C http:\/\/t.co\/8XkJ4vROBP",
    "id" : 570961648791334912,
    "created_at" : "2015-02-26 15:00:39 +0000",
    "user" : {
      "name" : "Ryan Broderick",
      "screen_name" : "broderick",
      "protected" : false,
      "id_str" : "18205531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549680207079043072\/7qHyAMbZ_normal.png",
      "id" : 18205531,
      "verified" : true
    }
  },
  "id" : 570977581236953091,
  "created_at" : "2015-02-26 16:03:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 16, 28 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Knitting Factory ",
      "screen_name" : "KnittingFactory",
      "indices" : [ 29, 45 ],
      "id_str" : "313447507",
      "id" : 313447507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570949886520233984",
  "geo" : { },
  "id_str" : "570967011787968513",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog @AqueousBand @KnittingFactory AHHHHH DDI &gt; WTC again. I love this combo.",
  "id" : 570967011787968513,
  "in_reply_to_status_id" : 570949886520233984,
  "created_at" : "2015-02-26 15:21:58 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 0, 12 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 13, 27 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570771394113511424",
  "geo" : { },
  "id_str" : "570772725326868480",
  "in_reply_to_user_id" : 26904582,
  "text" : "@AqueousBand @Carols10cents ok this one I actually need to figure out",
  "id" : 570772725326868480,
  "in_reply_to_status_id" : 570771394113511424,
  "created_at" : "2015-02-26 02:29:56 +0000",
  "in_reply_to_screen_name" : "AqueousBand",
  "in_reply_to_user_id_str" : "26904582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "indices" : [ 0, 8 ],
      "id_str" : "6532552",
      "id" : 6532552
    }, {
      "name" : "James Avery",
      "screen_name" : "averyj",
      "indices" : [ 9, 16 ],
      "id_str" : "6967822",
      "id" : 6967822
    }, {
      "name" : "Dugald Wilson",
      "screen_name" : "DugaldWilson",
      "indices" : [ 17, 30 ],
      "id_str" : "14098132",
      "id" : 14098132
    }, {
      "name" : "Niki Kohari",
      "screen_name" : "nikibeth",
      "indices" : [ 31, 40 ],
      "id_str" : "6533512",
      "id" : 6533512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570759876307255296",
  "geo" : { },
  "id_str" : "570760573824016384",
  "in_reply_to_user_id" : 6532552,
  "text" : "@nkohari @averyj @DugaldWilson @nikibeth BREAD AND MILK!!!!!",
  "id" : 570760573824016384,
  "in_reply_to_status_id" : 570759876307255296,
  "created_at" : "2015-02-26 01:41:39 +0000",
  "in_reply_to_screen_name" : "nkohari",
  "in_reply_to_user_id_str" : "6532552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 0, 15 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570726026122289152",
  "geo" : { },
  "id_str" : "570754042764226560",
  "in_reply_to_user_id" : 1472209542,
  "text" : "@PublicEspresso yesssssas",
  "id" : 570754042764226560,
  "in_reply_to_status_id" : 570726026122289152,
  "created_at" : "2015-02-26 01:15:42 +0000",
  "in_reply_to_screen_name" : "PublicEspresso",
  "in_reply_to_user_id_str" : "1472209542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jessicard",
      "screen_name" : "jessicard",
      "indices" : [ 3, 13 ],
      "id_str" : "253464752",
      "id" : 253464752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/QoiAEcdEWZ",
      "expanded_url" : "http:\/\/www.lenovo.com\/",
      "display_url" : "lenovo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "570702382205505536",
  "text" : "RT @jessicard: yikes http:\/\/t.co\/QoiAEcdEWZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/QoiAEcdEWZ",
        "expanded_url" : "http:\/\/www.lenovo.com\/",
        "display_url" : "lenovo.com"
      } ]
    },
    "geo" : { },
    "id_str" : "570701546213650433",
    "text" : "yikes http:\/\/t.co\/QoiAEcdEWZ",
    "id" : 570701546213650433,
    "created_at" : "2015-02-25 21:47:06 +0000",
    "user" : {
      "name" : "jessicard",
      "screen_name" : "jessicard",
      "protected" : false,
      "id_str" : "253464752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557025986223411201\/8ZXrxVdG_normal.jpeg",
      "id" : 253464752,
      "verified" : false
    }
  },
  "id" : 570702382205505536,
  "created_at" : "2015-02-25 21:50:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/TuwaymtKTR",
      "expanded_url" : "http:\/\/www.kamibox.de\/pancake",
      "display_url" : "kamibox.de\/pancake"
    } ]
  },
  "geo" : { },
  "id_str" : "570690333161463808",
  "text" : "Great copy-\n\n\"Throw the pancake!\nCatch the pancake!\nNo seriously. That\u2019s basically everything that you do.\"\n\nhttp:\/\/t.co\/TuwaymtKTR",
  "id" : 570690333161463808,
  "created_at" : "2015-02-25 21:02:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Keppel",
      "screen_name" : "akepps",
      "indices" : [ 0, 7 ],
      "id_str" : "16258970",
      "id" : 16258970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570677038203445249",
  "geo" : { },
  "id_str" : "570682061876535296",
  "in_reply_to_user_id" : 16258970,
  "text" : "@akepps oh noooooo",
  "id" : 570682061876535296,
  "in_reply_to_status_id" : 570677038203445249,
  "created_at" : "2015-02-25 20:29:40 +0000",
  "in_reply_to_screen_name" : "akepps",
  "in_reply_to_user_id_str" : "16258970",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "leon",
      "screen_name" : "leyawn",
      "indices" : [ 3, 10 ],
      "id_str" : "49708023",
      "id" : 49708023
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/leyawn\/status\/570666599486783488\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/7qLLp6nAkU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-tqP4iXAAEaDCc.png",
      "id_str" : "570666598899580929",
      "id" : 570666598899580929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-tqP4iXAAEaDCc.png",
      "sizes" : [ {
        "h" : 245,
        "resize" : "fit",
        "w" : 685
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 121,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 685
      } ],
      "display_url" : "pic.twitter.com\/7qLLp6nAkU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570667532551643136",
  "text" : "RT @leyawn: haha!! i cant believe buzzfeed randy fell for this http:\/\/t.co\/7qLLp6nAkU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/leyawn\/status\/570666599486783488\/photo\/1",
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/7qLLp6nAkU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-tqP4iXAAEaDCc.png",
        "id_str" : "570666598899580929",
        "id" : 570666598899580929,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-tqP4iXAAEaDCc.png",
        "sizes" : [ {
          "h" : 245,
          "resize" : "fit",
          "w" : 685
        }, {
          "h" : 214,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 121,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 245,
          "resize" : "fit",
          "w" : 685
        } ],
        "display_url" : "pic.twitter.com\/7qLLp6nAkU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570666599486783488",
    "text" : "haha!! i cant believe buzzfeed randy fell for this http:\/\/t.co\/7qLLp6nAkU",
    "id" : 570666599486783488,
    "created_at" : "2015-02-25 19:28:14 +0000",
    "user" : {
      "name" : "leon",
      "screen_name" : "leyawn",
      "protected" : false,
      "id_str" : "49708023",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3205550236\/70e0971b8c52faf3a44fd9a6194c54f5_normal.gif",
      "id" : 49708023,
      "verified" : false
    }
  },
  "id" : 570667532551643136,
  "created_at" : "2015-02-25 19:31:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 23, 35 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/n1bmuxAwkS",
      "expanded_url" : "http:\/\/bk.knittingfactory.com\/tw-event\/?event_id=5548415",
      "display_url" : "bk.knittingfactory.com\/tw-event\/?even\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570664722481094656",
  "text" : "NYC, Brooklyn friends: @AqueousBand is headed your way tonight. Go see them and tell me how it was. http:\/\/t.co\/n1bmuxAwkS",
  "id" : 570664722481094656,
  "created_at" : "2015-02-25 19:20:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570640098087145472",
  "geo" : { },
  "id_str" : "570641900224409600",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit no law school but I like the Cc: EVERYBODY",
  "id" : 570641900224409600,
  "in_reply_to_status_id" : 570640098087145472,
  "created_at" : "2015-02-25 17:50:05 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Tennier",
      "screen_name" : "jaytennier",
      "indices" : [ 0, 11 ],
      "id_str" : "15020118",
      "id" : 15020118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570567183027343360",
  "geo" : { },
  "id_str" : "570567722221744128",
  "in_reply_to_user_id" : 15020118,
  "text" : "@jaytennier Pancake.",
  "id" : 570567722221744128,
  "in_reply_to_status_id" : 570567183027343360,
  "created_at" : "2015-02-25 12:55:20 +0000",
  "in_reply_to_screen_name" : "jaytennier",
  "in_reply_to_user_id_str" : "15020118",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/570563348883906561\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/VoibUoVUt8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-sMVzDUcAATuSO.png",
      "id_str" : "570563346413416448",
      "id" : 570563346413416448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-sMVzDUcAATuSO.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VoibUoVUt8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570563348883906561",
  "text" : "Day 2: I have become one with the pancake and achieved balance http:\/\/t.co\/VoibUoVUt8",
  "id" : 570563348883906561,
  "created_at" : "2015-02-25 12:37:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "summer hale \u262D",
      "screen_name" : "velartrill",
      "indices" : [ 0, 11 ],
      "id_str" : "274843910",
      "id" : 274843910
    }, {
      "name" : "ashley needs tats",
      "screen_name" : "rabcyr",
      "indices" : [ 12, 19 ],
      "id_str" : "26157562",
      "id" : 26157562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570439017260457985",
  "geo" : { },
  "id_str" : "570442453854982145",
  "in_reply_to_user_id" : 274843910,
  "text" : "@velartrill @rabcyr is that the year of the Linux desktop?",
  "id" : 570442453854982145,
  "in_reply_to_status_id" : 570439017260457985,
  "created_at" : "2015-02-25 04:37:33 +0000",
  "in_reply_to_screen_name" : "velartrill",
  "in_reply_to_user_id_str" : "274843910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570439243383746561",
  "text" : "Some day I'll learn to play piano when it's as easy as flipping a pancake with a beefy forearm \uD83D\uDCAA\u26AB\uFE0F",
  "id" : 570439243383746561,
  "created_at" : "2015-02-25 04:24:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Bellware",
      "screen_name" : "sbellware",
      "indices" : [ 0, 10 ],
      "id_str" : "15636332",
      "id" : 15636332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570438377008275456",
  "geo" : { },
  "id_str" : "570438737294856193",
  "in_reply_to_user_id" : 15636332,
  "text" : "@sbellware agreed. The \"adoption center\" thread has more ideas on how to deal with this better.",
  "id" : 570438737294856193,
  "in_reply_to_status_id" : 570438377008275456,
  "created_at" : "2015-02-25 04:22:47 +0000",
  "in_reply_to_screen_name" : "sbellware",
  "in_reply_to_user_id_str" : "15636332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Bellware",
      "screen_name" : "sbellware",
      "indices" : [ 0, 10 ],
      "id_str" : "15636332",
      "id" : 15636332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570437309788585984",
  "geo" : { },
  "id_str" : "570437460787744769",
  "in_reply_to_user_id" : 15636332,
  "text" : "@sbellware thanks again. Always glad to see these resolve amicably",
  "id" : 570437460787744769,
  "in_reply_to_status_id" : 570437309788585984,
  "created_at" : "2015-02-25 04:17:43 +0000",
  "in_reply_to_screen_name" : "sbellware",
  "in_reply_to_user_id_str" : "15636332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "indices" : [ 0, 12 ],
      "id_str" : "9526722",
      "id" : 9526722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/ZCZVaiyYhi",
      "expanded_url" : "http:\/\/www.journalofcryptozoology.com\/",
      "display_url" : "journalofcryptozoology.com"
    } ]
  },
  "in_reply_to_status_id_str" : "570432291010248704",
  "geo" : { },
  "id_str" : "570432900463620096",
  "in_reply_to_user_id" : 9526722,
  "text" : "@CoralineAda but what about the Lake Monsters of Spain? http:\/\/t.co\/ZCZVaiyYhi",
  "id" : 570432900463620096,
  "in_reply_to_status_id" : 570432291010248704,
  "created_at" : "2015-02-25 03:59:36 +0000",
  "in_reply_to_screen_name" : "CoralineAda",
  "in_reply_to_user_id_str" : "9526722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jaff",
      "screen_name" : "jaffryan",
      "indices" : [ 3, 12 ],
      "id_str" : "27351506",
      "id" : 27351506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570431574195314688",
  "text" : "RT @jaffryan: [at fancy italian restaurant]\n\nwaiter: have u decided?\n\nme: yes i'll have the...ha, know im gonna butcher this\n\n[mispronounce\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "534922746636300288",
    "text" : "[at fancy italian restaurant]\n\nwaiter: have u decided?\n\nme: yes i'll have the...ha, know im gonna butcher this\n\n[mispronounces garlic bread]",
    "id" : 534922746636300288,
    "created_at" : "2014-11-19 04:14:55 +0000",
    "user" : {
      "name" : "jaff",
      "screen_name" : "jaffryan",
      "protected" : false,
      "id_str" : "27351506",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525800207741505536\/NSF5vUb5_normal.png",
      "id" : 27351506,
      "verified" : false
    }
  },
  "id" : 570431574195314688,
  "created_at" : "2015-02-25 03:54:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/rHinSfufS7",
      "expanded_url" : "http:\/\/nl.linkedin.com\/pub\/rofl-copter\/58\/503\/825",
      "display_url" : "nl.linkedin.com\/pub\/rofl-copte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570431510672576513",
  "text" : "Endorse my Cryptozoology skill on LINKEDIN. http:\/\/t.co\/rHinSfufS7",
  "id" : 570431510672576513,
  "created_at" : "2015-02-25 03:54:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 22, 32 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/LPJF0kPvAo",
      "expanded_url" : "http:\/\/www.journalofcryptozoology.com",
      "display_url" : "journalofcryptozoology.com"
    } ]
  },
  "geo" : { },
  "id_str" : "570430267946504192",
  "text" : "Not a good choice for @37signals education stipend, or is it? \"A Preliminary Examination of the Koolookamba Enigma\" http:\/\/t.co\/LPJF0kPvAo",
  "id" : 570430267946504192,
  "created_at" : "2015-02-25 03:49:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/33aYAp8SaM",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/V0MNrJCEHb",
      "expanded_url" : "https:\/\/github.com\/bundler\/bundler\/blob\/master\/CODE_OF_CONDUCT.md",
      "display_url" : "github.com\/bundler\/bundle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570429624192143360",
  "text" : "I think the next important step for http:\/\/t.co\/33aYAp8SaM is a CoC (and a legitimate ToS). Bundler's is great. https:\/\/t.co\/V0MNrJCEHb",
  "id" : 570429624192143360,
  "created_at" : "2015-02-25 03:46:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 0, 12 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570428653659672577",
  "geo" : { },
  "id_str" : "570428775340441600",
  "in_reply_to_user_id" : 26904582,
  "text" : "@AqueousBand And deleting that tweet :)",
  "id" : 570428775340441600,
  "in_reply_to_status_id" : 570428653659672577,
  "created_at" : "2015-02-25 03:43:12 +0000",
  "in_reply_to_screen_name" : "AqueousBand",
  "in_reply_to_user_id_str" : "26904582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/wCsxAY8phr",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/lYbWtu3VbI",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/commit\/5fcf2b39f5c1fa4aa115067f69f6234f5d1ad7ee#diff-8aa641a619b8ebeca0116d41774daf45R9",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570428145792192512",
  "text" : "&lt;3 http:\/\/t.co\/wCsxAY8phr. Still true ~6 years later: \"Enable the community to improve and enhance the site\" https:\/\/t.co\/lYbWtu3VbI",
  "id" : 570428145792192512,
  "created_at" : "2015-02-25 03:40:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Bellware",
      "screen_name" : "sbellware",
      "indices" : [ 0, 10 ],
      "id_str" : "15636332",
      "id" : 15636332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/DZtluprhnh",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/#!topic\/rubygems-org\/MeXnJDjOgMw",
      "display_url" : "groups.google.com\/forum\/#!topic\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570425844365008896",
  "in_reply_to_user_id" : 15636332,
  "text" : "@sbellware hi, can you take a look at https:\/\/t.co\/DZtluprhnh please?",
  "id" : 570425844365008896,
  "created_at" : "2015-02-25 03:31:33 +0000",
  "in_reply_to_screen_name" : "sbellware",
  "in_reply_to_user_id_str" : "15636332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/570421562324570112\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/AE2mYTZv99",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-qLYxQVIAAgeDn.jpg",
      "id_str" : "570421560470740992",
      "id" : 570421560470740992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-qLYxQVIAAgeDn.jpg",
      "sizes" : [ {
        "h" : 545,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 752
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 752
      } ],
      "display_url" : "pic.twitter.com\/AE2mYTZv99"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570421562324570112",
  "text" : "Current status http:\/\/t.co\/AE2mYTZv99",
  "id" : 570421562324570112,
  "created_at" : "2015-02-25 03:14:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Perry",
      "screen_name" : "stephperry",
      "indices" : [ 0, 11 ],
      "id_str" : "16008234",
      "id" : 16008234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570419013760761857",
  "geo" : { },
  "id_str" : "570420056389062657",
  "in_reply_to_user_id" : 16008234,
  "text" : "@stephperry sounds like an open mic night!",
  "id" : 570420056389062657,
  "in_reply_to_status_id" : 570419013760761857,
  "created_at" : "2015-02-25 03:08:33 +0000",
  "in_reply_to_screen_name" : "stephperry",
  "in_reply_to_user_id_str" : "16008234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/TZ4grJLMGi",
      "expanded_url" : "http:\/\/newsfeed.gawker.com\/sleeping-boston-driver-jumps-his-truck-off-the-top-deck-1687751294",
      "display_url" : "newsfeed.gawker.com\/sleeping-bosto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570418481620873216",
  "text" : "\"Just fucking terrifying\" - accurate description of any\/all Boston driving and this http:\/\/t.co\/TZ4grJLMGi",
  "id" : 570418481620873216,
  "created_at" : "2015-02-25 03:02:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Neufeld",
      "screen_name" : "rkneufeld",
      "indices" : [ 0, 10 ],
      "id_str" : "15728996",
      "id" : 15728996
    }, {
      "name" : "Con-Wan Kanobi",
      "screen_name" : "somethingconcon",
      "indices" : [ 11, 27 ],
      "id_str" : "37885397",
      "id" : 37885397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570407743288315904",
  "geo" : { },
  "id_str" : "570408711681761280",
  "in_reply_to_user_id" : 15728996,
  "text" : "@rkneufeld @somethingconcon OH CMON",
  "id" : 570408711681761280,
  "in_reply_to_status_id" : 570407743288315904,
  "created_at" : "2015-02-25 02:23:29 +0000",
  "in_reply_to_screen_name" : "rkneufeld",
  "in_reply_to_user_id_str" : "15728996",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Con-Wan Kanobi",
      "screen_name" : "somethingconcon",
      "indices" : [ 0, 16 ],
      "id_str" : "37885397",
      "id" : 37885397
    }, {
      "name" : "Ryan Neufeld",
      "screen_name" : "rkneufeld",
      "indices" : [ 17, 27 ],
      "id_str" : "15728996",
      "id" : 15728996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570321495144206336",
  "geo" : { },
  "id_str" : "570407252516941825",
  "in_reply_to_user_id" : 37885397,
  "text" : "@somethingconcon @rkneufeld high score 17 now",
  "id" : 570407252516941825,
  "in_reply_to_status_id" : 570321495144206336,
  "created_at" : "2015-02-25 02:17:41 +0000",
  "in_reply_to_screen_name" : "somethingconcon",
  "in_reply_to_user_id_str" : "37885397",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Neufeld",
      "screen_name" : "rkneufeld",
      "indices" : [ 0, 10 ],
      "id_str" : "15728996",
      "id" : 15728996
    }, {
      "name" : "Con-Wan Kanobi",
      "screen_name" : "somethingconcon",
      "indices" : [ 19, 35 ],
      "id_str" : "37885397",
      "id" : 37885397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570303553807523840",
  "geo" : { },
  "id_str" : "570309995578966016",
  "in_reply_to_user_id" : 15728996,
  "text" : "@rkneufeld Pancake @somethingconcon",
  "id" : 570309995578966016,
  "in_reply_to_status_id" : 570303553807523840,
  "created_at" : "2015-02-24 19:51:13 +0000",
  "in_reply_to_screen_name" : "rkneufeld",
  "in_reply_to_user_id_str" : "15728996",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/570302871528464384\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/SmxjBWw6lh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-ofcE9WwAIwkMI.png",
      "id_str" : "570302870043672578",
      "id" : 570302870043672578,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-ofcE9WwAIwkMI.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/SmxjBWw6lh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570302871528464384",
  "text" : "BROWNING PATTIES http:\/\/t.co\/SmxjBWw6lh",
  "id" : 570302871528464384,
  "created_at" : "2015-02-24 19:22:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570300854194057217",
  "text" : "Just noticed your pancake turns browner over time as if your beefy arm is a heat source",
  "id" : 570300854194057217,
  "created_at" : "2015-02-24 19:14:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 0, 7 ],
      "id_str" : "34953",
      "id" : 34953
    }, {
      "name" : "Ted Roche",
      "screen_name" : "tedroche",
      "indices" : [ 73, 82 ],
      "id_str" : "14353681",
      "id" : 14353681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570253882020003840",
  "geo" : { },
  "id_str" : "570254421004849152",
  "in_reply_to_user_id" : 34953,
  "text" : "@nathos I like changing the pronunciation to make everyone equally upset @tedroche",
  "id" : 570254421004849152,
  "in_reply_to_status_id" : 570253882020003840,
  "created_at" : "2015-02-24 16:10:23 +0000",
  "in_reply_to_screen_name" : "nathos",
  "in_reply_to_user_id_str" : "34953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570252658067578880",
  "text" : "How about instead of the \"Millenials\" we are instead the \"GIF Generation\" - funny for 6 seconds, on repeat, poorly encoded. Accurate.",
  "id" : 570252658067578880,
  "created_at" : "2015-02-24 16:03:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570249976422535168",
  "text" : "I can't wait for the following words to go away:\n\nInnovation\nMillenial\nPhablet\nMoist",
  "id" : 570249976422535168,
  "created_at" : "2015-02-24 15:52:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/570227835853369345\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/EbG4KyxghU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-nbMY_UMAAwIi-.png",
      "id_str" : "570227833752006656",
      "id" : 570227833752006656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-nbMY_UMAAwIi-.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/EbG4KyxghU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570227835853369345",
  "text" : "This \uD83D\uDCAA goes to 11 http:\/\/t.co\/EbG4KyxghU",
  "id" : 570227835853369345,
  "created_at" : "2015-02-24 14:24:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radek",
      "screen_name" : "radexp",
      "indices" : [ 0, 7 ],
      "id_str" : "107770370",
      "id" : 107770370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570223407268294656",
  "geo" : { },
  "id_str" : "570227731444543488",
  "in_reply_to_user_id" : 107770370,
  "text" : "@radexp working on it",
  "id" : 570227731444543488,
  "in_reply_to_status_id" : 570223407268294656,
  "created_at" : "2015-02-24 14:24:20 +0000",
  "in_reply_to_screen_name" : "radexp",
  "in_reply_to_user_id_str" : "107770370",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/q0WSN4ZCyC",
      "expanded_url" : "http:\/\/ericasadun.com\/2015\/02\/23\/swift-and-xcode-6-3-beta-2-did-drop-as-the-gentle-rain\/",
      "display_url" : "ericasadun.com\/2015\/02\/23\/swi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570221251899207681",
  "text" : "Oooh! Swift has zip now. http:\/\/t.co\/q0WSN4ZCyC",
  "id" : 570221251899207681,
  "created_at" : "2015-02-24 13:58:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NatashaTheRobot",
      "screen_name" : "NatashaTheRobot",
      "indices" : [ 3, 19 ],
      "id_str" : "398173256",
      "id" : 398173256
    }, {
      "name" : "ericasadun",
      "screen_name" : "ericasadun",
      "indices" : [ 66, 77 ],
      "id_str" : "13363282",
      "id" : 13363282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/ffSmRhb2iD",
      "expanded_url" : "http:\/\/ericasadun.com\/2015\/02\/23\/swift-and-xcode-6-3-beta-2-did-drop-as-the-gentle-rain\/",
      "display_url" : "ericasadun.com\/2015\/02\/23\/swi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570221179832655872",
  "text" : "RT @NatashaTheRobot: Good summary of XCode 6.3 beta 2 changes via @ericasadun http:\/\/t.co\/ffSmRhb2iD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ericasadun",
        "screen_name" : "ericasadun",
        "indices" : [ 45, 56 ],
        "id_str" : "13363282",
        "id" : 13363282
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/ffSmRhb2iD",
        "expanded_url" : "http:\/\/ericasadun.com\/2015\/02\/23\/swift-and-xcode-6-3-beta-2-did-drop-as-the-gentle-rain\/",
        "display_url" : "ericasadun.com\/2015\/02\/23\/swi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "570220609386496000",
    "text" : "Good summary of XCode 6.3 beta 2 changes via @ericasadun http:\/\/t.co\/ffSmRhb2iD",
    "id" : 570220609386496000,
    "created_at" : "2015-02-24 13:56:02 +0000",
    "user" : {
      "name" : "NatashaTheRobot",
      "screen_name" : "NatashaTheRobot",
      "protected" : false,
      "id_str" : "398173256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1606354121\/natashatherobot-eightbit_normal",
      "id" : 398173256,
      "verified" : false
    }
  },
  "id" : 570221179832655872,
  "created_at" : "2015-02-24 13:58:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 0, 7 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570217208661409792",
  "geo" : { },
  "id_str" : "570217525620793344",
  "in_reply_to_user_id" : 5743852,
  "text" : "@ftrain ah yes. They walked through your anxiety inducing email chain",
  "id" : 570217525620793344,
  "in_reply_to_status_id" : 570217208661409792,
  "created_at" : "2015-02-24 13:43:46 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 0, 7 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570217208661409792",
  "in_reply_to_user_id" : 6981492,
  "text" : "@ftrain I think you were just mentioned in Morning Edition??",
  "id" : 570217208661409792,
  "created_at" : "2015-02-24 13:42:31 +0000",
  "in_reply_to_screen_name" : "ftrain",
  "in_reply_to_user_id_str" : "6981492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/570197400909803520\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/7GxT253Lom",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-m_g1-UAAAJRMx.png",
      "id_str" : "570197398804234240",
      "id" : 570197398804234240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-m_g1-UAAAJRMx.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7GxT253Lom"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570197400909803520",
  "text" : "My greatest accomplishment today so far http:\/\/t.co\/7GxT253Lom",
  "id" : 570197400909803520,
  "created_at" : "2015-02-24 12:23:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    }, {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 9, 18 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/2ymgzndJ45",
      "expanded_url" : "https:\/\/sketchfab.com\/models\/mv3XlrFRPuVZoREQ8HXIxHUmlv4",
      "display_url" : "sketchfab.com\/models\/mv3XlrF\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "570010654221987840",
  "geo" : { },
  "id_str" : "570012402093142016",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo @mr_ndrsn next up? https:\/\/t.co\/2ymgzndJ45",
  "id" : 570012402093142016,
  "in_reply_to_status_id" : 570010654221987840,
  "created_at" : "2015-02-24 00:08:41 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Kay",
      "screen_name" : "_Jordan",
      "indices" : [ 3, 11 ],
      "id_str" : "14166065",
      "id" : 14166065
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/_Jordan\/status\/569940054358892544\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/VsksabEjmM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-jVdZzCMAASvuy.jpg",
      "id_str" : "569940053980229632",
      "id" : 569940053980229632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-jVdZzCMAASvuy.jpg",
      "sizes" : [ {
        "h" : 271,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3272,
        "resize" : "fit",
        "w" : 4092
      }, {
        "h" : 818,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VsksabEjmM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569951335187152896",
  "text" : "RT @_Jordan: Each emoji representing people on Apple platforms now offers a choice of skin color, with abstract color as the base. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/_Jordan\/status\/569940054358892544\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/VsksabEjmM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-jVdZzCMAASvuy.jpg",
        "id_str" : "569940053980229632",
        "id" : 569940053980229632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-jVdZzCMAASvuy.jpg",
        "sizes" : [ {
          "h" : 271,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3272,
          "resize" : "fit",
          "w" : 4092
        }, {
          "h" : 818,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/VsksabEjmM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569940054358892544",
    "text" : "Each emoji representing people on Apple platforms now offers a choice of skin color, with abstract color as the base. http:\/\/t.co\/VsksabEjmM",
    "id" : 569940054358892544,
    "created_at" : "2015-02-23 19:21:12 +0000",
    "user" : {
      "name" : "Jordan Kay",
      "screen_name" : "_Jordan",
      "protected" : false,
      "id_str" : "14166065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562480543128776705\/qQjopLgE_normal.jpeg",
      "id" : 14166065,
      "verified" : false
    }
  },
  "id" : 569951335187152896,
  "created_at" : "2015-02-23 20:06:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damn Big Coffee Mug",
      "screen_name" : "pxlpnk",
      "indices" : [ 0, 7 ],
      "id_str" : "62175345",
      "id" : 62175345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/ifk1GN0yKl",
      "expanded_url" : "http:\/\/mapcrafter.org",
      "display_url" : "mapcrafter.org"
    } ]
  },
  "in_reply_to_status_id_str" : "569874348007251968",
  "geo" : { },
  "id_str" : "569877297169199105",
  "in_reply_to_user_id" : 62175345,
  "text" : "@pxlpnk the map is generated with http:\/\/t.co\/ifk1GN0yKl. it's on a 16GB node.",
  "id" : 569877297169199105,
  "in_reply_to_status_id" : 569874348007251968,
  "created_at" : "2015-02-23 15:11:50 +0000",
  "in_reply_to_screen_name" : "pxlpnk",
  "in_reply_to_user_id_str" : "62175345",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Kern",
      "screen_name" : "lightcap",
      "indices" : [ 0, 9 ],
      "id_str" : "667803",
      "id" : 667803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569874395633741825",
  "geo" : { },
  "id_str" : "569877031669751808",
  "in_reply_to_user_id" : 667803,
  "text" : "@lightcap nick [at] quaran.to if you want to reach out.",
  "id" : 569877031669751808,
  "in_reply_to_status_id" : 569874395633741825,
  "created_at" : "2015-02-23 15:10:46 +0000",
  "in_reply_to_screen_name" : "lightcap",
  "in_reply_to_user_id_str" : "667803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damn Big Coffee Mug",
      "screen_name" : "pxlpnk",
      "indices" : [ 0, 7 ],
      "id_str" : "62175345",
      "id" : 62175345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569873336131457024",
  "geo" : { },
  "id_str" : "569874126879350785",
  "in_reply_to_user_id" : 62175345,
  "text" : "@pxlpnk ah! it's just vanilla. I spin a Linode up and down every weekend.",
  "id" : 569874126879350785,
  "in_reply_to_status_id" : 569873336131457024,
  "created_at" : "2015-02-23 14:59:14 +0000",
  "in_reply_to_screen_name" : "pxlpnk",
  "in_reply_to_user_id_str" : "62175345",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damn Big Coffee Mug",
      "screen_name" : "pxlpnk",
      "indices" : [ 0, 7 ],
      "id_str" : "62175345",
      "id" : 62175345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569835419145248769",
  "geo" : { },
  "id_str" : "569873091939020800",
  "in_reply_to_user_id" : 62175345,
  "text" : "@pxlpnk minecraft server? http server?",
  "id" : 569873091939020800,
  "in_reply_to_status_id" : 569835419145248769,
  "created_at" : "2015-02-23 14:55:07 +0000",
  "in_reply_to_screen_name" : "pxlpnk",
  "in_reply_to_user_id_str" : "62175345",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Kern",
      "screen_name" : "lightcap",
      "indices" : [ 0, 9 ],
      "id_str" : "667803",
      "id" : 667803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569830990983639041",
  "geo" : { },
  "id_str" : "569873043956170752",
  "in_reply_to_user_id" : 667803,
  "text" : "@lightcap i am slightly involved, whats up?",
  "id" : 569873043956170752,
  "in_reply_to_status_id" : 569830990983639041,
  "created_at" : "2015-02-23 14:54:56 +0000",
  "in_reply_to_screen_name" : "lightcap",
  "in_reply_to_user_id_str" : "667803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 3, 9 ],
      "id_str" : "1438261",
      "id" : 1438261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/hS4vMr4ral",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=2QUacU0I4yU",
      "display_url" : "youtube.com\/watch?v=2QUacU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "569633619473408001",
  "text" : "RT @atmos: I never knew Marlon Brando declined the Oscar he won for best actor in The Godfather. https:\/\/t.co\/hS4vMr4ral",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/hS4vMr4ral",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=2QUacU0I4yU",
        "display_url" : "youtube.com\/watch?v=2QUacU\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "569631904174989312",
    "text" : "I never knew Marlon Brando declined the Oscar he won for best actor in The Godfather. https:\/\/t.co\/hS4vMr4ral",
    "id" : 569631904174989312,
    "created_at" : "2015-02-22 22:56:43 +0000",
    "user" : {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "protected" : false,
      "id_str" : "1438261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/415297890701959168\/qmD48etq_normal.jpeg",
      "id" : 1438261,
      "verified" : false
    }
  },
  "id" : 569633619473408001,
  "created_at" : "2015-02-22 23:03:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Medero",
      "screen_name" : "soypunk",
      "indices" : [ 0, 8 ],
      "id_str" : "35213",
      "id" : 35213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569587751068127232",
  "geo" : { },
  "id_str" : "569606819905081344",
  "in_reply_to_user_id" : 35213,
  "text" : "@soypunk no idea right now. talking to insurance tomorrow",
  "id" : 569606819905081344,
  "in_reply_to_status_id" : 569587751068127232,
  "created_at" : "2015-02-22 21:17:03 +0000",
  "in_reply_to_screen_name" : "soypunk",
  "in_reply_to_user_id_str" : "35213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Broderick",
      "screen_name" : "broderick",
      "indices" : [ 3, 13 ],
      "id_str" : "18205531",
      "id" : 18205531
    }, {
      "name" : "The Daily Dot",
      "screen_name" : "dailydot",
      "indices" : [ 120, 129 ],
      "id_str" : "211620426",
      "id" : 211620426
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/broderick\/status\/569505506131386368\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Rnv8n0OF29",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-dKNFkIUAA6DsJ.jpg",
      "id_str" : "569505466578128896",
      "id" : 569505466578128896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-dKNFkIUAA6DsJ.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Rnv8n0OF29"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/yxIhM61DH3",
      "expanded_url" : "http:\/\/kernelmag.dailydot.com\/issue-sections\/headline-story\/11843\/angry-white-male-internet\/",
      "display_url" : "kernelmag.dailydot.com\/issue-sections\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "569601284178731010",
  "text" : "RT @broderick: We must bulldoze what\u2019s left of the nerdy white men\u2019s Internet http:\/\/t.co\/yxIhM61DH3 my guest piece for @dailydot! http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Daily Dot",
        "screen_name" : "dailydot",
        "indices" : [ 105, 114 ],
        "id_str" : "211620426",
        "id" : 211620426
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/broderick\/status\/569505506131386368\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/Rnv8n0OF29",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-dKNFkIUAA6DsJ.jpg",
        "id_str" : "569505466578128896",
        "id" : 569505466578128896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-dKNFkIUAA6DsJ.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Rnv8n0OF29"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/yxIhM61DH3",
        "expanded_url" : "http:\/\/kernelmag.dailydot.com\/issue-sections\/headline-story\/11843\/angry-white-male-internet\/",
        "display_url" : "kernelmag.dailydot.com\/issue-sections\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "569505506131386368",
    "text" : "We must bulldoze what\u2019s left of the nerdy white men\u2019s Internet http:\/\/t.co\/yxIhM61DH3 my guest piece for @dailydot! http:\/\/t.co\/Rnv8n0OF29",
    "id" : 569505506131386368,
    "created_at" : "2015-02-22 14:34:28 +0000",
    "user" : {
      "name" : "Ryan Broderick",
      "screen_name" : "broderick",
      "protected" : false,
      "id_str" : "18205531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549680207079043072\/7qHyAMbZ_normal.png",
      "id" : 18205531,
      "verified" : true
    }
  },
  "id" : 569601284178731010,
  "created_at" : "2015-02-22 20:55:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569584807346176000",
  "text" : "After noticing a leak and discovering a wall in my house is equal parts ice and wood I want it to stay below freezing forever please",
  "id" : 569584807346176000,
  "created_at" : "2015-02-22 19:49:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarr\u2B55\uFE0Fd Krieger",
      "screen_name" : "Jmkrochester",
      "indices" : [ 0, 13 ],
      "id_str" : "121941652",
      "id" : 121941652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/I11JbxJ2ZL",
      "expanded_url" : "http:\/\/mixlr.com\/qrush\/showreel\/aqueous-flour-city-station\/",
      "display_url" : "mixlr.com\/qrush\/showreel\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "569300189116284930",
  "geo" : { },
  "id_str" : "569472747505459201",
  "in_reply_to_user_id" : 121941652,
  "text" : "@Jmkrochester http:\/\/t.co\/I11JbxJ2ZL",
  "id" : 569472747505459201,
  "in_reply_to_status_id" : 569300189116284930,
  "created_at" : "2015-02-22 12:24:17 +0000",
  "in_reply_to_screen_name" : "Jmkrochester",
  "in_reply_to_user_id_str" : "121941652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul",
      "screen_name" : "phalt_",
      "indices" : [ 0, 7 ],
      "id_str" : "198444822",
      "id" : 198444822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569304533043679232",
  "geo" : { },
  "id_str" : "569305032547393537",
  "in_reply_to_user_id" : 198444822,
  "text" : "@phalt_ smart kerbals know what is coming for them - at least mine do. usually means smashing into the Mun because you forgot to test gears",
  "id" : 569305032547393537,
  "in_reply_to_status_id" : 569304533043679232,
  "created_at" : "2015-02-22 01:17:51 +0000",
  "in_reply_to_screen_name" : "phalt_",
  "in_reply_to_user_id_str" : "198444822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/569138350839328768\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/XiYNXDuCLL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-X8UEOCEAA1ws_.png",
      "id_str" : "569138349592416256",
      "id" : 569138349592416256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-X8UEOCEAA1ws_.png",
      "sizes" : [ {
        "h" : 472,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1074,
        "resize" : "fit",
        "w" : 1364
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XiYNXDuCLL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/HxiChvnjwP",
      "expanded_url" : "http:\/\/pickaxe.club\/#overworld\/0\/8\/-8175\/3822\/64",
      "display_url" : "pickaxe.club\/#overworld\/0\/8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "569138350839328768",
  "text" : "Ice biome mapped out - huge shards! http:\/\/t.co\/HxiChvnjwP http:\/\/t.co\/XiYNXDuCLL",
  "id" : 569138350839328768,
  "created_at" : "2015-02-21 14:15:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ira Glass",
      "screen_name" : "iraglass",
      "indices" : [ 3, 12 ],
      "id_str" : "14589511",
      "id" : 14589511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/Il35G4QmvO",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=4F0Mer4kDDY",
      "display_url" : "youtube.com\/watch?v=4F0Mer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "569110638498222080",
  "text" : "RT @iraglass: Sometimes I love the Internet so much. https:\/\/t.co\/Il35G4QmvO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/Il35G4QmvO",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=4F0Mer4kDDY",
        "display_url" : "youtube.com\/watch?v=4F0Mer\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "569097742104055808",
    "text" : "Sometimes I love the Internet so much. https:\/\/t.co\/Il35G4QmvO",
    "id" : 569097742104055808,
    "created_at" : "2015-02-21 11:34:09 +0000",
    "user" : {
      "name" : "Ira Glass",
      "screen_name" : "iraglass",
      "protected" : false,
      "id_str" : "14589511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480213585281298433\/gmgzaZsx_normal.jpeg",
      "id" : 14589511,
      "verified" : true
    }
  },
  "id" : 569110638498222080,
  "created_at" : "2015-02-21 12:25:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pnoidandroid",
      "screen_name" : "pnoidandroid",
      "indices" : [ 0, 13 ],
      "id_str" : "327175506",
      "id" : 327175506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568943701910794241",
  "geo" : { },
  "id_str" : "569109960287608832",
  "in_reply_to_user_id" : 327175506,
  "text" : "@pnoidandroid hey no problem ! Id love for them to stream every show. Working on it.",
  "id" : 569109960287608832,
  "in_reply_to_status_id" : 568943701910794241,
  "created_at" : "2015-02-21 12:22:42 +0000",
  "in_reply_to_screen_name" : "pnoidandroid",
  "in_reply_to_user_id_str" : "327175506",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Scheinberg",
      "screen_name" : "sethadam1",
      "indices" : [ 0, 10 ],
      "id_str" : "6667632",
      "id" : 6667632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569109685204328450",
  "geo" : { },
  "id_str" : "569109860287033344",
  "in_reply_to_user_id" : 6667632,
  "text" : "@sethadam1 woo!",
  "id" : 569109860287033344,
  "in_reply_to_status_id" : 569109685204328450,
  "created_at" : "2015-02-21 12:22:18 +0000",
  "in_reply_to_screen_name" : "sethadam1",
  "in_reply_to_user_id_str" : "6667632",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/568971039541104642\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/4FEoz5Jjh4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-VkJKyCAAArs_U.png",
      "id_str" : "568971036608036864",
      "id" : 568971036608036864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-VkJKyCAAArs_U.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4FEoz5Jjh4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aIQIr1ZjTi",
      "expanded_url" : "http:\/\/Pickaxe.club",
      "display_url" : "Pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "568971039541104642",
  "text" : "http:\/\/t.co\/aIQIr1ZjTi's new chat is a lot of fun. Seamless integration with people playing is great to catch up on http:\/\/t.co\/4FEoz5Jjh4",
  "id" : 568971039541104642,
  "created_at" : "2015-02-21 03:10:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 12, 24 ],
      "id_str" : "19627341",
      "id" : 19627341
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 25, 33 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 34, 43 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568965420918681600",
  "geo" : { },
  "id_str" : "568965752708923392",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler @dwradcliffe @evanphx @indirect thank you",
  "id" : 568965752708923392,
  "in_reply_to_status_id" : 568965420918681600,
  "created_at" : "2015-02-21 02:49:40 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 3, 14 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568965659209519104",
  "text" : "RT @samkottler: Was just reminded that I just passed two years of working on RubyGems and Bundler infrastructure &lt;3 &lt;3 &lt;3 &lt;3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568963720031969282",
    "text" : "Was just reminded that I just passed two years of working on RubyGems and Bundler infrastructure &lt;3 &lt;3 &lt;3 &lt;3",
    "id" : 568963720031969282,
    "created_at" : "2015-02-21 02:41:36 +0000",
    "user" : {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "protected" : false,
      "id_str" : "103914540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572808884675301376\/whqN3Ix2_normal.jpeg",
      "id" : 103914540,
      "verified" : false
    }
  },
  "id" : 568965659209519104,
  "created_at" : "2015-02-21 02:49:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pnoidandroid",
      "screen_name" : "pnoidandroid",
      "indices" : [ 0, 13 ],
      "id_str" : "327175506",
      "id" : 327175506
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 14, 29 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568916178443354112",
  "geo" : { },
  "id_str" : "568916609571491840",
  "in_reply_to_user_id" : 327175506,
  "text" : "@pnoidandroid @UnclePhilsBlog what a killer opener. I can't wait for them to bust it open.",
  "id" : 568916609571491840,
  "in_reply_to_status_id" : 568916178443354112,
  "created_at" : "2015-02-20 23:34:24 +0000",
  "in_reply_to_screen_name" : "pnoidandroid",
  "in_reply_to_user_id_str" : "327175506",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/biwDqHL2ML",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    }, {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/FSiRNFGzn9",
      "expanded_url" : "http:\/\/imgur.com\/FPmcHJI",
      "display_url" : "imgur.com\/FPmcHJI"
    } ]
  },
  "geo" : { },
  "id_str" : "568911140278808578",
  "text" : "Ice biome discovered on http:\/\/t.co\/biwDqHL2ML: http:\/\/t.co\/FSiRNFGzn9",
  "id" : 568911140278808578,
  "created_at" : "2015-02-20 23:12:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 3, 15 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/e6cslxWOlo",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/02\/20\/opinion\/bostons-winter-from-hell.html",
      "display_url" : "nytimes.com\/2015\/02\/20\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568862638395904000",
  "text" : "RT @fredyatesiv: A great NYT piece on how our Boston winter is a legitimate natural disaster. http:\/\/t.co\/e6cslxWOlo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/e6cslxWOlo",
        "expanded_url" : "http:\/\/www.nytimes.com\/2015\/02\/20\/opinion\/bostons-winter-from-hell.html",
        "display_url" : "nytimes.com\/2015\/02\/20\/opi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "568862244601249792",
    "text" : "A great NYT piece on how our Boston winter is a legitimate natural disaster. http:\/\/t.co\/e6cslxWOlo",
    "id" : 568862244601249792,
    "created_at" : "2015-02-20 19:58:22 +0000",
    "user" : {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "protected" : false,
      "id_str" : "11886642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000601269119\/e0edad3585e85a968b3840e2ccd0ace5_normal.jpeg",
      "id" : 11886642,
      "verified" : false
    }
  },
  "id" : 568862638395904000,
  "created_at" : "2015-02-20 19:59:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Sergeant",
      "screen_name" : "nicksergeant",
      "indices" : [ 0, 13 ],
      "id_str" : "13459652",
      "id" : 13459652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568852090694590464",
  "geo" : { },
  "id_str" : "568852409998569473",
  "in_reply_to_user_id" : 13459652,
  "text" : "@nicksergeant I can put signs up saying it's for lease\/demo\/construction if you so wish.",
  "id" : 568852409998569473,
  "in_reply_to_status_id" : 568852090694590464,
  "created_at" : "2015-02-20 19:19:17 +0000",
  "in_reply_to_screen_name" : "nicksergeant",
  "in_reply_to_user_id_str" : "13459652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Robinson",
      "screen_name" : "robins36",
      "indices" : [ 0, 9 ],
      "id_str" : "310290717",
      "id" : 310290717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568838619835736064",
  "geo" : { },
  "id_str" : "568839679308632065",
  "in_reply_to_user_id" : 310290717,
  "text" : "@robins36 I don't care what it is. I'd be surprised to see them pony up the cash though",
  "id" : 568839679308632065,
  "in_reply_to_status_id" : 568838619835736064,
  "created_at" : "2015-02-20 18:28:42 +0000",
  "in_reply_to_screen_name" : "robins36",
  "in_reply_to_user_id_str" : "310290717",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugo Freire",
      "screen_name" : "TLmaK0",
      "indices" : [ 0, 7 ],
      "id_str" : "468304748",
      "id" : 468304748
    }, {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 8, 24 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568823208490758147",
  "geo" : { },
  "id_str" : "568838881430388736",
  "in_reply_to_user_id" : 468304748,
  "text" : "@TLmaK0 @rubygems_status Seems OK. Maybe a strange ruby\/rubygems version combo?",
  "id" : 568838881430388736,
  "in_reply_to_status_id" : 568823208490758147,
  "created_at" : "2015-02-20 18:25:32 +0000",
  "in_reply_to_screen_name" : "TLmaK0",
  "in_reply_to_user_id_str" : "468304748",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/568837805448822784\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/VMe83UdbM0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Tq-DYCMAAn_a4.jpg",
      "id_str" : "568837804734427136",
      "id" : 568837804734427136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Tq-DYCMAAn_a4.jpg",
      "sizes" : [ {
        "h" : 862,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 143,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VMe83UdbM0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568837805448822784",
  "text" : "Really hoping this turns into a great grocery store for downtown - Wegmans? Whole Foods? Anything! Bueller? http:\/\/t.co\/VMe83UdbM0",
  "id" : 568837805448822784,
  "created_at" : "2015-02-20 18:21:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Keppel",
      "screen_name" : "akepps",
      "indices" : [ 0, 7 ],
      "id_str" : "16258970",
      "id" : 16258970
    }, {
      "name" : "Josh Robinson",
      "screen_name" : "robins36",
      "indices" : [ 8, 17 ],
      "id_str" : "310290717",
      "id" : 310290717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568834664133206017",
  "geo" : { },
  "id_str" : "568835015481511936",
  "in_reply_to_user_id" : 16258970,
  "text" : "@akepps @robins36 holy guacamole ! Which one?",
  "id" : 568835015481511936,
  "in_reply_to_status_id" : 568834664133206017,
  "created_at" : "2015-02-20 18:10:10 +0000",
  "in_reply_to_screen_name" : "akepps",
  "in_reply_to_user_id_str" : "16258970",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugo Freire",
      "screen_name" : "TLmaK0",
      "indices" : [ 0, 7 ],
      "id_str" : "468304748",
      "id" : 468304748
    }, {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 8, 24 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568712011183472640",
  "geo" : { },
  "id_str" : "568798771133460480",
  "in_reply_to_user_id" : 468304748,
  "text" : "@TLmaK0 @rubygems_status doesn't sound right. Can you pastie\/gist your gemspec?",
  "id" : 568798771133460480,
  "in_reply_to_status_id" : 568712011183472640,
  "created_at" : "2015-02-20 15:46:09 +0000",
  "in_reply_to_screen_name" : "TLmaK0",
  "in_reply_to_user_id_str" : "468304748",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tef",
      "screen_name" : "tef",
      "indices" : [ 3, 7 ],
      "id_str" : "16681276",
      "id" : 16681276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/WfkkEIsO5U",
      "expanded_url" : "https:\/\/twitter.com\/arthur_affect\/status\/567271070499999744",
      "display_url" : "twitter.com\/arthur_affect\/\u2026"
    }, {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/NPNAOrSIgl",
      "expanded_url" : "https:\/\/twitter.com\/wadhwa\/status\/568652157265686528",
      "display_url" : "twitter.com\/wadhwa\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568755473257771008",
  "text" : "RT @tef: four days between these two tweets:\n\nhttps:\/\/t.co\/WfkkEIsO5U\n\nhttps:\/\/t.co\/NPNAOrSIgl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/WfkkEIsO5U",
        "expanded_url" : "https:\/\/twitter.com\/arthur_affect\/status\/567271070499999744",
        "display_url" : "twitter.com\/arthur_affect\/\u2026"
      }, {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/NPNAOrSIgl",
        "expanded_url" : "https:\/\/twitter.com\/wadhwa\/status\/568652157265686528",
        "display_url" : "twitter.com\/wadhwa\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "568718542545272832",
    "text" : "four days between these two tweets:\n\nhttps:\/\/t.co\/WfkkEIsO5U\n\nhttps:\/\/t.co\/NPNAOrSIgl",
    "id" : 568718542545272832,
    "created_at" : "2015-02-20 10:27:21 +0000",
    "user" : {
      "name" : "tef",
      "screen_name" : "tef",
      "protected" : false,
      "id_str" : "16681276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571518449789071360\/_jLCStjM_normal.jpeg",
      "id" : 16681276,
      "verified" : false
    }
  },
  "id" : 568755473257771008,
  "created_at" : "2015-02-20 12:54:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Holthaus",
      "screen_name" : "EricHolthaus",
      "indices" : [ 3, 16 ],
      "id_str" : "290180065",
      "id" : 290180065
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/EricHolthaus\/status\/568636152434946048\/photo\/1",
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/gSYy7nXL9b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-QzkTwCYAAtoOE.png",
      "id_str" : "568636151825588224",
      "id" : 568636151825588224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-QzkTwCYAAtoOE.png",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gSYy7nXL9b"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/P8jVxLtV4k",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/the_slatest\/2015\/02\/19\/freezing_cold_temperatures_hit_record_lows_in_missouri_and_kentucky.html",
      "display_url" : "slate.com\/blogs\/the_slat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568647830694461440",
  "text" : "RT @EricHolthaus: Wow...the eastern U.S. has the most extreme cold of anywhere on Earth right now. http:\/\/t.co\/P8jVxLtV4k http:\/\/t.co\/gSYy7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/EricHolthaus\/status\/568636152434946048\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/gSYy7nXL9b",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-QzkTwCYAAtoOE.png",
        "id_str" : "568636151825588224",
        "id" : 568636151825588224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-QzkTwCYAAtoOE.png",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/gSYy7nXL9b"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/P8jVxLtV4k",
        "expanded_url" : "http:\/\/www.slate.com\/blogs\/the_slatest\/2015\/02\/19\/freezing_cold_temperatures_hit_record_lows_in_missouri_and_kentucky.html",
        "display_url" : "slate.com\/blogs\/the_slat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "568636152434946048",
    "text" : "Wow...the eastern U.S. has the most extreme cold of anywhere on Earth right now. http:\/\/t.co\/P8jVxLtV4k http:\/\/t.co\/gSYy7nXL9b",
    "id" : 568636152434946048,
    "created_at" : "2015-02-20 04:59:58 +0000",
    "user" : {
      "name" : "Eric Holthaus",
      "screen_name" : "EricHolthaus",
      "protected" : false,
      "id_str" : "290180065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458779628161597440\/mWG3M6gy_normal.jpeg",
      "id" : 290180065,
      "verified" : true
    }
  },
  "id" : 568647830694461440,
  "created_at" : "2015-02-20 05:46:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/4cnsyMJwxo",
      "expanded_url" : "http:\/\/mixlr.com\/qrush\/",
      "display_url" : "mixlr.com\/qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "568638040232599552",
  "text" : "Starting up now! How's it sound? http:\/\/t.co\/4cnsyMJwxo",
  "id" : 568638040232599552,
  "created_at" : "2015-02-20 05:07:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 1, 13 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/4cnsyMJwxo",
      "expanded_url" : "http:\/\/mixlr.com\/qrush\/",
      "display_url" : "mixlr.com\/qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "568637192979025920",
  "text" : ".@AqueousBand is starting up soon and I am streaming it live: http:\/\/t.co\/4cnsyMJwxo",
  "id" : 568637192979025920,
  "created_at" : "2015-02-20 05:04:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Lindvall",
      "screen_name" : "lindvall",
      "indices" : [ 0, 9 ],
      "id_str" : "7383702",
      "id" : 7383702
    }, {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 10, 21 ],
      "id_str" : "2355631",
      "id" : 2355631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568521743272271872",
  "geo" : { },
  "id_str" : "568521895957508097",
  "in_reply_to_user_id" : 7383702,
  "text" : "@lindvall @lmarburger licecap and then drag onto Dropbox.",
  "id" : 568521895957508097,
  "in_reply_to_status_id" : 568521743272271872,
  "created_at" : "2015-02-19 21:25:57 +0000",
  "in_reply_to_screen_name" : "lindvall",
  "in_reply_to_user_id_str" : "7383702",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568517925960679425",
  "geo" : { },
  "id_str" : "568518345705721857",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt he had the best handwriting tho, in fact this emoji was based off it\uD83D\uDC4C",
  "id" : 568518345705721857,
  "in_reply_to_status_id" : 568517925960679425,
  "created_at" : "2015-02-19 21:11:50 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hoo boy, its vrunt! ",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568515689310330880",
  "geo" : { },
  "id_str" : "568517473474977792",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt remember us mug buds when you're famous",
  "id" : 568517473474977792,
  "in_reply_to_status_id" : 568515689310330880,
  "created_at" : "2015-02-19 21:08:22 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/90wo1ndJzj",
      "expanded_url" : "https:\/\/signalvnoise.com\/posts\/3857-when-disaster-strikes",
      "display_url" : "signalvnoise.com\/posts\/3857-whe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568492953003540480",
  "text" : "Basecamp Ops is all out of bubblegum. https:\/\/t.co\/90wo1ndJzj",
  "id" : 568492953003540480,
  "created_at" : "2015-02-19 19:30:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jessicard",
      "screen_name" : "jessicard",
      "indices" : [ 3, 13 ],
      "id_str" : "253464752",
      "id" : 253464752
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jessicard\/status\/568475461786980352\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/N6rwF6rWzR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Oha4LCEAAJ_kv.png",
      "id_str" : "568475461106143232",
      "id" : 568475461106143232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Oha4LCEAAJ_kv.png",
      "sizes" : [ {
        "h" : 366,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1025,
        "resize" : "fit",
        "w" : 1680
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 624,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/N6rwF6rWzR"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/jessicard\/status\/568475461786980352\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/N6rwF6rWzR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-OhaoGCUAAU-rX.png",
      "id_str" : "568475456790220800",
      "id" : 568475456790220800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-OhaoGCUAAU-rX.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/N6rwF6rWzR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/YkktYsQjeG",
      "expanded_url" : "https:\/\/github.com\/SomeKittens\/ST-Hot-Dog-Stand",
      "display_url" : "github.com\/SomeKittens\/ST\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568476365533495297",
  "text" : "RT @jessicard: oh... oh my god. someone made a \"hot dog stand\" sublime theme (like the old windows theme) https:\/\/t.co\/YkktYsQjeG http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jessicard\/status\/568475461786980352\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/N6rwF6rWzR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Oha4LCEAAJ_kv.png",
        "id_str" : "568475461106143232",
        "id" : 568475461106143232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Oha4LCEAAJ_kv.png",
        "sizes" : [ {
          "h" : 366,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1025,
          "resize" : "fit",
          "w" : 1680
        }, {
          "h" : 207,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 624,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/N6rwF6rWzR"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/jessicard\/status\/568475461786980352\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/N6rwF6rWzR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-OhaoGCUAAU-rX.png",
        "id_str" : "568475456790220800",
        "id" : 568475456790220800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-OhaoGCUAAU-rX.png",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/N6rwF6rWzR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/YkktYsQjeG",
        "expanded_url" : "https:\/\/github.com\/SomeKittens\/ST-Hot-Dog-Stand",
        "display_url" : "github.com\/SomeKittens\/ST\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "568475461786980352",
    "text" : "oh... oh my god. someone made a \"hot dog stand\" sublime theme (like the old windows theme) https:\/\/t.co\/YkktYsQjeG http:\/\/t.co\/N6rwF6rWzR",
    "id" : 568475461786980352,
    "created_at" : "2015-02-19 18:21:26 +0000",
    "user" : {
      "name" : "jessicard",
      "screen_name" : "jessicard",
      "protected" : false,
      "id_str" : "253464752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557025986223411201\/8ZXrxVdG_normal.jpeg",
      "id" : 253464752,
      "verified" : false
    }
  },
  "id" : 568476365533495297,
  "created_at" : "2015-02-19 18:25:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Verwer",
      "screen_name" : "daveverwer",
      "indices" : [ 0, 11 ],
      "id_str" : "12512",
      "id" : 12512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568456089395572738",
  "geo" : { },
  "id_str" : "568467439597432832",
  "in_reply_to_user_id" : 12512,
  "text" : "@daveverwer i'll check it out! Too many links :)",
  "id" : 568467439597432832,
  "in_reply_to_status_id" : 568456089395572738,
  "created_at" : "2015-02-19 17:49:33 +0000",
  "in_reply_to_screen_name" : "daveverwer",
  "in_reply_to_user_id_str" : "12512",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/biwDqHtrVd",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    }, {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/qMzSYS3slZ",
      "expanded_url" : "https:\/\/github.com\/qrush\/pickaxechat",
      "display_url" : "github.com\/qrush\/pickaxec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568438472647835649",
  "text" : "Blog post incoming but here's the Slack to Minecraft chat gateway for http:\/\/t.co\/biwDqHtrVd: https:\/\/t.co\/qMzSYS3slZ",
  "id" : 568438472647835649,
  "created_at" : "2015-02-19 15:54:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/568423579223601152\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/ZQvLqThg5L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-NyO6BCcAETPvR.png",
      "id_str" : "568423578396160001",
      "id" : 568423578396160001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-NyO6BCcAETPvR.png",
      "sizes" : [ {
        "h" : 466,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1135,
        "resize" : "fit",
        "w" : 828
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1135,
        "resize" : "fit",
        "w" : 828
      }, {
        "h" : 822,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZQvLqThg5L"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568423579223601152",
  "text" : "A case study in calls to action http:\/\/t.co\/ZQvLqThg5L",
  "id" : 568423579223601152,
  "created_at" : "2015-02-19 14:55:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Barnhart",
      "screen_name" : "rachbarnhart",
      "indices" : [ 95, 108 ],
      "id_str" : "16275936",
      "id" : 16275936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/0GaylvpkGO",
      "expanded_url" : "http:\/\/nyti.ms\/1w0rqJp",
      "display_url" : "nyti.ms\/1w0rqJp"
    } ]
  },
  "geo" : { },
  "id_str" : "568389725016305664",
  "text" : "Amherst and Cheektowaga blocking access to schools for immigrants: http:\/\/t.co\/0GaylvpkGO (via @rachbarnhart)",
  "id" : 568389725016305664,
  "created_at" : "2015-02-19 12:40:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Borncamp",
      "screen_name" : "borncamp",
      "indices" : [ 0, 9 ],
      "id_str" : "1002573926",
      "id" : 1002573926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568283344745705472",
  "geo" : { },
  "id_str" : "568283695414530048",
  "in_reply_to_user_id" : 1002573926,
  "text" : "@borncamp ooh. You should cite your source here",
  "id" : 568283695414530048,
  "in_reply_to_status_id" : 568283344745705472,
  "created_at" : "2015-02-19 05:39:25 +0000",
  "in_reply_to_screen_name" : "borncamp",
  "in_reply_to_user_id_str" : "1002573926",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 12, 22 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/QHKCnxl3Wp",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2013\/11\/23\/sync-and-edit-files-on-two-iphones\/",
      "display_url" : "quaran.to\/blog\/2013\/11\/2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "568140394128674816",
  "geo" : { },
  "id_str" : "568140833528000512",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante @aquaranto we ended up on this http:\/\/t.co\/QHKCnxl3Wp",
  "id" : 568140833528000512,
  "in_reply_to_status_id" : 568140394128674816,
  "created_at" : "2015-02-18 20:11:44 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568119778839293953",
  "geo" : { },
  "id_str" : "568120074013429760",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt put that in a sweet mug",
  "id" : 568120074013429760,
  "in_reply_to_status_id" : 568119778839293953,
  "created_at" : "2015-02-18 18:49:15 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "triflin brand indeed",
      "screen_name" : "vogon",
      "indices" : [ 0, 6 ],
      "id_str" : "6326912",
      "id" : 6326912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568112258875834369",
  "geo" : { },
  "id_str" : "568112697436446721",
  "in_reply_to_user_id" : 5743852,
  "text" : "@vogon they have always been a part of my teams since i found that out. I don't think they actually surf, just all the water is removed",
  "id" : 568112697436446721,
  "in_reply_to_status_id" : 568112258875834369,
  "created_at" : "2015-02-18 18:19:56 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Bayer",
      "screen_name" : "vogon",
      "indices" : [ 0, 6 ],
      "id_str" : "6326912",
      "id" : 6326912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568112043296817152",
  "geo" : { },
  "id_str" : "568112258875834369",
  "in_reply_to_user_id" : 6326912,
  "text" : "@vogon the best part of Snorlax: they can learn Surf",
  "id" : 568112258875834369,
  "in_reply_to_status_id" : 568112043296817152,
  "created_at" : "2015-02-18 18:18:12 +0000",
  "in_reply_to_screen_name" : "vogon",
  "in_reply_to_user_id_str" : "6326912",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 28, 40 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/7uTVkgYjYk",
      "expanded_url" : "https:\/\/archive.org\/details\/Aqueous2015-02-06.matrix.CK63.SBD.flac16",
      "display_url" : "archive.org\/details\/Aqueou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568091554386223104",
  "text" : "2\/6\/15 is a short and sweet @AqueousBand set to listen to if you need some work jams today - https:\/\/t.co\/7uTVkgYjYk",
  "id" : 568091554386223104,
  "created_at" : "2015-02-18 16:55:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568069270061641728",
  "text" : "Nothing like laying the guilt on early in the morning as you realize what day it is and you had an egg for breakfast",
  "id" : 568069270061641728,
  "created_at" : "2015-02-18 15:27:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 0, 11 ],
      "id_str" : "67117740",
      "id" : 67117740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568030723149578240",
  "geo" : { },
  "id_str" : "568032917605064705",
  "in_reply_to_user_id" : 67117740,
  "text" : "@Dianna_2Ns still waiting...",
  "id" : 568032917605064705,
  "in_reply_to_status_id" : 568030723149578240,
  "created_at" : "2015-02-18 13:02:55 +0000",
  "in_reply_to_screen_name" : "Dianna_2Ns",
  "in_reply_to_user_id_str" : "67117740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry W. Cashdollar",
      "screen_name" : "_larry0",
      "indices" : [ 0, 8 ],
      "id_str" : "17055552",
      "id" : 17055552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568016238477254656",
  "geo" : { },
  "id_str" : "568027781956677632",
  "in_reply_to_user_id" : 17055552,
  "text" : "@_larry0 you could also grab \/specs.4.8.gz which has every gem available, then gunzip\/Marshal.load it (watch the output of gem install -V)",
  "id" : 568027781956677632,
  "in_reply_to_status_id" : 568016238477254656,
  "created_at" : "2015-02-18 12:42:31 +0000",
  "in_reply_to_screen_name" : "_larry0",
  "in_reply_to_user_id_str" : "17055552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/xZTRXJeuEQ",
      "expanded_url" : "http:\/\/help.rubygems.org\/discussions\/problems\/20470-kali-linux-plise-halp-myyyyyyyyyyyyyyyyyyy",
      "display_url" : "help.rubygems.org\/discussions\/pr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567916382324535296",
  "text" : "I feel awful for this confused user running bundle as root and trying to yank then push the timecop gem? What? http:\/\/t.co\/xZTRXJeuEQ",
  "id" : 567916382324535296,
  "created_at" : "2015-02-18 05:19:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry W. Cashdollar",
      "screen_name" : "_larry0",
      "indices" : [ 0, 8 ],
      "id_str" : "17055552",
      "id" : 17055552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567829713016860672",
  "geo" : { },
  "id_str" : "567914846718570496",
  "in_reply_to_user_id" : 17055552,
  "text" : "@_larry0 could you please use the API instead? Would be a lot faster :)",
  "id" : 567914846718570496,
  "in_reply_to_status_id" : 567829713016860672,
  "created_at" : "2015-02-18 05:13:45 +0000",
  "in_reply_to_screen_name" : "_larry0",
  "in_reply_to_user_id_str" : "17055552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/567912343553708033\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/1LwakqGz91",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-GhQ_1CMAAU8oG.png",
      "id_str" : "567912341409247232",
      "id" : 567912341409247232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-GhQ_1CMAAU8oG.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1LwakqGz91"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567912343553708033",
  "text" : "Gaming in 2015 http:\/\/t.co\/1LwakqGz91",
  "id" : 567912343553708033,
  "created_at" : "2015-02-18 05:03:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SPLC",
      "screen_name" : "splcenter",
      "indices" : [ 3, 13 ],
      "id_str" : "65698096",
      "id" : 65698096
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/splcenter\/status\/567843488831643651\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/i9BgqpSgpn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Epf7PCUAAKaFq.jpg",
      "id_str" : "567780656478834688",
      "id" : 567780656478834688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Epf7PCUAAKaFq.jpg",
      "sizes" : [ {
        "h" : 430,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 638
      } ],
      "display_url" : "pic.twitter.com\/i9BgqpSgpn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/3q8RSEZ7Cw",
      "expanded_url" : "http:\/\/sp.lc\/Jdq6L",
      "display_url" : "sp.lc\/Jdq6L"
    } ]
  },
  "geo" : { },
  "id_str" : "567845085137661952",
  "text" : "RT @splcenter: Boston's using prisoners to shovel mounds of snow in frigid temps. They\u2019ll make $0.20 an hour. http:\/\/t.co\/3q8RSEZ7Cw http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/splcenter\/status\/567843488831643651\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/i9BgqpSgpn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Epf7PCUAAKaFq.jpg",
        "id_str" : "567780656478834688",
        "id" : 567780656478834688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Epf7PCUAAKaFq.jpg",
        "sizes" : [ {
          "h" : 430,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 638
        } ],
        "display_url" : "pic.twitter.com\/i9BgqpSgpn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/3q8RSEZ7Cw",
        "expanded_url" : "http:\/\/sp.lc\/Jdq6L",
        "display_url" : "sp.lc\/Jdq6L"
      } ]
    },
    "geo" : { },
    "id_str" : "567843488831643651",
    "text" : "Boston's using prisoners to shovel mounds of snow in frigid temps. They\u2019ll make $0.20 an hour. http:\/\/t.co\/3q8RSEZ7Cw http:\/\/t.co\/i9BgqpSgpn",
    "id" : 567843488831643651,
    "created_at" : "2015-02-18 00:30:12 +0000",
    "user" : {
      "name" : "SPLC",
      "screen_name" : "splcenter",
      "protected" : false,
      "id_str" : "65698096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523117315122937858\/8azI4HEC_normal.png",
      "id" : 65698096,
      "verified" : true
    }
  },
  "id" : 567845085137661952,
  "created_at" : "2015-02-18 00:36:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "has_many :wizards",
      "screen_name" : "kerrizor",
      "indices" : [ 0, 9 ],
      "id_str" : "2998581",
      "id" : 2998581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567785276693430272",
  "geo" : { },
  "id_str" : "567785540339392513",
  "in_reply_to_user_id" : 2998581,
  "text" : "@kerrizor a thousand times this",
  "id" : 567785540339392513,
  "in_reply_to_status_id" : 567785276693430272,
  "created_at" : "2015-02-17 20:39:56 +0000",
  "in_reply_to_screen_name" : "kerrizor",
  "in_reply_to_user_id_str" : "2998581",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Worst Weather",
      "screen_name" : "worst_weather",
      "indices" : [ 3, 17 ],
      "id_str" : "1738372928",
      "id" : 1738372928
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/worst_weather\/status\/567776824806342657\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/zWBY9YPTgA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-EmA4_IgAAXm2z.jpg",
      "id_str" : "567776824764432384",
      "id" : 567776824764432384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-EmA4_IgAAXm2z.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/zWBY9YPTgA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/ipHlSnMFB4",
      "expanded_url" : "http:\/\/ift.tt\/1AiE2dx",
      "display_url" : "ift.tt\/1AiE2dx"
    } ]
  },
  "geo" : { },
  "id_str" : "567776985116868609",
  "text" : "RT @worst_weather: Today's worst weather http:\/\/t.co\/ipHlSnMFB4 http:\/\/t.co\/zWBY9YPTgA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/worst_weather\/status\/567776824806342657\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/zWBY9YPTgA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-EmA4_IgAAXm2z.jpg",
        "id_str" : "567776824764432384",
        "id" : 567776824764432384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-EmA4_IgAAXm2z.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 283,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/zWBY9YPTgA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/ipHlSnMFB4",
        "expanded_url" : "http:\/\/ift.tt\/1AiE2dx",
        "display_url" : "ift.tt\/1AiE2dx"
      } ]
    },
    "geo" : { },
    "id_str" : "567776824806342657",
    "text" : "Today's worst weather http:\/\/t.co\/ipHlSnMFB4 http:\/\/t.co\/zWBY9YPTgA",
    "id" : 567776824806342657,
    "created_at" : "2015-02-17 20:05:18 +0000",
    "user" : {
      "name" : "Worst Weather",
      "screen_name" : "worst_weather",
      "protected" : false,
      "id_str" : "1738372928",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527176705908035584\/bH9IfMzp_normal.jpeg",
      "id" : 1738372928,
      "verified" : false
    }
  },
  "id" : 567776985116868609,
  "created_at" : "2015-02-17 20:05:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate West",
      "screen_name" : "nate_west",
      "indices" : [ 0, 10 ],
      "id_str" : "942661",
      "id" : 942661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/ccqaoTxUGQ",
      "expanded_url" : "http:\/\/blog.ameliagreenhall.com\/post\/planning-your-weekend-getaway-to-jason-nation-its-huge",
      "display_url" : "blog.ameliagreenhall.com\/post\/planning-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "567770215081971712",
  "geo" : { },
  "id_str" : "567770513154785280",
  "in_reply_to_user_id" : 942661,
  "text" : "@nate_west no it's the main waterway in the Jason Nation! http:\/\/t.co\/ccqaoTxUGQ",
  "id" : 567770513154785280,
  "in_reply_to_status_id" : 567770215081971712,
  "created_at" : "2015-02-17 19:40:13 +0000",
  "in_reply_to_screen_name" : "nate_west",
  "in_reply_to_user_id_str" : "942661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567769132951932928",
  "text" : "Trying out this display name for a few hours because this is hilarious",
  "id" : 567769132951932928,
  "created_at" : "2015-02-17 19:34:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/567763999602016257\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/Yw9jEeX7Lt",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B-EaWUlCUAAfdMs.png",
      "id_str" : "567763998808887296",
      "id" : 567763998808887296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B-EaWUlCUAAfdMs.png",
      "sizes" : [ {
        "h" : 166,
        "resize" : "fit",
        "w" : 190
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 166,
        "resize" : "fit",
        "w" : 190
      }, {
        "h" : 166,
        "resize" : "fit",
        "w" : 190
      }, {
        "h" : 166,
        "resize" : "fit",
        "w" : 190
      } ],
      "display_url" : "pic.twitter.com\/Yw9jEeX7Lt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/ccqaoTxUGQ",
      "expanded_url" : "http:\/\/blog.ameliagreenhall.com\/post\/planning-your-weekend-getaway-to-jason-nation-its-huge",
      "display_url" : "blog.ameliagreenhall.com\/post\/planning-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567763999602016257",
  "text" : "I cannot wait for the Silicon Valley meltdown forthcoming about http:\/\/t.co\/ccqaoTxUGQ http:\/\/t.co\/Yw9jEeX7Lt",
  "id" : 567763999602016257,
  "created_at" : "2015-02-17 19:14:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567755424754323456",
  "geo" : { },
  "id_str" : "567755846458044418",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 this appeals to me in light of...Serial fanatics",
  "id" : 567755846458044418,
  "in_reply_to_status_id" : 567755424754323456,
  "created_at" : "2015-02-17 18:41:56 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567753867912544257",
  "text" : "Achewood's pretty funny and I never really got into it. Should I? (Y\/N)",
  "id" : 567753867912544257,
  "created_at" : "2015-02-17 18:34:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 24, 36 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/567709816576282624\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/fECdOb7wJ1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-DpEd5CYAAcmAX.jpg",
      "id_str" : "567709816001290240",
      "id" : 567709816001290240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-DpEd5CYAAcmAX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 927,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 776
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 776
      } ],
      "display_url" : "pic.twitter.com\/fECdOb7wJ1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/I2U2d6rGss",
      "expanded_url" : "http:\/\/upstatelive.com\/2015\/02\/17\/aqueous-spring-tour-includes-upstate-dates-and-colorado-debut\/",
      "display_url" : "upstatelive.com\/2015\/02\/17\/aqu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567709816576282624",
  "text" : "Colorado, get ready for @AqueousBand!!! So happy for this. http:\/\/t.co\/I2U2d6rGss http:\/\/t.co\/fECdOb7wJ1",
  "id" : 567709816576282624,
  "created_at" : "2015-02-17 15:39:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/567516733742002176\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/ik2t0mZQT2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-A5da8CEAAazqU.jpg",
      "id_str" : "567516730658787328",
      "id" : 567516730658787328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-A5da8CEAAazqU.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ik2t0mZQT2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567508819685941249",
  "geo" : { },
  "id_str" : "567516733742002176",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 comrade? http:\/\/t.co\/ik2t0mZQT2",
  "id" : 567516733742002176,
  "in_reply_to_status_id" : 567508819685941249,
  "created_at" : "2015-02-17 02:51:47 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 12, 21 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567511984204435456",
  "geo" : { },
  "id_str" : "567512207110332417",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @sabiddle something something naming things something something is the hardest thing something",
  "id" : 567512207110332417,
  "in_reply_to_status_id" : 567511984204435456,
  "created_at" : "2015-02-17 02:33:48 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/QjGKcGsNXL",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/dwarffortress\/comments\/2w4u2q\/so_i_decided_to_make_a_fisherdwarf_be_my_new\/",
      "display_url" : "reddit.com\/r\/dwarffortres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567508609869692928",
  "text" : "Fisherdwarf assigned to be chief medical dwarf. Misdiagnoses cut on arm as \"rotten lungs\", orders operation... http:\/\/t.co\/QjGKcGsNXL",
  "id" : 567508609869692928,
  "created_at" : "2015-02-17 02:19:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567507731758989312",
  "geo" : { },
  "id_str" : "567507786162900992",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 I'll take you up on that",
  "id" : 567507786162900992,
  "in_reply_to_status_id" : 567507731758989312,
  "created_at" : "2015-02-17 02:16:14 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wilkie (tired butt)",
      "screen_name" : "wilkieii",
      "indices" : [ 0, 9 ],
      "id_str" : "17047955",
      "id" : 17047955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567482757472088067",
  "geo" : { },
  "id_str" : "567488067657674754",
  "in_reply_to_user_id" : 17047955,
  "text" : "@wilkieii :\\ lame. seems to happen no matter what flavor of version manager eventually",
  "id" : 567488067657674754,
  "in_reply_to_status_id" : 567482757472088067,
  "created_at" : "2015-02-17 00:57:53 +0000",
  "in_reply_to_screen_name" : "wilkieii",
  "in_reply_to_user_id_str" : "17047955",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wilkie (tired butt)",
      "screen_name" : "wilkieii",
      "indices" : [ 0, 9 ],
      "id_str" : "17047955",
      "id" : 17047955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567481830027563008",
  "geo" : { },
  "id_str" : "567482460523749378",
  "in_reply_to_user_id" : 17047955,
  "text" : "@wilkieii wat. There's no ftp there. HTTPS should work",
  "id" : 567482460523749378,
  "in_reply_to_status_id" : 567481830027563008,
  "created_at" : "2015-02-17 00:35:36 +0000",
  "in_reply_to_screen_name" : "wilkieii",
  "in_reply_to_user_id_str" : "17047955",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arthur Neves",
      "screen_name" : "arthurnn",
      "indices" : [ 3, 12 ],
      "id_str" : "213767432",
      "id" : 213767432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/KEjEQN8dDf",
      "expanded_url" : "https:\/\/rubygems.org\/gems\/rails\/versions\/4.2.0",
      "display_url" : "rubygems.org\/gems\/rails\/ver\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567444305761935360",
  "text" : "RT @arthurnn: Gems will show a checksum now. https:\/\/t.co\/KEjEQN8dDf ! we are backfilling the db, but all new pushed gems should have it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/KEjEQN8dDf",
        "expanded_url" : "https:\/\/rubygems.org\/gems\/rails\/versions\/4.2.0",
        "display_url" : "rubygems.org\/gems\/rails\/ver\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "567443978359156736",
    "text" : "Gems will show a checksum now. https:\/\/t.co\/KEjEQN8dDf ! we are backfilling the db, but all new pushed gems should have it.",
    "id" : 567443978359156736,
    "created_at" : "2015-02-16 22:02:41 +0000",
    "user" : {
      "name" : "Arthur Neves",
      "screen_name" : "arthurnn",
      "protected" : false,
      "id_str" : "213767432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487261517008498688\/LGAbeHiC_normal.jpeg",
      "id" : 213767432,
      "verified" : false
    }
  },
  "id" : 567444305761935360,
  "created_at" : "2015-02-16 22:03:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567440428782202881",
  "geo" : { },
  "id_str" : "567441410693926912",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone you need to read some more PNAS",
  "id" : 567441410693926912,
  "in_reply_to_status_id" : 567440428782202881,
  "created_at" : "2015-02-16 21:52:29 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mcc",
      "screen_name" : "mcclure111",
      "indices" : [ 3, 14 ],
      "id_str" : "312426579",
      "id" : 312426579
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mcclure111\/status\/567310249292353536\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/90t1p2HPhk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B999qjWCUAEJAX2.png",
      "id_str" : "567310248067616769",
      "id" : 567310248067616769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B999qjWCUAEJAX2.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 593
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 593
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 594
      } ],
      "display_url" : "pic.twitter.com\/90t1p2HPhk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567433369709846528",
  "text" : "RT @mcclure111: \"GLOBAL THERMONUCLEAR WAR\" http:\/\/t.co\/90t1p2HPhk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mcclure111\/status\/567310249292353536\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/90t1p2HPhk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B999qjWCUAEJAX2.png",
        "id_str" : "567310248067616769",
        "id" : 567310248067616769,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B999qjWCUAEJAX2.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 593
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 593
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 594
        } ],
        "display_url" : "pic.twitter.com\/90t1p2HPhk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567310249292353536",
    "text" : "\"GLOBAL THERMONUCLEAR WAR\" http:\/\/t.co\/90t1p2HPhk",
    "id" : 567310249292353536,
    "created_at" : "2015-02-16 13:11:18 +0000",
    "user" : {
      "name" : "mcc",
      "screen_name" : "mcclure111",
      "protected" : false,
      "id_str" : "312426579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563051319007510528\/6mdkYASo_normal.png",
      "id" : 312426579,
      "verified" : false
    }
  },
  "id" : 567433369709846528,
  "created_at" : "2015-02-16 21:20:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Handsome",
      "screen_name" : "Millennial_Dave",
      "indices" : [ 0, 16 ],
      "id_str" : "60185021",
      "id" : 60185021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567423919381282816",
  "geo" : { },
  "id_str" : "567424151304941568",
  "in_reply_to_user_id" : 60185021,
  "text" : "@Millennial_Dave haha yep :)",
  "id" : 567424151304941568,
  "in_reply_to_status_id" : 567423919381282816,
  "created_at" : "2015-02-16 20:43:54 +0000",
  "in_reply_to_screen_name" : "Millennial_Dave",
  "in_reply_to_user_id_str" : "60185021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/BtFmHegp15",
      "expanded_url" : "http:\/\/curated.co\/",
      "display_url" : "curated.co"
    } ]
  },
  "geo" : { },
  "id_str" : "567393418553196544",
  "text" : "Actually http:\/\/t.co\/BtFmHegp15 seems like a nicer version of Revue. :\\",
  "id" : 567393418553196544,
  "created_at" : "2015-02-16 18:41:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 3, 15 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567388650279677952",
  "text" : "RT @AqueousBand: New TOUR DATES coming soon!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567388606340530176",
    "text" : "New TOUR DATES coming soon!!",
    "id" : 567388606340530176,
    "created_at" : "2015-02-16 18:22:39 +0000",
    "user" : {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "protected" : false,
      "id_str" : "26904582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567748496355516416\/9YUfd46g_normal.jpeg",
      "id" : 26904582,
      "verified" : false
    }
  },
  "id" : 567388650279677952,
  "created_at" : "2015-02-16 18:22:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/3XB3lZphZl",
      "expanded_url" : "http:\/\/www.getrevue.co\/profile\/qrush",
      "display_url" : "getrevue.co\/profile\/qrush"
    } ]
  },
  "geo" : { },
  "id_str" : "567388629677256704",
  "text" : "Going to try and tweet less links and instead try out Revue on a weekly basis - http:\/\/t.co\/3XB3lZphZl want to sign up and try it out?",
  "id" : 567388629677256704,
  "created_at" : "2015-02-16 18:22:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Del Santo \u26A1",
      "screen_name" : "tjdelsanto",
      "indices" : [ 3, 14 ],
      "id_str" : "36184638",
      "id" : 36184638
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tjdelsanto\/status\/567374649097740288\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/pghRQSPdIT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-4PKSIYAAYSUh.jpg",
      "id_str" : "567374648669921280",
      "id" : 567374648669921280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-4PKSIYAAYSUh.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 647
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 647
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pghRQSPdIT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567386841943269376",
  "text" : "RT @tjdelsanto: Here's today's satellite picture from MODIS.  It looks like there's lots of snow in New England. ;) http:\/\/t.co\/pghRQSPdIT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tjdelsanto\/status\/567374649097740288\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/pghRQSPdIT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-4PKSIYAAYSUh.jpg",
        "id_str" : "567374648669921280",
        "id" : 567374648669921280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-4PKSIYAAYSUh.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 647
        }, {
          "h" : 625,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 647
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/pghRQSPdIT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567374649097740288",
    "text" : "Here's today's satellite picture from MODIS.  It looks like there's lots of snow in New England. ;) http:\/\/t.co\/pghRQSPdIT",
    "id" : 567374649097740288,
    "created_at" : "2015-02-16 17:27:12 +0000",
    "user" : {
      "name" : "TJ Del Santo \u26A1",
      "screen_name" : "tjdelsanto",
      "protected" : false,
      "id_str" : "36184638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482512175987445760\/aQ9HfdBC_normal.jpeg",
      "id" : 36184638,
      "verified" : false
    }
  },
  "id" : 567386841943269376,
  "created_at" : "2015-02-16 18:15:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/mm5NvZHu6s",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=7dvLgQc4gks&list=PL121102D516F0320B",
      "display_url" : "youtube.com\/watch?v=7dvLgQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567385776065765377",
  "text" : "Current (better quality) theme song for this week https:\/\/t.co\/mm5NvZHu6s",
  "id" : 567385776065765377,
  "created_at" : "2015-02-16 18:11:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 0, 11 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567381324521283584",
  "geo" : { },
  "id_str" : "567383216386895872",
  "in_reply_to_user_id" : 14372143,
  "text" : "@jasonfried this could be a sweet album cover",
  "id" : 567383216386895872,
  "in_reply_to_status_id" : 567381324521283584,
  "created_at" : "2015-02-16 18:01:14 +0000",
  "in_reply_to_screen_name" : "jasonfried",
  "in_reply_to_user_id_str" : "14372143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jefferson Shaman V.",
      "screen_name" : "shamanime",
      "indices" : [ 0, 10 ],
      "id_str" : "14583626",
      "id" : 14583626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567356316700930049",
  "geo" : { },
  "id_str" : "567375907048800256",
  "in_reply_to_user_id" : 14583626,
  "text" : "@shamanime incoming\/outgoing webhooks and a little Sinatra magic",
  "id" : 567375907048800256,
  "in_reply_to_status_id" : 567356316700930049,
  "created_at" : "2015-02-16 17:32:12 +0000",
  "in_reply_to_screen_name" : "shamanime",
  "in_reply_to_user_id_str" : "14583626",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 53, 63 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/biwDqHL2ML",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    }, {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/5dFeniwjyN",
      "expanded_url" : "http:\/\/pickaxe.club\/#overworld\/0\/10\/2250\/3225\/64",
      "display_url" : "pickaxe.club\/#overworld\/0\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567345795326672896",
  "text" : "The first ad on http:\/\/t.co\/biwDqHL2ML award goes to @confreaks http:\/\/t.co\/5dFeniwjyN",
  "id" : 567345795326672896,
  "created_at" : "2015-02-16 15:32:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tow truck central",
      "screen_name" : "duh_nellll",
      "indices" : [ 0, 11 ],
      "id_str" : "146513248",
      "id" : 146513248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567343033315000320",
  "geo" : { },
  "id_str" : "567343150037864448",
  "in_reply_to_user_id" : 146513248,
  "text" : "@duh_nellll 30 stories tall made of radiation",
  "id" : 567343150037864448,
  "in_reply_to_status_id" : 567343033315000320,
  "created_at" : "2015-02-16 15:22:02 +0000",
  "in_reply_to_screen_name" : "duh_nellll",
  "in_reply_to_user_id_str" : "146513248",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567195524768358401",
  "text" : "I feel like we've reached that point in Day After Tomorrow where we have to break into a fast food place and heat ourselves to live",
  "id" : 567195524768358401,
  "created_at" : "2015-02-16 05:35:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conferenshish",
      "screen_name" : "tundal45",
      "indices" : [ 0, 9 ],
      "id_str" : "5573992",
      "id" : 5573992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567148590783823872",
  "geo" : { },
  "id_str" : "567148896447508482",
  "in_reply_to_user_id" : 5573992,
  "text" : "@tundal45 Shai'hulud",
  "id" : 567148896447508482,
  "in_reply_to_status_id" : 567148590783823872,
  "created_at" : "2015-02-16 02:30:08 +0000",
  "in_reply_to_screen_name" : "tundal45",
  "in_reply_to_user_id_str" : "5573992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/567148354207883264\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/FtktHWjgRV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B97qbBICUAAKVUv.jpg",
      "id_str" : "567148352974770176",
      "id" : 567148352974770176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B97qbBICUAAKVUv.jpg",
      "sizes" : [ {
        "h" : 438,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 145,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FtktHWjgRV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567148354207883264",
  "text" : "I tried Popeye's for the first time tonight. http:\/\/t.co\/FtktHWjgRV",
  "id" : 567148354207883264,
  "created_at" : "2015-02-16 02:27:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julz",
      "screen_name" : "lvnphish",
      "indices" : [ 0, 9 ],
      "id_str" : "15944661",
      "id" : 15944661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/zt7wzpMi3z",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/phish\/comments\/2w0pjl\/spotted_in_fort_wayne_in_a_few_months_back_i\/",
      "display_url" : "reddit.com\/r\/phish\/commen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567146597033582592",
  "in_reply_to_user_id" : 15944661,
  "text" : "@lvnphish I think someone found your car on \/r\/phish http:\/\/t.co\/zt7wzpMi3z",
  "id" : 567146597033582592,
  "created_at" : "2015-02-16 02:21:00 +0000",
  "in_reply_to_screen_name" : "lvnphish",
  "in_reply_to_user_id_str" : "15944661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567139840995491840",
  "text" : "Paul McCartney's drummer is slowly sucking his life force away",
  "id" : 567139840995491840,
  "created_at" : "2015-02-16 01:54:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567135148991197184",
  "text" : "This all feels very forced",
  "id" : 567135148991197184,
  "created_at" : "2015-02-16 01:35:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567131416073228288",
  "text" : "I'm glad they included Jimmy Fallon laughing in a sketch in the montage",
  "id" : 567131416073228288,
  "created_at" : "2015-02-16 01:20:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567129882820227073",
  "text" : "Sunday Night Live? I don't get it.",
  "id" : 567129882820227073,
  "created_at" : "2015-02-16 01:14:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567094893969817600",
  "text" : "Turns out a Banh Mi from Niagara Seafood is the perfect cure for -7 temps",
  "id" : 567094893969817600,
  "created_at" : "2015-02-15 22:55:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567091113484619776",
  "geo" : { },
  "id_str" : "567094772985114625",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl it was so funny!",
  "id" : 567094772985114625,
  "in_reply_to_status_id" : 567091113484619776,
  "created_at" : "2015-02-15 22:55:04 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567077548660498432",
  "text" : "Sherman and Mr Peabody was better than a lot of movies I have seen lately",
  "id" : 567077548660498432,
  "created_at" : "2015-02-15 21:46:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Keigher",
      "screen_name" : "afreak",
      "indices" : [ 3, 10 ],
      "id_str" : "1476431",
      "id" : 1476431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/qqZG9KJKaB",
      "expanded_url" : "https:\/\/github.com\/peenuty\/BitcoinEmissions",
      "display_url" : "github.com\/peenuty\/Bitcoi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567072078986096640",
  "text" : "RT @afreak: Each Bitcoin at this point or in the near future will release more than a tonne and a half of CO2 emissions  https:\/\/t.co\/qqZG9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/qqZG9KJKaB",
        "expanded_url" : "https:\/\/github.com\/peenuty\/BitcoinEmissions",
        "display_url" : "github.com\/peenuty\/Bitcoi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566763446264295424",
    "text" : "Each Bitcoin at this point or in the near future will release more than a tonne and a half of CO2 emissions  https:\/\/t.co\/qqZG9KJKaB",
    "id" : 566763446264295424,
    "created_at" : "2015-02-15 00:58:30 +0000",
    "user" : {
      "name" : "Colin Keigher",
      "screen_name" : "afreak",
      "protected" : false,
      "id_str" : "1476431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1300031318\/sadmac_resize_normal.png",
      "id" : 1476431,
      "verified" : false
    }
  },
  "id" : 567072078986096640,
  "created_at" : "2015-02-15 21:24:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 3, 17 ],
      "id_str" : "45490102",
      "id" : 45490102
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/markpoloncarz\/status\/567070995069288448\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/gPZzUFxYiz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B96kDvHCQAA8iBt.jpg",
      "id_str" : "567070987187798016",
      "id" : 567070987187798016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B96kDvHCQAA8iBt.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gPZzUFxYiz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567071781924528128",
  "text" : "RT @markpoloncarz: The steam coming off the \"warm\" Lake Erie waters is impressive. http:\/\/t.co\/gPZzUFxYiz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/markpoloncarz\/status\/567070995069288448\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/gPZzUFxYiz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B96kDvHCQAA8iBt.jpg",
        "id_str" : "567070987187798016",
        "id" : 567070987187798016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B96kDvHCQAA8iBt.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 581,
          "resize" : "fit",
          "w" : 1032
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/gPZzUFxYiz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.8844243, -78.8765227 ]
    },
    "id_str" : "567070995069288448",
    "text" : "The steam coming off the \"warm\" Lake Erie waters is impressive. http:\/\/t.co\/gPZzUFxYiz",
    "id" : 567070995069288448,
    "created_at" : "2015-02-15 21:20:35 +0000",
    "user" : {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "protected" : false,
      "id_str" : "45490102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572114131579179008\/EAk-fMOk_normal.jpeg",
      "id" : 45490102,
      "verified" : false
    }
  },
  "id" : 567071781924528128,
  "created_at" : "2015-02-15 21:23:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/TourF6qP1a",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/k8SzePi8qem",
      "display_url" : "swarmapp.com\/c\/k8SzePi8qem"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9067455631, -78.8433837891 ]
  },
  "id_str" : "566985203881873408",
  "text" : "I'm at Buffalo Museum of Science in Buffalo, NY https:\/\/t.co\/TourF6qP1a",
  "id" : 566985203881873408,
  "created_at" : "2015-02-15 15:39:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566980312929169409",
  "geo" : { },
  "id_str" : "566984413733715968",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff GL HF",
  "id" : 566984413733715968,
  "in_reply_to_status_id" : 566980312929169409,
  "created_at" : "2015-02-15 15:36:32 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mislav Marohni\u0107",
      "screen_name" : "mislav",
      "indices" : [ 3, 10 ],
      "id_str" : "7516242",
      "id" : 7516242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Thv61r9whl",
      "expanded_url" : "http:\/\/wayback.archive-it.org\/2782\/20110803215546\/http:\/\/1000memories.com\/what-is-forever",
      "display_url" : "wayback.archive-it.org\/2782\/201108032\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566946081489960960",
  "text" : "RT @mislav: 1000memories promised to keep your content on their platform \u201Cforever\u201D. A year later, they got acquired and shut down http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Thv61r9whl",
        "expanded_url" : "http:\/\/wayback.archive-it.org\/2782\/20110803215546\/http:\/\/1000memories.com\/what-is-forever",
        "display_url" : "wayback.archive-it.org\/2782\/201108032\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566945966029164544",
    "text" : "1000memories promised to keep your content on their platform \u201Cforever\u201D. A year later, they got acquired and shut down http:\/\/t.co\/Thv61r9whl",
    "id" : 566945966029164544,
    "created_at" : "2015-02-15 13:03:46 +0000",
    "user" : {
      "name" : "Mislav Marohni\u0107",
      "screen_name" : "mislav",
      "protected" : false,
      "id_str" : "7516242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500395960648749056\/A6trldA8_normal.jpeg",
      "id" : 7516242,
      "verified" : false
    }
  },
  "id" : 566946081489960960,
  "created_at" : "2015-02-15 13:04:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Nephew",
      "screen_name" : "snephew25",
      "indices" : [ 3, 13 ],
      "id_str" : "125562735",
      "id" : 125562735
    }, {
      "name" : "Gates Circle Liquor",
      "screen_name" : "GatesCircleLiq",
      "indices" : [ 116, 131 ],
      "id_str" : "386173726",
      "id" : 386173726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566692507530969088",
  "text" : "RT @snephew25: Overall, I think if you're intent on staying home on a day like today? Try the delivery service from @GatesCircleLiq. I appr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gates Circle Liquor",
        "screen_name" : "GatesCircleLiq",
        "indices" : [ 101, 116 ],
        "id_str" : "386173726",
        "id" : 386173726
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566690817017147393",
    "text" : "Overall, I think if you're intent on staying home on a day like today? Try the delivery service from @GatesCircleLiq. I appreciated it.",
    "id" : 566690817017147393,
    "created_at" : "2015-02-14 20:09:54 +0000",
    "user" : {
      "name" : "Samantha Nephew",
      "screen_name" : "snephew25",
      "protected" : false,
      "id_str" : "125562735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569489830909063168\/iwVOcxvd_normal.jpeg",
      "id" : 125562735,
      "verified" : false
    }
  },
  "id" : 566692507530969088,
  "created_at" : "2015-02-14 20:16:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Nephew",
      "screen_name" : "snephew25",
      "indices" : [ 0, 10 ],
      "id_str" : "125562735",
      "id" : 125562735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566688928280084480",
  "geo" : { },
  "id_str" : "566690664822218752",
  "in_reply_to_user_id" : 125562735,
  "text" : "@snephew25 holy crap !!! I want to do this",
  "id" : 566690664822218752,
  "in_reply_to_status_id" : 566688928280084480,
  "created_at" : "2015-02-14 20:09:17 +0000",
  "in_reply_to_screen_name" : "snephew25",
  "in_reply_to_user_id_str" : "125562735",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Hart",
      "screen_name" : "Hates_",
      "indices" : [ 0, 7 ],
      "id_str" : "6328872",
      "id" : 6328872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566689894266052610",
  "geo" : { },
  "id_str" : "566690505757425665",
  "in_reply_to_user_id" : 6328872,
  "text" : "@Hates_ same. What madness",
  "id" : 566690505757425665,
  "in_reply_to_status_id" : 566689894266052610,
  "created_at" : "2015-02-14 20:08:39 +0000",
  "in_reply_to_screen_name" : "Hates_",
  "in_reply_to_user_id_str" : "6328872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBlackMarket",
      "screen_name" : "theBMFT",
      "indices" : [ 0, 8 ],
      "id_str" : "900882032",
      "id" : 900882032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566612833484677120",
  "geo" : { },
  "id_str" : "566684426239619073",
  "in_reply_to_user_id" : 900882032,
  "text" : "@theBMFT same pickup location as last year? Blanking.",
  "id" : 566684426239619073,
  "in_reply_to_status_id" : 566612833484677120,
  "created_at" : "2015-02-14 19:44:30 +0000",
  "in_reply_to_screen_name" : "theBMFT",
  "in_reply_to_user_id_str" : "900882032",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minecraft",
      "screen_name" : "Minecraft",
      "indices" : [ 4, 14 ],
      "id_str" : "64565898",
      "id" : 64565898
    }, {
      "name" : "Matt Slack",
      "screen_name" : "slack",
      "indices" : [ 18, 24 ],
      "id_str" : "8922",
      "id" : 8922
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/566676919739883521\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/paoSE2Pb36",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B909p72CUAALTTK.png",
      "id_str" : "566676918766817280",
      "id" : 566676918766817280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B909p72CUAALTTK.png",
      "sizes" : [ {
        "h" : 83,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 194,
        "resize" : "fit",
        "w" : 786
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 194,
        "resize" : "fit",
        "w" : 786
      }, {
        "h" : 148,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/paoSE2Pb36"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/biwDqHL2ML",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "566676919739883521",
  "text" : "The @Minecraft to @Slack gateway in motion on http:\/\/t.co\/biwDqHL2ML: http:\/\/t.co\/paoSE2Pb36",
  "id" : 566676919739883521,
  "created_at" : "2015-02-14 19:14:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566665875940311040",
  "text" : "Snow in my piled up front yard is officially 2x taller than me and 3x taller than my dog",
  "id" : 566665875940311040,
  "created_at" : "2015-02-14 18:30:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566640490167021568",
  "text" : "A toddler's life: Eat. Run around until you fall on something. Eat. Sleep. Repeat.",
  "id" : 566640490167021568,
  "created_at" : "2015-02-14 16:49:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/566640071336411137\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/LFBJOMCafd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B90cJF-CAAABeDp.png",
      "id_str" : "566640070665306112",
      "id" : 566640070665306112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B90cJF-CAAABeDp.png",
      "sizes" : [ {
        "h" : 593,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 904,
        "resize" : "fit",
        "w" : 1560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/LFBJOMCafd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566640071336411137",
  "text" : "A bit of tail | grep | while magic, and we have two way chat between Slack &lt;=&gt; Minecraft! http:\/\/t.co\/LFBJOMCafd",
  "id" : 566640071336411137,
  "created_at" : "2015-02-14 16:48:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 0, 11 ],
      "id_str" : "2355631",
      "id" : 2355631
    }, {
      "name" : "Eric Lindvall",
      "screen_name" : "lindvall",
      "indices" : [ 12, 21 ],
      "id_str" : "7383702",
      "id" : 7383702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566633765267861505",
  "geo" : { },
  "id_str" : "566639827286622209",
  "in_reply_to_user_id" : 2355631,
  "text" : "@lmarburger @lindvall Just figured it out. NVM",
  "id" : 566639827286622209,
  "in_reply_to_status_id" : 566633765267861505,
  "created_at" : "2015-02-14 16:47:17 +0000",
  "in_reply_to_screen_name" : "lmarburger",
  "in_reply_to_user_id_str" : "2355631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 4, 15 ],
      "id_str" : "2355631",
      "id" : 2355631
    }, {
      "name" : "Eric Lindvall",
      "screen_name" : "lindvall",
      "indices" : [ 16, 25 ],
      "id_str" : "7383702",
      "id" : 7383702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566624352821456896",
  "text" : "hey @lmarburger @lindvall is it possible to send alerts on papertrail &lt; 1 min? Like...instantly?",
  "id" : 566624352821456896,
  "created_at" : "2015-02-14 15:45:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBlackMarket",
      "screen_name" : "theBMFT",
      "indices" : [ 0, 8 ],
      "id_str" : "900882032",
      "id" : 900882032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566612395502874625",
  "geo" : { },
  "id_str" : "566612691934924801",
  "in_reply_to_user_id" : 900882032,
  "text" : "@theBMFT One of these days I'm going to buy a sled for my husky",
  "id" : 566612691934924801,
  "in_reply_to_status_id" : 566612395502874625,
  "created_at" : "2015-02-14 14:59:27 +0000",
  "in_reply_to_screen_name" : "theBMFT",
  "in_reply_to_user_id_str" : "900882032",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBlackMarket",
      "screen_name" : "theBMFT",
      "indices" : [ 0, 8 ],
      "id_str" : "900882032",
      "id" : 900882032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566611444498972672",
  "geo" : { },
  "id_str" : "566612334655705089",
  "in_reply_to_user_id" : 900882032,
  "text" : "@theBMFT 6 sounds great, thanks!",
  "id" : 566612334655705089,
  "in_reply_to_status_id" : 566611444498972672,
  "created_at" : "2015-02-14 14:58:02 +0000",
  "in_reply_to_screen_name" : "theBMFT",
  "in_reply_to_user_id_str" : "900882032",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NWS BUFFALO",
      "screen_name" : "NWSBUFFALO",
      "indices" : [ 3, 14 ],
      "id_str" : "982762350",
      "id" : 982762350
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NWSBUFFALO\/status\/566602519791415296\/photo\/1",
      "indices" : [ 123, 144 ],
      "url" : "http:\/\/t.co\/TRAfxPcXhy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9z5_SuCcAArJX4.png",
      "id_str" : "566602518893850624",
      "id" : 566602518893850624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9z5_SuCcAArJX4.png",
      "sizes" : [ {
        "h" : 836,
        "resize" : "fit",
        "w" : 851
      }, {
        "h" : 836,
        "resize" : "fit",
        "w" : 851
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TRAfxPcXhy"
    } ],
    "hashtags" : [ {
      "text" : "snow",
      "indices" : [ 22, 27 ]
    }, {
      "text" : "Buffalo",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/SbU9kmp2T4",
      "expanded_url" : "https:\/\/nwschat.weather.gov\/p.php?pid=201502141405-KBUF-WWUS81-SPSBUF",
      "display_url" : "nwschat.weather.gov\/p.php?pid=2015\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566611141577560064",
  "text" : "RT @NWSBUFFALO: Heavy #snow band over #Buffalo with 2-3\"\/hr snow rates &amp; near zero visibility. https:\/\/t.co\/SbU9kmp2T4 http:\/\/t.co\/TRAfxPcX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NWSBUFFALO\/status\/566602519791415296\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/TRAfxPcXhy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9z5_SuCcAArJX4.png",
        "id_str" : "566602518893850624",
        "id" : 566602518893850624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9z5_SuCcAArJX4.png",
        "sizes" : [ {
          "h" : 836,
          "resize" : "fit",
          "w" : 851
        }, {
          "h" : 836,
          "resize" : "fit",
          "w" : 851
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 589,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TRAfxPcXhy"
      } ],
      "hashtags" : [ {
        "text" : "snow",
        "indices" : [ 6, 11 ]
      }, {
        "text" : "Buffalo",
        "indices" : [ 22, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/SbU9kmp2T4",
        "expanded_url" : "https:\/\/nwschat.weather.gov\/p.php?pid=201502141405-KBUF-WWUS81-SPSBUF",
        "display_url" : "nwschat.weather.gov\/p.php?pid=2015\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566602519791415296",
    "text" : "Heavy #snow band over #Buffalo with 2-3\"\/hr snow rates &amp; near zero visibility. https:\/\/t.co\/SbU9kmp2T4 http:\/\/t.co\/TRAfxPcXhy",
    "id" : 566602519791415296,
    "created_at" : "2015-02-14 14:19:02 +0000",
    "user" : {
      "name" : "NWS BUFFALO",
      "screen_name" : "NWSBUFFALO",
      "protected" : false,
      "id_str" : "982762350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465137770696957952\/-6l64r-b_normal.jpeg",
      "id" : 982762350,
      "verified" : true
    }
  },
  "id" : 566611141577560064,
  "created_at" : "2015-02-14 14:53:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBlackMarket",
      "screen_name" : "theBMFT",
      "indices" : [ 0, 8 ],
      "id_str" : "900882032",
      "id" : 900882032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566364114143182849",
  "geo" : { },
  "id_str" : "566610896290459649",
  "in_reply_to_user_id" : 900882032,
  "text" : "@theBMFT what's the earliest pickup time? Email confirmation doesn't have it.",
  "id" : 566610896290459649,
  "in_reply_to_status_id" : 566364114143182849,
  "created_at" : "2015-02-14 14:52:19 +0000",
  "in_reply_to_screen_name" : "theBMFT",
  "in_reply_to_user_id_str" : "900882032",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Bowsher",
      "screen_name" : "boffbowsh",
      "indices" : [ 0, 10 ],
      "id_str" : "7556272",
      "id" : 7556272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566601868764540928",
  "geo" : { },
  "id_str" : "566609710346809344",
  "in_reply_to_user_id" : 7556272,
  "text" : "@boffbowsh i put some tables in and a storeroom.",
  "id" : 566609710346809344,
  "in_reply_to_status_id" : 566601868764540928,
  "created_at" : "2015-02-14 14:47:36 +0000",
  "in_reply_to_screen_name" : "boffbowsh",
  "in_reply_to_user_id_str" : "7556272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/566594707359154176\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/Bha1p5r6kc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9zy4gGCMAA0bcQ.png",
      "id_str" : "566594705643679744",
      "id" : 566594705643679744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9zy4gGCMAA0bcQ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 854
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 854
      } ],
      "display_url" : "pic.twitter.com\/Bha1p5r6kc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/biwDqHL2ML",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "566594707359154176",
  "text" : "http:\/\/t.co\/biwDqHL2ML has its first Apple Store. http:\/\/t.co\/Bha1p5r6kc",
  "id" : 566594707359154176,
  "created_at" : "2015-02-14 13:47:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/566465514638036993\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/98lvmA74TT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9x9YjMCQAEq9FC.jpg",
      "id_str" : "566465513857892353",
      "id" : 566465513857892353,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9x9YjMCQAEq9FC.jpg",
      "sizes" : [ {
        "h" : 1145,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 572,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/98lvmA74TT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/biwDqHL2ML",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "566465514638036993",
  "text" : "Slack now piping into http:\/\/t.co\/biwDqHL2ML's minecraft server. Now for the other way around... http:\/\/t.co\/98lvmA74TT",
  "id" : 566465514638036993,
  "created_at" : "2015-02-14 05:14:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/3hGQJoneV7",
      "expanded_url" : "https:\/\/twitter.com\/joshm\/status\/566366841208324097",
      "display_url" : "twitter.com\/joshm\/status\/5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566398877972959232",
  "text" : "RT @steveklabnik: https:\/\/t.co\/3hGQJoneV7 &lt;- look at what the VC replies with",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/3hGQJoneV7",
        "expanded_url" : "https:\/\/twitter.com\/joshm\/status\/566366841208324097",
        "display_url" : "twitter.com\/joshm\/status\/5\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566395453550653440",
    "text" : "https:\/\/t.co\/3hGQJoneV7 &lt;- look at what the VC replies with",
    "id" : 566395453550653440,
    "created_at" : "2015-02-14 00:36:13 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 566398877972959232,
  "created_at" : "2015-02-14 00:49:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566380209612414976",
  "geo" : { },
  "id_str" : "566381528796516354",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit that's the most Clarence thing imaginable",
  "id" : 566381528796516354,
  "in_reply_to_status_id" : 566380209612414976,
  "created_at" : "2015-02-13 23:40:53 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily St.",
      "screen_name" : "emilyst",
      "indices" : [ 0, 8 ],
      "id_str" : "17088295",
      "id" : 17088295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566356165668270081",
  "geo" : { },
  "id_str" : "566359560433061888",
  "in_reply_to_user_id" : 17088295,
  "text" : "@emilyst OK",
  "id" : 566359560433061888,
  "in_reply_to_status_id" : 566356165668270081,
  "created_at" : "2015-02-13 22:13:36 +0000",
  "in_reply_to_screen_name" : "emilyst",
  "in_reply_to_user_id_str" : "17088295",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 0, 10 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566346526448836608",
  "geo" : { },
  "id_str" : "566348828068958208",
  "in_reply_to_user_id" : 755113,
  "text" : "@ShaunKing glad to hear. also not glad to see I am already getting some crazy mentions about this",
  "id" : 566348828068958208,
  "in_reply_to_status_id" : 566346526448836608,
  "created_at" : "2015-02-13 21:30:57 +0000",
  "in_reply_to_screen_name" : "ShaunKing",
  "in_reply_to_user_id_str" : "755113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 0, 15 ],
      "id_str" : "155998525",
      "id" : 155998525
    }, {
      "name" : "Nick Sergeant",
      "screen_name" : "nicksergeant",
      "indices" : [ 16, 29 ],
      "id_str" : "13459652",
      "id" : 13459652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/DrHNsTWWIs",
      "expanded_url" : "https:\/\/webcache.googleusercontent.com\/search?q=cache:www.rockpapershotgun.com%2F2015%2F02%2F13%2Fpeter-molyneux-interview-godus-reputation-kickstarter%2F%23comment-1820463",
      "display_url" : "webcache.googleusercontent.com\/search?q=cache\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "566347159726202880",
  "geo" : { },
  "id_str" : "566347570666942464",
  "in_reply_to_user_id" : 155998525,
  "text" : "@1ofyourmeteors @nicksergeant https:\/\/t.co\/DrHNsTWWIs",
  "id" : 566347570666942464,
  "in_reply_to_status_id" : 566347159726202880,
  "created_at" : "2015-02-13 21:25:57 +0000",
  "in_reply_to_screen_name" : "1ofyourmeteors",
  "in_reply_to_user_id_str" : "155998525",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566346118947016704",
  "text" : "Toddler mashing on keyboards are great strong password generators",
  "id" : 566346118947016704,
  "created_at" : "2015-02-13 21:20:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 0, 10 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566345636396539904",
  "geo" : { },
  "id_str" : "566345983265492992",
  "in_reply_to_user_id" : 5743852,
  "text" : "@ShaunKing oh, he didn't. \"then he was acting like an asshole\"",
  "id" : 566345983265492992,
  "in_reply_to_status_id" : 566345636396539904,
  "created_at" : "2015-02-13 21:19:39 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 0, 10 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/F34Uw8zE5x",
      "expanded_url" : "https:\/\/twitter.com\/sacca\/status\/502124261784707072",
      "display_url" : "twitter.com\/sacca\/status\/5\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "566345202059599872",
  "geo" : { },
  "id_str" : "566345636396539904",
  "in_reply_to_user_id" : 755113,
  "text" : "@ShaunKing Looks like he removed this quote https:\/\/t.co\/F34Uw8zE5x",
  "id" : 566345636396539904,
  "in_reply_to_status_id" : 566345202059599872,
  "created_at" : "2015-02-13 21:18:16 +0000",
  "in_reply_to_screen_name" : "ShaunKing",
  "in_reply_to_user_id_str" : "755113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RyanC",
      "screen_name" : "ryancdotorg",
      "indices" : [ 3, 15 ],
      "id_str" : "580041896",
      "id" : 580041896
    }, {
      "name" : "Dan Kaminsky",
      "screen_name" : "dakami",
      "indices" : [ 17, 24 ],
      "id_str" : "8917142",
      "id" : 8917142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ryancdotorg\/status\/566339514264588289\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/y1XGHb9vMI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9wKyY_CQAA5cDz.jpg",
      "id_str" : "566339513958416384",
      "id" : 566339513958416384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9wKyY_CQAA5cDz.jpg",
      "sizes" : [ {
        "h" : 1694,
        "resize" : "fit",
        "w" : 1244
      }, {
        "h" : 1394,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 462,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 817,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/y1XGHb9vMI"
    } ],
    "hashtags" : [ {
      "text" : "SanFrancisco",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566340678322376705",
  "text" : "RT @ryancdotorg: @dakami Look what I found in the #SanFrancisco financial district. http:\/\/t.co\/y1XGHb9vMI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dan Kaminsky",
        "screen_name" : "dakami",
        "indices" : [ 0, 7 ],
        "id_str" : "8917142",
        "id" : 8917142
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ryancdotorg\/status\/566339514264588289\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/y1XGHb9vMI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9wKyY_CQAA5cDz.jpg",
        "id_str" : "566339513958416384",
        "id" : 566339513958416384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9wKyY_CQAA5cDz.jpg",
        "sizes" : [ {
          "h" : 1694,
          "resize" : "fit",
          "w" : 1244
        }, {
          "h" : 1394,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 462,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 817,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/y1XGHb9vMI"
      } ],
      "hashtags" : [ {
        "text" : "SanFrancisco",
        "indices" : [ 33, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566339514264588289",
    "in_reply_to_user_id" : 8917142,
    "text" : "@dakami Look what I found in the #SanFrancisco financial district. http:\/\/t.co\/y1XGHb9vMI",
    "id" : 566339514264588289,
    "created_at" : "2015-02-13 20:53:56 +0000",
    "in_reply_to_screen_name" : "dakami",
    "in_reply_to_user_id_str" : "8917142",
    "user" : {
      "name" : "RyanC",
      "screen_name" : "ryancdotorg",
      "protected" : false,
      "id_str" : "580041896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/437452763417427968\/pBXeHo1D_normal.jpeg",
      "id" : 580041896,
      "verified" : false
    }
  },
  "id" : 566340678322376705,
  "created_at" : "2015-02-13 20:58:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566333282132832256",
  "text" : "I'm going to start every interview for now on with \"Do you think that you\u2019re a pathological liar?\"",
  "id" : 566333282132832256,
  "created_at" : "2015-02-13 20:29:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELLIOTTCABLE",
      "screen_name" : "ELLIOTTCABLE",
      "indices" : [ 0, 13 ],
      "id_str" : "771681",
      "id" : 771681
    }, {
      "name" : "Melissa Berger",
      "screen_name" : "melloburger",
      "indices" : [ 14, 26 ],
      "id_str" : "288587418",
      "id" : 288587418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566325813969428481",
  "geo" : { },
  "id_str" : "566326028629336064",
  "in_reply_to_user_id" : 771681,
  "text" : "@ELLIOTTCABLE @melloburger Come build some supports.",
  "id" : 566326028629336064,
  "in_reply_to_status_id" : 566325813969428481,
  "created_at" : "2015-02-13 20:00:21 +0000",
  "in_reply_to_screen_name" : "ELLIOTTCABLE",
  "in_reply_to_user_id_str" : "771681",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELLIOTTCABLE",
      "screen_name" : "ELLIOTTCABLE",
      "indices" : [ 0, 13 ],
      "id_str" : "771681",
      "id" : 771681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566324573021675520",
  "geo" : { },
  "id_str" : "566325033065127936",
  "in_reply_to_user_id" : 771681,
  "text" : "@ELLIOTTCABLE Yeah I need to update that map. It's 6 weekends out of date and 2-3x more dense",
  "id" : 566325033065127936,
  "in_reply_to_status_id" : 566324573021675520,
  "created_at" : "2015-02-13 19:56:24 +0000",
  "in_reply_to_screen_name" : "ELLIOTTCABLE",
  "in_reply_to_user_id_str" : "771681",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikko Hypponen",
      "screen_name" : "mikko",
      "indices" : [ 3, 9 ],
      "id_str" : "23566038",
      "id" : 23566038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/hFniT9Y4Ag",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "566324318070517763",
  "text" : "RT @mikko: That's kind of a neat site: http:\/\/t.co\/hFniT9Y4Ag\nZoom around.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/hFniT9Y4Ag",
        "expanded_url" : "http:\/\/pickaxe.club",
        "display_url" : "pickaxe.club"
      } ]
    },
    "geo" : { },
    "id_str" : "566290669623607296",
    "text" : "That's kind of a neat site: http:\/\/t.co\/hFniT9Y4Ag\nZoom around.",
    "id" : 566290669623607296,
    "created_at" : "2015-02-13 17:39:51 +0000",
    "user" : {
      "name" : "Mikko Hypponen",
      "screen_name" : "mikko",
      "protected" : false,
      "id_str" : "23566038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000408665656\/55c2b354ce18b37b6fe2f5ecdf04fa85_normal.png",
      "id" : 23566038,
      "verified" : false
    }
  },
  "id" : 566324318070517763,
  "created_at" : "2015-02-13 19:53:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 3, 17 ],
      "id_str" : "5795572",
      "id" : 5795572
    }, {
      "name" : "Wegmans Food Markets",
      "screen_name" : "Wegmans",
      "indices" : [ 20, 28 ],
      "id_str" : "66482863",
      "id" : 66482863
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buffalopundit\/status\/566323713197764609\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/9rqg0aBoSH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9v8aSxIUAAmAIQ.jpg",
      "id_str" : "566323706809831424",
      "id" : 566323706809831424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9v8aSxIUAAmAIQ.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/9rqg0aBoSH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566323926838415363",
  "text" : "RT @buffalopundit: .@Wegmans knows how to do Valentine's Day right. http:\/\/t.co\/9rqg0aBoSH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wegmans Food Markets",
        "screen_name" : "Wegmans",
        "indices" : [ 1, 9 ],
        "id_str" : "66482863",
        "id" : 66482863
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/buffalopundit\/status\/566323713197764609\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/9rqg0aBoSH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9v8aSxIUAAmAIQ.jpg",
        "id_str" : "566323706809831424",
        "id" : 566323706809831424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9v8aSxIUAAmAIQ.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/9rqg0aBoSH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566323713197764609",
    "text" : ".@Wegmans knows how to do Valentine's Day right. http:\/\/t.co\/9rqg0aBoSH",
    "id" : 566323713197764609,
    "created_at" : "2015-02-13 19:51:09 +0000",
    "user" : {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "protected" : false,
      "id_str" : "5795572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554430715308560384\/LnSJ-sAY_normal.jpeg",
      "id" : 5795572,
      "verified" : false
    }
  },
  "id" : 566323926838415363,
  "created_at" : "2015-02-13 19:52:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566307662292205568",
  "text" : "A better title: \"IRC as a self-serving, self-selecting hiring filter\"",
  "id" : 566307662292205568,
  "created_at" : "2015-02-13 18:47:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaz Adams",
      "screen_name" : "chazadams",
      "indices" : [ 0, 10 ],
      "id_str" : "14807622",
      "id" : 14807622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566307200243470336",
  "geo" : { },
  "id_str" : "566307451666849792",
  "in_reply_to_user_id" : 14807622,
  "text" : "@chazadams Survival.",
  "id" : 566307451666849792,
  "in_reply_to_status_id" : 566307200243470336,
  "created_at" : "2015-02-13 18:46:32 +0000",
  "in_reply_to_screen_name" : "chazadams",
  "in_reply_to_user_id_str" : "14807622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tinyletter.com\" rel=\"nofollow\"\u003ETinyLetter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/biwDqHtrVd",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    }, {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/Rc7ubGXFdg",
      "expanded_url" : "http:\/\/tinyletter.com\/pickaxe-club\/letters\/pickaxe-club-weekend-11",
      "display_url" : "tinyletter.com\/pickaxe-club\/l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566307321488625664",
  "text" : "http:\/\/t.co\/biwDqHtrVd: Weekend 11 http:\/\/t.co\/Rc7ubGXFdg",
  "id" : 566307321488625664,
  "created_at" : "2015-02-13 18:46:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/biwDqHL2ML",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    }, {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/gUF2xaIN4F",
      "expanded_url" : "https:\/\/vimeo.com\/119515551",
      "display_url" : "vimeo.com\/119515551"
    } ]
  },
  "geo" : { },
  "id_str" : "566306637577601024",
  "text" : "10 weekends of http:\/\/t.co\/biwDqHL2ML building: https:\/\/t.co\/gUF2xaIN4F",
  "id" : 566306637577601024,
  "created_at" : "2015-02-13 18:43:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/NrWNsso0Vy",
      "expanded_url" : "http:\/\/www.jasonwhaley.com\/blog\/2015\/2\/13\/irc-as-a-hiring-filter",
      "display_url" : "jasonwhaley.com\/blog\/2015\/2\/13\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566304290663174146",
  "text" : "I've been using IRC for over 10 years and I'd never consider it as a hiring filter. What utter nonsense. http:\/\/t.co\/NrWNsso0Vy",
  "id" : 566304290663174146,
  "created_at" : "2015-02-13 18:33:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "indices" : [ 0, 13 ],
      "id_str" : "9154112",
      "id" : 9154112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566255469891944448",
  "geo" : { },
  "id_str" : "566274372151676930",
  "in_reply_to_user_id" : 9154112,
  "text" : "@jeremiahfelt later today, childcare is out and winging it",
  "id" : 566274372151676930,
  "in_reply_to_status_id" : 566255469891944448,
  "created_at" : "2015-02-13 16:35:05 +0000",
  "in_reply_to_screen_name" : "jeremiahfelt",
  "in_reply_to_user_id_str" : "9154112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Berkopec",
      "screen_name" : "nateberkopec",
      "indices" : [ 0, 13 ],
      "id_str" : "18259813",
      "id" : 18259813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566229608648163328",
  "geo" : { },
  "id_str" : "566230956642545665",
  "in_reply_to_user_id" : 18259813,
  "text" : "@nateberkopec got Rock Slided.",
  "id" : 566230956642545665,
  "in_reply_to_status_id" : 566229608648163328,
  "created_at" : "2015-02-13 13:42:34 +0000",
  "in_reply_to_screen_name" : "nateberkopec",
  "in_reply_to_user_id_str" : "18259813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/566228687201132544\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/075Ez25zuU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ul_YKCAAAiSpX.png",
      "id_str" : "566228686399995904",
      "id" : 566228686399995904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ul_YKCAAAiSpX.png",
      "sizes" : [ {
        "h" : 362,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 774,
        "resize" : "fit",
        "w" : 1282
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 205,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 618,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/075Ez25zuU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566228687201132544",
  "text" : "Brock has Aerodactyl and that's kind of ridiculous for the first gym. http:\/\/t.co\/075Ez25zuU",
  "id" : 566228687201132544,
  "created_at" : "2015-02-13 13:33:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/566095223718031360\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/tjRFjzc0Jr",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B9ssmu3CcAIL9ib.png",
      "id_str" : "566095222090657794",
      "id" : 566095222090657794,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B9ssmu3CcAIL9ib.png",
      "sizes" : [ {
        "h" : 282,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/tjRFjzc0Jr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/biwDqHL2ML",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "566095223718031360",
  "text" : "Quick preview of tomorrow's http:\/\/t.co\/biwDqHL2ML newsletter http:\/\/t.co\/tjRFjzc0Jr",
  "id" : 566095223718031360,
  "created_at" : "2015-02-13 04:43:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthieu Aikins",
      "screen_name" : "mattaikins",
      "indices" : [ 3, 14 ],
      "id_str" : "72745782",
      "id" : 72745782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/qyHqGwaqWm",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=iLmkec_4Rfo",
      "display_url" : "youtube.com\/watch?v=iLmkec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566095086677540865",
  "text" : "RT @mattaikins: This classic clip of Carr interrogating the VICE crew gives you an idea of his mettle. https:\/\/t.co\/qyHqGwaqWm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/qyHqGwaqWm",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=iLmkec_4Rfo",
        "display_url" : "youtube.com\/watch?v=iLmkec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566082852039966720",
    "text" : "This classic clip of Carr interrogating the VICE crew gives you an idea of his mettle. https:\/\/t.co\/qyHqGwaqWm",
    "id" : 566082852039966720,
    "created_at" : "2015-02-13 03:54:03 +0000",
    "user" : {
      "name" : "Matthieu Aikins",
      "screen_name" : "mattaikins",
      "protected" : false,
      "id_str" : "72745782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1778689821\/twitterselfportrait_normal.jpg",
      "id" : 72745782,
      "verified" : false
    }
  },
  "id" : 566095086677540865,
  "created_at" : "2015-02-13 04:42:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566084473142263808",
  "text" : "RT @sstephenson: Does anyone know what Google plans to do with the .dev TLD?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566084138176770051",
    "text" : "Does anyone know what Google plans to do with the .dev TLD?",
    "id" : 566084138176770051,
    "created_at" : "2015-02-13 03:59:10 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 566084473142263808,
  "created_at" : "2015-02-13 04:00:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Voss",
      "screen_name" : "seldo",
      "indices" : [ 0, 6 ],
      "id_str" : "15453",
      "id" : 15453
    }, {
      "name" : "Strand McDadJokes ",
      "screen_name" : "Strabd",
      "indices" : [ 7, 14 ],
      "id_str" : "18032208",
      "id" : 18032208
    }, {
      "name" : "THAT isaac",
      "screen_name" : "izs",
      "indices" : [ 15, 19 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566052919972085762",
  "geo" : { },
  "id_str" : "566080054497513472",
  "in_reply_to_user_id" : 15453,
  "text" : "@seldo @Strabd @izs next thing they'll want to get married to other bikes",
  "id" : 566080054497513472,
  "in_reply_to_status_id" : 566052919972085762,
  "created_at" : "2015-02-13 03:42:56 +0000",
  "in_reply_to_screen_name" : "seldo",
  "in_reply_to_user_id_str" : "15453",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/biwDqHL2ML",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "566070648984698880",
  "text" : "144 people signed up for http:\/\/t.co\/biwDqHL2ML on 61 different main domains. Whyyyyy",
  "id" : 566070648984698880,
  "created_at" : "2015-02-13 03:05:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/iB8Nr4s77u",
      "expanded_url" : "https:\/\/twitter.com\/SteveStreza\/status\/566056733190000641",
      "display_url" : "twitter.com\/SteveStreza\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566057768583327744",
  "text" : "Twitch Plays Pokemon streamer just got a $5,555 donation. What if he had it open for donations originally? https:\/\/t.co\/iB8Nr4s77u",
  "id" : 566057768583327744,
  "created_at" : "2015-02-13 02:14:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566056733190000641",
  "geo" : { },
  "id_str" : "566057390743625728",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza holy crap",
  "id" : 566057390743625728,
  "in_reply_to_status_id" : 566056733190000641,
  "created_at" : "2015-02-13 02:12:53 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeatherBELL",
      "screen_name" : "weatherbell",
      "indices" : [ 3, 15 ],
      "id_str" : "2999377084",
      "id" : 2999377084
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/weatherbell\/status\/566043221663297536\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/zzRHbu3zA6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9r9T3tCAAEkrmb.png",
      "id_str" : "566043221000585217",
      "id" : 566043221000585217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9r9T3tCAAEkrmb.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zzRHbu3zA6"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/weatherbell\/status\/566043221663297536\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/zzRHbu3zA6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9r9T3sCUAAlJgG.png",
      "id_str" : "566043220996411392",
      "id" : 566043220996411392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9r9T3sCUAAlJgG.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zzRHbu3zA6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566047205346123776",
  "text" : "RT @weatherbell: Opening bids from NWS for snowfall through Sunday 7 pm in New England.  Boston 14-16'', Maine coast 12-20'' \nNYC 3'' http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/weatherbell\/status\/566043221663297536\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/zzRHbu3zA6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9r9T3tCAAEkrmb.png",
        "id_str" : "566043221000585217",
        "id" : 566043221000585217,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9r9T3tCAAEkrmb.png",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zzRHbu3zA6"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/weatherbell\/status\/566043221663297536\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/zzRHbu3zA6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9r9T3sCUAAlJgG.png",
        "id_str" : "566043220996411392",
        "id" : 566043220996411392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9r9T3sCUAAlJgG.png",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zzRHbu3zA6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566043221663297536",
    "text" : "Opening bids from NWS for snowfall through Sunday 7 pm in New England.  Boston 14-16'', Maine coast 12-20'' \nNYC 3'' http:\/\/t.co\/zzRHbu3zA6",
    "id" : 566043221663297536,
    "created_at" : "2015-02-13 01:16:35 +0000",
    "user" : {
      "name" : "WeatherBELL",
      "screen_name" : "weatherbell",
      "protected" : false,
      "id_str" : "2999377084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559644636080136192\/b2IKoEuq_normal.jpeg",
      "id" : 2999377084,
      "verified" : false
    }
  },
  "id" : 566047205346123776,
  "created_at" : "2015-02-13 01:32:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 3, 18 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/ASrPy3jELu",
      "expanded_url" : "http:\/\/instagram.com\/p\/zBcWVnMOde\/",
      "display_url" : "instagram.com\/p\/zBcWVnMOde\/"
    } ]
  },
  "geo" : { },
  "id_str" : "566043160569061376",
  "text" : "RT @PublicEspresso: The first of many future uses of the historic mail slots in the lobby of the Hotel at the Lafayette.\u2026 http:\/\/t.co\/ASrPy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/ASrPy3jELu",
        "expanded_url" : "http:\/\/instagram.com\/p\/zBcWVnMOde\/",
        "display_url" : "instagram.com\/p\/zBcWVnMOde\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.884965, -78.873067 ]
    },
    "id_str" : "566042845354946560",
    "text" : "The first of many future uses of the historic mail slots in the lobby of the Hotel at the Lafayette.\u2026 http:\/\/t.co\/ASrPy3jELu",
    "id" : 566042845354946560,
    "created_at" : "2015-02-13 01:15:05 +0000",
    "user" : {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "protected" : false,
      "id_str" : "1472209542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550509321445191680\/PwiO5VPn_normal.jpeg",
      "id" : 1472209542,
      "verified" : false
    }
  },
  "id" : 566043160569061376,
  "created_at" : "2015-02-13 01:16:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    }, {
      "name" : "danielle",
      "screen_name" : "duh_nellll",
      "indices" : [ 14, 25 ],
      "id_str" : "146513248",
      "id" : 146513248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566042923742273537",
  "geo" : { },
  "id_str" : "566043095163084800",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV @duh_nellll *fasts forward* ugh it's fucking hot ughhhh",
  "id" : 566043095163084800,
  "in_reply_to_status_id" : 566042923742273537,
  "created_at" : "2015-02-13 01:16:05 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/566027821064019971\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/y2m2RsPsly",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9rvTVBCUAA_0zB.png",
      "id_str" : "566027818526461952",
      "id" : 566027818526461952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9rvTVBCUAA_0zB.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/y2m2RsPsly"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566027821064019971",
  "text" : "Search just got turned on for Rooms, and well... http:\/\/t.co\/y2m2RsPsly",
  "id" : 566027821064019971,
  "created_at" : "2015-02-13 00:15:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "756161",
      "id" : 756161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565982759840010240",
  "geo" : { },
  "id_str" : "565983352797544448",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer it's so easy to not think critically when you're right all the time! Oh and when you have a lot of money and you're \"important\"",
  "id" : 565983352797544448,
  "in_reply_to_status_id" : 565982759840010240,
  "created_at" : "2015-02-12 21:18:41 +0000",
  "in_reply_to_screen_name" : "zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565979024841646080",
  "geo" : { },
  "id_str" : "565979207294287872",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza This streamer is making bank.",
  "id" : 565979207294287872,
  "in_reply_to_status_id" : 565979024841646080,
  "created_at" : "2015-02-12 21:02:13 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 3, 15 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TwitchPlaysPokemon",
      "indices" : [ 32, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565979171063873536",
  "text" : "RT @SteveStreza: AIIIAAB lives! #TwitchPlaysPokemon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TwitchPlaysPokemon",
        "indices" : [ 15, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565979024841646080",
    "text" : "AIIIAAB lives! #TwitchPlaysPokemon",
    "id" : 565979024841646080,
    "created_at" : "2015-02-12 21:01:29 +0000",
    "user" : {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "protected" : false,
      "id_str" : "658643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540811650727550976\/b7RvPDiF_normal.jpeg",
      "id" : 658643,
      "verified" : false
    }
  },
  "id" : 565979171063873536,
  "created_at" : "2015-02-12 21:02:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Signore",
      "screen_name" : "tanooki_mario",
      "indices" : [ 0, 14 ],
      "id_str" : "385767797",
      "id" : 385767797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/thXUqOqQoU",
      "expanded_url" : "http:\/\/www.twitch.tv\/twitchplayspokemon",
      "display_url" : "twitch.tv\/twitchplayspok\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "565975958436331521",
  "geo" : { },
  "id_str" : "565976090355982337",
  "in_reply_to_user_id" : 385767797,
  "text" : "@tanooki_mario http:\/\/t.co\/thXUqOqQoU",
  "id" : 565976090355982337,
  "in_reply_to_status_id" : 565975958436331521,
  "created_at" : "2015-02-12 20:49:49 +0000",
  "in_reply_to_screen_name" : "tanooki_mario",
  "in_reply_to_user_id_str" : "385767797",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/565975834130149376\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/1guOjFt4nV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9rABZgCQAA8ME3.png",
      "id_str" : "565975833446072320",
      "id" : 565975833446072320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9rABZgCQAA8ME3.png",
      "sizes" : [ {
        "h" : 208,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 784,
        "resize" : "fit",
        "w" : 1276
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1guOjFt4nV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565975834130149376",
  "text" : "Well that's all I have to say about it. http:\/\/t.co\/1guOjFt4nV",
  "id" : 565975834130149376,
  "created_at" : "2015-02-12 20:48:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/OEMH5AC3ft",
      "expanded_url" : "http:\/\/www.amazon.com\/Pokemon-Red-Version-Game-Boy-Color\/dp\/B00000IYEQ",
      "display_url" : "amazon.com\/Pokemon-Red-Ve\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565974786485272576",
  "text" : "lol wat http:\/\/t.co\/OEMH5AC3ft",
  "id" : 565974786485272576,
  "created_at" : "2015-02-12 20:44:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565972034841501696",
  "geo" : { },
  "id_str" : "565972332951633920",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy A snow shoveler's noble death. Make it quick.",
  "id" : 565972332951633920,
  "in_reply_to_status_id" : 565972034841501696,
  "created_at" : "2015-02-12 20:34:54 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/thXUqOqQoU",
      "expanded_url" : "http:\/\/www.twitch.tv\/twitchplayspokemon",
      "display_url" : "twitch.tv\/twitchplayspok\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565971454072999938",
  "text" : "All 151 need to be captured this time. LOL\n\nAlso it's been a year....????? http:\/\/t.co\/thXUqOqQoU",
  "id" : 565971454072999938,
  "created_at" : "2015-02-12 20:31:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565970964937048064",
  "geo" : { },
  "id_str" : "565971038924980226",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza your name just came up!!",
  "id" : 565971038924980226,
  "in_reply_to_status_id" : 565970964937048064,
  "created_at" : "2015-02-12 20:29:45 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Melissa Virus",
      "screen_name" : "0xabad1dea",
      "indices" : [ 0, 11 ],
      "id_str" : "126030998",
      "id" : 126030998
    }, {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "indices" : [ 12, 25 ],
      "id_str" : "9154112",
      "id" : 9154112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565970623936344064",
  "geo" : { },
  "id_str" : "565970776994906114",
  "in_reply_to_user_id" : 126030998,
  "text" : "@0xabad1dea @jeremiahfelt Yeah, I followed it until maybe Black\/White or so. The meme overriding got a little too much.",
  "id" : 565970776994906114,
  "in_reply_to_status_id" : 565970623936344064,
  "created_at" : "2015-02-12 20:28:43 +0000",
  "in_reply_to_screen_name" : "0xabad1dea",
  "in_reply_to_user_id_str" : "126030998",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/565970539123314689\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/JmR7T0mWZC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9q7NMGCUAEFB3z.png",
      "id_str" : "565970538447654913",
      "id" : 565970538447654913,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9q7NMGCUAEFB3z.png",
      "sizes" : [ {
        "h" : 180,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 672,
        "resize" : "fit",
        "w" : 1264
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JmR7T0mWZC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565970539123314689",
  "text" : "Easily the best news all day http:\/\/t.co\/JmR7T0mWZC",
  "id" : 565970539123314689,
  "created_at" : "2015-02-12 20:27:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Melissa Virus",
      "screen_name" : "0xabad1dea",
      "indices" : [ 0, 11 ],
      "id_str" : "126030998",
      "id" : 126030998
    }, {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "indices" : [ 12, 25 ],
      "id_str" : "9154112",
      "id" : 9154112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565967669808349184",
  "geo" : { },
  "id_str" : "565970191683960833",
  "in_reply_to_user_id" : 126030998,
  "text" : "@0xabad1dea @jeremiahfelt It's coming back!!?",
  "id" : 565970191683960833,
  "in_reply_to_status_id" : 565967669808349184,
  "created_at" : "2015-02-12 20:26:23 +0000",
  "in_reply_to_screen_name" : "0xabad1dea",
  "in_reply_to_user_id_str" : "126030998",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "triflin brand indeed",
      "screen_name" : "vogon",
      "indices" : [ 0, 6 ],
      "id_str" : "6326912",
      "id" : 6326912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565968273817092097",
  "geo" : { },
  "id_str" : "565969225555402752",
  "in_reply_to_user_id" : 6326912,
  "text" : "@vogon Porsche.",
  "id" : 565969225555402752,
  "in_reply_to_status_id" : 565968273817092097,
  "created_at" : "2015-02-12 20:22:33 +0000",
  "in_reply_to_screen_name" : "vogon",
  "in_reply_to_user_id_str" : "6326912",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 0, 14 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565960047935913984",
  "geo" : { },
  "id_str" : "565961208462049280",
  "in_reply_to_user_id" : 16930130,
  "text" : "@PhilDarnowsky was there mustard",
  "id" : 565961208462049280,
  "in_reply_to_status_id" : 565960047935913984,
  "created_at" : "2015-02-12 19:50:41 +0000",
  "in_reply_to_screen_name" : "PhilDarnowsky",
  "in_reply_to_user_id_str" : "16930130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Williams",
      "screen_name" : "j_m_williams",
      "indices" : [ 0, 13 ],
      "id_str" : "16210953",
      "id" : 16210953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565949487437193216",
  "geo" : { },
  "id_str" : "565949592458776576",
  "in_reply_to_user_id" : 16210953,
  "text" : "@j_m_williams \u0CA0_\u0CA0",
  "id" : 565949592458776576,
  "in_reply_to_status_id" : 565949487437193216,
  "created_at" : "2015-02-12 19:04:32 +0000",
  "in_reply_to_screen_name" : "j_m_williams",
  "in_reply_to_user_id_str" : "16210953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565706493383938049",
  "geo" : { },
  "id_str" : "565706948755333122",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo what has texas done to you",
  "id" : 565706948755333122,
  "in_reply_to_status_id" : 565706493383938049,
  "created_at" : "2015-02-12 03:00:21 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namira Islam",
      "screen_name" : "namirari",
      "indices" : [ 3, 12 ],
      "id_str" : "302204453",
      "id" : 302204453
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChapelHillShooting",
      "indices" : [ 14, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/vxxXk3HKTD",
      "expanded_url" : "http:\/\/fusion.net\/story\/47569\/chapel-hill-shooting-my-best-friend-was-killed-and-i-dont-know-why\/",
      "display_url" : "fusion.net\/story\/47569\/ch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565703897852166146",
  "text" : "RT @namirari: #ChapelHillShooting: shooter came to door w\/rifle once because \"they were making too much noise playing a board game\" http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChapelHillShooting",
        "indices" : [ 0, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/vxxXk3HKTD",
        "expanded_url" : "http:\/\/fusion.net\/story\/47569\/chapel-hill-shooting-my-best-friend-was-killed-and-i-dont-know-why\/",
        "display_url" : "fusion.net\/story\/47569\/ch\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "565702001649270785",
    "text" : "#ChapelHillShooting: shooter came to door w\/rifle once because \"they were making too much noise playing a board game\" http:\/\/t.co\/vxxXk3HKTD",
    "id" : 565702001649270785,
    "created_at" : "2015-02-12 02:40:42 +0000",
    "user" : {
      "name" : "Namira Islam",
      "screen_name" : "namirari",
      "protected" : false,
      "id_str" : "302204453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557729022134591488\/KqEhxkZD_normal.jpeg",
      "id" : 302204453,
      "verified" : false
    }
  },
  "id" : 565703897852166146,
  "created_at" : "2015-02-12 02:48:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/at06kGFxIo",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=NCFuNdsYnhs",
      "display_url" : "youtube.com\/watch?v=NCFuNd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565702793819066369",
  "text" : "Continually impressed by this arrangement https:\/\/t.co\/at06kGFxIo",
  "id" : 565702793819066369,
  "created_at" : "2015-02-12 02:43:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 16, 26 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565673830560325634",
  "geo" : { },
  "id_str" : "565685716303495168",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc @aquaranto nature...finds a way",
  "id" : 565685716303495168,
  "in_reply_to_status_id" : 565673830560325634,
  "created_at" : "2015-02-12 01:35:59 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 15, 21 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565675948788699137",
  "geo" : { },
  "id_str" : "565685601450860544",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents @phish oh crap!!",
  "id" : 565685601450860544,
  "in_reply_to_status_id" : 565675948788699137,
  "created_at" : "2015-02-12 01:35:31 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Scarcello",
      "screen_name" : "WordsWithSam",
      "indices" : [ 0, 13 ],
      "id_str" : "26401150",
      "id" : 26401150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565667705614000128",
  "geo" : { },
  "id_str" : "565668723525443584",
  "in_reply_to_user_id" : 26401150,
  "text" : "@WordsWithSam When is this opening?",
  "id" : 565668723525443584,
  "in_reply_to_status_id" : 565667705614000128,
  "created_at" : "2015-02-12 00:28:27 +0000",
  "in_reply_to_screen_name" : "WordsWithSam",
  "in_reply_to_user_id_str" : "26401150",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Scarcello",
      "screen_name" : "WordsWithSam",
      "indices" : [ 3, 16 ],
      "id_str" : "26401150",
      "id" : 26401150
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "publicespresso",
      "indices" : [ 47, 62 ]
    }, {
      "text" : "PublicAtTheLafayette",
      "indices" : [ 63, 84 ]
    }, {
      "text" : "buffalo",
      "indices" : [ 85, 93 ]
    }, {
      "text" : "pourover",
      "indices" : [ 94, 103 ]
    }, {
      "text" : "chemex",
      "indices" : [ 104, 111 ]
    }, {
      "text" : "modbar",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/ZpXxNNwk3A",
      "expanded_url" : "http:\/\/instagram.com\/p\/y-xwVAsOZj\/",
      "display_url" : "instagram.com\/p\/y-xwVAsOZj\/"
    } ]
  },
  "geo" : { },
  "id_str" : "565668446575525889",
  "text" : "RT @WordsWithSam: Chemex pour-over coming soon #publicespresso #PublicAtTheLafayette #buffalo #pourover #chemex #modbar\u2026 http:\/\/t.co\/ZpXxNN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "publicespresso",
        "indices" : [ 29, 44 ]
      }, {
        "text" : "PublicAtTheLafayette",
        "indices" : [ 45, 66 ]
      }, {
        "text" : "buffalo",
        "indices" : [ 67, 75 ]
      }, {
        "text" : "pourover",
        "indices" : [ 76, 85 ]
      }, {
        "text" : "chemex",
        "indices" : [ 86, 93 ]
      }, {
        "text" : "modbar",
        "indices" : [ 94, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/ZpXxNNwk3A",
        "expanded_url" : "http:\/\/instagram.com\/p\/y-xwVAsOZj\/",
        "display_url" : "instagram.com\/p\/y-xwVAsOZj\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.884965, -78.873067 ]
    },
    "id_str" : "565667705614000128",
    "text" : "Chemex pour-over coming soon #publicespresso #PublicAtTheLafayette #buffalo #pourover #chemex #modbar\u2026 http:\/\/t.co\/ZpXxNNwk3A",
    "id" : 565667705614000128,
    "created_at" : "2015-02-12 00:24:25 +0000",
    "user" : {
      "name" : "Sam Scarcello",
      "screen_name" : "WordsWithSam",
      "protected" : false,
      "id_str" : "26401150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522110046147469312\/9q8wqefP_normal.jpeg",
      "id" : 26401150,
      "verified" : false
    }
  },
  "id" : 565668446575525889,
  "created_at" : "2015-02-12 00:27:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Problem",
      "screen_name" : "BonzoESC",
      "indices" : [ 0, 9 ],
      "id_str" : "7865582",
      "id" : 7865582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565667317896724480",
  "geo" : { },
  "id_str" : "565667791253307393",
  "in_reply_to_user_id" : 7865582,
  "text" : "@BonzoESC I actually enjoy the snow. I couldn't imagine a place without seasons.",
  "id" : 565667791253307393,
  "in_reply_to_status_id" : 565667317896724480,
  "created_at" : "2015-02-12 00:24:45 +0000",
  "in_reply_to_screen_name" : "BonzoESC",
  "in_reply_to_user_id_str" : "7865582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/565666662788386816\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/Lqc3KerQmf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9mm1QlCMAAByEZ.jpg",
      "id_str" : "565666662125285376",
      "id" : 565666662125285376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9mm1QlCMAAByEZ.jpg",
      "sizes" : [ {
        "h" : 363,
        "resize" : "fit",
        "w" : 454
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 454
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 454
      } ],
      "display_url" : "pic.twitter.com\/Lqc3KerQmf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565666662788386816",
  "text" : "Buffalo weather forecast with -30 wind chills tomorrow http:\/\/t.co\/Lqc3KerQmf",
  "id" : 565666662788386816,
  "created_at" : "2015-02-12 00:20:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 3, 16 ],
      "id_str" : "14928483",
      "id" : 14928483
    }, {
      "name" : "Kevin Marks",
      "screen_name" : "kevinmarks",
      "indices" : [ 139, 140 ],
      "id_str" : "57203",
      "id" : 57203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Q8yaQnitaS",
      "expanded_url" : "http:\/\/known.kevinmarks.com\/2015\/quiet-wadha-episode-45-of-tldr-that-has-been-supressed",
      "display_url" : "known.kevinmarks.com\/2015\/quiet-wad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565662098353819649",
  "text" : "RT @lindseybieda: So, if you want to listen to that TLDR that Wadwha had removed you can listen to it here: http:\/\/t.co\/Q8yaQnitaS - thanks\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Marks",
        "screen_name" : "kevinmarks",
        "indices" : [ 122, 133 ],
        "id_str" : "57203",
        "id" : 57203
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/Q8yaQnitaS",
        "expanded_url" : "http:\/\/known.kevinmarks.com\/2015\/quiet-wadha-episode-45-of-tldr-that-has-been-supressed",
        "display_url" : "known.kevinmarks.com\/2015\/quiet-wad\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "565629987718705152",
    "text" : "So, if you want to listen to that TLDR that Wadwha had removed you can listen to it here: http:\/\/t.co\/Q8yaQnitaS - thanks @kevinmarks",
    "id" : 565629987718705152,
    "created_at" : "2015-02-11 21:54:32 +0000",
    "user" : {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "protected" : false,
      "id_str" : "14928483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569192760029089792\/zaGhTAHK_normal.jpeg",
      "id" : 14928483,
      "verified" : false
    }
  },
  "id" : 565662098353819649,
  "created_at" : "2015-02-12 00:02:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/6iS4eyRbzv",
      "expanded_url" : "http:\/\/cowork.buffal.ooo",
      "display_url" : "cowork.buffal.ooo"
    } ]
  },
  "in_reply_to_status_id_str" : "565658490149298176",
  "geo" : { },
  "id_str" : "565658671427104768",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 well something for http:\/\/t.co\/6iS4eyRbzv",
  "id" : 565658671427104768,
  "in_reply_to_status_id" : 565658490149298176,
  "created_at" : "2015-02-11 23:48:31 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Mims",
      "screen_name" : "mims",
      "indices" : [ 3, 8 ],
      "id_str" : "1769191",
      "id" : 1769191
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mims\/status\/565657803785011200\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/NHrrW3ys6H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9mexdZIQAA31pN.jpg",
      "id_str" : "565657800752513024",
      "id" : 565657800752513024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9mexdZIQAA31pN.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 660
      } ],
      "display_url" : "pic.twitter.com\/NHrrW3ys6H"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/6GFxs6VDI2",
      "expanded_url" : "http:\/\/wrd.cm\/1zwIbqh",
      "display_url" : "wrd.cm\/1zwIbqh"
    } ]
  },
  "geo" : { },
  "id_str" : "565658556910018560",
  "text" : "RT @mims: Vaccination rate at Google's and Pixar's daycare is less than 50% http:\/\/t.co\/6GFxs6VDI2 http:\/\/t.co\/NHrrW3ys6H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mims\/status\/565657803785011200\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/NHrrW3ys6H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9mexdZIQAA31pN.jpg",
        "id_str" : "565657800752513024",
        "id" : 565657800752513024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9mexdZIQAA31pN.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 660
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 660
        } ],
        "display_url" : "pic.twitter.com\/NHrrW3ys6H"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/6GFxs6VDI2",
        "expanded_url" : "http:\/\/wrd.cm\/1zwIbqh",
        "display_url" : "wrd.cm\/1zwIbqh"
      } ]
    },
    "geo" : { },
    "id_str" : "565657803785011200",
    "text" : "Vaccination rate at Google's and Pixar's daycare is less than 50% http:\/\/t.co\/6GFxs6VDI2 http:\/\/t.co\/NHrrW3ys6H",
    "id" : 565657803785011200,
    "created_at" : "2015-02-11 23:45:04 +0000",
    "user" : {
      "name" : "Christopher Mims",
      "screen_name" : "mims",
      "protected" : false,
      "id_str" : "1769191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464049016552972289\/xb0Y0hJO_normal.jpeg",
      "id" : 1769191,
      "verified" : true
    }
  },
  "id" : 565658556910018560,
  "created_at" : "2015-02-11 23:48:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565658305658626050",
  "geo" : { },
  "id_str" : "565658370989096961",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 is that yours!??",
  "id" : 565658370989096961,
  "in_reply_to_status_id" : 565658305658626050,
  "created_at" : "2015-02-11 23:47:19 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/mDHKOIYViW",
      "expanded_url" : "http:\/\/buffal.ooo",
      "display_url" : "buffal.ooo"
    } ]
  },
  "geo" : { },
  "id_str" : "565658356267114498",
  "text" : "RT @zobar2: Yup. http:\/\/t.co\/mDHKOIYViW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 5, 27 ],
        "url" : "http:\/\/t.co\/mDHKOIYViW",
        "expanded_url" : "http:\/\/buffal.ooo",
        "display_url" : "buffal.ooo"
      } ]
    },
    "geo" : { },
    "id_str" : "565658305658626050",
    "text" : "Yup. http:\/\/t.co\/mDHKOIYViW",
    "id" : 565658305658626050,
    "created_at" : "2015-02-11 23:47:04 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 565658356267114498,
  "created_at" : "2015-02-11 23:47:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565651432909852672",
  "text" : "There should be a limit of one comma per Twitter bio",
  "id" : 565651432909852672,
  "created_at" : "2015-02-11 23:19:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Hale",
      "screen_name" : "ilikevests",
      "indices" : [ 0, 11 ],
      "id_str" : "234765685",
      "id" : 234765685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565600186412851201",
  "geo" : { },
  "id_str" : "565601320850448384",
  "in_reply_to_user_id" : 234765685,
  "text" : "@ilikevests There's no license on this and it's a word doc. Is \"open source\" the right term here?",
  "id" : 565601320850448384,
  "in_reply_to_status_id" : 565600186412851201,
  "created_at" : "2015-02-11 20:00:37 +0000",
  "in_reply_to_screen_name" : "ilikevests",
  "in_reply_to_user_id_str" : "234765685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 2, 8 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565567204901806080",
  "text" : "a @phish audience in emojis\n\npit\n\u2510(\uFF9F\u0434\uFF9F\u2510) \u250C(\u30FB\u3002\u30FB)\u2518\u266A (\u30CE^o^)\u30CE\n\nhouse\n\\(._.\\) \u01AA(\u2018-\u2019 \u01AA)(\u0283 \u2018-\u2019)\u0283 (\/._.)\/\n\nlawn\n(\u02C7_\u02C7\u201D) \u01AA(\u02D8\u2323\u02D8)\u2510 \u01AA(\u02D8\u2323\u02D8)\u0283 \u250C(\u02D8\u2323\u02D8)\u0283",
  "id" : 565567204901806080,
  "created_at" : "2015-02-11 17:45:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 54, 60 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565566001824403457",
  "text" : "(\u02C7_\u02C7\u201D) \u01AA(\u02D8\u2323\u02D8)\u2510 \u01AA(\u02D8\u2323\u02D8)\u0283 \u250C(\u02D8\u2323\u02D8)\u0283\n\naccurate depiction of @phish show dancing",
  "id" : 565566001824403457,
  "created_at" : "2015-02-11 17:40:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565552502679306240",
  "geo" : { },
  "id_str" : "565552611257229312",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit I bet they'll find parking easily",
  "id" : 565552611257229312,
  "in_reply_to_status_id" : 565552502679306240,
  "created_at" : "2015-02-11 16:47:04 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 0, 12 ],
      "id_str" : "16454301",
      "id" : 16454301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565544416719286272",
  "geo" : { },
  "id_str" : "565544577546092544",
  "in_reply_to_user_id" : 16454301,
  "text" : "@jonasdowney next up, Wafflecoin",
  "id" : 565544577546092544,
  "in_reply_to_status_id" : 565544416719286272,
  "created_at" : "2015-02-11 16:15:09 +0000",
  "in_reply_to_screen_name" : "jonasdowney",
  "in_reply_to_user_id_str" : "16454301",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJE News",
      "screen_name" : "AJENews",
      "indices" : [ 3, 11 ],
      "id_str" : "18424289",
      "id" : 18424289
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChapelHillShooting",
      "indices" : [ 22, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/KZjU4DQ0bx",
      "expanded_url" : "http:\/\/aje.io\/7yw7",
      "display_url" : "aje.io\/7yw7"
    } ]
  },
  "geo" : { },
  "id_str" : "565508705991811073",
  "text" : "RT @AJENews: Opinion: #ChapelHillShooting and Western media bigotry. http:\/\/t.co\/KZjU4DQ0bx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChapelHillShooting",
        "indices" : [ 9, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/KZjU4DQ0bx",
        "expanded_url" : "http:\/\/aje.io\/7yw7",
        "display_url" : "aje.io\/7yw7"
      } ]
    },
    "geo" : { },
    "id_str" : "565469328192339969",
    "text" : "Opinion: #ChapelHillShooting and Western media bigotry. http:\/\/t.co\/KZjU4DQ0bx",
    "id" : 565469328192339969,
    "created_at" : "2015-02-11 11:16:08 +0000",
    "user" : {
      "name" : "AJE News",
      "screen_name" : "AJENews",
      "protected" : false,
      "id_str" : "18424289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448478250503647233\/xZOjTaoA_normal.jpeg",
      "id" : 18424289,
      "verified" : true
    }
  },
  "id" : 565508705991811073,
  "created_at" : "2015-02-11 13:52:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melody Joy Kramer",
      "screen_name" : "mkramer",
      "indices" : [ 0, 8 ],
      "id_str" : "10232022",
      "id" : 10232022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565499022014959616",
  "geo" : { },
  "id_str" : "565499446625312769",
  "in_reply_to_user_id" : 10232022,
  "text" : "@mkramer can you start abbreviating as gov't like in social studies class yet?",
  "id" : 565499446625312769,
  "in_reply_to_status_id" : 565499022014959616,
  "created_at" : "2015-02-11 13:15:49 +0000",
  "in_reply_to_screen_name" : "mkramer",
  "in_reply_to_user_id_str" : "10232022",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 0, 7 ],
      "id_str" : "6981492",
      "id" : 6981492
    }, {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 16, 27 ],
      "id_str" : "14620776",
      "id" : 14620776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565497515756519424",
  "geo" : { },
  "id_str" : "565498560125231105",
  "in_reply_to_user_id" : 6981492,
  "text" : "@ftrain I think @ellenchisa now appears in 60% of articles I read",
  "id" : 565498560125231105,
  "in_reply_to_status_id" : 565497515756519424,
  "created_at" : "2015-02-11 13:12:17 +0000",
  "in_reply_to_screen_name" : "ftrain",
  "in_reply_to_user_id_str" : "6981492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annika Backstrom",
      "screen_name" : "abackstrom",
      "indices" : [ 0, 11 ],
      "id_str" : "3621751",
      "id" : 3621751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565353724240211968",
  "geo" : { },
  "id_str" : "565354009410957313",
  "in_reply_to_user_id" : 3621751,
  "text" : "@abackstrom funny enough, that's not a thing here. it's just hot\/medium\/mild.",
  "id" : 565354009410957313,
  "in_reply_to_status_id" : 565353724240211968,
  "created_at" : "2015-02-11 03:37:54 +0000",
  "in_reply_to_screen_name" : "abackstrom",
  "in_reply_to_user_id_str" : "3621751",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 97, 109 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565352972067278849",
  "text" : "It's kind of crazy that a taco truck franchise can pack a theater of excited people. Happy to be @whereslloyd supporter tonight.",
  "id" : 565352972067278849,
  "created_at" : "2015-02-11 03:33:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 60, 72 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565350778874109952",
  "text" : "Whatever $SHAK, I'll wait until $LLOYD is ringing the bell, @whereslloyd!",
  "id" : 565350778874109952,
  "created_at" : "2015-02-11 03:25:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Restaurant Startup",
      "screen_name" : "RestStartup",
      "indices" : [ 3, 15 ],
      "id_str" : "2591576904",
      "id" : 2591576904
    }, {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 30, 42 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RestaurantStartup",
      "indices" : [ 48, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565349922464342017",
  "text" : "RT @RestStartup: AND IT\u2019S\u2026\u2026.. @WheresLloyd!!!!!\n#RestaurantStartup",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lloyd Taco Trucks",
        "screen_name" : "whereslloyd",
        "indices" : [ 13, 25 ],
        "id_str" : "156689065",
        "id" : 156689065
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RestaurantStartup",
        "indices" : [ 31, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565348983292592128",
    "text" : "AND IT\u2019S\u2026\u2026.. @WheresLloyd!!!!!\n#RestaurantStartup",
    "id" : 565348983292592128,
    "created_at" : "2015-02-11 03:17:55 +0000",
    "user" : {
      "name" : "Restaurant Startup",
      "screen_name" : "RestStartup",
      "protected" : false,
      "id_str" : "2591576904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545327715016921088\/QYmkCPUq_normal.png",
      "id" : 2591576904,
      "verified" : true
    }
  },
  "id" : 565349922464342017,
  "created_at" : "2015-02-11 03:21:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Berkopec",
      "screen_name" : "nateberkopec",
      "indices" : [ 0, 13 ],
      "id_str" : "18259813",
      "id" : 18259813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565347470402912256",
  "geo" : { },
  "id_str" : "565347789719498755",
  "in_reply_to_user_id" : 18259813,
  "text" : "@nateberkopec haven't tried the new beta yet",
  "id" : 565347789719498755,
  "in_reply_to_status_id" : 565347470402912256,
  "created_at" : "2015-02-11 03:13:11 +0000",
  "in_reply_to_screen_name" : "nateberkopec",
  "in_reply_to_user_id_str" : "18259813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lady Ivan Grey",
      "screen_name" : "LadyIvanGrey",
      "indices" : [ 0, 13 ],
      "id_str" : "2469964320",
      "id" : 2469964320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565338315667537920",
  "geo" : { },
  "id_str" : "565338453123301376",
  "in_reply_to_user_id" : 2469964320,
  "text" : "@LadyIvanGrey the only one you can use!",
  "id" : 565338453123301376,
  "in_reply_to_status_id" : 565338315667537920,
  "created_at" : "2015-02-11 02:36:05 +0000",
  "in_reply_to_screen_name" : "LadyIvanGrey",
  "in_reply_to_user_id_str" : "2469964320",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565338179331702785",
  "text" : "Swifts on a plane: I AM SICK OF THESE ******* SYNTAX HIGHLIGHTING CRASHES ON THIS ******* EDITOR",
  "id" : 565338179331702785,
  "created_at" : "2015-02-11 02:35:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565310742787022849",
  "geo" : { },
  "id_str" : "565314619301167104",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos Ok new name. Bottl.",
  "id" : 565314619301167104,
  "in_reply_to_status_id" : 565310742787022849,
  "created_at" : "2015-02-11 01:01:22 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565306494863028226",
  "geo" : { },
  "id_str" : "565307656270016512",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos all part of the plan",
  "id" : 565307656270016512,
  "in_reply_to_status_id" : 565306494863028226,
  "created_at" : "2015-02-11 00:33:42 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565305103742423040",
  "text" : "I want to seriously pitch the Uddr idea to YC. Weekly milk delivery. To your door. Give me the cashhhhhhhhh!! (That's the whole pitch deck)",
  "id" : 565305103742423040,
  "created_at" : "2015-02-11 00:23:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565296007618232321",
  "text" : "So Midnight Star seems to be a blatant rip of Halo just with touch controls. \uD83D\uDE2C",
  "id" : 565296007618232321,
  "created_at" : "2015-02-10 23:47:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby McKenna",
      "screen_name" : "bobby",
      "indices" : [ 0, 6 ],
      "id_str" : "17983820",
      "id" : 17983820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565285380380196865",
  "geo" : { },
  "id_str" : "565287507039096835",
  "in_reply_to_user_id" : 17983820,
  "text" : "@bobby Mr Governor, what is your position on having a tote of Skittles?",
  "id" : 565287507039096835,
  "in_reply_to_status_id" : 565285380380196865,
  "created_at" : "2015-02-10 23:13:38 +0000",
  "in_reply_to_screen_name" : "bobby",
  "in_reply_to_user_id_str" : "17983820",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565256466844880898",
  "geo" : { },
  "id_str" : "565260142376394752",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant but what about the 99% milk",
  "id" : 565260142376394752,
  "in_reply_to_status_id" : 565256466844880898,
  "created_at" : "2015-02-10 21:24:54 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jaime Bellmyer",
      "screen_name" : "bellmyer",
      "indices" : [ 0, 9 ],
      "id_str" : "14997187",
      "id" : 14997187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565249851190181888",
  "geo" : { },
  "id_str" : "565250516973002754",
  "in_reply_to_user_id" : 14997187,
  "text" : "@bellmyer 8CPU\/16GB. Don't need anything near that for a personal one.",
  "id" : 565250516973002754,
  "in_reply_to_status_id" : 565249851190181888,
  "created_at" : "2015-02-10 20:46:39 +0000",
  "in_reply_to_screen_name" : "bellmyer",
  "in_reply_to_user_id_str" : "14997187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565242966374350848",
  "geo" : { },
  "id_str" : "565243444034301952",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz could they contact you on updog?",
  "id" : 565243444034301952,
  "in_reply_to_status_id" : 565242966374350848,
  "created_at" : "2015-02-10 20:18:33 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Distance",
      "screen_name" : "distancemag",
      "indices" : [ 3, 15 ],
      "id_str" : "2432346013",
      "id" : 2432346013
    }, {
      "name" : "Quartz",
      "screen_name" : "qz",
      "indices" : [ 27, 30 ],
      "id_str" : "573918122",
      "id" : 573918122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/N13VZx9NLf",
      "expanded_url" : "http:\/\/qz.com\/339724",
      "display_url" : "qz.com\/339724"
    } ]
  },
  "geo" : { },
  "id_str" : "565233755779256320",
  "text" : "RT @distancemag: Thanks to @qz for picking up our story of the world\u2019s largest, most beloved laundromat: http:\/\/t.co\/N13VZx9NLf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quartz",
        "screen_name" : "qz",
        "indices" : [ 10, 13 ],
        "id_str" : "573918122",
        "id" : 573918122
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/N13VZx9NLf",
        "expanded_url" : "http:\/\/qz.com\/339724",
        "display_url" : "qz.com\/339724"
      } ]
    },
    "geo" : { },
    "id_str" : "565233637029711872",
    "text" : "Thanks to @qz for picking up our story of the world\u2019s largest, most beloved laundromat: http:\/\/t.co\/N13VZx9NLf",
    "id" : 565233637029711872,
    "created_at" : "2015-02-10 19:39:35 +0000",
    "user" : {
      "name" : "The Distance",
      "screen_name" : "distancemag",
      "protected" : false,
      "id_str" : "2432346013",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562666640223911936\/zYGY1Zjf_normal.jpeg",
      "id" : 2432346013,
      "verified" : false
    }
  },
  "id" : 565233755779256320,
  "created_at" : "2015-02-10 19:40:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "indices" : [ 82, 92 ],
      "id_str" : "816041347",
      "id" : 816041347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565233635843129345",
  "text" : "Seriously one of the best emails I get all week is the heaping list of carbs that @BreadHive has ready every Tuesday.",
  "id" : 565233635843129345,
  "created_at" : "2015-02-10 19:39:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565227441053270018",
  "geo" : { },
  "id_str" : "565228169171857408",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu oh no :(((((",
  "id" : 565228169171857408,
  "in_reply_to_status_id" : 565227441053270018,
  "created_at" : "2015-02-10 19:17:51 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Chalkley",
      "screen_name" : "chalkers",
      "indices" : [ 0, 9 ],
      "id_str" : "14360603",
      "id" : 14360603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565221147365490688",
  "geo" : { },
  "id_str" : "565221476497121280",
  "in_reply_to_user_id" : 14360603,
  "text" : "@chalkers Huh. I'm just going to wait another few years to pay attention to JS again.",
  "id" : 565221476497121280,
  "in_reply_to_status_id" : 565221147365490688,
  "created_at" : "2015-02-10 18:51:15 +0000",
  "in_reply_to_screen_name" : "chalkers",
  "in_reply_to_user_id_str" : "14360603",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Mitchum",
      "screen_name" : "phishcrit",
      "indices" : [ 0, 10 ],
      "id_str" : "467682045",
      "id" : 467682045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565219540452515840",
  "geo" : { },
  "id_str" : "565221078843551744",
  "in_reply_to_user_id" : 467682045,
  "text" : "@phishcrit well, now i'm listening to this show. thanks!",
  "id" : 565221078843551744,
  "in_reply_to_status_id" : 565219540452515840,
  "created_at" : "2015-02-10 18:49:41 +0000",
  "in_reply_to_screen_name" : "phishcrit",
  "in_reply_to_user_id_str" : "467682045",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565220915278266368",
  "text" : "I also don't get this about the io\/node split: Isn't npm the \"Node\" package manager? Will there be a ipm\/iopm?",
  "id" : 565220915278266368,
  "created_at" : "2015-02-10 18:49:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ghost in the Machine",
      "screen_name" : "hopefulcyborg",
      "indices" : [ 0, 14 ],
      "id_str" : "58708498",
      "id" : 58708498
    }, {
      "name" : "Raquel V\u00E9lez",
      "screen_name" : "rockbot",
      "indices" : [ 15, 23 ],
      "id_str" : "26330898",
      "id" : 26330898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565220351710212096",
  "geo" : { },
  "id_str" : "565220740174458880",
  "in_reply_to_user_id" : 58708498,
  "text" : "@hopefulcyborg @rockbot but then again we have a mostly hands-off philosophy short of hosting the files.",
  "id" : 565220740174458880,
  "in_reply_to_status_id" : 565220351710212096,
  "created_at" : "2015-02-10 18:48:20 +0000",
  "in_reply_to_screen_name" : "hopefulcyborg",
  "in_reply_to_user_id_str" : "58708498",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ghost in the Machine",
      "screen_name" : "hopefulcyborg",
      "indices" : [ 0, 14 ],
      "id_str" : "58708498",
      "id" : 58708498
    }, {
      "name" : "Raquel V\u00E9lez",
      "screen_name" : "rockbot",
      "indices" : [ 15, 23 ],
      "id_str" : "26330898",
      "id" : 26330898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/33aYAoRhje",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "565220351710212096",
  "geo" : { },
  "id_str" : "565220611421917184",
  "in_reply_to_user_id" : 58708498,
  "text" : "@hopefulcyborg @rockbot i've always been afraid of building\/deciding on a recommendation engine for http:\/\/t.co\/33aYAoRhje - curious here :)",
  "id" : 565220611421917184,
  "in_reply_to_status_id" : 565220351710212096,
  "created_at" : "2015-02-10 18:47:49 +0000",
  "in_reply_to_screen_name" : "hopefulcyborg",
  "in_reply_to_user_id_str" : "58708498",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/xbLIcRrGsQ",
      "expanded_url" : "http:\/\/www.phishtracks.com\/shows",
      "display_url" : "phishtracks.com\/shows"
    } ]
  },
  "geo" : { },
  "id_str" : "565219819965145088",
  "text" : "Always makes me a little happy to see that Rails 404 page on sites that you love to use http:\/\/t.co\/xbLIcRrGsQ",
  "id" : 565219819965145088,
  "created_at" : "2015-02-10 18:44:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/Zv5o2aCXYT",
      "expanded_url" : "http:\/\/www.joyent.com\/about\/press\/joyent-moves-to-establish-nodejs-foundation",
      "display_url" : "joyent.com\/about\/press\/jo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565211971759656960",
  "text" : "I don't understand Yavascript anymore. http:\/\/t.co\/Zv5o2aCXYT",
  "id" : 565211971759656960,
  "created_at" : "2015-02-10 18:13:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 54, 68 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565205833014050816",
  "text" : "New Indian place Chennai Express is a block away from @coworkbuffalo and is *delicious*.",
  "id" : 565205833014050816,
  "created_at" : "2015-02-10 17:49:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/MW4tfVYQIm",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=M8YjvHYbZ9w",
      "display_url" : "youtube.com\/watch?v=M8YjvH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565201266054545408",
  "text" : "When Central Command takes over what is left of the United States, just wait for these to be following ground troops https:\/\/t.co\/MW4tfVYQIm",
  "id" : 565201266054545408,
  "created_at" : "2015-02-10 17:30:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "756161",
      "id" : 756161
    }, {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 10, 20 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565192498943782912",
  "geo" : { },
  "id_str" : "565193036016406529",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer @raganwald yo dog i heard you like tile on laminate so i put tiles on your tiles so you can remove laminate while you tile",
  "id" : 565193036016406529,
  "in_reply_to_status_id" : 565192498943782912,
  "created_at" : "2015-02-10 16:58:15 +0000",
  "in_reply_to_screen_name" : "zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Schulp",
      "screen_name" : "marktimemedia",
      "indices" : [ 3, 17 ],
      "id_str" : "140183551",
      "id" : 140183551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565192661091778560",
  "text" : "RT @marktimemedia: Two branches diverged on Git, and I\u2014 \nI pulled the one less traveled by,  \nAnd now there are several merge conflicts.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469462640314421248",
    "text" : "Two branches diverged on Git, and I\u2014 \nI pulled the one less traveled by,  \nAnd now there are several merge conflicts.",
    "id" : 469462640314421248,
    "created_at" : "2014-05-22 12:59:50 +0000",
    "user" : {
      "name" : "Michelle Schulp",
      "screen_name" : "marktimemedia",
      "protected" : false,
      "id_str" : "140183551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446753966752145408\/z1VJ92EH_normal.jpeg",
      "id" : 140183551,
      "verified" : false
    }
  },
  "id" : 565192661091778560,
  "created_at" : "2015-02-10 16:56:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565187083879198721",
  "geo" : { },
  "id_str" : "565187351165825024",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff is that grass? where's the snow?",
  "id" : 565187351165825024,
  "in_reply_to_status_id" : 565187083879198721,
  "created_at" : "2015-02-10 16:35:39 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Sharp",
      "screen_name" : "sarahsharp",
      "indices" : [ 3, 14 ],
      "id_str" : "14804579",
      "id" : 14804579
    }, {
      "name" : "Jeb Bush",
      "screen_name" : "JebBush",
      "indices" : [ 39, 47 ],
      "id_str" : "113047940",
      "id" : 113047940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/CjA5cKRRwY",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/andrewkaczynski\/new-jeb-bush-chief-technology-officer-deleting-old?utm_term=.aqoa6OJ0n&s=mobile#.jdp5bvr8q",
      "display_url" : "buzzfeed.com\/andrewkaczynsk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565158721764859907",
  "text" : "RT @sarahsharp: \"But he's tech savvy!\" @JebBush's campaign CTO is purging his Twitter history of sexist &amp; homophobic comments:  http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeb Bush",
        "screen_name" : "JebBush",
        "indices" : [ 23, 31 ],
        "id_str" : "113047940",
        "id" : 113047940
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/CjA5cKRRwY",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/andrewkaczynski\/new-jeb-bush-chief-technology-officer-deleting-old?utm_term=.aqoa6OJ0n&s=mobile#.jdp5bvr8q",
        "display_url" : "buzzfeed.com\/andrewkaczynsk\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "565138838201180161",
    "text" : "\"But he's tech savvy!\" @JebBush's campaign CTO is purging his Twitter history of sexist &amp; homophobic comments:  http:\/\/t.co\/CjA5cKRRwY",
    "id" : 565138838201180161,
    "created_at" : "2015-02-10 13:22:53 +0000",
    "user" : {
      "name" : "Sarah Sharp",
      "screen_name" : "sarahsharp",
      "protected" : false,
      "id_str" : "14804579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512286107300425728\/2emZ1tHi_normal.jpeg",
      "id" : 14804579,
      "verified" : false
    }
  },
  "id" : 565158721764859907,
  "created_at" : "2015-02-10 14:41:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/ekwaySUWkY",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=lhRNO6EZmRA",
      "display_url" : "m.youtube.com\/watch?v=lhRNO6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564996215054401536",
  "text" : "Cmon and SLAM! https:\/\/t.co\/ekwaySUWkY",
  "id" : 564996215054401536,
  "created_at" : "2015-02-10 03:56:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Bouchard",
      "screen_name" : "timbouchard",
      "indices" : [ 0, 12 ],
      "id_str" : "48160411",
      "id" : 48160411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564947944840114177",
  "geo" : { },
  "id_str" : "564953638125051905",
  "in_reply_to_user_id" : 48160411,
  "text" : "@timbouchard Nope, real money only",
  "id" : 564953638125051905,
  "in_reply_to_status_id" : 564947944840114177,
  "created_at" : "2015-02-10 01:06:58 +0000",
  "in_reply_to_screen_name" : "timbouchard",
  "in_reply_to_user_id_str" : "48160411",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564948615840690178",
  "geo" : { },
  "id_str" : "564953616784437248",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc seems to be OK, demanded food as normal when I went back to the kitchen.",
  "id" : 564953616784437248,
  "in_reply_to_status_id" : 564948615840690178,
  "created_at" : "2015-02-10 01:06:53 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564946987586293760",
  "geo" : { },
  "id_str" : "564947108612931584",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy I think there's a few movies about that",
  "id" : 564947108612931584,
  "in_reply_to_status_id" : 564946987586293760,
  "created_at" : "2015-02-10 00:41:01 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564946485926969344",
  "geo" : { },
  "id_str" : "564946617174749184",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy yeah eating stuff just fine. At least they'll get replaced!",
  "id" : 564946617174749184,
  "in_reply_to_status_id" : 564946485926969344,
  "created_at" : "2015-02-10 00:39:04 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564946243114106881",
  "text" : "Little dude chipped a tooth: \uD83D\uDC4E Little dude then put on Fifth Element on Netflix: \uD83D\uDC4D",
  "id" : 564946243114106881,
  "created_at" : "2015-02-10 00:37:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake @ddfreyne",
      "screen_name" : "ddfreyne",
      "indices" : [ 0, 9 ],
      "id_str" : "635353",
      "id" : 635353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564903396323258368",
  "geo" : { },
  "id_str" : "564903669536006144",
  "in_reply_to_user_id" : 635353,
  "text" : "@ddfreyne whoa what an innovation. you should be on our board",
  "id" : 564903669536006144,
  "in_reply_to_status_id" : 564903396323258368,
  "created_at" : "2015-02-09 21:48:24 +0000",
  "in_reply_to_screen_name" : "ddfreyne",
  "in_reply_to_user_id_str" : "635353",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam J. McIntyre",
      "screen_name" : "_ajm",
      "indices" : [ 0, 5 ],
      "id_str" : "74257747",
      "id" : 74257747
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 67, 76 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564902271725498368",
  "geo" : { },
  "id_str" : "564903239754063872",
  "in_reply_to_user_id" : 74257747,
  "text" : "@_ajm ooooh man. That place sure did...several numbers...on me and @bquarant back in the day",
  "id" : 564903239754063872,
  "in_reply_to_status_id" : 564902271725498368,
  "created_at" : "2015-02-09 21:46:42 +0000",
  "in_reply_to_screen_name" : "_ajm",
  "in_reply_to_user_id_str" : "74257747",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564902021514280960",
  "text" : "Seeking cofounder for startup that delivers milk to your door every week. We would even put the milk in \"bottles\" inside of a \"crate\"",
  "id" : 564902021514280960,
  "created_at" : "2015-02-09 21:41:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strand McDadJokes ",
      "screen_name" : "Strabd",
      "indices" : [ 0, 7 ],
      "id_str" : "18032208",
      "id" : 18032208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564901266329858048",
  "geo" : { },
  "id_str" : "564901673517056000",
  "in_reply_to_user_id" : 18032208,
  "text" : "@Strabd sure is!",
  "id" : 564901673517056000,
  "in_reply_to_status_id" : 564901266329858048,
  "created_at" : "2015-02-09 21:40:28 +0000",
  "in_reply_to_screen_name" : "Strabd",
  "in_reply_to_user_id_str" : "18032208",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strand McDadJokes ",
      "screen_name" : "Strabd",
      "indices" : [ 0, 7 ],
      "id_str" : "18032208",
      "id" : 18032208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564899488335011840",
  "geo" : { },
  "id_str" : "564899675208040448",
  "in_reply_to_user_id" : 18032208,
  "text" : "@Strabd we offer a 1 month sabbatical every 3 years. essentially took a month for paternity leave too in 2013.",
  "id" : 564899675208040448,
  "in_reply_to_status_id" : 564899488335011840,
  "created_at" : "2015-02-09 21:32:32 +0000",
  "in_reply_to_screen_name" : "Strabd",
  "in_reply_to_user_id_str" : "18032208",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker Higgins",
      "screen_name" : "xor",
      "indices" : [ 3, 7 ],
      "id_str" : "24500377",
      "id" : 24500377
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/xor\/status\/564356757007261696\/photo\/1",
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/osywjYKV3W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9T_ejfCIAEAXpY.png",
      "id_str" : "564356753714716673",
      "id" : 564356753714716673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9T_ejfCIAEAXpY.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 329,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 371
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 371
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 371
      } ],
      "display_url" : "pic.twitter.com\/osywjYKV3W"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/xor\/status\/564356757007261696\/photo\/1",
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/osywjYKV3W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9T_es0CcAAJw9F.png",
      "id_str" : "564356756218736640",
      "id" : 564356756218736640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9T_es0CcAAJw9F.png",
      "sizes" : [ {
        "h" : 324,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 367,
        "resize" : "fit",
        "w" : 385
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 367,
        "resize" : "fit",
        "w" : 385
      }, {
        "h" : 367,
        "resize" : "fit",
        "w" : 385
      } ],
      "display_url" : "pic.twitter.com\/osywjYKV3W"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564872035096989696",
  "text" : "RT @xor: Left: Samsung SmartTV privacy policy, warning users not to discuss personal info in front of their TV\nRight: 1984 http:\/\/t.co\/osyw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/xor\/status\/564356757007261696\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/osywjYKV3W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9T_ejfCIAEAXpY.png",
        "id_str" : "564356753714716673",
        "id" : 564356753714716673,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9T_ejfCIAEAXpY.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 371
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 371
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 371
        } ],
        "display_url" : "pic.twitter.com\/osywjYKV3W"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/xor\/status\/564356757007261696\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/osywjYKV3W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9T_es0CcAAJw9F.png",
        "id_str" : "564356756218736640",
        "id" : 564356756218736640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9T_es0CcAAJw9F.png",
        "sizes" : [ {
          "h" : 324,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 367,
          "resize" : "fit",
          "w" : 385
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 367,
          "resize" : "fit",
          "w" : 385
        }, {
          "h" : 367,
          "resize" : "fit",
          "w" : 385
        } ],
        "display_url" : "pic.twitter.com\/osywjYKV3W"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564356757007261696",
    "text" : "Left: Samsung SmartTV privacy policy, warning users not to discuss personal info in front of their TV\nRight: 1984 http:\/\/t.co\/osywjYKV3W",
    "id" : 564356757007261696,
    "created_at" : "2015-02-08 09:35:10 +0000",
    "user" : {
      "name" : "Parker Higgins",
      "screen_name" : "xor",
      "protected" : false,
      "id_str" : "24500377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563770952375205888\/a74njVWH_normal.jpeg",
      "id" : 24500377,
      "verified" : false
    }
  },
  "id" : 564872035096989696,
  "created_at" : "2015-02-09 19:42:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Claire Reese",
      "screen_name" : "eclairereese",
      "indices" : [ 3, 16 ],
      "id_str" : "176429796",
      "id" : 176429796
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/eclairereese\/status\/557575464567709696\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/n6DgmFlB9v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7zn7jSCUAAeyaD.jpg",
      "id_str" : "557575464156286976",
      "id" : 557575464156286976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7zn7jSCUAAeyaD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/n6DgmFlB9v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564869621040181248",
  "text" : "RT @eclairereese: In today\u2019s issue of \u201CStalker or Dev Recruiter?\u201D I actually panicked and thought some dude was outside my apt. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/eclairereese\/status\/557575464567709696\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/n6DgmFlB9v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7zn7jSCUAAeyaD.jpg",
        "id_str" : "557575464156286976",
        "id" : 557575464156286976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7zn7jSCUAAeyaD.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 308,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 308,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/n6DgmFlB9v"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "557575464567709696",
    "text" : "In today\u2019s issue of \u201CStalker or Dev Recruiter?\u201D I actually panicked and thought some dude was outside my apt. http:\/\/t.co\/n6DgmFlB9v",
    "id" : 557575464567709696,
    "created_at" : "2015-01-20 16:28:44 +0000",
    "user" : {
      "name" : "Emily Claire Reese",
      "screen_name" : "eclairereese",
      "protected" : false,
      "id_str" : "176429796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478684125650374657\/xbNeTYyc_normal.jpeg",
      "id" : 176429796,
      "verified" : false
    }
  },
  "id" : 564869621040181248,
  "created_at" : "2015-02-09 19:33:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenneth Kalmer",
      "screen_name" : "kennethkalmer",
      "indices" : [ 0, 14 ],
      "id_str" : "15479835",
      "id" : 15479835
    }, {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 15, 22 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564804293203861504",
  "geo" : { },
  "id_str" : "564805242651287552",
  "in_reply_to_user_id" : 15479835,
  "text" : "@kennethkalmer @lsegal lol",
  "id" : 564805242651287552,
  "in_reply_to_status_id" : 564804293203861504,
  "created_at" : "2015-02-09 15:17:18 +0000",
  "in_reply_to_screen_name" : "kennethkalmer",
  "in_reply_to_user_id_str" : "15479835",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR News",
      "screen_name" : "nprnews",
      "indices" : [ 3, 11 ],
      "id_str" : "5392522",
      "id" : 5392522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/0ddzG4GUfL",
      "expanded_url" : "http:\/\/n.pr\/1DSGN5I",
      "display_url" : "n.pr\/1DSGN5I"
    } ]
  },
  "geo" : { },
  "id_str" : "564787494932058113",
  "text" : "RT @nprnews: The Birth Of A Nation debuted 100 years ago today. The famously racist film was, in many ways, the start of Hollywood http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/0ddzG4GUfL",
        "expanded_url" : "http:\/\/n.pr\/1DSGN5I",
        "display_url" : "n.pr\/1DSGN5I"
      } ]
    },
    "geo" : { },
    "id_str" : "564627301271207937",
    "text" : "The Birth Of A Nation debuted 100 years ago today. The famously racist film was, in many ways, the start of Hollywood http:\/\/t.co\/0ddzG4GUfL",
    "id" : 564627301271207937,
    "created_at" : "2015-02-09 03:30:13 +0000",
    "user" : {
      "name" : "NPR News",
      "screen_name" : "nprnews",
      "protected" : false,
      "id_str" : "5392522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1796148436\/nprnews_icon_normal.jpg",
      "id" : 5392522,
      "verified" : true
    }
  },
  "id" : 564787494932058113,
  "created_at" : "2015-02-09 14:06:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR's Planet Money",
      "screen_name" : "planetmoney",
      "indices" : [ 3, 15 ],
      "id_str" : "15905103",
      "id" : 15905103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/SXEpSJjhGY",
      "expanded_url" : "http:\/\/n.pr\/18W5BjG",
      "display_url" : "n.pr\/18W5BjG"
    } ]
  },
  "geo" : { },
  "id_str" : "564787395225063425",
  "text" : "RT @planetmoney: Without bank accounts or loans, the pot industry is far from becoming \u2018big weed.\u2019 It\u2019s more like dad\u2019s basement. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/SXEpSJjhGY",
        "expanded_url" : "http:\/\/n.pr\/18W5BjG",
        "display_url" : "n.pr\/18W5BjG"
      } ]
    },
    "geo" : { },
    "id_str" : "564778273461522434",
    "text" : "Without bank accounts or loans, the pot industry is far from becoming \u2018big weed.\u2019 It\u2019s more like dad\u2019s basement. http:\/\/t.co\/SXEpSJjhGY",
    "id" : 564778273461522434,
    "created_at" : "2015-02-09 13:30:08 +0000",
    "user" : {
      "name" : "NPR's Planet Money",
      "screen_name" : "planetmoney",
      "protected" : false,
      "id_str" : "15905103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473888336449269761\/vIurMh9f_normal.png",
      "id" : 15905103,
      "verified" : true
    }
  },
  "id" : 564787395225063425,
  "created_at" : "2015-02-09 14:06:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/564780851716575234\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/kw1R8FGAES",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9aBMNSCAAEHRZp.png",
      "id_str" : "564780850005278721",
      "id" : 564780850005278721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9aBMNSCAAEHRZp.png",
      "sizes" : [ {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 688,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1110,
        "resize" : "fit",
        "w" : 1652
      } ],
      "display_url" : "pic.twitter.com\/kw1R8FGAES"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/aIQIr1ZjTi",
      "expanded_url" : "http:\/\/Pickaxe.club",
      "display_url" : "Pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "564780851716575234",
  "text" : "A new density as http:\/\/t.co\/aIQIr1ZjTi's downtown fills up on its 10th weekend http:\/\/t.co\/kw1R8FGAES",
  "id" : 564780851716575234,
  "created_at" : "2015-02-09 13:40:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This Karen situation",
      "screen_name" : "gamehawk",
      "indices" : [ 0, 9 ],
      "id_str" : "17582985",
      "id" : 17582985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564641216961069057",
  "geo" : { },
  "id_str" : "564642035303337987",
  "in_reply_to_user_id" : 17582985,
  "text" : "@gamehawk nice!",
  "id" : 564642035303337987,
  "in_reply_to_status_id" : 564641216961069057,
  "created_at" : "2015-02-09 04:28:46 +0000",
  "in_reply_to_screen_name" : "gamehawk",
  "in_reply_to_user_id_str" : "17582985",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564639274335612930",
  "text" : "RT @rubygems_status: Gem install and gem push errors should be resolved now. Sorry for the trouble!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564637016777060352",
    "text" : "Gem install and gem push errors should be resolved now. Sorry for the trouble!",
    "id" : 564637016777060352,
    "created_at" : "2015-02-09 04:08:49 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 564639274335612930,
  "created_at" : "2015-02-09 04:17:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564627137945411584",
  "text" : "RT @rubygems_status: Current status: There's some problems with gem install. We're on it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564625286235713536",
    "text" : "Current status: There's some problems with gem install. We're on it!",
    "id" : 564625286235713536,
    "created_at" : "2015-02-09 03:22:13 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 564627137945411584,
  "created_at" : "2015-02-09 03:29:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "friendly catduck\u2122",
      "screen_name" : "duckinator",
      "indices" : [ 0, 11 ],
      "id_str" : "28650670",
      "id" : 28650670
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 12, 25 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Rocketpilot",
      "screen_name" : "ABillionSuns",
      "indices" : [ 26, 39 ],
      "id_str" : "32317477",
      "id" : 32317477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564624397366231040",
  "geo" : { },
  "id_str" : "564624805299625985",
  "in_reply_to_user_id" : 28650670,
  "text" : "@duckinator @steveklabnik @ABillionSuns not sure whats up but i've turned on the batsignal",
  "id" : 564624805299625985,
  "in_reply_to_status_id" : 564624397366231040,
  "created_at" : "2015-02-09 03:20:18 +0000",
  "in_reply_to_screen_name" : "duckinator",
  "in_reply_to_user_id_str" : "28650670",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    }, {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 7, 19 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564622930840391680",
  "geo" : { },
  "id_str" : "564623520886321153",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d @john_floren and you both said twitter was stupid",
  "id" : 564623520886321153,
  "in_reply_to_status_id" : 564622930840391680,
  "created_at" : "2015-02-09 03:15:12 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annika Backstrom",
      "screen_name" : "abackstrom",
      "indices" : [ 0, 11 ],
      "id_str" : "3621751",
      "id" : 3621751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564621852602302464",
  "geo" : { },
  "id_str" : "564623250710200323",
  "in_reply_to_user_id" : 3621751,
  "text" : "@abackstrom sorry to hear this :( Not the first i've heard. I think the school in general is becoming less brutal (semesters for one!)",
  "id" : 564623250710200323,
  "in_reply_to_status_id" : 564621852602302464,
  "created_at" : "2015-02-09 03:14:07 +0000",
  "in_reply_to_screen_name" : "abackstrom",
  "in_reply_to_user_id_str" : "3621751",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564621292154810369",
  "text" : "It's also fucking terrifying and I know a lot of friends that had trouble with it. But imagine waiting until the end to learn all that.",
  "id" : 564621292154810369,
  "created_at" : "2015-02-09 03:06:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564621104539377665",
  "text" : "Just the fact that you're pushed to figure out *how to get a job* 1.5-2 years into college instead of after 4+, is so fundamental",
  "id" : 564621104539377665,
  "created_at" : "2015-02-09 03:05:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564620897005228032",
  "text" : "I wish co-op was an essential part of the college\/university experience everywhere. It really does change your perspective on work and life.",
  "id" : 564620897005228032,
  "created_at" : "2015-02-09 03:04:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This Karen situation",
      "screen_name" : "gamehawk",
      "indices" : [ 0, 9 ],
      "id_str" : "17582985",
      "id" : 17582985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564595313730523136",
  "geo" : { },
  "id_str" : "564605040749326337",
  "in_reply_to_user_id" : 17582985,
  "text" : "@gamehawk nice!!",
  "id" : 564605040749326337,
  "in_reply_to_status_id" : 564595313730523136,
  "created_at" : "2015-02-09 02:01:46 +0000",
  "in_reply_to_screen_name" : "gamehawk",
  "in_reply_to_user_id_str" : "17582985",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This Karen situation",
      "screen_name" : "gamehawk",
      "indices" : [ 3, 12 ],
      "id_str" : "17582985",
      "id" : 17582985
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 14, 20 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/gamehawk\/status\/564595313730523136\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/17jpBbhaU7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9XYP6UCcAEOZoQ.png",
      "id_str" : "564595096167804929",
      "id" : 564595096167804929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9XYP6UCcAEOZoQ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 854
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 854
      } ],
      "display_url" : "pic.twitter.com\/17jpBbhaU7"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/gamehawk\/status\/564595313730523136\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/17jpBbhaU7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9XYP6KCAAAmoDt.png",
      "id_str" : "564595096125833216",
      "id" : 564595096125833216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9XYP6KCAAAmoDt.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 854
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 854
      } ],
      "display_url" : "pic.twitter.com\/17jpBbhaU7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564605017294794752",
  "text" : "RT @gamehawk: @qrush Reworking desert tower roof. To avoid digging more red sand, I finished the pickaxe (canal) monument instead. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/gamehawk\/status\/564595313730523136\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/17jpBbhaU7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9XYP6UCcAEOZoQ.png",
        "id_str" : "564595096167804929",
        "id" : 564595096167804929,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9XYP6UCcAEOZoQ.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 854
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 854
        } ],
        "display_url" : "pic.twitter.com\/17jpBbhaU7"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/gamehawk\/status\/564595313730523136\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/17jpBbhaU7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9XYP6KCAAAmoDt.png",
        "id_str" : "564595096125833216",
        "id" : 564595096125833216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9XYP6KCAAAmoDt.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 854
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 854
        } ],
        "display_url" : "pic.twitter.com\/17jpBbhaU7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564595313730523136",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush Reworking desert tower roof. To avoid digging more red sand, I finished the pickaxe (canal) monument instead. http:\/\/t.co\/17jpBbhaU7",
    "id" : 564595313730523136,
    "created_at" : "2015-02-09 01:23:07 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "This Karen situation",
      "screen_name" : "gamehawk",
      "protected" : false,
      "id_str" : "17582985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535841464110940160\/xuBjQcbB_normal.png",
      "id" : 17582985,
      "verified" : false
    }
  },
  "id" : 564605017294794752,
  "created_at" : "2015-02-09 02:01:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 1, 13 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/ZfzjB0i9Fk",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=sGKJI4rpQL4",
      "display_url" : "youtube.com\/watch?v=sGKJI4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564575248855863297",
  "text" : ".@whereslloyd is on TV!!! https:\/\/t.co\/ZfzjB0i9Fk",
  "id" : 564575248855863297,
  "created_at" : "2015-02-09 00:03:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564549022346526720",
  "text" : "RT @dhh: Plenty of shops have 10+ devs working on just 1 mobile app for 1 platform. Hybrid productivity is a 10x boost when it fits the dom\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564521738835202048",
    "text" : "Plenty of shops have 10+ devs working on just 1 mobile app for 1 platform. Hybrid productivity is a 10x boost when it fits the domain.",
    "id" : 564521738835202048,
    "created_at" : "2015-02-08 20:30:45 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 564549022346526720,
  "created_at" : "2015-02-08 22:19:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564548965354311680",
  "text" : "RT @dhh: Hybrid approach has allowed Android, iOS, mobile web, desktop web versions of BC to be developed by ~10 progs also working on next\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564521372164956160",
    "text" : "Hybrid approach has allowed Android, iOS, mobile web, desktop web versions of BC to be developed by ~10 progs also working on next-gen BC.",
    "id" : 564521372164956160,
    "created_at" : "2015-02-08 20:29:18 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 564548965354311680,
  "created_at" : "2015-02-08 22:18:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 0, 11 ],
      "id_str" : "9887102",
      "id" : 9887102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564497750944149508",
  "geo" : { },
  "id_str" : "564529582477291520",
  "in_reply_to_user_id" : 9887102,
  "text" : "@metaskills many many. Some structures entirely underground",
  "id" : 564529582477291520,
  "in_reply_to_status_id" : 564497750944149508,
  "created_at" : "2015-02-08 21:01:55 +0000",
  "in_reply_to_screen_name" : "metaskills",
  "in_reply_to_user_id_str" : "9887102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "indices" : [ 0, 13 ],
      "id_str" : "9154112",
      "id" : 9154112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564489646122356736",
  "geo" : { },
  "id_str" : "564490257010135041",
  "in_reply_to_user_id" : 9154112,
  "text" : "@jeremiahfelt there's been kids on with parents (or without) since week 2. whats the problem?",
  "id" : 564490257010135041,
  "in_reply_to_status_id" : 564489646122356736,
  "created_at" : "2015-02-08 18:25:39 +0000",
  "in_reply_to_screen_name" : "jeremiahfelt",
  "in_reply_to_user_id_str" : "9154112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "indices" : [ 0, 13 ],
      "id_str" : "9154112",
      "id" : 9154112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564487974830628865",
  "geo" : { },
  "id_str" : "564489375078023168",
  "in_reply_to_user_id" : 9154112,
  "text" : "@jeremiahfelt why?",
  "id" : 564489375078023168,
  "in_reply_to_status_id" : 564487974830628865,
  "created_at" : "2015-02-08 18:22:09 +0000",
  "in_reply_to_screen_name" : "jeremiahfelt",
  "in_reply_to_user_id_str" : "9154112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/aTmchFxcRR",
      "expanded_url" : "http:\/\/pickaxe.club\/#city\/2\/5\/-22\/272\/64",
      "display_url" : "pickaxe.club\/#city\/2\/5\/-22\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564486042103726080",
  "text" : "For reference here's what that area looked like last week. http:\/\/t.co\/aTmchFxcRR",
  "id" : 564486042103726080,
  "created_at" : "2015-02-08 18:08:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/564485830454956032\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/eZYe6wtgEV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9V03wPCYAAF4Sk.png",
      "id_str" : "564485829494464512",
      "id" : 564485829494464512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9V03wPCYAAF4Sk.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/eZYe6wtgEV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564485830454956032",
  "text" : "Also the eastern side of Pickaxe City has been booming. Cube, some new castles, a neat modern library thing, etc http:\/\/t.co\/eZYe6wtgEV",
  "id" : 564485830454956032,
  "created_at" : "2015-02-08 18:08:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/564485597725601792\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/rv8pw6SuWZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9V0qNkCEAAvchb.png",
      "id_str" : "564485596848984064",
      "id" : 564485596848984064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9V0qNkCEAAvchb.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rv8pw6SuWZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aIQIr1ZjTi",
      "expanded_url" : "http:\/\/Pickaxe.club",
      "display_url" : "Pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "564485597725601792",
  "text" : "http:\/\/t.co\/aIQIr1ZjTi City Hall finally topped out with a observation deck up top. Now to decide what to put inside! http:\/\/t.co\/rv8pw6SuWZ",
  "id" : 564485597725601792,
  "created_at" : "2015-02-08 18:07:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Silkey",
      "screen_name" : "filler",
      "indices" : [ 0, 7 ],
      "id_str" : "10076322",
      "id" : 10076322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564461515210620928",
  "geo" : { },
  "id_str" : "564475761466171392",
  "in_reply_to_user_id" : 10076322,
  "text" : "@filler join the mailing list!",
  "id" : 564475761466171392,
  "in_reply_to_status_id" : 564461515210620928,
  "created_at" : "2015-02-08 17:28:03 +0000",
  "in_reply_to_screen_name" : "filler",
  "in_reply_to_user_id_str" : "10076322",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 3, 13 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/Q4VXJTjOf5",
      "expanded_url" : "http:\/\/www.daedtech.com\/programmer-is-a-career-path-thank-you",
      "display_url" : "daedtech.com\/programmer-is-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564431526809448449",
  "text" : "RT @asianmack: Programmer *is* a career path: http:\/\/t.co\/Q4VXJTjOf5 ... This essay also applies to Graphic Designers too.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/Q4VXJTjOf5",
        "expanded_url" : "http:\/\/www.daedtech.com\/programmer-is-a-career-path-thank-you",
        "display_url" : "daedtech.com\/programmer-is-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "564427028787499010",
    "text" : "Programmer *is* a career path: http:\/\/t.co\/Q4VXJTjOf5 ... This essay also applies to Graphic Designers too.",
    "id" : 564427028787499010,
    "created_at" : "2015-02-08 14:14:24 +0000",
    "user" : {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "protected" : false,
      "id_str" : "15045995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542325270447808512\/BgWzvXi8_normal.png",
      "id" : 15045995,
      "verified" : false
    }
  },
  "id" : 564431526809448449,
  "created_at" : "2015-02-08 14:32:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David McMaster",
      "screen_name" : "dmcmasterr",
      "indices" : [ 0, 11 ],
      "id_str" : "181356849",
      "id" : 181356849
    }, {
      "name" : "Buffalo Sabres",
      "screen_name" : "BuffaloSabres",
      "indices" : [ 12, 26 ],
      "id_str" : "22536395",
      "id" : 22536395
    }, {
      "name" : "Craig Kanalley",
      "screen_name" : "ckanal",
      "indices" : [ 27, 34 ],
      "id_str" : "15964196",
      "id" : 15964196
    }, {
      "name" : "Lindy Ruff's Tie",
      "screen_name" : "LindyRuffsTie",
      "indices" : [ 45, 59 ],
      "id_str" : "97362461",
      "id" : 97362461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564246353464025088",
  "geo" : { },
  "id_str" : "564280111168757760",
  "in_reply_to_user_id" : 181356849,
  "text" : "@dmcmasterr @BuffaloSabres @ckanal attention @LindyRuffsTie",
  "id" : 564280111168757760,
  "in_reply_to_status_id" : 564246353464025088,
  "created_at" : "2015-02-08 04:30:36 +0000",
  "in_reply_to_screen_name" : "dmcmasterr",
  "in_reply_to_user_id_str" : "181356849",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564241136634830848",
  "geo" : { },
  "id_str" : "564243676965388288",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos yeah, I have taken to finding random MIDIs and plugging them in",
  "id" : 564243676965388288,
  "in_reply_to_status_id" : 564241136634830848,
  "created_at" : "2015-02-08 02:05:50 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564202262630002688",
  "geo" : { },
  "id_str" : "564235908577116161",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos but in general I have no idea. I bought Linus and Lucy and been working on it for weeks",
  "id" : 564235908577116161,
  "in_reply_to_status_id" : 564202262630002688,
  "created_at" : "2015-02-08 01:34:58 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564209853531316224",
  "text" : "Poking on Facebook is still a thing?!!!!",
  "id" : 564209853531316224,
  "created_at" : "2015-02-07 23:51:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/IcxzqwlQki",
      "expanded_url" : "http:\/\/qz.com\/333897\/japanese-army-troops-have-built-a-giant-star-wars-snow-sculpture\/",
      "display_url" : "qz.com\/333897\/japanes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564204574827749377",
  "text" : "Hey Buffalo here's an idea for all of the snow we have and are about to get http:\/\/t.co\/IcxzqwlQki",
  "id" : 564204574827749377,
  "created_at" : "2015-02-07 23:30:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564202262630002688",
  "geo" : { },
  "id_str" : "564204410427826176",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos I have the midi to USB plug they recommend and the OSX version.",
  "id" : 564204410427826176,
  "in_reply_to_status_id" : 564202262630002688,
  "created_at" : "2015-02-07 23:29:48 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/564186509751099393\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/C5zWxMhFEc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9RkpC1IIAEY7LZ.jpg",
      "id_str" : "564186509625270273",
      "id" : 564186509625270273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9RkpC1IIAEY7LZ.jpg",
      "sizes" : [ {
        "h" : 511,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/C5zWxMhFEc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564186509751099393",
  "text" : "Step 2: draw the rest of the fucking dog http:\/\/t.co\/C5zWxMhFEc",
  "id" : 564186509751099393,
  "created_at" : "2015-02-07 22:18:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 64, 72 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/564163333557714944\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/1lCq15lQQU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9RPj-LCIAA-csA.png",
      "id_str" : "564163332731445248",
      "id" : 564163332731445248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9RPj-LCIAA-csA.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1lCq15lQQU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564163333557714944",
  "text" : "Early lead for MVP (Most Valuable Pickaxer) of the week goes to @sikachu for this http:\/\/t.co\/1lCq15lQQU",
  "id" : 564163333557714944,
  "created_at" : "2015-02-07 20:46:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564155111480770561",
  "geo" : { },
  "id_str" : "564155354972315649",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda run, you fools!",
  "id" : 564155354972315649,
  "in_reply_to_status_id" : 564155111480770561,
  "created_at" : "2015-02-07 20:14:52 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564155270553538562",
  "text" : "Synthesia is great but brutally honest with its stats. It's nice to see *some* improvement though.",
  "id" : 564155270553538562,
  "created_at" : "2015-02-07 20:14:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miah Johnson",
      "screen_name" : "miah_",
      "indices" : [ 0, 6 ],
      "id_str" : "14260840",
      "id" : 14260840
    }, {
      "name" : "jacky",
      "screen_name" : "jackyalcine",
      "indices" : [ 7, 19 ],
      "id_str" : "44119449",
      "id" : 44119449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564128166160003075",
  "geo" : { },
  "id_str" : "564129007008899072",
  "in_reply_to_user_id" : 14260840,
  "text" : "@miah_ @jackyalcine sadly this has been RubyGems' problem in general for years.",
  "id" : 564129007008899072,
  "in_reply_to_status_id" : 564128166160003075,
  "created_at" : "2015-02-07 18:30:10 +0000",
  "in_reply_to_screen_name" : "miah_",
  "in_reply_to_user_id_str" : "14260840",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "auntie moon",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/0IFlh1d7NP",
      "expanded_url" : "http:\/\/on.recode.net\/1D82GPX",
      "display_url" : "on.recode.net\/1D82GPX"
    } ]
  },
  "geo" : { },
  "id_str" : "564098047865782272",
  "text" : "RT @ashedryden: Silicon Valley is gross in literally every way imaginable http:\/\/t.co\/0IFlh1d7NP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/0IFlh1d7NP",
        "expanded_url" : "http:\/\/on.recode.net\/1D82GPX",
        "display_url" : "on.recode.net\/1D82GPX"
      } ]
    },
    "geo" : { },
    "id_str" : "564087702480355328",
    "text" : "Silicon Valley is gross in literally every way imaginable http:\/\/t.co\/0IFlh1d7NP",
    "id" : 564087702480355328,
    "created_at" : "2015-02-07 15:46:03 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 564098047865782272,
  "created_at" : "2015-02-07 16:27:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Graves",
      "screen_name" : "didlix",
      "indices" : [ 0, 7 ],
      "id_str" : "81434063",
      "id" : 81434063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564055791217704960",
  "geo" : { },
  "id_str" : "564057984817307648",
  "in_reply_to_user_id" : 81434063,
  "text" : "@didlix don't forget the Princess :\\",
  "id" : 564057984817307648,
  "in_reply_to_status_id" : 564055791217704960,
  "created_at" : "2015-02-07 13:47:57 +0000",
  "in_reply_to_screen_name" : "didlix",
  "in_reply_to_user_id_str" : "81434063",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564057052339638274",
  "text" : "Technically 11th but we lost one weekend of data. I should write up the experience thus far.",
  "id" : 564057052339638274,
  "created_at" : "2015-02-07 13:44:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/biwDqHL2ML",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "564056922463035394",
  "text" : "This is the 10th weekend of http:\/\/t.co\/biwDqHL2ML. It's still pretty fun and we had ~10-12 people on last night.",
  "id" : 564056922463035394,
  "created_at" : "2015-02-07 13:43:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Borenstein",
      "screen_name" : "pborenstein",
      "indices" : [ 0, 12 ],
      "id_str" : "3675931",
      "id" : 3675931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563894791923302401",
  "geo" : { },
  "id_str" : "563902593915576321",
  "in_reply_to_user_id" : 3675931,
  "text" : "@pborenstein awesome! I'll have to get it in.",
  "id" : 563902593915576321,
  "in_reply_to_status_id" : 563894791923302401,
  "created_at" : "2015-02-07 03:30:29 +0000",
  "in_reply_to_screen_name" : "pborenstein",
  "in_reply_to_user_id_str" : "3675931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M-A",
      "screen_name" : "MileHighMusik",
      "indices" : [ 0, 14 ],
      "id_str" : "184501661",
      "id" : 184501661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563853982964416512",
  "geo" : { },
  "id_str" : "563854317250412545",
  "in_reply_to_user_id" : 184501661,
  "text" : "@MileHighMusik you seen that Liam Neesons movie where he killed those wolves and shit?",
  "id" : 563854317250412545,
  "in_reply_to_status_id" : 563853982964416512,
  "created_at" : "2015-02-07 00:18:39 +0000",
  "in_reply_to_screen_name" : "MileHighMusik",
  "in_reply_to_user_id_str" : "184501661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iliza Shlesinger",
      "screen_name" : "iliza",
      "indices" : [ 42, 48 ],
      "id_str" : "20900209",
      "id" : 20900209
    }, {
      "name" : "HeliumComedy Buffalo",
      "screen_name" : "HeliumComedyBUF",
      "indices" : [ 85, 101 ],
      "id_str" : "733412917",
      "id" : 733412917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/zFi8VUY39O",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/jONW9uqzSuH",
      "display_url" : "swarmapp.com\/c\/jONW9uqzSuH"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8744049548, -78.874320933 ]
  },
  "id_str" : "563852818101321728",
  "text" : "First comedy show in a long time and it's @iliza's. Not bad. (@ Helium Comedy Club - @heliumcomedybuf) https:\/\/t.co\/zFi8VUY39O",
  "id" : 563852818101321728,
  "created_at" : "2015-02-07 00:12:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/2vKzn7eeoG",
      "expanded_url" : "http:\/\/blogs.wsj.com\/speakeasy\/2015\/02\/06\/legend-of-zelda-netflix-series\/",
      "display_url" : "blogs.wsj.com\/speakeasy\/2015\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563807945935163392",
  "text" : "EXCUUUUUUSE ME PRINCESS http:\/\/t.co\/2vKzn7eeoG",
  "id" : 563807945935163392,
  "created_at" : "2015-02-06 21:14:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean",
      "screen_name" : "wheelbytes",
      "indices" : [ 0, 11 ],
      "id_str" : "536555069",
      "id" : 536555069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563803373674455040",
  "geo" : { },
  "id_str" : "563803934880305152",
  "in_reply_to_user_id" : 536555069,
  "text" : "@wheelbytes i'm not in Philly. You should go!",
  "id" : 563803934880305152,
  "in_reply_to_status_id" : 563803373674455040,
  "created_at" : "2015-02-06 20:58:27 +0000",
  "in_reply_to_screen_name" : "wheelbytes",
  "in_reply_to_user_id_str" : "536555069",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Sanche",
      "screen_name" : "thoughtsupnorth",
      "indices" : [ 3, 19 ],
      "id_str" : "990260678",
      "id" : 990260678
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/thoughtsupnorth\/status\/562081496731627520\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/5tTvX40kcj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8zqI7JCEAA4IEl.jpg",
      "id_str" : "562081492549898240",
      "id" : 562081492549898240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8zqI7JCEAA4IEl.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5tTvX40kcj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563781616275689472",
  "text" : "RT @thoughtsupnorth: excuse you http:\/\/t.co\/5tTvX40kcj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/thoughtsupnorth\/status\/562081496731627520\/photo\/1",
        "indices" : [ 11, 33 ],
        "url" : "http:\/\/t.co\/5tTvX40kcj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8zqI7JCEAA4IEl.jpg",
        "id_str" : "562081492549898240",
        "id" : 562081492549898240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8zqI7JCEAA4IEl.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/5tTvX40kcj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562081496731627520",
    "text" : "excuse you http:\/\/t.co\/5tTvX40kcj",
    "id" : 562081496731627520,
    "created_at" : "2015-02-02 02:54:06 +0000",
    "user" : {
      "name" : "Mary Sanche",
      "screen_name" : "thoughtsupnorth",
      "protected" : false,
      "id_str" : "990260678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/534817189216256000\/32-D6D23_normal.jpeg",
      "id" : 990260678,
      "verified" : false
    }
  },
  "id" : 563781616275689472,
  "created_at" : "2015-02-06 19:29:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 23, 35 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Ardmore Music Hall",
      "screen_name" : "ArdmoreMusicPA",
      "indices" : [ 50, 65 ],
      "id_str" : "449224939",
      "id" : 449224939
    }, {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 104, 112 ],
      "id_str" : "22682102",
      "id" : 22682102
    }, {
      "name" : "Len Smith",
      "screen_name" : "ignu",
      "indices" : [ 113, 118 ],
      "id_str" : "6649832",
      "id" : 6649832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563773224786223104",
  "text" : "Who else is in Philly? @AqueousBand is playing at @ArdmoreMusicPA tonight and it's worth the drive. \/cc @dmansen @ignu",
  "id" : 563773224786223104,
  "created_at" : "2015-02-06 18:56:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ol' QWERTY bastard",
      "screen_name" : "ElSangito",
      "indices" : [ 3, 13 ],
      "id_str" : "24504850",
      "id" : 24504850
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ElSangito\/status\/491698547339706368\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/RM5ZEpeklz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtLdOI-CAAQqmpI.jpg",
      "id_str" : "491698544332374020",
      "id" : 491698544332374020,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtLdOI-CAAQqmpI.jpg",
      "sizes" : [ {
        "h" : 381,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RM5ZEpeklz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563737455887532032",
  "text" : "RT @ElSangito: my transition into a more sophisticated modern adult http:\/\/t.co\/RM5ZEpeklz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ElSangito\/status\/491698547339706368\/photo\/1",
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/RM5ZEpeklz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtLdOI-CAAQqmpI.jpg",
        "id_str" : "491698544332374020",
        "id" : 491698544332374020,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtLdOI-CAAQqmpI.jpg",
        "sizes" : [ {
          "h" : 381,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 381,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 202,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RM5ZEpeklz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "491698547339706368",
    "text" : "my transition into a more sophisticated modern adult http:\/\/t.co\/RM5ZEpeklz",
    "id" : 491698547339706368,
    "created_at" : "2014-07-22 21:37:23 +0000",
    "user" : {
      "name" : "ol' QWERTY bastard",
      "screen_name" : "ElSangito",
      "protected" : false,
      "id_str" : "24504850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566268385986482176\/xRJIt1TQ_normal.jpeg",
      "id" : 24504850,
      "verified" : false
    }
  },
  "id" : 563737455887532032,
  "created_at" : "2015-02-06 16:34:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dick costolo",
      "screen_name" : "dickc",
      "indices" : [ 56, 62 ],
      "id_str" : "6385432",
      "id" : 6385432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/wyCdVtSId9",
      "expanded_url" : "http:\/\/www.onthemedia.org\/story\/45-quiet-wadhwa\/",
      "display_url" : "onthemedia.org\/story\/45-quiet\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563734858652872704",
  "text" : "\"Vivek Wadhwa is the Carrot Top of academic sources.\" - @dickc, part 2: http:\/\/t.co\/wyCdVtSId9",
  "id" : 563734858652872704,
  "created_at" : "2015-02-06 16:23:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Patton Fleece",
      "screen_name" : "DrFleece",
      "indices" : [ 3, 12 ],
      "id_str" : "2279771197",
      "id" : 2279771197
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DrFleece\/status\/560304476330811392\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/QaJIEGcYUz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8aZ81HCUAE2ziv.jpg",
      "id_str" : "560304473981997057",
      "id" : 560304473981997057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8aZ81HCUAE2ziv.jpg",
      "sizes" : [ {
        "h" : 404,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 839
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 839
      } ],
      "display_url" : "pic.twitter.com\/QaJIEGcYUz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563732428347289600",
  "text" : "RT @DrFleece: President Obama meeting with the hyper-advance sentient colour clusters of Omicron Prime. http:\/\/t.co\/QaJIEGcYUz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DrFleece\/status\/560304476330811392\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/QaJIEGcYUz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8aZ81HCUAE2ziv.jpg",
        "id_str" : "560304473981997057",
        "id" : 560304473981997057,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8aZ81HCUAE2ziv.jpg",
        "sizes" : [ {
          "h" : 404,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 565,
          "resize" : "fit",
          "w" : 839
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 565,
          "resize" : "fit",
          "w" : 839
        } ],
        "display_url" : "pic.twitter.com\/QaJIEGcYUz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "560304476330811392",
    "text" : "President Obama meeting with the hyper-advance sentient colour clusters of Omicron Prime. http:\/\/t.co\/QaJIEGcYUz",
    "id" : 560304476330811392,
    "created_at" : "2015-01-28 05:12:51 +0000",
    "user" : {
      "name" : "H. Patton Fleece",
      "screen_name" : "DrFleece",
      "protected" : false,
      "id_str" : "2279771197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/516010152655593472\/q-GApSKm_normal.jpeg",
      "id" : 2279771197,
      "verified" : false
    }
  },
  "id" : 563732428347289600,
  "created_at" : "2015-02-06 16:14:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saladin Ahmed",
      "screen_name" : "saladinahmed",
      "indices" : [ 3, 16 ],
      "id_str" : "29995782",
      "id" : 29995782
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/saladinahmed\/status\/563720785983180800\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/cjR06LpbfO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9K9EIWIEAEVb22.jpg",
      "id_str" : "563720782032146433",
      "id" : 563720782032146433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9K9EIWIEAEVb22.jpg",
      "sizes" : [ {
        "h" : 71,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/cjR06LpbfO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563728454609166337",
  "text" : "RT @saladinahmed: Albert Einstein almost never visited colleges. But in 1946 he made an exception: Lincoln University, a Black school. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/saladinahmed\/status\/563720785983180800\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/cjR06LpbfO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9K9EIWIEAEVb22.jpg",
        "id_str" : "563720782032146433",
        "id" : 563720782032146433,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9K9EIWIEAEVb22.jpg",
        "sizes" : [ {
          "h" : 71,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 126,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/cjR06LpbfO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563720785983180800",
    "text" : "Albert Einstein almost never visited colleges. But in 1946 he made an exception: Lincoln University, a Black school. http:\/\/t.co\/cjR06LpbfO",
    "id" : 563720785983180800,
    "created_at" : "2015-02-06 15:28:03 +0000",
    "user" : {
      "name" : "Saladin Ahmed",
      "screen_name" : "saladinahmed",
      "protected" : false,
      "id_str" : "29995782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491401748503076865\/CiUrJ-o2_normal.jpeg",
      "id" : 29995782,
      "verified" : false
    }
  },
  "id" : 563728454609166337,
  "created_at" : "2015-02-06 15:58:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielle",
      "screen_name" : "duh_nellll",
      "indices" : [ 0, 11 ],
      "id_str" : "146513248",
      "id" : 146513248
    }, {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 12, 21 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563724509312983040",
  "geo" : { },
  "id_str" : "563725047542468608",
  "in_reply_to_user_id" : 146513248,
  "text" : "@duh_nellll @Sigafoos por que no los dos?",
  "id" : 563725047542468608,
  "in_reply_to_status_id" : 563724509312983040,
  "created_at" : "2015-02-06 15:44:59 +0000",
  "in_reply_to_screen_name" : "duh_nellll",
  "in_reply_to_user_id_str" : "146513248",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jenn",
      "screen_name" : "jennschiffer",
      "indices" : [ 40, 53 ],
      "id_str" : "12524622",
      "id" : 12524622
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/563718159102783488\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/1IZruRGB3k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9K6ramCEAEiK7e.png",
      "id_str" : "563718158410715137",
      "id" : 563718158410715137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9K6ramCEAEiK7e.png",
      "sizes" : [ {
        "h" : 737,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1250
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1IZruRGB3k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563718159102783488",
  "text" : "Someone please make this a reality (via @jennschiffer) http:\/\/t.co\/1IZruRGB3k",
  "id" : 563718159102783488,
  "created_at" : "2015-02-06 15:17:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563717801471266816",
  "text" : "I can't bring myself to listen to that. Just like it's weird to watch your own talks (unless practicing them). Agh!",
  "id" : 563717801471266816,
  "created_at" : "2015-02-06 15:16:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Dowell",
      "screen_name" : "CerebroJD",
      "indices" : [ 26, 36 ],
      "id_str" : "5744302",
      "id" : 5744302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/KLtGIIsjj2",
      "expanded_url" : "http:\/\/undertheskin.poweruser.tv\/",
      "display_url" : "undertheskin.poweruser.tv"
    } ]
  },
  "geo" : { },
  "id_str" : "563717575247265792",
  "text" : "Also I had a podcast with @CerebroJD nearly TEN YEARS AGO http:\/\/t.co\/KLtGIIsjj2 (Holy crap!!)",
  "id" : 563717575247265792,
  "created_at" : "2015-02-06 15:15:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/6XNcRDIc9u",
      "expanded_url" : "https:\/\/signalvnoise.com\/posts\/3849-easy-listening",
      "display_url" : "signalvnoise.com\/posts\/3849-eas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563714659048382466",
  "text" : "I think I need to start a podcast for Phish. Words aren't easy listening for me, but many others feel so! https:\/\/t.co\/6XNcRDIc9u",
  "id" : 563714659048382466,
  "created_at" : "2015-02-06 15:03:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allentown Assoc",
      "screen_name" : "allentownassoc",
      "indices" : [ 0, 15 ],
      "id_str" : "71396869",
      "id" : 71396869
    }, {
      "name" : "GBNRTC",
      "screen_name" : "GBNRTC",
      "indices" : [ 16, 23 ],
      "id_str" : "270903949",
      "id" : 270903949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558338816029646849",
  "geo" : { },
  "id_str" : "563713648686682112",
  "in_reply_to_user_id" : 71396869,
  "text" : "@allentownassoc @GBNRTC missing soap bubbles",
  "id" : 563713648686682112,
  "in_reply_to_status_id" : 558338816029646849,
  "created_at" : "2015-02-06 14:59:41 +0000",
  "in_reply_to_screen_name" : "allentownassoc",
  "in_reply_to_user_id_str" : "71396869",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/nfF9xT17fu",
      "expanded_url" : "http:\/\/motherboard.vice.com\/read\/to-fight-anonymous-opferguson-this-guy-is-harvesting-ip-addresses-for-the-cops?trk_source=recommended",
      "display_url" : "motherboard.vice.com\/read\/to-fight-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563700434653569024",
  "text" : "*slow blinks* http:\/\/t.co\/nfF9xT17fu",
  "id" : 563700434653569024,
  "created_at" : "2015-02-06 14:07:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Celtic Kazenzakis",
      "screen_name" : "CelticSteelNY",
      "indices" : [ 3, 17 ],
      "id_str" : "519830368",
      "id" : 519830368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/SCywYzUheD",
      "expanded_url" : "http:\/\/www.amazon.com\/gp\/product\/1466938897?tag=kinja-20&ascsubtag=[b%7Cobservationdeck[p%7C1659129577[a%7C1466938897[au%7C5724589697837272386",
      "display_url" : "amazon.com\/gp\/product\/146\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563681588974993408",
  "text" : "RT @CelticSteelNY: Are.\n\nYou.\n\nFucking.\n\nKidding,\n\nMe.\n\nhttp:\/\/t.co\/SCywYzUheD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/SCywYzUheD",
        "expanded_url" : "http:\/\/www.amazon.com\/gp\/product\/1466938897?tag=kinja-20&ascsubtag=[b%7Cobservationdeck[p%7C1659129577[a%7C1466938897[au%7C5724589697837272386",
        "display_url" : "amazon.com\/gp\/product\/146\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "563560854726410241",
    "text" : "Are.\n\nYou.\n\nFucking.\n\nKidding,\n\nMe.\n\nhttp:\/\/t.co\/SCywYzUheD",
    "id" : 563560854726410241,
    "created_at" : "2015-02-06 04:52:32 +0000",
    "user" : {
      "name" : "Celtic Kazenzakis",
      "screen_name" : "CelticSteelNY",
      "protected" : false,
      "id_str" : "519830368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569700269173116928\/7_BVvJOF_normal.jpeg",
      "id" : 519830368,
      "verified" : false
    }
  },
  "id" : 563681588974993408,
  "created_at" : "2015-02-06 12:52:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/GyF484RyJh",
      "expanded_url" : "http:\/\/gfycat.com\/EdiblePolishedKingsnake",
      "display_url" : "gfycat.com\/EdiblePolished\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9278717041, -78.8763275146 ]
  },
  "id_str" : "563526507998367745",
  "text" : "How some days have felt lately http:\/\/t.co\/GyF484RyJh (today was a lot better though!)",
  "id" : 563526507998367745,
  "created_at" : "2015-02-06 02:36:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "j. williams friedman",
      "screen_name" : "satellitehigh",
      "indices" : [ 3, 17 ],
      "id_str" : "8365442",
      "id" : 8365442
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/satellitehigh\/status\/562782764265897984\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/xWPsIWCGD9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B89n6WTIQAAMukm.png",
      "id_str" : "562782730560487424",
      "id" : 562782730560487424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B89n6WTIQAAMukm.png",
      "sizes" : [ {
        "h" : 314,
        "resize" : "fit",
        "w" : 478
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 478
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 478
      } ],
      "display_url" : "pic.twitter.com\/xWPsIWCGD9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563492485574721537",
  "text" : "RT @satellitehigh: holy shit, i've seen it, i've now seen the worst facebook ad of all time http:\/\/t.co\/xWPsIWCGD9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/satellitehigh\/status\/562782764265897984\/photo\/1",
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/xWPsIWCGD9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B89n6WTIQAAMukm.png",
        "id_str" : "562782730560487424",
        "id" : 562782730560487424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B89n6WTIQAAMukm.png",
        "sizes" : [ {
          "h" : 314,
          "resize" : "fit",
          "w" : 478
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 478
        }, {
          "h" : 223,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 478
        } ],
        "display_url" : "pic.twitter.com\/xWPsIWCGD9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562782764265897984",
    "text" : "holy shit, i've seen it, i've now seen the worst facebook ad of all time http:\/\/t.co\/xWPsIWCGD9",
    "id" : 562782764265897984,
    "created_at" : "2015-02-04 01:20:41 +0000",
    "user" : {
      "name" : "j. williams friedman",
      "screen_name" : "satellitehigh",
      "protected" : false,
      "id_str" : "8365442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573620856372359168\/-Hxzvzr8_normal.jpeg",
      "id" : 8365442,
      "verified" : false
    }
  },
  "id" : 563492485574721537,
  "created_at" : "2015-02-06 00:20:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563484286204903424",
  "geo" : { },
  "id_str" : "563485379060596737",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik I'd be curious to hear an ops perspective on this. Seems one sided",
  "id" : 563485379060596737,
  "in_reply_to_status_id" : 563484286204903424,
  "created_at" : "2015-02-05 23:52:38 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ninja Panda",
      "screen_name" : "lrnrd",
      "indices" : [ 3, 9 ],
      "id_str" : "324960013",
      "id" : 324960013
    }, {
      "name" : "Bears Acting Human",
      "screen_name" : "BearsActHuman",
      "indices" : [ 31, 45 ],
      "id_str" : "289182486",
      "id" : 289182486
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BearsActHuman\/status\/563367009237626881\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/SJFbseEo8u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9F7T11IYAAyruA.jpg",
      "id_str" : "563367009195679744",
      "id" : 563367009195679744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9F7T11IYAAyruA.jpg",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/SJFbseEo8u"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563485056153706498",
  "text" : "RT @lrnrd: git push --force RT @BearsActHuman http:\/\/t.co\/SJFbseEo8u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bears Acting Human",
        "screen_name" : "BearsActHuman",
        "indices" : [ 20, 34 ],
        "id_str" : "289182486",
        "id" : 289182486
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BearsActHuman\/status\/563367009237626881\/photo\/1",
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/SJFbseEo8u",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9F7T11IYAAyruA.jpg",
        "id_str" : "563367009195679744",
        "id" : 563367009195679744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9F7T11IYAAyruA.jpg",
        "sizes" : [ {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/SJFbseEo8u"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563369582388584448",
    "text" : "git push --force RT @BearsActHuman http:\/\/t.co\/SJFbseEo8u",
    "id" : 563369582388584448,
    "created_at" : "2015-02-05 16:12:29 +0000",
    "user" : {
      "name" : "Ninja Panda",
      "screen_name" : "lrnrd",
      "protected" : false,
      "id_str" : "324960013",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556893024353923073\/ji2T-mAY_normal.jpeg",
      "id" : 324960013,
      "verified" : false
    }
  },
  "id" : 563485056153706498,
  "created_at" : "2015-02-05 23:51:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#techismaterial",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563481121887764480",
  "geo" : { },
  "id_str" : "563482637374078977",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik how is that even comparable? One is a compiled language with binaries and the other is a 10 year old framework",
  "id" : 563482637374078977,
  "in_reply_to_status_id" : 563481121887764480,
  "created_at" : "2015-02-05 23:41:44 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563478749405253632",
  "text" : "2015 broken glass thing count: 2",
  "id" : 563478749405253632,
  "created_at" : "2015-02-05 23:26:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 3, 15 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whereslloyd\/status\/563405314784264192\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/WnzHTe0sZm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9GeJgwIIAA0y7w.jpg",
      "id_str" : "563405314645827584",
      "id" : 563405314645827584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9GeJgwIIAA0y7w.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/WnzHTe0sZm"
    } ],
    "hashtags" : [ {
      "text" : "RealFood",
      "indices" : [ 100, 109 ]
    }, {
      "text" : "Lloydspecials",
      "indices" : [ 110, 124 ]
    }, {
      "text" : "Yummers",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563406552716288003",
  "text" : "RT @whereslloyd: You thought we just did tacos?! HA!  Introducing Rocket Wings!  Get em this week!  #RealFood #Lloydspecials #Yummers http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/whereslloyd\/status\/563405314784264192\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/WnzHTe0sZm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9GeJgwIIAA0y7w.jpg",
        "id_str" : "563405314645827584",
        "id" : 563405314645827584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9GeJgwIIAA0y7w.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/WnzHTe0sZm"
      } ],
      "hashtags" : [ {
        "text" : "RealFood",
        "indices" : [ 83, 92 ]
      }, {
        "text" : "Lloydspecials",
        "indices" : [ 93, 107 ]
      }, {
        "text" : "Yummers",
        "indices" : [ 108, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563405314784264192",
    "text" : "You thought we just did tacos?! HA!  Introducing Rocket Wings!  Get em this week!  #RealFood #Lloydspecials #Yummers http:\/\/t.co\/WnzHTe0sZm",
    "id" : 563405314784264192,
    "created_at" : "2015-02-05 18:34:29 +0000",
    "user" : {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "protected" : false,
      "id_str" : "156689065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2323991179\/5aehi7jx6vjealgij9f0_normal.png",
      "id" : 156689065,
      "verified" : false
    }
  },
  "id" : 563406552716288003,
  "created_at" : "2015-02-05 18:39:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563323716520931328",
  "text" : "Introducing Apple In-Utero Purchases (IUP). We are so excited about this. 99\u00A2 for blue eyes. $1.99 for sleep through the night expansion.",
  "id" : 563323716520931328,
  "created_at" : "2015-02-05 13:10:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563180584047218688",
  "geo" : { },
  "id_str" : "563182209361010689",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw you are the law",
  "id" : 563182209361010689,
  "in_reply_to_status_id" : 563180584047218688,
  "created_at" : "2015-02-05 03:47:56 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/w5KtiqPpCz",
      "expanded_url" : "https:\/\/medium.com\/backchannel\/how-twitter-found-its-money-mojo-1d170e3df985",
      "display_url" : "medium.com\/backchannel\/ho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563152510375174146",
  "text" : "It is mindboggling and backwards to me to have a business that has to figure out a scheme how to make money https:\/\/t.co\/w5KtiqPpCz",
  "id" : 563152510375174146,
  "created_at" : "2015-02-05 01:49:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "indices" : [ 13, 17 ],
      "id_str" : "5523",
      "id" : 5523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563146340629098497",
  "geo" : { },
  "id_str" : "563147043045380097",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines @pat seriously what an amazing venue.",
  "id" : 563147043045380097,
  "in_reply_to_status_id" : 563146340629098497,
  "created_at" : "2015-02-05 01:28:12 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563142255276347392",
  "geo" : { },
  "id_str" : "563142335325028352",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam HaaS. I'll take VC money now plz",
  "id" : 563142335325028352,
  "in_reply_to_status_id" : 563142255276347392,
  "created_at" : "2015-02-05 01:09:30 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve             ",
      "screen_name" : "stevejt",
      "indices" : [ 0, 8 ],
      "id_str" : "14056329",
      "id" : 14056329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563138810884534272",
  "geo" : { },
  "id_str" : "563142204307566592",
  "in_reply_to_user_id" : 14056329,
  "text" : "@stevejt Yeah could use one of those. I need to get a husky sled attachment.",
  "id" : 563142204307566592,
  "in_reply_to_status_id" : 563138810884534272,
  "created_at" : "2015-02-05 01:08:58 +0000",
  "in_reply_to_screen_name" : "stevejt",
  "in_reply_to_user_id_str" : "14056329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate West",
      "screen_name" : "nate_west",
      "indices" : [ 0, 10 ],
      "id_str" : "942661",
      "id" : 942661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563138846884257792",
  "geo" : { },
  "id_str" : "563142097851940865",
  "in_reply_to_user_id" : 942661,
  "text" : "@nate_west That's no blizzard. Just a normal storm :)",
  "id" : 563142097851940865,
  "in_reply_to_status_id" : 563138846884257792,
  "created_at" : "2015-02-05 01:08:33 +0000",
  "in_reply_to_screen_name" : "nate_west",
  "in_reply_to_user_id_str" : "942661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563137622743449600",
  "text" : "In related news I need a new shovel since I totally fucked mine up trying to get ice off of one. Should have used my spade...",
  "id" : 563137622743449600,
  "created_at" : "2015-02-05 00:50:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563137480976003072",
  "text" : "BTW that was one of 3 hydrants that I clear out on my block. Clear. Your. Hydrants.",
  "id" : 563137480976003072,
  "created_at" : "2015-02-05 00:50:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/563135190122651648\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/6dhlwg4SPB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9CoYDYIUAAe1Ys.jpg",
      "id_str" : "563135084598153216",
      "id" : 563135084598153216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9CoYDYIUAAe1Ys.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6dhlwg4SPB"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/563135190122651648\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/6dhlwg4SPB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9CoawcCUAA92Mm.jpg",
      "id_str" : "563135131053871104",
      "id" : 563135131053871104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9CoawcCUAA92Mm.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6dhlwg4SPB"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/563135190122651648\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/6dhlwg4SPB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9Codg6IUAAcaIb.jpg",
      "id_str" : "563135178424733696",
      "id" : 563135178424733696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9Codg6IUAAcaIb.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6dhlwg4SPB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563135190122651648",
  "text" : "City of Buffalo residents and elsewhere: please clear your fire hydrants. Your firefighters will thank you. http:\/\/t.co\/6dhlwg4SPB",
  "id" : 563135190122651648,
  "created_at" : "2015-02-05 00:41:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 0, 14 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563095134032900097",
  "geo" : { },
  "id_str" : "563095675198779394",
  "in_reply_to_user_id" : 5896952,
  "text" : "@BuffaloRising Godwin's Law in action",
  "id" : 563095675198779394,
  "in_reply_to_status_id" : 563095134032900097,
  "created_at" : "2015-02-04 22:04:05 +0000",
  "in_reply_to_screen_name" : "BuffaloRising",
  "in_reply_to_user_id_str" : "5896952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Jeong",
      "screen_name" : "sarahjeong",
      "indices" : [ 3, 14 ],
      "id_str" : "47509268",
      "id" : 47509268
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SilkRoadTrial",
      "indices" : [ 39, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563080875689402369",
  "text" : "RT @sarahjeong: Guilty on all counts.  #SilkRoadTrial",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SilkRoadTrial",
        "indices" : [ 23, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563079508837027842",
    "text" : "Guilty on all counts.  #SilkRoadTrial",
    "id" : 563079508837027842,
    "created_at" : "2015-02-04 20:59:51 +0000",
    "user" : {
      "name" : "Sarah Jeong",
      "screen_name" : "sarahjeong",
      "protected" : false,
      "id_str" : "47509268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544692642794053632\/eFqYMyeO_normal.jpeg",
      "id" : 47509268,
      "verified" : false
    }
  },
  "id" : 563080875689402369,
  "created_at" : "2015-02-04 21:05:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane V.",
      "screen_name" : "shanev",
      "indices" : [ 0, 7 ],
      "id_str" : "6068692",
      "id" : 6068692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563066840424120322",
  "geo" : { },
  "id_str" : "563067675782680576",
  "in_reply_to_user_id" : 6068692,
  "text" : "@shanev this is getting off topic but it's hilarious that MS is more open and transparent than Apple is. Not a good sign. Not at all.",
  "id" : 563067675782680576,
  "in_reply_to_status_id" : 563066840424120322,
  "created_at" : "2015-02-04 20:12:49 +0000",
  "in_reply_to_screen_name" : "shanev",
  "in_reply_to_user_id_str" : "6068692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane V.",
      "screen_name" : "shanev",
      "indices" : [ 0, 7 ],
      "id_str" : "6068692",
      "id" : 6068692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563062737845366785",
  "geo" : { },
  "id_str" : "563066139933421569",
  "in_reply_to_user_id" : 6068692,
  "text" : "@shanev I think i'd rather write my bug report on a message and toss it in a bottle over the ocean than open a radar",
  "id" : 563066139933421569,
  "in_reply_to_status_id" : 563062737845366785,
  "created_at" : "2015-02-04 20:06:43 +0000",
  "in_reply_to_screen_name" : "shanev",
  "in_reply_to_user_id_str" : "6068692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane V.",
      "screen_name" : "shanev",
      "indices" : [ 0, 7 ],
      "id_str" : "6068692",
      "id" : 6068692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563062737845366785",
  "geo" : { },
  "id_str" : "563065936908152835",
  "in_reply_to_user_id" : 6068692,
  "text" : "@shanev i don't find Apple's completely opaque bug reporting process to be helpful or useful at all",
  "id" : 563065936908152835,
  "in_reply_to_status_id" : 563062737845366785,
  "created_at" : "2015-02-04 20:05:55 +0000",
  "in_reply_to_screen_name" : "shanev",
  "in_reply_to_user_id_str" : "6068692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane V.",
      "screen_name" : "shanev",
      "indices" : [ 0, 7 ],
      "id_str" : "6068692",
      "id" : 6068692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563060358454472706",
  "geo" : { },
  "id_str" : "563062409460715521",
  "in_reply_to_user_id" : 6068692,
  "text" : "@shanev here's a good example. download the AdaptivePhotosAnAdaptiveApplication sample code and swap the display mode to that. rotate.",
  "id" : 563062409460715521,
  "in_reply_to_status_id" : 563060358454472706,
  "created_at" : "2015-02-04 19:51:54 +0000",
  "in_reply_to_screen_name" : "shanev",
  "in_reply_to_user_id_str" : "6068692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane V.",
      "screen_name" : "shanev",
      "indices" : [ 0, 7 ],
      "id_str" : "6068692",
      "id" : 6068692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563060358454472706",
  "geo" : { },
  "id_str" : "563060655134355456",
  "in_reply_to_user_id" : 6068692,
  "text" : "@shanev basically, .PrimaryOverlay is very broken and doesn't work at all. In fact anything but Automatic seems broken.",
  "id" : 563060655134355456,
  "in_reply_to_status_id" : 563060358454472706,
  "created_at" : "2015-02-04 19:44:56 +0000",
  "in_reply_to_screen_name" : "shanev",
  "in_reply_to_user_id_str" : "6068692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane V.",
      "screen_name" : "shanev",
      "indices" : [ 0, 7 ],
      "id_str" : "6068692",
      "id" : 6068692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563058453279932420",
  "geo" : { },
  "id_str" : "563058773766701056",
  "in_reply_to_user_id" : 6068692,
  "text" : "@shanev it does not seem worth it. it seems created for one simple purpose and deviating from that is impossible.",
  "id" : 563058773766701056,
  "in_reply_to_status_id" : 563058453279932420,
  "created_at" : "2015-02-04 19:37:27 +0000",
  "in_reply_to_screen_name" : "shanev",
  "in_reply_to_user_id_str" : "6068692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Jackson",
      "screen_name" : "_JeffreyJackson",
      "indices" : [ 0, 16 ],
      "id_str" : "392460916",
      "id" : 392460916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563054438760607744",
  "geo" : { },
  "id_str" : "563054796698316800",
  "in_reply_to_user_id" : 392460916,
  "text" : "@_JeffreyJackson Bullshit.",
  "id" : 563054796698316800,
  "in_reply_to_status_id" : 563054438760607744,
  "created_at" : "2015-02-04 19:21:39 +0000",
  "in_reply_to_screen_name" : "_JeffreyJackson",
  "in_reply_to_user_id_str" : "392460916",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563054027114831874",
  "text" : "I'm convinced Apple has not used UISplitViewController in production apps and created it out of pure thoughtstuff.",
  "id" : 563054027114831874,
  "created_at" : "2015-02-04 19:18:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563018565981569024",
  "geo" : { },
  "id_str" : "563019016999288832",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz meesa no likey",
  "id" : 563019016999288832,
  "in_reply_to_status_id" : 563018565981569024,
  "created_at" : "2015-02-04 16:59:28 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric S",
      "screen_name" : "MutualArising",
      "indices" : [ 0, 14 ],
      "id_str" : "15913837",
      "id" : 15913837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563009668227039233",
  "geo" : { },
  "id_str" : "563012377206349824",
  "in_reply_to_user_id" : 15913837,
  "text" : "@MutualArising awesome. it's funny to hear them criticize themselves in Bittersweet about this first set. It's wonderful.",
  "id" : 563012377206349824,
  "in_reply_to_status_id" : 563009668227039233,
  "created_at" : "2015-02-04 16:33:05 +0000",
  "in_reply_to_screen_name" : "MutualArising",
  "in_reply_to_user_id_str" : "15913837",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    }, {
      "name" : "Andy Lindeman",
      "screen_name" : "alindeman",
      "indices" : [ 9, 19 ],
      "id_str" : "13235612",
      "id" : 13235612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563010244344020994",
  "geo" : { },
  "id_str" : "563011018088280066",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle @alindeman I don't get the feeling it is. I don't think enough have experienced it to know how it can work, or why it matters.",
  "id" : 563011018088280066,
  "in_reply_to_status_id" : 563010244344020994,
  "created_at" : "2015-02-04 16:27:41 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Altano",
      "screen_name" : "agentbizzle",
      "indices" : [ 0, 12 ],
      "id_str" : "30900841",
      "id" : 30900841
    }, {
      "name" : "ghouls, buddy!",
      "screen_name" : "AaronM",
      "indices" : [ 13, 20 ],
      "id_str" : "9194742",
      "id" : 9194742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563001040426250243",
  "geo" : { },
  "id_str" : "563009991435902978",
  "in_reply_to_user_id" : 30900841,
  "text" : "@agentbizzle @AaronM oh no!!!! i need to cash in",
  "id" : 563009991435902978,
  "in_reply_to_status_id" : 563001040426250243,
  "created_at" : "2015-02-04 16:23:36 +0000",
  "in_reply_to_screen_name" : "agentbizzle",
  "in_reply_to_user_id_str" : "30900841",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562975146282352640",
  "geo" : { },
  "id_str" : "563009586698149888",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps run through my 325 likes. if you haven't laughed i need a new hobby",
  "id" : 563009586698149888,
  "in_reply_to_status_id" : 562975146282352640,
  "created_at" : "2015-02-04 16:22:00 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/13JWiQMwmM",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=5JtTA7lc86o",
      "display_url" : "youtube.com\/watch?v=5JtTA7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563008746834907136",
  "text" : "Buckle up, it's Great Went time. https:\/\/t.co\/13JWiQMwmM",
  "id" : 563008746834907136,
  "created_at" : "2015-02-04 16:18:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/tAnQGiaeko",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=H6otmy3DAK8",
      "display_url" : "youtube.com\/watch?v=H6otmy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563007997803495424",
  "text" : "It's great to see a musician for nearly 50 years still have a great sense of humor https:\/\/t.co\/tAnQGiaeko",
  "id" : 563007997803495424,
  "created_at" : "2015-02-04 16:15:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/563000516763201539\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/O9QlCrX8Ap",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9At_HEIAAEJlRR.jpg",
      "id_str" : "563000515672670209",
      "id" : 563000515672670209,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9At_HEIAAEJlRR.jpg",
      "sizes" : [ {
        "h" : 1402,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1402,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 934,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/O9QlCrX8Ap"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/G1kdcdXOOY",
      "expanded_url" : "http:\/\/www.dailypublic.com\/articles\/02032015\/pat-kewley-living-kongs",
      "display_url" : "dailypublic.com\/articles\/02032\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563000516763201539",
  "text" : "\"[I] still have enough to go out for fresh human sacrifices with my friends every week\" via http:\/\/t.co\/G1kdcdXOOY http:\/\/t.co\/O9QlCrX8Ap",
  "id" : 563000516763201539,
  "created_at" : "2015-02-04 15:45:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Arthur",
      "screen_name" : "truist",
      "indices" : [ 0, 7 ],
      "id_str" : "14653444",
      "id" : 14653444
    }, {
      "name" : "Michael Letterle",
      "screen_name" : "mletterle",
      "indices" : [ 8, 18 ],
      "id_str" : "458173",
      "id" : 458173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562847892587945984",
  "geo" : { },
  "id_str" : "562982219820843008",
  "in_reply_to_user_id" : 14653444,
  "text" : "@truist @mletterle never noticed the symbols on the sides of drums before. wild.",
  "id" : 562982219820843008,
  "in_reply_to_status_id" : 562847892587945984,
  "created_at" : "2015-02-04 14:33:15 +0000",
  "in_reply_to_screen_name" : "truist",
  "in_reply_to_user_id_str" : "14653444",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 0, 11 ],
      "id_str" : "67117740",
      "id" : 67117740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562975685791465473",
  "geo" : { },
  "id_str" : "562978929754255361",
  "in_reply_to_user_id" : 67117740,
  "text" : "@Dianna_2Ns one day...",
  "id" : 562978929754255361,
  "in_reply_to_status_id" : 562975685791465473,
  "created_at" : "2015-02-04 14:20:11 +0000",
  "in_reply_to_screen_name" : "Dianna_2Ns",
  "in_reply_to_user_id_str" : "67117740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562852848468512768",
  "text" : "Bittersweet Motel popped up as a recommended video, and now hello 1am. \uD83D\uDE2C",
  "id" : 562852848468512768,
  "created_at" : "2015-02-04 05:59:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 18, 26 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562851839587401728",
  "geo" : { },
  "id_str" : "562852668889366530",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza meet @mperham, I'm sure he could talk about it",
  "id" : 562852668889366530,
  "in_reply_to_status_id" : 562851839587401728,
  "created_at" : "2015-02-04 05:58:28 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Breaking News Feed",
      "screen_name" : "PzFeed",
      "indices" : [ 3, 10 ],
      "id_str" : "292777349",
      "id" : 292777349
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/sokane1\/status\/562829917248028672\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/tR7BXX0FQy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8-SyvQIEAE7vZi.png",
      "id_str" : "562829878819819521",
      "id" : 562829878819819521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8-SyvQIEAE7vZi.png",
      "sizes" : [ {
        "h" : 1480,
        "resize" : "fit",
        "w" : 1860
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 814,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tR7BXX0FQy"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/sokane1\/status\/562829917248028672\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/tR7BXX0FQy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8-S05uIYAAosgS.png",
      "id_str" : "562829915989762048",
      "id" : 562829915989762048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8-S05uIYAAosgS.png",
      "sizes" : [ {
        "h" : 346,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1444,
        "resize" : "fit",
        "w" : 1418
      }, {
        "h" : 1042,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/tR7BXX0FQy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562837579796860928",
  "text" : "RT @PzFeed: BREAKING PHOTOS: The wing of TransAsia GE235 clipped a taxi cab on the highway. (TVBS) http:\/\/t.co\/tR7BXX0FQy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/sokane1\/status\/562829917248028672\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/tR7BXX0FQy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8-SyvQIEAE7vZi.png",
        "id_str" : "562829878819819521",
        "id" : 562829878819819521,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8-SyvQIEAE7vZi.png",
        "sizes" : [ {
          "h" : 1480,
          "resize" : "fit",
          "w" : 1860
        }, {
          "h" : 477,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 814,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tR7BXX0FQy"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/sokane1\/status\/562829917248028672\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/tR7BXX0FQy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8-S05uIYAAosgS.png",
        "id_str" : "562829915989762048",
        "id" : 562829915989762048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8-S05uIYAAosgS.png",
        "sizes" : [ {
          "h" : 346,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1444,
          "resize" : "fit",
          "w" : 1418
        }, {
          "h" : 1042,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 611,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/tR7BXX0FQy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562832274434322433",
    "text" : "BREAKING PHOTOS: The wing of TransAsia GE235 clipped a taxi cab on the highway. (TVBS) http:\/\/t.co\/tR7BXX0FQy",
    "id" : 562832274434322433,
    "created_at" : "2015-02-04 04:37:25 +0000",
    "user" : {
      "name" : "Breaking News Feed",
      "screen_name" : "PzFeed",
      "protected" : false,
      "id_str" : "292777349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527514489919262721\/QKC5oMPD_normal.jpeg",
      "id" : 292777349,
      "verified" : false
    }
  },
  "id" : 562837579796860928,
  "created_at" : "2015-02-04 04:58:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562834884226715648",
  "geo" : { },
  "id_str" : "562835163676430337",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss thanks, now i only have one more question to ask an apple dev",
  "id" : 562835163676430337,
  "in_reply_to_status_id" : 562834884226715648,
  "created_at" : "2015-02-04 04:48:54 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562833677013770240",
  "geo" : { },
  "id_str" : "562833843447934977",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik yeah that looks redonk",
  "id" : 562833843447934977,
  "in_reply_to_status_id" : 562833677013770240,
  "created_at" : "2015-02-04 04:43:39 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J. Austin Hughey",
      "screen_name" : "jaustinhughey",
      "indices" : [ 0, 14 ],
      "id_str" : "72242732",
      "id" : 72242732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/OfeAC9gW3a",
      "expanded_url" : "https:\/\/twitter.com\/thatjohn\/status\/562824564519227393",
      "display_url" : "twitter.com\/thatjohn\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "562833153468141568",
  "geo" : { },
  "id_str" : "562833259839881217",
  "in_reply_to_user_id" : 72242732,
  "text" : "@jaustinhughey https:\/\/t.co\/OfeAC9gW3a",
  "id" : 562833259839881217,
  "in_reply_to_status_id" : 562833153468141568,
  "created_at" : "2015-02-04 04:41:20 +0000",
  "in_reply_to_screen_name" : "jaustinhughey",
  "in_reply_to_user_id_str" : "72242732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562832957954854914",
  "text" : "So yeah, anyone taken the Amtrak to Chicago? Is it impossible to sleep in the seats?",
  "id" : 562832957954854914,
  "created_at" : "2015-02-04 04:40:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562825188585537536",
  "text" : "Yep I fucking hate flying",
  "id" : 562825188585537536,
  "created_at" : "2015-02-04 04:09:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Sandora-Nastyn",
      "screen_name" : "PatSandora",
      "indices" : [ 0, 11 ],
      "id_str" : "21421691",
      "id" : 21421691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562817052520747009",
  "geo" : { },
  "id_str" : "562817265834659841",
  "in_reply_to_user_id" : 21421691,
  "text" : "@PatSandora missed slo motion opportunity",
  "id" : 562817265834659841,
  "in_reply_to_status_id" : 562817052520747009,
  "created_at" : "2015-02-04 03:37:47 +0000",
  "in_reply_to_screen_name" : "PatSandora",
  "in_reply_to_user_id_str" : "21421691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 12, 25 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562802094315667459",
  "geo" : { },
  "id_str" : "562803419241795584",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @steveklabnik (with 380 attachments of husky dog photos)",
  "id" : 562803419241795584,
  "in_reply_to_status_id" : 562802094315667459,
  "created_at" : "2015-02-04 02:42:46 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "auntie moon",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 12, 25 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562802094315667459",
  "geo" : { },
  "id_str" : "562803367488286721",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @steveklabnik *sends 380 emails to both of you*",
  "id" : 562803367488286721,
  "in_reply_to_status_id" : 562802094315667459,
  "created_at" : "2015-02-04 02:42:33 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 0, 14 ],
      "id_str" : "16930130",
      "id" : 16930130
    }, {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 15, 21 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562798494361350144",
  "geo" : { },
  "id_str" : "562799155060695040",
  "in_reply_to_user_id" : 16930130,
  "text" : "@PhilDarnowsky @nzkoz yeah. and if you let it sit, it ices over and then basically you can't get rid of it unless you hit it with a shovel",
  "id" : 562799155060695040,
  "in_reply_to_status_id" : 562798494361350144,
  "created_at" : "2015-02-04 02:25:49 +0000",
  "in_reply_to_screen_name" : "PhilDarnowsky",
  "in_reply_to_user_id_str" : "16930130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562792155262255105",
  "geo" : { },
  "id_str" : "562792538017640448",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel did you watch the video? the astral run is just harrowing to watch",
  "id" : 562792538017640448,
  "in_reply_to_status_id" : 562792155262255105,
  "created_at" : "2015-02-04 01:59:31 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/hmgHcUTntl",
      "expanded_url" : "https:\/\/medium.com\/message\/stupid-tricks-with-promoted-tweets-57325552109d",
      "display_url" : "medium.com\/message\/stupid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562791204644192256",
  "text" : "Twitter is getting fucking stupid. https:\/\/t.co\/hmgHcUTntl",
  "id" : 562791204644192256,
  "created_at" : "2015-02-04 01:54:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "indices" : [ 3, 8 ],
      "id_str" : "12534",
      "id" : 12534
    }, {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 13, 24 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/QcHlhgKei3",
      "expanded_url" : "https:\/\/medium.com\/message\/stupid-tricks-with-promoted-tweets-57325552109d",
      "display_url" : "medium.com\/message\/stupid\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/gm0GfN2OGm",
      "expanded_url" : "http:\/\/cl.ly\/image\/0d0g1B0s2i3j",
      "display_url" : "cl.ly\/image\/0d0g1B0s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562791023324446721",
  "text" : "RT @beep: So @waxpancake\u2019s the hero that Twitter needs. Or deserves. However the saying goes https:\/\/t.co\/QcHlhgKei3 is great.\n\nhttp:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Baio",
        "screen_name" : "waxpancake",
        "indices" : [ 3, 14 ],
        "id_str" : "13461",
        "id" : 13461
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/QcHlhgKei3",
        "expanded_url" : "https:\/\/medium.com\/message\/stupid-tricks-with-promoted-tweets-57325552109d",
        "display_url" : "medium.com\/message\/stupid\u2026"
      }, {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/gm0GfN2OGm",
        "expanded_url" : "http:\/\/cl.ly\/image\/0d0g1B0s2i3j",
        "display_url" : "cl.ly\/image\/0d0g1B0s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "562790705241022465",
    "text" : "So @waxpancake\u2019s the hero that Twitter needs. Or deserves. However the saying goes https:\/\/t.co\/QcHlhgKei3 is great.\n\nhttp:\/\/t.co\/gm0GfN2OGm",
    "id" : 562790705241022465,
    "created_at" : "2015-02-04 01:52:14 +0000",
    "user" : {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "protected" : false,
      "id_str" : "12534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561270834401382400\/AJ669BlB_normal.png",
      "id" : 12534,
      "verified" : false
    }
  },
  "id" : 562791023324446721,
  "created_at" : "2015-02-04 01:53:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Yun",
      "screen_name" : "dougyun",
      "indices" : [ 0, 8 ],
      "id_str" : "324160285",
      "id" : 324160285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562780186085974016",
  "geo" : { },
  "id_str" : "562780449551159298",
  "in_reply_to_user_id" : 324160285,
  "text" : "@dougyun have wished for a blessed +2 fireproof shirt many times. it's the best for pumping up AC",
  "id" : 562780449551159298,
  "in_reply_to_status_id" : 562780186085974016,
  "created_at" : "2015-02-04 01:11:29 +0000",
  "in_reply_to_screen_name" : "dougyun",
  "in_reply_to_user_id_str" : "324160285",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562765766345650179",
  "text" : "Curious how much Amazon and Hulu's traffic spikes when Netflix goes down. Crank those dynos.",
  "id" : 562765766345650179,
  "created_at" : "2015-02-04 00:13:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/562761327119454209\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/UXbC7mSxKa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B89Ucd2IgAAkxrg.png",
      "id_str" : "562761326469349376",
      "id" : 562761326469349376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B89Ucd2IgAAkxrg.png",
      "sizes" : [ {
        "h" : 102,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 848
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 848
      } ],
      "display_url" : "pic.twitter.com\/UXbC7mSxKa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562761327119454209",
  "text" : "\"You can begin using Swift code immediately\" but don't try to refactor it. That would be too much. http:\/\/t.co\/UXbC7mSxKa",
  "id" : 562761327119454209,
  "created_at" : "2015-02-03 23:55:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562716035242283009",
  "text" : "Also GG to the snow plowers that left 2-3' of a snow trench on the block next of me for cars to trudge through",
  "id" : 562716035242283009,
  "created_at" : "2015-02-03 20:55:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562715738403004418",
  "text" : "A beer distribution truck blocking the right lane at Grant &amp; Potomac was causing major safety issues. Fuck that truck.",
  "id" : 562715738403004418,
  "created_at" : "2015-02-03 20:54:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562711656908984320",
  "text" : "School buses forced to take the entire lane up and plenty of people walking in the street. What is this?",
  "id" : 562711656908984320,
  "created_at" : "2015-02-03 20:38:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562711226296598528",
  "text" : "Grant St and its side streets are barely plowed and this is an embarrassment for the city.",
  "id" : 562711226296598528,
  "created_at" : "2015-02-03 20:36:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 25, 37 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "The 8x10",
      "screen_name" : "The8x10",
      "indices" : [ 55, 63 ],
      "id_str" : "37769792",
      "id" : 37769792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/v7HoiMLk9L",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?feature=youtu.be&v=_S9u1E81tvo&app=desktop",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562679258255216641",
  "text" : "New and wonderfully shot @AqueousBand video from their @the8x10 set (and becoming my favorite song too): https:\/\/t.co\/v7HoiMLk9L",
  "id" : 562679258255216641,
  "created_at" : "2015-02-03 18:29:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    }, {
      "name" : "Samantha Nephew",
      "screen_name" : "snephew25",
      "indices" : [ 16, 26 ],
      "id_str" : "125562735",
      "id" : 125562735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562670651522420736",
  "geo" : { },
  "id_str" : "562670815049969665",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc @snephew25 also it is terrifying to see their (mostly full-size) salter\/plow trucks roll by our windows, inches from them",
  "id" : 562670815049969665,
  "in_reply_to_status_id" : 562670651522420736,
  "created_at" : "2015-02-03 17:55:50 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Nephew",
      "screen_name" : "snephew25",
      "indices" : [ 0, 10 ],
      "id_str" : "125562735",
      "id" : 125562735
    }, {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 11, 26 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562668638562709504",
  "geo" : { },
  "id_str" : "562669892336648192",
  "in_reply_to_user_id" : 125562735,
  "text" : "@snephew25 @ChristineLSloc because buffalo place has their own snowplowing force. also you walked by us!",
  "id" : 562669892336648192,
  "in_reply_to_status_id" : 562668638562709504,
  "created_at" : "2015-02-03 17:52:10 +0000",
  "in_reply_to_screen_name" : "snephew25",
  "in_reply_to_user_id_str" : "125562735",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562636779761967104",
  "text" : "Because of the incredible speed of your rocket",
  "id" : 562636779761967104,
  "created_at" : "2015-02-03 15:40:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/562636204911636481\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/GTdAeWryXZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B87ipU3CQAIR405.jpg",
      "id_str" : "562636203069947906",
      "id" : 562636203069947906,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B87ipU3CQAIR405.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/GTdAeWryXZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562636204911636481",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt won several of these at the county fair dime toss. Traded glasses for even more with the toothless attendant http:\/\/t.co\/GTdAeWryXZ",
  "id" : 562636204911636481,
  "created_at" : "2015-02-03 15:38:19 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 32, 46 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562494632819691520",
  "geo" : { },
  "id_str" : "562633716129075200",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt our mug life is on point @coworkbuffalo. my favorite: the #1 dad mug which we give to whoever cleans the most on that day",
  "id" : 562633716129075200,
  "in_reply_to_status_id" : 562494632819691520,
  "created_at" : "2015-02-03 15:28:25 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Jeong",
      "screen_name" : "sarahjeong",
      "indices" : [ 3, 14 ],
      "id_str" : "47509268",
      "id" : 47509268
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/sarahjeong\/status\/562596510144020480\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/PQuNd1BVZJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B86qkzBCYAIrLM5.jpg",
      "id_str" : "562574552614461442",
      "id" : 562574552614461442,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B86qkzBCYAIrLM5.jpg",
      "sizes" : [ {
        "h" : 1489,
        "resize" : "fit",
        "w" : 2023
      }, {
        "h" : 753,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 441,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/PQuNd1BVZJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/UHtRlsAnbw",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/sarahjeong\/2015\/02\/03\/the-silk-road-trial-that-wasnt\/",
      "display_url" : "forbes.com\/sites\/sarahjeo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562601586333986816",
  "text" : "RT @sarahjeong: How Ross Ulbricht's Defense Was Derailed http:\/\/t.co\/UHtRlsAnbw http:\/\/t.co\/PQuNd1BVZJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/sarahjeong\/status\/562596510144020480\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/PQuNd1BVZJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B86qkzBCYAIrLM5.jpg",
        "id_str" : "562574552614461442",
        "id" : 562574552614461442,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B86qkzBCYAIrLM5.jpg",
        "sizes" : [ {
          "h" : 1489,
          "resize" : "fit",
          "w" : 2023
        }, {
          "h" : 753,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 441,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/PQuNd1BVZJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/UHtRlsAnbw",
        "expanded_url" : "http:\/\/www.forbes.com\/sites\/sarahjeong\/2015\/02\/03\/the-silk-road-trial-that-wasnt\/",
        "display_url" : "forbes.com\/sites\/sarahjeo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "562596510144020480",
    "text" : "How Ross Ulbricht's Defense Was Derailed http:\/\/t.co\/UHtRlsAnbw http:\/\/t.co\/PQuNd1BVZJ",
    "id" : 562596510144020480,
    "created_at" : "2015-02-03 13:00:35 +0000",
    "user" : {
      "name" : "Sarah Jeong",
      "screen_name" : "sarahjeong",
      "protected" : false,
      "id_str" : "47509268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544692642794053632\/eFqYMyeO_normal.jpeg",
      "id" : 47509268,
      "verified" : false
    }
  },
  "id" : 562601586333986816,
  "created_at" : "2015-02-03 13:20:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562450843065008128",
  "text" : "I hate days when you have to claw and dig for progress and barely any is made. And then other days, you can jump over any hurdle.",
  "id" : 562450843065008128,
  "created_at" : "2015-02-03 03:21:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562417269599260672",
  "text" : "Phish White Tape tonight. Not sure why I'm feeling into it.",
  "id" : 562417269599260672,
  "created_at" : "2015-02-03 01:08:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    }, {
      "name" : "Ryan Nagelhout",
      "screen_name" : "goosesroost",
      "indices" : [ 10, 22 ],
      "id_str" : "21283898",
      "id" : 21283898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562396800494354432",
  "geo" : { },
  "id_str" : "562398264436088832",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos @goosesroost the point was the bug",
  "id" : 562398264436088832,
  "in_reply_to_status_id" : 562396800494354432,
  "created_at" : "2015-02-02 23:52:49 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pamela marie",
      "screen_name" : "pwnela",
      "indices" : [ 0, 7 ],
      "id_str" : "40960018",
      "id" : 40960018
    }, {
      "name" : "Russ Andolina",
      "screen_name" : "rjandolina",
      "indices" : [ 8, 19 ],
      "id_str" : "155655826",
      "id" : 155655826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562394921286795265",
  "geo" : { },
  "id_str" : "562395005038247936",
  "in_reply_to_user_id" : 40960018,
  "text" : "@pwnela @rjandolina this was more meant as a poke at the company which does not pay attention to bugs on its web UI",
  "id" : 562395005038247936,
  "in_reply_to_status_id" : 562394921286795265,
  "created_at" : "2015-02-02 23:39:52 +0000",
  "in_reply_to_screen_name" : "pwnela",
  "in_reply_to_user_id_str" : "40960018",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 34, 42 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/562394280900046848\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/UZYnjZmcIY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B84Gnj7CEAA48F2.png",
      "id_str" : "562394280195395584",
      "id" : 562394280195395584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B84Gnj7CEAA48F2.png",
      "sizes" : [ {
        "h" : 137,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 492,
        "resize" : "fit",
        "w" : 1214
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UZYnjZmcIY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562394280900046848",
  "text" : "does anyone use the web interface @twitter http:\/\/t.co\/UZYnjZmcIY",
  "id" : 562394280900046848,
  "created_at" : "2015-02-02 23:37:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sgt. John J. Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 3, 18 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562389345504477184",
  "text" : "RT @gabrielgironda: *attenborough voice* The Millennial must spend 3 to 4 hours a day basking in 680nm wavelength light in order to maintai\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "562388922399850496",
    "geo" : { },
    "id_str" : "562389254081241088",
    "in_reply_to_user_id" : 267895957,
    "text" : "*attenborough voice* The Millennial must spend 3 to 4 hours a day basking in 680nm wavelength light in order to maintain its glossy sheen.",
    "id" : 562389254081241088,
    "in_reply_to_status_id" : 562388922399850496,
    "created_at" : "2015-02-02 23:17:01 +0000",
    "in_reply_to_screen_name" : "gabrielgironda",
    "in_reply_to_user_id_str" : "267895957",
    "user" : {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "protected" : true,
      "id_str" : "267895957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560982536772259840\/0R0rl2ao_normal.jpeg",
      "id" : 267895957,
      "verified" : false
    }
  },
  "id" : 562389345504477184,
  "created_at" : "2015-02-02 23:17:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Aurora",
      "screen_name" : "vaurorapub",
      "indices" : [ 3, 14 ],
      "id_str" : "2339814156",
      "id" : 2339814156
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vaurorapub\/status\/562334351799500800\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/rtAWGT7J1N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B83QHP2CcAEf1OD.png",
      "id_str" : "562334351422025729",
      "id" : 562334351422025729,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B83QHP2CcAEf1OD.png",
      "sizes" : [ {
        "h" : 130,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 594
      } ],
      "display_url" : "pic.twitter.com\/rtAWGT7J1N"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562336356274159616",
  "text" : "RT @vaurorapub: Silicon Valley, I present to you: one of your role models http:\/\/t.co\/rtAWGT7J1N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vaurorapub\/status\/562334351799500800\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/rtAWGT7J1N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B83QHP2CcAEf1OD.png",
        "id_str" : "562334351422025729",
        "id" : 562334351422025729,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B83QHP2CcAEf1OD.png",
        "sizes" : [ {
          "h" : 130,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 594
        } ],
        "display_url" : "pic.twitter.com\/rtAWGT7J1N"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562334351799500800",
    "text" : "Silicon Valley, I present to you: one of your role models http:\/\/t.co\/rtAWGT7J1N",
    "id" : 562334351799500800,
    "created_at" : "2015-02-02 19:38:51 +0000",
    "user" : {
      "name" : "Valerie Aurora",
      "screen_name" : "vaurorapub",
      "protected" : false,
      "id_str" : "2339814156",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566795670200147970\/DeKC5hmZ_normal.jpeg",
      "id" : 2339814156,
      "verified" : false
    }
  },
  "id" : 562336356274159616,
  "created_at" : "2015-02-02 19:46:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/BxxmbiAgAH",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/nethack\/comments\/2tluxv\/yaap_fullauto_bot_ascension_bothack",
      "display_url" : "reddit.com\/r\/nethack\/comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562335448563855362",
  "text" : "First NetHack bot ascension. Wow. http:\/\/t.co\/BxxmbiAgAH",
  "id" : 562335448563855362,
  "created_at" : "2015-02-02 19:43:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Miller",
      "screen_name" : "bobprime",
      "indices" : [ 0, 9 ],
      "id_str" : "15837392",
      "id" : 15837392
    }, {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "indices" : [ 10, 23 ],
      "id_str" : "9154112",
      "id" : 9154112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562323762587377664",
  "geo" : { },
  "id_str" : "562324375550967808",
  "in_reply_to_user_id" : 15837392,
  "text" : "@bobprime @jeremiahfelt i'm not really interested in voice chat. i was considering opening up a slack for it.",
  "id" : 562324375550967808,
  "in_reply_to_status_id" : 562323762587377664,
  "created_at" : "2015-02-02 18:59:13 +0000",
  "in_reply_to_screen_name" : "bobprime",
  "in_reply_to_user_id_str" : "15837392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562299354426638336",
  "geo" : { },
  "id_str" : "562310732830605314",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella part of the map config",
  "id" : 562310732830605314,
  "in_reply_to_status_id" : 562299354426638336,
  "created_at" : "2015-02-02 18:05:00 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/Xl5OiTa2Pe",
      "expanded_url" : "http:\/\/pickaxe.club\/#city\/3\/6\/-530\/65\/64",
      "display_url" : "pickaxe.club\/#city\/3\/6\/-530\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562296999928549376",
  "text" : "Spotting some diamonds... http:\/\/t.co\/Xl5OiTa2Pe",
  "id" : 562296999928549376,
  "created_at" : "2015-02-02 17:10:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This Karen situation",
      "screen_name" : "gamehawk",
      "indices" : [ 0, 9 ],
      "id_str" : "17582985",
      "id" : 17582985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562291784970010625",
  "geo" : { },
  "id_str" : "562291885763354624",
  "in_reply_to_user_id" : 17582985,
  "text" : "@gamehawk i can try again. wasn't too happy with the quality last time.",
  "id" : 562291885763354624,
  "in_reply_to_status_id" : 562291784970010625,
  "created_at" : "2015-02-02 16:50:07 +0000",
  "in_reply_to_screen_name" : "gamehawk",
  "in_reply_to_user_id_str" : "17582985",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    }, {
      "name" : "Josh Owens",
      "screen_name" : "joshowens",
      "indices" : [ 8, 18 ],
      "id_str" : "768288",
      "id" : 768288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/nNt07IojOk",
      "expanded_url" : "http:\/\/pickaxe.club\/#city\/2\/6\/-76\/129\/64",
      "display_url" : "pickaxe.club\/#city\/2\/6\/-76\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "562276890715906048",
  "geo" : { },
  "id_str" : "562291585048530944",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek @joshowens looks OK from this side :P http:\/\/t.co\/nNt07IojOk",
  "id" : 562291585048530944,
  "in_reply_to_status_id" : 562276890715906048,
  "created_at" : "2015-02-02 16:48:55 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This Karen situation",
      "screen_name" : "gamehawk",
      "indices" : [ 0, 9 ],
      "id_str" : "17582985",
      "id" : 17582985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562290710376771586",
  "geo" : { },
  "id_str" : "562291104792326146",
  "in_reply_to_user_id" : 17582985,
  "text" : "@gamehawk ehh sounds like a lot of work :) i'd rather see how we can work it in.",
  "id" : 562291104792326146,
  "in_reply_to_status_id" : 562290710376771586,
  "created_at" : "2015-02-02 16:47:00 +0000",
  "in_reply_to_screen_name" : "gamehawk",
  "in_reply_to_user_id_str" : "17582985",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    }, {
      "name" : "Josh Owens",
      "screen_name" : "joshowens",
      "indices" : [ 8, 18 ],
      "id_str" : "768288",
      "id" : 768288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/pk3NE9HFdf",
      "expanded_url" : "http:\/\/mapcrafter.org\/index",
      "display_url" : "mapcrafter.org\/index"
    } ]
  },
  "in_reply_to_status_id_str" : "562276890715906048",
  "geo" : { },
  "id_str" : "562289477771489280",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek @joshowens http:\/\/t.co\/pk3NE9HFdf",
  "id" : 562289477771489280,
  "in_reply_to_status_id" : 562276890715906048,
  "created_at" : "2015-02-02 16:40:32 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This Karen situation",
      "screen_name" : "gamehawk",
      "indices" : [ 0, 9 ],
      "id_str" : "17582985",
      "id" : 17582985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562275601143189505",
  "geo" : { },
  "id_str" : "562289416069074944",
  "in_reply_to_user_id" : 17582985,
  "text" : "@gamehawk thats why there are multiple rotations",
  "id" : 562289416069074944,
  "in_reply_to_status_id" : 562275601143189505,
  "created_at" : "2015-02-02 16:40:18 +0000",
  "in_reply_to_screen_name" : "gamehawk",
  "in_reply_to_user_id_str" : "17582985",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562261843893555200",
  "geo" : { },
  "id_str" : "562262694670381057",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox not going to do any damage unless if the shovel was magically a wrench. also my dad's a fire captain...learned from the best ;)",
  "id" : 562262694670381057,
  "in_reply_to_status_id" : 562261843893555200,
  "created_at" : "2015-02-02 14:54:07 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562256432834179073",
  "text" : "Nearest fire hydrant had around 2-3\" of ice on it, hadn't seen that ever before. Please clear any if you're outside snow shoveling today.",
  "id" : 562256432834179073,
  "created_at" : "2015-02-02 14:29:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/hnAUl8y0HH",
      "expanded_url" : "http:\/\/pickaxe.club\/#overworld\/0\/8\/-62\/185\/64",
      "display_url" : "pickaxe.club\/#overworld\/0\/8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562256159466209281",
  "text" : "Lots of new builds from weekend 9 are now up: http:\/\/t.co\/hnAUl8y0HH",
  "id" : 562256159466209281,
  "created_at" : "2015-02-02 14:28:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/562247785483739136\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/8VPYu3ANpe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B82BYTACYAAm22n.jpg",
      "id_str" : "562247782908452864",
      "id" : 562247782908452864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B82BYTACYAAm22n.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8VPYu3ANpe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562247785483739136",
  "text" : "Happy Monday! http:\/\/t.co\/8VPYu3ANpe",
  "id" : 562247785483739136,
  "created_at" : "2015-02-02 13:54:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This Karen situation",
      "screen_name" : "gamehawk",
      "indices" : [ 0, 9 ],
      "id_str" : "17582985",
      "id" : 17582985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562104442271461376",
  "geo" : { },
  "id_str" : "562245882775474177",
  "in_reply_to_user_id" : 17582985,
  "text" : "@gamehawk but then you'll need to build a tower to see the new tower",
  "id" : 562245882775474177,
  "in_reply_to_status_id" : 562104442271461376,
  "created_at" : "2015-02-02 13:47:19 +0000",
  "in_reply_to_screen_name" : "gamehawk",
  "in_reply_to_user_id_str" : "17582985",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Graham",
      "screen_name" : "grahams",
      "indices" : [ 0, 8 ],
      "id_str" : "758727",
      "id" : 758727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562100547579547648",
  "geo" : { },
  "id_str" : "562101233758920705",
  "in_reply_to_user_id" : 758727,
  "text" : "@grahams I use it daily. Pretty buggy and missing features but I couldn't live without it",
  "id" : 562101233758920705,
  "in_reply_to_status_id" : 562100547579547648,
  "created_at" : "2015-02-02 04:12:32 +0000",
  "in_reply_to_screen_name" : "grahams",
  "in_reply_to_user_id_str" : "758727",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annika Backstrom",
      "screen_name" : "abackstrom",
      "indices" : [ 0, 11 ],
      "id_str" : "3621751",
      "id" : 3621751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562096742309851136",
  "geo" : { },
  "id_str" : "562096830947663872",
  "in_reply_to_user_id" : 3621751,
  "text" : "@abackstrom dammit by 2 seconds!!",
  "id" : 562096830947663872,
  "in_reply_to_status_id" : 562096742309851136,
  "created_at" : "2015-02-02 03:55:02 +0000",
  "in_reply_to_screen_name" : "abackstrom",
  "in_reply_to_user_id_str" : "3621751",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "indices" : [ 0, 14 ],
      "id_str" : "369585978",
      "id" : 369585978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562096525275594752",
  "geo" : { },
  "id_str" : "562096753566957568",
  "in_reply_to_user_id" : 369585978,
  "text" : "@meaganewaller Kings Cup James Version",
  "id" : 562096753566957568,
  "in_reply_to_status_id" : 562096525275594752,
  "created_at" : "2015-02-02 03:54:43 +0000",
  "in_reply_to_screen_name" : "meaganewaller",
  "in_reply_to_user_id_str" : "369585978",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Jeong",
      "screen_name" : "sarahjeong",
      "indices" : [ 3, 14 ],
      "id_str" : "47509268",
      "id" : 47509268
    }, {
      "name" : "Aaron",
      "screen_name" : "fermunation",
      "indices" : [ 16, 28 ],
      "id_str" : "30609306",
      "id" : 30609306
    }, {
      "name" : "Butt Coin",
      "screen_name" : "ButtCoin",
      "indices" : [ 29, 38 ],
      "id_str" : "305854715",
      "id" : 305854715
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/sarahjeong\/status\/561785170538553344\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/bS8OvdDcJI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8vcop4CMAAbGQ3.jpg",
      "id_str" : "561785169531514880",
      "id" : 561785169531514880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8vcop4CMAAbGQ3.jpg",
      "sizes" : [ {
        "h" : 2322,
        "resize" : "fit",
        "w" : 4128
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bS8OvdDcJI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562096117634965506",
  "text" : "RT @sarahjeong: @fermunation @ButtCoin he called it his \u201Cpleasure card\u201D while making intense eye contact http:\/\/t.co\/bS8OvdDcJI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aaron",
        "screen_name" : "fermunation",
        "indices" : [ 0, 12 ],
        "id_str" : "30609306",
        "id" : 30609306
      }, {
        "name" : "Butt Coin",
        "screen_name" : "ButtCoin",
        "indices" : [ 13, 22 ],
        "id_str" : "305854715",
        "id" : 305854715
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/sarahjeong\/status\/561785170538553344\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/bS8OvdDcJI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8vcop4CMAAbGQ3.jpg",
        "id_str" : "561785169531514880",
        "id" : 561785169531514880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8vcop4CMAAbGQ3.jpg",
        "sizes" : [ {
          "h" : 2322,
          "resize" : "fit",
          "w" : 4128
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/bS8OvdDcJI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "561782298593341441",
    "geo" : { },
    "id_str" : "561785170538553344",
    "in_reply_to_user_id" : 30609306,
    "text" : "@fermunation @ButtCoin he called it his \u201Cpleasure card\u201D while making intense eye contact http:\/\/t.co\/bS8OvdDcJI",
    "id" : 561785170538553344,
    "in_reply_to_status_id" : 561782298593341441,
    "created_at" : "2015-02-01 07:16:36 +0000",
    "in_reply_to_screen_name" : "fermunation",
    "in_reply_to_user_id_str" : "30609306",
    "user" : {
      "name" : "Sarah Jeong",
      "screen_name" : "sarahjeong",
      "protected" : false,
      "id_str" : "47509268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544692642794053632\/eFqYMyeO_normal.jpeg",
      "id" : 47509268,
      "verified" : false
    }
  },
  "id" : 562096117634965506,
  "created_at" : "2015-02-02 03:52:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Onion Sports Network",
      "screen_name" : "OnionSports",
      "indices" : [ 3, 15 ],
      "id_str" : "159894847",
      "id" : 159894847
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/OnionSports\/status\/562089480803209216\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ErzJcSai0i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8zxZ09CAAAS4Qa.jpg",
      "id_str" : "562089479528120320",
      "id" : 562089479528120320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8zxZ09CAAAS4Qa.jpg",
      "sizes" : [ {
        "h" : 1516,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 776,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ErzJcSai0i"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/8YsrE6WYaK",
      "expanded_url" : "http:\/\/onion.com\/1Bb7scz",
      "display_url" : "onion.com\/1Bb7scz"
    } ]
  },
  "geo" : { },
  "id_str" : "562090786146103296",
  "text" : "RT @OnionSports: In Focus: Super Bowl Confetti Made Entirely From Shredded Concussion Studies http:\/\/t.co\/8YsrE6WYaK http:\/\/t.co\/ErzJcSai0i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/OnionSports\/status\/562089480803209216\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/ErzJcSai0i",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8zxZ09CAAAS4Qa.jpg",
        "id_str" : "562089479528120320",
        "id" : 562089479528120320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8zxZ09CAAAS4Qa.jpg",
        "sizes" : [ {
          "h" : 1516,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 776,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ErzJcSai0i"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/8YsrE6WYaK",
        "expanded_url" : "http:\/\/onion.com\/1Bb7scz",
        "display_url" : "onion.com\/1Bb7scz"
      } ]
    },
    "geo" : { },
    "id_str" : "562089480803209216",
    "text" : "In Focus: Super Bowl Confetti Made Entirely From Shredded Concussion Studies http:\/\/t.co\/8YsrE6WYaK http:\/\/t.co\/ErzJcSai0i",
    "id" : 562089480803209216,
    "created_at" : "2015-02-02 03:25:49 +0000",
    "user" : {
      "name" : "Onion Sports Network",
      "screen_name" : "OnionSports",
      "protected" : false,
      "id_str" : "159894847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1132666818\/osn_small_normal.jpg",
      "id" : 159894847,
      "verified" : true
    }
  },
  "id" : 562090786146103296,
  "created_at" : "2015-02-02 03:31:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Rosenberg\u2122",
      "screen_name" : "jonrosenberg",
      "indices" : [ 3, 16 ],
      "id_str" : "14180105",
      "id" : 14180105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562085307848196098",
  "text" : "RT @jonrosenberg: I'm going to Disneyland to catch measles",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562085072749461506",
    "text" : "I'm going to Disneyland to catch measles",
    "id" : 562085072749461506,
    "created_at" : "2015-02-02 03:08:19 +0000",
    "user" : {
      "name" : "Jon Rosenberg\u2122",
      "screen_name" : "jonrosenberg",
      "protected" : false,
      "id_str" : "14180105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570975573367742464\/msxi-Vo3_normal.png",
      "id" : 14180105,
      "verified" : false
    }
  },
  "id" : 562085307848196098,
  "created_at" : "2015-02-02 03:09:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562061554330259459",
  "geo" : { },
  "id_str" : "562061926402768898",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting sorry I've just done that drive several dozen times by now. Just stay put.",
  "id" : 562061926402768898,
  "in_reply_to_status_id" : 562061554330259459,
  "created_at" : "2015-02-02 01:36:20 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    }, {
      "name" : "codemash",
      "screen_name" : "codemash",
      "indices" : [ 101, 110 ],
      "id_str" : "7469772",
      "id" : 7469772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562061554330259459",
  "geo" : { },
  "id_str" : "562061815970926593",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting they use sand not salt on most of the PA 90 section. It was so awful coming back from @codemash. NY state line was clear",
  "id" : 562061815970926593,
  "in_reply_to_status_id" : 562061554330259459,
  "created_at" : "2015-02-02 01:35:54 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562060153038446593",
  "geo" : { },
  "id_str" : "562061186334609408",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting they don't plow the 90 between Erie and the state line. I would just stay in Erie if possible.",
  "id" : 562061186334609408,
  "in_reply_to_status_id" : 562060153038446593,
  "created_at" : "2015-02-02 01:33:24 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562059919575093249",
  "text" : "Hey Buffalo in case you are driving after the game: it's fucking awful out.",
  "id" : 562059919575093249,
  "created_at" : "2015-02-02 01:28:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562041213784973312",
  "text" : "Every ops person out there just freaked out about a network operator having liquid in the data center",
  "id" : 562041213784973312,
  "created_at" : "2015-02-02 00:14:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This Karen situation",
      "screen_name" : "gamehawk",
      "indices" : [ 0, 9 ],
      "id_str" : "17582985",
      "id" : 17582985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562039475396558848",
  "geo" : { },
  "id_str" : "562039628992376832",
  "in_reply_to_user_id" : 17582985,
  "text" : "@gamehawk :( I think so. A Blake maybe?",
  "id" : 562039628992376832,
  "in_reply_to_status_id" : 562039475396558848,
  "created_at" : "2015-02-02 00:07:44 +0000",
  "in_reply_to_screen_name" : "gamehawk",
  "in_reply_to_user_id_str" : "17582985",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melody Joy Kramer",
      "screen_name" : "mkramer",
      "indices" : [ 3, 11 ],
      "id_str" : "10232022",
      "id" : 10232022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/F8eBp9l32k",
      "expanded_url" : "http:\/\/nyti.ms\/1zthfeD",
      "display_url" : "nyti.ms\/1zthfeD"
    } ]
  },
  "geo" : { },
  "id_str" : "562038713598087168",
  "text" : "RT @mkramer: In Domestic Violence Cases, N.F.L. Has a History of Lenience http:\/\/t.co\/F8eBp9l32k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/F8eBp9l32k",
        "expanded_url" : "http:\/\/nyti.ms\/1zthfeD",
        "display_url" : "nyti.ms\/1zthfeD"
      } ]
    },
    "geo" : { },
    "id_str" : "562036972341166080",
    "text" : "In Domestic Violence Cases, N.F.L. Has a History of Lenience http:\/\/t.co\/F8eBp9l32k",
    "id" : 562036972341166080,
    "created_at" : "2015-02-01 23:57:11 +0000",
    "user" : {
      "name" : "Melody Joy Kramer",
      "screen_name" : "mkramer",
      "protected" : false,
      "id_str" : "10232022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451395915455414272\/xfo3AxaN_normal.jpeg",
      "id" : 10232022,
      "verified" : true
    }
  },
  "id" : 562038713598087168,
  "created_at" : "2015-02-02 00:04:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melody Joy Kramer",
      "screen_name" : "mkramer",
      "indices" : [ 3, 11 ],
      "id_str" : "10232022",
      "id" : 10232022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/HIt0gnVQ22",
      "expanded_url" : "http:\/\/usat.ly\/1zthxBX",
      "display_url" : "usat.ly\/1zthxBX"
    } ]
  },
  "geo" : { },
  "id_str" : "562038417966788609",
  "text" : "RT @mkramer: Former NFL exec: Teams hid 'hundreds' of abuse incidents http:\/\/t.co\/HIt0gnVQ22",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/HIt0gnVQ22",
        "expanded_url" : "http:\/\/usat.ly\/1zthxBX",
        "display_url" : "usat.ly\/1zthxBX"
      } ]
    },
    "geo" : { },
    "id_str" : "562037534365335554",
    "text" : "Former NFL exec: Teams hid 'hundreds' of abuse incidents http:\/\/t.co\/HIt0gnVQ22",
    "id" : 562037534365335554,
    "created_at" : "2015-02-01 23:59:25 +0000",
    "user" : {
      "name" : "Melody Joy Kramer",
      "screen_name" : "mkramer",
      "protected" : false,
      "id_str" : "10232022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451395915455414272\/xfo3AxaN_normal.jpeg",
      "id" : 10232022,
      "verified" : true
    }
  },
  "id" : 562038417966788609,
  "created_at" : "2015-02-02 00:02:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562033852890480640",
  "geo" : { },
  "id_str" : "562033981668216832",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh you're gonna miss all the commercials!",
  "id" : 562033981668216832,
  "in_reply_to_status_id" : 562033852890480640,
  "created_at" : "2015-02-01 23:45:17 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562030917951049728",
  "geo" : { },
  "id_str" : "562032859347959809",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh are those your seats??!",
  "id" : 562032859347959809,
  "in_reply_to_status_id" : 562030917951049728,
  "created_at" : "2015-02-01 23:40:50 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tow truck central",
      "screen_name" : "duh_nellll",
      "indices" : [ 0, 11 ],
      "id_str" : "146513248",
      "id" : 146513248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562030452689866753",
  "geo" : { },
  "id_str" : "562030590804099074",
  "in_reply_to_user_id" : 146513248,
  "text" : "@duh_nellll thank you for asking",
  "id" : 562030590804099074,
  "in_reply_to_status_id" : 562030452689866753,
  "created_at" : "2015-02-01 23:31:49 +0000",
  "in_reply_to_screen_name" : "duh_nellll",
  "in_reply_to_user_id_str" : "146513248",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hal Hefner",
      "screen_name" : "halhefner",
      "indices" : [ 3, 13 ],
      "id_str" : "25318441",
      "id" : 25318441
    }, {
      "name" : "IGN",
      "screen_name" : "IGN",
      "indices" : [ 16, 20 ],
      "id_str" : "18927441",
      "id" : 18927441
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/halhefner\/status\/562008288728850432\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/kbxUVGjImv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8ynj3yCcAEKEHk.png",
      "id_str" : "562008288225554433",
      "id" : 562008288225554433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8ynj3yCcAEKEHk.png",
      "sizes" : [ {
        "h" : 1728,
        "resize" : "fit",
        "w" : 1296
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kbxUVGjImv"
    } ],
    "hashtags" : [ {
      "text" : "Obey",
      "indices" : [ 21, 26 ]
    }, {
      "text" : "superbowl",
      "indices" : [ 31, 41 ]
    }, {
      "text" : "obey",
      "indices" : [ 43, 48 ]
    }, {
      "text" : "avengerstrailer",
      "indices" : [ 53, 69 ]
    }, {
      "text" : "THEYLIVEwesleep",
      "indices" : [ 70, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562028069507309568",
  "text" : "RT @halhefner: .@IGN #Obey the #superbowl. #obey the #avengerstrailer #THEYLIVEwesleep http:\/\/t.co\/kbxUVGjImv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IGN",
        "screen_name" : "IGN",
        "indices" : [ 1, 5 ],
        "id_str" : "18927441",
        "id" : 18927441
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/halhefner\/status\/562008288728850432\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/kbxUVGjImv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8ynj3yCcAEKEHk.png",
        "id_str" : "562008288225554433",
        "id" : 562008288225554433,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8ynj3yCcAEKEHk.png",
        "sizes" : [ {
          "h" : 1728,
          "resize" : "fit",
          "w" : 1296
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/kbxUVGjImv"
      } ],
      "hashtags" : [ {
        "text" : "Obey",
        "indices" : [ 6, 11 ]
      }, {
        "text" : "superbowl",
        "indices" : [ 16, 26 ]
      }, {
        "text" : "obey",
        "indices" : [ 28, 33 ]
      }, {
        "text" : "avengerstrailer",
        "indices" : [ 38, 54 ]
      }, {
        "text" : "THEYLIVEwesleep",
        "indices" : [ 55, 71 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "562007778899030018",
    "geo" : { },
    "id_str" : "562008288728850432",
    "in_reply_to_user_id" : 18927441,
    "text" : ".@IGN #Obey the #superbowl. #obey the #avengerstrailer #THEYLIVEwesleep http:\/\/t.co\/kbxUVGjImv",
    "id" : 562008288728850432,
    "in_reply_to_status_id" : 562007778899030018,
    "created_at" : "2015-02-01 22:03:12 +0000",
    "in_reply_to_screen_name" : "IGN",
    "in_reply_to_user_id_str" : "18927441",
    "user" : {
      "name" : "Hal Hefner",
      "screen_name" : "halhefner",
      "protected" : false,
      "id_str" : "25318441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539498150667366401\/OKcaXi3v_normal.jpeg",
      "id" : 25318441,
      "verified" : false
    }
  },
  "id" : 562028069507309568,
  "created_at" : "2015-02-01 23:21:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This Karen situation",
      "screen_name" : "gamehawk",
      "indices" : [ 0, 9 ],
      "id_str" : "17582985",
      "id" : 17582985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562020232374411264",
  "geo" : { },
  "id_str" : "562027292172771328",
  "in_reply_to_user_id" : 17582985,
  "text" : "@gamehawk well now we have to make a police station...",
  "id" : 562027292172771328,
  "in_reply_to_status_id" : 562020232374411264,
  "created_at" : "2015-02-01 23:18:43 +0000",
  "in_reply_to_screen_name" : "gamehawk",
  "in_reply_to_user_id_str" : "17582985",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 3, 10 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/gabebw\/status\/561914539403644930\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/mWDeaiG3nP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8xSSg9IcAAjm83.png",
      "id_str" : "561914531551932416",
      "id" : 561914531551932416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8xSSg9IcAAjm83.png",
      "sizes" : [ {
        "h" : 331,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mWDeaiG3nP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562015107056934912",
  "text" : "RT @gabebw: Hashtag superbowl http:\/\/t.co\/mWDeaiG3nP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/gabebw\/status\/561914539403644930\/photo\/1",
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/mWDeaiG3nP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8xSSg9IcAAjm83.png",
        "id_str" : "561914531551932416",
        "id" : 561914531551932416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8xSSg9IcAAjm83.png",
        "sizes" : [ {
          "h" : 331,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/mWDeaiG3nP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561914539403644930",
    "text" : "Hashtag superbowl http:\/\/t.co\/mWDeaiG3nP",
    "id" : 561914539403644930,
    "created_at" : "2015-02-01 15:50:40 +0000",
    "user" : {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "protected" : false,
      "id_str" : "224887329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522042513951977472\/vthKCPDr_normal.jpeg",
      "id" : 224887329,
      "verified" : false
    }
  },
  "id" : 562015107056934912,
  "created_at" : "2015-02-01 22:30:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC7 Eyewitness News",
      "screen_name" : "ABC7",
      "indices" : [ 3, 8 ],
      "id_str" : "16374678",
      "id" : 16374678
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BREAKINGNEWS",
      "indices" : [ 10, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Y2w9YMkjQu",
      "expanded_url" : "http:\/\/abc7.la\/16hBIcL",
      "display_url" : "abc7.la\/16hBIcL"
    } ]
  },
  "geo" : { },
  "id_str" : "562014895466901505",
  "text" : "RT @ABC7: #BREAKINGNEWS: Former red Power Ranger fatally stabbed roommate with sword in Green Valley, LASD confirms http:\/\/t.co\/Y2w9YMkjQu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BREAKINGNEWS",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/Y2w9YMkjQu",
        "expanded_url" : "http:\/\/abc7.la\/16hBIcL",
        "display_url" : "abc7.la\/16hBIcL"
      } ]
    },
    "geo" : { },
    "id_str" : "562012835145076736",
    "text" : "#BREAKINGNEWS: Former red Power Ranger fatally stabbed roommate with sword in Green Valley, LASD confirms http:\/\/t.co\/Y2w9YMkjQu",
    "id" : 562012835145076736,
    "created_at" : "2015-02-01 22:21:16 +0000",
    "user" : {
      "name" : "ABC7 Eyewitness News",
      "screen_name" : "ABC7",
      "protected" : false,
      "id_str" : "16374678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3118201123\/860f36773d5ba8f8ab3a60a84bb33fc7_normal.jpeg",
      "id" : 16374678,
      "verified" : true
    }
  },
  "id" : 562014895466901505,
  "created_at" : "2015-02-01 22:29:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562011546898165762",
  "text" : "Totally forgot RIT hockey is on TV. That new arena is gorgeous.",
  "id" : 562011546898165762,
  "created_at" : "2015-02-01 22:16:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562003351534309378",
  "text" : "Puppy Bowl time!!!! \uD83D\uDC36\uD83D\uDC36\uD83D\uDC36\uD83C\uDFC8\uD83D\uDC36\uD83D\uDC36\uD83D\uDC36",
  "id" : 562003351534309378,
  "created_at" : "2015-02-01 21:43:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "561980328869253120",
  "geo" : { },
  "id_str" : "561983046195224578",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda there's quite a few builds going on :)",
  "id" : 561983046195224578,
  "in_reply_to_status_id" : 561980328869253120,
  "created_at" : "2015-02-01 20:22:54 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/561979744078405632\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/wmoZaCjcPt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8yNmVUCAAA8PgE.png",
      "id_str" : "561979743210176512",
      "id" : 561979743210176512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8yNmVUCAAA8PgE.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/wmoZaCjcPt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561979744078405632",
  "text" : "Pickaxe City Hall finally is growing, the pickaxe monument has become a villager home, and a huge skyscraper pops up http:\/\/t.co\/wmoZaCjcPt",
  "id" : 561979744078405632,
  "created_at" : "2015-02-01 20:09:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby McKenna",
      "screen_name" : "bobby",
      "indices" : [ 0, 6 ],
      "id_str" : "17983820",
      "id" : 17983820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "561960444722954242",
  "geo" : { },
  "id_str" : "561961036572409856",
  "in_reply_to_user_id" : 17983820,
  "text" : "@bobby you should read the books instead. Underrated.",
  "id" : 561961036572409856,
  "in_reply_to_status_id" : 561960444722954242,
  "created_at" : "2015-02-01 18:55:26 +0000",
  "in_reply_to_screen_name" : "bobby",
  "in_reply_to_user_id_str" : "17983820",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby McKenna",
      "screen_name" : "bobby",
      "indices" : [ 3, 9 ],
      "id_str" : "17983820",
      "id" : 17983820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561960785459437568",
  "text" : "RT @bobby: hey guys do i need to watch super bowls I through XLVIII to understand XLIX or can i just jump right in",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561960444722954242",
    "text" : "hey guys do i need to watch super bowls I through XLVIII to understand XLIX or can i just jump right in",
    "id" : 561960444722954242,
    "created_at" : "2015-02-01 18:53:05 +0000",
    "user" : {
      "name" : "Bobby McKenna",
      "screen_name" : "bobby",
      "protected" : false,
      "id_str" : "17983820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565317507515699203\/Sfoc-T3O_normal.jpeg",
      "id" : 17983820,
      "verified" : false
    }
  },
  "id" : 561960785459437568,
  "created_at" : "2015-02-01 18:54:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This Karen situation",
      "screen_name" : "gamehawk",
      "indices" : [ 3, 12 ],
      "id_str" : "17582985",
      "id" : 17582985
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 14, 20 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/gamehawk\/status\/561753852316102656\/photo\/1",
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/mOZlXRTrjz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8vAG5dCMAE8pzv.png",
      "id_str" : "561753803272105985",
      "id" : 561753803272105985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8vAG5dCMAE8pzv.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 854
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 854
      } ],
      "display_url" : "pic.twitter.com\/mOZlXRTrjz"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/gamehawk\/status\/561753852316102656\/photo\/1",
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/mOZlXRTrjz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8vAHLFCMAAe7F_.png",
      "id_str" : "561753808003280896",
      "id" : 561753808003280896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8vAHLFCMAAe7F_.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 854
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 854
      } ],
      "display_url" : "pic.twitter.com\/mOZlXRTrjz"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/gamehawk\/status\/561753852316102656\/photo\/1",
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/mOZlXRTrjz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8vAGVRCUAAc5wz.png",
      "id_str" : "561753793558106112",
      "id" : 561753793558106112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8vAGVRCUAAc5wz.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 854
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 854
      } ],
      "display_url" : "pic.twitter.com\/mOZlXRTrjz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561960160529092608",
  "text" : "RT @gamehawk: @qrush Five villagers (at least) hit by lightning, and then fighting with the golems. It was an epic battle. http:\/\/t.co\/mOZl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/gamehawk\/status\/561753852316102656\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/mOZlXRTrjz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8vAG5dCMAE8pzv.png",
        "id_str" : "561753803272105985",
        "id" : 561753803272105985,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8vAG5dCMAE8pzv.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 854
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 854
        } ],
        "display_url" : "pic.twitter.com\/mOZlXRTrjz"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/gamehawk\/status\/561753852316102656\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/mOZlXRTrjz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8vAHLFCMAAe7F_.png",
        "id_str" : "561753808003280896",
        "id" : 561753808003280896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8vAHLFCMAAe7F_.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 854
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 854
        } ],
        "display_url" : "pic.twitter.com\/mOZlXRTrjz"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/gamehawk\/status\/561753852316102656\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/mOZlXRTrjz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8vAGVRCUAAc5wz.png",
        "id_str" : "561753793558106112",
        "id" : 561753793558106112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8vAGVRCUAAc5wz.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 854
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 854
        } ],
        "display_url" : "pic.twitter.com\/mOZlXRTrjz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561753852316102656",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush Five villagers (at least) hit by lightning, and then fighting with the golems. It was an epic battle. http:\/\/t.co\/mOZlXRTrjz",
    "id" : 561753852316102656,
    "created_at" : "2015-02-01 05:12:09 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "This Karen situation",
      "screen_name" : "gamehawk",
      "protected" : false,
      "id_str" : "17582985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535841464110940160\/xuBjQcbB_normal.png",
      "id" : 17582985,
      "verified" : false
    }
  },
  "id" : 561960160529092608,
  "created_at" : "2015-02-01 18:51:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robb Kidd",
      "screen_name" : "robbkidd",
      "indices" : [ 3, 12 ],
      "id_str" : "60212114",
      "id" : 60212114
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/robbkidd\/status\/561953403501543426\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/3GIqTRKcf8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8x1pICCMAIht_R.png",
      "id_str" : "561953402905571330",
      "id" : 561953402905571330,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8x1pICCMAIht_R.png",
      "sizes" : [ {
        "h" : 1001,
        "resize" : "fit",
        "w" : 1680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3GIqTRKcf8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/3DS1UktJaw",
      "expanded_url" : "http:\/\/pickaxe.club",
      "display_url" : "pickaxe.club"
    } ]
  },
  "geo" : { },
  "id_str" : "561960093600604160",
  "text" : "RT @robbkidd: http:\/\/t.co\/3DS1UktJaw librarian locked up for the good of society and was apparently allowed conjugal visits. http:\/\/t.co\/3G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/robbkidd\/status\/561953403501543426\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/3GIqTRKcf8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8x1pICCMAIht_R.png",
        "id_str" : "561953402905571330",
        "id" : 561953402905571330,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8x1pICCMAIht_R.png",
        "sizes" : [ {
          "h" : 1001,
          "resize" : "fit",
          "w" : 1680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 202,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3GIqTRKcf8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/3DS1UktJaw",
        "expanded_url" : "http:\/\/pickaxe.club",
        "display_url" : "pickaxe.club"
      } ]
    },
    "geo" : { },
    "id_str" : "561953403501543426",
    "text" : "http:\/\/t.co\/3DS1UktJaw librarian locked up for the good of society and was apparently allowed conjugal visits. http:\/\/t.co\/3GIqTRKcf8",
    "id" : 561953403501543426,
    "created_at" : "2015-02-01 18:25:06 +0000",
    "user" : {
      "name" : "Robb Kidd",
      "screen_name" : "robbkidd",
      "protected" : false,
      "id_str" : "60212114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458796950117044224\/7FId6517_normal.jpeg",
      "id" : 60212114,
      "verified" : false
    }
  },
  "id" : 561960093600604160,
  "created_at" : "2015-02-01 18:51:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Brown",
      "screen_name" : "HigherEdSoc",
      "indices" : [ 3, 15 ],
      "id_str" : "2761284038",
      "id" : 2761284038
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HigherEdSoc\/status\/561954950423785473\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/PctY3uLHsA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8x3Cs5CMAMT7Zn.jpg",
      "id_str" : "561954941808291843",
      "id" : 561954941808291843,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8x3Cs5CMAMT7Zn.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 601
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 601
      } ],
      "display_url" : "pic.twitter.com\/PctY3uLHsA"
    } ],
    "hashtags" : [ {
      "text" : "measles",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/bZ2p9hT3Sm",
      "expanded_url" : "http:\/\/io9.com\/read-roald-dahls-heart-rending-endorsement-of-measles-v-1682995322",
      "display_url" : "io9.com\/read-roald-dah\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "561959844026916864",
  "text" : "RT @HigherEdSoc: Roald Dahl writes about losing his daughter to #measles in 1962\nhttp:\/\/t.co\/bZ2p9hT3Sm http:\/\/t.co\/PctY3uLHsA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HigherEdSoc\/status\/561954950423785473\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/PctY3uLHsA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8x3Cs5CMAMT7Zn.jpg",
        "id_str" : "561954941808291843",
        "id" : 561954941808291843,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8x3Cs5CMAMT7Zn.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 301,
          "resize" : "fit",
          "w" : 601
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 301,
          "resize" : "fit",
          "w" : 601
        } ],
        "display_url" : "pic.twitter.com\/PctY3uLHsA"
      } ],
      "hashtags" : [ {
        "text" : "measles",
        "indices" : [ 47, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/bZ2p9hT3Sm",
        "expanded_url" : "http:\/\/io9.com\/read-roald-dahls-heart-rending-endorsement-of-measles-v-1682995322",
        "display_url" : "io9.com\/read-roald-dah\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "561954950423785473",
    "text" : "Roald Dahl writes about losing his daughter to #measles in 1962\nhttp:\/\/t.co\/bZ2p9hT3Sm http:\/\/t.co\/PctY3uLHsA",
    "id" : 561954950423785473,
    "created_at" : "2015-02-01 18:31:15 +0000",
    "user" : {
      "name" : "Joshua Brown",
      "screen_name" : "HigherEdSoc",
      "protected" : false,
      "id_str" : "2761284038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/503395223150415872\/Ryr-avIm_normal.jpeg",
      "id" : 2761284038,
      "verified" : false
    }
  },
  "id" : 561959844026916864,
  "created_at" : "2015-02-01 18:50:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "561904584726437889",
  "geo" : { },
  "id_str" : "561904792541208576",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal too many slides\ntoo many slides \n~~too many slides~~",
  "id" : 561904792541208576,
  "in_reply_to_status_id" : 561904584726437889,
  "created_at" : "2015-02-01 15:11:56 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darren Rovell",
      "screen_name" : "darrenrovell",
      "indices" : [ 3, 16 ],
      "id_str" : "24277551",
      "id" : 24277551
    }, {
      "name" : "Dennis Brown",
      "screen_name" : "deno716",
      "indices" : [ 93, 101 ],
      "id_str" : "409670709",
      "id" : 409670709
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/deno716\/status\/561551826857000960\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/nmODN2vjKM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8sIaUNIcAAFa1F.jpg",
      "id_str" : "561551826731167744",
      "id" : 561551826731167744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8sIaUNIcAAFa1F.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 540
      } ],
      "display_url" : "pic.twitter.com\/nmODN2vjKM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561898401940267008",
  "text" : "RT @darrenrovell: Wegman\u2019s in Buffalo selling Tom\u2019s Deflate Cake http:\/\/t.co\/nmODN2vjKM (via @deno716)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dennis Brown",
        "screen_name" : "deno716",
        "indices" : [ 75, 83 ],
        "id_str" : "409670709",
        "id" : 409670709
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/deno716\/status\/561551826857000960\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/nmODN2vjKM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8sIaUNIcAAFa1F.jpg",
        "id_str" : "561551826731167744",
        "id" : 561551826731167744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8sIaUNIcAAFa1F.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 540
        } ],
        "display_url" : "pic.twitter.com\/nmODN2vjKM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561552521643044866",
    "text" : "Wegman\u2019s in Buffalo selling Tom\u2019s Deflate Cake http:\/\/t.co\/nmODN2vjKM (via @deno716)",
    "id" : 561552521643044866,
    "created_at" : "2015-01-31 15:52:08 +0000",
    "user" : {
      "name" : "Darren Rovell",
      "screen_name" : "darrenrovell",
      "protected" : false,
      "id_str" : "24277551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533936144829136896\/oUit9dMQ_normal.jpeg",
      "id" : 24277551,
      "verified" : true
    }
  },
  "id" : 561898401940267008,
  "created_at" : "2015-02-01 14:46:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric DuVall",
      "screen_name" : "EricRDuVall",
      "indices" : [ 3, 15 ],
      "id_str" : "31311465",
      "id" : 31311465
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/EricRDuVall\/status\/561411135988310016\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/lpW8zOv4ll",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8qIb-sIUAEhvYw.jpg",
      "id_str" : "561411117826985985",
      "id" : 561411117826985985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8qIb-sIUAEhvYw.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lpW8zOv4ll"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561894853051568128",
  "text" : "RT @EricRDuVall: Our last front page, done in BW on purpose. Felt right. http:\/\/t.co\/lpW8zOv4ll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/EricRDuVall\/status\/561411135988310016\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/lpW8zOv4ll",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8qIb-sIUAEhvYw.jpg",
        "id_str" : "561411117826985985",
        "id" : 561411117826985985,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8qIb-sIUAEhvYw.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 1065,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/lpW8zOv4ll"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561411135988310016",
    "text" : "Our last front page, done in BW on purpose. Felt right. http:\/\/t.co\/lpW8zOv4ll",
    "id" : 561411135988310016,
    "created_at" : "2015-01-31 06:30:19 +0000",
    "user" : {
      "name" : "Eric DuVall",
      "screen_name" : "EricRDuVall",
      "protected" : false,
      "id_str" : "31311465",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000696907195\/32f0e0baa6e0286f49478f426df49921_normal.jpeg",
      "id" : 31311465,
      "verified" : false
    }
  },
  "id" : 561894853051568128,
  "created_at" : "2015-02-01 14:32:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Scarcello",
      "screen_name" : "WordsWithSam",
      "indices" : [ 0, 13 ],
      "id_str" : "26401150",
      "id" : 26401150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "561893530491420672",
  "geo" : { },
  "id_str" : "561894305418067968",
  "in_reply_to_user_id" : 26401150,
  "text" : "@WordsWithSam put an envelope in each, do a raffle. Prizes in some. Coffee + $1 = envelope",
  "id" : 561894305418067968,
  "in_reply_to_status_id" : 561893530491420672,
  "created_at" : "2015-02-01 14:30:16 +0000",
  "in_reply_to_screen_name" : "WordsWithSam",
  "in_reply_to_user_id_str" : "26401150",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "561891078639722496",
  "geo" : { },
  "id_str" : "561892013075730432",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy the last time we looked into this it was outrageously expensive. Could look again though",
  "id" : 561892013075730432,
  "in_reply_to_status_id" : 561891078639722496,
  "created_at" : "2015-02-01 14:21:10 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 22, 36 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/t5KBy1RqpP",
      "expanded_url" : "http:\/\/www.wgrz.com\/story\/news\/local\/downtown\/2015\/01\/30\/city-of-buffalo-raises-parking-rates\/22632069\/",
      "display_url" : "wgrz.com\/story\/news\/loc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "561887131564376064",
  "text" : "Not the best news for @coworkbuffalo parking hunters http:\/\/t.co\/t5KBy1RqpP",
  "id" : 561887131564376064,
  "created_at" : "2015-02-01 14:01:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 3, 17 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/ClpchPGjN1",
      "expanded_url" : "http:\/\/wp.me\/p5oIq4-am1",
      "display_url" : "wp.me\/p5oIq4-am1"
    } ]
  },
  "geo" : { },
  "id_str" : "561885148535201792",
  "text" : "RT @buffalopundit: Buffalo as Hipster\u00A0Kingdom http:\/\/t.co\/ClpchPGjN1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/ClpchPGjN1",
        "expanded_url" : "http:\/\/wp.me\/p5oIq4-am1",
        "display_url" : "wp.me\/p5oIq4-am1"
      } ]
    },
    "geo" : { },
    "id_str" : "561882540374368257",
    "text" : "Buffalo as Hipster\u00A0Kingdom http:\/\/t.co\/ClpchPGjN1",
    "id" : 561882540374368257,
    "created_at" : "2015-02-01 13:43:31 +0000",
    "user" : {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "protected" : false,
      "id_str" : "5795572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554430715308560384\/LnSJ-sAY_normal.jpeg",
      "id" : 5795572,
      "verified" : false
    }
  },
  "id" : 561885148535201792,
  "created_at" : "2015-02-01 13:53:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This Karen situation",
      "screen_name" : "gamehawk",
      "indices" : [ 0, 9 ],
      "id_str" : "17582985",
      "id" : 17582985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "561754176389017600",
  "geo" : { },
  "id_str" : "561754484175413248",
  "in_reply_to_user_id" : 17582985,
  "text" : "@gamehawk geez!",
  "id" : 561754484175413248,
  "in_reply_to_status_id" : 561754176389017600,
  "created_at" : "2015-02-01 05:14:40 +0000",
  "in_reply_to_screen_name" : "gamehawk",
  "in_reply_to_user_id_str" : "17582985",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
Grailbird.data.tweets_2011_07 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trynity Mirell",
      "screen_name" : "mirell",
      "indices" : [ 0, 7 ],
      "id_str" : "2998829503",
      "id" : 2998829503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97819838319308800",
  "geo" : { },
  "id_str" : "97863467888943104",
  "in_reply_to_user_id" : 12733992,
  "text" : "@mirell definitely missing some, there's over 100k in the index :( we need to make mirroring easier.",
  "id" : 97863467888943104,
  "in_reply_to_status_id" : 97819838319308800,
  "created_at" : "2011-08-01 02:57:23 +0000",
  "in_reply_to_screen_name" : "evilgaywitch",
  "in_reply_to_user_id_str" : "12733992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poul Stevens",
      "screen_name" : "louisck",
      "indices" : [ 53, 61 ],
      "id_str" : "2218092372",
      "id" : 2218092372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97849072370728960",
  "text" : "Louie season 2 is off to an awesome start. Seriously @louisck, you're a boss.",
  "id" : 97849072370728960,
  "created_at" : "2011-08-01 02:00:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Hoolihan",
      "screen_name" : "thoolihan",
      "indices" : [ 0, 10 ],
      "id_str" : "9378332",
      "id" : 9378332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97805490301571073",
  "geo" : { },
  "id_str" : "97848908750929920",
  "in_reply_to_user_id" : 9378332,
  "text" : "@thoolihan ended up buying it, having fun so far!",
  "id" : 97848908750929920,
  "in_reply_to_status_id" : 97805490301571073,
  "created_at" : "2011-08-01 01:59:32 +0000",
  "in_reply_to_screen_name" : "thoolihan",
  "in_reply_to_user_id_str" : "9378332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 0, 12 ],
      "id_str" : "8828952",
      "id" : 8828952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97794443779903488",
  "geo" : { },
  "id_str" : "97795338697580544",
  "in_reply_to_user_id" : 8828952,
  "text" : "@codeofficer ehh....",
  "id" : 97795338697580544,
  "in_reply_to_status_id" : 97794443779903488,
  "created_at" : "2011-07-31 22:26:40 +0000",
  "in_reply_to_screen_name" : "codeofficer",
  "in_reply_to_user_id_str" : "8828952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 44, 53 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97794561753096192",
  "text" : "Hey xbox folks, is From Dust worth buying? +@mittense",
  "id" : 97794561753096192,
  "created_at" : "2011-07-31 22:23:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 0, 12 ],
      "id_str" : "8828952",
      "id" : 8828952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97781302123700224",
  "geo" : { },
  "id_str" : "97794078137266176",
  "in_reply_to_user_id" : 8828952,
  "text" : "@codeofficer did they announce the talks yet?",
  "id" : 97794078137266176,
  "in_reply_to_status_id" : 97781302123700224,
  "created_at" : "2011-07-31 22:21:39 +0000",
  "in_reply_to_screen_name" : "codeofficer",
  "in_reply_to_user_id_str" : "8828952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97740568184102913",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm you will be too! Let me know if you need help.",
  "id" : 97740568184102913,
  "created_at" : "2011-07-31 18:49:02 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97501264446889984",
  "text" : "Today was probably the most frustrating dog ownership day so far. Meeting new people is not easy.",
  "id" : 97501264446889984,
  "created_at" : "2011-07-31 02:58:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 84, 91 ],
      "id_str" : "3928731",
      "id" : 3928731
    }, {
      "name" : "Justin Rhinesmith",
      "screen_name" : "jerhinesmith",
      "indices" : [ 92, 105 ],
      "id_str" : "14564588",
      "id" : 14564588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 82 ],
      "url" : "http:\/\/t.co\/ke9yoPs",
      "expanded_url" : "https:\/\/img.skitch.com\/20110731-nwus94yt6kphp96pgh2fa7itby.png",
      "display_url" : "img.skitch.com\/20110731-nwus9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "97476452236279808",
  "text" : "Found it! Looks like rubycraft.org needs a northeast tunnel :) http:\/\/t.co\/ke9yoPs +@cssboy @jerhinesmith",
  "id" : 97476452236279808,
  "created_at" : "2011-07-31 01:19:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "u\u0250\u1D09\u0279o\u029E\u1D09\u0279\u029E \u1D09\u025F\u025F\u0250\u0279",
      "screen_name" : "raffi",
      "indices" : [ 13, 19 ],
      "id_str" : "8285392",
      "id" : 8285392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97322669640392704",
  "text" : "Just watched @raffi's oscon talk on engineering at twitter.....I really need to write something in Scala.",
  "id" : 97322669640392704,
  "created_at" : "2011-07-30 15:08:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Klishin",
      "screen_name" : "michaelklishin",
      "indices" : [ 0, 15 ],
      "id_str" : "13033522",
      "id" : 13033522
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 58, 68 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 77, 84 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Gabriel Horner",
      "screen_name" : "cldwalker",
      "indices" : [ 85, 95 ],
      "id_str" : "19846068",
      "id" : 19846068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97283187876696065",
  "geo" : { },
  "id_str" : "97308346440359936",
  "in_reply_to_user_id" : 13033522,
  "text" : "@michaelklishin damn. so how can we make that better from @gemcutter's end? +@sferik @cldwalker",
  "id" : 97308346440359936,
  "in_reply_to_status_id" : 97283187876696065,
  "created_at" : "2011-07-30 14:11:32 +0000",
  "in_reply_to_screen_name" : "michaelklishin",
  "in_reply_to_user_id_str" : "13033522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 25 ],
      "url" : "http:\/\/t.co\/JpUX1LY",
      "expanded_url" : "http:\/\/www.heyokay.com\/images\/FEELS%20GOODMAN.jpg",
      "display_url" : "heyokay.com\/images\/FEELS%2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "97150955287621632",
  "geo" : { },
  "id_str" : "97151068617707521",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k http:\/\/t.co\/JpUX1LY",
  "id" : 97151068617707521,
  "in_reply_to_status_id" : 97150955287621632,
  "created_at" : "2011-07-30 03:46:34 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97150980185014272",
  "text" : "That's not even counting the tunnel\/road system, which definitely isn't complete yet!!",
  "id" : 97150980185014272,
  "created_at" : "2011-07-30 03:46:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tamal White",
      "screen_name" : "tamalw",
      "indices" : [ 0, 7 ],
      "id_str" : "10715872",
      "id" : 10715872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97116056707022848",
  "geo" : { },
  "id_str" : "97117678262693889",
  "in_reply_to_user_id" : 10715872,
  "text" : "@tamalw awesome, it's due north! i'll blast out a tunnel from the keep to the sign area. also, a creeper exploded at your \"secret\" entrance",
  "id" : 97117678262693889,
  "in_reply_to_status_id" : 97116056707022848,
  "created_at" : "2011-07-30 01:33:53 +0000",
  "in_reply_to_screen_name" : "tamalw",
  "in_reply_to_user_id_str" : "10715872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tamal White",
      "screen_name" : "tamalw",
      "indices" : [ 0, 7 ],
      "id_str" : "10715872",
      "id" : 10715872
    }, {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 59, 67 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97101752398127105",
  "geo" : { },
  "id_str" : "97109130682183680",
  "in_reply_to_user_id" : 10715872,
  "text" : "@tamalw that's awesome! Where is it relative to the fort? +@ddollar",
  "id" : 97109130682183680,
  "in_reply_to_status_id" : 97101752398127105,
  "created_at" : "2011-07-30 00:59:55 +0000",
  "in_reply_to_screen_name" : "tamalw",
  "in_reply_to_user_id_str" : "10715872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brntbeer",
      "screen_name" : "brntbeer",
      "indices" : [ 0, 9 ],
      "id_str" : "14563437",
      "id" : 14563437
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 107, 114 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Gabriel Horner",
      "screen_name" : "cldwalker",
      "indices" : [ 116, 126 ],
      "id_str" : "19846068",
      "id" : 19846068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97063366509596672",
  "geo" : { },
  "id_str" : "97097958364950528",
  "in_reply_to_user_id" : 14563437,
  "text" : "@brntbeer i've heard reports but I haven't seen it myself. does chrome's inspector give any helpful info? +@sferik +@cldwalker",
  "id" : 97097958364950528,
  "in_reply_to_status_id" : 97063366509596672,
  "created_at" : "2011-07-30 00:15:31 +0000",
  "in_reply_to_screen_name" : "brntbeer",
  "in_reply_to_user_id_str" : "14563437",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis CI",
      "screen_name" : "travisci",
      "indices" : [ 33, 42 ],
      "id_str" : "252481460",
      "id" : 252481460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 74 ],
      "url" : "http:\/\/t.co\/8xhLKm3",
      "expanded_url" : "http:\/\/travis-ci.org\/#!\/thoughtbot\/factory_girl",
      "display_url" : "travis-ci.org\/#!\/thoughtbot\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "97070660500729856",
  "text" : "I must say, I was skeptical, but @travisci is awesome. http:\/\/t.co\/8xhLKm3",
  "id" : 97070660500729856,
  "created_at" : "2011-07-29 22:27:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 18, 28 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 65, 72 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Gabriel Horner",
      "screen_name" : "cldwalker",
      "indices" : [ 77, 87 ],
      "id_str" : "19846068",
      "id" : 19846068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 108 ],
      "url" : "http:\/\/t.co\/HnWriee",
      "expanded_url" : "http:\/\/bit.ly\/rahOMx",
      "display_url" : "bit.ly\/rahOMx"
    }, {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/kR2m5M0",
      "expanded_url" : "http:\/\/bit.ly\/oIV8k2",
      "display_url" : "bit.ly\/oIV8k2"
    } ]
  },
  "geo" : { },
  "id_str" : "97050047824396288",
  "text" : "Emotional day for @gemcutter! Moved repos and 2 new maintainers, @sferik and @cldwalker! http:\/\/t.co\/HnWriee http:\/\/t.co\/kR2m5M0",
  "id" : 97050047824396288,
  "created_at" : "2011-07-29 21:05:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97040868460072960",
  "text" : "Current git status: ## master...origin\/master [ahead 86, behind 1568]",
  "id" : 97040868460072960,
  "created_at" : "2011-07-29 20:28:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Schr\u00F6der",
      "screen_name" : "phoet",
      "indices" : [ 0, 6 ],
      "id_str" : "14339524",
      "id" : 14339524
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 41, 51 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 74 ],
      "url" : "http:\/\/t.co\/JmCwt5T",
      "expanded_url" : "http:\/\/github.com\/rubygems\/gemcutter",
      "display_url" : "github.com\/rubygems\/gemcu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "96968887559663617",
  "geo" : { },
  "id_str" : "97012372182536192",
  "in_reply_to_user_id" : 14339524,
  "text" : "@phoet i agree, you should contribute to @gemcutter :) http:\/\/t.co\/JmCwt5T",
  "id" : 97012372182536192,
  "in_reply_to_status_id" : 96968887559663617,
  "created_at" : "2011-07-29 18:35:26 +0000",
  "in_reply_to_screen_name" : "phoet",
  "in_reply_to_user_id_str" : "14339524",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 27, 33 ],
      "id_str" : "1438261",
      "id" : 1438261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http:\/\/t.co\/IjcBl1I",
      "expanded_url" : "http:\/\/www.justin.tv\/cascadiaruby",
      "display_url" : "justin.tv\/cascadiaruby"
    } ]
  },
  "geo" : { },
  "id_str" : "97011701823713280",
  "text" : "It's probably just me, but @atmos sounds like The Dude over the livestream:  http:\/\/t.co\/IjcBl1I",
  "id" : 97011701823713280,
  "created_at" : "2011-07-29 18:32:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "indices" : [ 0, 13 ],
      "id_str" : "1341781",
      "id" : 1341781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96993129881808896",
  "geo" : { },
  "id_str" : "97006563914555393",
  "in_reply_to_user_id" : 1341781,
  "text" : "@gilesgoatboy have you tried bundler 1.1.pre?",
  "id" : 97006563914555393,
  "in_reply_to_status_id" : 96993129881808896,
  "created_at" : "2011-07-29 18:12:21 +0000",
  "in_reply_to_screen_name" : "gilesgoatboy",
  "in_reply_to_user_id_str" : "1341781",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 31 ],
      "url" : "http:\/\/t.co\/IPIde3b",
      "expanded_url" : "https:\/\/img.skitch.com\/20110729-jik16ur4spa35g1cn1dr7rip84.png",
      "display_url" : "img.skitch.com\/20110729-jik16\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "97001816197300224",
  "geo" : { },
  "id_str" : "97005323184910336",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove http:\/\/t.co\/IPIde3b",
  "id" : 97005323184910336,
  "in_reply_to_status_id" : 97001816197300224,
  "created_at" : "2011-07-29 18:07:25 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96976637115113473",
  "geo" : { },
  "id_str" : "96976947254542336",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv i long for Mr. Burgundy though :( also, i dont have your gtalk anymore, who am I supposed to paste terrible things to",
  "id" : 96976947254542336,
  "in_reply_to_status_id" : 96976637115113473,
  "created_at" : "2011-07-29 16:14:40 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 0, 12 ],
      "id_str" : "517029319",
      "id" : 517029319
    }, {
      "name" : "Luis Lavena",
      "screen_name" : "luislavena",
      "indices" : [ 79, 90 ],
      "id_str" : "16891327",
      "id" : 16891327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96975356908675072",
  "text" : "@seacreature make sure you get notifications for new issues, thats good enough @luislavena has been doing good first-line support too! :D",
  "id" : 96975356908675072,
  "created_at" : "2011-07-29 16:08:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 24 ],
      "url" : "http:\/\/t.co\/dG7dYA4",
      "expanded_url" : "http:\/\/www.jetblue.com\/bluepass\/",
      "display_url" : "jetblue.com\/bluepass\/"
    } ]
  },
  "geo" : { },
  "id_str" : "96975123059441664",
  "text" : "Wow: http:\/\/t.co\/dG7dYA4",
  "id" : 96975123059441664,
  "created_at" : "2011-07-29 16:07:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renae Bair",
      "screen_name" : "renaebair",
      "indices" : [ 0, 10 ],
      "id_str" : "14945269",
      "id" : 14945269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96957582069088257",
  "geo" : { },
  "id_str" : "96958201991409664",
  "in_reply_to_user_id" : 14945269,
  "text" : "@renaebair thanks! Perhaps winter\/next summer, just bad timing this year...something else is a little more important ;)",
  "id" : 96958201991409664,
  "in_reply_to_status_id" : 96957582069088257,
  "created_at" : "2011-07-29 15:00:11 +0000",
  "in_reply_to_screen_name" : "renaebair",
  "in_reply_to_user_id_str" : "14945269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96955070918303744",
  "geo" : { },
  "id_str" : "96955768573657088",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape robotechnoviking?",
  "id" : 96955768573657088,
  "in_reply_to_status_id" : 96955070918303744,
  "created_at" : "2011-07-29 14:50:31 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renae Bair",
      "screen_name" : "renaebair",
      "indices" : [ 0, 10 ],
      "id_str" : "14945269",
      "id" : 14945269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96950972781297664",
  "geo" : { },
  "id_str" : "96955652169146368",
  "in_reply_to_user_id" : 14945269,
  "text" : "@renaebair i've begged but @ablissfulgal thinks it's too close to the wedding :( (and she could come too! :( )",
  "id" : 96955652169146368,
  "in_reply_to_status_id" : 96950972781297664,
  "created_at" : "2011-07-29 14:50:03 +0000",
  "in_reply_to_screen_name" : "renaebair",
  "in_reply_to_user_id_str" : "14945269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96941436754337792",
  "text" : "Step 1: Publish blog post about nil. Step 2: ?????? Step 3: NERDRAGE!!!!!!",
  "id" : 96941436754337792,
  "created_at" : "2011-07-29 13:53:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Ledet",
      "screen_name" : "chrisledet",
      "indices" : [ 0, 11 ],
      "id_str" : "12523492",
      "id" : 12523492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96934018083328002",
  "geo" : { },
  "id_str" : "96937671124992000",
  "in_reply_to_user_id" : 12523492,
  "text" : "@chrisledet new raid entirely...I remember taking down MC rag (and ony, and nef) for the first time and it was pretty much the same reaction",
  "id" : 96937671124992000,
  "in_reply_to_status_id" : 96934018083328002,
  "created_at" : "2011-07-29 13:38:36 +0000",
  "in_reply_to_screen_name" : "chrisledet",
  "in_reply_to_user_id_str" : "12523492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96937440492793856",
  "text" : "http:\/\/nytimes.com\/skimmer has been awesome for commutes, especially underground. More of this, please, internets!",
  "id" : 96937440492793856,
  "created_at" : "2011-07-29 13:37:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 49 ],
      "url" : "http:\/\/t.co\/nuWla1O",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Pgyas2TtGQM",
      "display_url" : "youtube.com\/watch?v=Pgyas2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "96923795297800193",
  "text" : "Current ex-WoW player status: http:\/\/t.co\/nuWla1O",
  "id" : 96923795297800193,
  "created_at" : "2011-07-29 12:43:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerred",
      "screen_name" : "justicefries",
      "indices" : [ 0, 13 ],
      "id_str" : "188906158",
      "id" : 188906158
    }, {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 18, 26 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96711213458796544",
  "geo" : { },
  "id_str" : "96711925622259712",
  "in_reply_to_user_id" : 188906158,
  "text" : "@justicefries ask @ddollar! I only have \/time and \/home so I don't go bonkers again :)",
  "id" : 96711925622259712,
  "in_reply_to_status_id" : 96711213458796544,
  "created_at" : "2011-07-28 22:41:34 +0000",
  "in_reply_to_screen_name" : "justicefries",
  "in_reply_to_user_id_str" : "188906158",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96642964473921536",
  "text" : "What's even MORE stupid about this google situation is that a Google Account != Google Profile. That's some seriously stupid shit.",
  "id" : 96642964473921536,
  "created_at" : "2011-07-28 18:07:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 0, 9 ],
      "id_str" : "14925480",
      "id" : 14925480
    }, {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 10, 20 ],
      "id_str" : "9980812",
      "id" : 9980812
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 128, 138 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96615482798514178",
  "geo" : { },
  "id_str" : "96641036645961729",
  "in_reply_to_user_id" : 14925480,
  "text" : "@nirvdrum @igrigorik the gemspec is not the place for that data. i'd love an rdoc.info style site for changelogs, separate from @gemcutter",
  "id" : 96641036645961729,
  "in_reply_to_status_id" : 96615482798514178,
  "created_at" : "2011-07-28 17:59:53 +0000",
  "in_reply_to_screen_name" : "nirvdrum",
  "in_reply_to_user_id_str" : "14925480",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96608420198744064",
  "text" : "\"Oops... you need a Google profile to use this feature.\nGoogle Profiles is not available for your organization.\" THIS IS STUPID",
  "id" : 96608420198744064,
  "created_at" : "2011-07-28 15:50:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96447760718512129",
  "geo" : { },
  "id_str" : "96586201141743616",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie sounds awesome! i need to make more rails\/carts.",
  "id" : 96586201141743616,
  "in_reply_to_status_id" : 96447760718512129,
  "created_at" : "2011-07-28 14:21:59 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 73 ],
      "url" : "http:\/\/t.co\/79P0obZ",
      "expanded_url" : "http:\/\/www.springerlink.com\/content\/y43r704467577074\/",
      "display_url" : "springerlink.com\/content\/y43r70\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "96585982140354561",
  "text" : "In today's \"feel nervous and awkward all over\" moment http:\/\/t.co\/79P0obZ",
  "id" : 96585982140354561,
  "created_at" : "2011-07-28 14:21:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neil tron",
      "screen_name" : "realtron",
      "indices" : [ 0, 9 ],
      "id_str" : "43989943",
      "id" : 43989943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96205881116590080",
  "geo" : { },
  "id_str" : "96556499584827392",
  "in_reply_to_user_id" : 43989943,
  "text" : "@realtron i dont see anything broken, this is really not a helpful bug report. what browser\/os and have a screenshot?",
  "id" : 96556499584827392,
  "in_reply_to_status_id" : 96205881116590080,
  "created_at" : "2011-07-28 12:23:58 +0000",
  "in_reply_to_screen_name" : "realtron",
  "in_reply_to_user_id_str" : "43989943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/71xXJwT",
      "expanded_url" : "http:\/\/kille6.deviantart.com\/art\/OPEN-YOUR-EYES-155632472",
      "display_url" : "kille6.deviantart.com\/art\/OPEN-YOUR-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "96556245527437312",
  "text" : "Current status: http:\/\/t.co\/71xXJwT",
  "id" : 96556245527437312,
  "created_at" : "2011-07-28 12:22:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96436813144662016",
  "geo" : { },
  "id_str" : "96441299862945792",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman I applaud your effort though, but to see change, especially as an outsider for a few years now...I just can't see that happening",
  "id" : 96441299862945792,
  "in_reply_to_status_id" : 96436813144662016,
  "created_at" : "2011-07-28 04:46:12 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96436813144662016",
  "geo" : { },
  "id_str" : "96441118887116800",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman this feels like an uphill battle for a company used to long product cycles and retail-ready releases",
  "id" : 96441118887116800,
  "in_reply_to_status_id" : 96436813144662016,
  "created_at" : "2011-07-28 04:45:29 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96437702819454976",
  "geo" : { },
  "id_str" : "96439753389510656",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant minecraft. Basically, $20 for infinite legos. And zombies, circuits, multiplayer, etc.",
  "id" : 96439753389510656,
  "in_reply_to_status_id" : 96437702819454976,
  "created_at" : "2011-07-28 04:40:03 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96436431915986944",
  "text" : "Probably needs a few torches, maybe a neat overhang thing too.",
  "id" : 96436431915986944,
  "created_at" : "2011-07-28 04:26:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 76, 83 ],
      "id_str" : "3928731",
      "id" : 3928731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/fWxLCUA",
      "expanded_url" : "https:\/\/img.skitch.com\/20110728-tejp9fcruya38dwfgnxik1jstu.png",
      "display_url" : "img.skitch.com\/20110728-tejp9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "96436064000016386",
  "text" : "Phew, rubycraft.org build of the night, big southeast tunnel\/road\/bridge to @cssboy's lighthouse and village! http:\/\/t.co\/fWxLCUA",
  "id" : 96436064000016386,
  "created_at" : "2011-07-28 04:25:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96402356538834944",
  "geo" : { },
  "id_str" : "96432774587748352",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad just trying to gain some perspective! end of the day, we're both testing, so wins all around. no nerdrage intended.",
  "id" : 96432774587748352,
  "in_reply_to_status_id" : 96402356538834944,
  "created_at" : "2011-07-28 04:12:19 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96381137001259008",
  "geo" : { },
  "id_str" : "96401504646336512",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad you can change the default build strategy. and yeah, syntax is a meh answer i feel ;)",
  "id" : 96401504646336512,
  "in_reply_to_status_id" : 96381137001259008,
  "created_at" : "2011-07-28 02:08:04 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96370101577711617",
  "geo" : { },
  "id_str" : "96380695789846528",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad what's wrong with factory_girl? Or rather, what does fixjour do better?",
  "id" : 96380695789846528,
  "in_reply_to_status_id" : 96370101577711617,
  "created_at" : "2011-07-28 00:45:23 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 100 ],
      "url" : "http:\/\/t.co\/OJE7LXz",
      "expanded_url" : "https:\/\/img.skitch.com\/20110728-ke8peu2skfg936qhj9m1htxcti.png",
      "display_url" : "img.skitch.com\/20110728-ke8pe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "96343844647473153",
  "text" : "Must he chew every toy *on* me? Look brodog, I'm not going to share it with you. http:\/\/t.co\/OJE7LXz",
  "id" : 96343844647473153,
  "created_at" : "2011-07-27 22:18:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 31 ],
      "url" : "http:\/\/t.co\/KH0n8yG",
      "expanded_url" : "http:\/\/www.startrek.com\/legacy_media\/images\/200307\/la-forge01\/320x240.jpg",
      "display_url" : "startrek.com\/legacy_media\/i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "96340679155920896",
  "geo" : { },
  "id_str" : "96341490611138561",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler http:\/\/t.co\/KH0n8yG",
  "id" : 96341490611138561,
  "in_reply_to_status_id" : 96340679155920896,
  "created_at" : "2011-07-27 22:09:35 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Bob Martin",
      "screen_name" : "unclebobmartin",
      "indices" : [ 0, 15 ],
      "id_str" : "9505092",
      "id" : 9505092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96335794087800833",
  "geo" : { },
  "id_str" : "96336595447316481",
  "in_reply_to_user_id" : 9505092,
  "text" : "@unclebobmartin all of which are hilarious since that's exactly what it helps push forward",
  "id" : 96336595447316481,
  "in_reply_to_status_id" : 96335794087800833,
  "created_at" : "2011-07-27 21:50:08 +0000",
  "in_reply_to_screen_name" : "unclebobmartin",
  "in_reply_to_user_id_str" : "9505092",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Bob Martin",
      "screen_name" : "unclebobmartin",
      "indices" : [ 0, 15 ],
      "id_str" : "9505092",
      "id" : 9505092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96335794087800833",
  "geo" : { },
  "id_str" : "96336479479005184",
  "in_reply_to_user_id" : 9505092,
  "text" : "@unclebobmartin what i've heard: wastes time, doesn't help deliver anything, hard to setup, painful for large apps",
  "id" : 96336479479005184,
  "in_reply_to_status_id" : 96335794087800833,
  "created_at" : "2011-07-27 21:49:41 +0000",
  "in_reply_to_screen_name" : "unclebobmartin",
  "in_reply_to_user_id_str" : "9505092",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Mornini",
      "screen_name" : "tmornini",
      "indices" : [ 0, 9 ],
      "id_str" : "13445732",
      "id" : 13445732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96327266698670080",
  "geo" : { },
  "id_str" : "96328295536263168",
  "in_reply_to_user_id" : 13445732,
  "text" : "@tmornini heh, figured I would set off some alarms. Just noting that it seems silly, support@ or cloudsupport@ would suffice",
  "id" : 96328295536263168,
  "in_reply_to_status_id" : 96327266698670080,
  "created_at" : "2011-07-27 21:17:10 +0000",
  "in_reply_to_screen_name" : "tmornini",
  "in_reply_to_user_id_str" : "13445732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96314748563505153",
  "text" : "\"Email pandas@engineyard.com with your questions or queries.\" seriously?",
  "id" : 96314748563505153,
  "created_at" : "2011-07-27 20:23:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96294530378252288",
  "geo" : { },
  "id_str" : "96294724398354432",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant this really is like a crazy girlfriend",
  "id" : 96294724398354432,
  "in_reply_to_status_id" : 96294530378252288,
  "created_at" : "2011-07-27 19:03:46 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hayes Davis",
      "screen_name" : "hayesdavis",
      "indices" : [ 3, 14 ],
      "id_str" : "5777902",
      "id" : 5777902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96287221895806976",
  "text" : "RT @hayesdavis: it's amazing how quickly a perfectly reasonable campfire can turn into a firehose of animal meme photos.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96286575851343872",
    "text" : "it's amazing how quickly a perfectly reasonable campfire can turn into a firehose of animal meme photos.",
    "id" : 96286575851343872,
    "created_at" : "2011-07-27 18:31:23 +0000",
    "user" : {
      "name" : "Hayes Davis",
      "screen_name" : "hayesdavis",
      "protected" : false,
      "id_str" : "5777902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/69343798\/hayes_in_NO_cropped_normal.png",
      "id" : 5777902,
      "verified" : false
    }
  },
  "id" : 96287221895806976,
  "created_at" : "2011-07-27 18:33:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96233028325609472",
  "text" : "Current status: time bake && say \"ding\"",
  "id" : 96233028325609472,
  "created_at" : "2011-07-27 14:58:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96044432469667840",
  "geo" : { },
  "id_str" : "96055230835331072",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin what did you search for?",
  "id" : 96055230835331072,
  "in_reply_to_status_id" : 96044432469667840,
  "created_at" : "2011-07-27 03:12:06 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95972199512547329",
  "geo" : { },
  "id_str" : "95972570700062720",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu that's a lot of porn",
  "id" : 95972570700062720,
  "in_reply_to_status_id" : 95972199512547329,
  "created_at" : "2011-07-26 21:43:38 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 3, 10 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http:\/\/t.co\/xMSpeNj",
      "expanded_url" : "https:\/\/github.com\/rubygems\/gemcutter\/wiki\/API-v2",
      "display_url" : "github.com\/rubygems\/gemcu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "95971185606656002",
  "text" : "RT @sferik: After spending two weeks improving the RubyGems.org API, I've proposed some changes for v2: http:\/\/t.co\/xMSpeNj Comments wel ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 111 ],
        "url" : "http:\/\/t.co\/xMSpeNj",
        "expanded_url" : "https:\/\/github.com\/rubygems\/gemcutter\/wiki\/API-v2",
        "display_url" : "github.com\/rubygems\/gemcu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "95969266989416448",
    "text" : "After spending two weeks improving the RubyGems.org API, I've proposed some changes for v2: http:\/\/t.co\/xMSpeNj Comments welcome!",
    "id" : 95969266989416448,
    "created_at" : "2011-07-26 21:30:30 +0000",
    "user" : {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "protected" : false,
      "id_str" : "7505382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567932260847206401\/ErQwT5za_normal.jpeg",
      "id" : 7505382,
      "verified" : false
    }
  },
  "id" : 95971185606656002,
  "created_at" : "2011-07-26 21:38:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 46 ],
      "url" : "http:\/\/t.co\/W8h9cgW",
      "expanded_url" : "http:\/\/contrastempire.com\/",
      "display_url" : "contrastempire.com"
    } ]
  },
  "geo" : { },
  "id_str" : "95967196039233536",
  "text" : "Really tempted to register http:\/\/t.co\/W8h9cgW with a big manifesto about font color written in white text on a white background.",
  "id" : 95967196039233536,
  "created_at" : "2011-07-26 21:22:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 88, 98 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95952226845081600",
  "text" : "Well, I have no idea where the google analytics accounts for any of my sites (including @gemcutter) have gone thanks to the migration crap.",
  "id" : 95952226845081600,
  "created_at" : "2011-07-26 20:22:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95930428493541376",
  "text" : "Dumb thought: would it be possible to track a  twitter user's commute size by looking at their gps location on tweets from work\/home hours?",
  "id" : 95930428493541376,
  "created_at" : "2011-07-26 18:56:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Poots",
      "screen_name" : "pootsbook",
      "indices" : [ 0, 10 ],
      "id_str" : "36464145",
      "id" : 36464145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http:\/\/t.co\/D88VQBp",
      "expanded_url" : "http:\/\/nethack.wikia.com\/wiki\/Source_diving",
      "display_url" : "nethack.wikia.com\/wiki\/Source_di\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "95920314747338752",
  "geo" : { },
  "id_str" : "95923493643878400",
  "in_reply_to_user_id" : 36464145,
  "text" : "@pootsbook not too original, from one of my favorite games' wiki: http:\/\/t.co\/D88VQBp",
  "id" : 95923493643878400,
  "in_reply_to_status_id" : 95920314747338752,
  "created_at" : "2011-07-26 18:28:37 +0000",
  "in_reply_to_screen_name" : "pootsbook",
  "in_reply_to_user_id_str" : "36464145",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2192() \u007B Robertt \u007D",
      "screen_name" : "robertodecurnex",
      "indices" : [ 0, 16 ],
      "id_str" : "63124269",
      "id" : 63124269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95883863544438784",
  "geo" : { },
  "id_str" : "95885742261272576",
  "in_reply_to_user_id" : 63124269,
  "text" : "@robertodecurnex it's working here (on tumblr)...maybe your DNS is screwy. also is that your wolf\/husky?",
  "id" : 95885742261272576,
  "in_reply_to_status_id" : 95883863544438784,
  "created_at" : "2011-07-26 15:58:37 +0000",
  "in_reply_to_screen_name" : "robertodecurnex",
  "in_reply_to_user_id_str" : "63124269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http:\/\/t.co\/BIOSwjE",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/8087279685\/use-capybara-on-any-html-fragment-or-page",
      "display_url" : "robots.thoughtbot.com\/post\/808727968\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "95877443772088321",
  "text" : "RT @thoughtbot: Capybaras, capybaras everywhere in your test suite http:\/\/t.co\/BIOSwjE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 70 ],
        "url" : "http:\/\/t.co\/BIOSwjE",
        "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/8087279685\/use-capybara-on-any-html-fragment-or-page",
        "display_url" : "robots.thoughtbot.com\/post\/808727968\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "95877372875771904",
    "text" : "Capybaras, capybaras everywhere in your test suite http:\/\/t.co\/BIOSwjE",
    "id" : 95877372875771904,
    "created_at" : "2011-07-26 15:25:21 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 95877443772088321,
  "created_at" : "2011-07-26 15:25:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95864801766551552",
  "geo" : { },
  "id_str" : "95877000589352960",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant that is totally not a word",
  "id" : 95877000589352960,
  "in_reply_to_status_id" : 95864801766551552,
  "created_at" : "2011-07-26 15:23:52 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mbta",
      "indices" : [ 67, 72 ]
    }, {
      "text" : "awesome",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "notreally",
      "indices" : [ 83, 93 ]
    }, {
      "text" : "fml",
      "indices" : [ 94, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95863821725474816",
  "text" : "An hour and a half after I left my apartment, still waiting on the #mbta. #awesome #notreally #fml",
  "id" : 95863821725474816,
  "created_at" : "2011-07-26 14:31:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mbta",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95860314217775107",
  "text" : "#mbta facepalm :(",
  "id" : 95860314217775107,
  "created_at" : "2011-07-26 14:17:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 0, 13 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95664357945520129",
  "geo" : { },
  "id_str" : "95665005281816576",
  "in_reply_to_user_id" : 11587602,
  "text" : "@wayneeseguin it's automatic enough, esp since it involves a cap deploy, etc. one rake task to parse rubyforge, upload, then commit\/deploy.",
  "id" : 95665005281816576,
  "in_reply_to_status_id" : 95664357945520129,
  "created_at" : "2011-07-26 01:21:29 +0000",
  "in_reply_to_screen_name" : "wayneeseguin",
  "in_reply_to_user_id_str" : "11587602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 0, 13 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95660282407436288",
  "geo" : { },
  "id_str" : "95664143553671169",
  "in_reply_to_user_id" : 11587602,
  "text" : "@wayneeseguin it doesn't propagate, i have to update it manually. doing so now.",
  "id" : 95664143553671169,
  "in_reply_to_status_id" : 95660282407436288,
  "created_at" : "2011-07-26 01:18:03 +0000",
  "in_reply_to_screen_name" : "wayneeseguin",
  "in_reply_to_user_id_str" : "11587602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 101 ],
      "url" : "http:\/\/t.co\/oWI47PU",
      "expanded_url" : "http:\/\/qrush.tumblr.com\/post\/330597406\/who-ate-the-damn-pizza-rolls",
      "display_url" : "qrush.tumblr.com\/post\/330597406\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "95663566958510080",
  "text" : "791 notes and counting from a post over a year and a half old. tumblr is strange. http:\/\/t.co\/oWI47PU",
  "id" : 95663566958510080,
  "created_at" : "2011-07-26 01:15:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95636394701111296",
  "geo" : { },
  "id_str" : "95639014819889152",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking YER A WIZARD HARRY",
  "id" : 95639014819889152,
  "in_reply_to_status_id" : 95636394701111296,
  "created_at" : "2011-07-25 23:38:12 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 13, 25 ],
      "id_str" : "6556972",
      "id" : 6556972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95575419159461889",
  "geo" : { },
  "id_str" : "95589240540381184",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @techpickles oh snap :(((",
  "id" : 95589240540381184,
  "in_reply_to_status_id" : 95575419159461889,
  "created_at" : "2011-07-25 20:20:25 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95584861779279872",
  "geo" : { },
  "id_str" : "95585056072011776",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh lol php",
  "id" : 95585056072011776,
  "in_reply_to_status_id" : 95584861779279872,
  "created_at" : "2011-07-25 20:03:47 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95572517284085760",
  "geo" : { },
  "id_str" : "95577446061047809",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking shut up, I got my degree there",
  "id" : 95577446061047809,
  "in_reply_to_status_id" : 95572517284085760,
  "created_at" : "2011-07-25 19:33:33 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 4, 11 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95509279607496704",
  "text" : "Hey @github, can you clean up the refs\/pull part of the git repo when pull requests are merged\/closed? `git ls-remote` is really noisy :(",
  "id" : 95509279607496704,
  "created_at" : "2011-07-25 15:02:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Mills",
      "screen_name" : "Remear",
      "indices" : [ 0, 7 ],
      "id_str" : "94150012",
      "id" : 94150012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 87 ],
      "url" : "http:\/\/t.co\/RNUML3d",
      "expanded_url" : "http:\/\/github.com\/rubygems\/rubygems",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "95363574200926208",
  "geo" : { },
  "id_str" : "95502318656688129",
  "in_reply_to_user_id" : 94150012,
  "text" : "@Remear looks like it can only do ~1 at a time. patches welcome! :) http:\/\/t.co\/RNUML3d",
  "id" : 95502318656688129,
  "in_reply_to_status_id" : 95363574200926208,
  "created_at" : "2011-07-25 14:35:01 +0000",
  "in_reply_to_screen_name" : "Remear",
  "in_reply_to_user_id_str" : "94150012",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Grimfelt",
      "screen_name" : "grimen",
      "indices" : [ 0, 7 ],
      "id_str" : "14269242",
      "id" : 14269242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95277526703812608",
  "geo" : { },
  "id_str" : "95311847175106560",
  "in_reply_to_user_id" : 14269242,
  "text" : "@grimen you can't repush versions. If you yanked the only version of a gem, bump the number and push to ownership back",
  "id" : 95311847175106560,
  "in_reply_to_status_id" : 95277526703812608,
  "created_at" : "2011-07-25 01:58:09 +0000",
  "in_reply_to_screen_name" : "grimen",
  "in_reply_to_user_id_str" : "14269242",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "liammclennan",
      "screen_name" : "liammclennan",
      "indices" : [ 0, 13 ],
      "id_str" : "15992648",
      "id" : 15992648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95259550852198400",
  "geo" : { },
  "id_str" : "95263977935872000",
  "in_reply_to_user_id" : 15992648,
  "text" : "@liammclennan -r is for require, it requires rubygems, more specifically 'ubygems.rb' does",
  "id" : 95263977935872000,
  "in_reply_to_status_id" : 95259550852198400,
  "created_at" : "2011-07-24 22:47:56 +0000",
  "in_reply_to_screen_name" : "liammclennan",
  "in_reply_to_user_id_str" : "15992648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 0, 12 ],
      "id_str" : "517029319",
      "id" : 517029319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95238721909174272",
  "text" : "@seacreature I meant for rbmu",
  "id" : 95238721909174272,
  "created_at" : "2011-07-24 21:07:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 0, 12 ],
      "id_str" : "517029319",
      "id" : 517029319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95226137432686592",
  "text" : "@seacreature how does one apply?",
  "id" : 95226137432686592,
  "created_at" : "2011-07-24 20:17:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Helmkamp",
      "screen_name" : "brynary",
      "indices" : [ 0, 8 ],
      "id_str" : "2049071",
      "id" : 2049071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95209462599647232",
  "geo" : { },
  "id_str" : "95223898764873728",
  "in_reply_to_user_id" : 2049071,
  "text" : "@brynary seriously, and it never loses history. Best $3\/mo I spend.",
  "id" : 95223898764873728,
  "in_reply_to_status_id" : 95209462599647232,
  "created_at" : "2011-07-24 20:08:41 +0000",
  "in_reply_to_screen_name" : "brynary",
  "in_reply_to_user_id_str" : "2049071",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 4, 12 ],
      "id_str" : "839931",
      "id" : 839931
    }, {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 72, 79 ],
      "id_str" : "3928731",
      "id" : 3928731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94932217867935744",
  "text" : "Hey @ddollar can you add the whitelist to the rubycraft.org perms list? @cssboy can't get in",
  "id" : 94932217867935744,
  "created_at" : "2011-07-24 00:49:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "lawrence wang",
      "screen_name" : "levity",
      "indices" : [ 8, 15 ],
      "id_str" : "819357",
      "id" : 819357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94858902541312000",
  "geo" : { },
  "id_str" : "94882193331060736",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik @levity no, it's actually rubygems :(((",
  "id" : 94882193331060736,
  "in_reply_to_status_id" : 94858902541312000,
  "created_at" : "2011-07-23 21:30:52 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94857416100950016",
  "geo" : { },
  "id_str" : "94858120068743168",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove automatic failover is webscale",
  "id" : 94858120068743168,
  "in_reply_to_status_id" : 94857416100950016,
  "created_at" : "2011-07-23 19:55:12 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 0, 8 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94821629040922624",
  "geo" : { },
  "id_str" : "94830325175300097",
  "in_reply_to_user_id" : 839931,
  "text" : "@ddollar yeah i would either reset or move the spawn for everyone *very* far",
  "id" : 94830325175300097,
  "in_reply_to_status_id" : 94821629040922624,
  "created_at" : "2011-07-23 18:04:46 +0000",
  "in_reply_to_screen_name" : "ddollar",
  "in_reply_to_user_id_str" : "839931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 0, 8 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94821629040922624",
  "geo" : { },
  "id_str" : "94829398800351234",
  "in_reply_to_user_id" : 839931,
  "text" : "@ddollar reset was kind of half-assed, a lot of my wreckage is around :\/",
  "id" : 94829398800351234,
  "in_reply_to_status_id" : 94821629040922624,
  "created_at" : "2011-07-23 18:01:05 +0000",
  "in_reply_to_screen_name" : "ddollar",
  "in_reply_to_user_id_str" : "839931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Helmkamp",
      "screen_name" : "brynary",
      "indices" : [ 0, 8 ],
      "id_str" : "2049071",
      "id" : 2049071
    }, {
      "name" : "IRCCloud",
      "screen_name" : "IRCCloud",
      "indices" : [ 17, 26 ],
      "id_str" : "171845650",
      "id" : 171845650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94797170934419457",
  "geo" : { },
  "id_str" : "94808551318495232",
  "in_reply_to_user_id" : 2049071,
  "text" : "@brynary want an @irccloud invite instead?",
  "id" : 94808551318495232,
  "in_reply_to_status_id" : 94797170934419457,
  "created_at" : "2011-07-23 16:38:14 +0000",
  "in_reply_to_screen_name" : "brynary",
  "in_reply_to_user_id_str" : "2049071",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94808397320433665",
  "text" : "A simple \"hello world\" for a chrome extension was ridiculously easy. Pleasantly surprised.",
  "id" : 94808397320433665,
  "created_at" : "2011-07-23 16:37:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 0, 8 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94792591505244160",
  "in_reply_to_user_id" : 839931,
  "text" : "@ddollar perhaps i could just avoid the old area :)",
  "id" : 94792591505244160,
  "created_at" : "2011-07-23 15:34:49 +0000",
  "in_reply_to_screen_name" : "ddollar",
  "in_reply_to_user_id_str" : "839931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 4, 12 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94792315205468160",
  "text" : "Hey @ddollar I kind of want to reseed\/restart rubycraft.org. Stop the admin giving madness and just...restart.",
  "id" : 94792315205468160,
  "created_at" : "2011-07-23 15:33:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94780037559095296",
  "geo" : { },
  "id_str" : "94780694127067137",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil if you do a shitload of relational\/association queries, it's going to be terrible. SQL is good for relational data, go figure",
  "id" : 94780694127067137,
  "in_reply_to_status_id" : 94780037559095296,
  "created_at" : "2011-07-23 14:47:33 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94775697557565441",
  "geo" : { },
  "id_str" : "94778268770766848",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil also the mongo ruby driver is really good, you don't have to write the equivalent of sql much (json\/js queries) much",
  "id" : 94778268770766848,
  "in_reply_to_status_id" : 94775697557565441,
  "created_at" : "2011-07-23 14:37:54 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94775697557565441",
  "geo" : { },
  "id_str" : "94777570800844801",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil mongoid lets you do relational queries\/associations too easily. It's a document store, treat it as one",
  "id" : 94777570800844801,
  "in_reply_to_status_id" : 94775697557565441,
  "created_at" : "2011-07-23 14:35:08 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94575459509088256",
  "geo" : { },
  "id_str" : "94741440214736896",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil mongoid. If possible though, just use the straight up mongo driver.",
  "id" : 94741440214736896,
  "in_reply_to_status_id" : 94575459509088256,
  "created_at" : "2011-07-23 12:11:34 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J3SSL33",
      "screen_name" : "J3SSL33",
      "indices" : [ 0, 8 ],
      "id_str" : "15002594",
      "id" : 15002594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94728045323231232",
  "geo" : { },
  "id_str" : "94741176682418176",
  "in_reply_to_user_id" : 15002594,
  "text" : "@J3SSL33 there's been problems with cloudfront to ec2 dns...no idea what's up there :(",
  "id" : 94741176682418176,
  "in_reply_to_status_id" : 94728045323231232,
  "created_at" : "2011-07-23 12:10:31 +0000",
  "in_reply_to_screen_name" : "J3SSL33",
  "in_reply_to_user_id_str" : "15002594",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 0, 12 ],
      "id_str" : "248477732",
      "id" : 248477732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94556786773868546",
  "geo" : { },
  "id_str" : "94559537683644416",
  "in_reply_to_user_id" : 248477732,
  "text" : "@ecarlsen912 current husky status http:\/\/yfrog.com\/h2kjblmj",
  "id" : 94559537683644416,
  "in_reply_to_status_id" : 94556786773868546,
  "created_at" : "2011-07-23 00:08:45 +0000",
  "in_reply_to_screen_name" : "ecarlsen912",
  "in_reply_to_user_id_str" : "248477732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 18, 28 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94518631773384704",
  "text" : "Guess what killed @gemcutter download counts? \"You have already activated rake 0.8.7, but your Gemfile requires rake 0.9.2.\"",
  "id" : 94518631773384704,
  "created_at" : "2011-07-22 21:26:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94502345718775808",
  "geo" : { },
  "id_str" : "94514720899465216",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky too much salty water i think",
  "id" : 94514720899465216,
  "in_reply_to_status_id" : 94502345718775808,
  "created_at" : "2011-07-22 21:10:40 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 10, 18 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94475031551291393",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits @sikachu you can add as many layers of shit on top of it, it's still going to boil down to a shitpile waste of time for everyone",
  "id" : 94475031551291393,
  "created_at" : "2011-07-22 18:32:57 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 10, 18 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94472980851204096",
  "geo" : { },
  "id_str" : "94474756983750656",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits @sikachu i'm still convinced CSS is the wrong solution. it's terrible, no way to fix it without something completely different",
  "id" : 94474756983750656,
  "in_reply_to_status_id" : 94472980851204096,
  "created_at" : "2011-07-22 18:31:51 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94426594432659457",
  "text" : "lots of bitching about the downloads issue, no offers to help. thanks everyone.",
  "id" : 94426594432659457,
  "created_at" : "2011-07-22 15:20:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serg Podtynnyi",
      "screen_name" : "shtirlic",
      "indices" : [ 0, 9 ],
      "id_str" : "8439592",
      "id" : 8439592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94395818622193664",
  "geo" : { },
  "id_str" : "94404661674647552",
  "in_reply_to_user_id" : 8439592,
  "text" : "@shtirlic yes, havent had time to fix it.",
  "id" : 94404661674647552,
  "in_reply_to_status_id" : 94395818622193664,
  "created_at" : "2011-07-22 13:53:19 +0000",
  "in_reply_to_screen_name" : "shtirlic",
  "in_reply_to_user_id_str" : "8439592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 0, 8 ],
      "id_str" : "9337082",
      "id" : 9337082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94402247403913217",
  "geo" : { },
  "id_str" : "94403121865965570",
  "in_reply_to_user_id" : 9337082,
  "text" : "@godfoca telnet nethack.alt.org, cmon :) http:\/\/alt.org\/nethack\/player-stats.php?player=DoctorNick",
  "id" : 94403121865965570,
  "in_reply_to_status_id" : 94402247403913217,
  "created_at" : "2011-07-22 13:47:13 +0000",
  "in_reply_to_screen_name" : "godfoca",
  "in_reply_to_user_id_str" : "9337082",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94393301884612608",
  "text" : "OBLIGATORY GLOBAL WARMING JOKE IN THE MIDDLE OF SUMMER NYUK NYUK NYUK",
  "id" : 94393301884612608,
  "created_at" : "2011-07-22 13:08:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Eppstein",
      "screen_name" : "chriseppstein",
      "indices" : [ 0, 14 ],
      "id_str" : "14148091",
      "id" : 14148091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94198116655448065",
  "geo" : { },
  "id_str" : "94211199230685184",
  "in_reply_to_user_id" : 14148091,
  "text" : "@chriseppstein our counts are off, its not a download spike",
  "id" : 94211199230685184,
  "in_reply_to_status_id" : 94198116655448065,
  "created_at" : "2011-07-22 01:04:34 +0000",
  "in_reply_to_screen_name" : "chriseppstein",
  "in_reply_to_user_id_str" : "14148091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seivan Heidari",
      "screen_name" : "Seivanheidari",
      "indices" : [ 0, 14 ],
      "id_str" : "93118049",
      "id" : 93118049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94117350625910784",
  "geo" : { },
  "id_str" : "94119603353034752",
  "in_reply_to_user_id" : 93118049,
  "text" : "@Seivanheidari probably because it runs KEYS * (facepalm)",
  "id" : 94119603353034752,
  "in_reply_to_status_id" : 94117350625910784,
  "created_at" : "2011-07-21 19:00:36 +0000",
  "in_reply_to_screen_name" : "Seivanheidari",
  "in_reply_to_user_id_str" : "93118049",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0412\u0441\u0435\u0441\u043B\u0430\u0432 \u041F\u043E\u043A\u0440\u043E\u0432\u0441\u043A\u0438\u0439",
      "screen_name" : "dan_sosedoff",
      "indices" : [ 0, 13 ],
      "id_str" : "203110801",
      "id" : 203110801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94092438683136000",
  "geo" : { },
  "id_str" : "94116562277117952",
  "in_reply_to_user_id" : 54645322,
  "text" : "@dan_sosedoff oh geez :(",
  "id" : 94116562277117952,
  "in_reply_to_status_id" : 94092438683136000,
  "created_at" : "2011-07-21 18:48:31 +0000",
  "in_reply_to_screen_name" : "sosedoff",
  "in_reply_to_user_id_str" : "54645322",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94116389463400448",
  "text" : "Dumb question: If you're using Resque, is there any reason *not* to use resque-web ?",
  "id" : 94116389463400448,
  "created_at" : "2011-07-21 18:47:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxim Chernyak",
      "screen_name" : "hakunin",
      "indices" : [ 3, 11 ],
      "id_str" : "11622052",
      "id" : 11622052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94010171080183808",
  "text" : "RT @hakunin: My (sleepless-nights-induced) view of developers as mages of creation and alteration. http:\/\/news.ycombinator.com\/item?id=2 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "93942681390161920",
    "text" : "My (sleepless-nights-induced) view of developers as mages of creation and alteration. http:\/\/news.ycombinator.com\/item?id=2788707",
    "id" : 93942681390161920,
    "created_at" : "2011-07-21 07:17:35 +0000",
    "user" : {
      "name" : "Maxim Chernyak",
      "screen_name" : "hakunin",
      "protected" : false,
      "id_str" : "11622052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544339044440633346\/LarUdivM_normal.png",
      "id" : 11622052,
      "verified" : false
    }
  },
  "id" : 94010171080183808,
  "created_at" : "2011-07-21 11:45:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93950981250875392",
  "geo" : { },
  "id_str" : "94007041709977600",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal is this on rubycraft.org? And if not, cmon :)",
  "id" : 94007041709977600,
  "in_reply_to_status_id" : 93950981250875392,
  "created_at" : "2011-07-21 11:33:19 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93897622728867840",
  "geo" : { },
  "id_str" : "93899408692879360",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats ooh, duh. Thanks.",
  "id" : 93899408692879360,
  "in_reply_to_status_id" : 93897622728867840,
  "created_at" : "2011-07-21 04:25:38 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93896767493521408",
  "geo" : { },
  "id_str" : "93897409905700864",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats no good docs of that method that I could find, even went spelunking around actionpack",
  "id" : 93897409905700864,
  "in_reply_to_status_id" : 93896767493521408,
  "created_at" : "2011-07-21 04:17:41 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "call",
      "indices" : [ 46, 51 ]
    }, {
      "text" : "render",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93896767493521408",
  "geo" : { },
  "id_str" : "93897306390282241",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats yeah I figured that out, but once you #call is there an easy way to give the response back to the controller? (with #render?)",
  "id" : 93897306390282241,
  "in_reply_to_status_id" : 93896767493521408,
  "created_at" : "2011-07-21 04:17:17 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93895783287496705",
  "geo" : { },
  "id_str" : "93896170333671424",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats that will work too...was hoping to use ActionController but I think I can get away without it",
  "id" : 93896170333671424,
  "in_reply_to_status_id" : 93895783287496705,
  "created_at" : "2011-07-21 04:12:46 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93894025689579520",
  "geo" : { },
  "id_str" : "93894559632850944",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats use the controller for auth and drop down to the rack app if it passes. Probably won't work, too many routes in the rack app",
  "id" : 93894559632850944,
  "in_reply_to_status_id" : 93894025689579520,
  "created_at" : "2011-07-21 04:06:22 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 97, 104 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 105, 114 ],
      "id_str" : "616163",
      "id" : 616163
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 115, 123 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 92 ],
      "url" : "http:\/\/t.co\/0Y4fnFq",
      "expanded_url" : "https:\/\/gist.github.com\/1096435",
      "display_url" : "gist.github.com\/1096435"
    } ]
  },
  "geo" : { },
  "id_str" : "93885598405902336",
  "text" : "Is it possible to call a Rack app from within a Rails controller action? http:\/\/t.co\/0Y4fnFq \/cc @wycats @joshpeek @sikachu",
  "id" : 93885598405902336,
  "created_at" : "2011-07-21 03:30:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93779691403616256",
  "geo" : { },
  "id_str" : "93780435334729728",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt \"Fuck ruby\" (I've heard it's pretty popular this year)",
  "id" : 93780435334729728,
  "in_reply_to_status_id" : 93779691403616256,
  "created_at" : "2011-07-20 20:32:52 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93778575454507008",
  "geo" : { },
  "id_str" : "93779517302259712",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw it's so shady. the equivalent of throwing your credit card down a sewer and hoping it pays for dinner",
  "id" : 93779517302259712,
  "in_reply_to_status_id" : 93778575454507008,
  "created_at" : "2011-07-20 20:29:13 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93777149768634368",
  "geo" : { },
  "id_str" : "93778045827153920",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold seriously though, just trolling :) you could write the tests too! ;)",
  "id" : 93778045827153920,
  "in_reply_to_status_id" : 93777149768634368,
  "created_at" : "2011-07-20 20:23:23 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93777149768634368",
  "geo" : { },
  "id_str" : "93777805015396352",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold \"requirements people\" ? what year is this?",
  "id" : 93777805015396352,
  "in_reply_to_status_id" : 93777149768634368,
  "created_at" : "2011-07-20 20:22:25 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis CI",
      "screen_name" : "travisci",
      "indices" : [ 3, 12 ],
      "id_str" : "252481460",
      "id" : 252481460
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 32, 42 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http:\/\/t.co\/F2AC1Ue",
      "expanded_url" : "http:\/\/travis-ci.org\/#!\/rubygems\/gemcutter",
      "display_url" : "travis-ci.org\/#!\/rubygems\/ge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "93777226247585792",
  "text" : "RT @travisci: And a BIG welcome @gemcutter who joins Travis today! http:\/\/t.co\/F2AC1Ue :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gemcutter",
        "screen_name" : "gemcutter",
        "indices" : [ 18, 28 ],
        "id_str" : "42259749",
        "id" : 42259749
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 72 ],
        "url" : "http:\/\/t.co\/F2AC1Ue",
        "expanded_url" : "http:\/\/travis-ci.org\/#!\/rubygems\/gemcutter",
        "display_url" : "travis-ci.org\/#!\/rubygems\/ge\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "93765658139041792",
    "text" : "And a BIG welcome @gemcutter who joins Travis today! http:\/\/t.co\/F2AC1Ue :)",
    "id" : 93765658139041792,
    "created_at" : "2011-07-20 19:34:09 +0000",
    "user" : {
      "name" : "Travis CI",
      "screen_name" : "travisci",
      "protected" : false,
      "id_str" : "252481460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000473699437\/7d9825fd0e38f5e05831d226afc41d9c_normal.jpeg",
      "id" : 252481460,
      "verified" : false
    }
  },
  "id" : 93777226247585792,
  "created_at" : "2011-07-20 20:20:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ZOBfKUz",
      "expanded_url" : "http:\/\/status.aws.amazon.com\/.",
      "display_url" : "status.aws.amazon.com"
    } ]
  },
  "geo" : { },
  "id_str" : "93776047673327616",
  "text" : "RT @gemcutter: We're seeing issues connecting to CloudFront from EC2, there's nothing we can do about this, and nothing on http:\/\/t.co\/Z ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 127 ],
        "url" : "http:\/\/t.co\/ZOBfKUz",
        "expanded_url" : "http:\/\/status.aws.amazon.com\/.",
        "display_url" : "status.aws.amazon.com"
      } ]
    },
    "geo" : { },
    "id_str" : "93776001628254208",
    "text" : "We're seeing issues connecting to CloudFront from EC2, there's nothing we can do about this, and nothing on http:\/\/t.co\/ZOBfKUz :(",
    "id" : 93776001628254208,
    "created_at" : "2011-07-20 20:15:15 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 93776047673327616,
  "created_at" : "2011-07-20 20:15:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93774646763196416",
  "geo" : { },
  "id_str" : "93775706005315585",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold this is why tests are important",
  "id" : 93775706005315585,
  "in_reply_to_status_id" : 93774646763196416,
  "created_at" : "2011-07-20 20:14:05 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93775461586444288",
  "text" : "Woo, just reupped quaran.to for 5 years. I still can't believe tonic.to lets you reserve domains for 100 years, lulz",
  "id" : 93775461586444288,
  "created_at" : "2011-07-20 20:13:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93737172053671936",
  "geo" : { },
  "id_str" : "93737766059376641",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove it would be extremely difficult to change the gemspec api or how it's marshalled...we should discuss in #rubygems",
  "id" : 93737766059376641,
  "in_reply_to_status_id" : 93737172053671936,
  "created_at" : "2011-07-20 17:43:19 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "indices" : [ 12, 26 ],
      "id_str" : "20104013",
      "id" : 20104013
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 76, 86 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93735649311592448",
  "geo" : { },
  "id_str" : "93736188917198849",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove @yukihiro_matz well it sounds like this is a ruby\/yaml bug, not @gemcutter's fault",
  "id" : 93736188917198849,
  "in_reply_to_status_id" : 93735649311592448,
  "created_at" : "2011-07-20 17:37:03 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "indices" : [ 0, 14 ],
      "id_str" : "20104013",
      "id" : 20104013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 81 ],
      "url" : "http:\/\/t.co\/o0xQhL0",
      "expanded_url" : "https:\/\/gist.github.com\/1095436",
      "display_url" : "gist.github.com\/1095436"
    } ]
  },
  "in_reply_to_status_id_str" : "93733899603148800",
  "geo" : { },
  "id_str" : "93735161849581568",
  "in_reply_to_user_id" : 20104013,
  "text" : "@yukihiro_matz worked for me, what's your `gem env` ? output: http:\/\/t.co\/o0xQhL0",
  "id" : 93735161849581568,
  "in_reply_to_status_id" : 93733899603148800,
  "created_at" : "2011-07-20 17:32:58 +0000",
  "in_reply_to_screen_name" : "yukihiro_matz",
  "in_reply_to_user_id_str" : "20104013",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "indices" : [ 12, 26 ],
      "id_str" : "20104013",
      "id" : 20104013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93732928953135104",
  "geo" : { },
  "id_str" : "93733702588305410",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove @yukihiro_matz what? what ruby\/rubygems does this happen with?",
  "id" : 93733702588305410,
  "in_reply_to_status_id" : 93732928953135104,
  "created_at" : "2011-07-20 17:27:10 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93685837203640320",
  "text" : "I can't wait until OSX 10.8 NyanCat, imagine all of the COOL FEATURES and BROKEN APPS!",
  "id" : 93685837203640320,
  "created_at" : "2011-07-20 14:16:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poul Stevens",
      "screen_name" : "louisck",
      "indices" : [ 18, 26 ],
      "id_str" : "2218092372",
      "id" : 2218092372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 65 ],
      "url" : "http:\/\/t.co\/m8EPJK8",
      "expanded_url" : "http:\/\/www.youtube.com\/user\/omgwtfitssteve#g\/c\/AA38AFD437C0D5BE",
      "display_url" : "youtube.com\/user\/omgwtfits\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "93465741285801984",
  "text" : "So awesome, every @louisck appearance on O&A. http:\/\/t.co\/m8EPJK8",
  "id" : 93465741285801984,
  "created_at" : "2011-07-19 23:42:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93450456164085760",
  "geo" : { },
  "id_str" : "93451127982526464",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic haha no way thanks to rubycraft.org",
  "id" : 93451127982526464,
  "in_reply_to_status_id" : 93450456164085760,
  "created_at" : "2011-07-19 22:44:19 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93448552495329280",
  "geo" : { },
  "id_str" : "93449354005856256",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything i had 90 days played through vanilla\/release of BC, raided MC\/BWL...the game has changed massively since then.",
  "id" : 93449354005856256,
  "in_reply_to_status_id" : 93448552495329280,
  "created_at" : "2011-07-19 22:37:16 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93448072331403264",
  "text" : "\"World of Warcraft Account Cancelled: DOCTORNICK40\" ...that was much easier than last time (emotionally, psychologically)",
  "id" : 93448072331403264,
  "created_at" : "2011-07-19 22:32:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 0, 12 ],
      "id_str" : "517029319",
      "id" : 517029319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93441779986206720",
  "text" : "@seacreature pay, that is. $3\/mo is worth not maintaining all that shit",
  "id" : 93441779986206720,
  "created_at" : "2011-07-19 22:07:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 0, 12 ],
      "id_str" : "517029319",
      "id" : 517029319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93441515682144256",
  "text" : "@seacreature dude just for it. $3\/mo.",
  "id" : 93441515682144256,
  "created_at" : "2011-07-19 22:06:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93429109501341698",
  "geo" : { },
  "id_str" : "93440831771508736",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy windows developers don't write scripts",
  "id" : 93440831771508736,
  "in_reply_to_status_id" : 93429109501341698,
  "created_at" : "2011-07-19 22:03:25 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik F. Kastner",
      "screen_name" : "kastner",
      "indices" : [ 0, 8 ],
      "id_str" : "627303",
      "id" : 627303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93375915974852608",
  "geo" : { },
  "id_str" : "93440007926333440",
  "in_reply_to_user_id" : 627303,
  "text" : "@kastner https:\/\/github.com\/rubygems\/gemcutter\/blob\/master\/app\/middleware\/hostess.rb",
  "id" : 93440007926333440,
  "in_reply_to_status_id" : 93375915974852608,
  "created_at" : "2011-07-19 22:00:08 +0000",
  "in_reply_to_screen_name" : "kastner",
  "in_reply_to_user_id_str" : "627303",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Smick",
      "screen_name" : "sprsquish",
      "indices" : [ 0, 10 ],
      "id_str" : "2296675008",
      "id" : 2296675008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93372406839783424",
  "geo" : { },
  "id_str" : "93373323874025473",
  "in_reply_to_user_id" : 3732061,
  "text" : "@sprsquish ever heard of a typewriter?",
  "id" : 93373323874025473,
  "in_reply_to_status_id" : 93372406839783424,
  "created_at" : "2011-07-19 17:35:09 +0000",
  "in_reply_to_screen_name" : "mrsprsquish",
  "in_reply_to_user_id_str" : "3732061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93371321483931648",
  "geo" : { },
  "id_str" : "93372072964784128",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik mango song here! :D",
  "id" : 93372072964784128,
  "in_reply_to_status_id" : 93371321483931648,
  "created_at" : "2011-07-19 17:30:11 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/N3znqnx",
      "expanded_url" : "http:\/\/www.rubyinside.com\/the-book-of-ruby-review-5166.html",
      "display_url" : "rubyinside.com\/the-book-of-ru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "93368520687104000",
  "text" : "I can't tell if this guy just doesn't give a fuck, or some asshat just let him publish a book: http:\/\/t.co\/N3znqnx",
  "id" : 93368520687104000,
  "created_at" : "2011-07-19 17:16:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93174990693859328",
  "text" : "Apparently our neighbor feels like its a good time to have a DANCE PARTY WUB WUB WUB WUB WUB WUB WUB FUCK WUB WUB WUB WUB YOU WUB WUB WUB",
  "id" : 93174990693859328,
  "created_at" : "2011-07-19 04:27:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93073049158565888",
  "text" : "Finished in -11926588.965455 seconds.\n\nCan I get the past 4.5 months back now?",
  "id" : 93073049158565888,
  "created_at" : "2011-07-18 21:41:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92988237869613056",
  "text" : "To any RubyGem that feels it necessary to override Kernel#require: Fuck you.",
  "id" : 92988237869613056,
  "created_at" : "2011-07-18 16:04:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 108 ],
      "url" : "http:\/\/t.co\/KJ63cDZ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=eBHHW-ijxJM",
      "display_url" : "youtube.com\/watch?v=eBHHW-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "92985706728783872",
  "text" : "\"square rectangle rule. Not all squares are rectangles, not all octogons are stop signs\" http:\/\/t.co\/KJ63cDZ",
  "id" : 92985706728783872,
  "created_at" : "2011-07-18 15:54:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 83, 91 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92805313383768065",
  "text" : "Didn't end up blowing up the TNT, made a giant glass tube and filled it with lava. @ddollar these server mods are a little crazy :)",
  "id" : 92805313383768065,
  "created_at" : "2011-07-18 03:58:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 49 ],
      "url" : "http:\/\/t.co\/uZv5u3D",
      "expanded_url" : "https:\/\/img.skitch.com\/20110718-k7h9se4y9bqhk7yqhpi7n32yca.png",
      "display_url" : "img.skitch.com\/20110718-k7h9s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "92800426667290624",
  "text" : "Current rubycraft.org status: http:\/\/t.co\/uZv5u3D",
  "id" : 92800426667290624,
  "created_at" : "2011-07-18 03:38:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http:\/\/t.co\/zTT1lHl",
      "expanded_url" : "https:\/\/www.facebook.com\/nick.quaranto",
      "display_url" : "facebook.com\/nick.quaranto"
    } ]
  },
  "in_reply_to_status_id_str" : "92781590438084608",
  "geo" : { },
  "id_str" : "92793116880412672",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh it's Geddy. add me on facebook, i tend to post more there. http:\/\/t.co\/zTT1lHl",
  "id" : 92793116880412672,
  "in_reply_to_status_id" : 92781590438084608,
  "created_at" : "2011-07-18 03:09:37 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 72, 80 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92779901240868865",
  "text" : "Current dog status: puppy ice cream coma. http:\/\/yfrog.com\/kiqhfpkj \/cc @jayunit",
  "id" : 92779901240868865,
  "created_at" : "2011-07-18 02:17:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Whitbeck",
      "screen_name" : "RedWolves",
      "indices" : [ 0, 10 ],
      "id_str" : "651373",
      "id" : 651373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92778478843330560",
  "geo" : { },
  "id_str" : "92779133284777984",
  "in_reply_to_user_id" : 651373,
  "text" : "@RedWolves about to do the same, except @ablissfulgal suggested it! :D",
  "id" : 92779133284777984,
  "in_reply_to_status_id" : 92778478843330560,
  "created_at" : "2011-07-18 02:14:03 +0000",
  "in_reply_to_screen_name" : "RedWolves",
  "in_reply_to_user_id_str" : "651373",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92451741722869760",
  "text" : "man vv\nNo manual entry for vv",
  "id" : 92451741722869760,
  "created_at" : "2011-07-17 04:33:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    }, {
      "name" : "Szil\u00E1gyi Zolt\u00E1n",
      "screen_name" : "Zedas",
      "indices" : [ 60, 66 ],
      "id_str" : "65596632",
      "id" : 65596632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92450173187391489",
  "geo" : { },
  "id_str" : "92451047745916928",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw fossil is a waste of time, has zero data integrity. @zedas has some fun blog posts about it :)",
  "id" : 92451047745916928,
  "in_reply_to_status_id" : 92450173187391489,
  "created_at" : "2011-07-17 04:30:22 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http:\/\/t.co\/MH8hxuc",
      "expanded_url" : "http:\/\/www.veracity-scm.com\/",
      "display_url" : "veracity-scm.com"
    } ]
  },
  "geo" : { },
  "id_str" : "92448355673833472",
  "text" : "A classic example of why not to compete on features, and how to lose automatically: http:\/\/t.co\/MH8hxuc",
  "id" : 92448355673833472,
  "created_at" : "2011-07-17 04:19:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92372124869730304",
  "geo" : { },
  "id_str" : "92380877883064320",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej added!",
  "id" : 92380877883064320,
  "in_reply_to_status_id" : 92372124869730304,
  "created_at" : "2011-07-16 23:51:32 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92373472927420416",
  "text" : "Epic mojito time! http:\/\/yfrog.com\/kebv8ooj",
  "id" : 92373472927420416,
  "created_at" : "2011-07-16 23:22:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carlos Galdino",
      "screen_name" : "carlosgaldino",
      "indices" : [ 0, 14 ],
      "id_str" : "19273120",
      "id" : 19273120
    }, {
      "name" : "wmoxam",
      "screen_name" : "wmoxam",
      "indices" : [ 15, 22 ],
      "id_str" : "14049936",
      "id" : 14049936
    }, {
      "name" : "R.T. Lechow",
      "screen_name" : "rtlechow",
      "indices" : [ 23, 32 ],
      "id_str" : "12208042",
      "id" : 12208042
    }, {
      "name" : "Carl Furrow",
      "screen_name" : "carl_furrow",
      "indices" : [ 33, 45 ],
      "id_str" : "14287135",
      "id" : 14287135
    }, {
      "name" : "Tom Stuart (UNUSED)",
      "screen_name" : "mortice",
      "indices" : [ 46, 54 ],
      "id_str" : "8102782",
      "id" : 8102782
    }, {
      "name" : "Pete Birkinshaw \u24CB",
      "screen_name" : "binaryape",
      "indices" : [ 55, 65 ],
      "id_str" : "16592166",
      "id" : 16592166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92370161113378816",
  "in_reply_to_user_id" : 19273120,
  "text" : "@carlosgaldino @wmoxam @rtlechow @carl_furrow @mortice @binaryape rubycraft.org is go!",
  "id" : 92370161113378816,
  "created_at" : "2011-07-16 23:08:57 +0000",
  "in_reply_to_screen_name" : "carlosgaldino",
  "in_reply_to_user_id_str" : "19273120",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tamal White",
      "screen_name" : "tamalw",
      "indices" : [ 0, 7 ],
      "id_str" : "10715872",
      "id" : 10715872
    }, {
      "name" : "dannytatom",
      "screen_name" : "dannytatom",
      "indices" : [ 8, 19 ],
      "id_str" : "2500287421",
      "id" : 2500287421
    }, {
      "name" : "Lukas",
      "screen_name" : "plukevdh",
      "indices" : [ 20, 29 ],
      "id_str" : "14103289",
      "id" : 14103289
    }, {
      "name" : "Adam Tanner",
      "screen_name" : "adamtanner",
      "indices" : [ 30, 41 ],
      "id_str" : "6367402",
      "id" : 6367402
    }, {
      "name" : "Ryan Garver",
      "screen_name" : "rgarver",
      "indices" : [ 42, 50 ],
      "id_str" : "969631",
      "id" : 969631
    }, {
      "name" : "Ben Cochran",
      "screen_name" : "bencochran",
      "indices" : [ 51, 62 ],
      "id_str" : "665773",
      "id" : 665773
    }, {
      "name" : "David Rose",
      "screen_name" : "doppler",
      "indices" : [ 63, 71 ],
      "id_str" : "881531",
      "id" : 881531
    }, {
      "name" : "jeffrydegrande",
      "screen_name" : "jeffrydegrande",
      "indices" : [ 72, 87 ],
      "id_str" : "12638032",
      "id" : 12638032
    }, {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 88, 99 ],
      "id_str" : "11694962",
      "id" : 11694962
    }, {
      "name" : "Justin Henry",
      "screen_name" : "jhenry",
      "indices" : [ 100, 107 ],
      "id_str" : "62013",
      "id" : 62013
    }, {
      "name" : "Follow @henrikhodne",
      "screen_name" : "dvyjones",
      "indices" : [ 108, 117 ],
      "id_str" : "632309987",
      "id" : 632309987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92370003529175040",
  "in_reply_to_user_id" : 10715872,
  "text" : "@tamalw @dannytatom @plukevdh @adamtanner @rgarver @bencochran @doppler @jeffrydegrande @alex_godin @jhenry @dvyjones rubycraft.org is go!",
  "id" : 92370003529175040,
  "created_at" : "2011-07-16 23:08:19 +0000",
  "in_reply_to_screen_name" : "tamalw",
  "in_reply_to_user_id_str" : "10715872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92368644146868224",
  "text" : "Just made double sure everyone who signed up for rubycraft.org is on the whitelist. Watch out for creepers!",
  "id" : 92368644146868224,
  "created_at" : "2011-07-16 23:02:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Guterl",
      "screen_name" : "mguterl",
      "indices" : [ 0, 8 ],
      "id_str" : "15404880",
      "id" : 15404880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92338206598627329",
  "geo" : { },
  "id_str" : "92366223161040896",
  "in_reply_to_user_id" : 15404880,
  "text" : "@mguterl you're added, go ahead!",
  "id" : 92366223161040896,
  "in_reply_to_status_id" : 92338206598627329,
  "created_at" : "2011-07-16 22:53:18 +0000",
  "in_reply_to_screen_name" : "mguterl",
  "in_reply_to_user_id_str" : "15404880",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92337517101203456",
  "text" : "I think everyone who's asked to get on rubycraft.org has been added! Come build!",
  "id" : 92337517101203456,
  "created_at" : "2011-07-16 20:59:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brian del vecchio",
      "screen_name" : "Hybernaut",
      "indices" : [ 0, 10 ],
      "id_str" : "4678",
      "id" : 4678
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92317922168541184",
  "geo" : { },
  "id_str" : "92323292576350208",
  "in_reply_to_user_id" : 4678,
  "text" : "@Hybernaut the bigger question: who let him into the suburbs?",
  "id" : 92323292576350208,
  "in_reply_to_status_id" : 92317922168541184,
  "created_at" : "2011-07-16 20:02:42 +0000",
  "in_reply_to_screen_name" : "Hybernaut",
  "in_reply_to_user_id_str" : "4678",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92318655899115520",
  "geo" : { },
  "id_str" : "92319069633642496",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu star trek the next generation! On netflix!",
  "id" : 92319069633642496,
  "in_reply_to_status_id" : 92318655899115520,
  "created_at" : "2011-07-16 19:45:56 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92305981110882304",
  "geo" : { },
  "id_str" : "92318128637353984",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit same here just MOJITO -&gt; TNG -&gt; REPEAT",
  "id" : 92318128637353984,
  "in_reply_to_status_id" : 92305981110882304,
  "created_at" : "2011-07-16 19:42:11 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92240028150923264",
  "text" : "Om nom nom! http:\/\/yfrog.com\/kegsjrvj",
  "id" : 92240028150923264,
  "created_at" : "2011-07-16 14:31:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David",
      "screen_name" : "rubycraft",
      "indices" : [ 4, 14 ],
      "id_str" : "24004819",
      "id" : 24004819
    }, {
      "name" : "nz",
      "screen_name" : "nz",
      "indices" : [ 103, 106 ],
      "id_str" : "4611811",
      "id" : 4611811
    }, {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 107, 115 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 94 ],
      "url" : "http:\/\/t.co\/MsE34bV",
      "expanded_url" : "http:\/\/rubycraft.org",
      "display_url" : "rubycraft.org"
    } ]
  },
  "geo" : { },
  "id_str" : "92054802179170306",
  "text" : "Hey @rubycraft folks, you should be able to connect now! If not, submit to http:\/\/t.co\/MsE34bV and bug @nz @ddollar or me!",
  "id" : 92054802179170306,
  "created_at" : "2011-07-16 02:15:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 0, 8 ],
      "id_str" : "839931",
      "id" : 839931
    }, {
      "name" : "David",
      "screen_name" : "rubycraft",
      "indices" : [ 35, 45 ],
      "id_str" : "24004819",
      "id" : 24004819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92040919607545856",
  "in_reply_to_user_id" : 839931,
  "text" : "@ddollar we have ~20 people on the @rubycraft mailing list, could I get ssh access and twitter access?",
  "id" : 92040919607545856,
  "created_at" : "2011-07-16 01:20:39 +0000",
  "in_reply_to_screen_name" : "ddollar",
  "in_reply_to_user_id_str" : "839931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 3, 12 ],
      "id_str" : "729936824",
      "id" : 729936824
    }, {
      "name" : "hoptoadapp",
      "screen_name" : "hoptoadapp",
      "indices" : [ 23, 34 ],
      "id_str" : "15689539",
      "id" : 15689539
    }, {
      "name" : "Airbrakeapp",
      "screen_name" : "Airbrakeapp",
      "indices" : [ 67, 79 ],
      "id_str" : "1246877592",
      "id" : 1246877592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92040724069105664",
  "text" : "RT @hgimenez: bye bye, @hoptoadapp, it was nice meeting you. oh hi @airbrakeapp! http:\/\/robots.thoughtbot.com\/post\/7665411707\/hoptoad-is ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "hoptoadapp",
        "screen_name" : "hoptoadapp",
        "indices" : [ 9, 20 ],
        "id_str" : "15689539",
        "id" : 15689539
      }, {
        "name" : "Airbrakeapp",
        "screen_name" : "Airbrakeapp",
        "indices" : [ 53, 65 ],
        "id_str" : "1246877592",
        "id" : 1246877592
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "92037561668734976",
    "text" : "bye bye, @hoptoadapp, it was nice meeting you. oh hi @airbrakeapp! http:\/\/robots.thoughtbot.com\/post\/7665411707\/hoptoad-is-now-airbrake",
    "id" : 92037561668734976,
    "created_at" : "2011-07-16 01:07:19 +0000",
    "user" : {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "protected" : false,
      "id_str" : "24425454",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491047783214747648\/6czBp_vy_normal.jpeg",
      "id" : 24425454,
      "verified" : false
    }
  },
  "id" : 92040724069105664,
  "created_at" : "2011-07-16 01:19:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Vasquez",
      "screen_name" : "cmv",
      "indices" : [ 0, 4 ],
      "id_str" : "12599",
      "id" : 12599
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92000995642585088",
  "geo" : { },
  "id_str" : "92005772283756544",
  "in_reply_to_user_id" : 12599,
  "text" : "@cmv why? Can you tell us at help.rubygems.org?",
  "id" : 92005772283756544,
  "in_reply_to_status_id" : 92000995642585088,
  "created_at" : "2011-07-15 23:01:00 +0000",
  "in_reply_to_screen_name" : "cmv",
  "in_reply_to_user_id_str" : "12599",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "indices" : [ 3, 13 ],
      "id_str" : "220097555",
      "id" : 220097555
    }, {
      "name" : "Redis To Go",
      "screen_name" : "redistogo",
      "indices" : [ 48, 58 ],
      "id_str" : "164181615",
      "id" : 164181615
    }, {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 62, 69 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/0E9ZQcz",
      "expanded_url" : "https:\/\/img.skitch.com\/20110716-qceudbirxpr221dgffkk7738aq.png",
      "display_url" : "img.skitch.com\/20110716-qceud\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "91998134015758336",
  "text" : "RT @radishapp: For real this time! If you're on @redistogo on @heroku, sign up and give us your REDIS_URL! http:\/\/t.co\/0E9ZQcz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Redis To Go",
        "screen_name" : "redistogo",
        "indices" : [ 33, 43 ],
        "id_str" : "164181615",
        "id" : 164181615
      }, {
        "name" : "Heroku",
        "screen_name" : "heroku",
        "indices" : [ 47, 54 ],
        "id_str" : "10257182",
        "id" : 10257182
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 111 ],
        "url" : "http:\/\/t.co\/0E9ZQcz",
        "expanded_url" : "https:\/\/img.skitch.com\/20110716-qceudbirxpr221dgffkk7738aq.png",
        "display_url" : "img.skitch.com\/20110716-qceud\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "91997910450962432",
    "text" : "For real this time! If you're on @redistogo on @heroku, sign up and give us your REDIS_URL! http:\/\/t.co\/0E9ZQcz",
    "id" : 91997910450962432,
    "created_at" : "2011-07-15 22:29:45 +0000",
    "user" : {
      "name" : "Radish",
      "screen_name" : "radishapp",
      "protected" : false,
      "id_str" : "220097555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1268075541\/radish_small_normal.png",
      "id" : 220097555,
      "verified" : false
    }
  },
  "id" : 91998134015758336,
  "created_at" : "2011-07-15 22:30:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http:\/\/t.co\/e3YVN8m",
      "expanded_url" : "http:\/\/bitly.com\/rqVFje",
      "display_url" : "bitly.com\/rqVFje"
    } ]
  },
  "geo" : { },
  "id_str" : "91969938054586368",
  "text" : "RT @thoughtbot: thoughtbot is writing a Backbone.js on Rails eBook http:\/\/t.co\/e3YVN8m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 70 ],
        "url" : "http:\/\/t.co\/e3YVN8m",
        "expanded_url" : "http:\/\/bitly.com\/rqVFje",
        "display_url" : "bitly.com\/rqVFje"
      } ]
    },
    "geo" : { },
    "id_str" : "91969853396754433",
    "text" : "thoughtbot is writing a Backbone.js on Rails eBook http:\/\/t.co\/e3YVN8m",
    "id" : 91969853396754433,
    "created_at" : "2011-07-15 20:38:16 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 91969938054586368,
  "created_at" : "2011-07-15 20:38:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91968377932886016",
  "geo" : { },
  "id_str" : "91968871292080128",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens it pains me to see this in someone's feed, it's 2011. why do you put up with it?",
  "id" : 91968871292080128,
  "in_reply_to_status_id" : 91968377932886016,
  "created_at" : "2011-07-15 20:34:22 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby Inside",
      "screen_name" : "RubyInside",
      "indices" : [ 0, 11 ],
      "id_str" : "15851832",
      "id" : 15851832
    }, {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 12, 19 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91961529406205953",
  "geo" : { },
  "id_str" : "91962424365809665",
  "in_reply_to_user_id" : 15851832,
  "text" : "@RubyInside @peterc why aren't there any entry\/junior\/apprentice level positions?",
  "id" : 91962424365809665,
  "in_reply_to_status_id" : 91961529406205953,
  "created_at" : "2011-07-15 20:08:45 +0000",
  "in_reply_to_screen_name" : "RubyInside",
  "in_reply_to_user_id_str" : "15851832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91961242616471552",
  "geo" : { },
  "id_str" : "91962013521166336",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv LOL \"bored_designer\"",
  "id" : 91962013521166336,
  "in_reply_to_status_id" : 91961242616471552,
  "created_at" : "2011-07-15 20:07:07 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 0, 11 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91923436183621632",
  "geo" : { },
  "id_str" : "91924882375446528",
  "in_reply_to_user_id" : 9070452,
  "text" : "@jimweirich test, no excuses",
  "id" : 91924882375446528,
  "in_reply_to_status_id" : 91923436183621632,
  "created_at" : "2011-07-15 17:39:34 +0000",
  "in_reply_to_screen_name" : "jimweirich",
  "in_reply_to_user_id_str" : "9070452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/apZHEf9",
      "expanded_url" : "http:\/\/vidque.com\/lukas\/31918\/siggraph-2011-technical-papers-video-preview",
      "display_url" : "vidque.com\/lukas\/31918\/si\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "91879228836036608",
  "text" : "SIGGRAPH papers\/videos are always mind-blowing. http:\/\/t.co\/apZHEf9",
  "id" : 91879228836036608,
  "created_at" : "2011-07-15 14:38:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 109, 117 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 23 ],
      "url" : "http:\/\/t.co\/XVtez9b",
      "expanded_url" : "http:\/\/rubycraft.org\/",
      "display_url" : "rubycraft.org"
    } ]
  },
  "geo" : { },
  "id_str" : "91697087959404545",
  "text" : "Yay http:\/\/t.co\/XVtez9b server is alive! Whitelist only, just fill out the form and we'll get you in! thanks @ddollar!!",
  "id" : 91697087959404545,
  "created_at" : "2011-07-15 02:34:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91666534451249153",
  "geo" : { },
  "id_str" : "91666967248896000",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza eh? just rebuilt the linode...what do you have in mind?",
  "id" : 91666967248896000,
  "in_reply_to_status_id" : 91666534451249153,
  "created_at" : "2011-07-15 00:34:42 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91666377433296896",
  "text" : "Definitely going to get a new server up with an approval process or something!!",
  "id" : 91666377433296896,
  "created_at" : "2011-07-15 00:32:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91666278607097856",
  "text" : "Shutting down minecraft.quaran.to, it was fun but the server was listed publicly and, well, shit got blown up.",
  "id" : 91666278607097856,
  "created_at" : "2011-07-15 00:31:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Zadrozny",
      "screen_name" : "nz_",
      "indices" : [ 0, 4 ],
      "id_str" : "49923",
      "id" : 49923
    }, {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 5, 13 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91653145503080448",
  "geo" : { },
  "id_str" : "91663298755440641",
  "in_reply_to_user_id" : 49923,
  "text" : "@nz_ @ddollar is it that fucked up? maybe we should just collectively invest in a bigger linode and restart",
  "id" : 91663298755440641,
  "in_reply_to_status_id" : 91653145503080448,
  "created_at" : "2011-07-15 00:20:08 +0000",
  "in_reply_to_screen_name" : "nz_",
  "in_reply_to_user_id_str" : "49923",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Zadrozny",
      "screen_name" : "nz_",
      "indices" : [ 0, 4 ],
      "id_str" : "49923",
      "id" : 49923
    }, {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 5, 13 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91644670718910464",
  "geo" : { },
  "id_str" : "91652671206985728",
  "in_reply_to_user_id" : 49923,
  "text" : "@nz_ @ddollar glad I took pictures yesterday lol",
  "id" : 91652671206985728,
  "in_reply_to_status_id" : 91644670718910464,
  "created_at" : "2011-07-14 23:37:54 +0000",
  "in_reply_to_screen_name" : "nz_",
  "in_reply_to_user_id_str" : "49923",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91639816181121024",
  "geo" : { },
  "id_str" : "91642441811230720",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella I was really hoping for late fall, why wasn't this put to a vote from possible attendees?",
  "id" : 91642441811230720,
  "in_reply_to_status_id" : 91639816181121024,
  "created_at" : "2011-07-14 22:57:15 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91575605010759680",
  "geo" : { },
  "id_str" : "91640809652367361",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella yeah not gonna happen",
  "id" : 91640809652367361,
  "in_reply_to_status_id" : 91575605010759680,
  "created_at" : "2011-07-14 22:50:46 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BM5k",
      "screen_name" : "BM5k",
      "indices" : [ 0, 5 ],
      "id_str" : "39593",
      "id" : 39593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91632644747571200",
  "geo" : { },
  "id_str" : "91632885928427520",
  "in_reply_to_user_id" : 39593,
  "text" : "@BM5k this is how I feel about 99% of eventmachine code ans libs",
  "id" : 91632885928427520,
  "in_reply_to_status_id" : 91632644747571200,
  "created_at" : "2011-07-14 22:19:17 +0000",
  "in_reply_to_screen_name" : "BM5k",
  "in_reply_to_user_id_str" : "39593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91596867468668928",
  "text" : "Evvverday i'm Array.shufflin'",
  "id" : 91596867468668928,
  "created_at" : "2011-07-14 19:56:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/dAqbFqe",
      "expanded_url" : "http:\/\/farm4.static.flickr.com\/3190\/2855445750_7f7eacbb4c.jpg",
      "display_url" : "farm4.static.flickr.com\/3190\/285544575\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "91592453571874816",
  "text" : "Current status: http:\/\/t.co\/dAqbFqe",
  "id" : 91592453571874816,
  "created_at" : "2011-07-14 19:38:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robby Grossman",
      "screen_name" : "freerobby",
      "indices" : [ 0, 10 ],
      "id_str" : "15023866",
      "id" : 15023866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91536692250558466",
  "geo" : { },
  "id_str" : "91541596985769984",
  "in_reply_to_user_id" : 15023866,
  "text" : "@freerobby not that I know of. Commit often :(",
  "id" : 91541596985769984,
  "in_reply_to_status_id" : 91536692250558466,
  "created_at" : "2011-07-14 16:16:32 +0000",
  "in_reply_to_screen_name" : "freerobby",
  "in_reply_to_user_id_str" : "15023866",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 16, 28 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 48 ],
      "url" : "http:\/\/t.co\/y4y8nYJ",
      "expanded_url" : "http:\/\/29.media.tumblr.com\/tumblr_lo82ov6RCJ1qck0pho1_500.png",
      "display_url" : "29.media.tumblr.com\/tumblr_lo82ov6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "91505506132299776",
  "text" : "This one is for @fredyatesiv http:\/\/t.co\/y4y8nYJ",
  "id" : 91505506132299776,
  "created_at" : "2011-07-14 13:53:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "saidul islam sayem",
      "screen_name" : "SayemIslam",
      "indices" : [ 0, 11 ],
      "id_str" : "1001482364",
      "id" : 1001482364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91361413058138112",
  "text" : "@sayemislam woo congrats!",
  "id" : 91361413058138112,
  "created_at" : "2011-07-14 04:20:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91355358903283713",
  "geo" : { },
  "id_str" : "91360198115078144",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror there are no actual salary numbers in that pdf",
  "id" : 91360198115078144,
  "in_reply_to_status_id" : 91355358903283713,
  "created_at" : "2011-07-14 04:15:43 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Smith",
      "screen_name" : "brianthecoder",
      "indices" : [ 0, 14 ],
      "id_str" : "9548262",
      "id" : 9548262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91354919096942593",
  "geo" : { },
  "id_str" : "91359419908112384",
  "in_reply_to_user_id" : 9548262,
  "text" : "@brianthecoder have you read http:\/\/robots.thoughtbot.com\/post\/2729333530\/fetching-source-index-for-http-rubygems-org ?",
  "id" : 91359419908112384,
  "in_reply_to_status_id" : 91354919096942593,
  "created_at" : "2011-07-14 04:12:37 +0000",
  "in_reply_to_screen_name" : "brianthecoder",
  "in_reply_to_user_id_str" : "9548262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Smith",
      "screen_name" : "brianthecoder",
      "indices" : [ 0, 14 ],
      "id_str" : "9548262",
      "id" : 9548262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91345459188215808",
  "geo" : { },
  "id_str" : "91351629667897344",
  "in_reply_to_user_id" : 9548262,
  "text" : "@brianthecoder it does, it just updates really frequently",
  "id" : 91351629667897344,
  "in_reply_to_status_id" : 91345459188215808,
  "created_at" : "2011-07-14 03:41:40 +0000",
  "in_reply_to_screen_name" : "brianthecoder",
  "in_reply_to_user_id_str" : "9548262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/0bWNba5",
      "expanded_url" : "http:\/\/imgur.com\/a\/CTv12",
      "display_url" : "imgur.com\/a\/CTv12"
    } ]
  },
  "geo" : { },
  "id_str" : "91351056717578240",
  "text" : "I couldn't upload all the photos I had, but minecraft.quaran.to has gotten completely awesome: http:\/\/t.co\/0bWNba5",
  "id" : 91351056717578240,
  "created_at" : "2011-07-14 03:39:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "indices" : [ 0, 13 ],
      "id_str" : "1341781",
      "id" : 1341781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91333153934942209",
  "geo" : { },
  "id_str" : "91344898145521664",
  "in_reply_to_user_id" : 1341781,
  "text" : "@gilesgoatboy bundler 1.1.pre is using a new api, but it's marshal only. hit me on IRC and i can give you a rundown",
  "id" : 91344898145521664,
  "in_reply_to_status_id" : 91333153934942209,
  "created_at" : "2011-07-14 03:14:55 +0000",
  "in_reply_to_screen_name" : "gilesgoatboy",
  "in_reply_to_user_id_str" : "1341781",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91204446037622786",
  "geo" : { },
  "id_str" : "91204721142005760",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms you win, rofl",
  "id" : 91204721142005760,
  "in_reply_to_status_id" : 91204446037622786,
  "created_at" : "2011-07-13 17:57:54 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 0, 6 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90968950594207744",
  "geo" : { },
  "id_str" : "91173886443536384",
  "in_reply_to_user_id" : 15359408,
  "text" : "@raggi whaaat..?",
  "id" : 91173886443536384,
  "in_reply_to_status_id" : 90968950594207744,
  "created_at" : "2011-07-13 15:55:23 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91151181040201728",
  "geo" : { },
  "id_str" : "91152138687873025",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik just like every birthday field i fill out to January 1, 1900",
  "id" : 91152138687873025,
  "in_reply_to_status_id" : 91151181040201728,
  "created_at" : "2011-07-13 14:28:58 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 45 ],
      "url" : "http:\/\/t.co\/iz4n07J",
      "expanded_url" : "https:\/\/github.com\/jeremyevans\/home_run",
      "display_url" : "github.com\/jeremyevans\/ho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "91149929753477120",
  "text" : "I'm still blown away that http:\/\/t.co\/iz4n07J isn't in Ruby yet :(",
  "id" : 91149929753477120,
  "created_at" : "2011-07-13 14:20:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 47 ],
      "url" : "http:\/\/t.co\/Z0ZvByV",
      "expanded_url" : "http:\/\/vastimg.herokuapp.com\/?http:\/\/thechive.files.wordpress.com\/2011\/07\/1310107085_2.gif",
      "display_url" : "vastimg.herokuapp.com\/?http:\/\/thechi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "91147880961810433",
  "geo" : { },
  "id_str" : "91148999809171456",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape yet another for http:\/\/t.co\/Z0ZvByV",
  "id" : 91148999809171456,
  "in_reply_to_status_id" : 91147880961810433,
  "created_at" : "2011-07-13 14:16:29 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91143126298791938",
  "geo" : { },
  "id_str" : "91144971058552832",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold just break it yourself and ask for a new one",
  "id" : 91144971058552832,
  "in_reply_to_status_id" : 91143126298791938,
  "created_at" : "2011-07-13 14:00:29 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91133240974389249",
  "text" : "Surrounded by two programmers on the train, yet feels so strange to talk to them. I can't be the only one like this.",
  "id" : 91133240974389249,
  "created_at" : "2011-07-13 13:13:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maarten van Berkel",
      "screen_name" : "mvberkel",
      "indices" : [ 0, 9 ],
      "id_str" : "45542819",
      "id" : 45542819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91109550014476288",
  "geo" : { },
  "id_str" : "91132489296384000",
  "in_reply_to_user_id" : 45542819,
  "text" : "@mvberkel either use 1.3.7 or 1.8.5, imo. :(",
  "id" : 91132489296384000,
  "in_reply_to_status_id" : 91109550014476288,
  "created_at" : "2011-07-13 13:10:53 +0000",
  "in_reply_to_screen_name" : "mvberkel",
  "in_reply_to_user_id_str" : "45542819",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alexander rakoczy",
      "screen_name" : "scissorjammer",
      "indices" : [ 0, 14 ],
      "id_str" : "1413246176",
      "id" : 1413246176
    }, {
      "name" : "Ryan Carmelo Briones",
      "screen_name" : "ryanbriones",
      "indices" : [ 15, 27 ],
      "id_str" : "6144652",
      "id" : 6144652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90937075829964800",
  "geo" : { },
  "id_str" : "90941531934048256",
  "in_reply_to_user_id" : 14238988,
  "text" : "@scissorjammer @ryanbriones does this mean all vc backed startups are boy bands?",
  "id" : 90941531934048256,
  "in_reply_to_status_id" : 90937075829964800,
  "created_at" : "2011-07-13 00:32:05 +0000",
  "in_reply_to_screen_name" : "toothrot",
  "in_reply_to_user_id_str" : "14238988",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Pickett",
      "screen_name" : "dpickett",
      "indices" : [ 0, 9 ],
      "id_str" : "1364461",
      "id" : 1364461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90931880064593920",
  "geo" : { },
  "id_str" : "90933033930211328",
  "in_reply_to_user_id" : 1364461,
  "text" : "@dpickett i mean testing the functionality you're adding, is that even possible?",
  "id" : 90933033930211328,
  "in_reply_to_status_id" : 90931880064593920,
  "created_at" : "2011-07-12 23:58:19 +0000",
  "in_reply_to_screen_name" : "dpickett",
  "in_reply_to_user_id_str" : "1364461",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 10, 20 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 26, 35 ],
      "id_str" : "21431343",
      "id" : 21431343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LIKEABOSS",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90930730464579584",
  "text" : "Deploying @gemcutter from @bostonrb #LIKEABOSS",
  "id" : 90930730464579584,
  "created_at" : "2011-07-12 23:49:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0412\u0441\u0435\u0441\u043B\u0430\u0432 \u041F\u043E\u043A\u0440\u043E\u0432\u0441\u043A\u0438\u0439",
      "screen_name" : "dan_sosedoff",
      "indices" : [ 11, 24 ],
      "id_str" : "203110801",
      "id" : 203110801
    }, {
      "name" : "Sam Lown",
      "screen_name" : "samlown",
      "indices" : [ 25, 33 ],
      "id_str" : "9375692",
      "id" : 9375692
    }, {
      "name" : "- \u0340\u0317new \u0341\u0316- Bolton\u2122",
      "screen_name" : "kyle_bolton",
      "indices" : [ 34, 46 ],
      "id_str" : "1355737052",
      "id" : 1355737052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90925608799965184",
  "geo" : { },
  "id_str" : "90929056752730112",
  "in_reply_to_user_id" : 15678855,
  "text" : "@bmblack34 @dan_sosedoff @samlown @kyle_bolton not down here, pingdom is up. I think a CloudFront edge location is boned",
  "id" : 90929056752730112,
  "in_reply_to_status_id" : 90925608799965184,
  "created_at" : "2011-07-12 23:42:31 +0000",
  "in_reply_to_screen_name" : "brandonmblack",
  "in_reply_to_user_id_str" : "15678855",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 23, 32 ],
      "id_str" : "21431343",
      "id" : 21431343
    }, {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 106, 113 ],
      "id_str" : "14114222",
      "id" : 14114222
    }, {
      "name" : "Dan Pickett",
      "screen_name" : "dpickett",
      "indices" : [ 114, 123 ],
      "id_str" : "1364461",
      "id" : 1364461
    }, {
      "name" : "Patrick Robertson",
      "screen_name" : "patricksroberts",
      "indices" : [ 124, 140 ],
      "id_str" : "46661605",
      "id" : 46661605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90928718737969152",
  "text" : "Learning Ruby CMS's at @bostonrb. Main question is unanswered: why? (and how do you test this stuff?) \/cc @jayroh @dpickett @patricksroberts",
  "id" : 90928718737969152,
  "created_at" : "2011-07-12 23:41:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@dogpatchlabs",
      "screen_name" : "dogpatchlabs",
      "indices" : [ 37, 50 ],
      "id_str" : "62415556",
      "id" : 62415556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90927307769917440",
  "text" : "Totally hacked the Microsoft wifi at @dogpatchlabs. TOTALLY L33T H4XX0RING",
  "id" : 90927307769917440,
  "created_at" : "2011-07-12 23:35:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 3, 12 ],
      "id_str" : "21431343",
      "id" : 21431343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90923716636184576",
  "text" : "At @bostonrb, I wish my gps worked so I could check in :(",
  "id" : 90923716636184576,
  "created_at" : "2011-07-12 23:21:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 83 ],
      "url" : "http:\/\/t.co\/r7s5Jwk",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=enmuwG5rOGA",
      "display_url" : "youtube.com\/watch?v=enmuwG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "90905511616192512",
  "text" : "Wow, @ablissfulgal's hot dog robot has 17,000 views on youtube! http:\/\/t.co\/r7s5Jwk",
  "id" : 90905511616192512,
  "created_at" : "2011-07-12 22:08:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Davide D'Agostino",
      "screen_name" : "DAddYE",
      "indices" : [ 0, 7 ],
      "id_str" : "14436377",
      "id" : 14436377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90835104334749696",
  "geo" : { },
  "id_str" : "90901262236790784",
  "in_reply_to_user_id" : 14436377,
  "text" : "@DAddYE maybe s3\/cloudfront is hosed from where you are?",
  "id" : 90901262236790784,
  "in_reply_to_status_id" : 90835104334749696,
  "created_at" : "2011-07-12 21:52:04 +0000",
  "in_reply_to_screen_name" : "DAddYE",
  "in_reply_to_user_id_str" : "14436377",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barttenbrinke",
      "screen_name" : "barttenbrinke",
      "indices" : [ 0, 14 ],
      "id_str" : "38826236",
      "id" : 38826236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90862091363303426",
  "geo" : { },
  "id_str" : "90895383009558528",
  "in_reply_to_user_id" : 38826236,
  "text" : "@barttenbrinke yes, it's alphanumeric only.",
  "id" : 90895383009558528,
  "in_reply_to_status_id" : 90862091363303426,
  "created_at" : "2011-07-12 21:28:42 +0000",
  "in_reply_to_screen_name" : "barttenbrinke",
  "in_reply_to_user_id_str" : "38826236",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Pearson News",
      "screen_name" : "mipearson",
      "indices" : [ 0, 10 ],
      "id_str" : "15630518",
      "id" : 15630518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90676681681022976",
  "geo" : { },
  "id_str" : "90790078288375808",
  "in_reply_to_user_id" : 15630518,
  "text" : "@mipearson you could use the api to make such a service! :)",
  "id" : 90790078288375808,
  "in_reply_to_status_id" : 90676681681022976,
  "created_at" : "2011-07-12 14:30:16 +0000",
  "in_reply_to_screen_name" : "mipearson",
  "in_reply_to_user_id_str" : "15630518",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90785197611679745",
  "text" : "Red line is DOA, watched the train go in reverse on inbound side at porter. Jumped back on the commuter rail, what a clusterfuck",
  "id" : 90785197611679745,
  "created_at" : "2011-07-12 14:10:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 0, 12 ],
      "id_str" : "8828952",
      "id" : 8828952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90771617344524289",
  "geo" : { },
  "id_str" : "90773409855840256",
  "in_reply_to_user_id" : 8828952,
  "text" : "@codeofficer also the downeaster hit a truck yesterday and there was 1 fatality....",
  "id" : 90773409855840256,
  "in_reply_to_status_id" : 90771617344524289,
  "created_at" : "2011-07-12 13:24:02 +0000",
  "in_reply_to_screen_name" : "codeofficer",
  "in_reply_to_user_id_str" : "8828952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 0, 12 ],
      "id_str" : "8828952",
      "id" : 8828952
    }, {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 23, 32 ],
      "id_str" : "21431343",
      "id" : 21431343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90756594748497921",
  "geo" : { },
  "id_str" : "90770355723059200",
  "in_reply_to_user_id" : 8828952,
  "text" : "@codeofficer coming to @bostonrb tonight?",
  "id" : 90770355723059200,
  "in_reply_to_status_id" : 90756594748497921,
  "created_at" : "2011-07-12 13:11:53 +0000",
  "in_reply_to_screen_name" : "codeofficer",
  "in_reply_to_user_id_str" : "8828952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http:\/\/t.co\/eWtEtsr",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=KHy7DGLTt8g",
      "display_url" : "youtube.com\/watch?v=KHy7DG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "90750972112019456",
  "text" : "I challenge you...to listen to 10 HOURS OF EPIC SAX GUY. http:\/\/t.co\/eWtEtsr",
  "id" : 90750972112019456,
  "created_at" : "2011-07-12 11:54:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 29, 39 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 107 ],
      "url" : "http:\/\/t.co\/3GER4EL",
      "expanded_url" : "https:\/\/github.com\/rubygems\/gemcutter\/compare\/281d758f3b86f2d41b3bbc5d90a3180d27a5055c",
      "display_url" : "github.com\/rubygems\/gemcu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "90639487150981120",
  "text" : "Also did a ton of cleanup on @gemcutter tonight, will deploy tomorrow! Refactoring ftw. http:\/\/t.co\/3GER4EL...master",
  "id" : 90639487150981120,
  "created_at" : "2011-07-12 04:31:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 62 ],
      "url" : "http:\/\/t.co\/30yYHRC",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/funny\/comments\/imwsi\/damned_huskies_always_hyper\/",
      "display_url" : "reddit.com\/r\/funny\/commen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "90638729881980928",
  "text" : "This reddit thread is pretty much my life: http:\/\/t.co\/30yYHRC",
  "id" : 90638729881980928,
  "created_at" : "2011-07-12 04:28:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90582376857608193",
  "geo" : { },
  "id_str" : "90582750872080385",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt reuse if you know what i mean nudge nudge wink wink say no more say no more",
  "id" : 90582750872080385,
  "in_reply_to_status_id" : 90582376857608193,
  "created_at" : "2011-07-12 00:46:25 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90560409584664576",
  "geo" : { },
  "id_str" : "90569800291598336",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi nailed it, exactly why I don't like Steak. Cuke forces you to stay abstract and not get caught up in implementation details.",
  "id" : 90569800291598336,
  "in_reply_to_status_id" : 90560409584664576,
  "created_at" : "2011-07-11 23:54:57 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 62, 73 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90550337781497857",
  "text" : "Apparently birds think they can ship too...right into the new @thoughtbot office windows.",
  "id" : 90550337781497857,
  "created_at" : "2011-07-11 22:37:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Fayram",
      "screen_name" : "KirinDave",
      "indices" : [ 0, 10 ],
      "id_str" : "784519",
      "id" : 784519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90536486541332480",
  "geo" : { },
  "id_str" : "90540574985306112",
  "in_reply_to_user_id" : 784519,
  "text" : "@KirinDave i thought for a moment you were on NetHack's plane of earth",
  "id" : 90540574985306112,
  "in_reply_to_status_id" : 90536486541332480,
  "created_at" : "2011-07-11 21:58:49 +0000",
  "in_reply_to_screen_name" : "KirinDave",
  "in_reply_to_user_id_str" : "784519",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 37 ],
      "url" : "http:\/\/t.co\/yfuFtjH",
      "expanded_url" : "http:\/\/hackertyper.net\/",
      "display_url" : "hackertyper.net"
    } ]
  },
  "geo" : { },
  "id_str" : "90518333283254272",
  "text" : "LEET HAXXORS ONLY http:\/\/t.co\/yfuFtjH",
  "id" : 90518333283254272,
  "created_at" : "2011-07-11 20:30:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90496911722811392",
  "geo" : { },
  "id_str" : "90504931450163201",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant grats dude, what's next?",
  "id" : 90504931450163201,
  "in_reply_to_status_id" : 90496911722811392,
  "created_at" : "2011-07-11 19:37:11 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 45 ],
      "url" : "http:\/\/t.co\/QQXMQSX",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=AaEmCFiNqP0",
      "display_url" : "youtube.com\/watch?v=AaEmCF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "90484672001351680",
  "text" : "I can't..stop...myself... http:\/\/t.co\/QQXMQSX",
  "id" : 90484672001351680,
  "created_at" : "2011-07-11 18:16:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90459600683417600",
  "text" : "@nilmethod most of them have old, crufty APIs that don't feel at all like Ruby",
  "id" : 90459600683417600,
  "created_at" : "2011-07-11 16:37:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90459512720465921",
  "text" : "@nilmethod they're terribly maintained and not gems, makes upgrading them and depending on them a nightmare, imo",
  "id" : 90459512720465921,
  "created_at" : "2011-07-11 16:36:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 0, 5 ],
      "id_str" : "20941662",
      "id" : 20941662
    }, {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 6, 18 ],
      "id_str" : "517029319",
      "id" : 517029319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90456222259613698",
  "in_reply_to_user_id" : 20941662,
  "text" : "@JEG2 @seacreature i still want to kill the stdlib and make a set of 'blessed' gems",
  "id" : 90456222259613698,
  "created_at" : "2011-07-11 16:23:38 +0000",
  "in_reply_to_screen_name" : "JEG2",
  "in_reply_to_user_id_str" : "20941662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 0, 5 ],
      "id_str" : "20941662",
      "id" : 20941662
    }, {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 6, 18 ],
      "id_str" : "517029319",
      "id" : 517029319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90451993033846784",
  "geo" : { },
  "id_str" : "90456116454109184",
  "in_reply_to_user_id" : 20941662,
  "text" : "@JEG2 @seacreature dear lord why can't they use gems :(",
  "id" : 90456116454109184,
  "in_reply_to_status_id" : 90451993033846784,
  "created_at" : "2011-07-11 16:23:13 +0000",
  "in_reply_to_screen_name" : "JEG2",
  "in_reply_to_user_id_str" : "20941662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90435716458356736",
  "geo" : { },
  "id_str" : "90436471978344448",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek yeah i haven't been able to get on because of that...fuck that",
  "id" : 90436471978344448,
  "in_reply_to_status_id" : 90435716458356736,
  "created_at" : "2011-07-11 15:05:09 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Lowell",
      "screen_name" : "cowboyd",
      "indices" : [ 0, 8 ],
      "id_str" : "791224",
      "id" : 791224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 28 ],
      "url" : "http:\/\/t.co\/2sYCTZO",
      "expanded_url" : "https:\/\/gist.github.com\/1075019",
      "display_url" : "gist.github.com\/1075019"
    } ]
  },
  "in_reply_to_status_id_str" : "90426404407226369",
  "geo" : { },
  "id_str" : "90427973336969216",
  "in_reply_to_user_id" : 791224,
  "text" : "@cowboyd http:\/\/t.co\/2sYCTZO",
  "id" : 90427973336969216,
  "in_reply_to_status_id" : 90426404407226369,
  "created_at" : "2011-07-11 14:31:23 +0000",
  "in_reply_to_screen_name" : "cowboyd",
  "in_reply_to_user_id_str" : "791224",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Lowell",
      "screen_name" : "cowboyd",
      "indices" : [ 0, 8 ],
      "id_str" : "791224",
      "id" : 791224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90424640819822594",
  "geo" : { },
  "id_str" : "90426208797466624",
  "in_reply_to_user_id" : 791224,
  "text" : "@cowboyd this is on snow leopard, i'm not prepared yet to enter the stupid madness that is Lion",
  "id" : 90426208797466624,
  "in_reply_to_status_id" : 90424640819822594,
  "created_at" : "2011-07-11 14:24:22 +0000",
  "in_reply_to_screen_name" : "cowboyd",
  "in_reply_to_user_id_str" : "791224",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/iYyT2th",
      "expanded_url" : "http:\/\/i.imgur.com\/2zOFO.jpg",
      "display_url" : "i.imgur.com\/2zOFO.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "90424402809860096",
  "text" : "Current status: http:\/\/t.co\/iYyT2th",
  "id" : 90424402809860096,
  "created_at" : "2011-07-11 14:17:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90240371858223104",
  "geo" : { },
  "id_str" : "90257751627927553",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant HTTB, that's how most brommunication happens these days",
  "id" : 90257751627927553,
  "in_reply_to_status_id" : 90240371858223104,
  "created_at" : "2011-07-11 03:14:59 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 0, 7 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90219021198303232",
  "geo" : { },
  "id_str" : "90221443685687296",
  "in_reply_to_user_id" : 15317640,
  "text" : "@hone02 yes it, and that would be great",
  "id" : 90221443685687296,
  "in_reply_to_status_id" : 90219021198303232,
  "created_at" : "2011-07-11 00:50:43 +0000",
  "in_reply_to_screen_name" : "hone02",
  "in_reply_to_user_id_str" : "15317640",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90180531723046912",
  "text" : "Yep, giving up on programming until tomorrow. Thanks for making this more complicated, Rails.",
  "id" : 90180531723046912,
  "created_at" : "2011-07-10 22:08:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 118 ],
      "url" : "http:\/\/t.co\/abgWDlH",
      "expanded_url" : "https:\/\/gist.github.com\/1075023",
      "display_url" : "gist.github.com\/1075023"
    } ]
  },
  "geo" : { },
  "id_str" : "90180292983271425",
  "text" : "Removed coffee-script from the Gemfile, now getting an activation error and I'm *on* Bundler. Wow. http:\/\/t.co\/abgWDlH",
  "id" : 90180292983271425,
  "created_at" : "2011-07-10 22:07:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90179682691055616",
  "text" : "Something failed locally when compiling v8, so yeah, fuck this nonsense.",
  "id" : 90179682691055616,
  "created_at" : "2011-07-10 22:04:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 113 ],
      "url" : "http:\/\/t.co\/aIDXhMR",
      "expanded_url" : "http:\/\/ridingrails.net\/heroku-rails-3-1-bamboo-cedar\/",
      "display_url" : "ridingrails.net\/heroku-rails-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "90179368156020736",
  "text" : "This is crazy, you have to bundle in v8 to even get a rails app working on Heroku? Fuck this. http:\/\/t.co\/aIDXhMR",
  "id" : 90179368156020736,
  "created_at" : "2011-07-10 22:03:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90168131967922176",
  "text" : "41 gems required for a freshly generated Rails 3.1 app. Just counting, here.",
  "id" : 90168131967922176,
  "created_at" : "2011-07-10 21:18:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90156268450361344",
  "text" : "TNG on Netflix!!!! ZOMG.",
  "id" : 90156268450361344,
  "created_at" : "2011-07-10 20:31:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 100 ],
      "url" : "http:\/\/t.co\/pGAgTfm",
      "expanded_url" : "https:\/\/img.skitch.com\/20110710-mhqpp8dr9etwwejxxtqsy8484a.png",
      "display_url" : "img.skitch.com\/20110710-mhqpp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "90098164195008512",
  "text" : "The fortress has gotten a lot more ridiculous, now with a working elevator too!! http:\/\/t.co\/pGAgTfm",
  "id" : 90098164195008512,
  "created_at" : "2011-07-10 16:40:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90080165580914688",
  "text" : "Current status: http:\/\/yfrog.com\/kldvidj",
  "id" : 90080165580914688,
  "created_at" : "2011-07-10 15:29:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daveott",
      "screen_name" : "daveott",
      "indices" : [ 0, 8 ],
      "id_str" : "14727265",
      "id" : 14727265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90056344463343616",
  "geo" : { },
  "id_str" : "90057446671912960",
  "in_reply_to_user_id" : 14727265,
  "text" : "@daveott I'm sure mongodb supports tape drives, definitely could cluster those up",
  "id" : 90057446671912960,
  "in_reply_to_status_id" : 90056344463343616,
  "created_at" : "2011-07-10 13:59:03 +0000",
  "in_reply_to_screen_name" : "daveott",
  "in_reply_to_user_id_str" : "14727265",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90055997623762946",
  "text" : "Beer pong for ages 9+ even comes with a douchey sweatband! http:\/\/yfrog.com\/ki9kydaj",
  "id" : 90055997623762946,
  "created_at" : "2011-07-10 13:53:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90042351686402048",
  "geo" : { },
  "id_str" : "90042905858818049",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits just wait until you learn macros, then you'll feel like a composer",
  "id" : 90042905858818049,
  "in_reply_to_status_id" : 90042351686402048,
  "created_at" : "2011-07-10 13:01:16 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90037171028893696",
  "geo" : { },
  "id_str" : "90038300387196928",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl invest",
  "id" : 90038300387196928,
  "in_reply_to_status_id" : 90037171028893696,
  "created_at" : "2011-07-10 12:42:58 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sven Fuchs",
      "screen_name" : "svenfuchs",
      "indices" : [ 0, 10 ],
      "id_str" : "9459332",
      "id" : 9459332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90015886429257728",
  "geo" : { },
  "id_str" : "90017240275091456",
  "in_reply_to_user_id" : 9459332,
  "text" : "@svenfuchs maybe uploads disabled, but not shut down\/off.",
  "id" : 90017240275091456,
  "in_reply_to_status_id" : 90015886429257728,
  "created_at" : "2011-07-10 11:19:17 +0000",
  "in_reply_to_screen_name" : "svenfuchs",
  "in_reply_to_user_id_str" : "9459332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sven Fuchs",
      "screen_name" : "svenfuchs",
      "indices" : [ 0, 10 ],
      "id_str" : "9459332",
      "id" : 9459332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90015886429257728",
  "geo" : { },
  "id_str" : "90017166463733760",
  "in_reply_to_user_id" : 9459332,
  "text" : "@svenfuchs and at once thousands of links from the first years of ruby and gems screamed out in terror",
  "id" : 90017166463733760,
  "in_reply_to_status_id" : 90015886429257728,
  "created_at" : "2011-07-10 11:18:59 +0000",
  "in_reply_to_screen_name" : "svenfuchs",
  "in_reply_to_user_id_str" : "9459332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yardboy",
      "screen_name" : "Yardboy",
      "indices" : [ 0, 8 ],
      "id_str" : "7939892",
      "id" : 7939892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89761886819713024",
  "geo" : { },
  "id_str" : "89762332347072512",
  "in_reply_to_user_id" : 7939892,
  "text" : "@Yardboy no worries!",
  "id" : 89762332347072512,
  "in_reply_to_status_id" : 89761886819713024,
  "created_at" : "2011-07-09 18:26:22 +0000",
  "in_reply_to_screen_name" : "Yardboy",
  "in_reply_to_user_id_str" : "7939892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 0, 8 ],
      "id_str" : "839931",
      "id" : 839931
    }, {
      "name" : "Tim Sharpe",
      "screen_name" : "rodjek",
      "indices" : [ 9, 16 ],
      "id_str" : "14439880",
      "id" : 14439880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89723115403354113",
  "geo" : { },
  "id_str" : "89723459889938434",
  "in_reply_to_user_id" : 839931,
  "text" : "@ddollar @rodjek email me your ssh key (nick@quaran.to) and i'll give you access to do whatever",
  "id" : 89723459889938434,
  "in_reply_to_status_id" : 89723115403354113,
  "created_at" : "2011-07-09 15:51:54 +0000",
  "in_reply_to_screen_name" : "ddollar",
  "in_reply_to_user_id_str" : "839931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 0, 8 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 28 ],
      "url" : "http:\/\/t.co\/PQG4cbn",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=cqkF6Ax-Pr4",
      "display_url" : "youtube.com\/watch?v=cqkF6A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "89573274513715200",
  "in_reply_to_user_id" : 839931,
  "text" : "@ddollar http:\/\/t.co\/PQG4cbn",
  "id" : 89573274513715200,
  "created_at" : "2011-07-09 05:55:07 +0000",
  "in_reply_to_screen_name" : "ddollar",
  "in_reply_to_user_id_str" : "839931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jeffrydegrande",
      "screen_name" : "jeffrydegrande",
      "indices" : [ 0, 15 ],
      "id_str" : "12638032",
      "id" : 12638032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89513990945902592",
  "geo" : { },
  "id_str" : "89516915063664640",
  "in_reply_to_user_id" : 12638032,
  "text" : "@jeffrydegrande we've probably had 12-15ish?",
  "id" : 89516915063664640,
  "in_reply_to_status_id" : 89513990945902592,
  "created_at" : "2011-07-09 02:11:10 +0000",
  "in_reply_to_screen_name" : "jeffrydegrande",
  "in_reply_to_user_id_str" : "12638032",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 90 ],
      "url" : "http:\/\/t.co\/VXB7rG9",
      "expanded_url" : "https:\/\/img.skitch.com\/20110709-1w2bxm1hs6kiww6ae5975iwhs6.png",
      "display_url" : "img.skitch.com\/20110709-1w2bx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "89512203241259008",
  "text" : "Really far away from the fortress, but I kind of want to link it up... http:\/\/t.co\/VXB7rG9",
  "id" : 89512203241259008,
  "created_at" : "2011-07-09 01:52:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/MeI3Div",
      "expanded_url" : "https:\/\/img.skitch.com\/20110709-ctb3k36hfbthd7bxsfpiyj8jxt.png",
      "display_url" : "img.skitch.com\/20110709-ctb3k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "89511652692738048",
  "text" : "Whoa, someone made an awesome bridge on minecraft.quaran.to: http:\/\/t.co\/MeI3Div",
  "id" : 89511652692738048,
  "created_at" : "2011-07-09 01:50:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 40 ],
      "url" : "http:\/\/t.co\/mgOrRoZ",
      "expanded_url" : "http:\/\/code.google.com\/p\/google-singleton-detector\/",
      "display_url" : "code.google.com\/p\/google-singl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "89509623329079297",
  "text" : "Death to singletons! http:\/\/t.co\/mgOrRoZ",
  "id" : 89509623329079297,
  "created_at" : "2011-07-09 01:42:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 59 ],
      "url" : "http:\/\/t.co\/Y1HgT47",
      "expanded_url" : "http:\/\/www.buffalonews.com\/city\/communities\/batavia-genesee-county\/article482668.ece",
      "display_url" : "buffalonews.com\/city\/communiti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "89509192146231296",
  "text" : "Whoa...been on this ride tons of times. http:\/\/t.co\/Y1HgT47",
  "id" : 89509192146231296,
  "created_at" : "2011-07-09 01:40:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2192() \u007B Robertt \u007D",
      "screen_name" : "robertodecurnex",
      "indices" : [ 3, 19 ],
      "id_str" : "63124269",
      "id" : 63124269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89508909571768322",
  "text" : "RT @robertodecurnex: Thank you @gemcutter\/contributors ! You rock !",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/timely.is\" rel=\"nofollow\"\u003ETimely by Demandforce\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "89450538135068673",
    "text" : "Thank you @gemcutter\/contributors ! You rock !",
    "id" : 89450538135068673,
    "created_at" : "2011-07-08 21:47:24 +0000",
    "user" : {
      "name" : "\u2192() \u007B Robertt \u007D",
      "screen_name" : "robertodecurnex",
      "protected" : false,
      "id_str" : "63124269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427905631199064064\/91pV17Xt_normal.png",
      "id" : 63124269,
      "verified" : false
    }
  },
  "id" : 89508909571768322,
  "created_at" : "2011-07-09 01:39:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 0, 8 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89498262578536448",
  "geo" : { },
  "id_str" : "89498737881264128",
  "in_reply_to_user_id" : 839931,
  "text" : "@ddollar will do when I get home, in a few. Maybe should just cron restart every 6 hrs",
  "id" : 89498737881264128,
  "in_reply_to_status_id" : 89498262578536448,
  "created_at" : "2011-07-09 00:58:56 +0000",
  "in_reply_to_screen_name" : "ddollar",
  "in_reply_to_user_id_str" : "839931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 0, 6 ],
      "id_str" : "15359408",
      "id" : 15359408
    }, {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 30, 37 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89496529081073665",
  "geo" : { },
  "id_str" : "89498319247785984",
  "in_reply_to_user_id" : 15359408,
  "text" : "@raggi err, I meant excon \/cc @geemus",
  "id" : 89498319247785984,
  "in_reply_to_status_id" : 89496529081073665,
  "created_at" : "2011-07-09 00:57:16 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 0, 6 ],
      "id_str" : "15359408",
      "id" : 15359408
    }, {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 56, 63 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89496529081073665",
  "geo" : { },
  "id_str" : "89498258874957824",
  "in_reply_to_user_id" : 15359408,
  "text" : "@raggi weak. Maybe fog should support eventmachine? \/cc @geemus",
  "id" : 89498258874957824,
  "in_reply_to_status_id" : 89496529081073665,
  "created_at" : "2011-07-09 00:57:02 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 0, 6 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89483767407845376",
  "geo" : { },
  "id_str" : "89487343404326912",
  "in_reply_to_user_id" : 15359408,
  "text" : "@raggi the beta is much better, but it's still mad confusing",
  "id" : 89487343404326912,
  "in_reply_to_status_id" : 89483767407845376,
  "created_at" : "2011-07-09 00:13:39 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Remsik",
      "screen_name" : "jremsikjr",
      "indices" : [ 0, 10 ],
      "id_str" : "1942",
      "id" : 1942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89348384422510594",
  "geo" : { },
  "id_str" : "89348713415319552",
  "in_reply_to_user_id" : 1942,
  "text" : "@jremsikjr sure, i'd try it",
  "id" : 89348713415319552,
  "in_reply_to_status_id" : 89348384422510594,
  "created_at" : "2011-07-08 15:02:47 +0000",
  "in_reply_to_screen_name" : "jremsikjr",
  "in_reply_to_user_id_str" : "1942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/BHu3XJp",
      "expanded_url" : "http:\/\/www.nasa.gov\/multimedia\/nasatv\/",
      "display_url" : "nasa.gov\/multimedia\/nas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "89345642157178880",
  "text" : "Last space shuttle launch today, end of an era. http:\/\/t.co\/BHu3XJp",
  "id" : 89345642157178880,
  "created_at" : "2011-07-08 14:50:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/oCKACyR",
      "expanded_url" : "http:\/\/i.imgur.com\/Eqrhz.jpg",
      "display_url" : "i.imgur.com\/Eqrhz.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "89342495372214272",
  "text" : "Current status: http:\/\/t.co\/oCKACyR",
  "id" : 89342495372214272,
  "created_at" : "2011-07-08 14:38:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89156138838392834",
  "text" : "Awesome license plate: http:\/\/yfrog.com\/ki5zmkmj",
  "id" : 89156138838392834,
  "created_at" : "2011-07-08 02:17:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89136611316613120",
  "text" : "New updates on minecraft.quaran.to: bridge built out to have a roof, connected to another tower. Building down now to help find slimes!",
  "id" : 89136611316613120,
  "created_at" : "2011-07-08 00:59:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yardboy",
      "screen_name" : "Yardboy",
      "indices" : [ 0, 8 ],
      "id_str" : "7939892",
      "id" : 7939892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89118330815922178",
  "geo" : { },
  "id_str" : "89123549025026048",
  "in_reply_to_user_id" : 7939892,
  "text" : "@Yardboy my only rule is don't be a dick",
  "id" : 89123549025026048,
  "in_reply_to_status_id" : 89118330815922178,
  "created_at" : "2011-07-08 00:08:04 +0000",
  "in_reply_to_screen_name" : "Yardboy",
  "in_reply_to_user_id_str" : "7939892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89118793774800896",
  "text" : "First homemade mojito: great success! http:\/\/yfrog.com\/kh8d3ngj",
  "id" : 89118793774800896,
  "created_at" : "2011-07-07 23:49:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 29 ],
      "url" : "http:\/\/t.co\/qdMOxlw",
      "expanded_url" : "http:\/\/www.codyfauser.com\/2008\/7\/4\/rails-http-status-code-to-symbol-mapping",
      "display_url" : "codyfauser.com\/2008\/7\/4\/rails\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "89062996541845505",
  "geo" : { },
  "id_str" : "89070699108515841",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg http:\/\/t.co\/qdMOxlw",
  "id" : 89070699108515841,
  "in_reply_to_status_id" : 89062996541845505,
  "created_at" : "2011-07-07 20:38:04 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Beveridge",
      "screen_name" : "davidjbeveridge",
      "indices" : [ 0, 16 ],
      "id_str" : "64652553",
      "id" : 64652553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http:\/\/t.co\/kpjtZ3O",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/2729333530\/fetching-source-index-for-http-rubygems-org",
      "display_url" : "robots.thoughtbot.com\/post\/272933353\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "89031814357843968",
  "geo" : { },
  "id_str" : "89034819786391553",
  "in_reply_to_user_id" : 64652553,
  "text" : "@davidjbeveridge yes? everyone has to deal with it. have you read http:\/\/t.co\/kpjtZ3O ?",
  "id" : 89034819786391553,
  "in_reply_to_status_id" : 89031814357843968,
  "created_at" : "2011-07-07 18:15:29 +0000",
  "in_reply_to_screen_name" : "davidjbeveridge",
  "in_reply_to_user_id_str" : "64652553",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89033808376115200",
  "text" : "I'm so glad I have to still refer to a 3+ year old blog post for Rails status codes instead of official docs.",
  "id" : 89033808376115200,
  "created_at" : "2011-07-07 18:11:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 55, 64 ],
      "id_str" : "9267332",
      "id" : 9267332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 25 ],
      "url" : "http:\/\/t.co\/MANyF8G",
      "expanded_url" : "http:\/\/vastimg.herokuapp.com\/",
      "display_url" : "vastimg.herokuapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "89020519390789634",
  "text" : "Go to http:\/\/t.co\/MANyF8G , hit Spacebar, win. (thanks @rtomayko!)",
  "id" : 89020519390789634,
  "created_at" : "2011-07-07 17:18:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/QrFXKa5",
      "expanded_url" : "http:\/\/27.media.tumblr.com\/tumblr_ksnbayiAwc1qzflvuo1_500.jpg",
      "display_url" : "27.media.tumblr.com\/tumblr_ksnbayi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "89016159847976960",
  "text" : "Current status: http:\/\/t.co\/QrFXKa5",
  "id" : 89016159847976960,
  "created_at" : "2011-07-07 17:01:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 37, 47 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 68 ],
      "url" : "http:\/\/t.co\/Y9rQAbj",
      "expanded_url" : "http:\/\/bit.ly\/r00aKz",
      "display_url" : "bit.ly\/r00aKz"
    } ]
  },
  "geo" : { },
  "id_str" : "88981528415178752",
  "text" : "I'm looking for more maintainers for @gemcutter: http:\/\/t.co\/Y9rQAbj",
  "id" : 88981528415178752,
  "created_at" : "2011-07-07 14:43:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http:\/\/t.co\/QLdfHsJ",
      "expanded_url" : "http:\/\/www.minecraftwiki.net\/wiki\/Redstone_circuits",
      "display_url" : "minecraftwiki.net\/wiki\/Redstone_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "88948614537285633",
  "text" : "This is by far the most math\/engineering I've ever seen in a game. http:\/\/t.co\/QLdfHsJ",
  "id" : 88948614537285633,
  "created_at" : "2011-07-07 12:32:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88820484740886528",
  "text" : "Did not much else on minecraft.quaran.to but explore huge caves and dig up some awesome stuff...will have to learn redstone another day",
  "id" : 88820484740886528,
  "created_at" : "2011-07-07 04:03:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Dave Jacobs",
      "screen_name" : "dave_jacobs",
      "indices" : [ 9, 21 ],
      "id_str" : "1117999368",
      "id" : 1117999368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88819060204244992",
  "geo" : { },
  "id_str" : "88820137628663808",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @dave_jacobs whaaa? First I've heard of that",
  "id" : 88820137628663808,
  "in_reply_to_status_id" : 88819060204244992,
  "created_at" : "2011-07-07 04:02:25 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Woodbridge",
      "screen_name" : "jrwoodbridge",
      "indices" : [ 0, 13 ],
      "id_str" : "19318821",
      "id" : 19318821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88784283975696386",
  "geo" : { },
  "id_str" : "88785174745198594",
  "in_reply_to_user_id" : 19318821,
  "text" : "@jrwoodbridge yes! thats the whole point. join and build!",
  "id" : 88785174745198594,
  "in_reply_to_status_id" : 88784283975696386,
  "created_at" : "2011-07-07 01:43:29 +0000",
  "in_reply_to_screen_name" : "jrwoodbridge",
  "in_reply_to_user_id_str" : "19318821",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88781967742599168",
  "text" : "More structures appearing on minecraft.quaran.to! Two new towers near the volcano, more secret rooms in the fortress, and a sugarcane farm!",
  "id" : 88781967742599168,
  "created_at" : "2011-07-07 01:30:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 44, 55 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 90 ],
      "url" : "http:\/\/t.co\/Co5n3wl",
      "expanded_url" : "https:\/\/github.com\/thoughtbot\/bourbon\/blame\/master\/generate-sass.sh",
      "display_url" : "github.com\/thoughtbot\/bou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "88721704955822081",
  "text" : "Designers slamming out some bash scripts at @thoughtbot. What's next!? http:\/\/t.co\/Co5n3wl",
  "id" : 88721704955822081,
  "created_at" : "2011-07-06 21:31:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 3, 11 ],
      "id_str" : "28819745",
      "id" : 28819745
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 36, 47 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88688886611591169",
  "text" : "RT @sikachu: \"I see you\" \u2014 Ralph at @thoughtbot http:\/\/instagr.am\/p\/HGJvv\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "thoughtbot",
        "screen_name" : "thoughtbot",
        "indices" : [ 23, 34 ],
        "id_str" : "14114392",
        "id" : 14114392
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88685775578873856",
    "text" : "\"I see you\" \u2014 Ralph at @thoughtbot http:\/\/instagr.am\/p\/HGJvv\/",
    "id" : 88685775578873856,
    "created_at" : "2011-07-06 19:08:31 +0000",
    "user" : {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "protected" : false,
      "id_str" : "28819745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548464438928355328\/uUhXMR2__normal.png",
      "id" : 28819745,
      "verified" : false
    }
  },
  "id" : 88688886611591169,
  "created_at" : "2011-07-06 19:20:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Sharpe",
      "screen_name" : "rodjek",
      "indices" : [ 0, 7 ],
      "id_str" : "14439880",
      "id" : 14439880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88569037545668608",
  "geo" : { },
  "id_str" : "88585751272497152",
  "in_reply_to_user_id" : 14439880,
  "text" : "@rodjek oh, duh",
  "id" : 88585751272497152,
  "in_reply_to_status_id" : 88569037545668608,
  "created_at" : "2011-07-06 12:31:03 +0000",
  "in_reply_to_screen_name" : "rodjek",
  "in_reply_to_user_id_str" : "14439880",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roy Osherove",
      "screen_name" : "RoyOsherove",
      "indices" : [ 3, 15 ],
      "id_str" : "14186105",
      "id" : 14186105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88585556338020352",
  "text" : "RT @RoyOsherove: When I said MS doesn't deserve great developers because it doesn't want great developers, I meant things like this: htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88562388995022848",
    "text" : "When I said MS doesn't deserve great developers because it doesn't want great developers, I meant things like this: http:\/\/bit.ly\/pNBKUS",
    "id" : 88562388995022848,
    "created_at" : "2011-07-06 10:58:13 +0000",
    "user" : {
      "name" : "Roy Osherove",
      "screen_name" : "RoyOsherove",
      "protected" : false,
      "id_str" : "14186105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1416811497\/Self_organizing_normal.jpg",
      "id" : 14186105,
      "verified" : false
    }
  },
  "id" : 88585556338020352,
  "created_at" : "2011-07-06 12:30:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Sharpe",
      "screen_name" : "rodjek",
      "indices" : [ 0, 7 ],
      "id_str" : "14439880",
      "id" : 14439880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88555456938786817",
  "geo" : { },
  "id_str" : "88568805814571008",
  "in_reply_to_user_id" : 14439880,
  "text" : "@rodjek isn't there one already on the south side?",
  "id" : 88568805814571008,
  "in_reply_to_status_id" : 88555456938786817,
  "created_at" : "2011-07-06 11:23:43 +0000",
  "in_reply_to_screen_name" : "rodjek",
  "in_reply_to_user_id_str" : "14439880",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 12, 23 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88391329230503936",
  "text" : "Zomg a wild @tenderlove appears! I HERD HE IS BUILDING A SECRET BASE (i should too, my lakehouse got wrecked)",
  "id" : 88391329230503936,
  "created_at" : "2011-07-05 23:38:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 90 ],
      "url" : "http:\/\/t.co\/0n4FT9c",
      "expanded_url" : "https:\/\/github.com\/karrth\/minecraft-init",
      "display_url" : "github.com\/karrth\/minecra\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "88390204712427520",
  "geo" : { },
  "id_str" : "88391198338859009",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie not too bad, using this, I should push my changes to it. http:\/\/t.co\/0n4FT9c",
  "id" : 88391198338859009,
  "in_reply_to_status_id" : 88390204712427520,
  "created_at" : "2011-07-05 23:37:58 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Sharpe",
      "screen_name" : "rodjek",
      "indices" : [ 0, 7 ],
      "id_str" : "14439880",
      "id" : 14439880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88389842597191681",
  "geo" : { },
  "id_str" : "88391091006615552",
  "in_reply_to_user_id" : 14439880,
  "text" : "@rodjek yeah, oh well though. i wonder where it went!",
  "id" : 88391091006615552,
  "in_reply_to_status_id" : 88389842597191681,
  "created_at" : "2011-07-05 23:37:32 +0000",
  "in_reply_to_screen_name" : "rodjek",
  "in_reply_to_user_id_str" : "14439880",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88389433002434560",
  "text" : "Day 3 and minecraft.quaran.to grows stranger...lake house wrecked, all the diamond stolen. Lots of little huts\/forts, more stairs!",
  "id" : 88389433002434560,
  "created_at" : "2011-07-05 23:30:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 5, 15 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/eS11CGb",
      "expanded_url" : "http:\/\/timetobleed.com\/the-broken-promises-of-mrireeyarv\/",
      "display_url" : "timetobleed.com\/the-broken-pro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "88359334274273280",
  "text" : "This @joedamato post is some epic assembly hacking, but why not use Rubinius or some other implementation? http:\/\/t.co\/eS11CGb",
  "id" : 88359334274273280,
  "created_at" : "2011-07-05 21:31:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 9, 16 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/J7dGu36",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/7271137884\/testing-cron-on-heroku",
      "display_url" : "robots.thoughtbot.com\/post\/727113788\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "88346043175018496",
  "text" : "You like @heroku. And Cron. Why not test both!? http:\/\/t.co\/J7dGu36",
  "id" : 88346043175018496,
  "created_at" : "2011-07-05 20:38:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 13, 25 ],
      "id_str" : "15294983",
      "id" : 15294983
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 88, 96 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88280503052021760",
  "geo" : { },
  "id_str" : "88302847816507392",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @doctorzaius also the index regenerates in around 15 seconds now thanks to @evanphx. If it's fast let me know!",
  "id" : 88302847816507392,
  "in_reply_to_status_id" : 88280503052021760,
  "created_at" : "2011-07-05 17:46:54 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 13, 25 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88280503052021760",
  "geo" : { },
  "id_str" : "88281219976007682",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @doctorzaius we're back up, Delayed::Job drank too much last night",
  "id" : 88281219976007682,
  "in_reply_to_status_id" : 88280503052021760,
  "created_at" : "2011-07-05 16:20:57 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 36 ],
      "url" : "http:\/\/t.co\/P1cH6gM",
      "expanded_url" : "http:\/\/i.imgur.com\/CM4UX.png",
      "display_url" : "i.imgur.com\/CM4UX.png"
    } ]
  },
  "geo" : { },
  "id_str" : "88239844697968641",
  "text" : "Previous status: http:\/\/t.co\/P1cH6gM",
  "id" : 88239844697968641,
  "created_at" : "2011-07-05 13:36:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francisco Reyes",
      "screen_name" : "pacorro2000",
      "indices" : [ 0, 12 ],
      "id_str" : "2668571",
      "id" : 2668571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88230882971885570",
  "geo" : { },
  "id_str" : "88236388000088064",
  "in_reply_to_user_id" : 2668571,
  "text" : "@pacorro2000 Have you tried the Bundler prerelease? it's using a new API that is way faster",
  "id" : 88236388000088064,
  "in_reply_to_status_id" : 88230882971885570,
  "created_at" : "2011-07-05 13:22:48 +0000",
  "in_reply_to_screen_name" : "pacorro2000",
  "in_reply_to_user_id_str" : "2668571",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 59, 70 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 39 ],
      "url" : "http:\/\/t.co\/WmKbXZ8",
      "expanded_url" : "http:\/\/events.jquery.org\/2011\/boston\/",
      "display_url" : "events.jquery.org\/2011\/boston\/"
    } ]
  },
  "geo" : { },
  "id_str" : "88230895366053889",
  "text" : "Just registered for http:\/\/t.co\/WmKbXZ8. Who's going!? \/cc @shellscape",
  "id" : 88230895366053889,
  "created_at" : "2011-07-05 13:00:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88064238010122241",
  "text" : "I wonder how much energy\/power total across the US will be spent on recharging cameras that tried to take flash photos of fireworks tonight",
  "id" : 88064238010122241,
  "created_at" : "2011-07-05 01:58:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88060876233515008",
  "text" : "OH \"there's sharks in there!\"",
  "id" : 88060876233515008,
  "created_at" : "2011-07-05 01:45:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88058687616327681",
  "text" : "Waltham fireworks from the riverside! Awesome.",
  "id" : 88058687616327681,
  "created_at" : "2011-07-05 01:36:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88056024078090240",
  "geo" : { },
  "id_str" : "88057021219340288",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton READ A BOOK READ A BOOK READ A MOTHERFUCKING BOOK",
  "id" : 88057021219340288,
  "in_reply_to_status_id" : 88056024078090240,
  "created_at" : "2011-07-05 01:30:04 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 39 ],
      "url" : "http:\/\/t.co\/8JJ2L7W",
      "expanded_url" : "https:\/\/img.skitch.com\/20110705-t4cxnj22t2u1pg5sd299ytg8kg.png",
      "display_url" : "img.skitch.com\/20110705-t4cxn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "88038262370869248",
  "text" : "The fortress grows! http:\/\/t.co\/8JJ2L7W (on minecraft.quaran.to)",
  "id" : 88038262370869248,
  "created_at" : "2011-07-05 00:15:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88037063370342400",
  "text" : "Noticing now a volcano, a little side hut\/fortress, and a big greenhouse underneath the fortress! zomg!",
  "id" : 88037063370342400,
  "created_at" : "2011-07-05 00:10:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88035999124430848",
  "text" : "New on minecraft.quaran.to since last night...a huge mushroom farm, two new towers on the fortress, and a lake house! Even more epic!",
  "id" : 88035999124430848,
  "created_at" : "2011-07-05 00:06:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/Wd4hOYI",
      "expanded_url" : "http:\/\/i.imgur.com\/nDPJW.gif",
      "display_url" : "i.imgur.com\/nDPJW.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "88035554477867008",
  "text" : "Current status: http:\/\/t.co\/Wd4hOYI",
  "id" : 88035554477867008,
  "created_at" : "2011-07-05 00:04:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87991201394987008",
  "geo" : { },
  "id_str" : "87991644867145728",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil +1",
  "id" : 87991644867145728,
  "in_reply_to_status_id" : 87991201394987008,
  "created_at" : "2011-07-04 21:10:17 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87989351597879296",
  "geo" : { },
  "id_str" : "87991071715491841",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil yay ruby! Its even more fun when using Timecop and you forget to unfreeze",
  "id" : 87991071715491841,
  "in_reply_to_status_id" : 87989351597879296,
  "created_at" : "2011-07-04 21:08:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87990639240822784",
  "geo" : { },
  "id_str" : "87990804152459264",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek Y U NO RUN JAVA WITHOUT CRASHING",
  "id" : 87990804152459264,
  "in_reply_to_status_id" : 87990639240822784,
  "created_at" : "2011-07-04 21:06:57 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87980579898920960",
  "geo" : { },
  "id_str" : "87990243147513858",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu gonna chill in waltham tonight, sorry bro",
  "id" : 87990243147513858,
  "in_reply_to_status_id" : 87980579898920960,
  "created_at" : "2011-07-04 21:04:43 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87936945795244032",
  "geo" : { },
  "id_str" : "87942927304757248",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy stay classy hobos",
  "id" : 87942927304757248,
  "in_reply_to_status_id" : 87936945795244032,
  "created_at" : "2011-07-04 17:56:42 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87941092548427776",
  "text" : "Ended up at Denny's. To date have never planned to visit one, just nothing else was open.",
  "id" : 87941092548427776,
  "created_at" : "2011-07-04 17:49:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Sharpe",
      "screen_name" : "rodjek",
      "indices" : [ 0, 7 ],
      "id_str" : "14439880",
      "id" : 14439880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87685142910468096",
  "geo" : { },
  "id_str" : "87689992075350016",
  "in_reply_to_user_id" : 14439880,
  "text" : "@rodjek with",
  "id" : 87689992075350016,
  "in_reply_to_status_id" : 87685142910468096,
  "created_at" : "2011-07-04 01:11:37 +0000",
  "in_reply_to_screen_name" : "rodjek",
  "in_reply_to_user_id_str" : "14439880",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Zadrozny",
      "screen_name" : "nz_",
      "indices" : [ 5, 9 ],
      "id_str" : "49923",
      "id" : 49923
    }, {
      "name" : "Sir Bacon Pancakes",
      "screen_name" : "evilhackerdude",
      "indices" : [ 14, 29 ],
      "id_str" : "15150116",
      "id" : 15150116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87685093392531456",
  "text" : "Wow, @nz_ and @evilhackerdude did some seriously awesome work. Kudos!",
  "id" : 87685093392531456,
  "created_at" : "2011-07-04 00:52:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 60 ],
      "url" : "http:\/\/t.co\/CHszYAB",
      "expanded_url" : "https:\/\/img.skitch.com\/20110704-njfs4taq3edy2cfdwmpxs7cxye.png",
      "display_url" : "img.skitch.com\/20110704-njfs4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "87684663304388608",
  "text" : "Pimp mansion on top of the mountain now! http:\/\/t.co\/CHszYAB",
  "id" : 87684663304388608,
  "created_at" : "2011-07-04 00:50:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 66 ],
      "url" : "http:\/\/t.co\/HxmTTI4",
      "expanded_url" : "https:\/\/img.skitch.com\/20110704-xti4m7yh3wix66ihgumkqbtt4t.png",
      "display_url" : "img.skitch.com\/20110704-xti4m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "87684166233231360",
  "text" : "Whoa, minecraft.quaran.to is looking awesome!! http:\/\/t.co\/HxmTTI4",
  "id" : 87684166233231360,
  "created_at" : "2011-07-04 00:48:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87668636302589953",
  "text" : "These benchmarks are totally made up. Where's the code? http:\/\/yfrog.com\/h3or4hlj",
  "id" : 87668636302589953,
  "created_at" : "2011-07-03 23:46:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87664283990761472",
  "text" : "This gal\/sec clearly doesn't scale. http:\/\/yfrog.com\/h4op7tggj",
  "id" : 87664283990761472,
  "created_at" : "2011-07-03 23:29:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photo",
      "indices" : [ 101, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0800004833, -79.0743726333 ]
  },
  "id_str" : "87662172712345600",
  "text" : "Niagara river...river wild....kevin bacon! @ Terrapin Point - Horseshoe Falls http:\/\/gowal.la\/p\/g1qn #photo",
  "id" : 87662172712345600,
  "created_at" : "2011-07-03 23:21:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 31, 43 ],
      "id_str" : "248477732",
      "id" : 248477732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87654630418423808",
  "text" : "Picked up our invitations from @ecarlsen912...zomg thanks!",
  "id" : 87654630418423808,
  "created_at" : "2011-07-03 22:51:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AzRael",
      "screen_name" : "AzRael1",
      "indices" : [ 3, 11 ],
      "id_str" : "347474168",
      "id" : 347474168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87618890972151808",
  "text" : "RT @azrael1: Sign Of The Times  http:\/\/yfrog.com\/h43yf8j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/yfrog.com\" rel=\"nofollow\"\u003EYfrog\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "87457577209839616",
    "text" : "Sign Of The Times  http:\/\/yfrog.com\/h43yf8j",
    "id" : 87457577209839616,
    "created_at" : "2011-07-03 09:48:05 +0000",
    "user" : {
      "name" : "Alex Kane",
      "screen_name" : "MrAlexKane",
      "protected" : false,
      "id_str" : "19302176",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1456664607\/peterg_watercolor_normal.jpg",
      "id" : 19302176,
      "verified" : false
    }
  },
  "id" : 87618890972151808,
  "created_at" : "2011-07-03 20:29:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sir Bacon Pancakes",
      "screen_name" : "evilhackerdude",
      "indices" : [ 0, 15 ],
      "id_str" : "15150116",
      "id" : 15150116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87587029562564608",
  "geo" : { },
  "id_str" : "87587903114452992",
  "in_reply_to_user_id" : 15150116,
  "text" : "@evilhackerdude oh that's weak",
  "id" : 87587903114452992,
  "in_reply_to_status_id" : 87587029562564608,
  "created_at" : "2011-07-03 18:25:58 +0000",
  "in_reply_to_screen_name" : "evilhackerdude",
  "in_reply_to_user_id_str" : "15150116",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sir Bacon Pancakes",
      "screen_name" : "evilhackerdude",
      "indices" : [ 0, 15 ],
      "id_str" : "15150116",
      "id" : 15150116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87586160301441025",
  "geo" : { },
  "id_str" : "87586422994907136",
  "in_reply_to_user_id" : 15150116,
  "text" : "@evilhackerdude apparently creepers got up there. Agreed, but whitelisting sounds easier :)",
  "id" : 87586422994907136,
  "in_reply_to_status_id" : 87586160301441025,
  "created_at" : "2011-07-03 18:20:05 +0000",
  "in_reply_to_screen_name" : "evilhackerdude",
  "in_reply_to_user_id_str" : "15150116",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87582907396390912",
  "geo" : { },
  "id_str" : "87583378706145280",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 just last week, was company only this year. Sorry dude.",
  "id" : 87583378706145280,
  "in_reply_to_status_id" : 87582907396390912,
  "created_at" : "2011-07-03 18:07:59 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87581775248891904",
  "text" : "Current status: http:\/\/yfrog.com\/h2wtdznj",
  "id" : 87581775248891904,
  "created_at" : "2011-07-03 18:01:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steen Lehmann",
      "screen_name" : "slehmann",
      "indices" : [ 0, 9 ],
      "id_str" : "75863",
      "id" : 75863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87501597248200704",
  "geo" : { },
  "id_str" : "87520122469752832",
  "in_reply_to_user_id" : 75863,
  "text" : "@slehmann server should be back up, if it happens again I might start using the whitelist",
  "id" : 87520122469752832,
  "in_reply_to_status_id" : 87501597248200704,
  "created_at" : "2011-07-03 13:56:37 +0000",
  "in_reply_to_screen_name" : "slehmann",
  "in_reply_to_user_id_str" : "75863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87491417487835139",
  "text" : "Apparently the server was killed due to some idiots joining :( Haven't reset the world yet, but minecraft.quaran.to is back up!",
  "id" : 87491417487835139,
  "created_at" : "2011-07-03 12:02:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87481133125734400",
  "text" : "The minecraft server is seriously buggy, can't stay alive at all....also, I suck at even getting a simple init script up to restart it.",
  "id" : 87481133125734400,
  "created_at" : "2011-07-03 11:21:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 82, 90 ],
      "id_str" : "28819745",
      "id" : 28819745
    }, {
      "name" : "Nick Zadrozny",
      "screen_name" : "nz_",
      "indices" : [ 91, 95 ],
      "id_str" : "49923",
      "id" : 49923
    }, {
      "name" : "Sir Bacon Pancakes",
      "screen_name" : "evilhackerdude",
      "indices" : [ 96, 111 ],
      "id_str" : "15150116",
      "id" : 15150116
    }, {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 112, 124 ],
      "id_str" : "248477732",
      "id" : 248477732
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 125, 136 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87311414355697664",
  "text" : "Linode upgraded, upstart script in place, minecraft.quaran.to is alive again! \/cc @sikachu @nz_ @evilhackerdude @ecarlsen912 @tenderlove",
  "id" : 87311414355697664,
  "created_at" : "2011-07-03 00:07:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Zadrozny",
      "screen_name" : "nz_",
      "indices" : [ 0, 4 ],
      "id_str" : "49923",
      "id" : 49923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87279966693236736",
  "geo" : { },
  "id_str" : "87281337807024128",
  "in_reply_to_user_id" : 49923,
  "text" : "@nz_ wow this is seriously buggy server software.",
  "id" : 87281337807024128,
  "in_reply_to_status_id" : 87279966693236736,
  "created_at" : "2011-07-02 22:07:47 +0000",
  "in_reply_to_screen_name" : "nz_",
  "in_reply_to_user_id_str" : "49923",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sir Bacon Pancakes",
      "screen_name" : "evilhackerdude",
      "indices" : [ 0, 15 ],
      "id_str" : "15150116",
      "id" : 15150116
    }, {
      "name" : "Kyle Maxwell",
      "screen_name" : "kmx",
      "indices" : [ 16, 20 ],
      "id_str" : "1000901",
      "id" : 1000901
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 21, 29 ],
      "id_str" : "28819745",
      "id" : 28819745
    }, {
      "name" : "Nick Zadrozny",
      "screen_name" : "nz_",
      "indices" : [ 30, 34 ],
      "id_str" : "49923",
      "id" : 49923
    }, {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 35, 47 ],
      "id_str" : "248477732",
      "id" : 248477732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87260008135397376",
  "geo" : { },
  "id_str" : "87265788314140672",
  "in_reply_to_user_id" : 15150116,
  "text" : "@evilhackerdude @kmx @sikachu @nz_ @ecarlsen912 server should be back, not sure why it got killed in screen",
  "id" : 87265788314140672,
  "in_reply_to_status_id" : 87260008135397376,
  "created_at" : "2011-07-02 21:05:59 +0000",
  "in_reply_to_screen_name" : "evilhackerdude",
  "in_reply_to_user_id_str" : "15150116",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sir Bacon Pancakes",
      "screen_name" : "evilhackerdude",
      "indices" : [ 0, 15 ],
      "id_str" : "15150116",
      "id" : 15150116
    }, {
      "name" : "Nick Zadrozny",
      "screen_name" : "nz_",
      "indices" : [ 16, 20 ],
      "id_str" : "49923",
      "id" : 49923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87260008135397376",
  "geo" : { },
  "id_str" : "87262123121577984",
  "in_reply_to_user_id" : 15150116,
  "text" : "@evilhackerdude @nz_ my linode (or screen) may have crapped out... will check when I get home",
  "id" : 87262123121577984,
  "in_reply_to_status_id" : 87260008135397376,
  "created_at" : "2011-07-02 20:51:26 +0000",
  "in_reply_to_screen_name" : "evilhackerdude",
  "in_reply_to_user_id_str" : "15150116",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87233576881496065",
  "text" : "So far, a huge tower, big mine shaft, three forts! If anyone else is up for minecraft, connect to minecraft.quaran.to !",
  "id" : 87233576881496065,
  "created_at" : "2011-07-02 18:58:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87196137169231873",
  "geo" : { },
  "id_str" : "87197829956763648",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin nope, just messing around and learning",
  "id" : 87197829956763648,
  "in_reply_to_status_id" : 87196137169231873,
  "created_at" : "2011-07-02 16:35:57 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87177812557053952",
  "text" : "Learning how to play Minecraft! Want to play too? Running a server at minecraft.quaran.to",
  "id" : 87177812557053952,
  "created_at" : "2011-07-02 15:16:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87172441864019968",
  "text" : "Hi Buffalo!",
  "id" : 87172441864019968,
  "created_at" : "2011-07-02 14:55:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86781465173569536",
  "geo" : { },
  "id_str" : "86782023481556992",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin D is for Diploma!",
  "id" : 86782023481556992,
  "in_reply_to_status_id" : 86781465173569536,
  "created_at" : "2011-07-01 13:03:41 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
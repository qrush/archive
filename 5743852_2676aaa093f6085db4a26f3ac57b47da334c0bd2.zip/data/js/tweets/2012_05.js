Grailbird.data.tweets_2012_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/ZlrmQ4hQ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=6GggY4TEYbk",
      "display_url" : "youtube.com\/watch?v=6GggY4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "208385300437807104",
  "text" : "Current status, after being awake for 15 hours. (WTF 5am brain?) http:\/\/t.co\/ZlrmQ4hQ",
  "id" : 208385300437807104,
  "created_at" : "2012-06-01 02:31:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208362387756163073",
  "geo" : { },
  "id_str" : "208385110771372032",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante ha! next time I need to do it without hitting several 2x IPAs.",
  "id" : 208385110771372032,
  "in_reply_to_status_id" : 208362387756163073,
  "created_at" : "2012-06-01 02:30:56 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208342836301664256",
  "geo" : { },
  "id_str" : "208360415976108032",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape get some deer\/elk horns. Lasts a long time. Ged has a bone chewing hour or two nightly where I can\u2019t imagine what he\u2019d wreck w\/o",
  "id" : 208360415976108032,
  "in_reply_to_status_id" : 208342836301664256,
  "created_at" : "2012-06-01 00:52:48 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208311199652249605",
  "text" : "Every modal dialog that blocks page content on load is like someone greeting me by flipping the bird and yelling \"FUCK OFF\"",
  "id" : 208311199652249605,
  "created_at" : "2012-05-31 21:37:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Canine Tatum",
      "screen_name" : "aphyr",
      "indices" : [ 3, 9 ],
      "id_str" : "49820803",
      "id" : 49820803
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lolfloats",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 46 ],
      "url" : "https:\/\/t.co\/VmWK9N3V",
      "expanded_url" : "https:\/\/github.com\/mranney\/node_pcap\/blob\/master\/pcap.js#L155",
      "display_url" : "github.com\/mranney\/node_p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "208296971516133376",
  "text" : "RT @aphyr: Reminder that https:\/\/t.co\/VmWK9N3V is larger than javascript's maxint. #lolfloats",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lolfloats",
        "indices" : [ 72, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 14, 35 ],
        "url" : "https:\/\/t.co\/VmWK9N3V",
        "expanded_url" : "https:\/\/github.com\/mranney\/node_pcap\/blob\/master\/pcap.js#L155",
        "display_url" : "github.com\/mranney\/node_p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "208295157899079680",
    "text" : "Reminder that https:\/\/t.co\/VmWK9N3V is larger than javascript's maxint. #lolfloats",
    "id" : 208295157899079680,
    "created_at" : "2012-05-31 20:33:30 +0000",
    "user" : {
      "name" : "Canine Tatum",
      "screen_name" : "aphyr",
      "protected" : false,
      "id_str" : "49820803",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570838692642557952\/kdmO23rS_normal.jpeg",
      "id" : 49820803,
      "verified" : false
    }
  },
  "id" : 208296971516133376,
  "created_at" : "2012-05-31 20:40:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/2gPpKxxM",
      "expanded_url" : "http:\/\/memegenerator.com",
      "display_url" : "memegenerator.com"
    }, {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/7FzPwbWl",
      "expanded_url" : "http:\/\/4chan.org",
      "display_url" : "4chan.org"
    } ]
  },
  "geo" : { },
  "id_str" : "208281565837541376",
  "text" : "curl -sI http:\/\/t.co\/2gPpKxxM | grep Location\nLocation: http:\/\/t.co\/7FzPwbWl",
  "id" : 208281565837541376,
  "created_at" : "2012-05-31 19:39:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 10, 15 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/208272029768622080\/photo\/1",
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/xLIXlYJ5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuPuTr9CIAAnK-C.png",
      "id_str" : "208272029772816384",
      "id" : 208272029772816384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuPuTr9CIAAnK-C.png",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1394
      } ],
      "display_url" : "pic.twitter.com\/xLIXlYJ5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208272029768622080",
  "text" : "Say Hi to @popo on FoxNews! http:\/\/t.co\/xLIXlYJ5",
  "id" : 208272029768622080,
  "created_at" : "2012-05-31 19:01:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208220604170649600",
  "geo" : { },
  "id_str" : "208221063748919296",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff DOOO EET",
  "id" : 208221063748919296,
  "in_reply_to_status_id" : 208220604170649600,
  "created_at" : "2012-05-31 15:39:04 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcampbuffalo",
      "indices" : [ 23, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208048387549966336",
  "text" : "Had an awesome time at #barcampbuffalo tonight. Also confirmed I produce lots of bugs.",
  "id" : 208048387549966336,
  "created_at" : "2012-05-31 04:12:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 16, 27 ],
      "id_str" : "14555937",
      "id" : 14555937
    }, {
      "name" : "Chris Eppstein",
      "screen_name" : "chriseppstein",
      "indices" : [ 28, 42 ],
      "id_str" : "14148091",
      "id" : 14148091
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 67, 81 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208044196102287360",
  "geo" : { },
  "id_str" : "208046910668414977",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten @phillapier @chriseppstein don\u2019t force me to bring @joshuaclayton up in here.",
  "id" : 208046910668414977,
  "in_reply_to_status_id" : 208044196102287360,
  "created_at" : "2012-05-31 04:07:03 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 26, 37 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208043129490771968",
  "geo" : { },
  "id_str" : "208043832489680900",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten maybe ask @phillapier ? ;)",
  "id" : 208043832489680900,
  "in_reply_to_status_id" : 208043129490771968,
  "created_at" : "2012-05-31 03:54:49 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208037571446571008",
  "geo" : { },
  "id_str" : "208041979542642688",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan  is that a duckface?",
  "id" : 208041979542642688,
  "in_reply_to_status_id" : 208037571446571008,
  "created_at" : "2012-05-31 03:47:27 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Mendieta",
      "screen_name" : "geonrd",
      "indices" : [ 3, 10 ],
      "id_str" : "110586755",
      "id" : 110586755
    }, {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 12, 23 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "BarCamp Buffalo",
      "screen_name" : "BarCampBuffalo",
      "indices" : [ 43, 58 ],
      "id_str" : "19735370",
      "id" : 19735370
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/geonrd\/status\/208023026942480384\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/svu201Jt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuML10JCEAEvQbu.jpg",
      "id_str" : "208023026946674689",
      "id" : 208023026946674689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuML10JCEAEvQbu.jpg",
      "sizes" : [ {
        "h" : 1952,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 203,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/svu201Jt"
    } ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "startups",
      "indices" : [ 110, 119 ]
    }, {
      "text" : "PearlSt",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208023331771908096",
  "text" : "RT @geonrd: @dangigante engaging the crowd @BarCampBuffalo. Been a really informative and fun night. #Buffalo #startups #PearlSt http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "dan gigante",
        "screen_name" : "dangigante",
        "indices" : [ 0, 11 ],
        "id_str" : "43151378",
        "id" : 43151378
      }, {
        "name" : "BarCamp Buffalo",
        "screen_name" : "BarCampBuffalo",
        "indices" : [ 31, 46 ],
        "id_str" : "19735370",
        "id" : 19735370
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/geonrd\/status\/208023026942480384\/photo\/1",
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/svu201Jt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AuML10JCEAEvQbu.jpg",
        "id_str" : "208023026946674689",
        "id" : 208023026946674689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuML10JCEAEvQbu.jpg",
        "sizes" : [ {
          "h" : 1952,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 203,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/svu201Jt"
      } ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 89, 97 ]
      }, {
        "text" : "startups",
        "indices" : [ 98, 107 ]
      }, {
        "text" : "PearlSt",
        "indices" : [ 108, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208023026942480384",
    "in_reply_to_user_id" : 43151378,
    "text" : "@dangigante engaging the crowd @BarCampBuffalo. Been a really informative and fun night. #Buffalo #startups #PearlSt http:\/\/t.co\/svu201Jt",
    "id" : 208023026942480384,
    "created_at" : "2012-05-31 02:32:10 +0000",
    "in_reply_to_screen_name" : "dangigante",
    "in_reply_to_user_id_str" : "43151378",
    "user" : {
      "name" : "Ryan Mendieta",
      "screen_name" : "geonrd",
      "protected" : false,
      "id_str" : "110586755",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3312562515\/e30ee87d5c86c867ec0ccceeec54c725_normal.png",
      "id" : 110586755,
      "verified" : false
    }
  },
  "id" : 208023331771908096,
  "created_at" : "2012-05-31 02:33:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208014348281589761",
  "geo" : { },
  "id_str" : "208023272065990657",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan a few beers make me a bad slide presenter",
  "id" : 208023272065990657,
  "in_reply_to_status_id" : 208014348281589761,
  "created_at" : "2012-05-31 02:33:07 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chelsea Orcutt",
      "screen_name" : "ChelseaOrcutt",
      "indices" : [ 3, 17 ],
      "id_str" : "22690038",
      "id" : 22690038
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 20, 30 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcampbuffalo",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208008237818200064",
  "text" : "RT @ChelseaOrcutt: .@aquaranto's tip: copying to comprehension as a learning style for programming. #barcampbuffalo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 1, 11 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "barcampbuffalo",
        "indices" : [ 81, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "207995283215355904",
    "text" : ".@aquaranto's tip: copying to comprehension as a learning style for programming. #barcampbuffalo",
    "id" : 207995283215355904,
    "created_at" : "2012-05-31 00:41:54 +0000",
    "user" : {
      "name" : "Chelsea Orcutt",
      "screen_name" : "ChelseaOrcutt",
      "protected" : false,
      "id_str" : "22690038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000600891612\/ef8ac6e94ba683c2f54f470beac02d5d_normal.jpeg",
      "id" : 22690038,
      "verified" : false
    }
  },
  "id" : 208008237818200064,
  "created_at" : "2012-05-31 01:33:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208000683419512834",
  "text" : "Love that the guy behind php sadness is in Buffalo.",
  "id" : 208000683419512834,
  "created_at" : "2012-05-31 01:03:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Boston",
      "screen_name" : "bostonaholic",
      "indices" : [ 0, 13 ],
      "id_str" : "16313839",
      "id" : 16313839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207999204176568320",
  "geo" : { },
  "id_str" : "208000036158717952",
  "in_reply_to_user_id" : 16313839,
  "text" : "@bostonaholic thought you were in buffalo. :(",
  "id" : 208000036158717952,
  "in_reply_to_status_id" : 207999204176568320,
  "created_at" : "2012-05-31 01:00:47 +0000",
  "in_reply_to_screen_name" : "bostonaholic",
  "in_reply_to_user_id_str" : "16313839",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CollectorsProof",
      "screen_name" : "CollectorsProof",
      "indices" : [ 0, 16 ],
      "id_str" : "166670186",
      "id" : 166670186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207973424981753856",
  "geo" : { },
  "id_str" : "207975004330143746",
  "in_reply_to_user_id" : 166670186,
  "text" : "@CollectorsProof not yet. Check out Ruboto.",
  "id" : 207975004330143746,
  "in_reply_to_status_id" : 207973424981753856,
  "created_at" : "2012-05-30 23:21:19 +0000",
  "in_reply_to_screen_name" : "CollectorsProof",
  "in_reply_to_user_id_str" : "166670186",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chelsea Orcutt",
      "screen_name" : "ChelseaOrcutt",
      "indices" : [ 3, 17 ],
      "id_str" : "22690038",
      "id" : 22690038
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 20, 26 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ChelseaOrcutt\/status\/207972765037371392\/photo\/1",
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/aR1DJdwe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuLeIL9CIAA0Zp6.jpg",
      "id_str" : "207972765041565696",
      "id" : 207972765041565696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuLeIL9CIAA0Zp6.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/aR1DJdwe"
    } ],
    "hashtags" : [ {
      "text" : "barcampbuffalo",
      "indices" : [ 71, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207974927008141312",
  "text" : "RT @ChelseaOrcutt: .@qrush is talking about Ruby Motion (Ruby for iOS) #barcampbuffalo http:\/\/t.co\/aR1DJdwe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 1, 7 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ChelseaOrcutt\/status\/207972765037371392\/photo\/1",
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/aR1DJdwe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AuLeIL9CIAA0Zp6.jpg",
        "id_str" : "207972765041565696",
        "id" : 207972765041565696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuLeIL9CIAA0Zp6.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/aR1DJdwe"
      } ],
      "hashtags" : [ {
        "text" : "barcampbuffalo",
        "indices" : [ 52, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "207972765037371392",
    "text" : ".@qrush is talking about Ruby Motion (Ruby for iOS) #barcampbuffalo http:\/\/t.co\/aR1DJdwe",
    "id" : 207972765037371392,
    "created_at" : "2012-05-30 23:12:26 +0000",
    "user" : {
      "name" : "Chelsea Orcutt",
      "screen_name" : "ChelseaOrcutt",
      "protected" : false,
      "id_str" : "22690038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000600891612\/ef8ac6e94ba683c2f54f470beac02d5d_normal.jpeg",
      "id" : 22690038,
      "verified" : false
    }
  },
  "id" : 207974927008141312,
  "created_at" : "2012-05-30 23:21:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 3, 12 ],
      "id_str" : "815545",
      "id" : 815545
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 48, 54 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcampbuffalo",
      "indices" : [ 55, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207974903524245508",
  "text" : "RT @Sigafoos: Excellent use of animated gifs by @qrush #barcampbuffalo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 34, 40 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "barcampbuffalo",
        "indices" : [ 41, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "207972955274219522",
    "text" : "Excellent use of animated gifs by @qrush #barcampbuffalo",
    "id" : 207972955274219522,
    "created_at" : "2012-05-30 23:13:11 +0000",
    "user" : {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "protected" : false,
      "id_str" : "815545",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460799514392002561\/4v7uLxvl_normal.jpeg",
      "id" : 815545,
      "verified" : false
    }
  },
  "id" : 207974903524245508,
  "created_at" : "2012-05-30 23:20:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207906071191371776",
  "geo" : { },
  "id_str" : "207906295754395650",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen \"DevSwag is a side projects of the folks over at Tilde Inc\"",
  "id" : 207906295754395650,
  "in_reply_to_status_id" : 207906071191371776,
  "created_at" : "2012-05-30 18:48:18 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "5by5",
      "screen_name" : "5by5",
      "indices" : [ 47, 52 ],
      "id_str" : "106231780",
      "id" : 106231780
    }, {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 76, 88 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/F6SXB9Ea",
      "expanded_url" : "http:\/\/bit.ly\/LfLWJp",
      "display_url" : "bit.ly\/LfLWJp"
    } ]
  },
  "geo" : { },
  "id_str" : "207904932806918144",
  "text" : "RT @kevinpurdy: Freaking amped to launch a new @5by5 podcast, In Beta, with @ginatrapani. First ep. Tuesday: http:\/\/t.co\/F6SXB9Ea",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "5by5",
        "screen_name" : "5by5",
        "indices" : [ 31, 36 ],
        "id_str" : "106231780",
        "id" : 106231780
      }, {
        "name" : "Gina Trapani",
        "screen_name" : "ginatrapani",
        "indices" : [ 60, 72 ],
        "id_str" : "930061",
        "id" : 930061
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/F6SXB9Ea",
        "expanded_url" : "http:\/\/bit.ly\/LfLWJp",
        "display_url" : "bit.ly\/LfLWJp"
      } ]
    },
    "geo" : { },
    "id_str" : "207900861307944960",
    "text" : "Freaking amped to launch a new @5by5 podcast, In Beta, with @ginatrapani. First ep. Tuesday: http:\/\/t.co\/F6SXB9Ea",
    "id" : 207900861307944960,
    "created_at" : "2012-05-30 18:26:42 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 207904932806918144,
  "created_at" : "2012-05-30 18:42:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Linse",
      "screen_name" : "JeffLinse",
      "indices" : [ 0, 10 ],
      "id_str" : "116526817",
      "id" : 116526817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207870401970311168",
  "geo" : { },
  "id_str" : "207870852727980033",
  "in_reply_to_user_id" : 116526817,
  "text" : "@JeffLinse the better question: will it crash on every, fucking, wootoff? I can't believe they haven't figured that shit out.",
  "id" : 207870852727980033,
  "in_reply_to_status_id" : 207870401970311168,
  "created_at" : "2012-05-30 16:27:28 +0000",
  "in_reply_to_screen_name" : "JeffLinse",
  "in_reply_to_user_id_str" : "116526817",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 3, 11 ],
      "id_str" : "234465384",
      "id" : 234465384
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 41, 51 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 93 ],
      "url" : "https:\/\/t.co\/OJoiXtD9",
      "expanded_url" : "https:\/\/github.com\/noahhl\/batsd",
      "display_url" : "github.com\/noahhl\/batsd"
    } ]
  },
  "geo" : { },
  "id_str" : "207866684957134848",
  "text" : "RT @noahhlo: The flavor of statsd we use @37signals is now available at https:\/\/t.co\/OJoiXtD9. Now you too can track, like, a billion me ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 28, 38 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 80 ],
        "url" : "https:\/\/t.co\/OJoiXtD9",
        "expanded_url" : "https:\/\/github.com\/noahhl\/batsd",
        "display_url" : "github.com\/noahhl\/batsd"
      } ]
    },
    "geo" : { },
    "id_str" : "207866425338101761",
    "text" : "The flavor of statsd we use @37signals is now available at https:\/\/t.co\/OJoiXtD9. Now you too can track, like, a billion metrics.",
    "id" : 207866425338101761,
    "created_at" : "2012-05-30 16:09:52 +0000",
    "user" : {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "protected" : false,
      "id_str" : "234465384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412045673408651264\/CPEGZ-93_normal.jpeg",
      "id" : 234465384,
      "verified" : false
    }
  },
  "id" : 207866684957134848,
  "created_at" : "2012-05-30 16:10:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/y0nIoWKZ",
      "expanded_url" : "http:\/\/www.ianlunn.co.uk\/plugins\/jquery-parallax\/",
      "display_url" : "ianlunn.co.uk\/plugins\/jquery\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "207832847640297473",
  "geo" : { },
  "id_str" : "207833162414436352",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape looks like they're using something else. i used http:\/\/t.co\/y0nIoWKZ",
  "id" : 207833162414436352,
  "in_reply_to_status_id" : 207832847640297473,
  "created_at" : "2012-05-30 13:57:41 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/jn6biUCz",
      "expanded_url" : "http:\/\/instagr.am\/p\/LQJt1gM6tD\/",
      "display_url" : "instagr.am\/p\/LQJt1gM6tD\/"
    } ]
  },
  "geo" : { },
  "id_str" : "207825093622120448",
  "text" : "Bidwell in the mornings is great. http:\/\/t.co\/jn6biUCz",
  "id" : 207825093622120448,
  "created_at" : "2012-05-30 13:25:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 0, 16 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207676516769861633",
  "geo" : { },
  "id_str" : "207676618209107968",
  "in_reply_to_user_id" : 10114802,
  "text" : "@whentheponydies Just did, finally. phew.",
  "id" : 207676618209107968,
  "in_reply_to_status_id" : 207676516769861633,
  "created_at" : "2012-05-30 03:35:38 +0000",
  "in_reply_to_screen_name" : "whentheponydies",
  "in_reply_to_user_id_str" : "10114802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207668328972562433",
  "geo" : { },
  "id_str" : "207670478612070400",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw i had to sound it out.",
  "id" : 207670478612070400,
  "in_reply_to_status_id" : 207668328972562433,
  "created_at" : "2012-05-30 03:11:15 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/mlJut3Qj",
      "expanded_url" : "http:\/\/images1.wikia.nocookie.net\/__cb20120403204636\/mk\/images\/7\/72\/No_meme_by_dylrocks95-d3jlcc7.png",
      "display_url" : "images1.wikia.nocookie.net\/__cb2012040320\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "207664030528192513",
  "geo" : { },
  "id_str" : "207664222405017600",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape http:\/\/t.co\/mlJut3Qj",
  "id" : 207664222405017600,
  "in_reply_to_status_id" : 207664030528192513,
  "created_at" : "2012-05-30 02:46:23 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207664024891039745",
  "text" : "Ready for the \"HERP DERP FACEBERK GOT AN IPO AND USED PEE EHHCH PHR CMON NOW NICK\"",
  "id" : 207664024891039745,
  "created_at" : "2012-05-30 02:45:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207663776181387264",
  "text" : "I mean more of the usage, proliferation, and continued spread of the terrible cancer that is PHP. Please just stop.",
  "id" : 207663776181387264,
  "created_at" : "2012-05-30 02:44:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207663618051932160",
  "text" : "One thing I'm confident about hating on PHP for: You will never use it for anything else other than developing shitty CMS sites. NOTHING.",
  "id" : 207663618051932160,
  "created_at" : "2012-05-30 02:43:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207660521871245312",
  "text" : "My presentations just aren't complete anymore without photos of bears.",
  "id" : 207660521871245312,
  "created_at" : "2012-05-30 02:31:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/gtc6CAda",
      "expanded_url" : "http:\/\/barcampbuffalo.org\/registrations",
      "display_url" : "barcampbuffalo.org\/registrations"
    } ]
  },
  "geo" : { },
  "id_str" : "207637302841851904",
  "text" : "BarCampBuffalo is tomorrow! http:\/\/t.co\/gtc6CAda",
  "id" : 207637302841851904,
  "created_at" : "2012-05-30 00:59:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/wCa2jbvf",
      "expanded_url" : "http:\/\/bit.ly\/KPV5dE",
      "display_url" : "bit.ly\/KPV5dE"
    } ]
  },
  "geo" : { },
  "id_str" : "207601118879023104",
  "text" : "RT @aquaranto: Hi Buffalo! I just started a new meetup group for Buffalonians who want to learn to program http:\/\/t.co\/wCa2jbvf. We star ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/wCa2jbvf",
        "expanded_url" : "http:\/\/bit.ly\/KPV5dE",
        "display_url" : "bit.ly\/KPV5dE"
      } ]
    },
    "geo" : { },
    "id_str" : "207600805015060480",
    "text" : "Hi Buffalo! I just started a new meetup group for Buffalonians who want to learn to program http:\/\/t.co\/wCa2jbvf. We start Jun 11 @ 630 pm.",
    "id" : 207600805015060480,
    "created_at" : "2012-05-29 22:34:23 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 207601118879023104,
  "created_at" : "2012-05-29 22:35:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207595864359837696",
  "text" : "PUT BITS ON DEVICE. FUCKING EASY.",
  "id" : 207595864359837696,
  "created_at" : "2012-05-29 22:14:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207595775063109633",
  "text" : "So fucking stupid. The DEVICE IS RIGHT FUCKING HERE.",
  "id" : 207595775063109633,
  "created_at" : "2012-05-29 22:14:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207595730074996736",
  "text" : "Getting \"valid signing identity not found\" and  \"Unable to codesign using identities in this team; no private keys available\"",
  "id" : 207595730074996736,
  "created_at" : "2012-05-29 22:14:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207593873906728962",
  "text" : "All I want to do is test my app on a real device? Why the fuck is it this hard? Does anyone understand this process?",
  "id" : 207593873906728962,
  "created_at" : "2012-05-29 22:06:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207591663986671618",
  "text" : "Running an iOS app on a real device is the most mind boggling, backwards, convoluted, and stupid process I've been through.",
  "id" : 207591663986671618,
  "created_at" : "2012-05-29 21:58:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 8, 21 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207538160031379457",
  "geo" : { },
  "id_str" : "207538816880357376",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight @wayneeseguin the falls is a special place.",
  "id" : 207538816880357376,
  "in_reply_to_status_id" : 207538160031379457,
  "created_at" : "2012-05-29 18:28:04 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Mongeau",
      "screen_name" : "halogenandtoast",
      "indices" : [ 3, 19 ],
      "id_str" : "15428948",
      "id" : 15428948
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 91, 97 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207524450709684224",
  "text" : "RT @halogenandtoast: I might start playing Dwarf Fortress. If anything goes wrong, I blame @qrush",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 70, 76 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "207523242959839232",
    "text" : "I might start playing Dwarf Fortress. If anything goes wrong, I blame @qrush",
    "id" : 207523242959839232,
    "created_at" : "2012-05-29 17:26:11 +0000",
    "user" : {
      "name" : "Matthew Mongeau",
      "screen_name" : "halogenandtoast",
      "protected" : false,
      "id_str" : "15428948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/248851406\/Photo_2_normal.jpg",
      "id" : 15428948,
      "verified" : false
    }
  },
  "id" : 207524450709684224,
  "created_at" : "2012-05-29 17:30:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207503804453761024",
  "geo" : { },
  "id_str" : "207504395435376640",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr Y U NO MEETUP",
  "id" : 207504395435376640,
  "in_reply_to_status_id" : 207503804453761024,
  "created_at" : "2012-05-29 16:11:17 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Buffalogal in NYC",
      "screen_name" : "Buffalogal",
      "indices" : [ 0, 11 ],
      "id_str" : "14500105",
      "id" : 14500105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207490759493042176",
  "geo" : { },
  "id_str" : "207491362415841280",
  "in_reply_to_user_id" : 14500105,
  "text" : "@Buffalogal hey! our say is no for right now, mostly because we're above spot's roastery. our next location is going to be more dog friendly",
  "id" : 207491362415841280,
  "in_reply_to_status_id" : 207490759493042176,
  "created_at" : "2012-05-29 15:19:30 +0000",
  "in_reply_to_screen_name" : "Buffalogal",
  "in_reply_to_user_id_str" : "14500105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MongoDB",
      "screen_name" : "MongoDB",
      "indices" : [ 4, 12 ],
      "id_str" : "18080585",
      "id" : 18080585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207479231180050432",
  "text" : "Hey @mongodb, can you take some of that $42M to turn on safe mode by default? Thanks, everyone who's ever used your database, ever.",
  "id" : 207479231180050432,
  "created_at" : "2012-05-29 14:31:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207291390152015872",
  "text" : "Avengers the second time was just as good.",
  "id" : 207291390152015872,
  "created_at" : "2012-05-29 02:04:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Hawkins",
      "screen_name" : "FortNinety",
      "indices" : [ 0, 11 ],
      "id_str" : "7617502",
      "id" : 7617502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207196733720100866",
  "geo" : { },
  "id_str" : "207289549913735170",
  "in_reply_to_user_id" : 7617502,
  "text" : "@FortNinety hey, I just moved all of the API docs to github...hit me at nick@37signals and I can hopefully help out!",
  "id" : 207289549913735170,
  "in_reply_to_status_id" : 207196733720100866,
  "created_at" : "2012-05-29 01:57:34 +0000",
  "in_reply_to_screen_name" : "FortNinety",
  "in_reply_to_user_id_str" : "7617502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Armin Ronacher",
      "screen_name" : "mitsuhiko",
      "indices" : [ 0, 10 ],
      "id_str" : "12963432",
      "id" : 12963432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207225096576843777",
  "geo" : { },
  "id_str" : "207289077836414976",
  "in_reply_to_user_id" : 12963432,
  "text" : "@mitsuhiko curlish?",
  "id" : 207289077836414976,
  "in_reply_to_status_id" : 207225096576843777,
  "created_at" : "2012-05-29 01:55:42 +0000",
  "in_reply_to_screen_name" : "mitsuhiko",
  "in_reply_to_user_id_str" : "12963432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 10, 18 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207155370005770241",
  "geo" : { },
  "id_str" : "207155994743152640",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone @mperham i actually prefer it this way, the less people using mongoid to poison their apps with relations, the better",
  "id" : 207155994743152640,
  "in_reply_to_status_id" : 207155370005770241,
  "created_at" : "2012-05-28 17:06:52 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 3, 11 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/ZLDKYYrO",
      "expanded_url" : "http:\/\/mongoid.org\/en\/mongoid\/index.html",
      "display_url" : "mongoid.org\/en\/mongoid\/ind\u2026"
    }, {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/cxUFNpOm",
      "expanded_url" : "http:\/\/j.mp\/KKkzcg",
      "display_url" : "j.mp\/KKkzcg"
    } ]
  },
  "geo" : { },
  "id_str" : "207149371991670784",
  "text" : "RT @mperham: LOLing at Mongoid's apparent desire to focus on anime rather than actual content.  http:\/\/t.co\/ZLDKYYrO http:\/\/t.co\/cxUFNpOm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/ZLDKYYrO",
        "expanded_url" : "http:\/\/mongoid.org\/en\/mongoid\/index.html",
        "display_url" : "mongoid.org\/en\/mongoid\/ind\u2026"
      }, {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/cxUFNpOm",
        "expanded_url" : "http:\/\/j.mp\/KKkzcg",
        "display_url" : "j.mp\/KKkzcg"
      } ]
    },
    "geo" : { },
    "id_str" : "207148526281555970",
    "text" : "LOLing at Mongoid's apparent desire to focus on anime rather than actual content.  http:\/\/t.co\/ZLDKYYrO http:\/\/t.co\/cxUFNpOm",
    "id" : 207148526281555970,
    "created_at" : "2012-05-28 16:37:11 +0000",
    "user" : {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "protected" : false,
      "id_str" : "14060922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519271188569128960\/i2t9GfcA_normal.jpeg",
      "id" : 14060922,
      "verified" : false
    }
  },
  "id" : 207149371991670784,
  "created_at" : "2012-05-28 16:40:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207147736527667200",
  "text" : "Will you be proud of the work you're doing now in 10 years? 20 years? 30 years? This question plagues me daily.",
  "id" : 207147736527667200,
  "created_at" : "2012-05-28 16:34:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 46, 53 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/Ppsw2Tbd",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3181-our-api-docs-are-now-hosted-on-github",
      "display_url" : "37signals.com\/svn\/posts\/3181\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "207100661039497216",
  "text" : "RT @37signals: Our API docs are now hosted at @github: http:\/\/t.co\/Ppsw2Tbd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GitHub",
        "screen_name" : "github",
        "indices" : [ 31, 38 ],
        "id_str" : "13334762",
        "id" : 13334762
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/Ppsw2Tbd",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3181-our-api-docs-are-now-hosted-on-github",
        "display_url" : "37signals.com\/svn\/posts\/3181\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "207100605045551105",
    "text" : "Our API docs are now hosted at @github: http:\/\/t.co\/Ppsw2Tbd",
    "id" : 207100605045551105,
    "created_at" : "2012-05-28 13:26:46 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 207100661039497216,
  "created_at" : "2012-05-28 13:26:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207099050380632064",
  "text" : "I love the smell of shipping in the morning.",
  "id" : 207099050380632064,
  "created_at" : "2012-05-28 13:20:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/sRE7dBqD",
      "expanded_url" : "http:\/\/imgur.com\/a\/GyPQg",
      "display_url" : "imgur.com\/a\/GyPQg"
    } ]
  },
  "geo" : { },
  "id_str" : "206851619080503297",
  "text" : "Last few days in Dwarf Fortress: Found an underground fortress, dealt with a siege, captured a war leader! http:\/\/t.co\/sRE7dBqD",
  "id" : 206851619080503297,
  "created_at" : "2012-05-27 20:57:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeeMan",
      "screen_name" : "Drew_Baggg",
      "indices" : [ 0, 11 ],
      "id_str" : "372319943",
      "id" : 372319943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205091251912065025",
  "geo" : { },
  "id_str" : "206597188162297857",
  "in_reply_to_user_id" : 372319943,
  "text" : "@Drew_Baggg just heard about this. seriously, fuck that guy",
  "id" : 206597188162297857,
  "in_reply_to_status_id" : 205091251912065025,
  "created_at" : "2012-05-27 04:06:22 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Kapp",
      "screen_name" : "happymrdave",
      "indices" : [ 0, 12 ],
      "id_str" : "15399388",
      "id" : 15399388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206570743465656321",
  "geo" : { },
  "id_str" : "206583601431715840",
  "in_reply_to_user_id" : 15399388,
  "text" : "@happymrdave oh man! Good luck against those monsters :)",
  "id" : 206583601431715840,
  "in_reply_to_status_id" : 206570743465656321,
  "created_at" : "2012-05-27 03:12:23 +0000",
  "in_reply_to_screen_name" : "happymrdave",
  "in_reply_to_user_id_str" : "15399388",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobi L\u00FCtke",
      "screen_name" : "tobi",
      "indices" : [ 3, 8 ],
      "id_str" : "676573",
      "id" : 676573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/Ef75Gfp8",
      "expanded_url" : "http:\/\/dcurt.is\/elon-musks-determination",
      "display_url" : "dcurt.is\/elon-musks-det\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206529352777728000",
  "text" : "RT @tobi: Optimism, pessimism, fuck that; we're going to make it happen. http:\/\/t.co\/Ef75Gfp8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/Ef75Gfp8",
        "expanded_url" : "http:\/\/dcurt.is\/elon-musks-determination",
        "display_url" : "dcurt.is\/elon-musks-det\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "206528008918548480",
    "text" : "Optimism, pessimism, fuck that; we're going to make it happen. http:\/\/t.co\/Ef75Gfp8",
    "id" : 206528008918548480,
    "created_at" : "2012-05-26 23:31:29 +0000",
    "user" : {
      "name" : "Tobi L\u00FCtke",
      "screen_name" : "tobi",
      "protected" : false,
      "id_str" : "676573",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551403375141457920\/28EOlhnM_normal.jpeg",
      "id" : 676573,
      "verified" : false
    }
  },
  "id" : 206529352777728000,
  "created_at" : "2012-05-26 23:36:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/MI08Wlrc",
      "expanded_url" : "http:\/\/instagr.am\/p\/LGzCpzM6rB\/",
      "display_url" : "instagr.am\/p\/LGzCpzM6rB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "206508551814909952",
  "text" : "Love the inside cover of 2112.  http:\/\/t.co\/MI08Wlrc",
  "id" : 206508551814909952,
  "created_at" : "2012-05-26 22:14:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/7zCGAtu7",
      "expanded_url" : "http:\/\/uk.reuters.com\/article\/2012\/05\/26\/us-climate-germany-solar-idUKBRE84P0FI20120526",
      "display_url" : "uk.reuters.com\/article\/2012\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206481796383252480",
  "text" : "Anyone else have a sudden urge to play Power Grid after reading this? http:\/\/t.co\/7zCGAtu7",
  "id" : 206481796383252480,
  "created_at" : "2012-05-26 20:27:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206164411952529408",
  "geo" : { },
  "id_str" : "206164744086892544",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten 7 so far!",
  "id" : 206164744086892544,
  "in_reply_to_status_id" : 206164411952529408,
  "created_at" : "2012-05-25 23:28:00 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206164677225492481",
  "text" : "Got called out for slapping the table while drinking. Buffalo doesn't know me well enough yet.",
  "id" : 206164677225492481,
  "created_at" : "2012-05-25 23:27:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    }, {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 15, 28 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206097519887925250",
  "geo" : { },
  "id_str" : "206100734486392832",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit @ChrisSmithAV I know this is a joke, but if we could get a floor that would be awesome. views look gorgeous.",
  "id" : 206100734486392832,
  "in_reply_to_status_id" : 206097519887925250,
  "created_at" : "2012-05-25 19:13:38 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 47, 61 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/lpWgeGel",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/76-coworkbuffalo-launch-drinkup",
      "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206087411879526402",
  "text" : "RT @coworkbuffalo: Up for some drinks with the @coworkbuffalo crew this evening? Come celebrate our first week! http:\/\/t.co\/lpWgeGel",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 28, 42 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/lpWgeGel",
        "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/76-coworkbuffalo-launch-drinkup",
        "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "206080991150870528",
    "text" : "Up for some drinks with the @coworkbuffalo crew this evening? Come celebrate our first week! http:\/\/t.co\/lpWgeGel",
    "id" : 206080991150870528,
    "created_at" : "2012-05-25 17:55:11 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 206087411879526402,
  "created_at" : "2012-05-25 18:20:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "206057755243589633",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Men At Work: Down Under \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 206057755243589633,
  "created_at" : "2012-05-25 16:22:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/gun18zNd",
      "expanded_url" : "http:\/\/internationaldockingstandard.com\/",
      "display_url" : "internationaldockingstandard.com"
    } ]
  },
  "geo" : { },
  "id_str" : "206046320954318848",
  "text" : "This is so fucking cool. In case you need to dock your spaceship with the ISS: http:\/\/t.co\/gun18zNd",
  "id" : 206046320954318848,
  "created_at" : "2012-05-25 15:37:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 11, 22 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206041317933973506",
  "geo" : { },
  "id_str" : "206041447240183808",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef @kevinpurdy yes!",
  "id" : 206041447240183808,
  "in_reply_to_status_id" : 206041317933973506,
  "created_at" : "2012-05-25 15:18:03 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hard Cheers",
      "screen_name" : "The__Sir",
      "indices" : [ 0, 9 ],
      "id_str" : "211941094",
      "id" : 211941094
    }, {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 10, 22 ],
      "id_str" : "158098704",
      "id" : 158098704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 83 ],
      "url" : "https:\/\/t.co\/grgNhL32",
      "expanded_url" : "https:\/\/twitter.com\/#!\/coworkbuffalo\/media\/grid",
      "display_url" : "twitter.com\/#!\/coworkbuffa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "206037324033830912",
  "geo" : { },
  "id_str" : "206038932239040512",
  "in_reply_to_user_id" : 211941094,
  "text" : "@The__Sir @mikemikemac need to get some on the site. for now: https:\/\/t.co\/grgNhL32",
  "id" : 206038932239040512,
  "in_reply_to_status_id" : 206037324033830912,
  "created_at" : "2012-05-25 15:08:04 +0000",
  "in_reply_to_screen_name" : "The__Sir",
  "in_reply_to_user_id_str" : "211941094",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 0, 6 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Adrian Roselli",
      "screen_name" : "aardrian",
      "indices" : [ 7, 16 ],
      "id_str" : "16515870",
      "id" : 16515870
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 17, 27 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206027199214661632",
  "geo" : { },
  "id_str" : "206027405918351360",
  "in_reply_to_user_id" : 5743852,
  "text" : "@qrush @aardrian @aspleenic er, contains only direct tweets...not mentions\/retweets.",
  "id" : 206027405918351360,
  "in_reply_to_status_id" : 206027199214661632,
  "created_at" : "2012-05-25 14:22:16 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffael Schmid",
      "screen_name" : "rafschmid",
      "indices" : [ 0, 10 ],
      "id_str" : "191774451",
      "id" : 191774451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205929819085615104",
  "geo" : { },
  "id_str" : "206027238553026561",
  "in_reply_to_user_id" : 191774451,
  "text" : "@rafschmid nope, it's the Jolly Bastion tileset.",
  "id" : 206027238553026561,
  "in_reply_to_status_id" : 205929819085615104,
  "created_at" : "2012-05-25 14:21:36 +0000",
  "in_reply_to_screen_name" : "rafschmid",
  "in_reply_to_user_id_str" : "191774451",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Roselli",
      "screen_name" : "aardrian",
      "indices" : [ 0, 9 ],
      "id_str" : "16515870",
      "id" : 16515870
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 10, 20 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206023000875737088",
  "geo" : { },
  "id_str" : "206027199214661632",
  "in_reply_to_user_id" : 16515870,
  "text" : "@aardrian @aspleenic it's open source, contains only retweets, and planning to make it better with a map. slow your roll! :)",
  "id" : 206027199214661632,
  "in_reply_to_status_id" : 206023000875737088,
  "created_at" : "2012-05-25 14:21:26 +0000",
  "in_reply_to_screen_name" : "aardrian",
  "in_reply_to_user_id_str" : "16515870",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Roselli",
      "screen_name" : "aardrian",
      "indices" : [ 0, 9 ],
      "id_str" : "16515870",
      "id" : 16515870
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 10, 20 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/EYaWwERQ",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food",
      "display_url" : "coworkbuffalo.com\/food"
    } ]
  },
  "in_reply_to_status_id_str" : "206006173240000513",
  "geo" : { },
  "id_str" : "206021160108953600",
  "in_reply_to_user_id" : 16515870,
  "text" : "@aardrian @aspleenic we have a better version of this at http:\/\/t.co\/EYaWwERQ",
  "id" : 206021160108953600,
  "in_reply_to_status_id" : 206006173240000513,
  "created_at" : "2012-05-25 13:57:26 +0000",
  "in_reply_to_screen_name" : "aardrian",
  "in_reply_to_user_id_str" : "16515870",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lems",
      "screen_name" : "ExtremeLemon",
      "indices" : [ 0, 13 ],
      "id_str" : "589508952",
      "id" : 589508952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205852592486629376",
  "geo" : { },
  "id_str" : "205869776403312640",
  "in_reply_to_user_id" : 589508952,
  "text" : "@ExtremeLemon yeah seems like too much effort. Maybe magma carts will be good, faster than a stack?",
  "id" : 205869776403312640,
  "in_reply_to_status_id" : 205852592486629376,
  "created_at" : "2012-05-25 03:55:54 +0000",
  "in_reply_to_screen_name" : "ExtremeLemon",
  "in_reply_to_user_id_str" : "589508952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pavel Kotlyar",
      "screen_name" : "pavlopiy",
      "indices" : [ 0, 9 ],
      "id_str" : "48178332",
      "id" : 48178332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205860174286692352",
  "geo" : { },
  "id_str" : "205869560119820288",
  "in_reply_to_user_id" : 48178332,
  "text" : "@pavlopiy nope! What's wrong with the real thing?",
  "id" : 205869560119820288,
  "in_reply_to_status_id" : 205860174286692352,
  "created_at" : "2012-05-25 03:55:02 +0000",
  "in_reply_to_screen_name" : "pavlopiy",
  "in_reply_to_user_id_str" : "48178332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205840403105189888",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt just hit Conky. holy shit.",
  "id" : 205840403105189888,
  "created_at" : "2012-05-25 01:59:11 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lems",
      "screen_name" : "ExtremeLemon",
      "indices" : [ 0, 13 ],
      "id_str" : "589508952",
      "id" : 589508952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205831957614034945",
  "geo" : { },
  "id_str" : "205834464058818560",
  "in_reply_to_user_id" : 589508952,
  "text" : "@ExtremeLemon wheelbarrows are *awesome* though! next project is going to be another hole through the aquifer to make a reservoir.",
  "id" : 205834464058818560,
  "in_reply_to_status_id" : 205831957614034945,
  "created_at" : "2012-05-25 01:35:35 +0000",
  "in_reply_to_screen_name" : "ExtremeLemon",
  "in_reply_to_user_id_str" : "589508952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lems",
      "screen_name" : "ExtremeLemon",
      "indices" : [ 0, 13 ],
      "id_str" : "589508952",
      "id" : 589508952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205831957614034945",
  "geo" : { },
  "id_str" : "205834352414826496",
  "in_reply_to_user_id" : 589508952,
  "text" : "@ExtremeLemon I have one cart going to haul iron between furnaces and stockpile. the UI sucks hard. Need to think about how to use them more",
  "id" : 205834352414826496,
  "in_reply_to_status_id" : 205831957614034945,
  "created_at" : "2012-05-25 01:35:08 +0000",
  "in_reply_to_screen_name" : "ExtremeLemon",
  "in_reply_to_user_id_str" : "589508952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lems",
      "screen_name" : "ExtremeLemon",
      "indices" : [ 0, 13 ],
      "id_str" : "589508952",
      "id" : 589508952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 83 ],
      "url" : "https:\/\/t.co\/tmM9SEzF",
      "expanded_url" : "https:\/\/img.skitch.com\/20120525-p3qmsh716m3ei35djr3qgp1ttg.png",
      "display_url" : "img.skitch.com\/20120525-p3qms\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "205791186080899072",
  "geo" : { },
  "id_str" : "205830544829841409",
  "in_reply_to_user_id" : 589508952,
  "text" : "@ExtremeLemon i'm an idiot. thanks! a bit more built out now: https:\/\/t.co\/tmM9SEzF",
  "id" : 205830544829841409,
  "in_reply_to_status_id" : 205791186080899072,
  "created_at" : "2012-05-25 01:20:00 +0000",
  "in_reply_to_screen_name" : "ExtremeLemon",
  "in_reply_to_user_id_str" : "589508952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 112 ],
      "url" : "https:\/\/t.co\/tmM9SEzF",
      "expanded_url" : "https:\/\/img.skitch.com\/20120525-p3qmsh716m3ei35djr3qgp1ttg.png",
      "display_url" : "img.skitch.com\/20120525-p3qms\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "205829291139796995",
  "text" : "Lancermountain, mid year 3. Walls up, survived its first goblin siege with &lt; 10 deaths. https:\/\/t.co\/tmM9SEzF",
  "id" : 205829291139796995,
  "created_at" : "2012-05-25 01:15:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/lpWgeGel",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/76-coworkbuffalo-launch-drinkup",
      "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "205818201458749441",
  "text" : "RT @coworkbuffalo: Happy almost Friday! Who's coming down to the space tomorrow? Also, we're having a drinkup at Blue Monk at 7! http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/lpWgeGel",
        "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/76-coworkbuffalo-launch-drinkup",
        "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "205818113479032832",
    "text" : "Happy almost Friday! Who's coming down to the space tomorrow? Also, we're having a drinkup at Blue Monk at 7! http:\/\/t.co\/lpWgeGel",
    "id" : 205818113479032832,
    "created_at" : "2012-05-25 00:30:36 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 205818201458749441,
  "created_at" : "2012-05-25 00:30:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 0, 7 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205783586522140675",
  "geo" : { },
  "id_str" : "205809990278197248",
  "in_reply_to_user_id" : 14237099,
  "text" : "@geemus got ours!",
  "id" : 205809990278197248,
  "in_reply_to_status_id" : 205783586522140675,
  "created_at" : "2012-05-24 23:58:20 +0000",
  "in_reply_to_screen_name" : "geemus",
  "in_reply_to_user_id_str" : "14237099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/1CoBKZRc",
      "expanded_url" : "http:\/\/instagr.am\/p\/LByhrzM6go\/",
      "display_url" : "instagr.am\/p\/LByhrzM6go\/"
    } ]
  },
  "geo" : { },
  "id_str" : "205803882255892483",
  "text" : "Puppies: best part of the dog park. Especially husky puppies. http:\/\/t.co\/1CoBKZRc",
  "id" : 205803882255892483,
  "created_at" : "2012-05-24 23:34:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205704299416788992",
  "text" : "Be open by default.",
  "id" : 205704299416788992,
  "created_at" : "2012-05-24 16:58:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205702945851965441",
  "geo" : { },
  "id_str" : "205703338623381506",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante we have a pull request open for that! will merge soon",
  "id" : 205703338623381506,
  "in_reply_to_status_id" : 205702945851965441,
  "created_at" : "2012-05-24 16:54:32 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205448797130731521",
  "geo" : { },
  "id_str" : "205687621916164098",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten yes, i wrote it. whats up?",
  "id" : 205687621916164098,
  "in_reply_to_status_id" : 205448797130731521,
  "created_at" : "2012-05-24 15:52:05 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "205684230276120576",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Trey Anastasio: Burlap Sack And Pumps \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 205684230276120576,
  "created_at" : "2012-05-24 15:38:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Pettit",
      "screen_name" : "nickrp",
      "indices" : [ 0, 7 ],
      "id_str" : "15349708",
      "id" : 15349708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205619868530262016",
  "geo" : { },
  "id_str" : "205621529059397633",
  "in_reply_to_user_id" : 15349708,
  "text" : "@nickrp pretty sure I did this in WoW already",
  "id" : 205621529059397633,
  "in_reply_to_status_id" : 205619868530262016,
  "created_at" : "2012-05-24 11:29:27 +0000",
  "in_reply_to_screen_name" : "nickrp",
  "in_reply_to_user_id_str" : "15349708",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 53, 59 ],
      "id_str" : "1438261",
      "id" : 1438261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/Q2v2kd72",
      "expanded_url" : "http:\/\/cargocollective.com\/jayse\/Avengers",
      "display_url" : "cargocollective.com\/jayse\/Avengers"
    } ]
  },
  "geo" : { },
  "id_str" : "205450311433863169",
  "text" : "Movie UIs at their finest: http:\/\/t.co\/Q2v2kd72 (via @atmos)",
  "id" : 205450311433863169,
  "created_at" : "2012-05-24 00:09:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205448461582221312",
  "geo" : { },
  "id_str" : "205448601378369537",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius BEARPOOP",
  "id" : 205448601378369537,
  "in_reply_to_status_id" : 205448461582221312,
  "created_at" : "2012-05-24 00:02:18 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Pumm",
      "screen_name" : "pummer",
      "indices" : [ 0, 7 ],
      "id_str" : "45489027",
      "id" : 45489027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205448194413445120",
  "geo" : { },
  "id_str" : "205448539495608321",
  "in_reply_to_user_id" : 45489027,
  "text" : "@pummer or as an echo chamber for those willing to waste time?",
  "id" : 205448539495608321,
  "in_reply_to_status_id" : 205448194413445120,
  "created_at" : "2012-05-24 00:02:03 +0000",
  "in_reply_to_screen_name" : "pummer",
  "in_reply_to_user_id_str" : "45489027",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Block Club",
      "screen_name" : "BlockClub",
      "indices" : [ 31, 41 ],
      "id_str" : "21003240",
      "id" : 21003240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/SmzSXrfC",
      "expanded_url" : "http:\/\/vimeo.com\/41960173",
      "display_url" : "vimeo.com\/41960173"
    } ]
  },
  "geo" : { },
  "id_str" : "205410961555861504",
  "text" : "RT @coworkbuffalo: Congrats to @BlockClub for making Buffalo better for the past 5 years! http:\/\/t.co\/SmzSXrfC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Block Club",
        "screen_name" : "BlockClub",
        "indices" : [ 12, 22 ],
        "id_str" : "21003240",
        "id" : 21003240
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/SmzSXrfC",
        "expanded_url" : "http:\/\/vimeo.com\/41960173",
        "display_url" : "vimeo.com\/41960173"
      } ]
    },
    "geo" : { },
    "id_str" : "205410531161554944",
    "text" : "Congrats to @BlockClub for making Buffalo better for the past 5 years! http:\/\/t.co\/SmzSXrfC",
    "id" : 205410531161554944,
    "created_at" : "2012-05-23 21:31:01 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 205410961555861504,
  "created_at" : "2012-05-23 21:32:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Adamsson",
      "screen_name" : "late2game",
      "indices" : [ 3, 13 ],
      "id_str" : "59758079",
      "id" : 59758079
    }, {
      "name" : "nik harron",
      "screen_name" : "nikharron",
      "indices" : [ 30, 40 ],
      "id_str" : "39803248",
      "id" : 39803248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/2LxocdbM",
      "expanded_url" : "http:\/\/youtu.be\/ggg3C87UVCY",
      "display_url" : "youtu.be\/ggg3C87UVCY"
    } ]
  },
  "geo" : { },
  "id_str" : "205402040925556736",
  "text" : "RT @late2game: Fantastic - RT @nikharron: The dark side of green energy. Pity the chimneys! Oh the humanity! http:\/\/t.co\/2LxocdbM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nik harron",
        "screen_name" : "nikharron",
        "indices" : [ 15, 25 ],
        "id_str" : "39803248",
        "id" : 39803248
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/2LxocdbM",
        "expanded_url" : "http:\/\/youtu.be\/ggg3C87UVCY",
        "display_url" : "youtu.be\/ggg3C87UVCY"
      } ]
    },
    "geo" : { },
    "id_str" : "205401393824141312",
    "text" : "Fantastic - RT @nikharron: The dark side of green energy. Pity the chimneys! Oh the humanity! http:\/\/t.co\/2LxocdbM",
    "id" : 205401393824141312,
    "created_at" : "2012-05-23 20:54:43 +0000",
    "user" : {
      "name" : "Shawn Adamsson",
      "screen_name" : "late2game",
      "protected" : false,
      "id_str" : "59758079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527052416089604096\/eXcbUcx8_normal.jpeg",
      "id" : 59758079,
      "verified" : false
    }
  },
  "id" : 205402040925556736,
  "created_at" : "2012-05-23 20:57:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Gisi",
      "screen_name" : "gisikw",
      "indices" : [ 0, 7 ],
      "id_str" : "14308739",
      "id" : 14308739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205400413816619008",
  "geo" : { },
  "id_str" : "205400796173570048",
  "in_reply_to_user_id" : 14308739,
  "text" : "@gisikw enjoy my tax money, but not in NYC",
  "id" : 205400796173570048,
  "in_reply_to_status_id" : 205400413816619008,
  "created_at" : "2012-05-23 20:52:20 +0000",
  "in_reply_to_screen_name" : "gisikw",
  "in_reply_to_user_id_str" : "14308739",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205400507127300096",
  "text" : "Who can I commission a series of demolishing buildings with faces, arms, and drinking tea GIFs from?",
  "id" : 205400507127300096,
  "created_at" : "2012-05-23 20:51:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 42, 49 ],
      "id_str" : "14432203",
      "id" : 14432203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/7pTGhFCV",
      "expanded_url" : "http:\/\/i.imgur.com\/JvAod.gif",
      "display_url" : "i.imgur.com\/JvAod.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "205399813808857090",
  "text" : "Current status: http:\/\/t.co\/7pTGhFCV (via @will_j)",
  "id" : 205399813808857090,
  "created_at" : "2012-05-23 20:48:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/E2eDOqmJ",
      "expanded_url" : "http:\/\/www.sohoburgerbar.com\/menus",
      "display_url" : "sohoburgerbar.com\/menus"
    } ]
  },
  "geo" : { },
  "id_str" : "205399016886894592",
  "text" : "Just now realizing that http:\/\/t.co\/E2eDOqmJ has a &lt;marquee&gt; tag and it's trying to be serious about it.",
  "id" : 205399016886894592,
  "created_at" : "2012-05-23 20:45:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "205329688879570944",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Cal Tjader: Afro-Blue \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 205329688879570944,
  "created_at" : "2012-05-23 16:09:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205281442127818752",
  "geo" : { },
  "id_str" : "205281978214400000",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape time to visit MI perhaps!",
  "id" : 205281978214400000,
  "in_reply_to_status_id" : 205281442127818752,
  "created_at" : "2012-05-23 13:00:12 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205029477741363200",
  "geo" : { },
  "id_str" : "205075456821694464",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson not sure if better or worse than my gifs folder attached to my finder sidebar",
  "id" : 205075456821694464,
  "in_reply_to_status_id" : 205029477741363200,
  "created_at" : "2012-05-22 23:19:33 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205046717509419008",
  "text" : "Ship or get off the laptop.",
  "id" : 205046717509419008,
  "created_at" : "2012-05-22 21:25:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205011155972919297",
  "geo" : { },
  "id_str" : "205011393743814656",
  "in_reply_to_user_id" : 156708162,
  "text" : "@seandevineinc nope, i've heard good things about the coop and 1871 though.",
  "id" : 205011393743814656,
  "in_reply_to_status_id" : 205011155972919297,
  "created_at" : "2012-05-22 19:04:59 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AKA JMoney",
      "screen_name" : "soederpop",
      "indices" : [ 0, 10 ],
      "id_str" : "18176421",
      "id" : 18176421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/IsL7yZu2",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/1732348\/regex-match-open-tags-except-xhtml-self-contained-tags#answer-1732454",
      "display_url" : "stackoverflow.com\/questions\/1732\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "205009749685698560",
  "geo" : { },
  "id_str" : "205010349655724032",
  "in_reply_to_user_id" : 18176421,
  "text" : "@soederpop Use a parser. http:\/\/t.co\/IsL7yZu2",
  "id" : 205010349655724032,
  "in_reply_to_status_id" : 205009749685698560,
  "created_at" : "2012-05-22 19:00:50 +0000",
  "in_reply_to_screen_name" : "soederpop",
  "in_reply_to_user_id_str" : "18176421",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 3, 19 ],
      "id_str" : "10114802",
      "id" : 10114802
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 39, 53 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/hoahSP7W",
      "expanded_url" : "http:\/\/statigr.am\/p\/196993330091626519_2533811",
      "display_url" : "statigr.am\/p\/196993330091\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "204996307918663680",
  "text" : "RT @whentheponydies: the front door of @coworkbuffalo with the awesome 8-bit buffalo\nhttp:\/\/t.co\/hoahSP7W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 18, 32 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/hoahSP7W",
        "expanded_url" : "http:\/\/statigr.am\/p\/196993330091626519_2533811",
        "display_url" : "statigr.am\/p\/196993330091\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "204995793575354368",
    "text" : "the front door of @coworkbuffalo with the awesome 8-bit buffalo\nhttp:\/\/t.co\/hoahSP7W",
    "id" : 204995793575354368,
    "created_at" : "2012-05-22 18:03:00 +0000",
    "user" : {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "protected" : false,
      "id_str" : "10114802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564813913192415232\/4L4S1xQt_normal.jpeg",
      "id" : 10114802,
      "verified" : false
    }
  },
  "id" : 204996307918663680,
  "created_at" : "2012-05-22 18:05:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 32, 46 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204991431994114049",
  "text" : "Really excited and proud to see @coworkbuffalo with butts in seats today!",
  "id" : 204991431994114049,
  "created_at" : "2012-05-22 17:45:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204959901095706625",
  "geo" : { },
  "id_str" : "204960052518453248",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff leading by example\/doing.",
  "id" : 204960052518453248,
  "in_reply_to_status_id" : 204959901095706625,
  "created_at" : "2012-05-22 15:40:59 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204782373332713472",
  "geo" : { },
  "id_str" : "204932116780302336",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten didnt see you! Are you dropping by?",
  "id" : 204932116780302336,
  "in_reply_to_status_id" : 204782373332713472,
  "created_at" : "2012-05-22 13:49:58 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204929345440063489",
  "geo" : { },
  "id_str" : "204931098180976641",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh 3 years.",
  "id" : 204931098180976641,
  "in_reply_to_status_id" : 204929345440063489,
  "created_at" : "2012-05-22 13:45:55 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204906188503121920",
  "geo" : { },
  "id_str" : "204908932563611648",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending tomorrow's: \"caremad\"",
  "id" : 204908932563611648,
  "in_reply_to_status_id" : 204906188503121920,
  "created_at" : "2012-05-22 12:17:51 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 0, 16 ],
      "id_str" : "46852648",
      "id" : 46852648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204843026189783040",
  "geo" : { },
  "id_str" : "204898787045556224",
  "in_reply_to_user_id" : 46852648,
  "text" : "@postmodern_mod3 mine. I use it all the time.",
  "id" : 204898787045556224,
  "in_reply_to_status_id" : 204843026189783040,
  "created_at" : "2012-05-22 11:37:32 +0000",
  "in_reply_to_screen_name" : "postmodern_mod3",
  "in_reply_to_user_id_str" : "46852648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "turntable",
      "screen_name" : "turntablefm",
      "indices" : [ 69, 81 ],
      "id_str" : "1934900918",
      "id" : 1934900918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204752261396705281",
  "text" : "I honestly don't think most people know or care what the stickers on @turntablefm are for...most just draw letters\/shapes with them.",
  "id" : 204752261396705281,
  "created_at" : "2012-05-22 01:55:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    }, {
      "name" : "Clark Dever",
      "screen_name" : "clarkdever",
      "indices" : [ 9, 20 ],
      "id_str" : "11081432",
      "id" : 11081432
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 21, 35 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 50, 55 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204642467654541312",
  "geo" : { },
  "id_str" : "204642641953038336",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending @clarkdever @coworkbuffalo actually it's @popo 's",
  "id" : 204642641953038336,
  "in_reply_to_status_id" : 204642467654541312,
  "created_at" : "2012-05-21 18:39:42 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "store716",
      "screen_name" : "store716",
      "indices" : [ 0, 9 ],
      "id_str" : "304448419",
      "id" : 304448419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204635344770048002",
  "geo" : { },
  "id_str" : "204642168684556289",
  "in_reply_to_user_id" : 304448419,
  "text" : "@store716 hi, thanks!",
  "id" : 204642168684556289,
  "in_reply_to_status_id" : 204635344770048002,
  "created_at" : "2012-05-21 18:37:49 +0000",
  "in_reply_to_screen_name" : "store716",
  "in_reply_to_user_id_str" : "304448419",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 51 ],
      "url" : "https:\/\/t.co\/PxbWDI7f",
      "expanded_url" : "https:\/\/github.com\/rapportive-oss\/ampex",
      "display_url" : "github.com\/rapportive-oss\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "204636820858875906",
  "text" : "Liking the idea behind ampex: https:\/\/t.co\/PxbWDI7f",
  "id" : 204636820858875906,
  "created_at" : "2012-05-21 18:16:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/pUpF1pa8",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/HistoryPorn\/",
      "display_url" : "reddit.com\/r\/HistoryPorn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "204633196304932864",
  "text" : "And today I learned about http:\/\/t.co\/pUpF1pa8. (SFW)",
  "id" : 204633196304932864,
  "created_at" : "2012-05-21 18:02:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/epnnWCjL",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "204631743511277569",
  "text" : "DJing in the CoworkBuffalo room. Now playing Medeski, Martin &amp; Wood: End Of The World Party \u266B\u266A #turntablefm http:\/\/t.co\/epnnWCjL",
  "id" : 204631743511277569,
  "created_at" : "2012-05-21 17:56:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204627428000280576",
  "geo" : { },
  "id_str" : "204627973997985793",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 thanks!!",
  "id" : 204627973997985793,
  "in_reply_to_status_id" : 204627428000280576,
  "created_at" : "2012-05-21 17:41:25 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 25, 39 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/JwEqQB4H",
      "expanded_url" : "http:\/\/instagr.am\/p\/K5bU3TM6hd\/",
      "display_url" : "instagr.am\/p\/K5bU3TM6hd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "204627172604903425",
  "text" : "We need a real sign, but @coworkbuffalo is open! http:\/\/t.co\/JwEqQB4H",
  "id" : 204627172604903425,
  "created_at" : "2012-05-21 17:38:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/lNjzBJ34",
      "expanded_url" : "http:\/\/law-order-food.tumblr.com\/",
      "display_url" : "law-order-food.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "204604344476237825",
  "text" : "Amazing: http:\/\/t.co\/lNjzBJ34",
  "id" : 204604344476237825,
  "created_at" : "2012-05-21 16:07:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 16, 30 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204589790526574593",
  "text" : "5 folks down at @coworkbuffalo today, so far. Where are you?",
  "id" : 204589790526574593,
  "created_at" : "2012-05-21 15:09:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon P Spitz",
      "screen_name" : "JonPSpitz",
      "indices" : [ 3, 13 ],
      "id_str" : "45264901",
      "id" : 45264901
    }, {
      "name" : "Coworking Rochester",
      "screen_name" : "coworkingroc",
      "indices" : [ 41, 54 ],
      "id_str" : "19386993",
      "id" : 19386993
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 95, 109 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ROC",
      "indices" : [ 131, 135 ]
    }, {
      "text" : "Buffalo",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "startups",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204350256668884992",
  "text" : "RT @JonPSpitz: Really impressed with the @coworkingroc space.  Looking forward to checking out @coworkbuffalo in the near future.  #ROC  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Coworking Rochester",
        "screen_name" : "coworkingroc",
        "indices" : [ 26, 39 ],
        "id_str" : "19386993",
        "id" : 19386993
      }, {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 80, 94 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ROC",
        "indices" : [ 116, 120 ]
      }, {
        "text" : "Buffalo",
        "indices" : [ 121, 129 ]
      }, {
        "text" : "startups",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "204327583737843712",
    "text" : "Really impressed with the @coworkingroc space.  Looking forward to checking out @coworkbuffalo in the near future.  #ROC #Buffalo #startups",
    "id" : 204327583737843712,
    "created_at" : "2012-05-20 21:47:46 +0000",
    "user" : {
      "name" : "Jon P Spitz",
      "screen_name" : "JonPSpitz",
      "protected" : false,
      "id_str" : "45264901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551435968188657664\/jiFhlhfc_normal.jpeg",
      "id" : 45264901,
      "verified" : false
    }
  },
  "id" : 204350256668884992,
  "created_at" : "2012-05-20 23:17:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 39, 53 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/uGCIUDOL",
      "expanded_url" : "http:\/\/coworkbuffalo.com",
      "display_url" : "coworkbuffalo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "204350232652283904",
  "text" : "RT @kevinpurdy: Excited to help launch @CoworkBuffalo tomorrow: http:\/\/t.co\/uGCIUDOL. Great coffee, solid Wi-Fi, smart people above Spot ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 23, 37 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/uGCIUDOL",
        "expanded_url" : "http:\/\/coworkbuffalo.com",
        "display_url" : "coworkbuffalo.com"
      } ]
    },
    "geo" : { },
    "id_str" : "204335964959686656",
    "text" : "Excited to help launch @CoworkBuffalo tomorrow: http:\/\/t.co\/uGCIUDOL. Great coffee, solid Wi-Fi, smart people above Spot Coffee in Buffalo.",
    "id" : 204335964959686656,
    "created_at" : "2012-05-20 22:21:05 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 204350232652283904,
  "created_at" : "2012-05-20 23:17:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 38, 52 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204275324320628736",
  "text" : "Finished final prep\/cleaning work for @coworkbuffalo, drove home to 4 play of Rush: 2112, Fly by Night, Lakeside Park, Freewill. Awesome!",
  "id" : 204275324320628736,
  "created_at" : "2012-05-20 18:20:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204267020823445504",
  "text" : "Who actually buys music from Starbucks?",
  "id" : 204267020823445504,
  "created_at" : "2012-05-20 17:47:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bryan von",
      "screen_name" : "alifeinwords",
      "indices" : [ 0, 13 ],
      "id_str" : "29196534",
      "id" : 29196534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204219761918349312",
  "geo" : { },
  "id_str" : "204220885433991168",
  "in_reply_to_user_id" : 29196534,
  "text" : "@alifeinwords grand island?",
  "id" : 204220885433991168,
  "in_reply_to_status_id" : 204219761918349312,
  "created_at" : "2012-05-20 14:43:47 +0000",
  "in_reply_to_screen_name" : "alifeinwords",
  "in_reply_to_user_id_str" : "29196534",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204061922943963136",
  "text" : "OH \"I was naked and marinating in my own pee\"",
  "id" : 204061922943963136,
  "created_at" : "2012-05-20 04:12:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/B9qYkwNc",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=3997876",
      "display_url" : "news.ycombinator.com\/item?id=3997876"
    } ]
  },
  "geo" : { },
  "id_str" : "204060288671166464",
  "text" : "Hacker News in one comment. http:\/\/t.co\/B9qYkwNc",
  "id" : 204060288671166464,
  "created_at" : "2012-05-20 04:05:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204053472658735104",
  "geo" : { },
  "id_str" : "204054105516285956",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten call them before going...not open all the time",
  "id" : 204054105516285956,
  "in_reply_to_status_id" : 204053472658735104,
  "created_at" : "2012-05-20 03:41:04 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "indices" : [ 40, 51 ],
      "id_str" : "7255652",
      "id" : 7255652
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 69, 79 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/QkJyRy8U",
      "expanded_url" : "http:\/\/instagr.am\/p\/K1Vs7js6mi\/",
      "display_url" : "instagr.am\/p\/K1Vs7js6mi\/"
    } ]
  },
  "geo" : { },
  "id_str" : "204051737995264001",
  "text" : "Bang! Finally found some scotch for the @engineyard tumbler! (thanks @aspleenic!) http:\/\/t.co\/QkJyRy8U",
  "id" : 204051737995264001,
  "created_at" : "2012-05-20 03:31:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204009076563263489",
  "geo" : { },
  "id_str" : "204010219284602880",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten green options \/ go bike.",
  "id" : 204010219284602880,
  "in_reply_to_status_id" : 204009076563263489,
  "created_at" : "2012-05-20 00:46:41 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203994904484003841",
  "geo" : { },
  "id_str" : "204007928565481472",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight I treat it like vim. Hidden UI, needs memorization, huge payoff",
  "id" : 204007928565481472,
  "in_reply_to_status_id" : 203994904484003841,
  "created_at" : "2012-05-20 00:37:35 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203981821250240512",
  "text" : "Also, had no idea waves are in Dwarf Fortress. This game continues to astound.",
  "id" : 203981821250240512,
  "created_at" : "2012-05-19 22:53:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/RBhQlK6Q",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/denee\/4720205202\/",
      "display_url" : "flickr.com\/photos\/denee\/4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203981529708371968",
  "text" : "The huge hole is the aquifer plug, basically used the \"plug\" method: http:\/\/t.co\/RBhQlK6Q",
  "id" : 203981529708371968,
  "created_at" : "2012-05-19 22:52:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 99 ],
      "url" : "https:\/\/t.co\/mu9Hc3Xm",
      "expanded_url" : "https:\/\/img.skitch.com\/20120520-q5131wq24kd91gc4fck3uy7hss.png",
      "display_url" : "img.skitch.com\/20120520-q5131\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203981305552191491",
  "text" : "Woot! First successful aquifer breach in Dwarf Fortress, first beach map too. https:\/\/t.co\/mu9Hc3Xm",
  "id" : 203981305552191491,
  "created_at" : "2012-05-19 22:51:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203863125907341313",
  "geo" : { },
  "id_str" : "203868442095403008",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil use the wiki for that! Or just markdown files.",
  "id" : 203868442095403008,
  "in_reply_to_status_id" : 203863125907341313,
  "created_at" : "2012-05-19 15:23:18 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203860068863705090",
  "geo" : { },
  "id_str" : "203862684419108864",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil yes.",
  "id" : 203862684419108864,
  "in_reply_to_status_id" : 203860068863705090,
  "created_at" : "2012-05-19 15:00:26 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203700674024833024",
  "text" : "I only rate songs when drunk. Always 5 stars. Can't be the only one.",
  "id" : 203700674024833024,
  "created_at" : "2012-05-19 04:16:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203675853119426562",
  "text" : "And after initial designations to tunnel under the rivers, 2 dorfs have wandered into the river and drowned. ABANDON FORTRESS!",
  "id" : 203675853119426562,
  "created_at" : "2012-05-19 02:38:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan Molloy",
      "screen_name" : "piecritic",
      "indices" : [ 0, 10 ],
      "id_str" : "17752201",
      "id" : 17752201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203665500822179840",
  "geo" : { },
  "id_str" : "203665755580014593",
  "in_reply_to_user_id" : 17752201,
  "text" : "@piecritic zoomed all the way out. these rivers are nuts.",
  "id" : 203665755580014593,
  "in_reply_to_status_id" : 203665500822179840,
  "created_at" : "2012-05-19 01:57:54 +0000",
  "in_reply_to_screen_name" : "piecritic",
  "in_reply_to_user_id_str" : "17752201",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan Molloy",
      "screen_name" : "piecritic",
      "indices" : [ 0, 10 ],
      "id_str" : "17752201",
      "id" : 17752201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203664762968621056",
  "geo" : { },
  "id_str" : "203665341593821184",
  "in_reply_to_user_id" : 17752201,
  "text" : "@piecritic It's the standard size?",
  "id" : 203665341593821184,
  "in_reply_to_status_id" : 203664762968621056,
  "created_at" : "2012-05-19 01:56:16 +0000",
  "in_reply_to_screen_name" : "piecritic",
  "in_reply_to_user_id_str" : "17752201",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203665280017248256",
  "text" : "Good Dwarf Fortress embarks leave you stunned, wondering where to STRIKE THE EARTH!",
  "id" : 203665280017248256,
  "created_at" : "2012-05-19 01:56:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 116 ],
      "url" : "https:\/\/t.co\/tUYLOaJt",
      "expanded_url" : "https:\/\/img.skitch.com\/20120519-r1q54hugr37iktb3h4yyfhqwg.png",
      "display_url" : "img.skitch.com\/20120519-r1q54\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203664484718493696",
  "text" : "Trying out the Jolly Bastion tileset for Dwarf Fortress. Embarked on a crazy 3 river junction. https:\/\/t.co\/tUYLOaJt",
  "id" : 203664484718493696,
  "created_at" : "2012-05-19 01:52:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nina Barone",
      "screen_name" : "buffalofoodie",
      "indices" : [ 0, 14 ],
      "id_str" : "190038945",
      "id" : 190038945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203620716753588224",
  "geo" : { },
  "id_str" : "203629655457144833",
  "in_reply_to_user_id" : 190038945,
  "text" : "@buffalofoodie where is this?!",
  "id" : 203629655457144833,
  "in_reply_to_status_id" : 203620716753588224,
  "created_at" : "2012-05-18 23:34:27 +0000",
  "in_reply_to_screen_name" : "buffalofoodie",
  "in_reply_to_user_id_str" : "190038945",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203563397856493568",
  "text" : "And 4 cups of delicious coffee later I'm so wired I can't even see straight.",
  "id" : 203563397856493568,
  "created_at" : "2012-05-18 19:11:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 59, 73 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203552058081689600",
  "text" : "Getting a serious coffee tasting from Elm Street Bakery at @coworkbuffalo. Learning slowly that coffee is SRS BUSINESS.",
  "id" : 203552058081689600,
  "created_at" : "2012-05-18 18:26:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Eppstein",
      "screen_name" : "chriseppstein",
      "indices" : [ 13, 27 ],
      "id_str" : "14148091",
      "id" : 14148091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203545568625164289",
  "geo" : { },
  "id_str" : "203546282617339906",
  "in_reply_to_user_id" : 535795834,
  "text" : "@CompassSusy @chriseppstein yikes not sure!",
  "id" : 203546282617339906,
  "in_reply_to_status_id" : 203545568625164289,
  "created_at" : "2012-05-18 18:03:10 +0000",
  "in_reply_to_screen_name" : "SassSusy",
  "in_reply_to_user_id_str" : "535795834",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/yesLtXl3",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=tQ_fnYhI1HU",
      "display_url" : "youtube.com\/watch?v=tQ_fnY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203545919814254593",
  "text" : "If you don't like lighthouses, you suck. http:\/\/t.co\/yesLtXl3",
  "id" : 203545919814254593,
  "created_at" : "2012-05-18 18:01:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 108 ],
      "url" : "https:\/\/t.co\/fHlPKG58",
      "expanded_url" : "https:\/\/groups.google.com\/group\/buffalo-coworking\/browse_thread\/thread\/f6be0c95db8514ec",
      "display_url" : "groups.google.com\/group\/buffalo-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203516292756553728",
  "text" : "RT @coworkbuffalo: We're officially opening this Monday, 5\/21! Full announcement here: https:\/\/t.co\/fHlPKG58",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 89 ],
        "url" : "https:\/\/t.co\/fHlPKG58",
        "expanded_url" : "https:\/\/groups.google.com\/group\/buffalo-coworking\/browse_thread\/thread\/f6be0c95db8514ec",
        "display_url" : "groups.google.com\/group\/buffalo-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "203514861882318849",
    "text" : "We're officially opening this Monday, 5\/21! Full announcement here: https:\/\/t.co\/fHlPKG58",
    "id" : 203514861882318849,
    "created_at" : "2012-05-18 15:58:18 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 203516292756553728,
  "created_at" : "2012-05-18 16:03:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/epnnWCjL",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "203493867952160769",
  "text" : "DJing in the CoworkBuffalo room. Now playing The Guess Who: No Sugar Tonight\\\/New Mother Nature \u266B\u266A #turntablefm http:\/\/t.co\/epnnWCjL",
  "id" : 203493867952160769,
  "created_at" : "2012-05-18 14:34:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203324837001822210",
  "geo" : { },
  "id_str" : "203325166699298816",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking already is",
  "id" : 203325166699298816,
  "in_reply_to_status_id" : 203324837001822210,
  "created_at" : "2012-05-18 03:24:31 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You and Who",
      "screen_name" : "You_and_Who",
      "indices" : [ 0, 12 ],
      "id_str" : "184659541",
      "id" : 184659541
    }, {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 13, 24 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203202469411569664",
  "geo" : { },
  "id_str" : "203202673418305536",
  "in_reply_to_user_id" : 184659541,
  "text" : "@You_and_Who @dangigante what size is the shirt on the mascot?",
  "id" : 203202673418305536,
  "in_reply_to_status_id" : 203202469411569664,
  "created_at" : "2012-05-17 19:17:47 +0000",
  "in_reply_to_screen_name" : "You_and_Who",
  "in_reply_to_user_id_str" : "184659541",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "InPodForm",
      "screen_name" : "InPodForm",
      "indices" : [ 0, 10 ],
      "id_str" : "395337544",
      "id" : 395337544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203158679481090049",
  "geo" : { },
  "id_str" : "203158881642348544",
  "in_reply_to_user_id" : 395337544,
  "text" : "@InPodForm I had to look up progenitor.",
  "id" : 203158881642348544,
  "in_reply_to_status_id" : 203158679481090049,
  "created_at" : "2012-05-17 16:23:46 +0000",
  "in_reply_to_screen_name" : "InPodForm",
  "in_reply_to_user_id_str" : "395337544",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/hgg3qBAC",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food\/",
      "display_url" : "coworkbuffalo.com\/food\/"
    } ]
  },
  "geo" : { },
  "id_str" : "203151053280133120",
  "text" : "Of course, first day I want to use http:\/\/t.co\/hgg3qBAC and no trucks are on Main St :(",
  "id" : 203151053280133120,
  "created_at" : "2012-05-17 15:52:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 36, 47 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "InPodForm",
      "screen_name" : "InPodForm",
      "indices" : [ 64, 74 ],
      "id_str" : "395337544",
      "id" : 395337544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 106 ],
      "url" : "https:\/\/t.co\/o3ePYgj6",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/108038811245479452343\/posts\/D3cKGzpXSXg",
      "display_url" : "plus.google.com\/u\/0\/1080388112\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203147861515440128",
  "text" : "Someone drew Guy on a Buffalo after @kevinpurdy mentioned it on @InPodForm. Awesome! https:\/\/t.co\/o3ePYgj6",
  "id" : 203147861515440128,
  "created_at" : "2012-05-17 15:39:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 16, 26 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203145509605609472",
  "geo" : { },
  "id_str" : "203145706565935104",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape ha, @aquaranto is home still. no way i'd leave him out.",
  "id" : 203145706565935104,
  "in_reply_to_status_id" : 203145509605609472,
  "created_at" : "2012-05-17 15:31:25 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rampino",
      "screen_name" : "AmberUX",
      "indices" : [ 3, 11 ],
      "id_str" : "17197399",
      "id" : 17197399
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 119, 133 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WNY",
      "indices" : [ 73, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/nj0e6aq1",
      "expanded_url" : "http:\/\/ow.ly\/aYjLF",
      "display_url" : "ow.ly\/aYjLF"
    } ]
  },
  "geo" : { },
  "id_str" : "203144872037855234",
  "text" : "RT @AmberUX: Relocation booster: I'd say this is a pretty typical day in #WNY. Come join us. http:\/\/t.co\/nj0e6aq1 (via @coworkbuffalo )",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 106, 120 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WNY",
        "indices" : [ 60, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/nj0e6aq1",
        "expanded_url" : "http:\/\/ow.ly\/aYjLF",
        "display_url" : "ow.ly\/aYjLF"
      } ]
    },
    "geo" : { },
    "id_str" : "203107133011660800",
    "text" : "Relocation booster: I'd say this is a pretty typical day in #WNY. Come join us. http:\/\/t.co\/nj0e6aq1 (via @coworkbuffalo )",
    "id" : 203107133011660800,
    "created_at" : "2012-05-17 12:58:08 +0000",
    "user" : {
      "name" : "Amber Rampino",
      "screen_name" : "AmberUX",
      "protected" : false,
      "id_str" : "17197399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1450473899\/selfportraitsq_normal.png",
      "id" : 17197399,
      "verified" : false
    }
  },
  "id" : 203144872037855234,
  "created_at" : "2012-05-17 15:28:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Rusbatch",
      "screen_name" : "jrusbatch",
      "indices" : [ 0, 10 ],
      "id_str" : "15424716",
      "id" : 15424716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203144098285223936",
  "geo" : { },
  "id_str" : "203144736498913281",
  "in_reply_to_user_id" : 15424716,
  "text" : "@jrusbatch Bike :)",
  "id" : 203144736498913281,
  "in_reply_to_status_id" : 203144098285223936,
  "created_at" : "2012-05-17 15:27:34 +0000",
  "in_reply_to_screen_name" : "jrusbatch",
  "in_reply_to_user_id_str" : "15424716",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/thhjbnyR",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ku40dbM6m8\/",
      "display_url" : "instagr.am\/p\/Ku40dbM6m8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "203143491751133184",
  "text" : "Don't leave! http:\/\/t.co\/thhjbnyR",
  "id" : 203143491751133184,
  "created_at" : "2012-05-17 15:22:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/203132243076595713\/photo\/1",
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/yzFuv3xO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtGrsueCQAA5eUH.jpg",
      "id_str" : "203132243084984320",
      "id" : 203132243084984320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtGrsueCQAA5eUH.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/yzFuv3xO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203132243076595713",
  "text" : "Geddy's reconnecting with his northern heritage, got him an elk horn. Very resilient! http:\/\/t.co\/yzFuv3xO",
  "id" : 203132243076595713,
  "created_at" : "2012-05-17 14:37:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "keeran",
      "screen_name" : "keeran",
      "indices" : [ 0, 7 ],
      "id_str" : "10075872",
      "id" : 10075872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203126783212654592",
  "geo" : { },
  "id_str" : "203127517211656193",
  "in_reply_to_user_id" : 10075872,
  "text" : "@keeran only a few helper methods do though...definitely not a majority case.",
  "id" : 203127517211656193,
  "in_reply_to_status_id" : 203126783212654592,
  "created_at" : "2012-05-17 14:19:08 +0000",
  "in_reply_to_screen_name" : "keeran",
  "in_reply_to_user_id_str" : "10075872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "keeran",
      "screen_name" : "keeran",
      "indices" : [ 0, 7 ],
      "id_str" : "10075872",
      "id" : 10075872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203126783212654592",
  "geo" : { },
  "id_str" : "203127424643379200",
  "in_reply_to_user_id" : 10075872,
  "text" : "@keeran we do. like i said, it happens on every app. just a symptom of using instance variables in actionview overall, sadly :\/",
  "id" : 203127424643379200,
  "in_reply_to_status_id" : 203126783212654592,
  "created_at" : "2012-05-17 14:18:46 +0000",
  "in_reply_to_screen_name" : "keeran",
  "in_reply_to_user_id_str" : "10075872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stJhimyBlog",
      "screen_name" : "stJhimyBlog",
      "indices" : [ 0, 12 ],
      "id_str" : "2521818631",
      "id" : 2521818631
    }, {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 38, 50 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203125725014925313",
  "geo" : { },
  "id_str" : "203125864488120320",
  "in_reply_to_user_id" : 58878838,
  "text" : "@stjhimyblog i know! holy crap! thank @sstephenson for showing me that one. :)",
  "id" : 203125864488120320,
  "in_reply_to_status_id" : 203125725014925313,
  "created_at" : "2012-05-17 14:12:34 +0000",
  "in_reply_to_screen_name" : "stjhimy",
  "in_reply_to_user_id_str" : "58878838",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitch Mirsky",
      "screen_name" : "MitchMirsky",
      "indices" : [ 0, 12 ],
      "id_str" : "10648482",
      "id" : 10648482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203124542523187200",
  "geo" : { },
  "id_str" : "203125704676753408",
  "in_reply_to_user_id" : 10648482,
  "text" : "@MitchMirsky I can just add a link to each truck's homepage. will do later tonight or this weekend!",
  "id" : 203125704676753408,
  "in_reply_to_status_id" : 203124542523187200,
  "created_at" : "2012-05-17 14:11:56 +0000",
  "in_reply_to_screen_name" : "MitchMirsky",
  "in_reply_to_user_id_str" : "10648482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/Ie6rFftv",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3176-three-quick-rails-console-tips",
      "display_url" : "37signals.com\/svn\/posts\/3176\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203123250081959936",
  "text" : "Learn something today! Here's 3 quick Rails console tips: http:\/\/t.co\/Ie6rFftv",
  "id" : 203123250081959936,
  "created_at" : "2012-05-17 14:02:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203121673669586944",
  "geo" : { },
  "id_str" : "203121882172624897",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss congrats dude! keep it up!",
  "id" : 203121882172624897,
  "in_reply_to_status_id" : 203121673669586944,
  "created_at" : "2012-05-17 13:56:45 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202986306765205504",
  "geo" : { },
  "id_str" : "202986469290283008",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante thanks! glad someone else is not getting enough sleep in buffalo tonight :)",
  "id" : 202986469290283008,
  "in_reply_to_status_id" : 202986306765205504,
  "created_at" : "2012-05-17 04:58:40 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 63, 75 ],
      "id_str" : "156689065",
      "id" : 156689065
    }, {
      "name" : "The Cheesy Chick",
      "screen_name" : "TheCheesyChick",
      "indices" : [ 76, 91 ],
      "id_str" : "342427103",
      "id" : 342427103
    }, {
      "name" : "Roaming Buffalo",
      "screen_name" : "RoamingBuffalo1",
      "indices" : [ 92, 108 ],
      "id_str" : "195824825",
      "id" : 195824825
    }, {
      "name" : "R&R BBQ",
      "screen_name" : "RnRBBQTruck",
      "indices" : [ 109, 121 ],
      "id_str" : "214261325",
      "id" : 214261325
    }, {
      "name" : "The Whole Hog Truck",
      "screen_name" : "WholeHogTruck",
      "indices" : [ 122, 136 ],
      "id_str" : "298098634",
      "id" : 298098634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/EYb14f10",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food",
      "display_url" : "coworkbuffalo.com\/food"
    } ]
  },
  "geo" : { },
  "id_str" : "202979615768190978",
  "text" : "All of Buffalo's food trucks on one page! http:\/\/t.co\/EYb14f10 @whereslloyd @TheCheesyChick @RoamingBuffalo1 @RnRBBQTruck @WholeHogTruck",
  "id" : 202979615768190978,
  "created_at" : "2012-05-17 04:31:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/gTkEJkA3",
      "expanded_url" : "http:\/\/www.toonamiaftermath.com\/",
      "display_url" : "toonamiaftermath.com"
    } ]
  },
  "geo" : { },
  "id_str" : "202942429429637120",
  "text" : "This is basically my afterschool childhood, on the internet. http:\/\/t.co\/gTkEJkA3",
  "id" : 202942429429637120,
  "created_at" : "2012-05-17 02:03:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 8, 18 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202935088428752896",
  "text" : "I think @aquaranto is a brony. Srony? What is the female form of brony?",
  "id" : 202935088428752896,
  "created_at" : "2012-05-17 01:34:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 3, 15 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/SK8MyEy4",
      "expanded_url" : "http:\/\/www.toonamiaftermath.com\/",
      "display_url" : "toonamiaftermath.com"
    } ]
  },
  "geo" : { },
  "id_str" : "202933611404595202",
  "text" : "RT @SteveStreza: Someone basically made their own web-based Toonami clone. Awesome. http:\/\/t.co\/SK8MyEy4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/SK8MyEy4",
        "expanded_url" : "http:\/\/www.toonamiaftermath.com\/",
        "display_url" : "toonamiaftermath.com"
      } ]
    },
    "geo" : { },
    "id_str" : "202926863679619074",
    "text" : "Someone basically made their own web-based Toonami clone. Awesome. http:\/\/t.co\/SK8MyEy4",
    "id" : 202926863679619074,
    "created_at" : "2012-05-17 01:01:49 +0000",
    "user" : {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "protected" : false,
      "id_str" : "658643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540811650727550976\/b7RvPDiF_normal.jpeg",
      "id" : 658643,
      "verified" : false
    }
  },
  "id" : 202933611404595202,
  "created_at" : "2012-05-17 01:28:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202903265241874432",
  "text" : "@billyist I get that a lot",
  "id" : 202903265241874432,
  "created_at" : "2012-05-16 23:28:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202896226474135552",
  "text" : "@billyist drop a git repo down, check everything in",
  "id" : 202896226474135552,
  "created_at" : "2012-05-16 23:00:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202855015969325056",
  "geo" : { },
  "id_str" : "202856713341255680",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda annnnd here's my next twitter bot",
  "id" : 202856713341255680,
  "in_reply_to_status_id" : 202855015969325056,
  "created_at" : "2012-05-16 20:23:04 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Whitbeck",
      "screen_name" : "RedWolves",
      "indices" : [ 47, 57 ],
      "id_str" : "651373",
      "id" : 651373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/OXTBCgNd",
      "expanded_url" : "http:\/\/youtu.be\/tV1JDW43kUE",
      "display_url" : "youtu.be\/tV1JDW43kUE"
    } ]
  },
  "geo" : { },
  "id_str" : "202851445786148864",
  "text" : "Snape (\u256F\u00B0\u25A1\u00B0\uFF09\u256F\uFE35 \u253B\u2501\u253B)  http:\/\/t.co\/OXTBCgNd (via @RedWolves )",
  "id" : 202851445786148864,
  "created_at" : "2012-05-16 20:02:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202831374577696768",
  "geo" : { },
  "id_str" : "202831959355953152",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza you mean, you dont enjoy blogs by VILLIANS?",
  "id" : 202831959355953152,
  "in_reply_to_status_id" : 202831374577696768,
  "created_at" : "2012-05-16 18:44:42 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 4, 12 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 46, 60 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202831807601852418",
  "text" : "Hey @wnyruby, have you purchased a ticket for @SteelCityRuby yet? It's only $50. Cmon.",
  "id" : 202831807601852418,
  "created_at" : "2012-05-16 18:44:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202827449090842625",
  "geo" : { },
  "id_str" : "202831691453169664",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden woot! see you there!",
  "id" : 202831691453169664,
  "in_reply_to_status_id" : 202827449090842625,
  "created_at" : "2012-05-16 18:43:38 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 119 ],
      "url" : "https:\/\/t.co\/6u6tPaal",
      "expanded_url" : "https:\/\/github.com\/clojure\/clojure\/blob\/master\/src\/jvm\/clojure\/lang\/IFn.java#L297",
      "display_url" : "github.com\/clojure\/clojur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "202811372340383745",
  "text" : "static public interface LOLOL \u007Blong invokePrim(long arg0, Object arg1, long arg2, Object arg3);\u007D\n\nhttps:\/\/t.co\/6u6tPaal",
  "id" : 202811372340383745,
  "created_at" : "2012-05-16 17:22:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    }, {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 9, 24 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202761080131436545",
  "geo" : { },
  "id_str" : "202761317097017344",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr @ChrisVanPatten THE DAYSTAR BURNS BRIGHT",
  "id" : 202761317097017344,
  "in_reply_to_status_id" : 202761080131436545,
  "created_at" : "2012-05-16 14:03:59 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202736406945206274",
  "geo" : { },
  "id_str" : "202751418795425792",
  "in_reply_to_user_id" : 120837801,
  "text" : "@jkym_ thanks dude! if you ever come on back give a shout.",
  "id" : 202751418795425792,
  "in_reply_to_status_id" : 202736406945206274,
  "created_at" : "2012-05-16 13:24:39 +0000",
  "in_reply_to_screen_name" : "davejachimiak",
  "in_reply_to_user_id_str" : "120837801",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 0, 9 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202612093848010753",
  "geo" : { },
  "id_str" : "202739755149033472",
  "in_reply_to_user_id" : 9462972,
  "text" : "@bitsweat oh c'mon, I only have two left!",
  "id" : 202739755149033472,
  "in_reply_to_status_id" : 202612093848010753,
  "created_at" : "2012-05-16 12:38:19 +0000",
  "in_reply_to_screen_name" : "bitsweat",
  "in_reply_to_user_id_str" : "9462972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/PLcInli8",
      "expanded_url" : "http:\/\/instagr.am\/p\/Kr9HnCM6mk\/",
      "display_url" : "instagr.am\/p\/Kr9HnCM6mk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "202730759713325056",
  "text" : "Sprung http:\/\/t.co\/PLcInli8",
  "id" : 202730759713325056,
  "created_at" : "2012-05-16 12:02:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202607476921745410",
  "geo" : { },
  "id_str" : "202608116372733952",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt just on season 3. Nope.",
  "id" : 202608116372733952,
  "in_reply_to_status_id" : 202607476921745410,
  "created_at" : "2012-05-16 03:55:13 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202607274081009664",
  "text" : "Trailer Park Boys ramps up pretty slowly then it's a fucking riot.",
  "id" : 202607274081009664,
  "created_at" : "2012-05-16 03:51:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/J5eKsDsX",
      "expanded_url" : "http:\/\/instagr.am\/p\/KqpryhM6sV\/",
      "display_url" : "instagr.am\/p\/KqpryhM6sV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "202547247379001344",
  "text" : "Your mind had been transported back in time. And to Buffalo. http:\/\/t.co\/J5eKsDsX",
  "id" : 202547247379001344,
  "created_at" : "2012-05-15 23:53:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/J2jMSwwX",
      "expanded_url" : "http:\/\/instagr.am\/p\/Kqo7nNs6rx\/",
      "display_url" : "instagr.am\/p\/Kqo7nNs6rx\/"
    } ]
  },
  "geo" : { },
  "id_str" : "202545638263619586",
  "text" : "+ Baby? http:\/\/t.co\/J2jMSwwX",
  "id" : 202545638263619586,
  "created_at" : "2012-05-15 23:46:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/drDw7GSe",
      "expanded_url" : "http:\/\/instagr.am\/p\/Kqo3jZs6rt\/",
      "display_url" : "instagr.am\/p\/Kqo3jZs6rt\/"
    } ]
  },
  "geo" : { },
  "id_str" : "202545474203430913",
  "text" : "Love this park. http:\/\/t.co\/drDw7GSe",
  "id" : 202545474203430913,
  "created_at" : "2012-05-15 23:46:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202529591733129217",
  "geo" : { },
  "id_str" : "202533841829765122",
  "in_reply_to_user_id" : 324160285,
  "text" : "@DuglasYun trying to not look like a dorm \uD83D\uDE12",
  "id" : 202533841829765122,
  "in_reply_to_status_id" : 202529591733129217,
  "created_at" : "2012-05-15 23:00:05 +0000",
  "in_reply_to_screen_name" : "dougyun",
  "in_reply_to_user_id_str" : "324160285",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 18, 32 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/QaflWC2Y",
      "expanded_url" : "http:\/\/instagr.am\/p\/KqeKwFM6nC\/",
      "display_url" : "instagr.am\/p\/KqeKwFM6nC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "202522049468563456",
  "text" : "Almost there with @coworkbuffalo. Phone booth in place and frames ready for conf badges! http:\/\/t.co\/QaflWC2Y",
  "id" : 202522049468563456,
  "created_at" : "2012-05-15 22:13:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 3, 14 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202503752740114433",
  "text" : "RT @themcgruff: \"... statsd: we track around 7-8 thousand unique measurements per second, with 1-1000 observations of each measurement i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "202503437076807680",
    "text" : "\"... statsd: we track around 7-8 thousand unique measurements per second, with 1-1000 observations of each measurement in that period.\"",
    "id" : 202503437076807680,
    "created_at" : "2012-05-15 20:59:16 +0000",
    "user" : {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "protected" : false,
      "id_str" : "13984262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539946640417619968\/0wwEYfHi_normal.png",
      "id" : 13984262,
      "verified" : false
    }
  },
  "id" : 202503752740114433,
  "created_at" : "2012-05-15 21:00:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jos\u00E9 Valim",
      "screen_name" : "josevalim",
      "indices" : [ 11, 21 ],
      "id_str" : "10230812",
      "id" : 10230812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202502162658496512",
  "text" : "Holy crap, @josevalim:\n$ git log --all --author \"Jos\u00E9 Valim\" | grep \"Merge pull request\" | wc -l\n952",
  "id" : 202502162658496512,
  "created_at" : "2012-05-15 20:54:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judson",
      "screen_name" : "judsonlester",
      "indices" : [ 0, 13 ],
      "id_str" : "216126673",
      "id" : 216126673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202484845350371330",
  "geo" : { },
  "id_str" : "202486819948994560",
  "in_reply_to_user_id" : 216126673,
  "text" : "@judsonlester what's wrong with SSD?",
  "id" : 202486819948994560,
  "in_reply_to_status_id" : 202484845350371330,
  "created_at" : "2012-05-15 19:53:14 +0000",
  "in_reply_to_screen_name" : "judsonlester",
  "in_reply_to_user_id_str" : "216126673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/epnnWCjL",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "202486467673591808",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Rush: Limelight \u266B\u266A #turntablefm http:\/\/t.co\/epnnWCjL",
  "id" : 202486467673591808,
  "created_at" : "2012-05-15 19:51:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202484351689166849",
  "text" : "Is there a reason why you wouldn't use `srm` over `rm` every time?",
  "id" : 202484351689166849,
  "created_at" : "2012-05-15 19:43:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neckbeard Hacker",
      "screen_name" : "NeckbeardHacker",
      "indices" : [ 3, 19 ],
      "id_str" : "278523798",
      "id" : 278523798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202473835373674496",
  "text" : "RT @NeckbeardHacker: Please don't learn to run a parody twitter account. Just don't.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "202473599779610624",
    "text" : "Please don't learn to run a parody twitter account. Just don't.",
    "id" : 202473599779610624,
    "created_at" : "2012-05-15 19:00:42 +0000",
    "user" : {
      "name" : "Neckbeard Hacker",
      "screen_name" : "NeckbeardHacker",
      "protected" : false,
      "id_str" : "278523798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303125542\/neckbeard_normal.jpg",
      "id" : 278523798,
      "verified" : false
    }
  },
  "id" : 202473835373674496,
  "created_at" : "2012-05-15 19:01:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 118, 128 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202468846832058369",
  "text" : "\"because all i want to do today is jump into a massive circle jerk w\/ a bunch of guys who think they know everything\" @aquaranto on HN today",
  "id" : 202468846832058369,
  "created_at" : "2012-05-15 18:41:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/epnnWCjL",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "202444241396436992",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing The Who: Eminence Front \u266B\u266A #turntablefm http:\/\/t.co\/epnnWCjL",
  "id" : 202444241396436992,
  "created_at" : "2012-05-15 17:04:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Keith",
      "screen_name" : "adactio",
      "indices" : [ 3, 11 ],
      "id_str" : "11250",
      "id" : 11250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/fVozGTfZ",
      "expanded_url" : "https:\/\/developers.google.com\/chart\/terms",
      "display_url" : "developers.google.com\/chart\/terms"
    } ]
  },
  "geo" : { },
  "id_str" : "202439222983004160",
  "text" : "RT @adactio: Next time someone asks why I'm reinventing the wheel, I'm telling them it's because the wheel API is being deprecated. http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 140 ],
        "url" : "https:\/\/t.co\/fVozGTfZ",
        "expanded_url" : "https:\/\/developers.google.com\/chart\/terms",
        "display_url" : "developers.google.com\/chart\/terms"
      } ]
    },
    "geo" : { },
    "id_str" : "202420431284740096",
    "text" : "Next time someone asks why I'm reinventing the wheel, I'm telling them it's because the wheel API is being deprecated. https:\/\/t.co\/fVozGTfZ",
    "id" : 202420431284740096,
    "created_at" : "2012-05-15 15:29:26 +0000",
    "user" : {
      "name" : "Jeremy Keith",
      "screen_name" : "adactio",
      "protected" : false,
      "id_str" : "11250",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477375893183033344\/xPth0Xgn_normal.png",
      "id" : 11250,
      "verified" : true
    }
  },
  "id" : 202439222983004160,
  "created_at" : "2012-05-15 16:44:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fernando Takai",
      "screen_name" : "fernando_takai",
      "indices" : [ 3, 18 ],
      "id_str" : "9336242",
      "id" : 9336242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/Kkwrkf4u",
      "expanded_url" : "http:\/\/twitpic.com\/9leiih",
      "display_url" : "twitpic.com\/9leiih"
    } ]
  },
  "geo" : { },
  "id_str" : "202437529251741697",
  "text" : "RT @fernando_takai: this actually represents hackernews pretty well. http:\/\/t.co\/Kkwrkf4u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/Kkwrkf4u",
        "expanded_url" : "http:\/\/twitpic.com\/9leiih",
        "display_url" : "twitpic.com\/9leiih"
      } ]
    },
    "geo" : { },
    "id_str" : "202436372789870592",
    "text" : "this actually represents hackernews pretty well. http:\/\/t.co\/Kkwrkf4u",
    "id" : 202436372789870592,
    "created_at" : "2012-05-15 16:32:47 +0000",
    "user" : {
      "name" : "Fernando Takai",
      "screen_name" : "fernando_takai",
      "protected" : false,
      "id_str" : "9336242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507331521007874048\/bHBAXNer_normal.jpeg",
      "id" : 9336242,
      "verified" : false
    }
  },
  "id" : 202437529251741697,
  "created_at" : "2012-05-15 16:37:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/pMWRtgGC",
      "expanded_url" : "http:\/\/vimeo.com\/42122869",
      "display_url" : "vimeo.com\/42122869"
    } ]
  },
  "geo" : { },
  "id_str" : "202431368297320448",
  "text" : "This game sounds awesome. Visit disasters before they happen as a team of ghouls to murder people. http:\/\/t.co\/pMWRtgGC",
  "id" : 202431368297320448,
  "created_at" : "2012-05-15 16:12:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/19xcZmDb",
      "expanded_url" : "http:\/\/is.gd\/a181PE",
      "display_url" : "is.gd\/a181PE"
    } ]
  },
  "geo" : { },
  "id_str" : "202418554551812098",
  "text" : "I made a chart about Google that will expire in 2015. http:\/\/t.co\/19xcZmDb",
  "id" : 202418554551812098,
  "created_at" : "2012-05-15 15:21:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202408795496910848",
  "text" : "Free OSS project idea: re-implement all of gchart's API as a public service.",
  "id" : 202408795496910848,
  "created_at" : "2012-05-15 14:43:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 70 ],
      "url" : "https:\/\/t.co\/NQJRkyWL",
      "expanded_url" : "https:\/\/developers.google.com\/chart\/image\/",
      "display_url" : "developers.google.com\/chart\/image\/"
    } ]
  },
  "geo" : { },
  "id_str" : "202408678505185280",
  "text" : "And Google Chart APIs are going away by 2015. :( https:\/\/t.co\/NQJRkyWL",
  "id" : 202408678505185280,
  "created_at" : "2012-05-15 14:42:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Willison",
      "screen_name" : "simonw",
      "indices" : [ 3, 10 ],
      "id_str" : "12497",
      "id" : 12497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 134 ],
      "url" : "https:\/\/t.co\/NGr5cUKP",
      "expanded_url" : "https:\/\/developers.google.com\/chart\/image\/",
      "display_url" : "developers.google.com\/chart\/image\/"
    } ]
  },
  "geo" : { },
  "id_str" : "202408617373208576",
  "text" : "RT @simonw: Plus discovered that Google are deprecating the Google Charts image APIs (!!!) as of April 20th 2012 https:\/\/t.co\/NGr5cUKP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 122 ],
        "url" : "https:\/\/t.co\/NGr5cUKP",
        "expanded_url" : "https:\/\/developers.google.com\/chart\/image\/",
        "display_url" : "developers.google.com\/chart\/image\/"
      } ]
    },
    "geo" : { },
    "id_str" : "202408216389353472",
    "text" : "Plus discovered that Google are deprecating the Google Charts image APIs (!!!) as of April 20th 2012 https:\/\/t.co\/NGr5cUKP",
    "id" : 202408216389353472,
    "created_at" : "2012-05-15 14:40:54 +0000",
    "user" : {
      "name" : "Simon Willison",
      "screen_name" : "simonw",
      "protected" : false,
      "id_str" : "12497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000261649705\/be9cc55e64014e6d7663c50d7cb9fc75_normal.jpeg",
      "id" : 12497,
      "verified" : false
    }
  },
  "id" : 202408617373208576,
  "created_at" : "2012-05-15 14:42:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 3, 14 ],
      "id_str" : "15445975",
      "id" : 15445975
    }, {
      "name" : "BarCamp Buffalo",
      "screen_name" : "BarCampBuffalo",
      "indices" : [ 35, 50 ],
      "id_str" : "19735370",
      "id" : 19735370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/o3BZm9T4",
      "expanded_url" : "http:\/\/barcampbuffalo.org\/registrations",
      "display_url" : "barcampbuffalo.org\/registrations"
    } ]
  },
  "geo" : { },
  "id_str" : "202401509781155840",
  "text" : "RT @paddyforan: Just signed up for @BarCampBuffalo. Have you? http:\/\/t.co\/o3BZm9T4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BarCamp Buffalo",
        "screen_name" : "BarCampBuffalo",
        "indices" : [ 19, 34 ],
        "id_str" : "19735370",
        "id" : 19735370
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/o3BZm9T4",
        "expanded_url" : "http:\/\/barcampbuffalo.org\/registrations",
        "display_url" : "barcampbuffalo.org\/registrations"
      } ]
    },
    "geo" : { },
    "id_str" : "202401422476709890",
    "text" : "Just signed up for @BarCampBuffalo. Have you? http:\/\/t.co\/o3BZm9T4",
    "id" : 202401422476709890,
    "created_at" : "2012-05-15 14:13:54 +0000",
    "user" : {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "protected" : false,
      "id_str" : "15445975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433766988179963904\/MjnoKMzP_normal.jpeg",
      "id" : 15445975,
      "verified" : false
    }
  },
  "id" : 202401509781155840,
  "created_at" : "2012-05-15 14:14:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paul smith",
      "screen_name" : "paulsmith",
      "indices" : [ 0, 10 ],
      "id_str" : "4578",
      "id" : 4578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202397413380591616",
  "geo" : { },
  "id_str" : "202401457683701761",
  "in_reply_to_user_id" : 4578,
  "text" : "@paulsmith some do, privately...I just can't stand the hate.",
  "id" : 202401457683701761,
  "in_reply_to_status_id" : 202397413380591616,
  "created_at" : "2012-05-15 14:14:02 +0000",
  "in_reply_to_screen_name" : "paulsmith",
  "in_reply_to_user_id_str" : "4578",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/FmxCf7om",
      "expanded_url" : "http:\/\/www.jetblue.com\/deals\/a-may-zing",
      "display_url" : "jetblue.com\/deals\/a-may-zi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "202396397037817857",
  "text" : "Ridiculous deals for JetBlue today. http:\/\/t.co\/FmxCf7om",
  "id" : 202396397037817857,
  "created_at" : "2012-05-15 13:53:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 9, 19 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "c2jf",
      "indices" : [ 41, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202392629428752384",
  "geo" : { },
  "id_str" : "202393334487072770",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @joeferris actually on day 8 of #c2jf.",
  "id" : 202393334487072770,
  "in_reply_to_status_id" : 202392629428752384,
  "created_at" : "2012-05-15 13:41:45 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paul smith",
      "screen_name" : "paulsmith",
      "indices" : [ 0, 10 ],
      "id_str" : "4578",
      "id" : 4578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202390516220960768",
  "geo" : { },
  "id_str" : "202392078490144770",
  "in_reply_to_user_id" : 4578,
  "text" : "@paulsmith hey man, this liberal catholic is right with you.",
  "id" : 202392078490144770,
  "in_reply_to_status_id" : 202390516220960768,
  "created_at" : "2012-05-15 13:36:46 +0000",
  "in_reply_to_screen_name" : "paulsmith",
  "in_reply_to_user_id_str" : "4578",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 0, 12 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202388889380466690",
  "geo" : { },
  "id_str" : "202390438760550401",
  "in_reply_to_user_id" : 10035582,
  "text" : "@rocketslide it was more like HEY! HEY! HEYY! as I slowly brushed past the door. Chain came off too, somehow.",
  "id" : 202390438760550401,
  "in_reply_to_status_id" : 202388889380466690,
  "created_at" : "2012-05-15 13:30:15 +0000",
  "in_reply_to_screen_name" : "rocketslide",
  "in_reply_to_user_id_str" : "10035582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202386496043483138",
  "text" : "Day of firsts on the bike commute: Ate a bug, got doored (very low speed, just a brushburn), saw an accident.",
  "id" : 202386496043483138,
  "created_at" : "2012-05-15 13:14:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 11, 26 ],
      "id_str" : "155998525",
      "id" : 155998525
    }, {
      "name" : "Con-Wan Kanobi",
      "screen_name" : "somethingconcon",
      "indices" : [ 27, 43 ],
      "id_str" : "37885397",
      "id" : 37885397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202235196580438017",
  "geo" : { },
  "id_str" : "202240840716910592",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @1ofyourmeteors @somethingconcon @leenbeeen augh forgot! Was assembling stuff.",
  "id" : 202240840716910592,
  "in_reply_to_status_id" : 202235196580438017,
  "created_at" : "2012-05-15 03:35:48 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202210556478881792",
  "geo" : { },
  "id_str" : "202211265827966977",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr understood :)",
  "id" : 202211265827966977,
  "in_reply_to_status_id" : 202210556478881792,
  "created_at" : "2012-05-15 01:38:17 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 45, 53 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202209479075430401",
  "geo" : { },
  "id_str" : "202210216123707392",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr you should come to the ruby meetup! @wnyruby",
  "id" : 202210216123707392,
  "in_reply_to_status_id" : 202209479075430401,
  "created_at" : "2012-05-15 01:34:07 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202209479075430401",
  "geo" : { },
  "id_str" : "202210064956788736",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr yes it will help, but not necessary. I learned both together.",
  "id" : 202210064956788736,
  "in_reply_to_status_id" : 202209479075430401,
  "created_at" : "2012-05-15 01:33:31 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    }, {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 8, 18 ],
      "id_str" : "9980812",
      "id" : 9980812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202118583730442242",
  "geo" : { },
  "id_str" : "202120075417886720",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman @igrigorik -1 to anything that distracts from preparing your talk. i stopped using showoff, etc since HTML\/CSS != your talk",
  "id" : 202120075417886720,
  "in_reply_to_status_id" : 202118583730442242,
  "created_at" : "2012-05-14 19:35:55 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202116531226812416",
  "text" : "Dwarf fortress with carts = monorail time. MONORAIL! MONORAIL! MONORAIL!",
  "id" : 202116531226812416,
  "created_at" : "2012-05-14 19:21:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202113974794330112",
  "geo" : { },
  "id_str" : "202115973912854528",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella look out for BOGO suit deals.",
  "id" : 202115973912854528,
  "in_reply_to_status_id" : 202113974794330112,
  "created_at" : "2012-05-14 19:19:37 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202113974794330112",
  "geo" : { },
  "id_str" : "202115802533597186",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella buy a suit, like a boss.",
  "id" : 202115802533597186,
  "in_reply_to_status_id" : 202113974794330112,
  "created_at" : "2012-05-14 19:18:57 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/h4hheRB1",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/dwarffortress\/comments\/tmb5w\/released_dwarf_fortress_03408\/",
      "display_url" : "reddit.com\/r\/dwarffortres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "202115747441410048",
  "text" : "Minecarts in Dwarf Fortress. So glad I learned how to play before this update. http:\/\/t.co\/h4hheRB1",
  "id" : 202115747441410048,
  "created_at" : "2012-05-14 19:18:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Sandofsky",
      "screen_name" : "sandofsky",
      "indices" : [ 0, 10 ],
      "id_str" : "699463",
      "id" : 699463
    }, {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 11, 20 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202105589445308416",
  "geo" : { },
  "id_str" : "202109253039833088",
  "in_reply_to_user_id" : 699463,
  "text" : "@sandofsky @konklone what's wrong with a passion for this?",
  "id" : 202109253039833088,
  "in_reply_to_status_id" : 202105589445308416,
  "created_at" : "2012-05-14 18:52:55 +0000",
  "in_reply_to_screen_name" : "sandofsky",
  "in_reply_to_user_id_str" : "699463",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Lindeman",
      "screen_name" : "alindeman",
      "indices" : [ 0, 10 ],
      "id_str" : "13235612",
      "id" : 13235612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202107221784535040",
  "geo" : { },
  "id_str" : "202107654091444224",
  "in_reply_to_user_id" : 13235612,
  "text" : "@alindeman git commit -am 'stuff'",
  "id" : 202107654091444224,
  "in_reply_to_status_id" : 202107221784535040,
  "created_at" : "2012-05-14 18:46:34 +0000",
  "in_reply_to_screen_name" : "alindeman",
  "in_reply_to_user_id_str" : "13235612",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/trhjD2ae",
      "expanded_url" : "http:\/\/barcampbuffalo.herokuapp.com",
      "display_url" : "barcampbuffalo.herokuapp.com"
    } ]
  },
  "in_reply_to_status_id_str" : "202106480374185984",
  "geo" : { },
  "id_str" : "202106740064518145",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr does http:\/\/t.co\/trhjD2ae work?",
  "id" : 202106740064518145,
  "in_reply_to_status_id" : 202106480374185984,
  "created_at" : "2012-05-14 18:42:56 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202093249870049281",
  "geo" : { },
  "id_str" : "202093635087499264",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes been sold out for a while now...same dude.",
  "id" : 202093635087499264,
  "in_reply_to_status_id" : 202093249870049281,
  "created_at" : "2012-05-14 17:50:51 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/8vtstuBy",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3175-were-hiring-help-us-significantly-improve-conversion-and-retention",
      "display_url" : "37signals.com\/svn\/posts\/3175\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "202091682039214080",
  "text" : "RT @37signals: 37signals is hiring! We're looking for someone who can focus entirely on improving conversion\/retention: http:\/\/t.co\/8vtstuBy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/8vtstuBy",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3175-were-hiring-help-us-significantly-improve-conversion-and-retention",
        "display_url" : "37signals.com\/svn\/posts\/3175\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "202091161471561728",
    "text" : "37signals is hiring! We're looking for someone who can focus entirely on improving conversion\/retention: http:\/\/t.co\/8vtstuBy",
    "id" : 202091161471561728,
    "created_at" : "2012-05-14 17:41:02 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 202091682039214080,
  "created_at" : "2012-05-14 17:43:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 3, 14 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/trevorturk\/status\/202080769001275394\/photo\/1",
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/EZ4PaySP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/As3vY4SCQAA405J.jpg",
      "id_str" : "202080769005469696",
      "id" : 202080769005469696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/As3vY4SCQAA405J.jpg",
      "sizes" : [ {
        "h" : 650,
        "resize" : "fit",
        "w" : 366
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 366
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 366
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EZ4PaySP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202083502185914368",
  "text" : "RT @trevorturk: Emoji representations of people who work at 37signals http:\/\/t.co\/EZ4PaySP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/trevorturk\/status\/202080769001275394\/photo\/1",
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/EZ4PaySP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/As3vY4SCQAA405J.jpg",
        "id_str" : "202080769005469696",
        "id" : 202080769005469696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/As3vY4SCQAA405J.jpg",
        "sizes" : [ {
          "h" : 650,
          "resize" : "fit",
          "w" : 366
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 366
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 366
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/EZ4PaySP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "202080769001275394",
    "text" : "Emoji representations of people who work at 37signals http:\/\/t.co\/EZ4PaySP",
    "id" : 202080769001275394,
    "created_at" : "2012-05-14 16:59:45 +0000",
    "user" : {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "protected" : false,
      "id_str" : "1742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/59730474\/costco_normal.png",
      "id" : 1742,
      "verified" : false
    }
  },
  "id" : 202083502185914368,
  "created_at" : "2012-05-14 17:10:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Deutsch",
      "screen_name" : "sippndipp",
      "indices" : [ 0, 10 ],
      "id_str" : "15035029",
      "id" : 15035029
    }, {
      "name" : "Andy Staple",
      "screen_name" : "AndyStaple",
      "indices" : [ 11, 22 ],
      "id_str" : "34352961",
      "id" : 34352961
    }, {
      "name" : "\u1D48\u02B3\u1D43\u1D4F\u1D4F\u02B0\u1D49\u207F",
      "screen_name" : "drakkhen",
      "indices" : [ 23, 32 ],
      "id_str" : "18176030",
      "id" : 18176030
    }, {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 33, 40 ],
      "id_str" : "9488922",
      "id" : 9488922
    }, {
      "name" : "Jay Gerland",
      "screen_name" : "jaygerland",
      "indices" : [ 41, 52 ],
      "id_str" : "1068451",
      "id" : 1068451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202080672859426816",
  "geo" : { },
  "id_str" : "202082936672108544",
  "in_reply_to_user_id" : 15035029,
  "text" : "@sippndipp @andystaple @drakkhen @cpytel @jaygerland Fixed! Sorry everyone.",
  "id" : 202082936672108544,
  "in_reply_to_status_id" : 202080672859426816,
  "created_at" : "2012-05-14 17:08:21 +0000",
  "in_reply_to_screen_name" : "sippndipp",
  "in_reply_to_user_id_str" : "15035029",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BarCamp Buffalo",
      "screen_name" : "BarCampBuffalo",
      "indices" : [ 3, 18 ],
      "id_str" : "19735370",
      "id" : 19735370
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 102, 108 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/osA7n4YL",
      "expanded_url" : "http:\/\/www.barcampbuffalo.org",
      "display_url" : "barcampbuffalo.org"
    } ]
  },
  "geo" : { },
  "id_str" : "202080093718331392",
  "text" : "RT @BarCampBuffalo: We have a real site! Come sign up for May 30th BarCamp! http:\/\/t.co\/osA7n4YL (thx @qrush for setup!)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 82, 88 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/osA7n4YL",
        "expanded_url" : "http:\/\/www.barcampbuffalo.org",
        "display_url" : "barcampbuffalo.org"
      } ]
    },
    "geo" : { },
    "id_str" : "202079507249766400",
    "text" : "We have a real site! Come sign up for May 30th BarCamp! http:\/\/t.co\/osA7n4YL (thx @qrush for setup!)",
    "id" : 202079507249766400,
    "created_at" : "2012-05-14 16:54:43 +0000",
    "user" : {
      "name" : "BarCamp Buffalo",
      "screen_name" : "BarCampBuffalo",
      "protected" : false,
      "id_str" : "19735370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444567584692645888\/A81UVOcA_normal.png",
      "id" : 19735370,
      "verified" : false
    }
  },
  "id" : 202080093718331392,
  "created_at" : "2012-05-14 16:57:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202079846610894848",
  "geo" : { },
  "id_str" : "202080075624095744",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr DNS might still be propagating... :(",
  "id" : 202080075624095744,
  "in_reply_to_status_id" : 202079846610894848,
  "created_at" : "2012-05-14 16:56:59 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/89SHjfn1",
      "expanded_url" : "http:\/\/www.bigmapblog.com\/2012\/howards-map-of-buffalo-new-york-1880\/",
      "display_url" : "bigmapblog.com\/2012\/howards-m\u2026"
    }, {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/UoBmJc22",
      "expanded_url" : "http:\/\/www.bigmapblog.com\/2012\/birdseye-map-of-buffalo-new-york-1900\/",
      "display_url" : "bigmapblog.com\/2012\/birdseye-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "202042645801996290",
  "geo" : { },
  "id_str" : "202049755440885761",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape old maps. http:\/\/t.co\/89SHjfn1 http:\/\/t.co\/UoBmJc22",
  "id" : 202049755440885761,
  "in_reply_to_status_id" : 202042645801996290,
  "created_at" : "2012-05-14 14:56:30 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/epnnWCjL",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "202034313317978112",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing James Brown: Funky Drummer \u266B\u266A #turntablefm http:\/\/t.co\/epnnWCjL",
  "id" : 202034313317978112,
  "created_at" : "2012-05-14 13:55:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201855923940098048",
  "geo" : { },
  "id_str" : "201859050189754368",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman your problem is that you read comments in the first place",
  "id" : 201859050189754368,
  "in_reply_to_status_id" : 201855923940098048,
  "created_at" : "2012-05-14 02:18:42 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 0, 11 ],
      "id_str" : "1742",
      "id" : 1742
    }, {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 12, 22 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201851037575946242",
  "geo" : { },
  "id_str" : "201858887836639232",
  "in_reply_to_user_id" : 1742,
  "text" : "@trevorturk @asianmack I only applied to coop schools. I don't understand the 'college is not to get a job' mentality.",
  "id" : 201858887836639232,
  "in_reply_to_status_id" : 201851037575946242,
  "created_at" : "2012-05-14 02:18:03 +0000",
  "in_reply_to_screen_name" : "trevorturk",
  "in_reply_to_user_id_str" : "1742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201826341493022720",
  "text" : "Missed Trailer Park Boys' live show by a day here in Buffalo. Frig off!",
  "id" : 201826341493022720,
  "created_at" : "2012-05-14 00:08:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/17jPOcCh",
      "expanded_url" : "http:\/\/instagr.am\/p\/Kk1jyYM6sk\/",
      "display_url" : "instagr.am\/p\/Kk1jyYM6sk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "201729082285756416",
  "text" : "Found Caress of Steel and 2112 today. Brings the Rush collection up to 10! http:\/\/t.co\/17jPOcCh",
  "id" : 201729082285756416,
  "created_at" : "2012-05-13 17:42:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 0, 9 ],
      "id_str" : "616163",
      "id" : 616163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201508726916653056",
  "geo" : { },
  "id_str" : "201511400118550528",
  "in_reply_to_user_id" : 616163,
  "text" : "@joshpeek ha! Would love to visit with the pup and wife.",
  "id" : 201511400118550528,
  "in_reply_to_status_id" : 201508726916653056,
  "created_at" : "2012-05-13 03:17:16 +0000",
  "in_reply_to_screen_name" : "joshpeek",
  "in_reply_to_user_id_str" : "616163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 0, 9 ],
      "id_str" : "616163",
      "id" : 616163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201506310343245824",
  "geo" : { },
  "id_str" : "201508339677528064",
  "in_reply_to_user_id" : 616163,
  "text" : "@joshpeek we did but opted out since we were just learning. Next time!",
  "id" : 201508339677528064,
  "in_reply_to_status_id" : 201506310343245824,
  "created_at" : "2012-05-13 03:05:06 +0000",
  "in_reply_to_screen_name" : "joshpeek",
  "in_reply_to_user_id_str" : "616163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/pNVc31C2",
      "expanded_url" : "http:\/\/instagr.am\/p\/KjNu5tM6jb\/",
      "display_url" : "instagr.am\/p\/KjNu5tM6jb\/"
    } ]
  },
  "geo" : { },
  "id_str" : "201500616256798721",
  "text" : "Bang! http:\/\/t.co\/pNVc31C2",
  "id" : 201500616256798721,
  "created_at" : "2012-05-13 02:34:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Dziuba",
      "screen_name" : "dozba",
      "indices" : [ 0, 6 ],
      "id_str" : "44282335",
      "id" : 44282335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201484411647176704",
  "geo" : { },
  "id_str" : "201484858516709376",
  "in_reply_to_user_id" : 44282335,
  "text" : "@dozba same experience here, quite lame.",
  "id" : 201484858516709376,
  "in_reply_to_status_id" : 201484411647176704,
  "created_at" : "2012-05-13 01:31:48 +0000",
  "in_reply_to_screen_name" : "dozba",
  "in_reply_to_user_id_str" : "44282335",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201479231010635776",
  "geo" : { },
  "id_str" : "201484543742586880",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten Y U NO USE JEKYLL",
  "id" : 201484543742586880,
  "in_reply_to_status_id" : 201479231010635776,
  "created_at" : "2012-05-13 01:30:33 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeeMan",
      "screen_name" : "Drew_Baggg",
      "indices" : [ 0, 11 ],
      "id_str" : "372319943",
      "id" : 372319943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201483214487961600",
  "geo" : { },
  "id_str" : "201484364759056385",
  "in_reply_to_user_id" : 372319943,
  "text" : "@Drew_Baggg could hit some Elmwood bars and crash at my place!",
  "id" : 201484364759056385,
  "in_reply_to_status_id" : 201483214487961600,
  "created_at" : "2012-05-13 01:29:50 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeeMan",
      "screen_name" : "Drew_Baggg",
      "indices" : [ 0, 11 ],
      "id_str" : "372319943",
      "id" : 372319943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201475374373273601",
  "geo" : { },
  "id_str" : "201480475838119936",
  "in_reply_to_user_id" : 372319943,
  "text" : "@Drew_Baggg Drink.",
  "id" : 201480475838119936,
  "in_reply_to_status_id" : 201475374373273601,
  "created_at" : "2012-05-13 01:14:23 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/VhbDETao",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ki7dauM6pQ\/",
      "display_url" : "instagr.am\/p\/Ki7dauM6pQ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "201460490344464385",
  "text" : "It's not summer until this. http:\/\/t.co\/VhbDETao",
  "id" : 201460490344464385,
  "created_at" : "2012-05-12 23:54:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/tlej3I2H",
      "expanded_url" : "http:\/\/instagr.am\/p\/KiO-9iM6tK\/",
      "display_url" : "instagr.am\/p\/KiO-9iM6tK\/"
    } ]
  },
  "geo" : { },
  "id_str" : "201362695243575296",
  "text" : "Love these lights. http:\/\/t.co\/tlej3I2H",
  "id" : 201362695243575296,
  "created_at" : "2012-05-12 17:26:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    }, {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 84, 90 ],
      "id_str" : "18673",
      "id" : 18673
    }, {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 95, 104 ],
      "id_str" : "148198686",
      "id" : 148198686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/LT754X9E",
      "expanded_url" : "http:\/\/gemcutter.org",
      "display_url" : "gemcutter.org"
    } ]
  },
  "geo" : { },
  "id_str" : "201328042289799168",
  "text" : "RT @rubygems_status: We have http:\/\/t.co\/LT754X9E back under control. Big thanks to @aeden and @dnsimple for managing this for us!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Comte Anthony Eden",
        "screen_name" : "aeden",
        "indices" : [ 63, 69 ],
        "id_str" : "18673",
        "id" : 18673
      }, {
        "name" : "DNSimple",
        "screen_name" : "dnsimple",
        "indices" : [ 74, 83 ],
        "id_str" : "148198686",
        "id" : 148198686
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 28 ],
        "url" : "http:\/\/t.co\/LT754X9E",
        "expanded_url" : "http:\/\/gemcutter.org",
        "display_url" : "gemcutter.org"
      } ]
    },
    "geo" : { },
    "id_str" : "201327956222685187",
    "text" : "We have http:\/\/t.co\/LT754X9E back under control. Big thanks to @aeden and @dnsimple for managing this for us!",
    "id" : 201327956222685187,
    "created_at" : "2012-05-12 15:08:19 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 201328042289799168,
  "created_at" : "2012-05-12 15:08:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 0, 6 ],
      "id_str" : "18673",
      "id" : 18673
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 7, 15 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201324788948549633",
  "geo" : { },
  "id_str" : "201327433499152384",
  "in_reply_to_user_id" : 18673,
  "text" : "@aeden @evanphx thanks so much!",
  "id" : 201327433499152384,
  "in_reply_to_status_id" : 201324788948549633,
  "created_at" : "2012-05-12 15:06:15 +0000",
  "in_reply_to_screen_name" : "aeden",
  "in_reply_to_user_id_str" : "18673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Hart",
      "screen_name" : "Hates_",
      "indices" : [ 3, 10 ],
      "id_str" : "6328872",
      "id" : 6328872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/6IT2wvdv",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ifTIuA8Dq58",
      "display_url" : "youtube.com\/watch?v=ifTIuA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "201298553467965440",
  "text" : "RT @Hates_: GTA IV Carmageddon gone Yakety http:\/\/t.co\/6IT2wvdv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\/mac\" rel=\"nofollow\"\u003EOsfoora for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/6IT2wvdv",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ifTIuA8Dq58",
        "display_url" : "youtube.com\/watch?v=ifTIuA\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "201251376519585792",
    "text" : "GTA IV Carmageddon gone Yakety http:\/\/t.co\/6IT2wvdv",
    "id" : 201251376519585792,
    "created_at" : "2012-05-12 10:04:01 +0000",
    "user" : {
      "name" : "Richard Hart",
      "screen_name" : "Hates_",
      "protected" : false,
      "id_str" : "6328872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556786979686215681\/hZq54rPB_normal.jpeg",
      "id" : 6328872,
      "verified" : false
    }
  },
  "id" : 201298553467965440,
  "created_at" : "2012-05-12 13:11:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 49, 63 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201190990764179457",
  "text" : "Giving up on life and internet tonight. Painting @coworkbuffalo tomorrow around 1030. Fuck.",
  "id" : 201190990764179457,
  "created_at" : "2012-05-12 06:04:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 92, 100 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/6pvoULty",
      "expanded_url" : "http:\/\/gemcutter.org",
      "display_url" : "gemcutter.org"
    } ]
  },
  "geo" : { },
  "id_str" : "201190711582928896",
  "text" : "Fuck, apparently http:\/\/t.co\/6pvoULty expired without notice and got squatted. Awesome. \/cc @evanphx",
  "id" : 201190711582928896,
  "created_at" : "2012-05-12 06:02:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Peterson",
      "screen_name" : "subwindow",
      "indices" : [ 0, 10 ],
      "id_str" : "14172449",
      "id" : 14172449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201095107838087168",
  "geo" : { },
  "id_str" : "201190472620843008",
  "in_reply_to_user_id" : 14172449,
  "text" : "@subwindow oh fuck, what? Not sure how I let that expire.",
  "id" : 201190472620843008,
  "in_reply_to_status_id" : 201095107838087168,
  "created_at" : "2012-05-12 06:02:01 +0000",
  "in_reply_to_screen_name" : "subwindow",
  "in_reply_to_user_id_str" : "14172449",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201189636855435264",
  "text" : "Seriously what a sour note to end an otherwise great day. Fucking hell.",
  "id" : 201189636855435264,
  "created_at" : "2012-05-12 05:58:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201189443812605952",
  "text" : "New to Buffalo too. Is it a requirement that every newcomer to this city gets broken into\/stolen from?",
  "id" : 201189443812605952,
  "created_at" : "2012-05-12 05:57:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201189229185871873",
  "text" : "Granted should have locked it, but holy fuck. What an asshole.",
  "id" : 201189229185871873,
  "created_at" : "2012-05-12 05:57:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201189009878290432",
  "text" : "To whoever stole our new friend's bike off our lit porch at 1am: FUCK YOU.",
  "id" : 201189009878290432,
  "created_at" : "2012-05-12 05:56:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Dave Parfitt",
      "screen_name" : "metadave",
      "indices" : [ 17, 26 ],
      "id_str" : "14212405",
      "id" : 14212405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201148670350065666",
  "geo" : { },
  "id_str" : "201163509097181184",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik say hi to @metadave next week!",
  "id" : 201163509097181184,
  "in_reply_to_status_id" : 201148670350065666,
  "created_at" : "2012-05-12 04:14:52 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201162472525266945",
  "geo" : { },
  "id_str" : "201163120603967488",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv dude. Get Carcassone. There are much better options.",
  "id" : 201163120603967488,
  "in_reply_to_status_id" : 201162472525266945,
  "created_at" : "2012-05-12 04:13:20 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/g6gV4UuA",
      "expanded_url" : "http:\/\/instagr.am\/p\/KgpHA7s6po\/",
      "display_url" : "instagr.am\/p\/KgpHA7s6po\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.916706, -78.8772922754 ]
  },
  "id_str" : "201138888784351234",
  "text" : "Fire pit!   @ Cecelia's Ristorante &amp; Martini Bar http:\/\/t.co\/g6gV4UuA",
  "id" : 201138888784351234,
  "created_at" : "2012-05-12 02:37:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/jFR7qUW5",
      "expanded_url" : "http:\/\/instagr.am\/p\/KgejMlM6kD\/",
      "display_url" : "instagr.am\/p\/KgejMlM6kD\/"
    } ]
  },
  "geo" : { },
  "id_str" : "201115395149660162",
  "text" : "Apparently today is Anthony Quaranto Day in Niagara Falls! http:\/\/t.co\/jFR7qUW5",
  "id" : 201115395149660162,
  "created_at" : "2012-05-12 01:03:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Rusterholz",
      "screen_name" : "apeiros",
      "indices" : [ 0, 8 ],
      "id_str" : "69860704",
      "id" : 69860704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201018181953929216",
  "geo" : { },
  "id_str" : "201018875263975426",
  "in_reply_to_user_id" : 69860704,
  "text" : "@apeiros namespaces?",
  "id" : 201018875263975426,
  "in_reply_to_status_id" : 201018181953929216,
  "created_at" : "2012-05-11 18:40:09 +0000",
  "in_reply_to_screen_name" : "apeiros",
  "in_reply_to_user_id_str" : "69860704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 126 ],
      "url" : "https:\/\/t.co\/jo1iL37F",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/issues\/424",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "201017165112016899",
  "text" : "This is a biggie! Adding a new step in the gem push workflow for RG 2.0. Would appreciate your feedback: https:\/\/t.co\/jo1iL37F",
  "id" : 201017165112016899,
  "created_at" : "2012-05-11 18:33:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Kelley",
      "screen_name" : "colindkelley",
      "indices" : [ 0, 13 ],
      "id_str" : "156697127",
      "id" : 156697127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/8bfnxrLl",
      "expanded_url" : "http:\/\/rubydoc.info\/github\/jnicklas\/capybara\/master\/Capybara\/Node\/Matchers",
      "display_url" : "rubydoc.info\/github\/jnickla\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "200985693256822785",
  "geo" : { },
  "id_str" : "200986385392467968",
  "in_reply_to_user_id" : 156697127,
  "text" : "@colindkelley Thanks! Capybara's selectors: http:\/\/t.co\/8bfnxrLl",
  "id" : 200986385392467968,
  "in_reply_to_status_id" : 200985693256822785,
  "created_at" : "2012-05-11 16:31:03 +0000",
  "in_reply_to_screen_name" : "colindkelley",
  "in_reply_to_user_id_str" : "156697127",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200981438382874625",
  "text" : "Why doesn't a site feel complete until it has a favicon? Such a strange part of internet construction.",
  "id" : 200981438382874625,
  "created_at" : "2012-05-11 16:11:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 14, 28 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200968099879583745",
  "geo" : { },
  "id_str" : "200968362254286849",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik that's @coworkbuffalo, yes! i did the site :)",
  "id" : 200968362254286849,
  "in_reply_to_status_id" : 200968099879583745,
  "created_at" : "2012-05-11 15:19:26 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/epnnWCjL",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "in_reply_to_status_id_str" : "200967554699763712",
  "geo" : { },
  "id_str" : "200967834485014530",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik http:\/\/t.co\/epnnWCjL",
  "id" : 200967834485014530,
  "in_reply_to_status_id" : 200967554699763712,
  "created_at" : "2012-05-11 15:17:20 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kedar Mhaswade",
      "screen_name" : "bloggerkedar",
      "indices" : [ 0, 13 ],
      "id_str" : "15676339",
      "id" : 15676339
    }, {
      "name" : "Chris Eppstein",
      "screen_name" : "chriseppstein",
      "indices" : [ 14, 28 ],
      "id_str" : "14148091",
      "id" : 14148091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200899615367774209",
  "geo" : { },
  "id_str" : "200967348784594944",
  "in_reply_to_user_id" : 15676339,
  "text" : "@bloggerkedar @chriseppstein thanks guys",
  "id" : 200967348784594944,
  "in_reply_to_status_id" : 200899615367774209,
  "created_at" : "2012-05-11 15:15:24 +0000",
  "in_reply_to_screen_name" : "bloggerkedar",
  "in_reply_to_user_id_str" : "15676339",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200967211869937664",
  "text" : "Chat overload: Currently in Campfire, Skype, Turntable, and IRC.",
  "id" : 200967211869937664,
  "created_at" : "2012-05-11 15:14:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Parfitt",
      "screen_name" : "metadave",
      "indices" : [ 0, 9 ],
      "id_str" : "14212405",
      "id" : 14212405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200912807233990657",
  "geo" : { },
  "id_str" : "200945046210613248",
  "in_reply_to_user_id" : 14212405,
  "text" : "@metadave I should be down around 1030.",
  "id" : 200945046210613248,
  "in_reply_to_status_id" : 200912807233990657,
  "created_at" : "2012-05-11 13:46:47 +0000",
  "in_reply_to_screen_name" : "metadave",
  "in_reply_to_user_id_str" : "14212405",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Parfitt",
      "screen_name" : "metadave",
      "indices" : [ 0, 9 ],
      "id_str" : "14212405",
      "id" : 14212405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200770764738281473",
  "geo" : { },
  "id_str" : "200794074255589376",
  "in_reply_to_user_id" : 14212405,
  "text" : "@metadave there is wifi and a table open in ste 9. Ste 10 is in progress still :\/",
  "id" : 200794074255589376,
  "in_reply_to_status_id" : 200770764738281473,
  "created_at" : "2012-05-11 03:46:52 +0000",
  "in_reply_to_screen_name" : "metadave",
  "in_reply_to_user_id_str" : "14212405",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Parfitt",
      "screen_name" : "metadave",
      "indices" : [ 0, 9 ],
      "id_str" : "14212405",
      "id" : 14212405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200770764738281473",
  "geo" : { },
  "id_str" : "200793770898366464",
  "in_reply_to_user_id" : 14212405,
  "text" : "@metadave it's not ready\/completed yet due to carpet issues. Can show you around though! I'll be down around 10am",
  "id" : 200793770898366464,
  "in_reply_to_status_id" : 200770764738281473,
  "created_at" : "2012-05-11 03:45:40 +0000",
  "in_reply_to_screen_name" : "metadave",
  "in_reply_to_user_id_str" : "14212405",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seed Coworking",
      "screen_name" : "seedcowork",
      "indices" : [ 9, 20 ],
      "id_str" : "403807816",
      "id" : 403807816
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 62, 76 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200777521489379328",
  "text" : "Watching @seedcowork come together has been really inspiring. @coworkbuffalo has a ways to go, getting there slowly.",
  "id" : 200777521489379328,
  "created_at" : "2012-05-11 02:41:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 0, 10 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200770294821044224",
  "geo" : { },
  "id_str" : "200770883256713216",
  "in_reply_to_user_id" : 5965482,
  "text" : "@jankowski How about a screencast on opening a file?",
  "id" : 200770883256713216,
  "in_reply_to_status_id" : 200770294821044224,
  "created_at" : "2012-05-11 02:14:43 +0000",
  "in_reply_to_screen_name" : "jankowski",
  "in_reply_to_user_id_str" : "5965482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 12, 22 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/MFlSZMAI",
      "expanded_url" : "http:\/\/vimeo.com\/40614203",
      "display_url" : "vimeo.com\/40614203"
    } ]
  },
  "geo" : { },
  "id_str" : "200769276687286272",
  "text" : "Pretty sure @jankowski just nailed the screencast market. http:\/\/t.co\/MFlSZMAI",
  "id" : 200769276687286272,
  "created_at" : "2012-05-11 02:08:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200757107979599874",
  "text" : "I think I like all of the bouncy happy avatars in turntable.fm the best. So much personality.",
  "id" : 200757107979599874,
  "created_at" : "2012-05-11 01:19:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 17, 23 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 24, 31 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 32, 43 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/CnslrYLn",
      "expanded_url" : "http:\/\/turntable.fm\/thephish",
      "display_url" : "turntable.fm\/thephish"
    } ]
  },
  "geo" : { },
  "id_str" : "200747106951118848",
  "text" : "Found a room for @cmeik @croaky @phillapier , etc... http:\/\/t.co\/CnslrYLn",
  "id" : 200747106951118848,
  "created_at" : "2012-05-11 00:40:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    }, {
      "name" : "BarCamp Buffalo",
      "screen_name" : "BarCampBuffalo",
      "indices" : [ 7, 22 ],
      "id_str" : "19735370",
      "id" : 19735370
    }, {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 51, 56 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200677842483290112",
  "geo" : { },
  "id_str" : "200681790267080705",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn @BarCampBuffalo agreed, I expressed this to @popo. Feels more like an Ignite.",
  "id" : 200681790267080705,
  "in_reply_to_status_id" : 200677842483290112,
  "created_at" : "2012-05-10 20:20:41 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/epnnWCjL",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "200655522477776896",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Kenny Loggins: This Is It \u266B\u266A #turntablefm http:\/\/t.co\/epnnWCjL",
  "id" : 200655522477776896,
  "created_at" : "2012-05-10 18:36:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob DenBleyker",
      "screen_name" : "RobDenBleyker",
      "indices" : [ 3, 17 ],
      "id_str" : "21369740",
      "id" : 21369740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/c5eb8gLK",
      "expanded_url" : "http:\/\/www.nytimes.com\/2012\/05\/10\/technology\/personaltech\/rage-comics-turn-everyday-stress-into-laughs.html",
      "display_url" : "nytimes.com\/2012\/05\/10\/tec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "200636893497536512",
  "text" : "RT @RobDenBleyker: R.I.P. Journalism, 1594 - 2012 http:\/\/t.co\/c5eb8gLK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/c5eb8gLK",
        "expanded_url" : "http:\/\/www.nytimes.com\/2012\/05\/10\/technology\/personaltech\/rage-comics-turn-everyday-stress-into-laughs.html",
        "display_url" : "nytimes.com\/2012\/05\/10\/tec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "200633396081336321",
    "text" : "R.I.P. Journalism, 1594 - 2012 http:\/\/t.co\/c5eb8gLK",
    "id" : 200633396081336321,
    "created_at" : "2012-05-10 17:08:23 +0000",
    "user" : {
      "name" : "Rob DenBleyker",
      "screen_name" : "RobDenBleyker",
      "protected" : false,
      "id_str" : "21369740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2468082667\/aq3fx6bhd1dx2rbrb78g_normal.png",
      "id" : 21369740,
      "verified" : false
    }
  },
  "id" : 200636893497536512,
  "created_at" : "2012-05-10 17:22:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200626438423060480",
  "geo" : { },
  "id_str" : "200626656690442240",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape we gave up at home and hit up a local pet store that has a self-serve bath area. easy to leash, no escaping, less mess",
  "id" : 200626656690442240,
  "in_reply_to_status_id" : 200626438423060480,
  "created_at" : "2012-05-10 16:41:37 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregg Pollack",
      "screen_name" : "greggpollack",
      "indices" : [ 4, 17 ],
      "id_str" : "6082492",
      "id" : 6082492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/WBUz7uhd",
      "expanded_url" : "http:\/\/courseware.codeschool.com\/images\/blog\/node-mind-blown.gif",
      "display_url" : "courseware.codeschool.com\/images\/blog\/no\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "200614352234102785",
  "text" : "ok, @greggpollack wins. http:\/\/t.co\/WBUz7uhd",
  "id" : 200614352234102785,
  "created_at" : "2012-05-10 15:52:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200611371023470593",
  "text" : "Today is a blow on the cartridge kind of day.",
  "id" : 200611371023470593,
  "created_at" : "2012-05-10 15:40:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Pickett",
      "screen_name" : "dpickett",
      "indices" : [ 0, 9 ],
      "id_str" : "1364461",
      "id" : 1364461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200592801770115072",
  "geo" : { },
  "id_str" : "200593802367471616",
  "in_reply_to_user_id" : 1364461,
  "text" : "@dpickett where in NY?",
  "id" : 200593802367471616,
  "in_reply_to_status_id" : 200592801770115072,
  "created_at" : "2012-05-10 14:31:03 +0000",
  "in_reply_to_screen_name" : "dpickett",
  "in_reply_to_user_id_str" : "1364461",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200590372542492672",
  "text" : "Back on a 17\" MacBook just for the day...and wow, I miss the extra screen real estate coming from a 15\".",
  "id" : 200590372542492672,
  "created_at" : "2012-05-10 14:17:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 1, 11 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200432696873320448",
  "text" : ".@aquaranto: \"Geddy. Outside. Geddy. Geddy. Outside. Geddy. GEDDY. GEDDDY! Geddy. Outside.\" .dog: *burrrrrrrrp* *falls back asleep*",
  "id" : 200432696873320448,
  "created_at" : "2012-05-10 03:50:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200424504659419136",
  "text" : "My prediction is that within a year I'll have invited all of Buffalo into a Basecamp project.",
  "id" : 200424504659419136,
  "created_at" : "2012-05-10 03:18:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 100, 107 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 108, 115 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200423734966886400",
  "geo" : { },
  "id_str" : "200423995689025536",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi not sure... i think it's server-only configuration. not sure where it fits in really. maybe @hone02 @wycats can clarify?",
  "id" : 200423995689025536,
  "in_reply_to_status_id" : 200423734966886400,
  "created_at" : "2012-05-10 03:16:18 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Whittaker",
      "screen_name" : "swhitt",
      "indices" : [ 0, 7 ],
      "id_str" : "6534802",
      "id" : 6534802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/nG0SezUw",
      "expanded_url" : "http:\/\/blog.heroku.com\/archives\/2012\/5\/9\/multiple_ruby_version_support_on_heroku\/",
      "display_url" : "blog.heroku.com\/archives\/2012\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "200423490665459716",
  "geo" : { },
  "id_str" : "200423858015186945",
  "in_reply_to_user_id" : 6534802,
  "text" : "@swhitt http:\/\/t.co\/nG0SezUw",
  "id" : 200423858015186945,
  "in_reply_to_status_id" : 200423490665459716,
  "created_at" : "2012-05-10 03:15:46 +0000",
  "in_reply_to_screen_name" : "swhitt",
  "in_reply_to_user_id_str" : "6534802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 29 ],
      "url" : "https:\/\/t.co\/qrhFYbyx",
      "expanded_url" : "https:\/\/github.com\/coworkbuffalo\/barcampbuffalo\/blob\/master\/Gemfile#L3",
      "display_url" : "github.com\/coworkbuffalo\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "200422870378225664",
  "geo" : { },
  "id_str" : "200423089744510976",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi https:\/\/t.co\/qrhFYbyx",
  "id" : 200423089744510976,
  "in_reply_to_status_id" : 200422870378225664,
  "created_at" : "2012-05-10 03:12:42 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 56 ],
      "url" : "https:\/\/t.co\/smnOs7In",
      "expanded_url" : "https:\/\/github.com\/coworkbuffalo\/barcampbuffalo",
      "display_url" : "github.com\/coworkbuffalo\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "200422396782579712",
  "geo" : { },
  "id_str" : "200422844256092162",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes not much to it, really. https:\/\/t.co\/smnOs7In",
  "id" : 200422844256092162,
  "in_reply_to_status_id" : 200422396782579712,
  "created_at" : "2012-05-10 03:11:44 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 17, 24 ],
      "id_str" : "10257182",
      "id" : 10257182
    }, {
      "name" : "The Bundler",
      "screen_name" : "thebundler",
      "indices" : [ 39, 50 ],
      "id_str" : "139863817",
      "id" : 139863817
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 96, 103 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 104, 113 ],
      "id_str" : "23621187",
      "id" : 23621187
    }, {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 114, 121 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200422139722072065",
  "text" : "Pushed an app to @heroku tonight using @thebundler's new ruby directive, worked great! Nice job @hone02 @schneems @wycats, etc!",
  "id" : 200422139722072065,
  "created_at" : "2012-05-10 03:08:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Pumm",
      "screen_name" : "pummer",
      "indices" : [ 0, 7 ],
      "id_str" : "45489027",
      "id" : 45489027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/BamKEZFe",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=fHZnzFVZ3_o",
      "display_url" : "youtube.com\/watch?v=fHZnzF\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "200414518864658434",
  "geo" : { },
  "id_str" : "200414923992473602",
  "in_reply_to_user_id" : 45489027,
  "text" : "@pummer http:\/\/t.co\/BamKEZFe",
  "id" : 200414923992473602,
  "in_reply_to_status_id" : 200414518864658434,
  "created_at" : "2012-05-10 02:40:16 +0000",
  "in_reply_to_screen_name" : "pummer",
  "in_reply_to_user_id_str" : "45489027",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 12, 25 ],
      "id_str" : "11587602",
      "id" : 11587602
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 34, 42 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "Kevin Lawver",
      "screen_name" : "kplawver",
      "indices" : [ 81, 90 ],
      "id_str" : "3404",
      "id" : 3404
    }, {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 91, 97 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/7IvKOTVS",
      "expanded_url" : "http:\/\/mlkshk.com\/r\/FKDQ",
      "display_url" : "mlkshk.com\/r\/FKDQ"
    } ]
  },
  "geo" : { },
  "id_str" : "200376839489863680",
  "text" : "Synopsis of @wayneeseguin 's talk @wnyruby last night: http:\/\/t.co\/7IvKOTVS \/via @kplawver @wfarr",
  "id" : 200376839489863680,
  "created_at" : "2012-05-10 00:08:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200363530627719168",
  "text" : "IT'S SIMPLE! WE WATCH THE BATMAN! Begins on 5\/20, Dark Knight on 6\/20, Rises on 7\/20. Love multi-month movie marathons!",
  "id" : 200363530627719168,
  "created_at" : "2012-05-09 23:16:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200313387442372609",
  "text" : "FLAWLESS REFACTORY.",
  "id" : 200313387442372609,
  "created_at" : "2012-05-09 19:56:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    }, {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 6, 16 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200312553312763904",
  "geo" : { },
  "id_str" : "200313330953498625",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo @theediguy couch fire in steve's backyard! woo!",
  "id" : 200313330953498625,
  "in_reply_to_status_id" : 200312553312763904,
  "created_at" : "2012-05-09 19:56:34 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/NI7ePYsc",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=0JElywbkSbY",
      "display_url" : "youtube.com\/watch?v=0JElyw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "200270563569184768",
  "text" : "Current status: http:\/\/t.co\/NI7ePYsc",
  "id" : 200270563569184768,
  "created_at" : "2012-05-09 17:06:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 11, 18 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/200269986550382592\/photo\/1",
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/HBQVE2pp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AseAfd_CAAAmrdI.png",
      "id_str" : "200269986554576896",
      "id" : 200269986554576896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AseAfd_CAAAmrdI.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 993
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 994
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HBQVE2pp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200269986550382592",
  "text" : "Seems like @github has gotten a little boxy lately. http:\/\/t.co\/HBQVE2pp",
  "id" : 200269986550382592,
  "created_at" : "2012-05-09 17:04:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 109 ],
      "url" : "https:\/\/t.co\/mW2Lh824",
      "expanded_url" : "https:\/\/shinyplasticbag.com\/dragondrop\/",
      "display_url" : "shinyplasticbag.com\/dragondrop\/"
    } ]
  },
  "geo" : { },
  "id_str" : "200245341793169408",
  "text" : "Bought DragonDrop and literally used it a minute later. This guy is going to make bank. https:\/\/t.co\/mW2Lh824",
  "id" : 200245341793169408,
  "created_at" : "2012-05-09 15:26:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/nX5ntyE4",
      "expanded_url" : "http:\/\/bukk.it\/technobear.gif",
      "display_url" : "bukk.it\/technobear.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "200230929275428865",
  "text" : "Opened up my computer to http:\/\/t.co\/nX5ntyE4. One of these days.",
  "id" : 200230929275428865,
  "created_at" : "2012-05-09 14:29:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 6, 17 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200083702192144385",
  "geo" : { },
  "id_str" : "200087263953166338",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi @joshsusser go has gofmt though. Totally different ballpark. I wish Ruby had a required format.",
  "id" : 200087263953166338,
  "in_reply_to_status_id" : 200083702192144385,
  "created_at" : "2012-05-09 04:58:15 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200071224813031424",
  "geo" : { },
  "id_str" : "200071463502495744",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox I feel the same for an app I use daily.",
  "id" : 200071463502495744,
  "in_reply_to_status_id" : 200071224813031424,
  "created_at" : "2012-05-09 03:55:28 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200051015704248320",
  "text" : "Sounds like the internet forgot that the South is the South.",
  "id" : 200051015704248320,
  "created_at" : "2012-05-09 02:34:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 15, 28 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WNYRuby",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/pGEpLIFe",
      "expanded_url" : "http:\/\/instagr.am\/p\/KYoGjbBTOH\/",
      "display_url" : "instagr.am\/p\/KYoGjbBTOH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "200012027224260609",
  "text" : "RT @aspleenic: @wayneeseguin speaks on PostgreSQL at #WNYRuby - w00t!  @ Caputi's Sheridan Pub http:\/\/t.co\/pGEpLIFe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "wayneeseguin",
        "screen_name" : "wayneeseguin",
        "indices" : [ 0, 13 ],
        "id_str" : "11587602",
        "id" : 11587602
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WNYRuby",
        "indices" : [ 38, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/pGEpLIFe",
        "expanded_url" : "http:\/\/instagr.am\/p\/KYoGjbBTOH\/",
        "display_url" : "instagr.am\/p\/KYoGjbBTOH\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.9805709437, -78.8467526436 ]
    },
    "id_str" : "200010859051880448",
    "in_reply_to_user_id" : 11587602,
    "text" : "@wayneeseguin speaks on PostgreSQL at #WNYRuby - w00t!  @ Caputi's Sheridan Pub http:\/\/t.co\/pGEpLIFe",
    "id" : 200010859051880448,
    "created_at" : "2012-05-08 23:54:39 +0000",
    "in_reply_to_screen_name" : "wayneeseguin",
    "in_reply_to_user_id_str" : "11587602",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 200012027224260609,
  "created_at" : "2012-05-08 23:59:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199947057992179712",
  "geo" : { },
  "id_str" : "199996473591603200",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef Please don't encourage VB :(",
  "id" : 199996473591603200,
  "in_reply_to_status_id" : 199947057992179712,
  "created_at" : "2012-05-08 22:57:29 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scottmotte",
      "screen_name" : "scottmotte",
      "indices" : [ 0, 11 ],
      "id_str" : "2808474884",
      "id" : 2808474884
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199975086940372994",
  "geo" : { },
  "id_str" : "199975406206595072",
  "in_reply_to_user_id" : 23777689,
  "text" : "@scottmotte woo slow motion antique buffalo dong",
  "id" : 199975406206595072,
  "in_reply_to_status_id" : 199975086940372994,
  "created_at" : "2012-05-08 21:33:46 +0000",
  "in_reply_to_screen_name" : "motdotla",
  "in_reply_to_user_id_str" : "23777689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199919180227690497",
  "geo" : { },
  "id_str" : "199920555170869248",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr PLZ SHARE",
  "id" : 199920555170869248,
  "in_reply_to_status_id" : 199919180227690497,
  "created_at" : "2012-05-08 17:55:49 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Becker",
      "screen_name" : "veganstraightedge",
      "indices" : [ 0, 18 ],
      "id_str" : "641013",
      "id" : 641013
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 19, 32 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/Bw933mGX",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/",
      "display_url" : "coworkbuffalo.com"
    } ]
  },
  "in_reply_to_status_id_str" : "199915708791009280",
  "geo" : { },
  "id_str" : "199916183301001217",
  "in_reply_to_user_id" : 641013,
  "text" : "@veganstraightedge @steveklabnik totally using it on http:\/\/t.co\/Bw933mGX :)",
  "id" : 199916183301001217,
  "in_reply_to_status_id" : 199915708791009280,
  "created_at" : "2012-05-08 17:38:27 +0000",
  "in_reply_to_screen_name" : "veganstraightedge",
  "in_reply_to_user_id_str" : "641013",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "indices" : [ 13, 18 ],
      "id_str" : "12534",
      "id" : 12534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/xTf40m9A",
      "expanded_url" : "http:\/\/bukk.it",
      "display_url" : "bukk.it"
    } ]
  },
  "geo" : { },
  "id_str" : "199913959485227009",
  "text" : "I gotta say, @beep was already awesome, and then I found http:\/\/t.co\/xTf40m9A. My gifs directory size just expanded by 200%.",
  "id" : 199913959485227009,
  "created_at" : "2012-05-08 17:29:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199913271015374849",
  "text" : "\"blur\" is the worst named browser event.",
  "id" : 199913271015374849,
  "created_at" : "2012-05-08 17:26:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/ASwL89D3",
      "expanded_url" : "http:\/\/bukk.it\/trex.jpg",
      "display_url" : "bukk.it\/trex.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "199885212312805376",
  "text" : "Current status: http:\/\/t.co\/ASwL89D3",
  "id" : 199885212312805376,
  "created_at" : "2012-05-08 15:35:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sven Fuchs",
      "screen_name" : "svenfuchs",
      "indices" : [ 0, 10 ],
      "id_str" : "9459332",
      "id" : 9459332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199872722333990912",
  "geo" : { },
  "id_str" : "199873018460250112",
  "in_reply_to_user_id" : 9459332,
  "text" : "@svenfuchs Emoji? :P",
  "id" : 199873018460250112,
  "in_reply_to_status_id" : 199872722333990912,
  "created_at" : "2012-05-08 14:46:55 +0000",
  "in_reply_to_screen_name" : "svenfuchs",
  "in_reply_to_user_id_str" : "9459332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/cYf6Qy3s",
      "expanded_url" : "http:\/\/bukk.it\/BEARPOCALYPSE.gif",
      "display_url" : "bukk.it\/BEARPOCALYPSE.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "199863693410963456",
  "text" : "Current status: http:\/\/t.co\/cYf6Qy3s",
  "id" : 199863693410963456,
  "created_at" : "2012-05-08 14:09:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199822154915790848",
  "geo" : { },
  "id_str" : "199827675014107136",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo still waiting for this moment",
  "id" : 199827675014107136,
  "in_reply_to_status_id" : 199822154915790848,
  "created_at" : "2012-05-08 11:46:44 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 0, 7 ],
      "id_str" : "638323",
      "id" : 638323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199691098069794817",
  "geo" : { },
  "id_str" : "199701971979075584",
  "in_reply_to_user_id" : 638323,
  "text" : "@kneath complaining",
  "id" : 199701971979075584,
  "in_reply_to_status_id" : 199691098069794817,
  "created_at" : "2012-05-08 03:27:15 +0000",
  "in_reply_to_screen_name" : "kneath",
  "in_reply_to_user_id_str" : "638323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199629983545688065",
  "text" : "I really wish dogs had a \uD83D\uDCA9 button. Scumbag puppy cries incessantly to go outside then does nothing.",
  "id" : 199629983545688065,
  "created_at" : "2012-05-07 22:41:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin John Gomez",
      "screen_name" : "kevinjohngomez",
      "indices" : [ 0, 15 ],
      "id_str" : "26253666",
      "id" : 26253666
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 16, 26 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199618454477742080",
  "geo" : { },
  "id_str" : "199629279091376129",
  "in_reply_to_user_id" : 26253666,
  "text" : "@kevinjohngomez @magnachef *not ready",
  "id" : 199629279091376129,
  "in_reply_to_status_id" : 199618454477742080,
  "created_at" : "2012-05-07 22:38:23 +0000",
  "in_reply_to_screen_name" : "kevinjohngomez",
  "in_reply_to_user_id_str" : "26253666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin John Gomez",
      "screen_name" : "kevinjohngomez",
      "indices" : [ 0, 15 ],
      "id_str" : "26253666",
      "id" : 26253666
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 16, 26 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199618454477742080",
  "geo" : { },
  "id_str" : "199629221801365506",
  "in_reply_to_user_id" : 26253666,
  "text" : "@kevinjohngomez @magnachef cool. Definitely my ready yet...lots of setup to do still.",
  "id" : 199629221801365506,
  "in_reply_to_status_id" : 199618454477742080,
  "created_at" : "2012-05-07 22:38:10 +0000",
  "in_reply_to_screen_name" : "kevinjohngomez",
  "in_reply_to_user_id_str" : "26253666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/yDVnH05e",
      "expanded_url" : "http:\/\/chzgifs.files.wordpress.com\/2011\/12\/bad-guys-are-such-terrible-shots1.gif",
      "display_url" : "chzgifs.files.wordpress.com\/2011\/12\/bad-gu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "199599681171488768",
  "text" : "Current status: http:\/\/t.co\/yDVnH05e",
  "id" : 199599681171488768,
  "created_at" : "2012-05-07 20:40:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Norris",
      "screen_name" : "rsl",
      "indices" : [ 0, 4 ],
      "id_str" : "82863",
      "id" : 82863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199592235803742208",
  "geo" : { },
  "id_str" : "199592576339279873",
  "in_reply_to_user_id" : 82863,
  "text" : "@rsl yes, they also messed up their research...\"father of four\", not three :(",
  "id" : 199592576339279873,
  "in_reply_to_status_id" : 199592235803742208,
  "created_at" : "2012-05-07 20:12:33 +0000",
  "in_reply_to_screen_name" : "rsl",
  "in_reply_to_user_id_str" : "82863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/YJAT1zFI",
      "expanded_url" : "http:\/\/niagara-gazette.com\/communities\/x1585744249\/Niagara-Falls-Education-Foundation-hands-out-honors",
      "display_url" : "niagara-gazette.com\/communities\/x1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "199591932131938304",
  "text" : "Proud and honored to be a Quaranto today. http:\/\/t.co\/YJAT1zFI",
  "id" : 199591932131938304,
  "created_at" : "2012-05-07 20:09:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199577607086407680",
  "text" : "wat:  ?\/ == \"\/\"",
  "id" : 199577607086407680,
  "created_at" : "2012-05-07 19:13:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 9, 21 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199552293488701440",
  "text" : "TIL that @whereslloyd makes a huge, mean, spicy, and delicious burrito for only $6. Hell yes.",
  "id" : 199552293488701440,
  "created_at" : "2012-05-07 17:32:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 13, 23 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199517096386895872",
  "geo" : { },
  "id_str" : "199517353967484929",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison @aquaranto yep! she's been to CodeMash and RailsConf so far. :)",
  "id" : 199517353967484929,
  "in_reply_to_status_id" : 199517096386895872,
  "created_at" : "2012-05-07 15:13:38 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 12, 22 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 41, 55 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199514218200956929",
  "text" : "Just signed @aquaranto and myself up for @steelcityruby. See you there!",
  "id" : 199514218200956929,
  "created_at" : "2012-05-07 15:01:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 3, 11 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 96, 106 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 111, 124 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WNY",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "dev",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "hack",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/6KDA1Zdl",
      "expanded_url" : "http:\/\/bit.ly\/K62EhH",
      "display_url" : "bit.ly\/K62EhH"
    } ]
  },
  "geo" : { },
  "id_str" : "199494138117357568",
  "text" : "RT @wnyruby: Tomorrow night is the night for the May meetup - http:\/\/t.co\/6KDA1Zdl - Talks from @aspleenic and @wayneeseguin - Food, bee ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PJ Hagerty",
        "screen_name" : "aspleenic",
        "indices" : [ 83, 93 ],
        "id_str" : "31435721",
        "id" : 31435721
      }, {
        "name" : "wayneeseguin",
        "screen_name" : "wayneeseguin",
        "indices" : [ 98, 111 ],
        "id_str" : "11587602",
        "id" : 11587602
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WNY",
        "indices" : [ 125, 129 ]
      }, {
        "text" : "dev",
        "indices" : [ 130, 134 ]
      }, {
        "text" : "hack",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/6KDA1Zdl",
        "expanded_url" : "http:\/\/bit.ly\/K62EhH",
        "display_url" : "bit.ly\/K62EhH"
      } ]
    },
    "geo" : { },
    "id_str" : "199492341545959424",
    "text" : "Tomorrow night is the night for the May meetup - http:\/\/t.co\/6KDA1Zdl - Talks from @aspleenic and @wayneeseguin - Food, beer #WNY #dev #hack",
    "id" : 199492341545959424,
    "created_at" : "2012-05-07 13:34:15 +0000",
    "user" : {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "protected" : false,
      "id_str" : "205886758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1149676438\/wnyruby_normal.png",
      "id" : 205886758,
      "verified" : false
    }
  },
  "id" : 199494138117357568,
  "created_at" : "2012-05-07 13:41:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199334793572401152",
  "text" : "Does anyone else blink furiously sometimes when a page is loading, hoping it will appear after?",
  "id" : 199334793572401152,
  "created_at" : "2012-05-07 03:08:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199329708280778753",
  "text" : "Ok, Avengers was awesome.",
  "id" : 199329708280778753,
  "created_at" : "2012-05-07 02:48:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199287873336377344",
  "text" : "Wrapping up this epic weekend with Avengers. This better be good.",
  "id" : 199287873336377344,
  "created_at" : "2012-05-07 00:01:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boom Haackalacka",
      "screen_name" : "haacked",
      "indices" : [ 0, 8 ],
      "id_str" : "768197",
      "id" : 768197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199253785011425281",
  "geo" : { },
  "id_str" : "199272857757417472",
  "in_reply_to_user_id" : 768197,
  "text" : "@haacked git aliases exist for this reason!",
  "id" : 199272857757417472,
  "in_reply_to_status_id" : 199253785011425281,
  "created_at" : "2012-05-06 23:02:06 +0000",
  "in_reply_to_screen_name" : "haacked",
  "in_reply_to_user_id_str" : "768197",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/HhSXaRlP",
      "expanded_url" : "http:\/\/www.andylopresto.com\/japersrink\/Ron%20Burgundy%20That%20Escalated%20Quickly.jpg",
      "display_url" : "andylopresto.com\/japersrink\/Ron\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "199248625954594816",
  "text" : "Current status:  http:\/\/t.co\/HhSXaRlP",
  "id" : 199248625954594816,
  "created_at" : "2012-05-06 21:25:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199229453702930432",
  "geo" : { },
  "id_str" : "199241769743945728",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy biked down too! Coffee helps, but yes, exhausted",
  "id" : 199241769743945728,
  "in_reply_to_status_id" : 199229453702930432,
  "created_at" : "2012-05-06 20:58:34 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/AAHEASJz",
      "expanded_url" : "http:\/\/www.groupon.com\/deals\/spca-erie-county",
      "display_url" : "groupon.com\/deals\/spca-eri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "199153294231347200",
  "text" : "A groupon for the SPCA seems like this is going a little too far. http:\/\/t.co\/AAHEASJz",
  "id" : 199153294231347200,
  "created_at" : "2012-05-06 15:07:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198957305377734656",
  "geo" : { },
  "id_str" : "198957681975885825",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy 16, actually: 8 desks, 8 chairs. D: Going to need to wait until carpet is down.",
  "id" : 198957681975885825,
  "in_reply_to_status_id" : 198957305377734656,
  "created_at" : "2012-05-06 02:09:42 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198951465539211264",
  "geo" : { },
  "id_str" : "198953403563520000",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef if you end up hitting any elmwood bars, yell!",
  "id" : 198953403563520000,
  "in_reply_to_status_id" : 198951465539211264,
  "created_at" : "2012-05-06 01:52:42 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198933827018702848",
  "text" : "Holy crap! SUPERMOON",
  "id" : 198933827018702848,
  "created_at" : "2012-05-06 00:34:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 33, 47 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198932452004216832",
  "text" : "Holy crap, epic shipping day for @coworkbuffalo. SHIP!",
  "id" : 198932452004216832,
  "created_at" : "2012-05-06 00:29:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/198525966811803649\/photo\/1",
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/QM1qi54q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsFOUKLCMAITOy0.jpg",
      "id_str" : "198525966815997954",
      "id" : 198525966815997954,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsFOUKLCMAITOy0.jpg",
      "sizes" : [ {
        "h" : 406,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QM1qi54q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198526063737974785",
  "text" : "RT @coworkbuffalo: This is not the TARDIS. However it is still awesome, and we'll have it soon! http:\/\/t.co\/QM1qi54q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/198525966811803649\/photo\/1",
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/QM1qi54q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AsFOUKLCMAITOy0.jpg",
        "id_str" : "198525966815997954",
        "id" : 198525966815997954,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsFOUKLCMAITOy0.jpg",
        "sizes" : [ {
          "h" : 406,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 406,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 406,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/QM1qi54q"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "198525966811803649",
    "text" : "This is not the TARDIS. However it is still awesome, and we'll have it soon! http:\/\/t.co\/QM1qi54q",
    "id" : 198525966811803649,
    "created_at" : "2012-05-04 21:34:14 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 198526063737974785,
  "created_at" : "2012-05-04 21:34:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 17, 31 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198430772594618368",
  "text" : "Working a ton on @coworkbuffalo space this weekend. Follow for updates!",
  "id" : 198430772594618368,
  "created_at" : "2012-05-04 15:15:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/1N032ang",
      "expanded_url" : "http:\/\/samsoff.es\/posts\/rubymotion-review",
      "display_url" : "samsoff.es\/posts\/rubymoti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "198225442380054532",
  "text" : "RubyMotion is looking great. Need to check it out. http:\/\/t.co\/1N032ang",
  "id" : 198225442380054532,
  "created_at" : "2012-05-04 01:40:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198166520122179584",
  "geo" : { },
  "id_str" : "198188740718510081",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan serious. Don't waste time writing a site when you can write your presentation",
  "id" : 198188740718510081,
  "in_reply_to_status_id" : 198166520122179584,
  "created_at" : "2012-05-03 23:14:12 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/waTaI38X",
      "expanded_url" : "http:\/\/instagr.am\/p\/KLqx-Ws6sN\/",
      "display_url" : "instagr.am\/p\/KLqx-Ws6sN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "198186826236825600",
  "text" : "First picnic in the parkway! http:\/\/t.co\/waTaI38X",
  "id" : 198186826236825600,
  "created_at" : "2012-05-03 23:06:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198166147542159360",
  "geo" : { },
  "id_str" : "198166300609089536",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan keynote",
  "id" : 198166300609089536,
  "in_reply_to_status_id" : 198166147542159360,
  "created_at" : "2012-05-03 21:45:02 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Rusterholz",
      "screen_name" : "apeiros",
      "indices" : [ 0, 8 ],
      "id_str" : "69860704",
      "id" : 69860704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198145625458618370",
  "geo" : { },
  "id_str" : "198155612360687616",
  "in_reply_to_user_id" : 69860704,
  "text" : "@apeiros @mr_robgleeson there were a\nLOT of parsing problems with the descriptions. If you want a db dump to help fix this, let me know",
  "id" : 198155612360687616,
  "in_reply_to_status_id" : 198145625458618370,
  "created_at" : "2012-05-03 21:02:34 +0000",
  "in_reply_to_screen_name" : "apeiros",
  "in_reply_to_user_id_str" : "69860704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Rusterholz",
      "screen_name" : "apeiros",
      "indices" : [ 0, 8 ],
      "id_str" : "69860704",
      "id" : 69860704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198142021662285824",
  "geo" : { },
  "id_str" : "198143315072385024",
  "in_reply_to_user_id" : 69860704,
  "text" : "@apeiros What?",
  "id" : 198143315072385024,
  "in_reply_to_status_id" : 198142021662285824,
  "created_at" : "2012-05-03 20:13:42 +0000",
  "in_reply_to_screen_name" : "apeiros",
  "in_reply_to_user_id_str" : "69860704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/198128031397724160\/photo\/1",
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/mrjrj1hS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar_kZRPCQAMUsxU.png",
      "id_str" : "198128031401918467",
      "id" : 198128031401918467,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar_kZRPCQAMUsxU.png",
      "sizes" : [ {
        "h" : 333,
        "resize" : "fit",
        "w" : 356
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 356
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 356
      } ],
      "display_url" : "pic.twitter.com\/mrjrj1hS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/8CoTPvj6",
      "expanded_url" : "http:\/\/barackobama.com",
      "display_url" : "barackobama.com"
    } ]
  },
  "geo" : { },
  "id_str" : "198128031397724160",
  "text" : "Amazing, http:\/\/t.co\/8CoTPvj6 has the campaign logo in ASCII art in the HTML source. http:\/\/t.co\/mrjrj1hS",
  "id" : 198128031397724160,
  "created_at" : "2012-05-03 19:12:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 3, 11 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198083271484129280",
  "text" : "RT @evanphx: Pour one out for Hpricot. It's been closed. Tell your friends to switch to nokogiri.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "198082869086797825",
    "text" : "Pour one out for Hpricot. It's been closed. Tell your friends to switch to nokogiri.",
    "id" : 198082869086797825,
    "created_at" : "2012-05-03 16:13:30 +0000",
    "user" : {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "protected" : false,
      "id_str" : "5444392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500424848519077892\/9BhPED16_normal.jpeg",
      "id" : 5444392,
      "verified" : false
    }
  },
  "id" : 198083271484129280,
  "created_at" : "2012-05-03 16:15:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/7ySSVTEO",
      "expanded_url" : "http:\/\/instagr.am\/p\/KKuiohM6i9\/",
      "display_url" : "instagr.am\/p\/KKuiohM6i9\/"
    } ]
  },
  "geo" : { },
  "id_str" : "198054448499671040",
  "text" : "My pair programming partner is way too distracted on the porch. http:\/\/t.co\/7ySSVTEO",
  "id" : 198054448499671040,
  "created_at" : "2012-05-03 14:20:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198049539180068865",
  "text" : "Today is a hack on the porch kind of day. The best day.",
  "id" : 198049539180068865,
  "created_at" : "2012-05-03 14:01:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 25, 31 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/WbHZf4K9",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3167-code-spelunking-in-the-all-new-basecamp",
      "display_url" : "37signals.com\/svn\/posts\/3167\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "198048960160608256",
  "text" : "RT @thoughtbot: Put some @qrush knowledge in your brain: http:\/\/t.co\/WbHZf4K9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 9, 15 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/WbHZf4K9",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3167-code-spelunking-in-the-all-new-basecamp",
        "display_url" : "37signals.com\/svn\/posts\/3167\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "198042661633007616",
    "text" : "Put some @qrush knowledge in your brain: http:\/\/t.co\/WbHZf4K9",
    "id" : 198042661633007616,
    "created_at" : "2012-05-03 13:33:44 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 198048960160608256,
  "created_at" : "2012-05-03 13:58:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Winfield",
      "screen_name" : "wpeterson",
      "indices" : [ 0, 10 ],
      "id_str" : "13268512",
      "id" : 13268512
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 11, 19 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 20, 27 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 85 ],
      "url" : "https:\/\/t.co\/FKnnbNiG",
      "expanded_url" : "https:\/\/rubygems.org\/users\/new",
      "display_url" : "rubygems.org\/users\/new"
    } ]
  },
  "in_reply_to_status_id_str" : "198045270968246274",
  "geo" : { },
  "id_str" : "198048899838124033",
  "in_reply_to_user_id" : 13268512,
  "text" : "@wpeterson @evanphx @sferik this just worked for me. are you on https:\/\/t.co\/FKnnbNiG ?",
  "id" : 198048899838124033,
  "in_reply_to_status_id" : 198045270968246274,
  "created_at" : "2012-05-03 13:58:31 +0000",
  "in_reply_to_screen_name" : "wpeterson",
  "in_reply_to_user_id_str" : "13268512",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Winfield",
      "screen_name" : "wpeterson",
      "indices" : [ 0, 10 ],
      "id_str" : "13268512",
      "id" : 13268512
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 72, 80 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 81, 88 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198045270968246274",
  "geo" : { },
  "id_str" : "198045713215660033",
  "in_reply_to_user_id" : 13268512,
  "text" : "@wpeterson aghhhh will investigate. Has to be a server config issue \/cc @evanphx @sferik",
  "id" : 198045713215660033,
  "in_reply_to_status_id" : 198045270968246274,
  "created_at" : "2012-05-03 13:45:52 +0000",
  "in_reply_to_screen_name" : "wpeterson",
  "in_reply_to_user_id_str" : "13268512",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seed Coworking",
      "screen_name" : "seedcowork",
      "indices" : [ 0, 11 ],
      "id_str" : "403807816",
      "id" : 403807816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198031898398818305",
  "geo" : { },
  "id_str" : "198042428488433664",
  "in_reply_to_user_id" : 403807816,
  "text" : "@seedcowork nice work! Who did the sticker?",
  "id" : 198042428488433664,
  "in_reply_to_status_id" : 198031898398818305,
  "created_at" : "2012-05-03 13:32:49 +0000",
  "in_reply_to_screen_name" : "seedcowork",
  "in_reply_to_user_id_str" : "403807816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197907015031459841",
  "geo" : { },
  "id_str" : "197907300621615104",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten coworking in most cities is 200-400\/mo. I hope you can fit it in!",
  "id" : 197907300621615104,
  "in_reply_to_status_id" : 197907015031459841,
  "created_at" : "2012-05-03 04:35:52 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 6, 17 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 18, 25 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197868024722763776",
  "geo" : { },
  "id_str" : "197901979073253377",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo @kevinpurdy @nb3004 good times! Moar!",
  "id" : 197901979073253377,
  "in_reply_to_status_id" : 197868024722763776,
  "created_at" : "2012-05-03 04:14:43 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/pSrCtonx",
      "expanded_url" : "http:\/\/www.rheothing.com\/2012\/05\/im-that-guy.html",
      "display_url" : "rheothing.com\/2012\/05\/im-tha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197822548405260288",
  "text" : "\"I'm that guy. The guy that everyone hates. The guy who made it so difficult to open your bag of potato chips.\" http:\/\/t.co\/pSrCtonx",
  "id" : 197822548405260288,
  "created_at" : "2012-05-02 22:59:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 0, 5 ],
      "id_str" : "20941662",
      "id" : 20941662
    }, {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 6, 13 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197774225250070530",
  "geo" : { },
  "id_str" : "197775571617447936",
  "in_reply_to_user_id" : 20941662,
  "text" : "@JEG2 @geemus Resistance is great, but so unbalanced in favor of Spies.",
  "id" : 197775571617447936,
  "in_reply_to_status_id" : 197774225250070530,
  "created_at" : "2012-05-02 19:52:25 +0000",
  "in_reply_to_screen_name" : "JEG2",
  "in_reply_to_user_id_str" : "20941662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197771721711947776",
  "text" : "I can't email Google about support for this either. SO FUCKING BROKEN.",
  "id" : 197771721711947776,
  "created_at" : "2012-05-02 19:37:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197771666737213440",
  "text" : "Once you add an alias for a domain under Google Apps, you can NEVER sign up for another account with that after canceling the original.",
  "id" : 197771666737213440,
  "created_at" : "2012-05-02 19:36:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Weber",
      "screen_name" : "DeanWeber",
      "indices" : [ 0, 10 ],
      "id_str" : "7307492",
      "id" : 7307492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/8T4A3IDT",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3049-we-welcome-nick-quaranto-to-37signals",
      "display_url" : "37signals.com\/svn\/posts\/3049\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "197761565020266496",
  "geo" : { },
  "id_str" : "197763258688602112",
  "in_reply_to_user_id" : 7307492,
  "text" : "@DeanWeber December. Thanks! http:\/\/t.co\/8T4A3IDT",
  "id" : 197763258688602112,
  "in_reply_to_status_id" : 197761565020266496,
  "created_at" : "2012-05-02 19:03:29 +0000",
  "in_reply_to_screen_name" : "DeanWeber",
  "in_reply_to_user_id_str" : "7307492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Reyna",
      "screen_name" : "erikreyna",
      "indices" : [ 0, 10 ],
      "id_str" : "28374202",
      "id" : 28374202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/7so8ZRzD",
      "expanded_url" : "http:\/\/imgur.com\/a\/79Kun",
      "display_url" : "imgur.com\/a\/79Kun"
    } ]
  },
  "in_reply_to_status_id_str" : "197760291365335040",
  "geo" : { },
  "id_str" : "197761340851503104",
  "in_reply_to_user_id" : 28374202,
  "text" : "@erikreyna haha nope, my husky is equally as crazy. http:\/\/t.co\/7so8ZRzD",
  "id" : 197761340851503104,
  "in_reply_to_status_id" : 197760291365335040,
  "created_at" : "2012-05-02 18:55:52 +0000",
  "in_reply_to_screen_name" : "erikreyna",
  "in_reply_to_user_id_str" : "28374202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197759758105722882",
  "text" : "Refactoring CoffeeScript is such a joy. Love this language.",
  "id" : 197759758105722882,
  "created_at" : "2012-05-02 18:49:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    }, {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 14, 21 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197755947911876609",
  "geo" : { },
  "id_str" : "197756717545697280",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie @maddox yeah, figured. Just feels like you guys are using them differently than 99% of orgs do.",
  "id" : 197756717545697280,
  "in_reply_to_status_id" : 197755947911876609,
  "created_at" : "2012-05-02 18:37:30 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197756042950606848",
  "geo" : { },
  "id_str" : "197756597576024064",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox Guess ;)",
  "id" : 197756597576024064,
  "in_reply_to_status_id" : 197756042950606848,
  "created_at" : "2012-05-02 18:37:01 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 0, 16 ],
      "id_str" : "16997374",
      "id" : 16997374
    }, {
      "name" : "Erik Reyna",
      "screen_name" : "erikreyna",
      "indices" : [ 17, 27 ],
      "id_str" : "28374202",
      "id" : 28374202
    }, {
      "name" : "Wynn Netherland",
      "screen_name" : "pengwynn",
      "indices" : [ 28, 37 ],
      "id_str" : "14100886",
      "id" : 14100886
    }, {
      "name" : "Travis CI",
      "screen_name" : "travisci",
      "indices" : [ 38, 47 ],
      "id_str" : "252481460",
      "id" : 252481460
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/197756456429305856\/photo\/1",
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/FZqWDpo0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar6ScwnCQAIGPQU.png",
      "id_str" : "197756456433500162",
      "id" : 197756456433500162,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar6ScwnCQAIGPQU.png",
      "sizes" : [ {
        "h" : 244,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 244
      } ],
      "display_url" : "pic.twitter.com\/FZqWDpo0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197755142605504512",
  "geo" : { },
  "id_str" : "197756456429305856",
  "in_reply_to_user_id" : 16997374,
  "text" : "@konstantinhaase @erikreyna @pengwynn @travisci How's this? I accept checks or cash. http:\/\/t.co\/FZqWDpo0",
  "id" : 197756456429305856,
  "in_reply_to_status_id" : 197755142605504512,
  "created_at" : "2012-05-02 18:36:28 +0000",
  "in_reply_to_screen_name" : "konstantinhaase",
  "in_reply_to_user_id_str" : "16997374",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197754941304094721",
  "geo" : { },
  "id_str" : "197755435858665473",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox PRs just don't seem conducive to a long-term discussion\/design. glad it works for you guys though.",
  "id" : 197755435858665473,
  "in_reply_to_status_id" : 197754941304094721,
  "created_at" : "2012-05-02 18:32:24 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197754052405243904",
  "geo" : { },
  "id_str" : "197754584293326848",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox lasting *months* !? i dont see how thats sustainable inside of one thread.",
  "id" : 197754584293326848,
  "in_reply_to_status_id" : 197754052405243904,
  "created_at" : "2012-05-02 18:29:01 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Carmelo Briones",
      "screen_name" : "ryanbriones",
      "indices" : [ 0, 12 ],
      "id_str" : "6144652",
      "id" : 6144652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197744571264942080",
  "geo" : { },
  "id_str" : "197744894889050112",
  "in_reply_to_user_id" : 6144652,
  "text" : "@ryanbriones the contributor agreement nonsense screams AVOID to me",
  "id" : 197744894889050112,
  "in_reply_to_status_id" : 197744571264942080,
  "created_at" : "2012-05-02 17:50:31 +0000",
  "in_reply_to_screen_name" : "ryanbriones",
  "in_reply_to_user_id_str" : "6144652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Carmelo Briones",
      "screen_name" : "ryanbriones",
      "indices" : [ 0, 12 ],
      "id_str" : "6144652",
      "id" : 6144652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197743538560172032",
  "geo" : { },
  "id_str" : "197743777845231617",
  "in_reply_to_user_id" : 6144652,
  "text" : "@ryanbriones very unhappy with choice of license on their projects. :\/",
  "id" : 197743777845231617,
  "in_reply_to_status_id" : 197743538560172032,
  "created_at" : "2012-05-02 17:46:05 +0000",
  "in_reply_to_screen_name" : "ryanbriones",
  "in_reply_to_user_id_str" : "6144652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197743153653104640",
  "geo" : { },
  "id_str" : "197743400441757696",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy also there are only stairs...:(",
  "id" : 197743400441757696,
  "in_reply_to_status_id" : 197743153653104640,
  "created_at" : "2012-05-02 17:44:35 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 11, 21 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197743153653104640",
  "geo" : { },
  "id_str" : "197743277112430593",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy @magnachef yes! come on down. space is not ready but you're more than welcome",
  "id" : 197743277112430593,
  "in_reply_to_status_id" : 197743153653104640,
  "created_at" : "2012-05-02 17:44:05 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 0, 4 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197736833021517825",
  "geo" : { },
  "id_str" : "197737726169198592",
  "in_reply_to_user_id" : 10079052,
  "text" : "@rjs WON'T SOMEONE THINK OF THE KERNING?!",
  "id" : 197737726169198592,
  "in_reply_to_status_id" : 197736833021517825,
  "created_at" : "2012-05-02 17:22:02 +0000",
  "in_reply_to_screen_name" : "rjs",
  "in_reply_to_user_id_str" : "10079052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Mongeau",
      "screen_name" : "halogenandtoast",
      "indices" : [ 0, 16 ],
      "id_str" : "15428948",
      "id" : 15428948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197707985177411585",
  "geo" : { },
  "id_str" : "197714140540846081",
  "in_reply_to_user_id" : 15428948,
  "text" : "@halogenandtoast Woo! congrats dude!",
  "id" : 197714140540846081,
  "in_reply_to_status_id" : 197707985177411585,
  "created_at" : "2012-05-02 15:48:19 +0000",
  "in_reply_to_screen_name" : "halogenandtoast",
  "in_reply_to_user_id_str" : "15428948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 0, 4 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197549609944494080",
  "geo" : { },
  "id_str" : "197551165762830336",
  "in_reply_to_user_id" : 10079052,
  "text" : "@rjs INTERNETBUX",
  "id" : 197551165762830336,
  "in_reply_to_status_id" : 197549609944494080,
  "created_at" : "2012-05-02 05:00:42 +0000",
  "in_reply_to_screen_name" : "rjs",
  "in_reply_to_user_id_str" : "10079052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/197544920377069568\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/QA0xoObu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar3SDvaCEAAox0F.png",
      "id_str" : "197544920381263872",
      "id" : 197544920381263872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar3SDvaCEAAox0F.png",
      "sizes" : [ {
        "h" : 570,
        "resize" : "fit",
        "w" : 465
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 465
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 465
      } ],
      "display_url" : "pic.twitter.com\/QA0xoObu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197545300565557249",
  "text" : "RT @coworkbuffalo: Say hello to Herd v1.0! Going to use this for figuring out who's at the space! (hooked up to Basecamp, of course!) ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/197544920377069568\/photo\/1",
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/QA0xoObu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar3SDvaCEAAox0F.png",
        "id_str" : "197544920381263872",
        "id" : 197544920381263872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar3SDvaCEAAox0F.png",
        "sizes" : [ {
          "h" : 570,
          "resize" : "fit",
          "w" : 465
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 416,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 465
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 465
        } ],
        "display_url" : "pic.twitter.com\/QA0xoObu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197544920377069568",
    "text" : "Say hello to Herd v1.0! Going to use this for figuring out who's at the space! (hooked up to Basecamp, of course!) http:\/\/t.co\/QA0xoObu",
    "id" : 197544920377069568,
    "created_at" : "2012-05-02 04:35:54 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 197545300565557249,
  "created_at" : "2012-05-02 04:37:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neeraj Singh",
      "screen_name" : "neerajdotname",
      "indices" : [ 0, 14 ],
      "id_str" : "8346072",
      "id" : 8346072
    }, {
      "name" : "Jack Dempsey",
      "screen_name" : "jackdempsey",
      "indices" : [ 15, 27 ],
      "id_str" : "15493123",
      "id" : 15493123
    }, {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 28, 37 ],
      "id_str" : "616163",
      "id" : 616163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197534716868571136",
  "geo" : { },
  "id_str" : "197542539383939073",
  "in_reply_to_user_id" : 8346072,
  "text" : "@neerajdotname @jackdempsey @joshpeek we're not using it yet ! pretty sure the slides say this. just pimping it out!",
  "id" : 197542539383939073,
  "in_reply_to_status_id" : 197534716868571136,
  "created_at" : "2012-05-02 04:26:26 +0000",
  "in_reply_to_screen_name" : "neerajdotname",
  "in_reply_to_user_id_str" : "8346072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 0, 8 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197476450432069632",
  "geo" : { },
  "id_str" : "197476534594977792",
  "in_reply_to_user_id" : 670283,
  "text" : "@drbrain what is this i dont even",
  "id" : 197476534594977792,
  "in_reply_to_status_id" : 197476450432069632,
  "created_at" : "2012-05-02 00:04:09 +0000",
  "in_reply_to_screen_name" : "drbrain",
  "in_reply_to_user_id_str" : "670283",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197470720861814784",
  "text" : "@IselaMariaPhoto awesome! glad he's doing more than eating them! :P",
  "id" : 197470720861814784,
  "created_at" : "2012-05-01 23:41:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197467264302329856",
  "geo" : { },
  "id_str" : "197467403263811584",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx TACO TOWWWWN!!!!!",
  "id" : 197467403263811584,
  "in_reply_to_status_id" : 197467264302329856,
  "created_at" : "2012-05-01 23:27:52 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/LuUsUM0p",
      "expanded_url" : "http:\/\/instagr.am\/p\/KGjYgRs6uQ\/",
      "display_url" : "instagr.am\/p\/KGjYgRs6uQ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "197466895534915584",
  "text" : "P I ZZ A  http:\/\/t.co\/LuUsUM0p",
  "id" : 197466895534915584,
  "created_at" : "2012-05-01 23:25:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/Dh0Xozjp",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=wusGIl3v044",
      "display_url" : "youtube.com\/watch?v=wusGIl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197463075903913984",
  "text" : "Current dinner status: http:\/\/t.co\/Dh0Xozjp",
  "id" : 197463075903913984,
  "created_at" : "2012-05-01 23:10:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt culpepper",
      "screen_name" : "_mculp",
      "indices" : [ 0, 7 ],
      "id_str" : "21530821",
      "id" : 21530821
    }, {
      "name" : "Chris Thorn",
      "screen_name" : "thorncp",
      "indices" : [ 8, 16 ],
      "id_str" : "31168483",
      "id" : 31168483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197370295894548480",
  "geo" : { },
  "id_str" : "197386003542052864",
  "in_reply_to_user_id" : 21530821,
  "text" : "@_mculp @thorncp nope, it's just GET requests counted to those URLs. Lots of mirrors combing the site, webhooks too.",
  "id" : 197386003542052864,
  "in_reply_to_status_id" : 197370295894548480,
  "created_at" : "2012-05-01 18:04:25 +0000",
  "in_reply_to_screen_name" : "_mculp",
  "in_reply_to_user_id_str" : "21530821",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Chris Buryta",
      "screen_name" : "cburyta",
      "indices" : [ 46, 54 ],
      "id_str" : "5875982",
      "id" : 5875982
    }, {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 59, 74 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/ZQVySwST",
      "expanded_url" : "http:\/\/coworkbuffalo.com",
      "display_url" : "coworkbuffalo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "197353902725799937",
  "text" : "RT @coworkbuffalo: Big thanks and congrats to @cburyta and @ChrisVanPatten for their first pull requests ever on http:\/\/t.co\/ZQVySwST today!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Buryta",
        "screen_name" : "cburyta",
        "indices" : [ 27, 35 ],
        "id_str" : "5875982",
        "id" : 5875982
      }, {
        "name" : "Chris Van Patten",
        "screen_name" : "ChrisVanPatten",
        "indices" : [ 40, 55 ],
        "id_str" : "72883",
        "id" : 72883
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/ZQVySwST",
        "expanded_url" : "http:\/\/coworkbuffalo.com",
        "display_url" : "coworkbuffalo.com"
      } ]
    },
    "geo" : { },
    "id_str" : "197353866537340929",
    "text" : "Big thanks and congrats to @cburyta and @ChrisVanPatten for their first pull requests ever on http:\/\/t.co\/ZQVySwST today!",
    "id" : 197353866537340929,
    "created_at" : "2012-05-01 15:56:43 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 197353902725799937,
  "created_at" : "2012-05-01 15:56:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197352504873320448",
  "geo" : { },
  "id_str" : "197353576660606977",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten MERGED!",
  "id" : 197353576660606977,
  "in_reply_to_status_id" : 197352504873320448,
  "created_at" : "2012-05-01 15:55:33 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197341796496441344",
  "text" : "Any Sparrow users know the shortcut for getting the latest update in a thread? (The black link at the top of a convo)",
  "id" : 197341796496441344,
  "created_at" : "2012-05-01 15:08:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/vnCFrbri",
      "expanded_url" : "http:\/\/soundcloud.com\/marak\/the-git-rap",
      "display_url" : "soundcloud.com\/marak\/the-git-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197331667600408576",
  "text" : "The git rap. http:\/\/t.co\/vnCFrbri",
  "id" : 197331667600408576,
  "created_at" : "2012-05-01 14:28:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197177039093116928",
  "geo" : { },
  "id_str" : "197293630640234496",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant thanks!!",
  "id" : 197293630640234496,
  "in_reply_to_status_id" : 197177039093116928,
  "created_at" : "2012-05-01 11:57:21 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
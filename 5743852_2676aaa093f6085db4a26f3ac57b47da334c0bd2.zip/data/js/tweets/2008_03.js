Grailbird.data.tweets_2008_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780939192",
  "geo" : { },
  "id_str" : "780939970",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway Lovely. Now I wonder if anyone will actually use the broken format.",
  "id" : 780939970,
  "in_reply_to_status_id" : 780939192,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780944875",
  "text" : "There's some innate satisfaction to a clean inbox.",
  "id" : 780944875,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780947941",
  "geo" : { },
  "id_str" : "780948394",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob From what I've read, the spec has a lot of obvious internal problems.  I don't claim to be an expert but it seems pretty broken.",
  "id" : 780948394,
  "in_reply_to_status_id" : 780947941,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780948993",
  "geo" : { },
  "id_str" : "780952351",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob  Here's a presentation about what's messed up with it. Some MS specific stuff is built into the spec. http:\/\/tinyurl.com\/2b8w9g",
  "id" : 780952351,
  "in_reply_to_status_id" : 780948993,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780988215",
  "text" : "Actually fell for an april fools joke when out of reach of said person to hit them with a brick. Good for said person.",
  "id" : 780988215,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Elder",
      "screen_name" : "keithelder",
      "indices" : [ 0, 11 ],
      "id_str" : "6136542",
      "id" : 6136542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780988351",
  "geo" : { },
  "id_str" : "780989951",
  "in_reply_to_user_id" : 6136542,
  "text" : "@keithelder You could probably set up templates or code snippets, but it'd be way too hard to generalize that.",
  "id" : 780989951,
  "in_reply_to_status_id" : 780988351,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "keithelder",
  "in_reply_to_user_id_str" : "6136542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Elder",
      "screen_name" : "keithelder",
      "indices" : [ 0, 11 ],
      "id_str" : "6136542",
      "id" : 6136542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780993840",
  "geo" : { },
  "id_str" : "780994681",
  "in_reply_to_user_id" : 6136542,
  "text" : "@keithelder Try Ctrl + i...incremental search. It's handy.",
  "id" : 780994681,
  "in_reply_to_status_id" : 780993840,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "keithelder",
  "in_reply_to_user_id_str" : "6136542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Badera",
      "screen_name" : "andrewbadera",
      "indices" : [ 0, 13 ],
      "id_str" : "1535551",
      "id" : 1535551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780985294",
  "geo" : { },
  "id_str" : "780998634",
  "in_reply_to_user_id" : 1535551,
  "text" : "@andrewbadera Hi there! Yes, I am. Are you a grad?",
  "id" : 780998634,
  "in_reply_to_status_id" : 780985294,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewbadera",
  "in_reply_to_user_id_str" : "1535551",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morten H\u00F8jer Jensen",
      "screen_name" : "obstructionist",
      "indices" : [ 0, 15 ],
      "id_str" : "324298080",
      "id" : 324298080
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780999787",
  "text" : "@Obstructionist I thought they were starting to build there...or not yet? I haven't been to NYC in a few years.",
  "id" : 780999787,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780998754",
  "geo" : { },
  "id_str" : "781000234",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 Damn, I missed it! Hopefully they'll still be up tomorrow.",
  "id" : 781000234,
  "in_reply_to_status_id" : 780998754,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Badera",
      "screen_name" : "andrewbadera",
      "indices" : [ 0, 13 ],
      "id_str" : "1535551",
      "id" : 1535551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781010271",
  "geo" : { },
  "id_str" : "781011872",
  "in_reply_to_user_id" : 1535551,
  "text" : "@andrewbadera Cool. Always neat meeting RITsians on Twitter. :)",
  "id" : 781011872,
  "in_reply_to_status_id" : 781010271,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewbadera",
  "in_reply_to_user_id_str" : "1535551",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781013935",
  "text" : "Mike Myers' career takes another dive: http:\/\/www.cnn.com\/2008\/SHOWBIZ\/Movies\/04\/01\/film.theloveguru.ap\/index.html",
  "id" : 781013935,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Badera",
      "screen_name" : "andrewbadera",
      "indices" : [ 0, 13 ],
      "id_str" : "1535551",
      "id" : 1535551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781016550",
  "geo" : { },
  "id_str" : "781020317",
  "in_reply_to_user_id" : 1535551,
  "text" : "@andrewbadera Today, absolutely beautiful. Very warm, a tad bit rainy at times. The real first day of spring.",
  "id" : 781020317,
  "in_reply_to_status_id" : 781016550,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewbadera",
  "in_reply_to_user_id_str" : "1535551",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shashi Bellamkonda",
      "screen_name" : "shashib",
      "indices" : [ 0, 8 ],
      "id_str" : "1221471",
      "id" : 1221471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781041354",
  "geo" : { },
  "id_str" : "781043321",
  "in_reply_to_user_id" : 1221471,
  "text" : "@shashib I hate you for linking to a website that resized my browser. :[",
  "id" : 781043321,
  "in_reply_to_status_id" : 781041354,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "shashib",
  "in_reply_to_user_id_str" : "1221471",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 25, 30 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781068730",
  "text" : "I'm really thinking that @woot's bag of craps today are nonexistent april fool's jokes.",
  "id" : 781068730,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781113262",
  "text" : "The pinnacle of gaming. I need to do this. http:\/\/aa1.naurunappula.com\/0\/011\/465\/78723.jpg",
  "id" : 781113262,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zefrank",
      "screen_name" : "zefrank",
      "indices" : [ 0, 8 ],
      "id_str" : "11340982",
      "id" : 11340982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781030921",
  "geo" : { },
  "id_str" : "781119397",
  "in_reply_to_user_id" : 11340982,
  "text" : "@zefrank hello there fellow twitterati :)",
  "id" : 781119397,
  "in_reply_to_status_id" : 781030921,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "zefrank",
  "in_reply_to_user_id_str" : "11340982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Henderson",
      "screen_name" : "elmofromok",
      "indices" : [ 0, 11 ],
      "id_str" : "4444",
      "id" : 4444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781120221",
  "geo" : { },
  "id_str" : "781120352",
  "in_reply_to_user_id" : 4444,
  "text" : "@elmofromok CAPS LOCK IS CRUISE CONTROL FOR COOL.",
  "id" : 781120352,
  "in_reply_to_status_id" : 781120221,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "elmofromok",
  "in_reply_to_user_id_str" : "4444",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781152881",
  "text" : "I think panic buttons on keyless entries are solely for making the driver look retarded and not to deter criminals.",
  "id" : 781152881,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Le",
      "screen_name" : "a7an",
      "indices" : [ 0, 5 ],
      "id_str" : "758185",
      "id" : 758185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780497135",
  "geo" : { },
  "id_str" : "780498587",
  "in_reply_to_user_id" : 758185,
  "text" : "@a7an Definitely time for new laptop, or sending it back to IBM",
  "id" : 780498587,
  "in_reply_to_status_id" : 780497135,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "a7an",
  "in_reply_to_user_id_str" : "758185",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780502381",
  "text" : "One would think that planes would be easier to raytrace than spheres. Think again.",
  "id" : 780502381,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780514606",
  "text" : "I can't stand this raytracer. Considering withdrawing from the class.",
  "id" : 780514606,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780834426",
  "text" : "Wireless network is not working with my laptop. What a lovely Tuesday. And I brought my coat. Professor 7 minutes late to class today.",
  "id" : 780834426,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780835899",
  "geo" : { },
  "id_str" : "780836890",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco Business cards for a coop? Are you joking?",
  "id" : 780836890,
  "in_reply_to_status_id" : 780835899,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780842545",
  "geo" : { },
  "id_str" : "780844449",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco What happened to college? Taking a leave of absence?",
  "id" : 780844449,
  "in_reply_to_status_id" : 780842545,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780844817",
  "text" : "Connected to the wireless, finally. I was almost off the grid for this horrendous class.",
  "id" : 780844817,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JComboBox",
      "screen_name" : "JComboBox",
      "indices" : [ 0, 10 ],
      "id_str" : "14198120",
      "id" : 14198120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780850484",
  "geo" : { },
  "id_str" : "780851320",
  "in_reply_to_user_id" : 14198120,
  "text" : "@JComboBox Use osmosis. Place the book above your head and wait for the information to hydrate into your brain.",
  "id" : 780851320,
  "in_reply_to_status_id" : 780850484,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "JComboBox",
  "in_reply_to_user_id_str" : "14198120",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780874980",
  "text" : "Bag of crap. Again. And I'm missing.",
  "id" : 780874980,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Starr",
      "screen_name" : "NickStarr",
      "indices" : [ 0, 10 ],
      "id_str" : "48933",
      "id" : 48933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780881952",
  "geo" : { },
  "id_str" : "780882214",
  "in_reply_to_user_id" : 48933,
  "text" : "@NickStarr It's just you. Lighten up a bit!",
  "id" : 780882214,
  "in_reply_to_status_id" : 780881952,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "NickStarr",
  "in_reply_to_user_id_str" : "48933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "milksama",
      "screen_name" : "milksama",
      "indices" : [ 0, 9 ],
      "id_str" : "14245580",
      "id" : 14245580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780878918",
  "geo" : { },
  "id_str" : "780882805",
  "in_reply_to_user_id" : 14245580,
  "text" : "@milksama That would be a bit tough since they use guid's",
  "id" : 780882805,
  "in_reply_to_status_id" : 780878918,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "milksama",
  "in_reply_to_user_id_str" : "14245580",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780885951",
  "text" : "I hit BUY IT for the Bag of Crap, but I don't see the order appearing on my account page.",
  "id" : 780885951,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780901405",
  "text" : "Sort of convinced my professor to let us leave class early. EPIC WIN.",
  "id" : 780901405,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780904984",
  "text" : "Humanized.com is down. Lame. I need to reinstall Enso.",
  "id" : 780904984,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abacab",
      "screen_name" : "abacab",
      "indices" : [ 0, 7 ],
      "id_str" : "9767172",
      "id" : 9767172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780908345",
  "geo" : { },
  "id_str" : "780909383",
  "in_reply_to_user_id" : 9767172,
  "text" : "@abacab What exactly is going wrong with your install?",
  "id" : 780909383,
  "in_reply_to_status_id" : 780908345,
  "created_at" : "2008-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "abacab",
  "in_reply_to_user_id_str" : "9767172",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0413\u0440\u0430\u043D\u043E\u0432\u0441\u043A\u0430\u044F \u0422\u0430\u0442\u044C\u044F\u043D\u0430",
      "screen_name" : "anjrued",
      "indices" : [ 23, 31 ],
      "id_str" : "2836824647",
      "id" : 2836824647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780164988",
  "geo" : { },
  "id_str" : "780166866",
  "in_reply_to_user_id" : 11204662,
  "text" : "@tw3nty3ight As I told @anjrued, let's just stick to rickrolling. Never gonna give you up...",
  "id" : 780166866,
  "in_reply_to_status_id" : 780164988,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "F3SportsCards",
  "in_reply_to_user_id_str" : "11204662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780169843",
  "text" : "Momentary brain fart: I thought I had class at 10 and I'm still sitting in my room at 9:57. It's definitely not Tuesday though. Damn mondays",
  "id" : 780169843,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780172730",
  "geo" : { },
  "id_str" : "780173145",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman Don't even joke about that combination.",
  "id" : 780173145,
  "in_reply_to_status_id" : 780172730,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780181571",
  "text" : "I can't believe that Penny Arcade is still down.",
  "id" : 780181571,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780182895",
  "geo" : { },
  "id_str" : "780184198",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 How is that class? And good luck to wherever you're headed",
  "id" : 780184198,
  "in_reply_to_status_id" : 780182895,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    }, {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 120, 128 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780187417",
  "geo" : { },
  "id_str" : "780189233",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 I really wish I was 21 so I could take that class. I would love to take Wines of the World...with guest speaker @garyvee? :P",
  "id" : 780189233,
  "in_reply_to_status_id" : 780187417,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780187104",
  "geo" : { },
  "id_str" : "780189998",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense If you put a reserve down on Women's Murder Club, I can get you 15% off a strategy guide.",
  "id" : 780189998,
  "in_reply_to_status_id" : 780187104,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JasonMC",
      "screen_name" : "Jasoncalacanis",
      "indices" : [ 0, 15 ],
      "id_str" : "1004",
      "id" : 1004
    }, {
      "name" : "Robert Scoble",
      "screen_name" : "Scobleizer",
      "indices" : [ 34, 45 ],
      "id_str" : "13348",
      "id" : 13348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780189144",
  "geo" : { },
  "id_str" : "780190651",
  "in_reply_to_user_id" : 3840,
  "text" : "@JasonCalacanis 200 followers for @Scobleizer is a drop in the bucket.",
  "id" : 780190651,
  "in_reply_to_status_id" : 780189144,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Jason",
  "in_reply_to_user_id_str" : "3840",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780192221",
  "geo" : { },
  "id_str" : "780193127",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 What. Sign me up!",
  "id" : 780193127,
  "in_reply_to_status_id" : 780192221,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K. Scott Allen",
      "screen_name" : "OdeToCode",
      "indices" : [ 0, 10 ],
      "id_str" : "13479972",
      "id" : 13479972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780193160",
  "geo" : { },
  "id_str" : "780195552",
  "in_reply_to_user_id" : 13479972,
  "text" : "@OdeToCode Awesome avatar, I'm a huge Rush fan too :) Did you see them in concert last summer?",
  "id" : 780195552,
  "in_reply_to_status_id" : 780193160,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "OdeToCode",
  "in_reply_to_user_id_str" : "13479972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780195249",
  "geo" : { },
  "id_str" : "780196628",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee Drinks for forgetting mondays.",
  "id" : 780196628,
  "in_reply_to_status_id" : 780195249,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Wurster",
      "screen_name" : "wildeep",
      "indices" : [ 0, 8 ],
      "id_str" : "1939681",
      "id" : 1939681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780210281",
  "geo" : { },
  "id_str" : "780212395",
  "in_reply_to_user_id" : 1939681,
  "text" : "@wildeep Upgrade was painless for me...having issues with it?",
  "id" : 780212395,
  "in_reply_to_status_id" : 780210281,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "wildeep",
  "in_reply_to_user_id_str" : "1939681",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Zawinski",
      "screen_name" : "jwz",
      "indices" : [ 12, 16 ],
      "id_str" : "7190742",
      "id" : 7190742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780221707",
  "text" : "Courtesy of @jwz, happy run some old web browsers day! http:\/\/snurl.com\/232ay",
  "id" : 780221707,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uE10D Clay Newton \uE11C",
      "screen_name" : "claynewton",
      "indices" : [ 0, 11 ],
      "id_str" : "6295312",
      "id" : 6295312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780220934",
  "geo" : { },
  "id_str" : "780222836",
  "in_reply_to_user_id" : 6295312,
  "text" : "@claynewton Thanks for the site link...I need to run through this too!",
  "id" : 780222836,
  "in_reply_to_status_id" : 780220934,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "claynewton",
  "in_reply_to_user_id_str" : "6295312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780246731",
  "geo" : { },
  "id_str" : "780248130",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 Suggest the 'A' word again and I'll have to beat you with a rusty motherboard.",
  "id" : 780248130,
  "in_reply_to_status_id" : 780246731,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780250125",
  "geo" : { },
  "id_str" : "780251182",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 CLEVER.",
  "id" : 780251182,
  "in_reply_to_status_id" : 780250125,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie Downe",
      "screen_name" : "Natbat",
      "indices" : [ 0, 7 ],
      "id_str" : "12161",
      "id" : 12161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780254820",
  "geo" : { },
  "id_str" : "780256647",
  "in_reply_to_user_id" : 12161,
  "text" : "@Natbat HTML Goodies has decent tutorials that are very basic and get the job done: http:\/\/snurl.com\/232gy",
  "id" : 780256647,
  "in_reply_to_status_id" : 780254820,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Natbat",
  "in_reply_to_user_id_str" : "12161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee McKusick",
      "screen_name" : "LeeMcKusick",
      "indices" : [ 0, 12 ],
      "id_str" : "10234782",
      "id" : 10234782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780259478",
  "geo" : { },
  "id_str" : "780259797",
  "in_reply_to_user_id" : 10234782,
  "text" : "@leemckusick Lovely. What class?",
  "id" : 780259797,
  "in_reply_to_status_id" : 780259478,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "LeeMcKusick",
  "in_reply_to_user_id_str" : "10234782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee McKusick",
      "screen_name" : "LeeMcKusick",
      "indices" : [ 0, 12 ],
      "id_str" : "10234782",
      "id" : 10234782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780271189",
  "geo" : { },
  "id_str" : "780272459",
  "in_reply_to_user_id" : 10234782,
  "text" : "@leemckusick Better than power atheists in ethics\/philosophy classes",
  "id" : 780272459,
  "in_reply_to_status_id" : 780271189,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "LeeMcKusick",
  "in_reply_to_user_id_str" : "10234782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780278701",
  "geo" : { },
  "id_str" : "780284456",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 I had no idea!",
  "id" : 780284456,
  "in_reply_to_status_id" : 780278701,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780329141",
  "text" : "It's always neat meeting webcomic authors. I wish I could draw.",
  "id" : 780329141,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CarrieP",
      "screen_name" : "CarrieP",
      "indices" : [ 0, 8 ],
      "id_str" : "10266282",
      "id" : 10266282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780332163",
  "geo" : { },
  "id_str" : "780333383",
  "in_reply_to_user_id" : 10266282,
  "text" : "@CarrieP Comic artist for Insert Life Here, a comic about life here at RIT. Happened to be sitting next to him in class!",
  "id" : 780333383,
  "in_reply_to_status_id" : 780332163,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "CarrieP",
  "in_reply_to_user_id_str" : "10266282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780344367",
  "text" : "Math is effing hard.",
  "id" : 780344367,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K. Scott Allen",
      "screen_name" : "OdeToCode",
      "indices" : [ 0, 10 ],
      "id_str" : "13479972",
      "id" : 13479972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780344719",
  "geo" : { },
  "id_str" : "780345652",
  "in_reply_to_user_id" : 13479972,
  "text" : "@OdeToCode Nice! I've been trying to decide where to see them this summer...Saratoga, Hershey, or Long Island",
  "id" : 780345652,
  "in_reply_to_status_id" : 780344719,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "OdeToCode",
  "in_reply_to_user_id_str" : "13479972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CariElf",
      "screen_name" : "CariElf",
      "indices" : [ 0, 8 ],
      "id_str" : "14238116",
      "id" : 14238116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780350217",
  "geo" : { },
  "id_str" : "780354857",
  "in_reply_to_user_id" : 14238116,
  "text" : "@CariElf Trying to build my raytracer and it's hurting my brain.",
  "id" : 780354857,
  "in_reply_to_status_id" : 780350217,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "CariElf",
  "in_reply_to_user_id_str" : "14238116",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Brister",
      "screen_name" : "icejunkies",
      "indices" : [ 0, 11 ],
      "id_str" : "7297052",
      "id" : 7297052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780398173",
  "geo" : { },
  "id_str" : "780399088",
  "in_reply_to_user_id" : 7297052,
  "text" : "@icejunkies think the Sabres have any chance?",
  "id" : 780399088,
  "in_reply_to_status_id" : 780398173,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "icejunkies",
  "in_reply_to_user_id_str" : "7297052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Brister",
      "screen_name" : "icejunkies",
      "indices" : [ 0, 11 ],
      "id_str" : "7297052",
      "id" : 7297052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780400209",
  "geo" : { },
  "id_str" : "780401214",
  "in_reply_to_user_id" : 7297052,
  "text" : "@icejunkies I'm wearing my sabres jersey today in hopes they'll make it!",
  "id" : 780401214,
  "in_reply_to_status_id" : 780400209,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "icejunkies",
  "in_reply_to_user_id_str" : "7297052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Kelly",
      "screen_name" : "inkedmn",
      "indices" : [ 0, 8 ],
      "id_str" : "2844098929",
      "id" : 2844098929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780417300",
  "geo" : { },
  "id_str" : "780418918",
  "in_reply_to_user_id" : 434883,
  "text" : "@inkedmn damn, how did you accomplish that? message people who didn't follow you back?",
  "id" : 780418918,
  "in_reply_to_status_id" : 780417300,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrbrettkelly",
  "in_reply_to_user_id_str" : "434883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780438217",
  "geo" : { },
  "id_str" : "780448373",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Sims...Carnival? Wtf.",
  "id" : 780448373,
  "in_reply_to_status_id" : 780438217,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780452887",
  "geo" : { },
  "id_str" : "780455269",
  "in_reply_to_user_id" : 10058232,
  "text" : "@krisbjorkman I second that.",
  "id" : 780455269,
  "in_reply_to_status_id" : 780452887,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "kristophrrr",
  "in_reply_to_user_id_str" : "10058232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780457733",
  "text" : "Super Mario Galaxy music orchestra: http:\/\/snurl.com\/233r5 really cool!",
  "id" : 780457733,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780461837",
  "text" : "Rediscovering Mario & Zelda Big Band. I have a weakness for orchestras playing video game music.",
  "id" : 780461837,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780466645",
  "geo" : { },
  "id_str" : "780468658",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Can I test it? Pleeeeeease.",
  "id" : 780468658,
  "in_reply_to_status_id" : 780466645,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780477264",
  "geo" : { },
  "id_str" : "780478178",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror That's hilarious! If only they showed that 60-70% of those planes will crash and burn.",
  "id" : 780478178,
  "in_reply_to_status_id" : 780477264,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 0, 12 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780485184",
  "geo" : { },
  "id_str" : "780486110",
  "in_reply_to_user_id" : 8453452,
  "text" : "@guykawasaki Thanks, I'll make sure to throw it on my page. And thanks again for putting me up there!",
  "id" : 780486110,
  "in_reply_to_status_id" : 780485184,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "GuyKawasaki",
  "in_reply_to_user_id_str" : "8453452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Flauaus",
      "screen_name" : "zachflauaus",
      "indices" : [ 0, 12 ],
      "id_str" : "6839272",
      "id" : 6839272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779885192",
  "geo" : { },
  "id_str" : "779886044",
  "in_reply_to_user_id" : 6839272,
  "text" : "@zachflauaus You didn't get Dune? I'm disappointed. :P",
  "id" : 779886044,
  "in_reply_to_status_id" : 779885192,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "zachflauaus",
  "in_reply_to_user_id_str" : "6839272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779910805",
  "text" : "I'm sick of homework, I just want to go on coop again.",
  "id" : 779910805,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779910005",
  "geo" : { },
  "id_str" : "779911707",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog I'm quite tempted to buy some Rush posters.",
  "id" : 779911707,
  "in_reply_to_status_id" : 779910005,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779922800",
  "text" : "Missing my blog schedule for the first time in a few weeks. I would probably feel bad if someone read it in the first place...",
  "id" : 779922800,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trish",
      "screen_name" : "Dayngr",
      "indices" : [ 0, 7 ],
      "id_str" : "5920872",
      "id" : 5920872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779928056",
  "geo" : { },
  "id_str" : "779928305",
  "in_reply_to_user_id" : 5920872,
  "text" : "@Dayngr I counted the minutes...err, tweets.",
  "id" : 779928305,
  "in_reply_to_status_id" : 779928056,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Dayngr",
  "in_reply_to_user_id_str" : "5920872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trish",
      "screen_name" : "Dayngr",
      "indices" : [ 0, 7 ],
      "id_str" : "5920872",
      "id" : 5920872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779929119",
  "geo" : { },
  "id_str" : "779929166",
  "in_reply_to_user_id" : 5920872,
  "text" : "@Dayngr Pretending to do homework.",
  "id" : 779929166,
  "in_reply_to_status_id" : 779929119,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Dayngr",
  "in_reply_to_user_id_str" : "5920872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan McMinn",
      "screen_name" : "ryanmcminn",
      "indices" : [ 0, 11 ],
      "id_str" : "12061042",
      "id" : 12061042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779928049",
  "geo" : { },
  "id_str" : "779929620",
  "in_reply_to_user_id" : 12061042,
  "text" : "@ryanmcminn Now you've got to continue the streak for the next earthquake...",
  "id" : 779929620,
  "in_reply_to_status_id" : 779928049,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryanmcminn",
  "in_reply_to_user_id_str" : "12061042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trish",
      "screen_name" : "Dayngr",
      "indices" : [ 0, 7 ],
      "id_str" : "5920872",
      "id" : 5920872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779929917",
  "geo" : { },
  "id_str" : "779930010",
  "in_reply_to_user_id" : 5920872,
  "text" : "@Dayngr I'm long beyond that...how I wish there could be cliff's notes \/ teachers guides on this stuff",
  "id" : 779930010,
  "in_reply_to_status_id" : 779929917,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Dayngr",
  "in_reply_to_user_id_str" : "5920872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779931343",
  "text" : "could I be pregnant? (hilariously dumb forum post) http:\/\/tinyurl.com\/34w3qr",
  "id" : 779931343,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Mullenweg",
      "screen_name" : "photomatt",
      "indices" : [ 61, 71 ],
      "id_str" : "13479",
      "id" : 13479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779936787",
  "text" : "Upgraded to WP 2.5, no problems yet! Very painless, props to @photomatt and his crew",
  "id" : 779936787,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779939022",
  "text" : "There doesn't seem to be too many new settings for WP 2.5, but damn the dashboard is beautiful.",
  "id" : 779939022,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779957352",
  "text" : "Why do I always work on my raytracer after midnight. It's bad for me.",
  "id" : 779957352,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyell E. Petersen",
      "screen_name" : "93octane",
      "indices" : [ 0, 9 ],
      "id_str" : "1508231",
      "id" : 1508231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779956629",
  "geo" : { },
  "id_str" : "779958013",
  "in_reply_to_user_id" : 1508231,
  "text" : "@93octane I've got an event starting at 9ish going until midday, so perhaps after that...is a huge problem if I show up late?",
  "id" : 779958013,
  "in_reply_to_status_id" : 779956629,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "93octane",
  "in_reply_to_user_id_str" : "1508231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0413\u0440\u0430\u043D\u043E\u0432\u0441\u043A\u0430\u044F \u0422\u0430\u0442\u044C\u044F\u043D\u0430",
      "screen_name" : "anjrued",
      "indices" : [ 0, 8 ],
      "id_str" : "2836824647",
      "id" : 2836824647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779962929",
  "geo" : { },
  "id_str" : "779963201",
  "in_reply_to_user_id" : 860851,
  "text" : "@anjrued Tweetdrawal.",
  "id" : 779963201,
  "in_reply_to_status_id" : 779962929,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewdobrow",
  "in_reply_to_user_id_str" : "860851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779972805",
  "text" : "I hate when I accidentally close my command prompt.",
  "id" : 779972805,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780127582",
  "text" : "I have a case of the Mondays.",
  "id" : 780127582,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "milksama",
      "screen_name" : "milksama",
      "indices" : [ 34, 43 ],
      "id_str" : "14245580",
      "id" : 14245580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780130512",
  "text" : "Big welcome to fellow Stardockian @milksama! You definitely need an avatar, asap!",
  "id" : 780130512,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780130768",
  "text" : "@archibaldtort I'm glad you didn't say \"good\" morning. Mondays are never good.",
  "id" : 780130768,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 18, 26 ],
      "id_str" : "5768872",
      "id" : 5768872
    }, {
      "name" : "zefrank",
      "screen_name" : "zefrank",
      "indices" : [ 31, 39 ],
      "id_str" : "11340982",
      "id" : 11340982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780140344",
  "text" : "Being higher than @garyvee and @zefrank on http:\/\/twitter.alltop.com\/ is quite humbling",
  "id" : 780140344,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie Downe",
      "screen_name" : "Natbat",
      "indices" : [ 0, 7 ],
      "id_str" : "12161",
      "id" : 12161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780144773",
  "geo" : { },
  "id_str" : "780146663",
  "in_reply_to_user_id" : 12161,
  "text" : "@Natbat It's become self-aware. Unplug it before it activates SkyNet!",
  "id" : 780146663,
  "in_reply_to_status_id" : 780144773,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Natbat",
  "in_reply_to_user_id_str" : "12161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780148882",
  "text" : "Oooh, WP 2.5 dashboard can revert to the classic WP 2.3.x color scheme, click on your name at the top.",
  "id" : 780148882,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darren Rowse",
      "screen_name" : "problogger",
      "indices" : [ 0, 11 ],
      "id_str" : "1143031",
      "id" : 1143031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780153666",
  "geo" : { },
  "id_str" : "780155128",
  "in_reply_to_user_id" : 1143031,
  "text" : "@problogger This may be the beginning of the end for twitter being ad-free.",
  "id" : 780155128,
  "in_reply_to_status_id" : 780153666,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "problogger",
  "in_reply_to_user_id_str" : "1143031",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780157697",
  "text" : "News you need. Fair and Balanced. Sponsored. THANKS FACEBOOK.",
  "id" : 780157697,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780158476",
  "geo" : { },
  "id_str" : "780158922",
  "in_reply_to_user_id" : 11204662,
  "text" : "@tw3nty3ight Yeah, I don't really like it either. I could see ad companies jumping on this real fast...",
  "id" : 780158922,
  "in_reply_to_status_id" : 780158476,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "F3SportsCards",
  "in_reply_to_user_id_str" : "11204662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0413\u0440\u0430\u043D\u043E\u0432\u0441\u043A\u0430\u044F \u0422\u0430\u0442\u044C\u044F\u043D\u0430",
      "screen_name" : "anjrued",
      "indices" : [ 0, 8 ],
      "id_str" : "2836824647",
      "id" : 2836824647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780157727",
  "geo" : { },
  "id_str" : "780160649",
  "in_reply_to_user_id" : 860851,
  "text" : "@anjrued Dammit. I actually fell for it. Can't we just rickroll people instead for April Fools?",
  "id" : 780160649,
  "in_reply_to_status_id" : 780157727,
  "created_at" : "2008-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewdobrow",
  "in_reply_to_user_id_str" : "860851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snook",
      "screen_name" : "snookca",
      "indices" : [ 0, 8 ],
      "id_str" : "12591",
      "id" : 12591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779453815",
  "geo" : { },
  "id_str" : "779454776",
  "in_reply_to_user_id" : 12591,
  "text" : "@snookca Classy.",
  "id" : 779454776,
  "in_reply_to_status_id" : 779453815,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "snookca",
  "in_reply_to_user_id_str" : "12591",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779471534",
  "text" : "Still not done with the Java project of doom, need to update my Visio model and whatnot. Curses.",
  "id" : 779471534,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779603209",
  "text" : "Sick of Firefox 2's problems and installing FF 3b4.",
  "id" : 779603209,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779604455",
  "text" : "As always, I've killed my twhirl limit first thing in the morning. Also, Firebug and delicious plugins don't work in FF 3b4. :(",
  "id" : 779604455,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779619194",
  "text" : "Sundays are for sleeping. Not for being up early.",
  "id" : 779619194,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779635955",
  "text" : "Sunday morning TV sucks.",
  "id" : 779635955,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779651287",
  "geo" : { },
  "id_str" : "779652658",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense TorqueX hates you.",
  "id" : 779652658,
  "in_reply_to_status_id" : 779651287,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779663737",
  "text" : "I hate UML. Hate hate hate.",
  "id" : 779663737,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Public Hikkups",
      "screen_name" : "hikkup",
      "indices" : [ 0, 7 ],
      "id_str" : "8255522",
      "id" : 8255522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779666288",
  "geo" : { },
  "id_str" : "779666755",
  "in_reply_to_user_id" : 8255522,
  "text" : "@hikkup A washable one so you won't regret getting it in 30-40 years.",
  "id" : 779666755,
  "in_reply_to_status_id" : 779666288,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "hikkup",
  "in_reply_to_user_id_str" : "8255522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779680736",
  "text" : "Finally done with this accursed Java project. Thank goodness I didn't choose the java coop for this summer.",
  "id" : 779680736,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779686753",
  "geo" : { },
  "id_str" : "779688267",
  "in_reply_to_user_id" : 11204662,
  "text" : "@tw3nty3ight Stardust. Silly movie, but Robert DeNiro as a gay pirate is a riot.",
  "id" : 779688267,
  "in_reply_to_status_id" : 779686753,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "F3SportsCards",
  "in_reply_to_user_id_str" : "11204662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Zehnder Rossi",
      "screen_name" : "shawnz",
      "indices" : [ 0, 7 ],
      "id_str" : "7789282",
      "id" : 7789282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779694883",
  "geo" : { },
  "id_str" : "779695185",
  "in_reply_to_user_id" : 7789282,
  "text" : "@shawnz you have too much fun with the follow game.",
  "id" : 779695185,
  "in_reply_to_status_id" : 779694883,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "shawnz",
  "in_reply_to_user_id_str" : "7789282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779715146",
  "text" : "Reading about Defensiveness Communication...or super smash brothers brawl. Tough choice!",
  "id" : 779715146,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 0, 12 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779711947",
  "geo" : { },
  "id_str" : "779718011",
  "in_reply_to_user_id" : 8453452,
  "text" : "@guykawasaki Alltop suggestion: Randomize at least the 2nd row of links so users might see some of the links towards the bottom of the list",
  "id" : 779718011,
  "in_reply_to_status_id" : 779711947,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "GuyKawasaki",
  "in_reply_to_user_id_str" : "8453452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Owyang",
      "screen_name" : "jowyang",
      "indices" : [ 0, 8 ],
      "id_str" : "79543",
      "id" : 79543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779724566",
  "geo" : { },
  "id_str" : "779725275",
  "in_reply_to_user_id" : 79543,
  "text" : "@jowyang I wouldn't be surprised if this was true. Most sites have way more consumers than producers of content.",
  "id" : 779725275,
  "in_reply_to_status_id" : 779724566,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "jowyang",
  "in_reply_to_user_id_str" : "79543",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruud Hein",
      "screen_name" : "RuudHein",
      "indices" : [ 0, 9 ],
      "id_str" : "6460152",
      "id" : 6460152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779726444",
  "geo" : { },
  "id_str" : "779726889",
  "in_reply_to_user_id" : 6460152,
  "text" : "@RuudHein No, I play one on IRC.",
  "id" : 779726889,
  "in_reply_to_status_id" : 779726444,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "RuudHein",
  "in_reply_to_user_id_str" : "6460152",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779738579",
  "text" : "Facebook's people you may know feature is unearthing people from high school I really don't want to know anymore.",
  "id" : 779738579,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Roy",
      "screen_name" : "juliaroy",
      "indices" : [ 0, 9 ],
      "id_str" : "631583",
      "id" : 631583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779741679",
  "geo" : { },
  "id_str" : "779742664",
  "in_reply_to_user_id" : 631583,
  "text" : "@juliaroy Slightly more retarded than Superbad, that's how I felt about it.",
  "id" : 779742664,
  "in_reply_to_status_id" : 779741679,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "juliaroy",
  "in_reply_to_user_id_str" : "631583",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Dowell",
      "screen_name" : "CerebroJD",
      "indices" : [ 0, 10 ],
      "id_str" : "5744302",
      "id" : 5744302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779742677",
  "geo" : { },
  "id_str" : "779743044",
  "in_reply_to_user_id" : 5744302,
  "text" : "@CerebroJD It feels like typing on a thin calculator...make sure you try before you buy",
  "id" : 779743044,
  "in_reply_to_status_id" : 779742677,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "CerebroJD",
  "in_reply_to_user_id_str" : "5744302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Briggs",
      "screen_name" : "briggsb",
      "indices" : [ 0, 8 ],
      "id_str" : "1563671",
      "id" : 1563671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779746449",
  "geo" : { },
  "id_str" : "779746696",
  "in_reply_to_user_id" : 1563671,
  "text" : "@briggsb That's how I friended ya today :) How's your site holding up to the traffic?",
  "id" : 779746696,
  "in_reply_to_status_id" : 779746449,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "briggsb",
  "in_reply_to_user_id_str" : "1563671",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779755937",
  "text" : "I should probably be doing homework instead of playing games. Oh well.",
  "id" : 779755937,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mittens",
      "screen_name" : "mittens",
      "indices" : [ 0, 8 ],
      "id_str" : "5836022",
      "id" : 5836022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779750041",
  "geo" : { },
  "id_str" : "779795327",
  "in_reply_to_user_id" : 5836022,
  "text" : "@mittens congrats. the 'gallery' image looks pretty jaggy",
  "id" : 779795327,
  "in_reply_to_status_id" : 779750041,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittens",
  "in_reply_to_user_id_str" : "5836022",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779805158",
  "text" : "Trying to get motivated again, and it's certainly not working.",
  "id" : 779805158,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779824175",
  "text" : "I feel bad for the game designer who had to model steve tyler's huge lips http:\/\/snurl.com\/23059",
  "id" : 779824175,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779835050",
  "geo" : { },
  "id_str" : "779840613",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Google Docs is a lot more fun when &gt; 1 person is editing it at the same time.",
  "id" : 779840613,
  "in_reply_to_status_id" : 779835050,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779396692",
  "text" : "Still beating Java into submission...end is now in sight.",
  "id" : 779396692,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779405748",
  "text" : "Java crap still not done, but it's almost there. At least it's easy.",
  "id" : 779405748,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 56, 65 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779430787",
  "text" : "Looks like I'm headed for purgatory. How about you? via @mittense http:\/\/snurl.com\/22y9u",
  "id" : 779430787,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zak brsek",
      "screen_name" : "LittleBoy22",
      "indices" : [ 0, 12 ],
      "id_str" : "634050512",
      "id" : 634050512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779432301",
  "geo" : { },
  "id_str" : "779433103",
  "in_reply_to_user_id" : 14244723,
  "text" : "@Littleboy22 Yikes! Make sure to report them in the forums or via support so we Stardockians can handle them for ya!",
  "id" : 779433103,
  "in_reply_to_status_id" : 779432301,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Julien_Templier",
  "in_reply_to_user_id_str" : "14244723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zak brsek",
      "screen_name" : "LittleBoy22",
      "indices" : [ 0, 12 ],
      "id_str" : "634050512",
      "id" : 634050512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779438319",
  "geo" : { },
  "id_str" : "779439270",
  "in_reply_to_user_id" : 14244723,
  "text" : "@Littleboy22 I think they'll manage, now that the system has been somewhat upgraded. ;)",
  "id" : 779439270,
  "in_reply_to_status_id" : 779438319,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Julien_Templier",
  "in_reply_to_user_id_str" : "14244723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Thomson",
      "screen_name" : "chris24",
      "indices" : [ 0, 8 ],
      "id_str" : "705953",
      "id" : 705953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779444292",
  "geo" : { },
  "id_str" : "779446158",
  "in_reply_to_user_id" : 705953,
  "text" : "@chris24 Go for hell. If they've got a problem with it, I'm sure they'll write some hate mail.",
  "id" : 779446158,
  "in_reply_to_status_id" : 779444292,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris24",
  "in_reply_to_user_id_str" : "705953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779446563",
  "geo" : { },
  "id_str" : "779446858",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror On expert singing is ridiculously hard. I always wonder how Rush would do on their own songs in Rock Band...",
  "id" : 779446858,
  "in_reply_to_status_id" : 779446563,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Haslam",
      "screen_name" : "DougH",
      "indices" : [ 0, 6 ],
      "id_str" : "10396",
      "id" : 10396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779446893",
  "geo" : { },
  "id_str" : "779448183",
  "in_reply_to_user_id" : 10396,
  "text" : "@DougH Are you SURE?! You don't want QuickTime, iTunes, their automatic updating service running in the background, AND Safari? Oh please.",
  "id" : 779448183,
  "in_reply_to_status_id" : 779446893,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "DougH",
  "in_reply_to_user_id_str" : "10396",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779450212",
  "text" : "D&D First level magic spells that generally suck. I'm not a huge D&D player, but this is a riot. http:\/\/snurl.com\/22ydr",
  "id" : 779450212,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779452186",
  "text" : "does anyone actually find the 'mark as read' function in twhirl to be useful?",
  "id" : 779452186,
  "created_at" : "2008-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778961224",
  "text" : "Free parking pool led to an @ablissfulgal victory by forfeit. I did manage to get the blues however and 5 houses.",
  "id" : 778961224,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PoSmedley",
      "screen_name" : "PoSmedley",
      "indices" : [ 0, 10 ],
      "id_str" : "406996805",
      "id" : 406996805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778962462",
  "text" : "@PoSmedley Not in this house! Although I do admit, I haven't played a real game with auctions and without free parking in a while.",
  "id" : 778962462,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucretia M Pruitt",
      "screen_name" : "GeekMommy",
      "indices" : [ 0, 10 ],
      "id_str" : "14320218",
      "id" : 14320218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778956576",
  "geo" : { },
  "id_str" : "778963058",
  "in_reply_to_user_id" : 4303181,
  "text" : "@GeekMommy RE: silly woot items, so true. Sadly I succumbed to getting a memory card, but that's it for this one.",
  "id" : 778963058,
  "in_reply_to_status_id" : 778956576,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "LucretiaPruitt",
  "in_reply_to_user_id_str" : "4303181",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "infinitypro",
      "screen_name" : "infinitypro",
      "indices" : [ 0, 12 ],
      "id_str" : "15733409",
      "id" : 15733409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778956564",
  "geo" : { },
  "id_str" : "778963488",
  "in_reply_to_user_id" : 7705112,
  "text" : "@infinitypro Greetings! Always a pleasure to follow another alltopper. :)",
  "id" : 778963488,
  "in_reply_to_status_id" : 778956564,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "NEENZ",
  "in_reply_to_user_id_str" : "7705112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0413\u0440\u0430\u043D\u043E\u0432\u0441\u043A\u0430\u044F \u0422\u0430\u0442\u044C\u044F\u043D\u0430",
      "screen_name" : "anjrued",
      "indices" : [ 0, 8 ],
      "id_str" : "2836824647",
      "id" : 2836824647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778964470",
  "geo" : { },
  "id_str" : "778965021",
  "in_reply_to_user_id" : 860851,
  "text" : "@anjrued You won't get your jelly for at least a month, and they will deny that you were out of jelly in the first place.",
  "id" : 778965021,
  "in_reply_to_status_id" : 778964470,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewdobrow",
  "in_reply_to_user_id_str" : "860851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778965115",
  "geo" : { },
  "id_str" : "778965946",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee I turn it to ELEVEN.",
  "id" : 778965946,
  "in_reply_to_status_id" : 778965115,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Montgomery",
      "screen_name" : "Johnmont",
      "indices" : [ 0, 9 ],
      "id_str" : "2342251",
      "id" : 2342251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778966257",
  "geo" : { },
  "id_str" : "778967748",
  "in_reply_to_user_id" : 2342251,
  "text" : "@Johnmont As long it's not like Onion headlines, I'm ok with that.",
  "id" : 778967748,
  "in_reply_to_status_id" : 778966257,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "Johnmont",
  "in_reply_to_user_id_str" : "2342251",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778968800",
  "text" : "I really want to see Shatner pull out a phaser and vaporize someone during his crappy Priceline commericals.",
  "id" : 778968800,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0413\u0440\u0430\u043D\u043E\u0432\u0441\u043A\u0430\u044F \u0422\u0430\u0442\u044C\u044F\u043D\u0430",
      "screen_name" : "anjrued",
      "indices" : [ 0, 8 ],
      "id_str" : "2836824647",
      "id" : 2836824647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778968692",
  "geo" : { },
  "id_str" : "778968922",
  "in_reply_to_user_id" : 860851,
  "text" : "@anjrued AGREED. Even better are Nestle Crunch Eggs.",
  "id" : 778968922,
  "in_reply_to_status_id" : 778968692,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewdobrow",
  "in_reply_to_user_id_str" : "860851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778972817",
  "text" : "Age poll for twitter: http:\/\/is.gd\/3cE",
  "id" : 778972817,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778974366",
  "text" : "Watched The Soup for the first time, and it's a riot.",
  "id" : 778974366,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778973734",
  "geo" : { },
  "id_str" : "778974885",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee Sounds like you need to hire a personal assistant just for your social networks. XD",
  "id" : 778974885,
  "in_reply_to_status_id" : 778973734,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778975975",
  "geo" : { },
  "id_str" : "778976931",
  "in_reply_to_user_id" : 1388411,
  "text" : "@TheADOGuy It's like watching The Superficial blog on TV. Fantastic.",
  "id" : 778976931,
  "in_reply_to_status_id" : 778975975,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "ShawnWildermuth",
  "in_reply_to_user_id_str" : "1388411",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779142788",
  "text" : "Twitter...screensaver!? Now that's a neat idea. http:\/\/snurl.com\/22wsu",
  "id" : 779142788,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779145488",
  "text" : "Exceeding twhirl's limit in the first 10 minutes I'm awake = FAIL.",
  "id" : 779145488,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Zawinski",
      "screen_name" : "jwz",
      "indices" : [ 103, 107 ],
      "id_str" : "7190742",
      "id" : 7190742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779148986",
  "text" : "Code Rush documentary online! Awesome story about the programmers behind the Mozilla 1.0 release (like @jwz!) http:\/\/tinyurl.com\/2go759",
  "id" : 779148986,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779165303",
  "text" : "11 year old runs a school network by himself. Astounding. http:\/\/tinyurl.com\/2kupzx",
  "id" : 779165303,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CariElf",
      "screen_name" : "CariElf",
      "indices" : [ 0, 8 ],
      "id_str" : "14238116",
      "id" : 14238116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779166759",
  "geo" : { },
  "id_str" : "779168160",
  "in_reply_to_user_id" : 14238116,
  "text" : "@CariElf It's quite impressive! Reminds me of when I'd be fixing computers and TVs since no one else did in my elementary schools...",
  "id" : 779168160,
  "in_reply_to_status_id" : 779166759,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "CariElf",
  "in_reply_to_user_id_str" : "14238116",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 0, 7 ],
      "id_str" : "6118872",
      "id" : 6118872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779185590",
  "geo" : { },
  "id_str" : "779188129",
  "in_reply_to_user_id" : 6118872,
  "text" : "@zoomba I wish. Lows here tonight in Rochester are between 13-17 degrees.",
  "id" : 779188129,
  "in_reply_to_status_id" : 779185590,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "zoomba",
  "in_reply_to_user_id_str" : "6118872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779188667",
  "text" : "In the nice and quiet RIT library...I need to come here more often to get work done...",
  "id" : 779188667,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779189989",
  "text" : "WordPress 2.5 is out! http:\/\/wordpress.org\/",
  "id" : 779189989,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Owyang",
      "screen_name" : "jowyang",
      "indices" : [ 0, 8 ],
      "id_str" : "79543",
      "id" : 79543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779194714",
  "geo" : { },
  "id_str" : "779196283",
  "in_reply_to_user_id" : 79543,
  "text" : "@jowyang Goo Goo Dolls. being from buffalo I'm quite partial to them...",
  "id" : 779196283,
  "in_reply_to_status_id" : 779194714,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "jowyang",
  "in_reply_to_user_id_str" : "79543",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779202058",
  "text" : "I know being a well-rounded college student is a good thing and all, but I really hate liberal arts courses.",
  "id" : 779202058,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Devroe",
      "screen_name" : "cdevroe",
      "indices" : [ 0, 8 ],
      "id_str" : "11764",
      "id" : 11764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779251144",
  "geo" : { },
  "id_str" : "779251903",
  "in_reply_to_user_id" : 11764,
  "text" : "@cdevroe I'm going to be doing the same tonight...I think I need a new theme http:\/\/www.litanyagainstfear.com\/",
  "id" : 779251903,
  "in_reply_to_status_id" : 779251144,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "cdevroe",
  "in_reply_to_user_id_str" : "11764",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Starr",
      "screen_name" : "NickStarr",
      "indices" : [ 0, 10 ],
      "id_str" : "48933",
      "id" : 48933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779252901",
  "geo" : { },
  "id_str" : "779253200",
  "in_reply_to_user_id" : 48933,
  "text" : "@NickStarr Damn...now i'm worried about when I try mine tonight! I hope you've backed up your posts.",
  "id" : 779253200,
  "in_reply_to_status_id" : 779252901,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "NickStarr",
  "in_reply_to_user_id_str" : "48933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779255620",
  "text" : "Annie's mac and cheese is the REAL college student lunch food.",
  "id" : 779255620,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779265030",
  "text" : "The new Advance Wars game rocks. If you have a DS you need to get this game.",
  "id" : 779265030,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779267701",
  "geo" : { },
  "id_str" : "779270927",
  "in_reply_to_user_id" : 10058232,
  "text" : "@krisbjorkman I think they used to matter...now it seems that nothing on facebook really does",
  "id" : 779270927,
  "in_reply_to_status_id" : 779267701,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "kristophrrr",
  "in_reply_to_user_id_str" : "10058232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779272068",
  "text" : "Major cleaning spree time.",
  "id" : 779272068,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Flauaus",
      "screen_name" : "zachflauaus",
      "indices" : [ 0, 12 ],
      "id_str" : "6839272",
      "id" : 6839272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779274596",
  "geo" : { },
  "id_str" : "779275083",
  "in_reply_to_user_id" : 6839272,
  "text" : "@zachflauaus Dune, by Frank Herbert if you're into scifi.",
  "id" : 779275083,
  "in_reply_to_status_id" : 779274596,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "zachflauaus",
  "in_reply_to_user_id_str" : "6839272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779275525",
  "geo" : { },
  "id_str" : "779276670",
  "in_reply_to_user_id" : 10058232,
  "text" : "@krisbjorkman Best line of that movie: You failed me once again, Starscream. I'll watch the whole movie just for it.",
  "id" : 779276670,
  "in_reply_to_status_id" : 779275525,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "kristophrrr",
  "in_reply_to_user_id_str" : "10058232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Flauaus",
      "screen_name" : "zachflauaus",
      "indices" : [ 0, 12 ],
      "id_str" : "6839272",
      "id" : 6839272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779279374",
  "geo" : { },
  "id_str" : "779279598",
  "in_reply_to_user_id" : 6839272,
  "text" : "@zachflauaus It's worth it, believe me. I'm sure some would kill me for this comparsion, but it's the Lord of the Rings of sci-fi. Get it!",
  "id" : 779279598,
  "in_reply_to_status_id" : 779279374,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "zachflauaus",
  "in_reply_to_user_id_str" : "6839272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Flauaus",
      "screen_name" : "zachflauaus",
      "indices" : [ 0, 12 ],
      "id_str" : "6839272",
      "id" : 6839272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779281161",
  "geo" : { },
  "id_str" : "779281303",
  "in_reply_to_user_id" : 6839272,
  "text" : "@zachflauaus you want the first one, titled simply \"Dune\"",
  "id" : 779281303,
  "in_reply_to_status_id" : 779281161,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "zachflauaus",
  "in_reply_to_user_id_str" : "6839272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason",
      "screen_name" : "jesmith81",
      "indices" : [ 0, 10 ],
      "id_str" : "7775872",
      "id" : 7775872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779288271",
  "geo" : { },
  "id_str" : "779292920",
  "in_reply_to_user_id" : 7775872,
  "text" : "@jesmith81 Yeah, I'm still not done! This more like general apartment cleaning.",
  "id" : 779292920,
  "in_reply_to_status_id" : 779288271,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "jesmith81",
  "in_reply_to_user_id_str" : "7775872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779305017",
  "text" : "Done cleaning. Need to find another form of procrastination.",
  "id" : 779305017,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shashi Bellamkonda",
      "screen_name" : "shashib",
      "indices" : [ 0, 8 ],
      "id_str" : "1221471",
      "id" : 1221471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779308002",
  "geo" : { },
  "id_str" : "779310035",
  "in_reply_to_user_id" : 1221471,
  "text" : "@shashib It's a simple formula for most magazines. &lt;INSERT A\/B-LIST CELEBRITY HERE&gt; or &lt;INSERT OVERLY BUFF DUDE\/GIRL HERE&gt;",
  "id" : 779310035,
  "in_reply_to_status_id" : 779308002,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "shashib",
  "in_reply_to_user_id_str" : "1221471",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779319679",
  "text" : "Starting to work with Java\/JDBC and MySQL. Ugh.",
  "id" : 779319679,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779327227",
  "text" : "Wow. Getting JDBC set up was much easier than I thought it would be.",
  "id" : 779327227,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 69, 75 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779329927",
  "text" : "This is heinous. Hackers Assault Epilepsy Patients via Computer, via @wired. http:\/\/snurl.com\/22xtw",
  "id" : 779329927,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779374868",
  "text" : "Java's JDBC isn't that bad. Could be worse...it could be classic ASP.",
  "id" : 779374868,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778924178",
  "text" : "Monopoly time! Let's see if we can finish a game in under 4 hours. Or 3.",
  "id" : 778924178,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778944832",
  "text" : "Getting owned at monopoly. i just want boardwalk...is that so hard",
  "id" : 778944832,
  "created_at" : "2008-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778622195",
  "geo" : { },
  "id_str" : "778623492",
  "in_reply_to_user_id" : 10058232,
  "text" : "@krisbjorkman Do they have good milkshakes there? I've only heard that the burgers are a bit pricey...",
  "id" : 778623492,
  "in_reply_to_status_id" : 778622195,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "kristophrrr",
  "in_reply_to_user_id_str" : "10058232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778628970",
  "text" : "Windows Search 4.0 Preview is out, with plenty of fixes and speed enhancements. Upgrades the Vista search box. http:\/\/snurl.com\/22uc9",
  "id" : 778628970,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abacab",
      "screen_name" : "abacab",
      "indices" : [ 0, 7 ],
      "id_str" : "9767172",
      "id" : 9767172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778632195",
  "geo" : { },
  "id_str" : "778635071",
  "in_reply_to_user_id" : 9767172,
  "text" : "@abacab twitter is basically multiplayer notepad 2.0. (IRC is 1.0)",
  "id" : 778635071,
  "in_reply_to_status_id" : 778632195,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "abacab",
  "in_reply_to_user_id_str" : "9767172",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick O'Neill",
      "screen_name" : "biznickman",
      "indices" : [ 0, 11 ],
      "id_str" : "24944172",
      "id" : 24944172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778635195",
  "geo" : { },
  "id_str" : "778636431",
  "in_reply_to_user_id" : 965651,
  "text" : "@biznickman You're not alone.",
  "id" : 778636431,
  "in_reply_to_status_id" : 778635195,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "allnick",
  "in_reply_to_user_id_str" : "965651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WinCustomize.com",
      "screen_name" : "WinCustomize",
      "indices" : [ 74, 87 ],
      "id_str" : "14243974",
      "id" : 14243974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778637546",
  "text" : "A big welcome to my favorite Windows customization site on the interwebs, @wincustomize!",
  "id" : 778637546,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Hunt",
      "screen_name" : "missrogue",
      "indices" : [ 0, 10 ],
      "id_str" : "1192",
      "id" : 1192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778636412",
  "geo" : { },
  "id_str" : "778638156",
  "in_reply_to_user_id" : 1192,
  "text" : "@missrogue So what happens when Dvorak cries?",
  "id" : 778638156,
  "in_reply_to_status_id" : 778636412,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "missrogue",
  "in_reply_to_user_id_str" : "1192",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Starr",
      "screen_name" : "NickStarr",
      "indices" : [ 0, 10 ],
      "id_str" : "48933",
      "id" : 48933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778640638",
  "geo" : { },
  "id_str" : "778641770",
  "in_reply_to_user_id" : 48933,
  "text" : "@NickStarr Solution, lockable minifridge in your room.",
  "id" : 778641770,
  "in_reply_to_status_id" : 778640638,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "NickStarr",
  "in_reply_to_user_id_str" : "48933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Sliwinski",
      "screen_name" : "Tsliwi2000",
      "indices" : [ 0, 11 ],
      "id_str" : "10660522",
      "id" : 10660522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778641665",
  "geo" : { },
  "id_str" : "778644294",
  "in_reply_to_user_id" : 10660522,
  "text" : "@Tsliwi2000 And it's still snowing. I just want some real sunshine and clear skies...",
  "id" : 778644294,
  "in_reply_to_status_id" : 778641665,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Tsliwi2000",
  "in_reply_to_user_id_str" : "10660522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miffy balboa",
      "screen_name" : "Puddington",
      "indices" : [ 0, 11 ],
      "id_str" : "298414457",
      "id" : 298414457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778643240",
  "geo" : { },
  "id_str" : "778644859",
  "in_reply_to_user_id" : 2057591,
  "text" : "@Puddington Are you the gatekeeper?",
  "id" : 778644859,
  "in_reply_to_status_id" : 778643240,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "oneWillJ",
  "in_reply_to_user_id_str" : "2057591",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Starr",
      "screen_name" : "NickStarr",
      "indices" : [ 0, 10 ],
      "id_str" : "48933",
      "id" : 48933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778650334",
  "geo" : { },
  "id_str" : "778651064",
  "in_reply_to_user_id" : 48933,
  "text" : "@NickStarr I had a roommate like that too. Luckily he would rather lay in bed and play FFXI instead of moving around.",
  "id" : 778651064,
  "in_reply_to_status_id" : 778650334,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "NickStarr",
  "in_reply_to_user_id_str" : "48933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778631344",
  "geo" : { },
  "id_str" : "778652562",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee some wine-related news about my school you may find interesting http:\/\/www.rit.edu\/news\/?v=46047",
  "id" : 778652562,
  "in_reply_to_status_id" : 778631344,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778662335",
  "text" : "Just realized my twitter page name color was set to white. A tad hard to see on a white background.",
  "id" : 778662335,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778687349",
  "text" : "Definitely did not enjoy brushing 3-4 inches of snow off my car.",
  "id" : 778687349,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Roy",
      "screen_name" : "juliaroy",
      "indices" : [ 0, 9 ],
      "id_str" : "631583",
      "id" : 631583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778687391",
  "geo" : { },
  "id_str" : "778690329",
  "in_reply_to_user_id" : 631583,
  "text" : "@juliaroy there's a film school here at RIT, want some contacts?",
  "id" : 778690329,
  "in_reply_to_status_id" : 778687391,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "juliaroy",
  "in_reply_to_user_id_str" : "631583",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778696113",
  "geo" : { },
  "id_str" : "778700419",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense If I was still in Michigan, that sandwich would be consumed by now.",
  "id" : 778700419,
  "in_reply_to_status_id" : 778696113,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulsgildea",
      "screen_name" : "paulsgildea",
      "indices" : [ 0, 12 ],
      "id_str" : "14165478",
      "id" : 14165478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778700754",
  "geo" : { },
  "id_str" : "778702004",
  "in_reply_to_user_id" : 14165478,
  "text" : "@paulsgildea ouch! What happened?",
  "id" : 778702004,
  "in_reply_to_status_id" : 778700754,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "paulsgildea",
  "in_reply_to_user_id_str" : "14165478",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sol Young",
      "screen_name" : "sol",
      "indices" : [ 0, 4 ],
      "id_str" : "12649752",
      "id" : 12649752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778708969",
  "geo" : { },
  "id_str" : "778709346",
  "in_reply_to_user_id" : 12649752,
  "text" : "@sol The only thing you'll regret is not having more fries.",
  "id" : 778709346,
  "in_reply_to_status_id" : 778708969,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "sol",
  "in_reply_to_user_id_str" : "12649752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778715687",
  "text" : "Looks like Stardock lunch conversation is moving off IRC and onto Twitter. Not surprising, really.",
  "id" : 778715687,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snook",
      "screen_name" : "snookca",
      "indices" : [ 0, 8 ],
      "id_str" : "12591",
      "id" : 12591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778726263",
  "geo" : { },
  "id_str" : "778727829",
  "in_reply_to_user_id" : 12591,
  "text" : "@snookca please sharpie KISS on the usability bat\/stick\/pole",
  "id" : 778727829,
  "in_reply_to_status_id" : 778726263,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "snookca",
  "in_reply_to_user_id_str" : "12591",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778727255",
  "geo" : { },
  "id_str" : "778728108",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Think they'll bite? EA seems pretty adamant about this.",
  "id" : 778728108,
  "in_reply_to_status_id" : 778727255,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778730685",
  "geo" : { },
  "id_str" : "778735224",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee good advice! perhaps I can summarize in latin for you: tempus fugit, memento mori",
  "id" : 778735224,
  "in_reply_to_status_id" : 778730685,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778736201",
  "geo" : { },
  "id_str" : "778740459",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway Vageyena Man sightings, from that same page, just as funny: http:\/\/snurl.com\/22uxc",
  "id" : 778740459,
  "in_reply_to_status_id" : 778736201,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778753270",
  "geo" : { },
  "id_str" : "778757910",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense I used to watch this show all the time. I don't remember this one! how disturbing.",
  "id" : 778757910,
  "in_reply_to_status_id" : 778753270,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778765532",
  "text" : "Woot's yellow screen of death is not welcome during a woot-off.",
  "id" : 778765532,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucretia M Pruitt",
      "screen_name" : "GeekMommy",
      "indices" : [ 0, 10 ],
      "id_str" : "14320218",
      "id" : 14320218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778769856",
  "geo" : { },
  "id_str" : "778771492",
  "in_reply_to_user_id" : 4303181,
  "text" : "@GeekMommy you haven't been hunting for many bags of crap, have you? ;)",
  "id" : 778771492,
  "in_reply_to_status_id" : 778769856,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "LucretiaPruitt",
  "in_reply_to_user_id_str" : "4303181",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alesandro Ortiz",
      "screen_name" : "The_PHP_Jedi",
      "indices" : [ 0, 13 ],
      "id_str" : "1692901",
      "id" : 1692901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778772366",
  "geo" : { },
  "id_str" : "778773658",
  "in_reply_to_user_id" : 1692901,
  "text" : "@The_PHP_Jedi you're late to the party, been going on for at least a day now",
  "id" : 778773658,
  "in_reply_to_status_id" : 778772366,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "The_PHP_Jedi",
  "in_reply_to_user_id_str" : "1692901",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778772772",
  "geo" : { },
  "id_str" : "778774051",
  "in_reply_to_user_id" : 14152810,
  "text" : "@offwhitemke $.extend(\"awesome\");",
  "id" : 778774051,
  "in_reply_to_status_id" : 778772772,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "brennanMKE",
  "in_reply_to_user_id_str" : "14152810",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucretia M Pruitt",
      "screen_name" : "GeekMommy",
      "indices" : [ 0, 10 ],
      "id_str" : "14320218",
      "id" : 14320218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778776457",
  "geo" : { },
  "id_str" : "778777295",
  "in_reply_to_user_id" : 4303181,
  "text" : "@GeekMommy I got a Roomba in one a few months back. Best $1 I've ever spent.",
  "id" : 778777295,
  "in_reply_to_status_id" : 778776457,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "LucretiaPruitt",
  "in_reply_to_user_id_str" : "4303181",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778780412",
  "text" : "Hurray! Woot is back. Penny Arcade seems hosed still though.",
  "id" : 778780412,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778781940",
  "text" : "Opera is like the overachiever in class that everyone despises and has no friends. Opera dev builds pass Acid3 test: http:\/\/snurl.com\/22v5i",
  "id" : 778781940,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778784144",
  "geo" : { },
  "id_str" : "778785980",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense All I can think of is this comment in regards to IE: hurr IMA BROWSARRRR http:\/\/snurl.com\/22v6p",
  "id" : 778785980,
  "in_reply_to_status_id" : 778784144,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778753333",
  "geo" : { },
  "id_str" : "778788081",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror your twitter page name color is white, hard to see on a white background. fyi",
  "id" : 778788081,
  "in_reply_to_status_id" : 778753333,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zubaz",
      "screen_name" : "zubaz",
      "indices" : [ 0, 6 ],
      "id_str" : "14243440",
      "id" : 14243440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778794025",
  "geo" : { },
  "id_str" : "778794664",
  "in_reply_to_user_id" : 14243440,
  "text" : "@zubaz You're a sad, sad man. At least you didn't say Seamonkey.",
  "id" : 778794664,
  "in_reply_to_status_id" : 778794025,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "zubaz",
  "in_reply_to_user_id_str" : "14243440",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778798841",
  "text" : "Does it not snow frequently in Seattle? Because if not, western\/central NY has plenty here that we could ship off to those interested",
  "id" : 778798841,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobasoft",
      "screen_name" : "mobasoft",
      "indices" : [ 0, 9 ],
      "id_str" : "144751909",
      "id" : 144751909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778803967",
  "text" : "@Mobasoft Good advice for most professional communications. XD",
  "id" : 778803967,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778803893",
  "geo" : { },
  "id_str" : "778805335",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob yes but I've been noticing many from seattle\/WA twittering about the snow. i grew up in buffalo so it's not a huge deal for me ;)",
  "id" : 778805335,
  "in_reply_to_status_id" : 778803893,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778806490",
  "geo" : { },
  "id_str" : "778807614",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob I couldn't imagine winter without it!",
  "id" : 778807614,
  "in_reply_to_status_id" : 778806490,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Gilbert",
      "screen_name" : "zackgilbert",
      "indices" : [ 0, 12 ],
      "id_str" : "822454",
      "id" : 822454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778816080",
  "geo" : { },
  "id_str" : "778818700",
  "in_reply_to_user_id" : 822454,
  "text" : "@zackgilbert hey sounds like Silverlight!",
  "id" : 778818700,
  "in_reply_to_status_id" : 778816080,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "zackgilbert",
  "in_reply_to_user_id_str" : "822454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Starr",
      "screen_name" : "NickStarr",
      "indices" : [ 0, 10 ],
      "id_str" : "48933",
      "id" : 48933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778827058",
  "geo" : { },
  "id_str" : "778828225",
  "in_reply_to_user_id" : 48933,
  "text" : "@NickStarr You can sign up for the free version, it's got most of the features that BaseCamp has, but only one project and company.",
  "id" : 778828225,
  "in_reply_to_status_id" : 778827058,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "NickStarr",
  "in_reply_to_user_id_str" : "48933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alesandro Ortiz",
      "screen_name" : "The_PHP_Jedi",
      "indices" : [ 11, 24 ],
      "id_str" : "1692901",
      "id" : 1692901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778831543",
  "text" : "Retweeting @The_PHP_Jedi: What does the red button do at a gas station? http:\/\/tinyurl.com\/3cbgod This is classic.",
  "id" : 778831543,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Carvin",
      "screen_name" : "acarvin",
      "indices" : [ 0, 8 ],
      "id_str" : "778057",
      "id" : 778057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778832399",
  "geo" : { },
  "id_str" : "778834288",
  "in_reply_to_user_id" : 778057,
  "text" : "@acarvin Did they actually finish the whole movie yet? Last time I saw it, it was only the first few minutes",
  "id" : 778834288,
  "in_reply_to_status_id" : 778832399,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "acarvin",
  "in_reply_to_user_id_str" : "778057",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wm. Lee Williams",
      "screen_name" : "WmLee",
      "indices" : [ 0, 6 ],
      "id_str" : "14219412",
      "id" : 14219412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778837965",
  "geo" : { },
  "id_str" : "778840381",
  "in_reply_to_user_id" : 14219412,
  "text" : "@WmLee Yeah, I could imagine! You'd think there would be a huge warning label above that button...or perhaps people are just dumb.",
  "id" : 778840381,
  "in_reply_to_status_id" : 778837965,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "WmLee",
  "in_reply_to_user_id_str" : "14219412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Brogan",
      "screen_name" : "chrisbrogan",
      "indices" : [ 0, 12 ],
      "id_str" : "10202",
      "id" : 10202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778839897",
  "geo" : { },
  "id_str" : "778841113",
  "in_reply_to_user_id" : 10202,
  "text" : "@chrisbrogan You've missed me! Always happy to follow a fellow alltopper.",
  "id" : 778841113,
  "in_reply_to_status_id" : 778839897,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "chrisbrogan",
  "in_reply_to_user_id_str" : "10202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778845752",
  "text" : "Genociding this bag of baby goldfish that @ablissfulgal left me. Remorse? I have none.",
  "id" : 778845752,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 27, 32 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778849095",
  "text" : "Bought the 2gig SD card on @woot for $11 in hopes they'll put a new item up soon.",
  "id" : 778849095,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "steelopus",
      "screen_name" : "steelopus",
      "indices" : [ 0, 10 ],
      "id_str" : "6902732",
      "id" : 6902732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778851450",
  "geo" : { },
  "id_str" : "778852150",
  "in_reply_to_user_id" : 6902732,
  "text" : "@steelopus Base price for the card was $5.99....was yours with shipping included?",
  "id" : 778852150,
  "in_reply_to_status_id" : 778851450,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "steelopus",
  "in_reply_to_user_id_str" : "6902732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778860720",
  "text" : "Cleaning this disgusting apartment. It's about damn time.",
  "id" : 778860720,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 11, 16 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778863224",
  "text" : "Here's how @woot works: WEBCAM, WEBCAM, OVERPRICED REFURB, BLUETOOTH GADGET, ROOMBA, WEBCAM BAG OF CRAP, SERVER CRASH,  WEBCAM",
  "id" : 778863224,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : " Jake McKee",
      "screen_name" : "jakemckee",
      "indices" : [ 0, 10 ],
      "id_str" : "734343",
      "id" : 734343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778286709",
  "geo" : { },
  "id_str" : "778288306",
  "in_reply_to_user_id" : 734343,
  "text" : "@jakemckee .NET apps can look much sexier...perhaps you're working mostly with older MFC\/COM based apps?",
  "id" : 778288306,
  "in_reply_to_status_id" : 778286709,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "jakemckee",
  "in_reply_to_user_id_str" : "734343",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jim halligan",
      "screen_name" : "jimCTC",
      "indices" : [ 0, 7 ],
      "id_str" : "15122455",
      "id" : 15122455
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778300982",
  "geo" : { },
  "id_str" : "778302278",
  "in_reply_to_user_id" : 10143482,
  "text" : "@jimCTC if you have any rush albums, i'll buy them off ya ;)",
  "id" : 778302278,
  "in_reply_to_status_id" : 778300982,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "jim",
  "in_reply_to_user_id_str" : "10143482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778302742",
  "text" : "Spicy baconator pizza now in the oven. mmm tasty.",
  "id" : 778302742,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778315781",
  "text" : "Pizza turned out great! Except now I feel like I need sleep.",
  "id" : 778315781,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778328800",
  "text" : "Clearing the numerous events in Brawl...man there's a ton of them.",
  "id" : 778328800,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778323292",
  "geo" : { },
  "id_str" : "778328937",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Only because it was 100% DELICIOUS.",
  "id" : 778328937,
  "in_reply_to_status_id" : 778323292,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alesandro Ortiz",
      "screen_name" : "The_PHP_Jedi",
      "indices" : [ 0, 13 ],
      "id_str" : "1692901",
      "id" : 1692901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778338050",
  "geo" : { },
  "id_str" : "778338840",
  "in_reply_to_user_id" : 1692901,
  "text" : "@The_PHP_Jedi Another governor? Now who?",
  "id" : 778338840,
  "in_reply_to_status_id" : 778338050,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "The_PHP_Jedi",
  "in_reply_to_user_id_str" : "1692901",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0413\u0440\u0430\u043D\u043E\u0432\u0441\u043A\u0430\u044F \u0422\u0430\u0442\u044C\u044F\u043D\u0430",
      "screen_name" : "anjrued",
      "indices" : [ 0, 8 ],
      "id_str" : "2836824647",
      "id" : 2836824647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778343977",
  "geo" : { },
  "id_str" : "778344455",
  "in_reply_to_user_id" : 860851,
  "text" : "@anjrued It's because you're one of the twitterati: http:\/\/twitter.alltop.com",
  "id" : 778344455,
  "in_reply_to_status_id" : 778343977,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewdobrow",
  "in_reply_to_user_id_str" : "860851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Kallen",
      "screen_name" : "spidaman",
      "indices" : [ 0, 9 ],
      "id_str" : "68153",
      "id" : 68153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778345851",
  "geo" : { },
  "id_str" : "778346640",
  "in_reply_to_user_id" : 68153,
  "text" : "@spidaman Think it's worth it to jump to 2.5 yet?",
  "id" : 778346640,
  "in_reply_to_status_id" : 778345851,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "spidaman",
  "in_reply_to_user_id_str" : "68153",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 0, 5 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778348313",
  "geo" : { },
  "id_str" : "778349803",
  "in_reply_to_user_id" : 1183041,
  "text" : "@wilw Wicked sick! What difficulty?",
  "id" : 778349803,
  "in_reply_to_status_id" : 778348313,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "wilw",
  "in_reply_to_user_id_str" : "1183041",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778354948",
  "text" : "Watching Ace of Cakes makes me hungry for ice cream. Or a milkshake. Or a cake.",
  "id" : 778354948,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778361229",
  "text" : "Blogged: Rock band rocks. http:\/\/snurl.com\/22sw2",
  "id" : 778361229,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 0, 7 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778361531",
  "geo" : { },
  "id_str" : "778361815",
  "in_reply_to_user_id" : 38003,
  "text" : "@gedeon Hi there! I'm a fellow RITsian as well, glad to see more on twitter :)",
  "id" : 778361815,
  "in_reply_to_status_id" : 778361531,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "gedeon",
  "in_reply_to_user_id_str" : "38003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Flauaus",
      "screen_name" : "zachflauaus",
      "indices" : [ 0, 12 ],
      "id_str" : "6839272",
      "id" : 6839272
    }, {
      "name" : "\u0413\u0440\u0430\u043D\u043E\u0432\u0441\u043A\u0430\u044F \u0422\u0430\u0442\u044C\u044F\u043D\u0430",
      "screen_name" : "anjrued",
      "indices" : [ 36, 44 ],
      "id_str" : "2836824647",
      "id" : 2836824647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778362129",
  "geo" : { },
  "id_str" : "778363226",
  "in_reply_to_user_id" : 6839272,
  "text" : "@zachflauaus Heyo! Found ya through @anjrued.",
  "id" : 778363226,
  "in_reply_to_status_id" : 778362129,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "zachflauaus",
  "in_reply_to_user_id_str" : "6839272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 0, 7 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778363698",
  "geo" : { },
  "id_str" : "778365247",
  "in_reply_to_user_id" : 38003,
  "text" : "@gedeon Thanks! I tend to prefer Jim's Steakout subs from Buffalo however ;)",
  "id" : 778365247,
  "in_reply_to_status_id" : 778363698,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "gedeon",
  "in_reply_to_user_id_str" : "38003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 0, 7 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778366678",
  "geo" : { },
  "id_str" : "778368494",
  "in_reply_to_user_id" : 38003,
  "text" : "@gedeon Hah. I am a fan of garbage plates and DIno BBQ at least. I also have an unnatural love of icons\/OS customization as well ;)",
  "id" : 778368494,
  "in_reply_to_status_id" : 778366678,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "gedeon",
  "in_reply_to_user_id_str" : "38003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778371360",
  "text" : "A beautiful ode to coding: http:\/\/snurl.com\/22sxg",
  "id" : 778371360,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778540262",
  "geo" : { },
  "id_str" : "778540750",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog Which means it's not Saturday.",
  "id" : 778540750,
  "in_reply_to_status_id" : 778540262,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778541520",
  "text" : "Gray. Snow. Dim morning light. Ahh, Rochester.",
  "id" : 778541520,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Hoogenboom",
      "screen_name" : "Hoogenboom",
      "indices" : [ 0, 11 ],
      "id_str" : "12809952",
      "id" : 12809952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778542862",
  "geo" : { },
  "id_str" : "778543280",
  "in_reply_to_user_id" : 12809952,
  "text" : "@Hoogenboom The madness hasn't ended yet. Just don't steal my bag o' crap.",
  "id" : 778543280,
  "in_reply_to_status_id" : 778542862,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Hoogenboom",
  "in_reply_to_user_id_str" : "12809952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778540262",
  "geo" : { },
  "id_str" : "778543352",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog We really need a Stardock network for Facebook.",
  "id" : 778543352,
  "in_reply_to_status_id" : 778540262,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778544901",
  "geo" : { },
  "id_str" : "778545836",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog Submitted. I'll bug some others today about it.",
  "id" : 778545836,
  "in_reply_to_status_id" : 778544901,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778547385",
  "geo" : { },
  "id_str" : "778547882",
  "in_reply_to_user_id" : 11204662,
  "text" : "@tw3nty3ight Fridays are inherently unproductive.",
  "id" : 778547882,
  "in_reply_to_status_id" : 778547385,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "F3SportsCards",
  "in_reply_to_user_id_str" : "11204662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778556763",
  "text" : "There's something extremely satisfying in pressing the \"Delete all Spam Messages Now\" button in GMail.",
  "id" : 778556763,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaine Mata",
      "screen_name" : "shaine",
      "indices" : [ 0, 7 ],
      "id_str" : "871631",
      "id" : 871631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778557437",
  "geo" : { },
  "id_str" : "778558568",
  "in_reply_to_user_id" : 871631,
  "text" : "@shaine Sounds tastier than the pumpkin flax plus crunch cereal i'm monging on now. Probably cheaper too.",
  "id" : 778558568,
  "in_reply_to_status_id" : 778557437,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "shaine",
  "in_reply_to_user_id_str" : "871631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0413\u0440\u0430\u043D\u043E\u0432\u0441\u043A\u0430\u044F \u0422\u0430\u0442\u044C\u044F\u043D\u0430",
      "screen_name" : "anjrued",
      "indices" : [ 0, 8 ],
      "id_str" : "2836824647",
      "id" : 2836824647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778559787",
  "geo" : { },
  "id_str" : "778561054",
  "in_reply_to_user_id" : 860851,
  "text" : "@anjrued So does Monopoly brainwash us into becoming ravenous consumers or greedy corporate pigs?",
  "id" : 778561054,
  "in_reply_to_status_id" : 778559787,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewdobrow",
  "in_reply_to_user_id_str" : "860851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aaron brazell",
      "screen_name" : "technosailor",
      "indices" : [ 0, 13 ],
      "id_str" : "789158",
      "id" : 789158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778560965",
  "geo" : { },
  "id_str" : "778562206",
  "in_reply_to_user_id" : 789158,
  "text" : "@technosailor As long as you're not flying the plane!",
  "id" : 778562206,
  "in_reply_to_status_id" : 778560965,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "technosailor",
  "in_reply_to_user_id_str" : "789158",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaine Mata",
      "screen_name" : "shaine",
      "indices" : [ 0, 7 ],
      "id_str" : "871631",
      "id" : 871631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778570689",
  "geo" : { },
  "id_str" : "778572620",
  "in_reply_to_user_id" : 871631,
  "text" : "@shaine helped me lose around 50 pounds this summer, I don't plan on stopping. It's not that bad, just a tad expensive.",
  "id" : 778572620,
  "in_reply_to_status_id" : 778570689,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "shaine",
  "in_reply_to_user_id_str" : "871631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaine Mata",
      "screen_name" : "shaine",
      "indices" : [ 0, 7 ],
      "id_str" : "871631",
      "id" : 871631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778574411",
  "geo" : { },
  "id_str" : "778576366",
  "in_reply_to_user_id" : 871631,
  "text" : "@shaine It won't have as many omega 3's, that's what flax is good for ;)",
  "id" : 778576366,
  "in_reply_to_status_id" : 778574411,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "shaine",
  "in_reply_to_user_id_str" : "871631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zubaz",
      "screen_name" : "zubaz",
      "indices" : [ 19, 25 ],
      "id_str" : "14243440",
      "id" : 14243440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778577198",
  "text" : "Welcome to twitter @zubaz! About time!",
  "id" : 778577198,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778583199",
  "text" : "Gasp! Server error on Penny Arcade makes for a sad friday morning.",
  "id" : 778583199,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 11, 18 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778584017",
  "text" : "Retweeting @elvo86: OFFICIAL PETITION TO MAKE THE SNOW GO AWAY (copy and repost to sign)",
  "id" : 778584017,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Zehnder Rossi",
      "screen_name" : "shawnz",
      "indices" : [ 0, 7 ],
      "id_str" : "7789282",
      "id" : 7789282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778586148",
  "geo" : { },
  "id_str" : "778588066",
  "in_reply_to_user_id" : 7789282,
  "text" : "@shawnz Happy Friday to you too! Definitely not Saturday yet though :[",
  "id" : 778588066,
  "in_reply_to_status_id" : 778586148,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "shawnz",
  "in_reply_to_user_id_str" : "7789282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zubaz",
      "screen_name" : "zubaz",
      "indices" : [ 0, 6 ],
      "id_str" : "14243440",
      "id" : 14243440
    }, {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 26, 35 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778586578",
  "geo" : { },
  "id_str" : "778588410",
  "in_reply_to_user_id" : 14243440,
  "text" : "@zubaz Oh I'm well aware. @mittense may actually kill me for bringing him here.",
  "id" : 778588410,
  "in_reply_to_status_id" : 778586578,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "zubaz",
  "in_reply_to_user_id_str" : "14243440",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zubaz",
      "screen_name" : "zubaz",
      "indices" : [ 0, 6 ],
      "id_str" : "14243440",
      "id" : 14243440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778591492",
  "geo" : { },
  "id_str" : "778592387",
  "in_reply_to_user_id" : 14243440,
  "text" : "@zubaz JoeUser has a destroy account button just for that purpose. &gt;:-)",
  "id" : 778592387,
  "in_reply_to_status_id" : 778591492,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "zubaz",
  "in_reply_to_user_id_str" : "14243440",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CarrieP",
      "screen_name" : "CarrieP",
      "indices" : [ 0, 8 ],
      "id_str" : "10266282",
      "id" : 10266282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778593523",
  "geo" : { },
  "id_str" : "778593933",
  "in_reply_to_user_id" : 10266282,
  "text" : "@CarrieP There's snow here in NY too. I think mother nature just hates the Northeast.",
  "id" : 778593933,
  "in_reply_to_status_id" : 778593523,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "CarrieP",
  "in_reply_to_user_id_str" : "10266282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778598379",
  "geo" : { },
  "id_str" : "778602382",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense I KNOW WHO YOU ARE! AND WHERE YOU LIVE!",
  "id" : 778602382,
  "in_reply_to_status_id" : 778598379,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allan branch",
      "screen_name" : "lessallan",
      "indices" : [ 0, 10 ],
      "id_str" : "18058252",
      "id" : 18058252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778603851",
  "geo" : { },
  "id_str" : "778604753",
  "in_reply_to_user_id" : 6183972,
  "text" : "@lessallan They really don't let up, do they.",
  "id" : 778604753,
  "in_reply_to_status_id" : 778603851,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "allanbranch",
  "in_reply_to_user_id_str" : "6183972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778607797",
  "text" : "Only those who strongly believe in rebirth should risk going near. http:\/\/snurl.com\/22u54",
  "id" : 778607797,
  "created_at" : "2008-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778241810",
  "text" : "Thursdays suck, mostly because they're not Fridays.",
  "id" : 778241810,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778243154",
  "geo" : { },
  "id_str" : "778245208",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco Seemed to happen to me a lot as well. Murphy's law.",
  "id" : 778245208,
  "in_reply_to_status_id" : 778243154,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778249546",
  "text" : "Pizza time! ...once I make it.",
  "id" : 778249546,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778258191",
  "geo" : { },
  "id_str" : "778260438",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog Police helicopters look a lot meaner now.",
  "id" : 778260438,
  "in_reply_to_status_id" : 778258191,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "trillian1117",
      "indices" : [ 0, 13 ],
      "id_str" : "4220781",
      "id" : 4220781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778268053",
  "geo" : { },
  "id_str" : "778268547",
  "in_reply_to_user_id" : 4220781,
  "text" : "@trillian1117 And also gray. Dontcha love Rochester?",
  "id" : 778268547,
  "in_reply_to_status_id" : 778268053,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "trillian1117",
  "in_reply_to_user_id_str" : "4220781",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778270646",
  "text" : "Coming back to Reddit after 2 weeks of blocking it, and I'm still logged in. Creepy.",
  "id" : 778270646,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twhirl Announce",
      "screen_name" : "twhirl",
      "indices" : [ 0, 7 ],
      "id_str" : "9993542",
      "id" : 9993542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778272278",
  "geo" : { },
  "id_str" : "778273994",
  "in_reply_to_user_id" : 9993542,
  "text" : "@twhirl I'm on XP, but it worked the same way. Here's a post about getting to the same options window in XP: http:\/\/snurl.com\/22sjq",
  "id" : 778273994,
  "in_reply_to_status_id" : 778272278,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "twhirl",
  "in_reply_to_user_id_str" : "9993542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778269968",
  "geo" : { },
  "id_str" : "778274169",
  "in_reply_to_user_id" : 14152810,
  "text" : "@offwhitemke http:\/\/www.twhirl.org is pretty kickass.",
  "id" : 778274169,
  "in_reply_to_status_id" : 778269968,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "brennanMKE",
  "in_reply_to_user_id_str" : "14152810",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Curl",
      "screen_name" : "patrickcurl",
      "indices" : [ 0, 12 ],
      "id_str" : "5644892",
      "id" : 5644892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778275914",
  "geo" : { },
  "id_str" : "778277163",
  "in_reply_to_user_id" : 5644892,
  "text" : "@patrickcurl Not sure if I agree with the 'fake it' part. That makes it seem like you're trying too hard to fit in. Decent ideas though.",
  "id" : 778277163,
  "in_reply_to_status_id" : 778275914,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "patrickcurl",
  "in_reply_to_user_id_str" : "5644892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778281533",
  "text" : "They're demolishing one of the buildings at my high school. Supposedly I had my freshman year homeroom here: http:\/\/snurl.com\/22skq",
  "id" : 778281533,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0413\u0440\u0430\u043D\u043E\u0432\u0441\u043A\u0430\u044F \u0422\u0430\u0442\u044C\u044F\u043D\u0430",
      "screen_name" : "anjrued",
      "indices" : [ 0, 8 ],
      "id_str" : "2836824647",
      "id" : 2836824647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778283698",
  "geo" : { },
  "id_str" : "778283759",
  "in_reply_to_user_id" : 860851,
  "text" : "@anjrued Either that or it got hit by a bomb",
  "id" : 778283759,
  "in_reply_to_status_id" : 778283698,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewdobrow",
  "in_reply_to_user_id_str" : "860851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778021382",
  "geo" : { },
  "id_str" : "778021659",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob Yeah, I need to start working out again...went from 215 to 165 over the summer but haven't done much else since.",
  "id" : 778021659,
  "in_reply_to_status_id" : 778021382,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778022713",
  "text" : "I really hate 2 hour lectures that professors don't give students a break. Think about the people you're talking to, please.",
  "id" : 778022713,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778021382",
  "geo" : { },
  "id_str" : "778024125",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob It's a woot-off. New items are put up as they sell out, usually there's a fabled bag of crap during these as well.",
  "id" : 778024125,
  "in_reply_to_status_id" : 778021382,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778024780",
  "geo" : { },
  "id_str" : "778026958",
  "in_reply_to_user_id" : 5744442,
  "text" : "@ablissfulgal Perhaps you need some POWERTHIRST. So you can kick Mother Nature in the face with your ENERGY LEGS.",
  "id" : 778026958,
  "in_reply_to_status_id" : 778024780,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778033269",
  "text" : "Blizzard says WoW bot creator earned $2.8 million. Damn, that's a lot of cash just for gold. http:\/\/snurl.com\/22r4v",
  "id" : 778033269,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 35, 40 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778033896",
  "text" : "Getting sick of the webcams on the @woot -off. This is the 3rd one in the last hour.",
  "id" : 778033896,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778038904",
  "geo" : { },
  "id_str" : "778041794",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog I barely can fill my 200GB drive. Maybe I need to be more of a pirate. :P",
  "id" : 778041794,
  "in_reply_to_status_id" : 778038904,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778098462",
  "text" : "No internet during my last class = twitter withdrawal",
  "id" : 778098462,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778099163",
  "text" : "Time Warner fixed my home interwebs quite fast...which means I can work from home. Oh darn.",
  "id" : 778099163,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778098934",
  "geo" : { },
  "id_str" : "778103114",
  "in_reply_to_user_id" : 10058232,
  "text" : "@krisbjorkman There was a network, but I couldn't get on the DHCP server for some reason. Fail.",
  "id" : 778103114,
  "in_reply_to_status_id" : 778098934,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "kristophrrr",
  "in_reply_to_user_id_str" : "10058232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brainwashcamp",
      "indices" : [ 3, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778103382",
  "text" : "is #brainwashcamp still active?",
  "id" : 778103382,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trish",
      "screen_name" : "Dayngr",
      "indices" : [ 0, 7 ],
      "id_str" : "5920872",
      "id" : 5920872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778103346",
  "geo" : { },
  "id_str" : "778105576",
  "in_reply_to_user_id" : 5920872,
  "text" : "@Dayngr I think I prefer \"twits\" rather than \"tweeties\". ;)",
  "id" : 778105576,
  "in_reply_to_status_id" : 778103346,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Dayngr",
  "in_reply_to_user_id_str" : "5920872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778105383",
  "geo" : { },
  "id_str" : "778107338",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman I think that's a tough comparsion and it really depends on the local area and businesses.",
  "id" : 778107338,
  "in_reply_to_status_id" : 778105383,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778107842",
  "geo" : { },
  "id_str" : "778108497",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror what if public logs are kept of the channel? I know some freenode channels do have bots just for that.",
  "id" : 778108497,
  "in_reply_to_status_id" : 778107842,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778110399",
  "text" : "Signing my life away for the summer...",
  "id" : 778110399,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778112191",
  "text" : "Hey look, it's World of Warhammer. Craft. Online. http:\/\/snurl.com\/22rm2",
  "id" : 778112191,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tantek \u00C7elik",
      "screen_name" : "t",
      "indices" : [ 0, 2 ],
      "id_str" : "11628",
      "id" : 11628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778111910",
  "geo" : { },
  "id_str" : "778112646",
  "in_reply_to_user_id" : 11628,
  "text" : "@t That's hilarious. Could spawn an entire new meme: loltrebuchets.",
  "id" : 778112646,
  "in_reply_to_status_id" : 778111910,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "t",
  "in_reply_to_user_id_str" : "11628",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778115086",
  "text" : "Shacknews Replay Couch #19, always good for some video game hilarity: http:\/\/snurl.com\/22rmn",
  "id" : 778115086,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778117853",
  "text" : "what exactly does the pound sign do in tweets? It looks like a link to something",
  "id" : 778117853,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778118278",
  "text" : "Only in Japan: Pink Windows Vista. http:\/\/snurl.com\/22rnh",
  "id" : 778118278,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trish",
      "screen_name" : "Dayngr",
      "indices" : [ 0, 7 ],
      "id_str" : "5920872",
      "id" : 5920872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778112018",
  "geo" : { },
  "id_str" : "778118937",
  "in_reply_to_user_id" : 5920872,
  "text" : "@Dayngr I think even @ablissfulgal would prefer to call me a twit ;)",
  "id" : 778118937,
  "in_reply_to_status_id" : 778112018,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Dayngr",
  "in_reply_to_user_id_str" : "5920872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Elder",
      "screen_name" : "keithelder",
      "indices" : [ 72, 83 ],
      "id_str" : "6136542",
      "id" : 6136542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778123093",
  "text" : "Great ammo for those looking to convince friends to use Twitter. Thanks @keithelder! http:\/\/snurl.com\/22rof",
  "id" : 778123093,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Jones",
      "screen_name" : "smalljones",
      "indices" : [ 0, 11 ],
      "id_str" : "11726",
      "id" : 11726
    }, {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 12, 21 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778124454",
  "geo" : { },
  "id_str" : "778125597",
  "in_reply_to_user_id" : 11726,
  "text" : "@smalljones @pilotbob Thanks! It's not entirely obvious to newcomers, sadly.",
  "id" : 778125597,
  "in_reply_to_status_id" : 778124454,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "smalljones",
  "in_reply_to_user_id_str" : "11726",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Reynolds",
      "screen_name" : "scottcreynolds",
      "indices" : [ 0, 15 ],
      "id_str" : "441985676",
      "id" : 441985676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778136723",
  "text" : "@scottcreynolds hay everybady! (and thanks for following me!)",
  "id" : 778136723,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 17, 26 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778143337",
  "text" : "Everyone welcome @mittense to twitter, gamedev.net moderator, blogger, and fellow video game addict.",
  "id" : 778143337,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778143130",
  "geo" : { },
  "id_str" : "778145562",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman Start the presentation with a linux desktop environment, say it's your side job",
  "id" : 778145562,
  "in_reply_to_status_id" : 778143130,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 0, 7 ],
      "id_str" : "6118872",
      "id" : 6118872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778145612",
  "geo" : { },
  "id_str" : "778146978",
  "in_reply_to_user_id" : 6118872,
  "text" : "@zoomba Try it out for a bit, follow some of the twitterati at http:\/\/twitter.alltop.com\/",
  "id" : 778146978,
  "in_reply_to_status_id" : 778145612,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "zoomba",
  "in_reply_to_user_id_str" : "6118872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778151055",
  "geo" : { },
  "id_str" : "778151941",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog And now only 4 hours to edit it!",
  "id" : 778151941,
  "in_reply_to_status_id" : 778151055,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Starr",
      "screen_name" : "NickStarr",
      "indices" : [ 0, 10 ],
      "id_str" : "48933",
      "id" : 48933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778149583",
  "geo" : { },
  "id_str" : "778152218",
  "in_reply_to_user_id" : 48933,
  "text" : "@NickStarr http:\/\/tweetstats.com\/ in ur tweets, graphin ur stats",
  "id" : 778152218,
  "in_reply_to_status_id" : 778149583,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "NickStarr",
  "in_reply_to_user_id_str" : "48933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778154079",
  "text" : "Dreading working with Java\/JDBC tonight, but looking forward to learning about Hibernate.",
  "id" : 778154079,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason",
      "screen_name" : "jesmith81",
      "indices" : [ 0, 10 ],
      "id_str" : "7775872",
      "id" : 7775872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778161364",
  "geo" : { },
  "id_str" : "778162261",
  "in_reply_to_user_id" : 7775872,
  "text" : "@jesmith81 I tend to do that on a weekly basis but my desk ends up full of crap anyway a day or two after",
  "id" : 778162261,
  "in_reply_to_status_id" : 778161364,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "jesmith81",
  "in_reply_to_user_id_str" : "7775872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778168377",
  "text" : "\"The crane was on top of the bridge preparing for bridge construction work when it fell through the overpass\"  Oops. http:\/\/snurl.com\/22rxx",
  "id" : 778168377,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CariElf",
      "screen_name" : "CariElf",
      "indices" : [ 20, 28 ],
      "id_str" : "14238116",
      "id" : 14238116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778169269",
  "text" : "Welcome to Twitter, @CariElf! :) try out twhirl for keeping this updated: http:\/\/www.twhirl.org\/",
  "id" : 778169269,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778170576",
  "geo" : { },
  "id_str" : "778171337",
  "in_reply_to_user_id" : 1388411,
  "text" : "@TheADOGuy At least this one didn't hurt anyone...it is causing traffic problems in Detroit now though",
  "id" : 778171337,
  "in_reply_to_status_id" : 778170576,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "ShawnWildermuth",
  "in_reply_to_user_id_str" : "1388411",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778174588",
  "text" : "Half of RIT's campus is without power right now. The nerds will actually have to talk to people now!",
  "id" : 778174588,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 26, 31 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778175947",
  "text" : "Another webcam. Seriously @woot. Something new plzkthx",
  "id" : 778175947,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K. Scott Allen",
      "screen_name" : "OdeToCode",
      "indices" : [ 0, 10 ],
      "id_str" : "13479972",
      "id" : 13479972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778180665",
  "geo" : { },
  "id_str" : "778184058",
  "in_reply_to_user_id" : 13479972,
  "text" : "@OdeToCode You're talking about 90% of VB developers, right?",
  "id" : 778184058,
  "in_reply_to_status_id" : 778180665,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "OdeToCode",
  "in_reply_to_user_id_str" : "13479972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 0, 7 ],
      "id_str" : "6118872",
      "id" : 6118872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778189415",
  "geo" : { },
  "id_str" : "778189949",
  "in_reply_to_user_id" : 6118872,
  "text" : "@zoomba Exactly! Now help spread it. :)",
  "id" : 778189949,
  "in_reply_to_status_id" : 778189415,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "zoomba",
  "in_reply_to_user_id_str" : "6118872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Nordquist",
      "screen_name" : "Akula",
      "indices" : [ 0, 6 ],
      "id_str" : "46363",
      "id" : 46363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778189257",
  "geo" : { },
  "id_str" : "778190903",
  "in_reply_to_user_id" : 46363,
  "text" : "@Akula Doorstops.",
  "id" : 778190903,
  "in_reply_to_status_id" : 778189257,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Akula",
  "in_reply_to_user_id_str" : "46363",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778187511",
  "geo" : { },
  "id_str" : "778193860",
  "in_reply_to_user_id" : 1388411,
  "text" : "@TheADOGuy I know, I'm kidding around. I'm actually more familiar with vb.net, but I love c# due to my java background.",
  "id" : 778193860,
  "in_reply_to_status_id" : 778187511,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "ShawnWildermuth",
  "in_reply_to_user_id_str" : "1388411",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mormegil",
      "screen_name" : "Mormegil",
      "indices" : [ 0, 9 ],
      "id_str" : "14165991",
      "id" : 14165991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778191415",
  "geo" : { },
  "id_str" : "778194473",
  "in_reply_to_user_id" : 14165991,
  "text" : "@Mormegil Yes, but also horribly boring. :)",
  "id" : 778194473,
  "in_reply_to_status_id" : 778191415,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Mormegil",
  "in_reply_to_user_id_str" : "14165991",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Jones",
      "screen_name" : "smalljones",
      "indices" : [ 0, 11 ],
      "id_str" : "11726",
      "id" : 11726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778199855",
  "geo" : { },
  "id_str" : "778199933",
  "in_reply_to_user_id" : 11726,
  "text" : "@smalljones You need to bang a huge gong for this kind of statement.",
  "id" : 778199933,
  "in_reply_to_status_id" : 778199855,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "smalljones",
  "in_reply_to_user_id_str" : "11726",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Kelly",
      "screen_name" : "inkedmn",
      "indices" : [ 0, 8 ],
      "id_str" : "2844098929",
      "id" : 2844098929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778201744",
  "geo" : { },
  "id_str" : "778203601",
  "in_reply_to_user_id" : 434883,
  "text" : "@inkedmn I love vim! Not using hjkl and ^B, ^F to browse text makes me feel gimped.",
  "id" : 778203601,
  "in_reply_to_status_id" : 778201744,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrbrettkelly",
  "in_reply_to_user_id_str" : "434883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twhirl Announce",
      "screen_name" : "twhirl",
      "indices" : [ 38, 45 ],
      "id_str" : "9993542",
      "id" : 9993542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778213482",
  "text" : "I can't seem to click links inside of @twhirl to open a web browser on XP. Any suggestions?",
  "id" : 778213482,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 0, 8 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778213574",
  "geo" : { },
  "id_str" : "778215048",
  "in_reply_to_user_id" : 752673,
  "text" : "@jeresig crappy microphone for the talk :( thanks for the link though!",
  "id" : 778215048,
  "in_reply_to_status_id" : 778213574,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "jeresig",
  "in_reply_to_user_id_str" : "752673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778211616",
  "geo" : { },
  "id_str" : "778215537",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense map&lt;fail, boat&gt; mymap;",
  "id" : 778215537,
  "in_reply_to_status_id" : 778211616,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778214994",
  "geo" : { },
  "id_str" : "778215831",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob Yep! I bet it's something funky with my system...",
  "id" : 778215831,
  "in_reply_to_status_id" : 778214994,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "steelopus",
      "screen_name" : "steelopus",
      "indices" : [ 0, 10 ],
      "id_str" : "6902732",
      "id" : 6902732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778214347",
  "geo" : { },
  "id_str" : "778215940",
  "in_reply_to_user_id" : 6902732,
  "text" : "@steelopus Joke. I'm a windows user at heart, I doubt that will ever change.",
  "id" : 778215940,
  "in_reply_to_status_id" : 778214347,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "steelopus",
  "in_reply_to_user_id_str" : "6902732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 35, 43 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778217435",
  "text" : "Wondering if I would have attended @jeresig's latest talk about Javascript\/jQuery if I went to Northeastern http:\/\/snurl.com\/22s85",
  "id" : 778217435,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GarrettAtreides",
      "screen_name" : "GarrettAtreides",
      "indices" : [ 0, 16 ],
      "id_str" : "8091602",
      "id" : 8091602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778220999",
  "geo" : { },
  "id_str" : "778222787",
  "in_reply_to_user_id" : 8091602,
  "text" : "@GarrettAtreides EFCS sucks. Although learning assembly is fun, circuits and whatnot is not.",
  "id" : 778222787,
  "in_reply_to_status_id" : 778220999,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "GarrettAtreides",
  "in_reply_to_user_id_str" : "8091602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777682172",
  "text" : "Hour 13 of consciousness today is brought to you by 2 extra strength tylenol",
  "id" : 777682172,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777681719",
  "geo" : { },
  "id_str" : "777684956",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman Great starting point for those looking to build social apps!",
  "id" : 777684956,
  "in_reply_to_status_id" : 777681719,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777686078",
  "text" : "For some reason I'm opting to kneel at my desk instead of sit down in my chair. Probably not good posture.",
  "id" : 777686078,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alesandro Ortiz",
      "screen_name" : "The_PHP_Jedi",
      "indices" : [ 0, 13 ],
      "id_str" : "1692901",
      "id" : 1692901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777686919",
  "geo" : { },
  "id_str" : "777689515",
  "in_reply_to_user_id" : 1692901,
  "text" : "@The_PHP_Jedi or better yet:http:\/\/snurl.com\/22mbq",
  "id" : 777689515,
  "in_reply_to_status_id" : 777686919,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "The_PHP_Jedi",
  "in_reply_to_user_id_str" : "1692901",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777687898",
  "geo" : { },
  "id_str" : "777689845",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco Planet Earth? And yes, Dr. David Attenborough's commentary is awesome.",
  "id" : 777689845,
  "in_reply_to_status_id" : 777687898,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777694024",
  "geo" : { },
  "id_str" : "777701659",
  "in_reply_to_user_id" : 14152810,
  "text" : "@offwhitemke Doesn't the asian guy during the vs2008 install have a really tiny face and freak you out? Or maybe I'm just strange.",
  "id" : 777701659,
  "in_reply_to_status_id" : 777694024,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "brennanMKE",
  "in_reply_to_user_id_str" : "14152810",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777704234",
  "text" : "Time to hack away with my raytracer again!",
  "id" : 777704234,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Kelly",
      "screen_name" : "inkedmn",
      "indices" : [ 0, 8 ],
      "id_str" : "2844098929",
      "id" : 2844098929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777704377",
  "geo" : { },
  "id_str" : "777706251",
  "in_reply_to_user_id" : 434883,
  "text" : "@inkedmn Me too! :D That's how I added you, actually you.I want to know how the algorithm works that decides who the twitterati are.",
  "id" : 777706251,
  "in_reply_to_status_id" : 777704377,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrbrettkelly",
  "in_reply_to_user_id_str" : "434883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Glazman",
      "screen_name" : "glazou",
      "indices" : [ 0, 7 ],
      "id_str" : "14231313",
      "id" : 14231313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777706833",
  "geo" : { },
  "id_str" : "777707640",
  "in_reply_to_user_id" : 14231313,
  "text" : "@glazou Welcome to twitter!",
  "id" : 777707640,
  "in_reply_to_status_id" : 777706833,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "glazou",
  "in_reply_to_user_id_str" : "14231313",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777711056",
  "text" : "some annie's mac and cheese is callilng my name",
  "id" : 777711056,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twhirl Announce",
      "screen_name" : "twhirl",
      "indices" : [ 16, 23 ],
      "id_str" : "9993542",
      "id" : 9993542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777712123",
  "text" : "For some reason @twhirl opens all links in IE for me even though my default browser is FF2.0 (on Vista). Anyone else experience this?",
  "id" : 777712123,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adele McAlear",
      "screen_name" : "AdeleMcAlear",
      "indices" : [ 0, 13 ],
      "id_str" : "5554222",
      "id" : 5554222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777712868",
  "geo" : { },
  "id_str" : "777714715",
  "in_reply_to_user_id" : 5554222,
  "text" : "@adelemcalear It's not just females suffering from headaches today. ;)",
  "id" : 777714715,
  "in_reply_to_status_id" : 777712868,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "AdeleMcAlear",
  "in_reply_to_user_id_str" : "5554222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Allen",
      "screen_name" : "steveswrong",
      "indices" : [ 0, 12 ],
      "id_str" : "14175623",
      "id" : 14175623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777714789",
  "geo" : { },
  "id_str" : "777714993",
  "in_reply_to_user_id" : 14175623,
  "text" : "@steveswrong oh snap, twitterroll",
  "id" : 777714993,
  "in_reply_to_status_id" : 777714789,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "steveswrong",
  "in_reply_to_user_id_str" : "14175623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777716281",
  "text" : "Teaching @ablissfulgal how to play NetHack. Do you want your possessions identified? (y\/n\/q)",
  "id" : 777716281,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Allen",
      "screen_name" : "steveswrong",
      "indices" : [ 0, 12 ],
      "id_str" : "14175623",
      "id" : 14175623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777715744",
  "geo" : { },
  "id_str" : "777716502",
  "in_reply_to_user_id" : 14175623,
  "text" : "@steveswrong sadly, I won scariest costume because of that fact",
  "id" : 777716502,
  "in_reply_to_status_id" : 777715744,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "steveswrong",
  "in_reply_to_user_id_str" : "14175623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Allen",
      "screen_name" : "steveswrong",
      "indices" : [ 0, 12 ],
      "id_str" : "14175623",
      "id" : 14175623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777718889",
  "geo" : { },
  "id_str" : "777721256",
  "in_reply_to_user_id" : 14175623,
  "text" : "@steveswrong Rush?",
  "id" : 777721256,
  "in_reply_to_status_id" : 777718889,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "steveswrong",
  "in_reply_to_user_id_str" : "14175623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Zeldman",
      "screen_name" : "zeldman",
      "indices" : [ 11, 19 ],
      "id_str" : "61133",
      "id" : 61133
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777722436",
  "text" : "Retweeting @zeldman: STOP IN THE NAME OF DESIGN. This needs to be a bumper sticker.",
  "id" : 777722436,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777725556",
  "text" : "When D&D plays YOU! This reminds me of the Dilbert board game. http:\/\/snurl.com\/22pkj",
  "id" : 777725556,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777736800",
  "text" : "C++ is hurting my brain.",
  "id" : 777736800,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777740249",
  "text" : "I has 2 spheres on my raytracer now!",
  "id" : 777740249,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Schwager",
      "screen_name" : "onlycodered",
      "indices" : [ 0, 12 ],
      "id_str" : "1622561",
      "id" : 1622561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777743644",
  "geo" : { },
  "id_str" : "777745819",
  "in_reply_to_user_id" : 1622561,
  "text" : "@onlycodered any screenshots?",
  "id" : 777745819,
  "in_reply_to_status_id" : 777743644,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "onlycodered",
  "in_reply_to_user_id_str" : "1622561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777755112",
  "text" : "Completely frustrated with ray-plane intersections and being awak since 7am doesn't help. Sleep.",
  "id" : 777755112,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777984984",
  "text" : "In my favorite class ever. So favorite that I probably won't pay attention.",
  "id" : 777984984,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Trinity",
      "screen_name" : "TheProkrammer",
      "indices" : [ 0, 14 ],
      "id_str" : "1454222514",
      "id" : 1454222514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777985419",
  "geo" : { },
  "id_str" : "777987168",
  "in_reply_to_user_id" : 458173,
  "text" : "@TheProkrammer Nice, not too expensive either.",
  "id" : 777987168,
  "in_reply_to_status_id" : 777985419,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mletterle",
  "in_reply_to_user_id_str" : "458173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777990162",
  "text" : "Professor shows up 8 minutes late to class. Let's see if he keeps us 8 minutes later. Prognosis: positive.",
  "id" : 777990162,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777990665",
  "text" : "How do you hold on to a girl? (warning, terribly creepy) http:\/\/snurl.com\/22qw2",
  "id" : 777990665,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just A Sun God",
      "screen_name" : "JustaSunGod",
      "indices" : [ 0, 12 ],
      "id_str" : "11390722",
      "id" : 11390722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777992354",
  "geo" : { },
  "id_str" : "777994493",
  "in_reply_to_user_id" : 11390722,
  "text" : "@JustaSunGod Perhaps because we prefer to talk online to relatively unknown people in under 140 chars? Or maybe he's just a dolt.",
  "id" : 777994493,
  "in_reply_to_status_id" : 777992354,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "JustaSunGod",
  "in_reply_to_user_id_str" : "11390722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777995274",
  "text" : "Lecture begins at 10:17. Wonderful.",
  "id" : 777995274,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Owyang",
      "screen_name" : "jowyang",
      "indices" : [ 0, 8 ],
      "id_str" : "79543",
      "id" : 79543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777996490",
  "geo" : { },
  "id_str" : "777998668",
  "in_reply_to_user_id" : 79543,
  "text" : "@jowyang I'm not on the bottom anymore! :D",
  "id" : 777998668,
  "in_reply_to_status_id" : 777996490,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "jowyang",
  "in_reply_to_user_id_str" : "79543",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 11, 16 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777999753",
  "text" : "Holy crap! @woot -off!",
  "id" : 777999753,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777999960",
  "text" : "This is what I get for going to bed early. Woot-off in progress! http:\/\/www.woot.com\/",
  "id" : 777999960,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778005452",
  "text" : "The Sims 3 Looks Rad: http:\/\/snurl.com\/22qyt",
  "id" : 778005452,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debra Hamel",
      "screen_name" : "debra_hamel",
      "indices" : [ 0, 12 ],
      "id_str" : "765942",
      "id" : 765942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778007626",
  "geo" : { },
  "id_str" : "778008946",
  "in_reply_to_user_id" : 765942,
  "text" : "@Debra_Hamel GMail's labels work out great for me. I have filters to apply labels, and anything I need is one search away.",
  "id" : 778008946,
  "in_reply_to_status_id" : 778007626,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "debra_hamel",
  "in_reply_to_user_id_str" : "765942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twhirl Announce",
      "screen_name" : "twhirl",
      "indices" : [ 0, 7 ],
      "id_str" : "9993542",
      "id" : 9993542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778010961",
  "geo" : { },
  "id_str" : "778011995",
  "in_reply_to_user_id" : 9993542,
  "text" : "@twhirl A suggestion: back button for when looking up profiles, etc to return to the Timeline. Keyboard shortcut or 4th mouse button maybe",
  "id" : 778011995,
  "in_reply_to_status_id" : 778010961,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "twhirl",
  "in_reply_to_user_id_str" : "9993542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debra Hamel",
      "screen_name" : "debra_hamel",
      "indices" : [ 0, 12 ],
      "id_str" : "765942",
      "id" : 765942
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 59, 67 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778010214",
  "geo" : { },
  "id_str" : "778013789",
  "in_reply_to_user_id" : 765942,
  "text" : "@Debra_Hamel Yeah, that's why filters help... i.e., i have @twitter.com emails hit with a Twitter label. To each his\/her own, I suppose.",
  "id" : 778013789,
  "in_reply_to_status_id" : 778010214,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "debra_hamel",
  "in_reply_to_user_id_str" : "765942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778014908",
  "geo" : { },
  "id_str" : "778015557",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob Thanks! That helps a lot.",
  "id" : 778015557,
  "in_reply_to_status_id" : 778014908,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snook",
      "screen_name" : "snookca",
      "indices" : [ 0, 8 ],
      "id_str" : "12591",
      "id" : 12591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778015160",
  "geo" : { },
  "id_str" : "778017359",
  "in_reply_to_user_id" : 12591,
  "text" : "@snookca Interesting...does ie8 quirks mode always return to IE6 rendering? Or am I missing the boat entirely here.",
  "id" : 778017359,
  "in_reply_to_status_id" : 778015160,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "snookca",
  "in_reply_to_user_id_str" : "12591",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777737015",
  "geo" : { },
  "id_str" : "778019339",
  "in_reply_to_user_id" : 5744442,
  "text" : "@ablissfulgal 's delicious omelette from this morning does not like me now.. Ham, cheese, red pepper flakes and frank's red hot = awesome.",
  "id" : 778019339,
  "in_reply_to_status_id" : 777737015,
  "created_at" : "2008-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Markman",
      "screen_name" : "Mickeleh",
      "indices" : [ 0, 9 ],
      "id_str" : "13413",
      "id" : 13413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777657742",
  "geo" : { },
  "id_str" : "777659620",
  "in_reply_to_user_id" : 13413,
  "text" : "@Mickeleh Hah, thanks. I dressed up as an engineer from Team Fortress 2 last Halloween: http:\/\/snurl.com\/22pas",
  "id" : 777659620,
  "in_reply_to_status_id" : 777657742,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Mickeleh",
  "in_reply_to_user_id_str" : "13413",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke",
      "screen_name" : "lukeawol",
      "indices" : [ 0, 9 ],
      "id_str" : "5351422",
      "id" : 5351422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777654663",
  "geo" : { },
  "id_str" : "777659917",
  "in_reply_to_user_id" : 5351422,
  "text" : "@lukeawol Good choice! Jay's sucks.",
  "id" : 777659917,
  "in_reply_to_status_id" : 777654663,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "lukeawol",
  "in_reply_to_user_id_str" : "5351422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777665094",
  "text" : "woot, got a job for the summer!",
  "id" : 777665094,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Kelly",
      "screen_name" : "inkedmn",
      "indices" : [ 0, 8 ],
      "id_str" : "2844098929",
      "id" : 2844098929
    }, {
      "name" : "TweetStats",
      "screen_name" : "TweetStats",
      "indices" : [ 99, 110 ],
      "id_str" : "11805432",
      "id" : 11805432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777667448",
  "geo" : { },
  "id_str" : "777667510",
  "in_reply_to_user_id" : 434883,
  "text" : "@inkedmn my daily average for DMs is pretty high simply because I like to send thank-yous. too bad @TweetStats is down for us to check. :[",
  "id" : 777667510,
  "in_reply_to_status_id" : 777667448,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrbrettkelly",
  "in_reply_to_user_id_str" : "434883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    }, {
      "name" : "Political Machine",
      "screen_name" : "Politic_Machine",
      "indices" : [ 55, 71 ],
      "id_str" : "13692432",
      "id" : 13692432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777561361",
  "geo" : { },
  "id_str" : "777668453",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog We definitely need a better background for  @politic_machine",
  "id" : 777668453,
  "in_reply_to_status_id" : 777561361,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Kelly",
      "screen_name" : "inkedmn",
      "indices" : [ 0, 8 ],
      "id_str" : "2844098929",
      "id" : 2844098929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777668634",
  "geo" : { },
  "id_str" : "777669038",
  "in_reply_to_user_id" : 434883,
  "text" : "@inkedmn Yeah, I wouldn't dare hook up twitter to my phone for that reason",
  "id" : 777669038,
  "in_reply_to_status_id" : 777668634,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrbrettkelly",
  "in_reply_to_user_id_str" : "434883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Winer \u262E",
      "screen_name" : "davewiner",
      "indices" : [ 0, 10 ],
      "id_str" : "3839",
      "id" : 3839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777669967",
  "geo" : { },
  "id_str" : "777670606",
  "in_reply_to_user_id" : 3839,
  "text" : "@davewiner Naming suggestion: squelch.",
  "id" : 777670606,
  "in_reply_to_status_id" : 777669967,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "davewiner",
  "in_reply_to_user_id_str" : "3839",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Zawinski",
      "screen_name" : "jwz",
      "indices" : [ 15, 19 ],
      "id_str" : "7190742",
      "id" : 7190742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777671907",
  "text" : "The (in)famous @jwz is on twitter.",
  "id" : 777671907,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777674604",
  "geo" : { },
  "id_str" : "777675629",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway Productivity = 0",
  "id" : 777675629,
  "in_reply_to_status_id" : 777674604,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777674604",
  "geo" : { },
  "id_str" : "777675762",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway Also, what are you using to connect them all? Multiplicity? Synergy?",
  "id" : 777675762,
  "in_reply_to_status_id" : 777674604,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777677807",
  "geo" : { },
  "id_str" : "777679800",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway look into Multiplicity, you could control all 3 with one kb\/mouse and copy files\/text between them http:\/\/snurl.com\/22peh",
  "id" : 777679800,
  "in_reply_to_status_id" : 777677807,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777678832",
  "geo" : { },
  "id_str" : "777680133",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort That's pretty much the story of life.",
  "id" : 777680133,
  "in_reply_to_status_id" : 777678832,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777303081",
  "geo" : { },
  "id_str" : "777307999",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee Awake, but not necessarily aware.",
  "id" : 777307999,
  "in_reply_to_status_id" : 777303081,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777308996",
  "text" : "Probably the most WTF picture of Sonic the Hedgehog I've ever seen. http:\/\/snurl.com\/22n8h",
  "id" : 777308996,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sol Young",
      "screen_name" : "sol",
      "indices" : [ 0, 4 ],
      "id_str" : "12649752",
      "id" : 12649752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777309983",
  "geo" : { },
  "id_str" : "777311123",
  "in_reply_to_user_id" : 12649752,
  "text" : "@sol My bad, it's called staticize-reloaded, and it does cache wp-rss.php\/wp-rss2.php according to the plugin file http:\/\/snurl.com\/22n8r",
  "id" : 777311123,
  "in_reply_to_status_id" : 777309983,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "sol",
  "in_reply_to_user_id_str" : "12649752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777317464",
  "text" : "Come one, come all, it's time for the job fair! Forcing RIT students to dress up nicely since they need a job to pay off their huge debts!",
  "id" : 777317464,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777318500",
  "geo" : { },
  "id_str" : "777320872",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee So is MySpace equivalent to making a drunk dial?",
  "id" : 777320872,
  "in_reply_to_status_id" : 777318500,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Schwager",
      "screen_name" : "onlycodered",
      "indices" : [ 0, 12 ],
      "id_str" : "1622561",
      "id" : 1622561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777320303",
  "geo" : { },
  "id_str" : "777323449",
  "in_reply_to_user_id" : 1622561,
  "text" : "@onlycodered Shopped.",
  "id" : 777323449,
  "in_reply_to_status_id" : 777320303,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "onlycodered",
  "in_reply_to_user_id_str" : "1622561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777329856",
  "text" : "Almond M&M's: breakfast of champions.",
  "id" : 777329856,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777333269",
  "text" : "How to make $$$ selling wallpapers: http:\/\/snurl.com\/22nc5 Vladstudio has awesome walls but my trial runs out soon :( http:\/\/snurl.com\/22nc7",
  "id" : 777333269,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777337898",
  "geo" : { },
  "id_str" : "777342836",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog Perhaps show off the Impulse beta?",
  "id" : 777342836,
  "in_reply_to_status_id" : 777337898,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777344586",
  "text" : "Turning caching back on for my blog, now that I've figured out how to post my twitter status via javascript. Woot!",
  "id" : 777344586,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arienna",
      "screen_name" : "Arienna",
      "indices" : [ 0, 8 ],
      "id_str" : "9277532",
      "id" : 9277532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777342838",
  "geo" : { },
  "id_str" : "777345463",
  "in_reply_to_user_id" : 9277532,
  "text" : "@Arienna Seems like a cheap way out of an artist's block to me! :P",
  "id" : 777345463,
  "in_reply_to_status_id" : 777342838,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Arienna",
  "in_reply_to_user_id_str" : "9277532",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Sliwinski",
      "screen_name" : "Tsliwi2000",
      "indices" : [ 0, 11 ],
      "id_str" : "10660522",
      "id" : 10660522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777347622",
  "geo" : { },
  "id_str" : "777351017",
  "in_reply_to_user_id" : 10660522,
  "text" : "@Tsliwi2000 Typical Rochester day, eh? Mostly gray skies, but I do see some sun today",
  "id" : 777351017,
  "in_reply_to_status_id" : 777347622,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Tsliwi2000",
  "in_reply_to_user_id_str" : "10660522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Zehnder Rossi",
      "screen_name" : "shawnz",
      "indices" : [ 0, 7 ],
      "id_str" : "7789282",
      "id" : 7789282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777354054",
  "geo" : { },
  "id_str" : "777354671",
  "in_reply_to_user_id" : 7789282,
  "text" : "@shawnz Scorpion vodka? A scorpion lollipop!? This is downright terrifying, how in the world is it meant for human consumption",
  "id" : 777354671,
  "in_reply_to_status_id" : 777354054,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "shawnz",
  "in_reply_to_user_id_str" : "7789282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debra Hamel",
      "screen_name" : "debra_hamel",
      "indices" : [ 0, 12 ],
      "id_str" : "765942",
      "id" : 765942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777359839",
  "geo" : { },
  "id_str" : "777360145",
  "in_reply_to_user_id" : 765942,
  "text" : "@Debra_Hamel Thanks! :D why do YOU love it?",
  "id" : 777360145,
  "in_reply_to_status_id" : 777359839,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "debra_hamel",
  "in_reply_to_user_id_str" : "765942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debra Hamel",
      "screen_name" : "debra_hamel",
      "indices" : [ 0, 12 ],
      "id_str" : "765942",
      "id" : 765942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777364251",
  "geo" : { },
  "id_str" : "777364700",
  "in_reply_to_user_id" : 765942,
  "text" : "@Debra_Hamel Yep, I used your post as a starting point and bent twitter's blogger.js to my will",
  "id" : 777364700,
  "in_reply_to_status_id" : 777364251,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "debra_hamel",
  "in_reply_to_user_id_str" : "765942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uE10D Clay Newton \uE11C",
      "screen_name" : "claynewton",
      "indices" : [ 0, 11 ],
      "id_str" : "6295312",
      "id" : 6295312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777363056",
  "geo" : { },
  "id_str" : "777365240",
  "in_reply_to_user_id" : 6295312,
  "text" : "@claynewton Why not WordPress?",
  "id" : 777365240,
  "in_reply_to_status_id" : 777363056,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "claynewton",
  "in_reply_to_user_id_str" : "6295312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777449684",
  "text" : "Career fair, accomplished. Made out with a Wegmans cloth bag too, woot.",
  "id" : 777449684,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777452636",
  "text" : "Furiously labeling new emails in GMail. It's a sick habit of mine.",
  "id" : 777452636,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777453622",
  "geo" : { },
  "id_str" : "777454607",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort Not yet! Definitely worth looking into, but the majority of my emails are labeled when they enter my inbox.",
  "id" : 777454607,
  "in_reply_to_status_id" : 777453622,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777454198",
  "geo" : { },
  "id_str" : "777454969",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror That's just wonderful, but if the UI blows I don't see any reason why Safari will pick up on Windows.",
  "id" : 777454969,
  "in_reply_to_status_id" : 777454198,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777456399",
  "text" : "Google Calendar is temporarily unavailable. Wonderful.",
  "id" : 777456399,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777460190",
  "geo" : { },
  "id_str" : "777461885",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman I'll have a bacon turkey bravo with a cup of broccoli cheddar soup, please.",
  "id" : 777461885,
  "in_reply_to_status_id" : 777460190,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777462996",
  "text" : "Working with databases in Java seems like a huge pain. Either that or the .NET framework does a lot of magic I'm not aware of yet.",
  "id" : 777462996,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777464332",
  "text" : "JavaBeans: Proving why C#'s properties and method\/class attributes are better.",
  "id" : 777464332,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brainwashcamp",
      "indices" : [ 38, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777472432",
  "text" : "Finding new twits on irc.freenode.net #brainwashcamp :D",
  "id" : 777472432,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777470711",
  "geo" : { },
  "id_str" : "777473118",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway That would be a nightmare, imo. ActiveX's current gimped state doesn't help your argument",
  "id" : 777473118,
  "in_reply_to_status_id" : 777470711,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Kelly",
      "screen_name" : "inkedmn",
      "indices" : [ 0, 8 ],
      "id_str" : "2844098929",
      "id" : 2844098929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777482364",
  "geo" : { },
  "id_str" : "777486619",
  "in_reply_to_user_id" : 434883,
  "text" : "@inkedmn Perhaps you should consider butterflies? http:\/\/xkcd.com\/378\/",
  "id" : 777486619,
  "in_reply_to_status_id" : 777482364,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrbrettkelly",
  "in_reply_to_user_id_str" : "434883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777491194",
  "text" : "Watching my professor do a lot of magic with an eclipse UML modeling tool from Rational. Seems...very unnecessary.",
  "id" : 777491194,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Patterson",
      "screen_name" : "metadaddy",
      "indices" : [ 0, 10 ],
      "id_str" : "5518682",
      "id" : 5518682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csharp",
      "indices" : [ 37, 44 ]
    }, {
      "text" : "nethack",
      "indices" : [ 46, 54 ]
    }, {
      "text" : "jquery",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777490985",
  "geo" : { },
  "id_str" : "777492042",
  "in_reply_to_user_id" : 5518682,
  "text" : "@metadaddy I'm normally on freenode ##csharp, #nethack, and #jquery, so one more channel doesn't hurt.",
  "id" : 777492042,
  "in_reply_to_status_id" : 777490985,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "metadaddy",
  "in_reply_to_user_id_str" : "5518682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jae",
      "screen_name" : "jae",
      "indices" : [ 0, 4 ],
      "id_str" : "637273",
      "id" : 637273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777490701",
  "geo" : { },
  "id_str" : "777492627",
  "in_reply_to_user_id" : 637273,
  "text" : "@jae snorg tees has good ones too... http:\/\/www.snorgtees.com\/",
  "id" : 777492627,
  "in_reply_to_status_id" : 777490701,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "jae",
  "in_reply_to_user_id_str" : "637273",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Fitton",
      "screen_name" : "Pistachio",
      "indices" : [ 0, 10 ],
      "id_str" : "3533231",
      "id" : 3533231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777494459",
  "geo" : { },
  "id_str" : "777496838",
  "in_reply_to_user_id" : 3533231,
  "text" : "@Pistachio You mean all guys don't obsess over 50x50 pixel pictures of women? Gasp.",
  "id" : 777496838,
  "in_reply_to_status_id" : 777494459,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Pistachio",
  "in_reply_to_user_id_str" : "3533231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777497437",
  "geo" : { },
  "id_str" : "777498612",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco Now I want a spicy baconator.",
  "id" : 777498612,
  "in_reply_to_status_id" : 777497437,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 11, 21 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777499412",
  "text" : "Retweeting @IslandDog: New blog post: Political Machine 2008 Announced! http:\/\/tinyurl.com\/3dav7v",
  "id" : 777499412,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyell E. Petersen",
      "screen_name" : "93octane",
      "indices" : [ 0, 9 ],
      "id_str" : "1508231",
      "id" : 1508231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777500760",
  "geo" : { },
  "id_str" : "777502340",
  "in_reply_to_user_id" : 1508231,
  "text" : "@93octane You also may enjoy why I love twitter http:\/\/snurl.com\/22oei",
  "id" : 777502340,
  "in_reply_to_status_id" : 777500760,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "93octane",
  "in_reply_to_user_id_str" : "1508231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twhirl Announce",
      "screen_name" : "twhirl",
      "indices" : [ 7, 14 ],
      "id_str" : "9993542",
      "id" : 9993542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777504455",
  "text" : "I wish @twhirl would show if I'm following the person I'm looking up or not, instead of just showing an error message when I try to add them",
  "id" : 777504455,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "indices" : [ 0, 8 ],
      "id_str" : "4030",
      "id" : 4030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777502822",
  "geo" : { },
  "id_str" : "777504904",
  "in_reply_to_user_id" : 4030,
  "text" : "@monstro Your username or your domain got blocked?",
  "id" : 777504904,
  "in_reply_to_status_id" : 777502822,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "monstro",
  "in_reply_to_user_id_str" : "4030",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Recordon",
      "screen_name" : "daveman692",
      "indices" : [ 0, 11 ],
      "id_str" : "744463",
      "id" : 744463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777525754",
  "geo" : { },
  "id_str" : "777526371",
  "in_reply_to_user_id" : 744463,
  "text" : "@daveman692 I'm wondering the same. If you find anything let me know!",
  "id" : 777526371,
  "in_reply_to_status_id" : 777525754,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "daveman692",
  "in_reply_to_user_id_str" : "744463",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777527053",
  "text" : "20 minutes to send a fax. ridiculous.",
  "id" : 777527053,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777525618",
  "geo" : { },
  "id_str" : "777527247",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob That sucks. Seems like it would make sense.",
  "id" : 777527247,
  "in_reply_to_status_id" : 777525618,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JComboBox",
      "screen_name" : "JComboBox",
      "indices" : [ 0, 10 ],
      "id_str" : "14198120",
      "id" : 14198120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777527641",
  "geo" : { },
  "id_str" : "777528014",
  "in_reply_to_user_id" : 14198120,
  "text" : "@JComboBox There seemed to be waaay too many people at the Yahoo table.",
  "id" : 777528014,
  "in_reply_to_status_id" : 777527641,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "JComboBox",
  "in_reply_to_user_id_str" : "14198120",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miffy balboa",
      "screen_name" : "Puddington",
      "indices" : [ 0, 11 ],
      "id_str" : "298414457",
      "id" : 298414457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777533638",
  "geo" : { },
  "id_str" : "777535878",
  "in_reply_to_user_id" : 2057591,
  "text" : "@Puddington Westbrooke seemed quite scary when I visited. I also heard that the cops visit quite often to break up parties...",
  "id" : 777535878,
  "in_reply_to_status_id" : 777533638,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "oneWillJ",
  "in_reply_to_user_id_str" : "2057591",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howland",
      "screen_name" : "backslash",
      "indices" : [ 0, 10 ],
      "id_str" : "8161622",
      "id" : 8161622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777539060",
  "geo" : { },
  "id_str" : "777539543",
  "in_reply_to_user_id" : 8161622,
  "text" : "@backslash I read it on the Interblag! http:\/\/xkcd.com\/181\/",
  "id" : 777539543,
  "in_reply_to_status_id" : 777539060,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "backslash",
  "in_reply_to_user_id_str" : "8161622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777541877",
  "text" : "One day I wonder if I'll regret Twittering when I should be paying attention in class.",
  "id" : 777541877,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777541989",
  "geo" : { },
  "id_str" : "777542716",
  "in_reply_to_user_id" : 12920742,
  "text" : "@listen_to_pius I saw him in Lewiston, NY at Artpark...good stuff! I need to see him again.",
  "id" : 777542716,
  "in_reply_to_status_id" : 777541989,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "_pius",
  "in_reply_to_user_id_str" : "12920742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JComboBox",
      "screen_name" : "JComboBox",
      "indices" : [ 0, 10 ],
      "id_str" : "14198120",
      "id" : 14198120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777527641",
  "geo" : { },
  "id_str" : "777543242",
  "in_reply_to_user_id" : 14198120,
  "text" : "@JComboBox Yeah, they've got a lot of great things going on, I just hope that MS doesn't go OM NOM NOM NOM. And follow me!",
  "id" : 777543242,
  "in_reply_to_status_id" : 777527641,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "JComboBox",
  "in_reply_to_user_id_str" : "14198120",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777546471",
  "geo" : { },
  "id_str" : "777548114",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror Don't you dare disturb the esoteric language gods with this one. I really hope PHP isn't the future, but it is easy to set up.",
  "id" : 777548114,
  "in_reply_to_status_id" : 777546471,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777565366",
  "text" : "Going to get lost in downtown Rochester! Whee!",
  "id" : 777565366,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777620397",
  "text" : "note to self, turn off twhirl on desktop when you're not around, as it will stay updated.",
  "id" : 777620397,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whurley \u00AE",
      "screen_name" : "whurley",
      "indices" : [ 0, 8 ],
      "id_str" : "330093",
      "id" : 330093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777623051",
  "geo" : { },
  "id_str" : "777627291",
  "in_reply_to_user_id" : 330093,
  "text" : "@whurley Throw in a few marquee tags on the brainwashcamp, it'll match the blinks nicely",
  "id" : 777627291,
  "in_reply_to_status_id" : 777623051,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "whurley",
  "in_reply_to_user_id_str" : "330093",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777658736",
  "text" : "Geek workout: 1 hour of drums on Rock Band. I bet it burns more calories than you'd think. Or maybe not.",
  "id" : 777658736,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777074434",
  "text" : "Almond M&M's are crazy delicious.",
  "id" : 777074434,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777031960",
  "geo" : { },
  "id_str" : "777080860",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort Have you thought about using the Google Chart API so stats can be shown to others?",
  "id" : 777080860,
  "in_reply_to_status_id" : 777031960,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777090048",
  "text" : "La pequena Hillary Clinton, Very disturbing: http:\/\/snurl.com\/22ma7",
  "id" : 777090048,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777099486",
  "text" : "New blog post, why I love twitter: http:\/\/snurl.com\/22mbq",
  "id" : 777099486,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JComboBox",
      "screen_name" : "JComboBox",
      "indices" : [ 0, 10 ],
      "id_str" : "14198120",
      "id" : 14198120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777098253",
  "geo" : { },
  "id_str" : "777100287",
  "in_reply_to_user_id" : 14198120,
  "text" : "@JComboBox After every test in that class I felt like jumping out of the 3rd story windows in GCCIS",
  "id" : 777100287,
  "in_reply_to_status_id" : 777098253,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "JComboBox",
  "in_reply_to_user_id_str" : "14198120",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 0, 7 ],
      "id_str" : "6118872",
      "id" : 6118872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777113445",
  "geo" : { },
  "id_str" : "777114786",
  "in_reply_to_user_id" : 6118872,
  "text" : "@zoomba It's a great client! glad to see you're trying it out.",
  "id" : 777114786,
  "in_reply_to_status_id" : 777113445,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "zoomba",
  "in_reply_to_user_id_str" : "6118872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    }, {
      "name" : "Chris Brogan",
      "screen_name" : "chrisbrogan",
      "indices" : [ 9, 21 ],
      "id_str" : "10202",
      "id" : 10202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777101692",
  "geo" : { },
  "id_str" : "777115231",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee @chrisbrogan Any tips for getting comments on a comment-less blog? I'm not sure if \"build it, and they will come\" is working for me",
  "id" : 777115231,
  "in_reply_to_status_id" : 777101692,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 0, 7 ],
      "id_str" : "6118872",
      "id" : 6118872
    }, {
      "name" : "Hi Everybody!",
      "screen_name" : "DoctorNick",
      "indices" : [ 45, 56 ],
      "id_str" : "2951720045",
      "id" : 2951720045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777113445",
  "geo" : { },
  "id_str" : "777119018",
  "in_reply_to_user_id" : 6118872,
  "text" : "@zoomba Hah, not just you! :P Next time use \"@DoctorNick blah blah\" so it shows up in my replies",
  "id" : 777119018,
  "in_reply_to_status_id" : 777113445,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "zoomba",
  "in_reply_to_user_id_str" : "6118872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Schwager",
      "screen_name" : "onlycodered",
      "indices" : [ 0, 12 ],
      "id_str" : "1622561",
      "id" : 1622561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777121063",
  "geo" : { },
  "id_str" : "777121408",
  "in_reply_to_user_id" : 1622561,
  "text" : "@onlycodered I want a flying car. NOW.",
  "id" : 777121408,
  "in_reply_to_status_id" : 777121063,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "onlycodered",
  "in_reply_to_user_id_str" : "1622561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777127020",
  "geo" : { },
  "id_str" : "777129468",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee DoctorNick40",
  "id" : 777129468,
  "in_reply_to_status_id" : 777127020,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777146983",
  "text" : "Boston song pack for Rock Band RULES!",
  "id" : 777146983,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Starr",
      "screen_name" : "NickStarr",
      "indices" : [ 0, 10 ],
      "id_str" : "48933",
      "id" : 48933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777150064",
  "geo" : { },
  "id_str" : "777151410",
  "in_reply_to_user_id" : 48933,
  "text" : "@NickStarr Isn't the point of it to learn how to play? (And to lose money?)",
  "id" : 777151410,
  "in_reply_to_status_id" : 777150064,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "NickStarr",
  "in_reply_to_user_id_str" : "48933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777159697",
  "text" : "How in hell does Valve wrap 36 acheivements around TF2's medic class? http:\/\/snurl.com\/22mk4",
  "id" : 777159697,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ATyler",
      "screen_name" : "ATyler",
      "indices" : [ 0, 7 ],
      "id_str" : "14173094",
      "id" : 14173094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777169102",
  "geo" : { },
  "id_str" : "777169800",
  "in_reply_to_user_id" : 14173094,
  "text" : "@ATyler I'm printing out my resumes now...oh joy",
  "id" : 777169800,
  "in_reply_to_status_id" : 777169102,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "ATyler",
  "in_reply_to_user_id_str" : "14173094",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777180979",
  "text" : "Sleep is for the weak. And tired.",
  "id" : 777180979,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777298260",
  "geo" : { },
  "id_str" : "777303979",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort Perhaps what I meant was to provide javascript snippet so the flash object could be embedded into other websites. Just an idea.",
  "id" : 777303979,
  "in_reply_to_status_id" : 777298260,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sol Young",
      "screen_name" : "sol",
      "indices" : [ 0, 4 ],
      "id_str" : "12649752",
      "id" : 12649752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777304661",
  "geo" : { },
  "id_str" : "777306019",
  "in_reply_to_user_id" : 12649752,
  "text" : "@sol Staticized-cache is another good cache plugin if you find wp-cache to not work for you like I did.",
  "id" : 777306019,
  "in_reply_to_status_id" : 777304661,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "sol",
  "in_reply_to_user_id_str" : "12649752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 0, 12 ],
      "id_str" : "8453452",
      "id" : 8453452
    }, {
      "name" : "Robert Scoble",
      "screen_name" : "Scobleizer",
      "indices" : [ 13, 24 ],
      "id_str" : "13348",
      "id" : 13348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777192860",
  "geo" : { },
  "id_str" : "777306850",
  "in_reply_to_user_id" : 8453452,
  "text" : "@guykawasaki @scobleizer I'm on twitter.alltop! Thanks so much, I really appreciate it!",
  "id" : 777306850,
  "in_reply_to_status_id" : 777192860,
  "created_at" : "2008-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "GuyKawasaki",
  "in_reply_to_user_id_str" : "8453452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaine Mata",
      "screen_name" : "shaine",
      "indices" : [ 0, 7 ],
      "id_str" : "871631",
      "id" : 871631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776848539",
  "geo" : { },
  "id_str" : "776850389",
  "in_reply_to_user_id" : 871631,
  "text" : "@shaine passw0rd? :P",
  "id" : 776850389,
  "in_reply_to_status_id" : 776848539,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "shaine",
  "in_reply_to_user_id_str" : "871631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776861931",
  "text" : "I find it hilarious when professors can't figure out how to hook up their laptops with classrom projectors. Not like they do it every day.",
  "id" : 776861931,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776872715",
  "text" : "I'm absolutely astounded that Texans call soda pop 'coke' by default. What kinda cokes do ya'll have? Coke coke? Coke pepsi? That's nuts.",
  "id" : 776872715,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Stoner",
      "screen_name" : "maslowbeer",
      "indices" : [ 0, 11 ],
      "id_str" : "13749072",
      "id" : 13749072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776873824",
  "geo" : { },
  "id_str" : "776874337",
  "in_reply_to_user_id" : 13749072,
  "text" : "@maslowbeer I concur, the sad thing is that my college only has pepsi. Luckily some groups smuggle Coke in. *snurk*",
  "id" : 776874337,
  "in_reply_to_status_id" : 776873824,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "maslowbeer",
  "in_reply_to_user_id_str" : "13749072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776875928",
  "geo" : { },
  "id_str" : "776878116",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco Have you tried FF3 yet? I'm a bit afraid to make the jump since I'm so dependent on my addons",
  "id" : 776878116,
  "in_reply_to_status_id" : 776875928,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776880248",
  "geo" : { },
  "id_str" : "776881937",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 Virtual office? I'd definitely be anywhere but an office in a virtual world.",
  "id" : 776881937,
  "in_reply_to_status_id" : 776880248,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Grigsby, \u26014",
      "screen_name" : "grigs",
      "indices" : [ 0, 6 ],
      "id_str" : "5774462",
      "id" : 5774462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776881902",
  "geo" : { },
  "id_str" : "776883385",
  "in_reply_to_user_id" : 5774462,
  "text" : "@grigs This is a riot. Now I want to know what the \"other\" names are.",
  "id" : 776883385,
  "in_reply_to_status_id" : 776881902,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "grigs",
  "in_reply_to_user_id_str" : "5774462",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Grigsby, \u26014",
      "screen_name" : "grigs",
      "indices" : [ 0, 6 ],
      "id_str" : "5774462",
      "id" : 5774462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776881902",
  "geo" : { },
  "id_str" : "776884411",
  "in_reply_to_user_id" : 5774462,
  "text" : "@grigs Looks like they do have \"other\" results...and i'm glad they filtered 4chan out http:\/\/snurl.com\/22kxx",
  "id" : 776884411,
  "in_reply_to_status_id" : 776881902,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "grigs",
  "in_reply_to_user_id_str" : "5774462",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 0, 12 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776886490",
  "geo" : { },
  "id_str" : "776887722",
  "in_reply_to_user_id" : 8453452,
  "text" : "@guykawasaki This is borderline amazing, and borderline ridiculous.",
  "id" : 776887722,
  "in_reply_to_status_id" : 776886490,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "GuyKawasaki",
  "in_reply_to_user_id_str" : "8453452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776899611",
  "geo" : { },
  "id_str" : "776902332",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 Yeah, I do the same for my job currently. Whoo boy...",
  "id" : 776902332,
  "in_reply_to_status_id" : 776899611,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776909715",
  "geo" : { },
  "id_str" : "776911377",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman Save yourself some pain now and go back to 32-bit Vista. I tried using 64-bit for a few months at home and just got so sick  ...",
  "id" : 776911377,
  "in_reply_to_status_id" : 776909715,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776912237",
  "text" : "The xkcd posters rule. So glad my roommate got them!",
  "id" : 776912237,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776913995",
  "geo" : { },
  "id_str" : "776914213",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman You're a brave soul then, and you certainly enjoy your dogfood. :)",
  "id" : 776914213,
  "in_reply_to_status_id" : 776913995,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Hunt",
      "screen_name" : "missrogue",
      "indices" : [ 0, 10 ],
      "id_str" : "1192",
      "id" : 1192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776926295",
  "geo" : { },
  "id_str" : "776927206",
  "in_reply_to_user_id" : 1192,
  "text" : "@missrogue The real way: lolcats.",
  "id" : 776927206,
  "in_reply_to_status_id" : 776926295,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "missrogue",
  "in_reply_to_user_id_str" : "1192",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Schwager",
      "screen_name" : "onlycodered",
      "indices" : [ 0, 12 ],
      "id_str" : "1622561",
      "id" : 1622561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776926453",
  "geo" : { },
  "id_str" : "776928476",
  "in_reply_to_user_id" : 1622561,
  "text" : "@onlycodered Two rows of F keys? This keyboard just blew my mind.",
  "id" : 776928476,
  "in_reply_to_status_id" : 776926453,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "onlycodered",
  "in_reply_to_user_id_str" : "1622561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid \u041C\u0451\u0434\u043E\u0432",
      "screen_name" : "Leonid",
      "indices" : [ 0, 7 ],
      "id_str" : "8022892",
      "id" : 8022892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773301402",
  "geo" : { },
  "id_str" : "776931468",
  "in_reply_to_user_id" : 8022892,
  "text" : "@Leonid has a HILARIOUS background image.",
  "id" : 776931468,
  "in_reply_to_status_id" : 773301402,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Leonid",
  "in_reply_to_user_id_str" : "8022892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 0, 14 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776946401",
  "geo" : { },
  "id_str" : "776950060",
  "in_reply_to_user_id" : 749863,
  "text" : "@hotdogsladies The \"my other shirt is in a shitty meeting\" shirt WINS. http:\/\/snurl.com\/22lfr",
  "id" : 776950060,
  "in_reply_to_status_id" : 776946401,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "hotdogsladies",
  "in_reply_to_user_id_str" : "749863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "trillian1117",
      "indices" : [ 0, 13 ],
      "id_str" : "4220781",
      "id" : 4220781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776836328",
  "geo" : { },
  "id_str" : "776956895",
  "in_reply_to_user_id" : 4220781,
  "text" : "@trillian1117 I can't seem to message you, since you're not following me! I'm a wizop at Wincustomize.com and a Catholic. ;)",
  "id" : 776956895,
  "in_reply_to_status_id" : 776836328,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "trillian1117",
  "in_reply_to_user_id_str" : "4220781",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776962115",
  "text" : "I really should cut up celery and have it with peanut butter instead of finishing off the box of oreos in my fridge.",
  "id" : 776962115,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776973643",
  "text" : "Going to finish the oreos. I'll probably regret it later.",
  "id" : 776973643,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Brogan",
      "screen_name" : "chrisbrogan",
      "indices" : [ 0, 12 ],
      "id_str" : "10202",
      "id" : 10202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776977334",
  "geo" : { },
  "id_str" : "776977851",
  "in_reply_to_user_id" : 10202,
  "text" : "@chrisbrogan I certainly hope so! Meeting new people is all twitter is about, really.",
  "id" : 776977851,
  "in_reply_to_status_id" : 776977334,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "chrisbrogan",
  "in_reply_to_user_id_str" : "10202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776983772",
  "text" : "Weighted companion cube plushies are back! http:\/\/snurl.com\/22lnw",
  "id" : 776983772,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Making Finances",
      "screen_name" : "colleencoplick",
      "indices" : [ 0, 15 ],
      "id_str" : "2535457327",
      "id" : 2535457327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776991446",
  "geo" : { },
  "id_str" : "776991917",
  "in_reply_to_user_id" : 9454022,
  "text" : "@ColleenCoplick Del.icio.us, by far. Their firefox bookmarks plugin rocks!",
  "id" : 776991917,
  "in_reply_to_status_id" : 776991446,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "MissManifesto",
  "in_reply_to_user_id_str" : "9454022",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776993702",
  "text" : "My Motorola Q's T key doesn't want to work all the time, and it's making text messaging painful.",
  "id" : 776993702,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776999090",
  "text" : "Early screen shots of The Political Machine 2008 from Stardock http:\/\/snurl.com\/22lr4",
  "id" : 776999090,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777013890",
  "geo" : { },
  "id_str" : "777014938",
  "in_reply_to_user_id" : 14144232,
  "text" : "@choosetheforce Try http:\/\/www.quotably.com\/choosetheforce",
  "id" : 777014938,
  "in_reply_to_status_id" : 777013890,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "chuckrector",
  "in_reply_to_user_id_str" : "14144232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shel israel",
      "screen_name" : "shelisrael",
      "indices" : [ 0, 11 ],
      "id_str" : "8069572",
      "id" : 8069572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777020439",
  "geo" : { },
  "id_str" : "777020789",
  "in_reply_to_user_id" : 8069572,
  "text" : "@shelisrael I really like how Vista lays out the Documents folder, I feel it's much more intelligent than XP's Documents and Setting setup.",
  "id" : 777020789,
  "in_reply_to_status_id" : 777020439,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "shelisrael",
  "in_reply_to_user_id_str" : "8069572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Dowell",
      "screen_name" : "CerebroJD",
      "indices" : [ 0, 10 ],
      "id_str" : "5744302",
      "id" : 5744302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777023378",
  "geo" : { },
  "id_str" : "777023828",
  "in_reply_to_user_id" : 5744302,
  "text" : "@CerebroJD What. Who listens to CDs now anyway :P",
  "id" : 777023828,
  "in_reply_to_status_id" : 777023378,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "CerebroJD",
  "in_reply_to_user_id_str" : "5744302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777024628",
  "text" : "Bitstrips is quite neat, but I have a feeling I'd still suck at drawing. Create your own comics online with it! http:\/\/www.bitstrips.com\/",
  "id" : 777024628,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tarabrown",
      "indices" : [ 0, 10 ],
      "id_str" : "17400089",
      "id" : 17400089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777023363",
  "geo" : { },
  "id_str" : "777025550",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tarabrown neat, but don't you hate sites that make you click through series of pictures like this just for ad impressions?",
  "id" : 777025550,
  "in_reply_to_status_id" : 777023363,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777028012",
  "geo" : { },
  "id_str" : "777029468",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco Neat. I also wonder if Safari's UI still blows. They managed to make iTunes look great on Windows but Safari sucked.",
  "id" : 777029468,
  "in_reply_to_status_id" : 777028012,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777033309",
  "text" : "I really don't like when people don't flip pictures the right side up on Facebook.",
  "id" : 777033309,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776498003",
  "text" : "Mmmm, chocolate frosty.",
  "id" : 776498003,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776426112",
  "geo" : { },
  "id_str" : "776499419",
  "in_reply_to_user_id" : 5744442,
  "text" : "@ablissfulgal has socks on her hands, and it looks funneh",
  "id" : 776499419,
  "in_reply_to_status_id" : 776426112,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Scoble",
      "screen_name" : "Scobleizer",
      "indices" : [ 0, 11 ],
      "id_str" : "13348",
      "id" : 13348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776498480",
  "geo" : { },
  "id_str" : "776500977",
  "in_reply_to_user_id" : 13348,
  "text" : "@Scobleizer Well of course, the internet is basically one giant bathroom wall.",
  "id" : 776500977,
  "in_reply_to_status_id" : 776498480,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Scobleizer",
  "in_reply_to_user_id_str" : "13348",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776504534",
  "text" : "Wondering what it's like to be on spring break, since RIT definitely doesn't have one.",
  "id" : 776504534,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776505471",
  "geo" : { },
  "id_str" : "776505733",
  "in_reply_to_user_id" : 14152810,
  "text" : "@offwhitemke Try subversion! AnkhSVN is a nice vs add-in if you need it, and RapidSVN is a kickass stand alone client.",
  "id" : 776505733,
  "in_reply_to_status_id" : 776505471,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "brennanMKE",
  "in_reply_to_user_id_str" : "14152810",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776505870",
  "text" : "Adam Carolla on Dancing with the Stars? Call me crazy but this should be a riot.",
  "id" : 776505870,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776512629",
  "geo" : { },
  "id_str" : "776513998",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog What the heck is iPhone 2.0. What happened to 1.0 through 2.0, or am I oblivious? Also, will the contact suck as much.",
  "id" : 776513998,
  "in_reply_to_status_id" : 776512629,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Scoble",
      "screen_name" : "Scobleizer",
      "indices" : [ 0, 11 ],
      "id_str" : "13348",
      "id" : 13348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776514680",
  "geo" : { },
  "id_str" : "776517872",
  "in_reply_to_user_id" : 13348,
  "text" : "@Scobleizer Are there still people hawking picture books of the attacks near Ground Zero? Almost made me sick.",
  "id" : 776517872,
  "in_reply_to_status_id" : 776514680,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Scobleizer",
  "in_reply_to_user_id_str" : "13348",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776516856",
  "geo" : { },
  "id_str" : "776518006",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco At least it's not blue screening. :P",
  "id" : 776518006,
  "in_reply_to_status_id" : 776516856,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Markman",
      "screen_name" : "Mickeleh",
      "indices" : [ 0, 9 ],
      "id_str" : "13413",
      "id" : 13413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776522343",
  "geo" : { },
  "id_str" : "776522809",
  "in_reply_to_user_id" : 13413,
  "text" : "@Mickeleh Obviously, there's only one explanation: TRANSFORMERS.",
  "id" : 776522809,
  "in_reply_to_status_id" : 776522343,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Mickeleh",
  "in_reply_to_user_id_str" : "13413",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776526153",
  "text" : "I need to start working out again. Seriously.",
  "id" : 776526153,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776535136",
  "text" : "I am really staring to hate raytracing.",
  "id" : 776535136,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arienna",
      "screen_name" : "Arienna",
      "indices" : [ 0, 8 ],
      "id_str" : "9277532",
      "id" : 9277532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776536335",
  "geo" : { },
  "id_str" : "776536542",
  "in_reply_to_user_id" : 9277532,
  "text" : "@Arienna PUSH BUTAN, RECEEV BACON.",
  "id" : 776536542,
  "in_reply_to_status_id" : 776536335,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Arienna",
  "in_reply_to_user_id_str" : "9277532",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776539721",
  "text" : "I really hate installing Apple software on Windows.",
  "id" : 776539721,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "steelopus",
      "screen_name" : "steelopus",
      "indices" : [ 0, 10 ],
      "id_str" : "6902732",
      "id" : 6902732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776540035",
  "geo" : { },
  "id_str" : "776541841",
  "in_reply_to_user_id" : 6902732,
  "text" : "@steelopus I don't think I could live without alt-tab.",
  "id" : 776541841,
  "in_reply_to_status_id" : 776540035,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "steelopus",
  "in_reply_to_user_id_str" : "6902732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "steelopus",
      "screen_name" : "steelopus",
      "indices" : [ 0, 10 ],
      "id_str" : "6902732",
      "id" : 6902732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776542602",
  "geo" : { },
  "id_str" : "776543518",
  "in_reply_to_user_id" : 6902732,
  "text" : "@steelopus I have my ways of dealing. I use Enso http:\/\/snurl.com\/22j25 and i pimp my console out http:\/\/snurl.com\/22j27",
  "id" : 776543518,
  "in_reply_to_status_id" : 776542602,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "steelopus",
  "in_reply_to_user_id_str" : "6902732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776545815",
  "text" : "Says on your chart you're fucked up, you talk like a fag, and your shit's all retarded. I love Idiocracy.",
  "id" : 776545815,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah jones",
      "screen_name" : "LeahJones",
      "indices" : [ 0, 10 ],
      "id_str" : "1539609079",
      "id" : 1539609079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776545977",
  "text" : "@leahjones Something went wrong.",
  "id" : 776545977,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Dowell",
      "screen_name" : "CerebroJD",
      "indices" : [ 0, 10 ],
      "id_str" : "5744302",
      "id" : 5744302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776564261",
  "geo" : { },
  "id_str" : "776566470",
  "in_reply_to_user_id" : 5744302,
  "text" : "@CerebroJD Without getting paid? You're a brave soul.",
  "id" : 776566470,
  "in_reply_to_status_id" : 776564261,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "CerebroJD",
  "in_reply_to_user_id_str" : "5744302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776569235",
  "text" : "Twhirl really needs to scroll up when it updates.",
  "id" : 776569235,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Zehnder Rossi",
      "screen_name" : "shawnz",
      "indices" : [ 0, 7 ],
      "id_str" : "7789282",
      "id" : 7789282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776577266",
  "geo" : { },
  "id_str" : "776577744",
  "in_reply_to_user_id" : 7789282,
  "text" : "@shawnz is now twitterpedia.",
  "id" : 776577744,
  "in_reply_to_status_id" : 776577266,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "shawnz",
  "in_reply_to_user_id_str" : "7789282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776601251",
  "text" : "Sleep is for the weak.",
  "id" : 776601251,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776603413",
  "text" : "Livejournal 404 pages are a riot. http:\/\/www.livejournal.com\/404",
  "id" : 776603413,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776751830",
  "text" : "Tuesday's coming, did you bring your coat?",
  "id" : 776751830,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776767890",
  "geo" : { },
  "id_str" : "776772556",
  "in_reply_to_user_id" : 5744442,
  "text" : "@ablissfulgal Good one.",
  "id" : 776772556,
  "in_reply_to_status_id" : 776767890,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776777078",
  "text" : "I propose that Tuesdays should be considered worse than Mondays.",
  "id" : 776777078,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776779084",
  "geo" : { },
  "id_str" : "776779370",
  "in_reply_to_user_id" : 5744442,
  "text" : "@ablissfulgal Sounds good!",
  "id" : 776779370,
  "in_reply_to_status_id" : 776779084,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776827611",
  "text" : "Attention RIT. Stop bothering me about grad school.",
  "id" : 776827611,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776829117",
  "text" : "Rock Band Wii Arrives June 22, Will Not Offer Downloadable Songs or Online Play. Failboat. http:\/\/snurl.com\/22kls",
  "id" : 776829117,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776831189",
  "text" : "Even creepier than real mario, real homer: http:\/\/snurl.com\/22km2",
  "id" : 776831189,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776832144",
  "text" : "Attention RIT professors: Do not start new lecture notes 2 minutes before your 2 hour lecture ends.",
  "id" : 776832144,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gapingvoid",
      "screen_name" : "gapingvoid",
      "indices" : [ 0, 11 ],
      "id_str" : "72982024",
      "id" : 72982024
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776843161",
  "geo" : { },
  "id_str" : "776843765",
  "in_reply_to_user_id" : 50193,
  "text" : "@gapingvoid Better than 670 application requests.",
  "id" : 776843765,
  "in_reply_to_status_id" : 776843161,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "hughcartoons",
  "in_reply_to_user_id_str" : "50193",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776843796",
  "geo" : { },
  "id_str" : "776846450",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway The question is, what the hell is an Orgasmatron?",
  "id" : 776846450,
  "in_reply_to_status_id" : 776843796,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gapingvoid",
      "screen_name" : "gapingvoid",
      "indices" : [ 11, 22 ],
      "id_str" : "72982024",
      "id" : 72982024
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776848450",
  "text" : "Retweeting @gapingvoid:  \"A simple 'ignore all' bookmark for facebook\"  http:\/\/www.ignoreall.com\/",
  "id" : 776848450,
  "created_at" : "2008-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776187342",
  "text" : "Must...stop...staring at Twitter...and get on with life!",
  "id" : 776187342,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776204511",
  "text" : "I also need to stop watching NetHack games and get a move on to campus.",
  "id" : 776204511,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776216407",
  "text" : "I really hate lab computers. Not having my setup makes me feel gimped.",
  "id" : 776216407,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776218407",
  "geo" : { },
  "id_str" : "776219445",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog I can hear your video games beckoning you from here...",
  "id" : 776219445,
  "in_reply_to_status_id" : 776218407,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776223872",
  "text" : "I really hate Visio.",
  "id" : 776223872,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Thomson",
      "screen_name" : "chris24",
      "indices" : [ 0, 8 ],
      "id_str" : "705953",
      "id" : 705953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776231747",
  "geo" : { },
  "id_str" : "776234131",
  "in_reply_to_user_id" : 705953,
  "text" : "@chris24 10:30 is early for you? I wish I could say the same...",
  "id" : 776234131,
  "in_reply_to_status_id" : 776231747,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris24",
  "in_reply_to_user_id_str" : "705953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776234612",
  "text" : "Watching tour groups stare blankly into the fishbowl labs here on campus is highly amusing.",
  "id" : 776234612,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776250281",
  "text" : "The creative headphones that came with my laptop do a great job of filtering out any and all annoying noise around me.",
  "id" : 776250281,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776252261",
  "geo" : { },
  "id_str" : "776254293",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco Yeah, the skulls look pretty badass.",
  "id" : 776254293,
  "in_reply_to_status_id" : 776252261,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776279173",
  "text" : "I really should have eaten something before class.",
  "id" : 776279173,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Fitton",
      "screen_name" : "Pistachio",
      "indices" : [ 0, 10 ],
      "id_str" : "3533231",
      "id" : 3533231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776282617",
  "geo" : { },
  "id_str" : "776282831",
  "in_reply_to_user_id" : 3533231,
  "text" : "@Pistachio Might be easier (and less painful) if you get a wallet with a clip or carabiner.",
  "id" : 776282831,
  "in_reply_to_status_id" : 776282617,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "Pistachio",
  "in_reply_to_user_id_str" : "3533231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Nordquist",
      "screen_name" : "Akula",
      "indices" : [ 0, 6 ],
      "id_str" : "46363",
      "id" : 46363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776285477",
  "geo" : { },
  "id_str" : "776286205",
  "in_reply_to_user_id" : 46363,
  "text" : "@Akula Yes, Windows XP. :)",
  "id" : 776286205,
  "in_reply_to_status_id" : 776285477,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "Akula",
  "in_reply_to_user_id_str" : "46363",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776305661",
  "text" : "My raytracer is showing a sphere! ALMOST THERE!",
  "id" : 776305661,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776332730",
  "text" : "My laptop will probably die during this class. Failboat.",
  "id" : 776332730,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776359145",
  "geo" : { },
  "id_str" : "776362348",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco Your dashes make twitter's web interface suck.",
  "id" : 776362348,
  "in_reply_to_status_id" : 776359145,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776426112",
  "geo" : { },
  "id_str" : "776466064",
  "in_reply_to_user_id" : 5744442,
  "text" : "@ablissfulgal Spicy baconators ftw!",
  "id" : 776466064,
  "in_reply_to_status_id" : 776426112,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776006534",
  "text" : "Wii Bowling seems so...dated.",
  "id" : 776006534,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    }, {
      "name" : "Robert Scoble",
      "screen_name" : "Scobleizer",
      "indices" : [ 10, 21 ],
      "id_str" : "13348",
      "id" : 13348
    }, {
      "name" : "Kevin Rose",
      "screen_name" : "kevinrose",
      "indices" : [ 23, 33 ],
      "id_str" : "657863",
      "id" : 657863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776020760",
  "geo" : { },
  "id_str" : "776028553",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee, @Scobleizer, @kevinrose truly make me feel like I'm outside of the real twitter clique looking in. Teh suck.",
  "id" : 776028553,
  "in_reply_to_status_id" : 776020760,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Scoble",
      "screen_name" : "Scobleizer",
      "indices" : [ 0, 11 ],
      "id_str" : "13348",
      "id" : 13348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776028741",
  "geo" : { },
  "id_str" : "776031962",
  "in_reply_to_user_id" : 13348,
  "text" : "@Scobleizer Thanks! Perhaps not completely outside, but lurking in the background. One day I'll be a twitterati: http:\/\/twitter.alltop.com\/",
  "id" : 776031962,
  "in_reply_to_status_id" : 776028741,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "Scobleizer",
  "in_reply_to_user_id_str" : "13348",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776032877",
  "text" : "I'm going on a Twitterati adding spree.",
  "id" : 776032877,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Scoble",
      "screen_name" : "Scobleizer",
      "indices" : [ 0, 11 ],
      "id_str" : "13348",
      "id" : 13348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776032638",
  "geo" : { },
  "id_str" : "776033083",
  "in_reply_to_user_id" : 13348,
  "text" : "@Scobleizer Think the developer will take a bribe?",
  "id" : 776033083,
  "in_reply_to_status_id" : 776032638,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "Scobleizer",
  "in_reply_to_user_id_str" : "13348",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Scoble",
      "screen_name" : "Scobleizer",
      "indices" : [ 0, 11 ],
      "id_str" : "13348",
      "id" : 13348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776033369",
  "geo" : { },
  "id_str" : "776034992",
  "in_reply_to_user_id" : 13348,
  "text" : "@Scobleizer I'd appreciate it. But in reality all twitter users should feel \"in\" and know about the top twitter users\/twitterati.",
  "id" : 776034992,
  "in_reply_to_status_id" : 776033369,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "Scobleizer",
  "in_reply_to_user_id_str" : "13348",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776039302",
  "text" : "So according to my girlfriend I've replaced my Reddit\/Digg addiction with Twitter. Well, at least it's better than World of Warcraft.",
  "id" : 776039302,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776041556",
  "geo" : { },
  "id_str" : "776041748",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror How many until your own fighter jet?",
  "id" : 776041748,
  "in_reply_to_status_id" : 776041556,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776044495",
  "text" : "Ben Stiller, Jack Black, Robert Downey Jr. I hope Tropic Thunder turns out as awesome as it sounds: http:\/\/www.imdb.com\/title\/tt0942385\/",
  "id" : 776044495,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775888022",
  "geo" : { },
  "id_str" : "776045976",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco: Should I go to BarCamp? I don't know much OSS outside of the .NET world but I want to learn. I do lovejQuery though.",
  "id" : 776045976,
  "in_reply_to_status_id" : 775888022,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 0, 8 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775994698",
  "geo" : { },
  "id_str" : "776046349",
  "in_reply_to_user_id" : 752673,
  "text" : "@jeresig Are you coming to RochesterBarCamp3? I'd love to go but I'm not that well versed in OSS outside of jQuery...",
  "id" : 776046349,
  "in_reply_to_status_id" : 775994698,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "jeresig",
  "in_reply_to_user_id_str" : "752673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776048978",
  "geo" : { },
  "id_str" : "776057216",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco I can do that. :)",
  "id" : 776057216,
  "in_reply_to_status_id" : 776048978,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Puri",
      "screen_name" : "paulpuri",
      "indices" : [ 0, 9 ],
      "id_str" : "5472862",
      "id" : 5472862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776052708",
  "geo" : { },
  "id_str" : "776057347",
  "in_reply_to_user_id" : 5472862,
  "text" : "@paulpuri Yeah, the trailer is a riot. I just hope it doesn't bomb.",
  "id" : 776057347,
  "in_reply_to_status_id" : 776052708,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "paulpuri",
  "in_reply_to_user_id_str" : "5472862",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776057889",
  "text" : "It would be really nice if Twitter had a way other than email to show which people added you most recently, and not just a huge list.",
  "id" : 776057889,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776059497",
  "text" : "I love my new laptop. Warning icon on the battery, 19% remaining...with an hour to plug it in. My last one wouldn't even give me 5 minutes.",
  "id" : 776059497,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776060168",
  "text" : "Holy crap, twitter poster is huge. http:\/\/twitterposter.com\/ I really need to look into the Twitter API.",
  "id" : 776060168,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776061607",
  "geo" : { },
  "id_str" : "776062521",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway I seriously doubt that most people type http:\/\/ in the first place. Hell, the majority won't even know what it means.",
  "id" : 776062521,
  "in_reply_to_status_id" : 776061607,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776063405",
  "text" : "http:\/\/twitterposter.com really gives one a sense of how global twitter really is...it's HUUUUUUUGE as one certain car salesman would say",
  "id" : 776063405,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Laporte",
      "screen_name" : "leolaporte",
      "indices" : [ 0, 11 ],
      "id_str" : "3829151",
      "id" : 3829151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776065235",
  "geo" : { },
  "id_str" : "776066000",
  "in_reply_to_user_id" : 3829151,
  "text" : "@leolaporte Quotably is quite impressive...it's actually a decent way to keep track of conversations, like a real forum. *gasp*",
  "id" : 776066000,
  "in_reply_to_status_id" : 776065235,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "leolaporte",
  "in_reply_to_user_id_str" : "3829151",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776066622",
  "text" : "The best part about Twitter is that they used @ symbols to reference people, like in NetHack. Who cares about social networking anyway.",
  "id" : 776066622,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776068924",
  "text" : "Halo 3 Heroic Map Pack is free this Tuesday. It's nice to see gaming companies care. http:\/\/tinyurl.com\/2wlc84",
  "id" : 776068924,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776069856",
  "text" : "Broccoli Obama. Now I've seen everything. http:\/\/tinyurl.com\/2mc5pd",
  "id" : 776069856,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quotably.com",
      "screen_name" : "quotably",
      "indices" : [ 0, 9 ],
      "id_str" : "14197877",
      "id" : 14197877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776069552",
  "geo" : { },
  "id_str" : "776070371",
  "in_reply_to_user_id" : 14197877,
  "text" : "@quotably Site is looking good! I just wish this kind of stuff was actually inside of Twitter, but I guess that's why the API exists.",
  "id" : 776070371,
  "in_reply_to_status_id" : 776069552,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "quotably",
  "in_reply_to_user_id_str" : "14197877",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776070498",
  "text" : "I've become a Twitterholic and I need sleep.",
  "id" : 776070498,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shashi Bellamkonda",
      "screen_name" : "shashib",
      "indices" : [ 0, 8 ],
      "id_str" : "1221471",
      "id" : 1221471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776072394",
  "geo" : { },
  "id_str" : "776073828",
  "in_reply_to_user_id" : 1221471,
  "text" : "@shashib The local twitter sites you found rule! I just need to dig through them now and add people. thanks!",
  "id" : 776073828,
  "in_reply_to_status_id" : 776072394,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "shashib",
  "in_reply_to_user_id_str" : "1221471",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776172337",
  "text" : "Waking up sucks.",
  "id" : 776172337,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Brogan",
      "screen_name" : "chrisbrogan",
      "indices" : [ 0, 12 ],
      "id_str" : "10202",
      "id" : 10202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776163143",
  "geo" : { },
  "id_str" : "776173551",
  "in_reply_to_user_id" : 10202,
  "text" : "@chrisbrogan Great tips for bloggers! Now I just need to do some of them, and hope that people magically can find my blog.",
  "id" : 776173551,
  "in_reply_to_status_id" : 776163143,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "chrisbrogan",
  "in_reply_to_user_id_str" : "10202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Kottke",
      "screen_name" : "jkottke",
      "indices" : [ 0, 8 ],
      "id_str" : "1305941",
      "id" : 1305941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776176833",
  "geo" : { },
  "id_str" : "776176972",
  "in_reply_to_user_id" : 1305941,
  "text" : "@jkottke Dammit, if i get Twitter-rolled one more time I'm going to hurt someone.",
  "id" : 776176972,
  "in_reply_to_status_id" : 776176833,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "jkottke",
  "in_reply_to_user_id_str" : "1305941",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776178300",
  "text" : "Buy your own Waterworld island: http:\/\/tinyurl.com\/358pcq",
  "id" : 776178300,
  "created_at" : "2008-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775776921",
  "text" : "Happy Easter!",
  "id" : 775776921,
  "created_at" : "2008-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775860973",
  "text" : "Recuperating after eating too much at Denny's.",
  "id" : 775860973,
  "created_at" : "2008-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775884338",
  "geo" : { },
  "id_str" : "775887657",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco: Isn't TNT doing that next weekend? Just trying to beat them to it? :P",
  "id" : 775887657,
  "in_reply_to_status_id" : 775884338,
  "created_at" : "2008-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775884338",
  "geo" : { },
  "id_str" : "775887746",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco: Err, Spike TV. Stupid cable networks.",
  "id" : 775887746,
  "in_reply_to_status_id" : 775884338,
  "created_at" : "2008-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775888322",
  "text" : "DoctorNick (Sam Hum Mal Law), 3340 points, killed by a fall onto poison spikes. That's just garbage.",
  "id" : 775888322,
  "created_at" : "2008-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775890678",
  "text" : "Computer graphics project, or NetHack? Tough choice.",
  "id" : 775890678,
  "created_at" : "2008-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775907268",
  "text" : "Computer graphics project proposal done. Whew!",
  "id" : 775907268,
  "created_at" : "2008-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775907356",
  "text" : "Twitter's web interface seems to double-post quite a lot. Either that or I have an itchy trigger finger.",
  "id" : 775907356,
  "created_at" : "2008-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775945293",
  "text" : "Trying to think about a blog topic...",
  "id" : 775945293,
  "created_at" : "2008-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775207535",
  "text" : "Shelving units do wonders to messy kitchens.",
  "id" : 775207535,
  "created_at" : "2008-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775237175",
  "geo" : { },
  "id_str" : "775241474",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco: Happened to me today too, ftl.",
  "id" : 775241474,
  "in_reply_to_status_id" : 775237175,
  "created_at" : "2008-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775291252",
  "text" : "I can fire rays! And that's about it.",
  "id" : 775291252,
  "created_at" : "2008-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775398529",
  "text" : "Late night coding sprees are starting to affect my health.",
  "id" : 775398529,
  "created_at" : "2008-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775491964",
  "text" : "A clean desk is so much easier to work at.",
  "id" : 775491964,
  "created_at" : "2008-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775554460",
  "text" : "Ray tracing is hard. :(",
  "id" : 775554460,
  "created_at" : "2008-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775114599",
  "geo" : { },
  "id_str" : "775115463",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror HELL YES. So glad I bought Rock Band, Rush + Boston rules.",
  "id" : 775115463,
  "in_reply_to_status_id" : 775114599,
  "created_at" : "2008-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775117900",
  "geo" : { },
  "id_str" : "775119561",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman: Poop.",
  "id" : 775119561,
  "in_reply_to_status_id" : 775117900,
  "created_at" : "2008-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775134617",
  "text" : "Finally opened up Toon Link. Dammit he was hard.",
  "id" : 775134617,
  "created_at" : "2008-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775151809",
  "text" : "Ooh, BarCamp Rochester. I may have to clear that Saturday... http:\/\/www.barcamp.org\/BarCampRochester3",
  "id" : 775151809,
  "created_at" : "2008-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775158650",
  "geo" : { },
  "id_str" : "775164681",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway: Mark the methods as obsolete?",
  "id" : 775164681,
  "in_reply_to_status_id" : 775158650,
  "created_at" : "2008-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775162314",
  "geo" : { },
  "id_str" : "775171618",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman I find them to be extremely useful, the colors are great for finding emails at a glance in my inbox.",
  "id" : 775171618,
  "in_reply_to_status_id" : 775162314,
  "created_at" : "2008-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774758019",
  "text" : "New blag post, pimping the windows command line: http:\/\/tinyurl.com\/33am36",
  "id" : 774758019,
  "created_at" : "2008-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774763572",
  "text" : "41 funny science fair experiments: http:\/\/tinyurl.com\/2fqz3r Dot-com is definitely my favorite.",
  "id" : 774763572,
  "created_at" : "2008-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774782980",
  "geo" : { },
  "id_str" : "774798386",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee: You just earned yourself another reader. Thanks for spending those few minutes explaining a great approach to life and work.",
  "id" : 774798386,
  "in_reply_to_status_id" : 774782980,
  "created_at" : "2008-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774944059",
  "text" : "My ray tracer is slowly killing me.",
  "id" : 774944059,
  "created_at" : "2008-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775058903",
  "text" : "Good friday is truly good when it's a vacation day.",
  "id" : 775058903,
  "created_at" : "2008-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775047416",
  "geo" : { },
  "id_str" : "775060398",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco I'm not sure which is worse, that or the 9 year old who's a sick guitar hero player.",
  "id" : 775060398,
  "in_reply_to_status_id" : 775047416,
  "created_at" : "2008-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775067484",
  "text" : "YouTube pulled my favorite Rush concert, a View from the Palace from their Counterparts tour, and I'm sad.",
  "id" : 775067484,
  "created_at" : "2008-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Allen",
      "screen_name" : "steveswrong",
      "indices" : [ 0, 12 ],
      "id_str" : "14175623",
      "id" : 14175623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775070379",
  "geo" : { },
  "id_str" : "775072722",
  "in_reply_to_user_id" : 14175623,
  "text" : "@steveswrong How dare you deface Rush in the name of Rick Roll.",
  "id" : 775072722,
  "in_reply_to_status_id" : 775070379,
  "created_at" : "2008-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "steveswrong",
  "in_reply_to_user_id_str" : "14175623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775114112",
  "text" : "It's actually a decent, sunny day in Rochester. No gray!",
  "id" : 775114112,
  "created_at" : "2008-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774245439",
  "text" : "Hey Apple Updater: I don't want Safari on Windows. Die in a fire.",
  "id" : 774245439,
  "created_at" : "2008-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774390645",
  "text" : "Staying up until 2am playing with C++ == tired Nick.",
  "id" : 774390645,
  "created_at" : "2008-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774391527",
  "text" : "It really helps if I want to use Google Analytics to include the javascript snippet when I switch blog themes.",
  "id" : 774391527,
  "created_at" : "2008-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774424498",
  "text" : "Keep track of the people who are more important\/famous than you on Twitter: http:\/\/twitter.alltop.com\/",
  "id" : 774424498,
  "created_at" : "2008-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774505428",
  "text" : "Communication classes are a joke.",
  "id" : 774505428,
  "created_at" : "2008-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774506579",
  "text" : "Open command prompt here in Vista rules. http:\/\/tinyurl.com\/3css23",
  "id" : 774506579,
  "created_at" : "2008-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774544822",
  "text" : "RIP Carl Reynolds.",
  "id" : 774544822,
  "created_at" : "2008-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774548888",
  "geo" : { },
  "id_str" : "774550332",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog: Solution, use Google calendar and Gmail :)",
  "id" : 774550332,
  "in_reply_to_status_id" : 774548888,
  "created_at" : "2008-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774588004",
  "text" : "\"forgive the falsetto but Geddy's range often goes beyond human hearing\" best youtube comment ever.",
  "id" : 774588004,
  "created_at" : "2008-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774589581",
  "text" : "A CHALLENGER APPROACHES! The tshirt: http:\/\/tinyurl.com\/2j49rz",
  "id" : 774589581,
  "created_at" : "2008-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774635863",
  "text" : "Oreo: Milk's favorite cookie. http:\/\/tinyurl.com\/34rmbc",
  "id" : 774635863,
  "created_at" : "2008-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774645595",
  "text" : "New Wall-E trailer! http:\/\/tinyurl.com\/2tljbt",
  "id" : 774645595,
  "created_at" : "2008-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773669065",
  "text" : "New blag post: Defraggle rock. http:\/\/tinyurl.com\/2ntsef",
  "id" : 773669065,
  "created_at" : "2008-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773733722",
  "text" : "Defraggle finally finished after 10 or so hours. Time for a restart.",
  "id" : 773733722,
  "created_at" : "2008-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773857199",
  "text" : "I am really starting to hate watching embedded videos in QT or Windows Media Player. Go go flash.",
  "id" : 773857199,
  "created_at" : "2008-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773877895",
  "text" : "Google Summer of Code organizations are up, and once again I'm shafted. http:\/\/tinyurl.com\/33u7df",
  "id" : 773877895,
  "created_at" : "2008-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773916785",
  "geo" : { },
  "id_str" : "773937429",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog Feels like 42 here. So unfair.",
  "id" : 773937429,
  "in_reply_to_status_id" : 773916785,
  "created_at" : "2008-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773938178",
  "text" : "I'm very tempted to install Wordpress 2.5...it looks shiny. http:\/\/tinyurl.com\/35dh54",
  "id" : 773938178,
  "created_at" : "2008-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773960264",
  "text" : "Preparing to get lost in downtown Rochester.",
  "id" : 773960264,
  "created_at" : "2008-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774046370",
  "geo" : { },
  "id_str" : "774049159",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror: Thanks for the advice. I need to invoke Glengarry Ross more often...always be blogging. Coffee is for CLOSERS ONLY.",
  "id" : 774049159,
  "in_reply_to_status_id" : 774046370,
  "created_at" : "2008-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774049361",
  "text" : "Entering the Rochester metropolis in T minus one hour...",
  "id" : 774049361,
  "created_at" : "2008-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774139926",
  "text" : "Rochester is eternally gray. Seriously.",
  "id" : 774139926,
  "created_at" : "2008-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774128464",
  "geo" : { },
  "id_str" : "774139989",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco: Taking the massage class?",
  "id" : 774139989,
  "in_reply_to_status_id" : 774128464,
  "created_at" : "2008-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774140568",
  "geo" : { },
  "id_str" : "774165939",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco I hate you. Even more than Google for having nap pods.",
  "id" : 774165939,
  "in_reply_to_status_id" : 774140568,
  "created_at" : "2008-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774168289",
  "text" : "Ray Tracer checkpoint 1 done, sans rays. And tracing.",
  "id" : 774168289,
  "created_at" : "2008-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773351775",
  "text" : "Should be a) sleeping, b) playing games, but definitely not c) in class.",
  "id" : 773351775,
  "created_at" : "2008-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773589152",
  "text" : "Defraggling for nearly 8 hours now.",
  "id" : 773589152,
  "created_at" : "2008-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772617515",
  "text" : "I really need to stop playing Rock Band and write a blog post instead.",
  "id" : 772617515,
  "created_at" : "2008-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772625687",
  "text" : "I'm turning off the firehose: http:\/\/tinyurl.com\/2rdbn3",
  "id" : 772625687,
  "created_at" : "2008-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 9, 22 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772941950",
  "text" : "Gasp! No @codinghorror blog yet? Perhaps his startup is already sucking up his life...",
  "id" : 772941950,
  "created_at" : "2008-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772945370",
  "text" : "I love my new laptop. More than 5 hours of battery life wins.",
  "id" : 772945370,
  "created_at" : "2008-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772325583",
  "text" : "I need more sleep. A week of it.",
  "id" : 772325583,
  "created_at" : "2008-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772099727",
  "text" : "Bought roses for Amanda from a van near the airport. :)",
  "id" : 772099727,
  "created_at" : "2008-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772099852",
  "text" : "Trying to decide if I should do homework...or play Brawl.",
  "id" : 772099852,
  "created_at" : "2008-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770915312",
  "text" : "I vote to cancel all classes before noon, for eternity. There's just no need for them anymore.",
  "id" : 770915312,
  "created_at" : "2008-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770147904",
  "text" : "New blag post: http:\/\/snurl.com\/21jqo",
  "id" : 770147904,
  "created_at" : "2008-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770444482",
  "text" : "Back in class, and ridiculously hungry. Curse the no food in lab rule.",
  "id" : 770444482,
  "created_at" : "2008-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770454871",
  "text" : "Sweet. I can update my facebook status from Twitter now. Yay for facebook apps.",
  "id" : 770454871,
  "created_at" : "2008-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770595911",
  "text" : "iPhone peggle! http:\/\/tinyurl.com\/2nd7es Actually makes me wish I had that overpriced soap bar for a moment.",
  "id" : 770595911,
  "created_at" : "2008-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770602483",
  "text" : "For every complex problem, there is an answer that is short, simple, and wrong. -H.L. Mencken",
  "id" : 770602483,
  "created_at" : "2008-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770066617",
  "text" : "Dilbert: It's pronounced hay-soos http:\/\/snurl.com\/21jbl",
  "id" : 770066617,
  "created_at" : "2008-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769639646",
  "text" : "New blog post: getting Flash and WPF to work is a pain in the ass, but doable: http:\/\/snurl.com\/21gu9",
  "id" : 769639646,
  "created_at" : "2008-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769927755",
  "geo" : { },
  "id_str" : "769938709",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco very neat, but I'm not sure about its practical use",
  "id" : 769938709,
  "in_reply_to_status_id" : 769927755,
  "created_at" : "2008-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769940380",
  "text" : "I wish facebook status could sync with tweets.",
  "id" : 769940380,
  "created_at" : "2008-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769940383",
  "geo" : { },
  "id_str" : "769944441",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror Hah, have you tried out the IE8 developer tools? They're no where close to Firebug yet.",
  "id" : 769944441,
  "in_reply_to_status_id" : 769940383,
  "created_at" : "2008-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 0, 8 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769953722",
  "geo" : { },
  "id_str" : "769955008",
  "in_reply_to_user_id" : 752673,
  "text" : "@jeresig: Will there be a screencast or possibly transcript of the talk?",
  "id" : 769955008,
  "in_reply_to_status_id" : 769953722,
  "created_at" : "2008-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "jeresig",
  "in_reply_to_user_id_str" : "752673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769969466",
  "text" : "Polimon! I choose you, Barack! http:\/\/i29.tinypic.com\/1zx6ttt.jpg",
  "id" : 769969466,
  "created_at" : "2008-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769992281",
  "text" : "When you are traveling, Do you bring the very more USB cable? Is it very trable ? http:\/\/snurl.com\/21ivs",
  "id" : 769992281,
  "created_at" : "2008-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770009999",
  "text" : "Holy crap, Dropbox looks fantastic. http:\/\/www.getdropbox.com\/",
  "id" : 770009999,
  "created_at" : "2008-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ByronTodd",
      "screen_name" : "ByronTodd",
      "indices" : [ 0, 10 ],
      "id_str" : "7836652",
      "id" : 7836652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770018795",
  "geo" : { },
  "id_str" : "770019720",
  "in_reply_to_user_id" : 7836652,
  "text" : "@ByronTodd I guess nudging on Twitter actually has real life consequences! hah!",
  "id" : 770019720,
  "in_reply_to_status_id" : 770018795,
  "created_at" : "2008-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ByronTodd",
  "in_reply_to_user_id_str" : "7836652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770039243",
  "geo" : { },
  "id_str" : "770040335",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror My favorite: IN THE GRIM FUTURE OF HELLO KITTY THERE IS ONLY WAR.  http:\/\/snurl.com\/21j5l I had to go Reddit with this one.",
  "id" : 770040335,
  "in_reply_to_status_id" : 770039243,
  "created_at" : "2008-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769319368",
  "text" : "I'm back on Twitter. TWhirl is a neat Adobe AIR app!",
  "id" : 769319368,
  "created_at" : "2008-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769319506",
  "text" : "Starting classes again...oh boy.",
  "id" : 769319506,
  "created_at" : "2008-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
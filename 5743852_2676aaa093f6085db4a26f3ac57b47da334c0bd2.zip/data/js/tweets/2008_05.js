Grailbird.data.tweets_2008_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824331218",
  "text" : "Wtf is BrowserPlus? And why does it seem like it could be chock full of security issues? http:\/\/browserplus.yahoo.com\/",
  "id" : 824331218,
  "created_at" : "2008-06-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824331535",
  "text" : "2008 is nearly half over. Where did it go?",
  "id" : 824331535,
  "created_at" : "2008-06-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824438401",
  "text" : "Tried out Beautiful Katamari for the first time, and it's fantastic. There's some innate satisfaction to rolling up people and buildings.",
  "id" : 824438401,
  "created_at" : "2008-06-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824620426",
  "text" : "So, Ruby 1.8.7 is out. Will it work with Rails 2.1? And why isn't http:\/\/rubyonrails.com\/ showing the new release yet?",
  "id" : 824620426,
  "created_at" : "2008-06-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824712589",
  "text" : "Trying out @ablissfulgal's iMac and getting very frustrated even after 5 minutes of use. It's like everything useful was turned upside down.",
  "id" : 824712589,
  "created_at" : "2008-06-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824713260",
  "text" : "Why isn't there a damn VGA port on the back of this iMac. I don't even want to know how much I'll have to shell out to get an extender. Agh.",
  "id" : 824713260,
  "created_at" : "2008-06-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824717141",
  "text" : "This is like relearning how to use a computer all over again. No Alt + D in firefox, now it's Command + L. This isn't going to be easy.",
  "id" : 824717141,
  "created_at" : "2008-06-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824720236",
  "geo" : { },
  "id_str" : "824811658",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn I just started, give me a break!",
  "id" : 824811658,
  "in_reply_to_status_id" : 824720236,
  "created_at" : "2008-06-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Howard",
      "screen_name" : "adrianh",
      "indices" : [ 0, 8 ],
      "id_str" : "23513",
      "id" : 23513
    }, {
      "name" : "mike stedman",
      "screen_name" : "ravuya",
      "indices" : [ 9, 16 ],
      "id_str" : "8939632",
      "id" : 8939632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824796170",
  "geo" : { },
  "id_str" : "824814846",
  "in_reply_to_user_id" : 23513,
  "text" : "@adrianh @ravuya I needed the mini-DVI to DVI, I ended up just picking it up at Best Buy.",
  "id" : 824814846,
  "in_reply_to_status_id" : 824796170,
  "created_at" : "2008-06-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "adrianh",
  "in_reply_to_user_id_str" : "23513",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824815232",
  "text" : "Settling in with the Mac a bit, configuring things to my liking. Still feels strange to me, like it's in control.",
  "id" : 824815232,
  "created_at" : "2008-06-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824816490",
  "geo" : { },
  "id_str" : "824817908",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog I spent a week with Ubuntu, and now a week with OSX. Just wanted to branch out a bit and see if I liked any of the alternatives",
  "id" : 824817908,
  "in_reply_to_status_id" : 824816490,
  "created_at" : "2008-06-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana Taylor",
      "screen_name" : "alanataylor",
      "indices" : [ 0, 12 ],
      "id_str" : "12367712",
      "id" : 12367712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "824761576",
  "geo" : { },
  "id_str" : "824825112",
  "in_reply_to_user_id" : 12367712,
  "text" : "@alanataylor I believe that's called AIM\/MSN\/YIM\/IRC\/Jabber, the list goes on and on and on...",
  "id" : 824825112,
  "in_reply_to_status_id" : 824761576,
  "created_at" : "2008-06-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "alanataylor",
  "in_reply_to_user_id_str" : "12367712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "823993883",
  "text" : "I like Google's new favicon. Something is more friendly about g than G.",
  "id" : 823993883,
  "created_at" : "2008-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824171167",
  "text" : "Setup VNC and accessing Ubuntu remotely. Seems to be a bit slower than I'd like.",
  "id" : 824171167,
  "created_at" : "2008-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "822935627",
  "text" : "Moved my new Unix nerd housemate in. I haven't seen computers this old in years. And he's my age.",
  "id" : 822935627,
  "created_at" : "2008-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "823042464",
  "text" : "Pictures of our commander-in-chief acting like a complete dolt. http:\/\/is.gd\/nYE How many months until January?",
  "id" : 823042464,
  "created_at" : "2008-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "823099047",
  "text" : "Ruby's use of the % operator is crazy. It's not just modulus anymore, baby.",
  "id" : 823099047,
  "created_at" : "2008-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana Taylor",
      "screen_name" : "alanataylor",
      "indices" : [ 0, 12 ],
      "id_str" : "12367712",
      "id" : 12367712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "823051017",
  "geo" : { },
  "id_str" : "823107438",
  "in_reply_to_user_id" : 12367712,
  "text" : "@alanataylor ditch the new blog logo, the glossy button look gives a tacky feel of default photoshop filters\/blend effects",
  "id" : 823107438,
  "in_reply_to_status_id" : 823051017,
  "created_at" : "2008-05-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "alanataylor",
  "in_reply_to_user_id_str" : "12367712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "823450733",
  "text" : "Heading to Buffalo soon for the weekend, if I can ever get out of here. Delicious wings incoming.",
  "id" : 823450733,
  "created_at" : "2008-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "823636118",
  "text" : "Trip to buffalo got shelved until next week since I'm feeling like crap. More Ruby hacking and GTA for me then!",
  "id" : 823636118,
  "created_at" : "2008-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "823641846",
  "text" : "30 tons of lobster lost in Boston fire! http:\/\/www.cnn.com\/2008\/US\/05\/30\/boston.fire.ap\/index.html At least it wasn't Legal Seafood.",
  "id" : 823641846,
  "created_at" : "2008-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "822151210",
  "text" : "I want to know the percentage of RIT grads or coops that end up at MS. It seems like I meet a new one every week.",
  "id" : 822151210,
  "created_at" : "2008-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "822152162",
  "text" : "Double inner joins just seem messy. But they sure do the trick...I really need to cache that query.",
  "id" : 822152162,
  "created_at" : "2008-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "822268693",
  "text" : "LAME. Newegg now must charge for NY state taxes. And ooh, new status tumblr.",
  "id" : 822268693,
  "created_at" : "2008-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "822490502",
  "text" : "NY to recognize gay marriages! http:\/\/www.cnn.com\/2008\/US\/05\/29\/nygay.marriage\/index.html Good news.",
  "id" : 822490502,
  "created_at" : "2008-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "822499506",
  "text" : "http:\/\/www.sarahjessicaparkerlookslikeahorse.com\/",
  "id" : 822499506,
  "created_at" : "2008-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 18, 29 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "822504689",
  "text" : "Awesome post from @shanselman: Is Microsoft losing the Alpha Geeks? http:\/\/www.hanselman.com\/blog\/IsMicrosoftLosingTheAlphaGeeks.aspx",
  "id" : 822504689,
  "created_at" : "2008-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "822613478",
  "text" : "The twitter whale needs a name. I propose 'Failwhale'",
  "id" : 822613478,
  "created_at" : "2008-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "822726145",
  "text" : "Why don't people in GTA understand. Run into my parked cars, and you're gonna get capped.",
  "id" : 822726145,
  "created_at" : "2008-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "822845532",
  "text" : "Spent my $25 gift cert for Barnes and Noble on The Ruby Way. Seeing a trend here?",
  "id" : 822845532,
  "created_at" : "2008-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer P",
      "screen_name" : "jdots24",
      "indices" : [ 0, 8 ],
      "id_str" : "9897172",
      "id" : 9897172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821726897",
  "geo" : { },
  "id_str" : "821727948",
  "in_reply_to_user_id" : 9897172,
  "text" : "@jdots24 That's a feature, not a bug.",
  "id" : 821727948,
  "in_reply_to_status_id" : 821726897,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "jdots24",
  "in_reply_to_user_id_str" : "9897172",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821772549",
  "text" : "Starting lifting again in the morning, first time in nearly a year since I started my big weight loss (went from 215 to now 160ish!)",
  "id" : 821772549,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer P",
      "screen_name" : "jdots24",
      "indices" : [ 0, 8 ],
      "id_str" : "9897172",
      "id" : 9897172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821802426",
  "geo" : { },
  "id_str" : "821805076",
  "in_reply_to_user_id" : 9897172,
  "text" : "@jdots24 Probably, but hey, you go to RIT. Aren't we all in some way or another?",
  "id" : 821805076,
  "in_reply_to_status_id" : 821802426,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "jdots24",
  "in_reply_to_user_id_str" : "9897172",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821826725",
  "text" : "This is fantastic. Write on an LED display over the internet. http:\/\/www.easyjo.com\/led.php",
  "id" : 821826725,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821849903",
  "text" : "One thing I'm loving about Ubuntu: the GNOME environment makes all sorts of UIs very consistent.",
  "id" : 821849903,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821912839",
  "text" : "The Political Machine 2008 shots! http:\/\/is.gd\/n5R I don't know what's more awesome, the Colbert-esque painting or the Drengin campaign.",
  "id" : 821912839,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821911250",
  "geo" : { },
  "id_str" : "821922744",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror Try out a Twitter client like Twhirl or Witty, they'll save the messages you get so you can go through them as you like.",
  "id" : 821922744,
  "in_reply_to_status_id" : 821911250,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821924577",
  "text" : "3 A's and one C for spring quarter. So glad I didn't drop that C class, at least it's over now.",
  "id" : 821924577,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821928157",
  "text" : "Definitely just saw an ad for porn on Facebook. Lovely.",
  "id" : 821928157,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "822068194",
  "text" : "Holy crap, epic rant against TechCrunch and Arrington. This guy is PISSED! http:\/\/is.gd\/nfv",
  "id" : 822068194,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821375876",
  "text" : "Lame, gedit's keyboard shortcuts seem to be hardcoded. I can't use Ctrl+Tab to switch active tabs. Argh!",
  "id" : 821375876,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 78, 84 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821400951",
  "text" : "Jealous of those who are going to railsconf. I'm looking at you, @bjh5537 and @chorn.",
  "id" : 821400951,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "820528944",
  "text" : "2 hours later and still stuck in XP. It would have helped if the ISO I burned didn't mess up and my IDE cable wasn't jammed.",
  "id" : 820528944,
  "created_at" : "2008-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "820578410",
  "text" : "Finally on Ubuntu! Time to customize.",
  "id" : 820578410,
  "created_at" : "2008-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "820604063",
  "text" : "Awesome, I installed Consolas on Ubuntu and now have it as my terminal font. So much for FOSS.",
  "id" : 820604063,
  "created_at" : "2008-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "820649474",
  "text" : "WTF Facebook. Mini-feed cannot be collapsed anymore. I've had it collapsed since they introduced it. BOO.",
  "id" : 820649474,
  "created_at" : "2008-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne K. Halsall",
      "screen_name" : "annekate",
      "indices" : [ 0, 9 ],
      "id_str" : "14061830",
      "id" : 14061830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820654809",
  "geo" : { },
  "id_str" : "820655716",
  "in_reply_to_user_id" : 14061830,
  "text" : "@annekate Fear is the little-death that brings total obliteration. (I registered http:\/\/litanyagainstfear.com for a reason!)",
  "id" : 820655716,
  "in_reply_to_status_id" : 820654809,
  "created_at" : "2008-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "annekate",
  "in_reply_to_user_id_str" : "14061830",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Dowell",
      "screen_name" : "CerebroJD",
      "indices" : [ 0, 10 ],
      "id_str" : "5744302",
      "id" : 5744302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820705399",
  "geo" : { },
  "id_str" : "820977666",
  "in_reply_to_user_id" : 5744302,
  "text" : "@CerebroJD Yep! Still configuring things...getting used to this virtual desktop nonsense.",
  "id" : 820977666,
  "in_reply_to_status_id" : 820705399,
  "created_at" : "2008-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "CerebroJD",
  "in_reply_to_user_id_str" : "5744302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "820978126",
  "text" : "Windows chief manages to say nothing at all about Windows 7 in an interview other than 'we're working on it': http:\/\/is.gd\/mmv",
  "id" : 820978126,
  "created_at" : "2008-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821012978",
  "text" : "Getting twhirl to work on Linux was quite easy. Doesn't seem to be any functional differences, quite good, quite good.",
  "id" : 821012978,
  "created_at" : "2008-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821041821",
  "text" : "Panera's is ridiculously expensive. Which is unfortunate since it's ridicously delicious.",
  "id" : 821041821,
  "created_at" : "2008-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821180901",
  "text" : "Trying to gather ideas to create something new with Rails. I wanted to do something like a family based site...but http:\/\/is.gd\/mxG :(",
  "id" : 821180901,
  "created_at" : "2008-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821230139",
  "text" : "PHP vs Python: http:\/\/tinyurl.com\/69vlrq",
  "id" : 821230139,
  "created_at" : "2008-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819826374",
  "text" : "We set a log on fire that was home to a bunch of ants. They're freaking out. Then again, I would freak out if my home was on fire too.",
  "id" : 819826374,
  "created_at" : "2008-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "820468129",
  "text" : "Home after a long weekend in OH! And hurray, the new Reddit is alive. http:\/\/reddit.com",
  "id" : 820468129,
  "created_at" : "2008-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Recordon",
      "screen_name" : "daveman692",
      "indices" : [ 0, 11 ],
      "id_str" : "744463",
      "id" : 744463
    }, {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 26, 39 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820440859",
  "geo" : { },
  "id_str" : "820480512",
  "in_reply_to_user_id" : 744463,
  "text" : "@daveman692 Have you seen @codinghorror's latest opus on OpenID? http:\/\/www.codinghorror.com\/blog\/archives\/001121.html",
  "id" : 820480512,
  "in_reply_to_status_id" : 820440859,
  "created_at" : "2008-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "daveman692",
  "in_reply_to_user_id_str" : "744463",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "820483287",
  "text" : "Taking the plunge and installing Ubuntu on a spare hard drive. Here we go!",
  "id" : 820483287,
  "created_at" : "2008-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819745595",
  "text" : "Getting ready for a pretty huge bonfire. Woot!",
  "id" : 819745595,
  "created_at" : "2008-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819753039",
  "text" : "I passed the class I hated! WOOT.",
  "id" : 819753039,
  "created_at" : "2008-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Reynolds",
      "screen_name" : "scottcreynolds",
      "indices" : [ 0, 15 ],
      "id_str" : "441985676",
      "id" : 441985676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819753648",
  "text" : "@scottcreynolds Yes, and I bought this shirt because of it: http:\/\/tinyurl.com\/6yvywh",
  "id" : 819753648,
  "created_at" : "2008-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "NateLewis",
      "indices" : [ 0, 10 ],
      "id_str" : "4614511",
      "id" : 4614511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819722048",
  "geo" : { },
  "id_str" : "819753910",
  "in_reply_to_user_id" : 4614511,
  "text" : "@NateLewis I'm from Buffalo, but @ablissfulgal's family now lives near Grove City but in OH.",
  "id" : 819753910,
  "in_reply_to_status_id" : 819722048,
  "created_at" : "2008-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "NateLewis",
  "in_reply_to_user_id_str" : "4614511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819764179",
  "text" : "Scary article about the future without IPv6. I sure hope this doesn't happen. http:\/\/tinyurl.com\/6azflz",
  "id" : 819764179,
  "created_at" : "2008-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819791907",
  "text" : "Bonfire time! I better stop stealing the neighbor's wifi. Or move closer to the fire and still steal the wifi.",
  "id" : 819791907,
  "created_at" : "2008-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818702734",
  "text" : "Indiana Jones was AWESOME.",
  "id" : 818702734,
  "created_at" : "2008-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819221072",
  "text" : "2 days, 2 dinners, 2 buffets. i am so full. roll me home plzkthx",
  "id" : 819221072,
  "created_at" : "2008-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "817999735",
  "text" : "Made it to Ohio after 4 hours of driving, and completely sick of dealing with semis on truck routes. Also, truck stops smell horrible.",
  "id" : 817999735,
  "created_at" : "2008-05-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818004542",
  "text" : "There's no greater joy than leeching wifi from an SSID named \"linksys\" and logging into the router configuration. Luckily, I'm not evil.",
  "id" : 818004542,
  "created_at" : "2008-05-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Hahn",
      "screen_name" : "GauntletWizard",
      "indices" : [ 0, 15 ],
      "id_str" : "14006082",
      "id" : 14006082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "818015068",
  "geo" : { },
  "id_str" : "818016922",
  "in_reply_to_user_id" : 14006082,
  "text" : "@GauntletWizard Did he start the conversation with \"I herd you like mudkips?\"",
  "id" : 818016922,
  "in_reply_to_status_id" : 818015068,
  "created_at" : "2008-05-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "GauntletWizard",
  "in_reply_to_user_id_str" : "14006082",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818018359",
  "text" : "Hooking up wordpress with the WP-OpenID plugin, very seamless and painless so far. Centralization of identity management ftw",
  "id" : 818018359,
  "created_at" : "2008-05-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818032343",
  "text" : "New blog post for the first time in months! Showing off some of my computer graphics projects for this quarter. http:\/\/is.gd\/kEd",
  "id" : 818032343,
  "created_at" : "2008-05-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818400158",
  "text" : "Reconnecting with the original Zelda for NES. I hate Tektites SO MUCH.",
  "id" : 818400158,
  "created_at" : "2008-05-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818481736",
  "text" : "Shopping in Grove City, PA for the first time. Consumerism overload.",
  "id" : 818481736,
  "created_at" : "2008-05-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "817063033",
  "text" : "I'm considering an experiment this summer, trying out OSX for a week, and then trying out Ubuntu for a week. Scary, but I want to try.",
  "id" : 817063033,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "817063698",
  "geo" : { },
  "id_str" : "817065591",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco Spoiler alert: I like gaming too much to ditch Windows. Also I don't think my gf's mac has the latest OSX.",
  "id" : 817065591,
  "in_reply_to_status_id" : 817063698,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "817449482",
  "text" : "A somewhat 3D RSS reader\/aggregator from MSNBC: http:\/\/msnbcmedia.msn.com\/i\/\/msnbc\/Components\/spectra\/index.html",
  "id" : 817449482,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Zehnder Rossi",
      "screen_name" : "shawnz",
      "indices" : [ 0, 7 ],
      "id_str" : "7789282",
      "id" : 7789282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "817458909",
  "geo" : { },
  "id_str" : "817459828",
  "in_reply_to_user_id" : 7789282,
  "text" : "@shawnz Not a fan of the chocolate shake from Wendy's, it's just a frosty with chocolate syrup added in.",
  "id" : 817459828,
  "in_reply_to_status_id" : 817458909,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "shawnz",
  "in_reply_to_user_id_str" : "7789282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "817495627",
  "text" : "Done with exams, but I never feel done until grades are in.",
  "id" : 817495627,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Younge",
      "screen_name" : "ayounge",
      "indices" : [ 0, 8 ],
      "id_str" : "14746618",
      "id" : 14746618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "817503934",
  "geo" : { },
  "id_str" : "817507755",
  "in_reply_to_user_id" : 14746618,
  "text" : "@ayounge Because I've been using Windows forever, that's pretty much it.",
  "id" : 817507755,
  "in_reply_to_status_id" : 817503934,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ayounge",
  "in_reply_to_user_id_str" : "14746618",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "817583150",
  "text" : "Reddit's beta is continually looking better. http:\/\/www.beta.reddit.com\/",
  "id" : 817583150,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "817594798",
  "geo" : { },
  "id_str" : "817596743",
  "in_reply_to_user_id" : 7488582,
  "text" : "@runeinalya Story of my life.",
  "id" : 817596743,
  "in_reply_to_status_id" : 817594798,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "sela_davis",
  "in_reply_to_user_id_str" : "7488582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kodak Alaris SM MGR",
      "screen_name" : "kodakCB",
      "indices" : [ 0, 8 ],
      "id_str" : "14590903",
      "id" : 14590903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "817641501",
  "geo" : { },
  "id_str" : "817659363",
  "in_reply_to_user_id" : 14590903,
  "text" : "@kodakCB I can't see the blimp from out in Henrietta, I have a clear view of downtown though. And the typical overcast Rochester skies.",
  "id" : 817659363,
  "in_reply_to_status_id" : 817641501,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "kodakCB",
  "in_reply_to_user_id_str" : "14590903",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "817697127",
  "text" : "Twitter's JSON seems to take forever to load on my blog. Maybe I should figure out how to cache it. or not.",
  "id" : 817697127,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "817706993",
  "text" : "Awesome post about building a scalable microblogging service that the Twitter devs linked to. TC needs to read this. http:\/\/is.gd\/fN6",
  "id" : 817706993,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Finkler",
      "screen_name" : "funkatron",
      "indices" : [ 0, 10 ],
      "id_str" : "65583",
      "id" : 65583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "817707495",
  "geo" : { },
  "id_str" : "817708683",
  "in_reply_to_user_id" : 65583,
  "text" : "@funkatron It bothers me too, but I am learning a lot from the discussion. Mostly about how not to be an assuming moron, though. :)",
  "id" : 817708683,
  "in_reply_to_status_id" : 817707495,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "funkatron",
  "in_reply_to_user_id_str" : "65583",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "817768014",
  "text" : "Preparing for a lovely 4 hour drive out to Ohio. Going off the grid! GASP.",
  "id" : 817768014,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816900204",
  "geo" : { },
  "id_str" : "816905587",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense FF Tactics!!! AWESOME. I hope they've got multiplayer.",
  "id" : 816905587,
  "in_reply_to_status_id" : 816900204,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816906345",
  "geo" : { },
  "id_str" : "816907476",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense I better be able to create a red mage\/summoner that can doublecast huge summons still. FFTA was such an awesome game.",
  "id" : 816907476,
  "in_reply_to_status_id" : 816906345,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Kelly",
      "screen_name" : "inkedmn",
      "indices" : [ 0, 8 ],
      "id_str" : "2844098929",
      "id" : 2844098929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816906417",
  "geo" : { },
  "id_str" : "816911719",
  "in_reply_to_user_id" : 434883,
  "text" : "@inkedmn Engineer is my favorite if you couldn't tell from my previous avatar. Something about autonomously fragging people is awesome to me",
  "id" : 816911719,
  "in_reply_to_status_id" : 816906417,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrbrettkelly",
  "in_reply_to_user_id_str" : "434883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816918559",
  "text" : "Computer Vision project that autonomously plays Rock Band. http:\/\/www.vimeo.com\/1045326",
  "id" : 816918559,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816930133",
  "geo" : { },
  "id_str" : "816935356",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense On PS, sadly no. I think my brother had it, but we 'donated' our ps2 after several months\/years of not using it to my high school",
  "id" : 816935356,
  "in_reply_to_status_id" : 816930133,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816163909",
  "text" : "An hour of fighting and I've got subversion working through apache again. Huzzah! Now to set up SSL.",
  "id" : 816163909,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816196114",
  "text" : "Yay, SSL is working. Firefox is quite bitchy when it finds a self-signed SSL, but whatever, it's my site.",
  "id" : 816196114,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816278067",
  "text" : "Great success! SVN is set up with apache via mod_dav, SSL is enabled, and I've applied an awesome XSLT to make the web interface all purdy.",
  "id" : 816278067,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816480364",
  "text" : "8am exams FTL.",
  "id" : 816480364,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816514346",
  "text" : "I LOVE PUPPIES. I HATE STEPPING IN THEIR POO.",
  "id" : 816514346,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816581853",
  "text" : "Awesome, I just won $25 in a Barnes and Noble gift certificate for my Renderman image: http:\/\/is.gd\/jC4",
  "id" : 816581853,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816668550",
  "geo" : { },
  "id_str" : "816669623",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense pleasepleasepleaseplease dont be an mmo",
  "id" : 816669623,
  "in_reply_to_status_id" : 816668550,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816674610",
  "text" : "46, feels like 40 out in Rochester today. WTF",
  "id" : 816674610,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sutton",
      "screen_name" : "KellySutton",
      "indices" : [ 0, 12 ],
      "id_str" : "2232241",
      "id" : 2232241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816695583",
  "geo" : { },
  "id_str" : "816704751",
  "in_reply_to_user_id" : 2232241,
  "text" : "@KellySutton Get an internship in your field! Don't sit around doing jack squat, or else you might end up living in a VAN DOWN BY THE RIVER!",
  "id" : 816704751,
  "in_reply_to_status_id" : 816695583,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "KellySutton",
  "in_reply_to_user_id_str" : "2232241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816713187",
  "text" : "Burger King to offer huge burger meant to feed 6 people and compete with pizza. Tear off your burger from it. Gross. http:\/\/is.gd\/jFg",
  "id" : 816713187,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kodak Alaris SM MGR",
      "screen_name" : "kodakCB",
      "indices" : [ 0, 8 ],
      "id_str" : "14590903",
      "id" : 14590903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816779051",
  "geo" : { },
  "id_str" : "816780603",
  "in_reply_to_user_id" : 14590903,
  "text" : "@kodakCB Heh, you don't come by RIT enough, there's an anime club full of people who love doing this stuff.",
  "id" : 816780603,
  "in_reply_to_status_id" : 816779051,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "kodakCB",
  "in_reply_to_user_id_str" : "14590903",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Le",
      "screen_name" : "a7an",
      "indices" : [ 0, 5 ],
      "id_str" : "758185",
      "id" : 758185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816834275",
  "geo" : { },
  "id_str" : "816836454",
  "in_reply_to_user_id" : 758185,
  "text" : "@a7an My brain, if you have a better system, let me know.",
  "id" : 816836454,
  "in_reply_to_status_id" : 816834275,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "a7an",
  "in_reply_to_user_id_str" : "758185",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer P",
      "screen_name" : "jdots24",
      "indices" : [ 0, 8 ],
      "id_str" : "9897172",
      "id" : 9897172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816843029",
  "geo" : { },
  "id_str" : "816844953",
  "in_reply_to_user_id" : 9897172,
  "text" : "@jdots24 The what? If it's anything like MyCourses, I care not.",
  "id" : 816844953,
  "in_reply_to_status_id" : 816843029,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "jdots24",
  "in_reply_to_user_id_str" : "9897172",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816847818",
  "text" : "When code works the first time, it's a thing of beauty. And worry.",
  "id" : 816847818,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer P",
      "screen_name" : "jdots24",
      "indices" : [ 0, 8 ],
      "id_str" : "9897172",
      "id" : 9897172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816848548",
  "geo" : { },
  "id_str" : "816850542",
  "in_reply_to_user_id" : 9897172,
  "text" : "@jdots24 Sort of like...http:\/\/drop.io ?",
  "id" : 816850542,
  "in_reply_to_status_id" : 816848548,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "jdots24",
  "in_reply_to_user_id_str" : "9897172",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Younge",
      "screen_name" : "ayounge",
      "indices" : [ 0, 8 ],
      "id_str" : "14746618",
      "id" : 14746618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816867774",
  "geo" : { },
  "id_str" : "816871590",
  "in_reply_to_user_id" : 14746618,
  "text" : "@ayounge One more exam here :(",
  "id" : 816871590,
  "in_reply_to_status_id" : 816867774,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "ayounge",
  "in_reply_to_user_id_str" : "14746618",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816874912",
  "text" : "It seems that every time I open Filezilla there's a new beta waiting for me to download.",
  "id" : 816874912,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Foord",
      "screen_name" : "voidspace",
      "indices" : [ 0, 10 ],
      "id_str" : "11486902",
      "id" : 11486902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816887656",
  "geo" : { },
  "id_str" : "816897068",
  "in_reply_to_user_id" : 11486902,
  "text" : "@voidspace http:\/\/www.deepthoughtsbyjackhandey.com\/today.asp",
  "id" : 816897068,
  "in_reply_to_status_id" : 816887656,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "voidspace",
  "in_reply_to_user_id_str" : "11486902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816904613",
  "text" : "Trying to figure out wtf this site is about. Looks like cuneiform to me. http:\/\/chishio.jp\/",
  "id" : 816904613,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "816900204",
  "geo" : { },
  "id_str" : "816905082",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense OH MAN.",
  "id" : 816905082,
  "in_reply_to_status_id" : 816900204,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815359837",
  "text" : "Rediscovering my ipod after several months of dust collecting. Going to be essential to surviving my summer internship, methinks.",
  "id" : 815359837,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815366079",
  "geo" : { },
  "id_str" : "815372508",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror May I suggest RapidSVN, a pretty solid client app from Tigris, where SVN was brewed: http:\/\/rapidsvn.tigris.org",
  "id" : 815372508,
  "in_reply_to_status_id" : 815366079,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Brogan",
      "screen_name" : "chrisbrogan",
      "indices" : [ 0, 12 ],
      "id_str" : "10202",
      "id" : 10202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815394707",
  "geo" : { },
  "id_str" : "815396083",
  "in_reply_to_user_id" : 10202,
  "text" : "@chrisbrogan Books. I'd take a physical novel over a hastily written, SEO driven, and possibly ad-ridden blog any day.",
  "id" : 815396083,
  "in_reply_to_status_id" : 815394707,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "chrisbrogan",
  "in_reply_to_user_id_str" : "10202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Younge",
      "screen_name" : "ayounge",
      "indices" : [ 0, 8 ],
      "id_str" : "14746618",
      "id" : 14746618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815408904",
  "geo" : { },
  "id_str" : "815411359",
  "in_reply_to_user_id" : 14746618,
  "text" : "@ayounge I'm surprised the guy calmly walked out. If he was in an american college the dude would have been tackled or tasered.",
  "id" : 815411359,
  "in_reply_to_status_id" : 815408904,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ayounge",
  "in_reply_to_user_id_str" : "14746618",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815413629",
  "text" : "I'm looking at material for my exam tomorrow, but absorbing none of it. NOT GOOD.",
  "id" : 815413629,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen T. Colbert",
      "screen_name" : "StephenTColbert",
      "indices" : [ 0, 16 ],
      "id_str" : "12750862",
      "id" : 12750862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815414949",
  "geo" : { },
  "id_str" : "815417151",
  "in_reply_to_user_id" : 12750862,
  "text" : "@StephenTColbert Sell it. 10k followers = money!",
  "id" : 815417151,
  "in_reply_to_status_id" : 815414949,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "StephenTColbert",
  "in_reply_to_user_id_str" : "12750862",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815450587",
  "text" : "One of @ablissfulgal's roommates has a siberian husky mix puppy that's 8 weeks old. Damn cutest thing I've ever seen.",
  "id" : 815450587,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815453470",
  "text" : "I choose producer. http:\/\/is.gd\/iUx",
  "id" : 815453470,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815456946",
  "text" : "Put that coffee down. COFFEE IS FOR CLOSERS ONLY.",
  "id" : 815456946,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815467031",
  "text" : "Looking into Ruby on Rails CMS systems...all I can seem to find is Comatose (updated last year) and Typo (a blog). Any other suggestions?",
  "id" : 815467031,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Fitton",
      "screen_name" : "Pistachio",
      "indices" : [ 0, 10 ],
      "id_str" : "3533231",
      "id" : 3533231
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 16, 28 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815492588",
  "geo" : { },
  "id_str" : "815494138",
  "in_reply_to_user_id" : 3533231,
  "text" : "@Pistachio That @BarackObama uses it, among thousands others, to connect with new people and make new contacts.",
  "id" : 815494138,
  "in_reply_to_status_id" : 815492588,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "Pistachio",
  "in_reply_to_user_id_str" : "3533231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Pike",
      "screen_name" : "npike",
      "indices" : [ 0, 6 ],
      "id_str" : "13056112",
      "id" : 13056112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815774031",
  "geo" : { },
  "id_str" : "815777749",
  "in_reply_to_user_id" : 13056112,
  "text" : "@npike Better than the ones who trudge around in GCCIS with no shoes, and go in the bathrooms.",
  "id" : 815777749,
  "in_reply_to_status_id" : 815774031,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "npike",
  "in_reply_to_user_id_str" : "13056112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Ross",
      "screen_name" : "RossCode",
      "indices" : [ 0, 9 ],
      "id_str" : "5742002",
      "id" : 5742002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815787908",
  "geo" : { },
  "id_str" : "815790836",
  "in_reply_to_user_id" : 5742002,
  "text" : "@RossCode Self-closing is way better. Less markup and fugly asp.net tags.",
  "id" : 815790836,
  "in_reply_to_status_id" : 815787908,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "RossCode",
  "in_reply_to_user_id_str" : "5742002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815881230",
  "text" : "Listening to Rusty Schweickart talking about the Asteroid Threat in the next 100,000 years. Some real doomsday stuff, scary but fascinating.",
  "id" : 815881230,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815989562",
  "text" : "1 exam down, 1 to go.",
  "id" : 815989562,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815990025",
  "text" : "DeviantART fella plushie is cute. http:\/\/tinyurl.com\/ytmcsh",
  "id" : 815990025,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816079532",
  "text" : "Attempting some Tone Reproduction with my raytracer, and failing.",
  "id" : 816079532,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815228230",
  "geo" : { },
  "id_str" : "815231293",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway Thanks for the retweet. It seems like a drastic weeding out practice. I wonder what their overall turnover is. (post-offer)",
  "id" : 815231293,
  "in_reply_to_status_id" : 815228230,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815233197",
  "text" : "Ballmer egged at Hungarian University. http:\/\/is.gd\/iLG Not enough DEVELOPERS DEVELOPERS DEVELOPERS obviously.",
  "id" : 815233197,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Daniel",
      "screen_name" : "jack_daniel",
      "indices" : [ 0, 12 ],
      "id_str" : "7025212",
      "id" : 7025212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815243608",
  "geo" : { },
  "id_str" : "815243910",
  "in_reply_to_user_id" : 7025212,
  "text" : "@jack_daniel The real challenge will be finding the Norway pavilion.",
  "id" : 815243910,
  "in_reply_to_status_id" : 815243608,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "jack_daniel",
  "in_reply_to_user_id_str" : "7025212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Aldrich",
      "screen_name" : "randyaa",
      "indices" : [ 0, 8 ],
      "id_str" : "981291",
      "id" : 981291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815252256",
  "geo" : { },
  "id_str" : "815254403",
  "in_reply_to_user_id" : 981291,
  "text" : "@randyaa What will that solve?",
  "id" : 815254403,
  "in_reply_to_status_id" : 815252256,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "randyaa",
  "in_reply_to_user_id_str" : "981291",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Flauaus",
      "screen_name" : "zachflauaus",
      "indices" : [ 0, 12 ],
      "id_str" : "6839272",
      "id" : 6839272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815254519",
  "geo" : { },
  "id_str" : "815256603",
  "in_reply_to_user_id" : 6839272,
  "text" : "@zachflauaus That's just dumb. It's a free service, no ads, ffs, what will a 'tweet-out' solve?",
  "id" : 815256603,
  "in_reply_to_status_id" : 815254519,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "zachflauaus",
  "in_reply_to_user_id_str" : "6839272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Flauaus",
      "screen_name" : "zachflauaus",
      "indices" : [ 0, 12 ],
      "id_str" : "6839272",
      "id" : 6839272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815258589",
  "geo" : { },
  "id_str" : "815259919",
  "in_reply_to_user_id" : 6839272,
  "text" : "@zachflauaus Reliability is an issue. I'm 100% sure they are aware. 10 minutes today and a few hours the other day is not cause for revolt.",
  "id" : 815259919,
  "in_reply_to_status_id" : 815258589,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "zachflauaus",
  "in_reply_to_user_id_str" : "6839272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815263596",
  "text" : "To anyone bitching about Twitter reliability: STFU. It's a free service with no ads. Be grateful for what it brings us and support the devs.",
  "id" : 815263596,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815264964",
  "geo" : { },
  "id_str" : "815265549",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway I hear that, I'd pay for it in a heartbeat. I'm sure any fervent user would.",
  "id" : 815265549,
  "in_reply_to_status_id" : 815264964,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 0, 7 ],
      "id_str" : "6118872",
      "id" : 6118872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815266786",
  "geo" : { },
  "id_str" : "815268590",
  "in_reply_to_user_id" : 6118872,
  "text" : "@zoomba Everyone's waiting for their sustainable business plan, if that's it and it works, so be it.",
  "id" : 815268590,
  "in_reply_to_status_id" : 815266786,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "zoomba",
  "in_reply_to_user_id_str" : "6118872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dwight silverman",
      "screen_name" : "dsilverman",
      "indices" : [ 0, 11 ],
      "id_str" : "1010181",
      "id" : 1010181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815269257",
  "geo" : { },
  "id_str" : "815273738",
  "in_reply_to_user_id" : 1010181,
  "text" : "@dsilverman If MS buys Facebook, think there will be a mass exodus? I doubt I would delete my profile, too many people I know use it daily.",
  "id" : 815273738,
  "in_reply_to_status_id" : 815269257,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "dsilverman",
  "in_reply_to_user_id_str" : "1010181",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen T. Colbert",
      "screen_name" : "StephenTColbert",
      "indices" : [ 17, 33 ],
      "id_str" : "12750862",
      "id" : 12750862
    }, {
      "name" : "Jebus",
      "screen_name" : "tweetjebus",
      "indices" : [ 56, 67 ],
      "id_str" : "40735560",
      "id" : 40735560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815277853",
  "text" : "http:\/\/is.gd\/iO9 @StephenTColbert is fake. What's next? @TweetJebus EXPOSED AS A FRAUD!",
  "id" : 815277853,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815279604",
  "text" : "Japanese version of the Office for those who missed it on SNL: http:\/\/is.gd\/iqg",
  "id" : 815279604,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815317072",
  "text" : "Flatout wraps suck.",
  "id" : 815317072,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "814539673",
  "text" : "I can't export links from my old WP site to my new one. Lame.",
  "id" : 814539673,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Stoner",
      "screen_name" : "maslowbeer",
      "indices" : [ 0, 11 ],
      "id_str" : "13749072",
      "id" : 13749072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "814545728",
  "geo" : { },
  "id_str" : "814547853",
  "in_reply_to_user_id" : 13749072,
  "text" : "@maslowbeer Not a big deal, I needed to define XFN relationships anyway",
  "id" : 814547853,
  "in_reply_to_status_id" : 814545728,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "maslowbeer",
  "in_reply_to_user_id_str" : "13749072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shella",
      "screen_name" : "Shella",
      "indices" : [ 0, 7 ],
      "id_str" : "814306",
      "id" : 814306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "814604071",
  "geo" : { },
  "id_str" : "814614071",
  "in_reply_to_user_id" : 814306,
  "text" : "@Shella I'll get to studying too. At some point. Or never.",
  "id" : 814614071,
  "in_reply_to_status_id" : 814604071,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "Shella",
  "in_reply_to_user_id_str" : "814306",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "814614401",
  "text" : "Yay, blog is now on Slicehost, and I updated my theme. Now to actually start blogging again. http:\/\/litanyagainstfear.com\/",
  "id" : 814614401,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Fisher",
      "screen_name" : "Nick",
      "indices" : [ 0, 5 ],
      "id_str" : "181851585",
      "id" : 181851585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "814619700",
  "geo" : { },
  "id_str" : "814623876",
  "in_reply_to_user_id" : 1084,
  "text" : "@nick shares my name and follows me. why aren't you following him? i promise you dont need to share his name either.",
  "id" : 814623876,
  "in_reply_to_status_id" : 814619700,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "toomuchnick",
  "in_reply_to_user_id_str" : "1084",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "814624540",
  "text" : "mod_rails (Passenger) has the most beautiful error messages I've ever seen on a website. http:\/\/is.gd\/inR",
  "id" : 814624540,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pawe\u0142 Szymczykowski",
      "screen_name" : "makenai",
      "indices" : [ 0, 8 ],
      "id_str" : "4569381",
      "id" : 4569381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "814623488",
  "geo" : { },
  "id_str" : "814624974",
  "in_reply_to_user_id" : 4569381,
  "text" : "@makenai I'm still trying to chug my way through CC2. I tend to get 50-100 pgs into any programming book then stop.",
  "id" : 814624974,
  "in_reply_to_status_id" : 814623488,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "makenai",
  "in_reply_to_user_id_str" : "4569381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "814665052",
  "text" : "Reading the personal \"Rails Way\" testimonies in the back of The Rails Way is damn inspiring. I need to get my rails site published this week",
  "id" : 814665052,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gapingvoid",
      "screen_name" : "gapingvoid",
      "indices" : [ 0, 11 ],
      "id_str" : "72982024",
      "id" : 72982024
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "814903143",
  "geo" : { },
  "id_str" : "814908333",
  "in_reply_to_user_id" : 50193,
  "text" : "@gapingvoid I love your cartoons, but your blog is majorly messed up in IE7. The sidebar bleeds over halfway down the page.",
  "id" : 814908333,
  "in_reply_to_status_id" : 814903143,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "hughcartoons",
  "in_reply_to_user_id_str" : "50193",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Wardell",
      "screen_name" : "draginol",
      "indices" : [ 70, 79 ],
      "id_str" : "13972382",
      "id" : 13972382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "814910814",
  "text" : "Stardock's new app Impulse is in Game Informer this month, along with @draginol's plan to fix PC gaming. I worked on it! That's awesome.",
  "id" : 814910814,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer P",
      "screen_name" : "jdots24",
      "indices" : [ 0, 8 ],
      "id_str" : "9897172",
      "id" : 9897172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "814928284",
  "geo" : { },
  "id_str" : "814937537",
  "in_reply_to_user_id" : 9897172,
  "text" : "@jdots24 I'm so glad I don't have to take that class. I love me some Ruby, but everytime I start seeing the parens of Lisp I get scared.",
  "id" : 814937537,
  "in_reply_to_status_id" : 814928284,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "jdots24",
  "in_reply_to_user_id_str" : "9897172",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellie Banks",
      "screen_name" : "iEllie",
      "indices" : [ 5, 12 ],
      "id_str" : "8111452",
      "id" : 8111452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "814938580",
  "text" : "From @iellie: Facebook set for a major facelift. How much longer until it's actually MySpace? http:\/\/is.gd\/ixf",
  "id" : 814938580,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dwight silverman",
      "screen_name" : "dsilverman",
      "indices" : [ 11, 22 ],
      "id_str" : "1010181",
      "id" : 1010181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "814950888",
  "text" : "Retweeting @dsilverman: Twitter matters. http:\/\/tinyurl.com\/5x5cxz But you knew that.",
  "id" : 814950888,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 11, 21 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "814957751",
  "text" : "Retweeting @IslandDog: Game Informer article about Stardock and Impulse.  http:\/\/twurl.nl\/4psv0o",
  "id" : 814957751,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JComboBox",
      "screen_name" : "JComboBox",
      "indices" : [ 0, 10 ],
      "id_str" : "14198120",
      "id" : 14198120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "814992151",
  "geo" : { },
  "id_str" : "815009144",
  "in_reply_to_user_id" : 14198120,
  "text" : "@JComboBox I got my tickets for last year's Rush concert through craigslist, and I fully expect to do the same this year. What did you get?",
  "id" : 815009144,
  "in_reply_to_status_id" : 814992151,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "JComboBox",
  "in_reply_to_user_id_str" : "14198120",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815034360",
  "text" : "Retweeting @ablissfulgal: It is OMFG Cold in Roch today... I CONCUR.",
  "id" : 815034360,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815035395",
  "text" : "Truck loaded with (14 tons of) Oreos overturns after driver falls asleep. NOOOOOO! http:\/\/www.msnbc.msn.com\/id\/24707718\/",
  "id" : 815035395,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815047812",
  "text" : "StrawPoll's interface completely kicks the crap out of a voting site I've been working on for twitter.",
  "id" : 815047812,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815048683",
  "text" : "I guess the challenge will be to figure out how to beat it then! :)",
  "id" : 815048683,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815072288",
  "geo" : { },
  "id_str" : "815074561",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog Wtf is Twingly?",
  "id" : 815074561,
  "in_reply_to_status_id" : 815072288,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lance white",
      "screen_name" : "fallenrogue",
      "indices" : [ 0, 12 ],
      "id_str" : "378588370",
      "id" : 378588370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815107505",
  "text" : "@fallenrogue I think i'd rather know that something IS loading rather than the previous blank page.",
  "id" : 815107505,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815087170",
  "geo" : { },
  "id_str" : "815110705",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Just wait, that will soon be transformed into a Night Elf and be sold by Blizzard for millions.",
  "id" : 815110705,
  "in_reply_to_status_id" : 815087170,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TweetTees",
      "screen_name" : "TweetTees",
      "indices" : [ 0, 10 ],
      "id_str" : "14237465",
      "id" : 14237465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815126502",
  "geo" : { },
  "id_str" : "815128269",
  "in_reply_to_user_id" : 14237465,
  "text" : "@TweetTees Respond in Comic Sans.",
  "id" : 815128269,
  "in_reply_to_status_id" : 815126502,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "TweetTees",
  "in_reply_to_user_id_str" : "14237465",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815139798",
  "geo" : { },
  "id_str" : "815143083",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco Will you be taking them again sometime, or are you just gonna keep the fulltime gig?",
  "id" : 815143083,
  "in_reply_to_status_id" : 815139798,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815172433",
  "text" : "Horrible shopped picture on MSN.com: http:\/\/stb.msn.com\/i\/1D\/9C4AFA321F373C247FF56F65B4F1.jpg Definitely 2 different people there.",
  "id" : 815172433,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815185879",
  "text" : "Google....Health? I trust them with my email, but I'm not so sure about this. http:\/\/is.gd\/iJ5",
  "id" : 815185879,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Le",
      "screen_name" : "a7an",
      "indices" : [ 11, 16 ],
      "id_str" : "758185",
      "id" : 758185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815201230",
  "text" : "Retweeting @a7an: rick-roll can help stop babies from crying. lol http:\/\/tinyurl.com\/5t95j5",
  "id" : 815201230,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Briggs",
      "screen_name" : "briggsb",
      "indices" : [ 0, 8 ],
      "id_str" : "1563671",
      "id" : 1563671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815199287",
  "geo" : { },
  "id_str" : "815202600",
  "in_reply_to_user_id" : 1563671,
  "text" : "@briggsb You need to set your default internet browser, go to Control Panel &gt; Add or Remove Programs &gt; Set Program Access and Defaults",
  "id" : 815202600,
  "in_reply_to_status_id" : 815199287,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "briggsb",
  "in_reply_to_user_id_str" : "1563671",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zappos",
      "screen_name" : "zappos",
      "indices" : [ 39, 46 ],
      "id_str" : "338601496",
      "id" : 338601496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815210070",
  "text" : "What an interesting business practice. @Zappos employees go through 4 weeks of training, then are offered $1k to quit. http:\/\/is.gd\/iKh",
  "id" : 815210070,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813879062",
  "text" : "Kids in public school in MN now has 'no touch rule'. No touching even for tag. http:\/\/is.gd\/i29 Public schools suck.",
  "id" : 813879062,
  "created_at" : "2008-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813882343",
  "text" : "Saturdays go too damn fast. I demand a refund.",
  "id" : 813882343,
  "created_at" : "2008-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813883244",
  "geo" : { },
  "id_str" : "813883363",
  "in_reply_to_user_id" : 1388411,
  "text" : "@TheADOGuy I can call him for a heli-ride, but I didn't know he'd BRING you one. Damn.",
  "id" : 813883363,
  "in_reply_to_status_id" : 813883244,
  "created_at" : "2008-05-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ShawnWildermuth",
  "in_reply_to_user_id_str" : "1388411",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Dowell",
      "screen_name" : "CerebroJD",
      "indices" : [ 0, 10 ],
      "id_str" : "5744302",
      "id" : 5744302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813883805",
  "geo" : { },
  "id_str" : "813885102",
  "in_reply_to_user_id" : 5744302,
  "text" : "@CerebroJD Welcome to america!",
  "id" : 813885102,
  "in_reply_to_status_id" : 813883805,
  "created_at" : "2008-05-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "CerebroJD",
  "in_reply_to_user_id_str" : "5744302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813898863",
  "text" : "indiana jones and the last crusade on scifi, starting now! woot!",
  "id" : 813898863,
  "created_at" : "2008-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813908283",
  "text" : "Working through setting my ubuntu slice with slicehost. all of this unix stuff is confusing.",
  "id" : 813908283,
  "created_at" : "2008-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813994918",
  "text" : "John McCain, I'm sick of seeing you on SNL.",
  "id" : 813994918,
  "created_at" : "2008-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "814007586",
  "text" : "'sudo gem install rails' bliss.",
  "id" : 814007586,
  "created_at" : "2008-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "814017029",
  "text" : "ri documentation install took so long, putty disconnected. Crap.",
  "id" : 814017029,
  "created_at" : "2008-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "814348011",
  "text" : "Procrastinating by messing around with my new server. But it's so much fun! :(",
  "id" : 814348011,
  "created_at" : "2008-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0413\u0440\u0430\u043D\u043E\u0432\u0441\u043A\u0430\u044F \u0422\u0430\u0442\u044C\u044F\u043D\u0430",
      "screen_name" : "anjrued",
      "indices" : [ 0, 8 ],
      "id_str" : "2836824647",
      "id" : 2836824647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813297352",
  "geo" : { },
  "id_str" : "813300189",
  "in_reply_to_user_id" : 860851,
  "text" : "@anjrued Twitter is a testament to the fact that Rails scales. Yes it's got downtime, but usually due to DB\/cache issues, not Rails.",
  "id" : 813300189,
  "in_reply_to_status_id" : 813297352,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewdobrow",
  "in_reply_to_user_id_str" : "860851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Dockery",
      "screen_name" : "dougdockery",
      "indices" : [ 0, 12 ],
      "id_str" : "14188012",
      "id" : 14188012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813578057",
  "geo" : { },
  "id_str" : "813578393",
  "in_reply_to_user_id" : 14188012,
  "text" : "@dougdockery I loved the dumb bear saying \"FOR ASSSSLAAAN!\" Completely threw off the tempo of the movie.",
  "id" : 813578393,
  "in_reply_to_status_id" : 813578057,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "dougdockery",
  "in_reply_to_user_id_str" : "14188012",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813640299",
  "text" : "Local coffee shop's router has the default linksys password for wifi. Cmon.",
  "id" : 813640299,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Kirkpatrick",
      "screen_name" : "marshallk",
      "indices" : [ 0, 10 ],
      "id_str" : "818340",
      "id" : 818340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813638867",
  "geo" : { },
  "id_str" : "813647045",
  "in_reply_to_user_id" : 818340,
  "text" : "@marshallk I always envision a bunch of fat greasy nerds with torches and pitchforks when I see \"digg users revolt\"",
  "id" : 813647045,
  "in_reply_to_status_id" : 813638867,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "marshallk",
  "in_reply_to_user_id_str" : "818340",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813665303",
  "text" : "Six cars of a train filled with HCL acid have derailed in Lafayette, LA; 1000s forced to evacuate. My aunt lives there! :(",
  "id" : 813665303,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813667874",
  "text" : "Looks like aunt & co. in Lafayette are safe, as long as the wind doesn't change.",
  "id" : 813667874,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy Kelly",
      "screen_name" : "hci",
      "indices" : [ 0, 4 ],
      "id_str" : "12628652",
      "id" : 12628652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813668957",
  "geo" : { },
  "id_str" : "813670750",
  "in_reply_to_user_id" : 12628652,
  "text" : "@hci Let's hope. Hazmat gogogo",
  "id" : 813670750,
  "in_reply_to_status_id" : 813668957,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "hci",
  "in_reply_to_user_id_str" : "12628652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813703114",
  "text" : "I don't like VS2008's ctrl-tab window. I don't feel seeing a small preview of the code window I'm switching to makes it any faster\/efficient",
  "id" : 813703114,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813720276",
  "geo" : { },
  "id_str" : "813720870",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror wtf. why is he so shiny.",
  "id" : 813720870,
  "in_reply_to_status_id" : 813720276,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813864489",
  "text" : "I put a helicopter in my parking spot in GTA4. Flying around &gt; driving.",
  "id" : 813864489,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon LeBlanc",
      "screen_name" : "brandonleblanc",
      "indices" : [ 0, 15 ],
      "id_str" : "849131",
      "id" : 849131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813864817",
  "geo" : { },
  "id_str" : "813864864",
  "in_reply_to_user_id" : 849131,
  "text" : "@brandonleblanc Change to the smaller toolbar icons. And the awesome (address) bar is VERY helpful, it's a lot smarter than FF2's",
  "id" : 813864864,
  "in_reply_to_status_id" : 813864817,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "brandonleblanc",
  "in_reply_to_user_id_str" : "849131",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813299205",
  "text" : "Best part of Prince Caspian: grizzly bear saying in a slightly tarded voice \"FOR ASSSSLAAAN!\"",
  "id" : 813299205,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812362469",
  "text" : "At the Rochester on Rails meeting. My poor dell m1330 is outnumbered by Macs.",
  "id" : 812362469,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812427459",
  "text" : "JETPACK BRONTOSAURUS. http:\/\/jetpackbrontosaurus.com\/alpha\/",
  "id" : 812427459,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812432713",
  "text" : "Brontosauruses are not nimble creatures.",
  "id" : 812432713,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812435836",
  "text" : "I need to submit a peer evaluation for one of my classes by midnight. Document is not near where the assignment is online. I hate MyCourses.",
  "id" : 812435836,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812440368",
  "text" : "I need to get off Pownce. Or at least unfriend Kevin Rose, I don't care about his files.",
  "id" : 812440368,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812470060",
  "text" : "Aliens in cornfields. Mermaids and scary crap in pools. Now, plants that release deadly neurotoxins. http:\/\/is.gd\/hhL",
  "id" : 812470060,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812470982",
  "geo" : { },
  "id_str" : "812472393",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense @ablissfulgal got sick of the trailers so I needed to find out what it was about.",
  "id" : 812472393,
  "in_reply_to_status_id" : 812470982,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0413\u0440\u0430\u043D\u043E\u0432\u0441\u043A\u0430\u044F \u0422\u0430\u0442\u044C\u044F\u043D\u0430",
      "screen_name" : "anjrued",
      "indices" : [ 0, 8 ],
      "id_str" : "2836824647",
      "id" : 2836824647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812473955",
  "geo" : { },
  "id_str" : "812474651",
  "in_reply_to_user_id" : 860851,
  "text" : "@anjrued Play us out? WHAT DOES THAT EVEN MEAN?!",
  "id" : 812474651,
  "in_reply_to_status_id" : 812473955,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewdobrow",
  "in_reply_to_user_id_str" : "860851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812496883",
  "text" : "Wall-E is much cuter in real life. http:\/\/tinyurl.com\/5kgfvh",
  "id" : 812496883,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812729843",
  "text" : "Had a drug test this morning. I don't hate them, but they bother me.",
  "id" : 812729843,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Daniel",
      "screen_name" : "jack_daniel",
      "indices" : [ 0, 12 ],
      "id_str" : "7025212",
      "id" : 7025212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812730309",
  "geo" : { },
  "id_str" : "812731508",
  "in_reply_to_user_id" : 7025212,
  "text" : "@jack_daniel I prefer Twhirl and Witty. I think Witty looks better, but Twhirl just has more functionality.",
  "id" : 812731508,
  "in_reply_to_status_id" : 812730309,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "jack_daniel",
  "in_reply_to_user_id_str" : "7025212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812780217",
  "text" : "I have a mailing list from Google Groups forwarding into GMail. If i reply to a message via email, will it show up in the mailing list?",
  "id" : 812780217,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nino Benvenuti",
      "screen_name" : "NinoB",
      "indices" : [ 0, 6 ],
      "id_str" : "7281072",
      "id" : 7281072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812781271",
  "geo" : { },
  "id_str" : "812782729",
  "in_reply_to_user_id" : 7281072,
  "text" : "@ninob Most of the windows utilies use \/. i.e, \"dir \/a\" I prefer \"ls -la\" so much more.",
  "id" : 812782729,
  "in_reply_to_status_id" : 812781271,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "NinoB",
  "in_reply_to_user_id_str" : "7281072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scheirman",
      "screen_name" : "subdigital",
      "indices" : [ 0, 11 ],
      "id_str" : "14133001",
      "id" : 14133001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812803414",
  "geo" : { },
  "id_str" : "812804614",
  "in_reply_to_user_id" : 14133001,
  "text" : "@subdigital Design pattern accomplished!",
  "id" : 812804614,
  "in_reply_to_status_id" : 812803414,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "subdigital",
  "in_reply_to_user_id_str" : "14133001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Badera",
      "screen_name" : "andrewbadera",
      "indices" : [ 0, 13 ],
      "id_str" : "1535551",
      "id" : 1535551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812804408",
  "geo" : { },
  "id_str" : "812814743",
  "in_reply_to_user_id" : 1535551,
  "text" : "@andrewbadera That's really sad. Huge WTF at: Sites may not include \"advocacy against any individual, group, or organization.\"",
  "id" : 812814743,
  "in_reply_to_status_id" : 812804408,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewbadera",
  "in_reply_to_user_id_str" : "1535551",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zubaz",
      "screen_name" : "zubaz",
      "indices" : [ 5, 11 ],
      "id_str" : "14243440",
      "id" : 14243440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812829820",
  "text" : "From @zubaz, arm-length Sonic tattoo. WHY. http:\/\/cache.kotaku.com\/assets\/resources\/2008\/05\/sonictatlarge.jpg",
  "id" : 812829820,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellie Banks",
      "screen_name" : "iEllie",
      "indices" : [ 0, 7 ],
      "id_str" : "8111452",
      "id" : 8111452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812832131",
  "geo" : { },
  "id_str" : "812833171",
  "in_reply_to_user_id" : 8111452,
  "text" : "@iellie Hah, @ablissfulgal is now watching it. I wish I could join her D:",
  "id" : 812833171,
  "in_reply_to_status_id" : 812832131,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "iEllie",
  "in_reply_to_user_id_str" : "8111452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CarrieP",
      "screen_name" : "CarrieP",
      "indices" : [ 0, 8 ],
      "id_str" : "10266282",
      "id" : 10266282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812842110",
  "geo" : { },
  "id_str" : "812842775",
  "in_reply_to_user_id" : 10266282,
  "text" : "@CarrieP The hedgehog. Valid point though. Either are excessively dumb.",
  "id" : 812842775,
  "in_reply_to_status_id" : 812842110,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "CarrieP",
  "in_reply_to_user_id_str" : "10266282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Pike",
      "screen_name" : "npike",
      "indices" : [ 0, 6 ],
      "id_str" : "13056112",
      "id" : 13056112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812851783",
  "geo" : { },
  "id_str" : "812852372",
  "in_reply_to_user_id" : 13056112,
  "text" : "@npike OMG DINO BBQ.",
  "id" : 812852372,
  "in_reply_to_status_id" : 812851783,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "npike",
  "in_reply_to_user_id_str" : "13056112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kodak Alaris SM MGR",
      "screen_name" : "kodakCB",
      "indices" : [ 0, 8 ],
      "id_str" : "14590903",
      "id" : 14590903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812858133",
  "geo" : { },
  "id_str" : "812859087",
  "in_reply_to_user_id" : 14590903,
  "text" : "@kodakCB Google has nap pods. And nap\/relaxation rooms. Seems ridiculous to me.",
  "id" : 812859087,
  "in_reply_to_status_id" : 812858133,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "kodakCB",
  "in_reply_to_user_id_str" : "14590903",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812870730",
  "text" : "Repeating code makes me angry. Especially when it's unavoidable.",
  "id" : 812870730,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just A Sun God",
      "screen_name" : "JustaSunGod",
      "indices" : [ 0, 12 ],
      "id_str" : "11390722",
      "id" : 11390722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812877561",
  "geo" : { },
  "id_str" : "812878892",
  "in_reply_to_user_id" : 11390722,
  "text" : "@JustaSunGod All three, but send the pineapple delight to me.",
  "id" : 812878892,
  "in_reply_to_status_id" : 812877561,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "JustaSunGod",
  "in_reply_to_user_id_str" : "11390722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 0, 7 ],
      "id_str" : "6118872",
      "id" : 6118872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812881349",
  "geo" : { },
  "id_str" : "812885250",
  "in_reply_to_user_id" : 6118872,
  "text" : "@zoomba IT'S JUST BITTER.",
  "id" : 812885250,
  "in_reply_to_status_id" : 812881349,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "zoomba",
  "in_reply_to_user_id_str" : "6118872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frymaster",
      "screen_name" : "frymaster",
      "indices" : [ 0, 10 ],
      "id_str" : "13622792",
      "id" : 13622792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812885779",
  "geo" : { },
  "id_str" : "812887534",
  "in_reply_to_user_id" : 13622792,
  "text" : "@frymaster So what the heck generation are the 20 somethings?",
  "id" : 812887534,
  "in_reply_to_status_id" : 812885779,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "frymaster",
  "in_reply_to_user_id_str" : "13622792",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812891081",
  "text" : "Tonight! The CHRONIC WHAT! LES OF NARNIA.",
  "id" : 812891081,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812893814",
  "text" : "Prince Caspian has a 69% from Rotten Tomatoes currently. Let's hope it doesn't disappoint. http:\/\/is.gd\/hwT",
  "id" : 812893814,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812896887",
  "geo" : { },
  "id_str" : "812931938",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco DOUBLE TRUE.",
  "id" : 812931938,
  "in_reply_to_status_id" : 812896887,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812938516",
  "text" : "Hulu is so much better than youtube. The high res rocks.",
  "id" : 812938516,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813053785",
  "text" : "Obama faces racism in WV. It's going to be an uphill battle. http:\/\/tinyurl.com\/6y6gxb",
  "id" : 813053785,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813056783",
  "geo" : { },
  "id_str" : "813058212",
  "in_reply_to_user_id" : 5744442,
  "text" : "@ablissfulgal You also can't spell.",
  "id" : 813058212,
  "in_reply_to_status_id" : 813056783,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813061142",
  "text" : "Since when has GMail had \"Join the GMail team\" at the bottom. I thought Google hires 100 people per day, why do they need more ads for it?",
  "id" : 813061142,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813072049",
  "text" : "Bob Cesca's Goddamn Awesome Blog has a goddamn awesome logo. http:\/\/www.bobcesca.com\/",
  "id" : 813072049,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813106541",
  "text" : "What is it with web 2.0 news outlets getting OM NOM NOM'd this week http:\/\/is.gd\/hF3",
  "id" : 813106541,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813147142",
  "geo" : { },
  "id_str" : "813158280",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn DO NOT DISASSEMBLE NUMBER FIVE!",
  "id" : 813158280,
  "in_reply_to_status_id" : 813147142,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813158996",
  "text" : "Just went for a decent bike ride with @ablissfulgal. First of many this summer!",
  "id" : 813158996,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811613616",
  "text" : "Mario Kart on Nintendo Wifi is awesome. Custom Miis, and seamless play with people from other continents, sans lag.",
  "id" : 811613616,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811945129",
  "geo" : { },
  "id_str" : "811961886",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 Yeah, but you cant make polls there. also http:\/\/twitter.polldaddy.com. I feel we have better user account tracking\/visualization",
  "id" : 811961886,
  "in_reply_to_status_id" : 811945129,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lance white",
      "screen_name" : "fallenrogue",
      "indices" : [ 0, 12 ],
      "id_str" : "378588370",
      "id" : 378588370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811963593",
  "text" : "@fallenrogue It's a trap!",
  "id" : 811963593,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811963689",
  "geo" : { },
  "id_str" : "811964709",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 Ok, maybe we just suck.",
  "id" : 811964709,
  "in_reply_to_status_id" : 811963689,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811992108",
  "text" : "Why am I always the guy who gets up to talk? Not that I don't mind, just cmon. There's internet to browse.",
  "id" : 811992108,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 0, 8 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811982669",
  "geo" : { },
  "id_str" : "812000943",
  "in_reply_to_user_id" : 752673,
  "text" : "@jeresig Neat jQuery animations site, build stuff with cubes: http:\/\/is.gd\/gWR",
  "id" : 812000943,
  "in_reply_to_status_id" : 811982669,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "jeresig",
  "in_reply_to_user_id_str" : "752673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812050773",
  "text" : "Oooh, Reddit beta. http:\/\/beta.reddit.com\/ Seems like they can cram more stories in.",
  "id" : 812050773,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellie Banks",
      "screen_name" : "iEllie",
      "indices" : [ 0, 7 ],
      "id_str" : "8111452",
      "id" : 8111452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812053236",
  "geo" : { },
  "id_str" : "812053264",
  "in_reply_to_user_id" : 8111452,
  "text" : "@iellie Have you found a list somewhere?",
  "id" : 812053264,
  "in_reply_to_status_id" : 812053236,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "iEllie",
  "in_reply_to_user_id_str" : "8111452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812181122",
  "text" : "Safari carpet bombing. http:\/\/tinyurl.com\/57kwlj",
  "id" : 812181122,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812186243",
  "text" : "\"..a high risk vulnerability in Safari that can be used to remotely steal local files from the user\u2019s file system.\" Nice job Apple!",
  "id" : 812186243,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812254457",
  "text" : "Digg is down. Somehow though, I can't resist visiting links they provide. Such as http:\/\/www.khaaan.com\/",
  "id" : 812254457,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812280526",
  "text" : "We now return you to your regularly scheduled tweets.",
  "id" : 812280526,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812280956",
  "text" : "Replies tab is disabled on Twitter's web interface. Strange.",
  "id" : 812280956,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812310000",
  "text" : "\"Jeopardy 1999\" from SNL in 1979: http:\/\/tinyurl.com\/5aobsq",
  "id" : 812310000,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811562240",
  "text" : "CLEANING SPREE!",
  "id" : 811562240,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811562400",
  "text" : "M-M-M-M-M-MULTICLEAN!",
  "id" : 811562400,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 55, 64 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810727244",
  "text" : "1\/2 rack of ribs from Dino BBQ was SCRUMPTIOUS! *kicks @mittense down a hole*",
  "id" : 810727244,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Koon",
      "screen_name" : "lazycoder",
      "indices" : [ 0, 10 ],
      "id_str" : "697163",
      "id" : 697163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "810809177",
  "geo" : { },
  "id_str" : "810811530",
  "in_reply_to_user_id" : 697163,
  "text" : "@lazycoder Great post. The sad thing is that \"that guy\" will never read your blog.",
  "id" : 810811530,
  "in_reply_to_status_id" : 810809177,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "lazycoder",
  "in_reply_to_user_id_str" : "697163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810817848",
  "text" : "Rails routes are blowing my mind.",
  "id" : 810817848,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810819480",
  "text" : "Just what I needed! A roomba for my gutters! http:\/\/www.woot.com\/",
  "id" : 810819480,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810882913",
  "text" : "That's enough Rails for one night! Good enough for our presentation tomorrow. The road to actually publishing the website is still ahead.",
  "id" : 810882913,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tarabrown",
      "indices" : [ 0, 10 ],
      "id_str" : "17400089",
      "id" : 17400089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "810944189",
  "geo" : { },
  "id_str" : "811035672",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tarabrown Yeah, I decided I needed a nickname that was really my own. I was neither a doctor or Dr. Nic Williams: http:\/\/drnicwilliams.com\/",
  "id" : 811035672,
  "in_reply_to_status_id" : 810944189,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811060451",
  "text" : "1930s 'wife chart'. Definitely going to get slapped by @ablissfulgal for this. http:\/\/is.gd\/gpJ",
  "id" : 811060451,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark H. Delfs",
      "screen_name" : "mdelfs",
      "indices" : [ 0, 7 ],
      "id_str" : "697933",
      "id" : 697933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811074903",
  "geo" : { },
  "id_str" : "811076664",
  "in_reply_to_user_id" : 697933,
  "text" : "@mdelfs Saw this news yesterday. As a Catholic, I tend to ignore what comes out of the Vatican more and more. I mean, seriously. Aliens.",
  "id" : 811076664,
  "in_reply_to_status_id" : 811074903,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "mdelfs",
  "in_reply_to_user_id_str" : "697933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Younge",
      "screen_name" : "ayounge",
      "indices" : [ 0, 8 ],
      "id_str" : "14746618",
      "id" : 14746618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811081944",
  "geo" : { },
  "id_str" : "811086560",
  "in_reply_to_user_id" : 14746618,
  "text" : "@ayounge 2 more days of class, 2 more days of class...chant with me.",
  "id" : 811086560,
  "in_reply_to_status_id" : 811081944,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "ayounge",
  "in_reply_to_user_id_str" : "14746618",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811104458",
  "geo" : { },
  "id_str" : "811107038",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Fable seemed so damn linear. I wanted to be evil, but killing enemies\/progressing turned me good. Looks nice though, might rent it",
  "id" : 811107038,
  "in_reply_to_status_id" : 811104458,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tina Clark",
      "screen_name" : "tostina",
      "indices" : [ 0, 8 ],
      "id_str" : "756110",
      "id" : 756110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811124335",
  "geo" : { },
  "id_str" : "811125053",
  "in_reply_to_user_id" : 756110,
  "text" : "@tostina We all do, in some form or another. Anything specific you need help with?",
  "id" : 811125053,
  "in_reply_to_status_id" : 811124335,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "tostina",
  "in_reply_to_user_id_str" : "756110",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811121114",
  "geo" : { },
  "id_str" : "811143644",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog does anyone actually have negative karma?",
  "id" : 811143644,
  "in_reply_to_status_id" : 811121114,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811149283",
  "text" : "Facebook's photo album page just got more ajaxified.",
  "id" : 811149283,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811153241",
  "text" : "I just dont understand video game college\/degrees. Especially as a programmer, why would you want to limit yourself like that.",
  "id" : 811153241,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Milton",
      "screen_name" : "Jaxidian",
      "indices" : [ 0, 9 ],
      "id_str" : "14267403",
      "id" : 14267403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811207761",
  "geo" : { },
  "id_str" : "811208920",
  "in_reply_to_user_id" : 14267403,
  "text" : "@Jaxidian I don't think it's all marketing fluff, I've met several game design majors. I just don't get them",
  "id" : 811208920,
  "in_reply_to_status_id" : 811207761,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "Jaxidian",
  "in_reply_to_user_id_str" : "14267403",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811211450",
  "text" : "Giving 2 presentations today, one on my Rails project and another on my XNA particle system. ALMOST DONE.",
  "id" : 811211450,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811239588",
  "text" : "I left twhirl open during my presentation. Luckily the sound was off.",
  "id" : 811239588,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811232986",
  "geo" : { },
  "id_str" : "811240200",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 Oops.",
  "id" : 811240200,
  "in_reply_to_status_id" : 811232986,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811278789",
  "text" : "I got win32 ANSI colors working in ruby script\/console and server, but the console acts funky. Deleting creates blank characters. It's odd.",
  "id" : 811278789,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811312204",
  "text" : "Presentations over! Now I've just got exams to worry about.",
  "id" : 811312204,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee McKusick",
      "screen_name" : "LeeMcKusick",
      "indices" : [ 0, 12 ],
      "id_str" : "10234782",
      "id" : 10234782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811361848",
  "geo" : { },
  "id_str" : "811362730",
  "in_reply_to_user_id" : 10234782,
  "text" : "@leemckusick Great success!",
  "id" : 811362730,
  "in_reply_to_status_id" : 811361848,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "LeeMcKusick",
  "in_reply_to_user_id_str" : "10234782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809779188",
  "text" : "Watching a crazy guy who's caused a standoff on I-190 in Buffalo. Really close camera view, you can see the guy and the gun. http:\/\/wivb.com",
  "id" : 809779188,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BreakingNewsOn",
      "screen_name" : "BreakingNewsOn",
      "indices" : [ 0, 15 ],
      "id_str" : "27867231",
      "id" : 27867231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809777815",
  "geo" : { },
  "id_str" : "809779572",
  "in_reply_to_user_id" : 6017542,
  "text" : "@BreakingNewsOn Police standoff in buffalo on I-190, video at http:\/\/wivb.com",
  "id" : 809779572,
  "in_reply_to_status_id" : 809777815,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "BreakingNews",
  "in_reply_to_user_id_str" : "6017542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809784980",
  "text" : "Hooray, the police shot a flashbang or something at the suspect and took him down. About time!",
  "id" : 809784980,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809862447",
  "text" : "Rails just makes me feel so productive. The entire app is at my fingertips, from database to presentation. It's an awesome coding experience",
  "id" : 809862447,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonic Linley",
      "screen_name" : "Jonic",
      "indices" : [ 0, 6 ],
      "id_str" : "654033",
      "id" : 654033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809876046",
  "geo" : { },
  "id_str" : "809937112",
  "in_reply_to_user_id" : 654033,
  "text" : "@jonic It's glorious. That's all I can say.",
  "id" : 809937112,
  "in_reply_to_status_id" : 809876046,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "Jonic",
  "in_reply_to_user_id_str" : "654033",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809937331",
  "text" : "Behold jQuery! $(this).parents(\"li\").currentQuestion.after(newQuestion).next().hide().fadeIn(); (I'm going to regret this code someday)",
  "id" : 809937331,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810173064",
  "text" : "Staying up until 4am = mistake.",
  "id" : 810173064,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810418395",
  "text" : "Drug test for new job can only be scheduled before 7am and 11am. EPIC FAIL.",
  "id" : 810418395,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810500608",
  "text" : "Either I'm a moron, or I can't get my vs color scheme to load within SQL management studio. Boohiss, I miss my dark pastels.",
  "id" : 810500608,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Cangiano",
      "screen_name" : "acangiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14582359",
      "id" : 14582359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "810497277",
  "geo" : { },
  "id_str" : "810501084",
  "in_reply_to_user_id" : 14582359,
  "text" : "@acangiano I'll get to reading that tomorrow.",
  "id" : 810501084,
  "in_reply_to_status_id" : 810497277,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "acangiano",
  "in_reply_to_user_id_str" : "14582359",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810504110",
  "text" : "Considering changing my handle to avoid further confusion with Dr. Nic, and I'll never get a PhD. Will twitter forward @'s from my old nick?",
  "id" : 810504110,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 21, 27 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810515477",
  "text" : "Changed my handle to @qrush. Crush? Q + Rush (my favorite band) ? I don't know. but it's different and my own.",
  "id" : 810515477,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 70, 82 ],
      "id_str" : "8453452",
      "id" : 8453452
    }, {
      "name" : "Hi Everybody!",
      "screen_name" : "DoctorNick",
      "indices" : [ 98, 109 ],
      "id_str" : "2951720045",
      "id" : 2951720045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810518340",
  "text" : "Very impressed that twitter.alltop recognized my new handle! Kudos to @guykawasaki. Sadly though, @DoctorNick does not redirect.",
  "id" : 810518340,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K. Scott Allen",
      "screen_name" : "OdeToCode",
      "indices" : [ 0, 10 ],
      "id_str" : "13479972",
      "id" : 13479972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "810539551",
  "geo" : { },
  "id_str" : "810542894",
  "in_reply_to_user_id" : 13479972,
  "text" : "@OdeToCode F0DD2CAA-2132-11DD-AC50-FE9355D89593",
  "id" : 810542894,
  "in_reply_to_status_id" : 810539551,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "OdeToCode",
  "in_reply_to_user_id_str" : "13479972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer P",
      "screen_name" : "jdots24",
      "indices" : [ 0, 8 ],
      "id_str" : "9897172",
      "id" : 9897172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "810546587",
  "geo" : { },
  "id_str" : "810549959",
  "in_reply_to_user_id" : 9897172,
  "text" : "@jdots24 There are so many strange things in the color science building. Not sure why they have their own building still.",
  "id" : 810549959,
  "in_reply_to_status_id" : 810546587,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "jdots24",
  "in_reply_to_user_id_str" : "9897172",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810557576",
  "text" : "Going to the Dinosaur BBQ tonight! Hell yes, delicious ribs.",
  "id" : 810557576,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pawe\u0142 Szymczykowski",
      "screen_name" : "makenai",
      "indices" : [ 0, 8 ],
      "id_str" : "4569381",
      "id" : 4569381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "810512221",
  "geo" : { },
  "id_str" : "810563883",
  "in_reply_to_user_id" : 4569381,
  "text" : "@makenai this is absurdly useful, I'm starting to really get into Ruby and now I can follow those who are also addicted to it. Thanks!",
  "id" : 810563883,
  "in_reply_to_status_id" : 810512221,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "makenai",
  "in_reply_to_user_id_str" : "4569381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Koon",
      "screen_name" : "lazycoder",
      "indices" : [ 0, 10 ],
      "id_str" : "697163",
      "id" : 697163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "810585224",
  "geo" : { },
  "id_str" : "810588508",
  "in_reply_to_user_id" : 697163,
  "text" : "@lazycoder I might show up just for the humor value.",
  "id" : 810588508,
  "in_reply_to_status_id" : 810585224,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "lazycoder",
  "in_reply_to_user_id_str" : "697163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CarrieP",
      "screen_name" : "CarrieP",
      "indices" : [ 0, 8 ],
      "id_str" : "10266282",
      "id" : 10266282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809005742",
  "geo" : { },
  "id_str" : "809008651",
  "in_reply_to_user_id" : 10266282,
  "text" : "@CarrieP KOLIMA!",
  "id" : 809008651,
  "in_reply_to_status_id" : 809005742,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "CarrieP",
  "in_reply_to_user_id_str" : "10266282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809038222",
  "text" : "Witty gets real slow when it's open for a long time. I need to free up some time to start poking around its code.",
  "id" : 809038222,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809304937",
  "text" : "Oh man, another Steve Yegge blog post. Better curl up and get some tea, I'm in the for long haul.",
  "id" : 809304937,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809338339",
  "text" : "My brain is leaking.",
  "id" : 809338339,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809378933",
  "text" : "I hate worrying about running queries on the production DB. This is why I love rails migrations, and the environment system.",
  "id" : 809378933,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Starr",
      "screen_name" : "NickStarr",
      "indices" : [ 0, 10 ],
      "id_str" : "48933",
      "id" : 48933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809393093",
  "geo" : { },
  "id_str" : "809396178",
  "in_reply_to_user_id" : 48933,
  "text" : "@NickStarr Where's your new job at?",
  "id" : 809396178,
  "in_reply_to_status_id" : 809393093,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "NickStarr",
  "in_reply_to_user_id_str" : "48933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809528386",
  "text" : "CS majors give crappy presentations. Sorry, but SE students just get more practice in this area.",
  "id" : 809528386,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809570166",
  "text" : "Absolutely stunning. One group in my CG2 class used processing to create particle systems from sound, even input from a mic! I'm stunned.",
  "id" : 809570166,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809720944",
  "text" : "3 more days of class, 3 more days of class...cmon, chant with me!",
  "id" : 809720944,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kee Hinckley",
      "screen_name" : "nazgul",
      "indices" : [ 0, 7 ],
      "id_str" : "2084821",
      "id" : 2084821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "808928569",
  "geo" : { },
  "id_str" : "808931540",
  "in_reply_to_user_id" : 2084821,
  "text" : "@nazgul Bah! I'm a huge Nethack fan and proud of it. I've ascended...5 times now?",
  "id" : 808931540,
  "in_reply_to_status_id" : 808928569,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "nazgul",
  "in_reply_to_user_id_str" : "2084821",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kee Hinckley",
      "screen_name" : "nazgul",
      "indices" : [ 0, 7 ],
      "id_str" : "2084821",
      "id" : 2084821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "808932079",
  "geo" : { },
  "id_str" : "808940206",
  "in_reply_to_user_id" : 2084821,
  "text" : "@nazgul Whoa! Following him for sure.",
  "id" : 808940206,
  "in_reply_to_status_id" : 808932079,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "nazgul",
  "in_reply_to_user_id_str" : "2084821",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "objo",
      "screen_name" : "objo",
      "indices" : [ 0, 5 ],
      "id_str" : "2190330632",
      "id" : 2190330632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809000387",
  "text" : "@objo I've been reading a little about git...it seems so much more complicated than cvs\/svn I doubt average developers could actually use it",
  "id" : 809000387,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "808997758",
  "geo" : { },
  "id_str" : "809001388",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee Looks awesome! I'm going to be picking it up, I've got a $25 gift cert that is begging to be spent.",
  "id" : 809001388,
  "in_reply_to_status_id" : 808997758,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808910967",
  "text" : "Went to Canada today, always surprised to see that Canadians don't talk like characters in South Park. I can't help of thinking of it though",
  "id" : 808910967,
  "created_at" : "2008-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808927177",
  "text" : "Just beat Shiren the Wanderer, Mystery Dungeon. Awesome roguelike for the DS, pales in comparison to Nethack but it was fun.",
  "id" : 808927177,
  "created_at" : "2008-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "807698410",
  "text" : "I just got a $25 gift certificate to Amazon, from Microsoft, for taking a survey about an interview I never had. Woot!",
  "id" : 807698410,
  "created_at" : "2008-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "807764695",
  "text" : "Woot-off rating: MEH.",
  "id" : 807764695,
  "created_at" : "2008-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "807764931",
  "geo" : { },
  "id_str" : "807765012",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman Saw your book at Borders today! I was tempted, but I decided to get a Rails one instead, I'm branching out a bit. :)",
  "id" : 807765012,
  "in_reply_to_status_id" : 807764931,
  "created_at" : "2008-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellie Banks",
      "screen_name" : "iEllie",
      "indices" : [ 0, 7 ],
      "id_str" : "8111452",
      "id" : 8111452
    }, {
      "name" : "Drew_Barrymore",
      "screen_name" : "Drew_Barrymore",
      "indices" : [ 11, 26 ],
      "id_str" : "14700701",
      "id" : 14700701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "807775572",
  "geo" : { },
  "id_str" : "807776820",
  "in_reply_to_user_id" : 8111452,
  "text" : "@iellie If @Drew_Barrymore is a fake, he\/she is doing a decent job of it.",
  "id" : 807776820,
  "in_reply_to_status_id" : 807775572,
  "created_at" : "2008-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "iEllie",
  "in_reply_to_user_id_str" : "8111452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808054211",
  "text" : "Mmm, b-spline. So curvy.",
  "id" : 808054211,
  "created_at" : "2008-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808060730",
  "text" : "What is your coding music? I can't get enough of Rush.",
  "id" : 808060730,
  "created_at" : "2008-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808069675",
  "text" : "Kevin Rose keeps sending me files through Pownce. No thanks.",
  "id" : 808069675,
  "created_at" : "2008-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808178262",
  "text" : "XNA to Rails in the same day. My brain my explode, but at least it would be fun.",
  "id" : 808178262,
  "created_at" : "2008-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806913481",
  "text" : "Debating buying http:\/\/quaran.to from Tonga. $50 for 2 years...but i could have a really neat email address and website!",
  "id" : 806913481,
  "created_at" : "2008-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "807223500",
  "text" : "I know I should stop staying up until 2-3am playing games, but it's SO MUCH FUN. Agh.",
  "id" : 807223500,
  "created_at" : "2008-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "807229516",
  "text" : "Best shirt.woot in a long while, and I missed it. I was up too! :( http:\/\/shirt.woot.com\/",
  "id" : 807229516,
  "created_at" : "2008-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 0, 5 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "807235262",
  "geo" : { },
  "id_str" : "807239224",
  "in_reply_to_user_id" : 734493,
  "text" : "@woot SHIP MY TV PLEASE. It's been over a week now!",
  "id" : 807239224,
  "in_reply_to_status_id" : 807235262,
  "created_at" : "2008-05-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "woot",
  "in_reply_to_user_id_str" : "734493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "807246855",
  "text" : "UPDATE: My TV literally just arrived. Minutes after posting on woot's forums, submitting feedback, and other whining. Not bad!",
  "id" : 807246855,
  "created_at" : "2008-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "807462110",
  "text" : "Wasting a way a day configuring visual studio, sql server, and friends. ugh.",
  "id" : 807462110,
  "created_at" : "2008-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "807466332",
  "text" : "I AM NOT A LOCKERGNOME.",
  "id" : 807466332,
  "created_at" : "2008-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "807532474",
  "text" : "Where art thou, Bag of Crap?",
  "id" : 807532474,
  "created_at" : "2008-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 82, 91 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805973513",
  "text" : "9 weeks into my raytracer and I realize that my phong calculations are wrong. Cue @mittense.",
  "id" : 805973513,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806028339",
  "text" : "Definitely fixed my phong shading issues with my raytracer! Now to back to translucency...",
  "id" : 806028339,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 5, 10 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806105399",
  "text" : "From @wilw: REAL LIGHTNING. And a spewing volcano. Just another lovely day in Chile. http:\/\/tinyurl.com\/5n77lh",
  "id" : 806105399,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806109260",
  "text" : "Woot! Refraction done with my raytracer, and these parameters are true to Whitted's original. http:\/\/is.gd\/duZ",
  "id" : 806109260,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 0, 5 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806111261",
  "geo" : { },
  "id_str" : "806111510",
  "in_reply_to_user_id" : 734493,
  "text" : "@woot is down but the twitter bot still reported the item?",
  "id" : 806111510,
  "in_reply_to_status_id" : 806111261,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "woot",
  "in_reply_to_user_id_str" : "734493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806111740",
  "text" : "WOOT OFF!!!!!",
  "id" : 806111740,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806114308",
  "text" : "Whatever algorithm Twitter uses to resize avatars is absolute crap.",
  "id" : 806114308,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806116669",
  "text" : "2 tweets for returning to the engineer avatar...I figured since it's over 6 months old now and I just cut the mop off my head, it was time.",
  "id" : 806116669,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 21, 26 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806119610",
  "text" : "Slowest moving first @woot-off item EVAR.",
  "id" : 806119610,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thanks",
      "screen_name" : "thanks",
      "indices" : [ 0, 7 ],
      "id_str" : "787405086",
      "id" : 787405086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806128154",
  "text" : "@Thanks! I think I do too.",
  "id" : 806128154,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Adkins",
      "screen_name" : "leeadkins",
      "indices" : [ 0, 10 ],
      "id_str" : "2895081",
      "id" : 2895081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806120430",
  "geo" : { },
  "id_str" : "806128336",
  "in_reply_to_user_id" : 2895081,
  "text" : "@leeadkins Who knows, just buy one so we can get to the Bag of Crap!",
  "id" : 806128336,
  "in_reply_to_status_id" : 806120430,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "leeadkins",
  "in_reply_to_user_id_str" : "2895081",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 41, 46 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806132378",
  "text" : "Another battery pack? I really hate when @woot plays games.",
  "id" : 806132378,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 0, 8 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806362794",
  "geo" : { },
  "id_str" : "806363879",
  "in_reply_to_user_id" : 752673,
  "text" : "@jeresig Happy birthday! And don't work too hard, you have an excuse today. :)",
  "id" : 806363879,
  "in_reply_to_status_id" : 806362794,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "jeresig",
  "in_reply_to_user_id_str" : "752673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806367698",
  "text" : "Microsoft is hungry! OM NOM NOM NOM! http:\/\/tinyurl.com\/5pbe4d",
  "id" : 806367698,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806389322",
  "text" : "Kid who got pegged in the forehead with a candy bar last class got payback and nailed the professor in the head when he was called for roll.",
  "id" : 806389322,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806478332",
  "text" : "Supposedly it might hail today. wtf Rochester.",
  "id" : 806478332,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806602414",
  "text" : "CNN headline on their front page: GINORMOUS SINKHOLE. Ugh.",
  "id" : 806602414,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806601554",
  "geo" : { },
  "id_str" : "806603538",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway BORDER=0 VALIGN=TOP...errr...crap I have no idea either.",
  "id" : 806603538,
  "in_reply_to_status_id" : 806601554,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806662738",
  "text" : "Horrifying stories of bees\/wasps\/hornets on Opie and Anthony today...anyone have any bad experiences? I've haven't been stung yet. Yet.",
  "id" : 806662738,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806728392",
  "text" : "Crude and immature. Exactly my kind of humor. http:\/\/superjared.com\/static\/images\/headline.png",
  "id" : 806728392,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Pike",
      "screen_name" : "npike",
      "indices" : [ 0, 6 ],
      "id_str" : "13056112",
      "id" : 13056112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "806749921",
  "geo" : { },
  "id_str" : "806751665",
  "in_reply_to_user_id" : 13056112,
  "text" : "@npike Lots of games out for that Leopard, eh? :)",
  "id" : 806751665,
  "in_reply_to_status_id" : 806749921,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "npike",
  "in_reply_to_user_id_str" : "13056112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806771073",
  "text" : "Heading back to campus. Only two more weeks. Only two more weeks. Only two more weeks. Only two more weeks. Only two more weeks.",
  "id" : 806771073,
  "created_at" : "2008-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paisano",
      "screen_name" : "Paisano",
      "indices" : [ 0, 8 ],
      "id_str" : "5658202",
      "id" : 5658202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805709639",
  "geo" : { },
  "id_str" : "805710867",
  "in_reply_to_user_id" : 5658202,
  "text" : "@Paisano Go to DisneyQuest in downtown disney. 5 floors of video games and interactive fun.",
  "id" : 805710867,
  "in_reply_to_status_id" : 805709639,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Paisano",
  "in_reply_to_user_id_str" : "5658202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Pike",
      "screen_name" : "npike",
      "indices" : [ 0, 6 ],
      "id_str" : "13056112",
      "id" : 13056112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805727537",
  "geo" : { },
  "id_str" : "805730197",
  "in_reply_to_user_id" : 13056112,
  "text" : "@npike What class are you in, and why didn't I get into it.",
  "id" : 805730197,
  "in_reply_to_status_id" : 805727537,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "npike",
  "in_reply_to_user_id_str" : "13056112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805736932",
  "geo" : { },
  "id_str" : "805738659",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense: This is fantastic. Waste of time yes, but amazing.",
  "id" : 805738659,
  "in_reply_to_status_id" : 805736932,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805902665",
  "text" : "Firefox 2 just can't handle Facebook, GMail, and multiple tabs. Curses.",
  "id" : 805902665,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805922944",
  "text" : "Wow! I haven't tried out my laptop webcam since I got it and it's quite good. Dell M1330 ftw!",
  "id" : 805922944,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Grubbs",
      "screen_name" : "DougGrubbs",
      "indices" : [ 0, 11 ],
      "id_str" : "822451266",
      "id" : 822451266
    }, {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 100, 113 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805933217",
  "text" : "@douggrubbs It's quite good. Lightweight, powerful, decent speakers, LED backlit display. Check out @codinghorror's review: http:\/\/is.gd\/dpt",
  "id" : 805933217,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805110215",
  "text" : "Cleaning spree accomplished! Now I need a break. Or food. Or both.",
  "id" : 805110215,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer P",
      "screen_name" : "jdots24",
      "indices" : [ 0, 8 ],
      "id_str" : "9897172",
      "id" : 9897172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805077081",
  "geo" : { },
  "id_str" : "805113792",
  "in_reply_to_user_id" : 9897172,
  "text" : "@jdots24 That's dumb. I guess it's one way of DB design but I prefer my tables in a way that makes joins quick 'n easy.",
  "id" : 805113792,
  "in_reply_to_status_id" : 805077081,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "jdots24",
  "in_reply_to_user_id_str" : "9897172",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805129111",
  "text" : "Watching CNN is just mind numbing.",
  "id" : 805129111,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805136366",
  "text" : "bbPress looks interesting: http:\/\/bbpress.org\/ Much cleaner than phpBB or vBulletin imo.",
  "id" : 805136366,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K. Scott Allen",
      "screen_name" : "OdeToCode",
      "indices" : [ 0, 10 ],
      "id_str" : "13479972",
      "id" : 13479972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805135979",
  "geo" : { },
  "id_str" : "805136708",
  "in_reply_to_user_id" : 13479972,
  "text" : "@OdeToCode +1",
  "id" : 805136708,
  "in_reply_to_status_id" : 805135979,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "OdeToCode",
  "in_reply_to_user_id_str" : "13479972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805141911",
  "geo" : { },
  "id_str" : "805164980",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 Yeah, it sucks when you really need to squeeze in as much as possible and the user has a HUGE nickname :(",
  "id" : 805164980,
  "in_reply_to_status_id" : 805141911,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Hahn",
      "screen_name" : "GauntletWizard",
      "indices" : [ 0, 15 ],
      "id_str" : "14006082",
      "id" : 14006082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805171872",
  "geo" : { },
  "id_str" : "805173507",
  "in_reply_to_user_id" : 14006082,
  "text" : "@GauntletWizard Rule 36.",
  "id" : 805173507,
  "in_reply_to_status_id" : 805171872,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "GauntletWizard",
  "in_reply_to_user_id_str" : "14006082",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805175106",
  "text" : "I love Backpack. It's like a persistent post-it note that lets me organize my ideas, thoughts, and things that need to get done.",
  "id" : 805175106,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805201941",
  "text" : "This 100 line method in my raytracer is haunting me. It doesn't need to be split up, but something tells me it should.",
  "id" : 805201941,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805443442",
  "text" : "I am completely sick of my roommate. I spent an 1 1\/2 hours cleaning, and last night he made a total mess of the kitchen and left stuff out.",
  "id" : 805443442,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Muthuselvam RS",
      "screen_name" : "IntelliBitz",
      "indices" : [ 0, 12 ],
      "id_str" : "1407251",
      "id" : 1407251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805447019",
  "geo" : { },
  "id_str" : "805447964",
  "in_reply_to_user_id" : 1407251,
  "text" : "@intellibitz There may not be, but I would really prefer that he have RESPECT. Argh. I'm not even going to waste time yelling at him.",
  "id" : 805447964,
  "in_reply_to_status_id" : 805447019,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "IntelliBitz",
  "in_reply_to_user_id_str" : "1407251",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Cangiano",
      "screen_name" : "acangiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14582359",
      "id" : 14582359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805449711",
  "geo" : { },
  "id_str" : "805451074",
  "in_reply_to_user_id" : 14582359,
  "text" : "@acangiano I'm trying it out too! I think it has a lot of potential...I'm gathering up ideas that I want to contribute :)",
  "id" : 805451074,
  "in_reply_to_status_id" : 805449711,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "acangiano",
  "in_reply_to_user_id_str" : "14582359",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miffy balboa",
      "screen_name" : "Puddington",
      "indices" : [ 0, 11 ],
      "id_str" : "298414457",
      "id" : 298414457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805472571",
  "geo" : { },
  "id_str" : "805474930",
  "in_reply_to_user_id" : 2057591,
  "text" : "@Puddington Dude, you need an avatar.",
  "id" : 805474930,
  "in_reply_to_status_id" : 805472571,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "oneWillJ",
  "in_reply_to_user_id_str" : "2057591",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Trinity",
      "screen_name" : "TheProkrammer",
      "indices" : [ 0, 14 ],
      "id_str" : "1454222514",
      "id" : 1454222514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805472863",
  "geo" : { },
  "id_str" : "805476116",
  "in_reply_to_user_id" : 458173,
  "text" : "@TheProkrammer Boohiss, use jQuery! If you need help I can gladly assist, especially with effects.",
  "id" : 805476116,
  "in_reply_to_status_id" : 805472863,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "mletterle",
  "in_reply_to_user_id_str" : "458173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Hinze",
      "screen_name" : "mhinze",
      "indices" : [ 0, 7 ],
      "id_str" : "51023",
      "id" : 51023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805482132",
  "geo" : { },
  "id_str" : "805483818",
  "in_reply_to_user_id" : 51023,
  "text" : "@mhinze Didn't Joel make his own VBScript lang or something for FogBugz? Sounds scary, but not understanding those concepts is pretty bad.",
  "id" : 805483818,
  "in_reply_to_status_id" : 805482132,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "mhinze",
  "in_reply_to_user_id_str" : "51023",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805485910",
  "text" : "Witty definitely should not freeze while it updates tweets. Or at least let the user know it is.",
  "id" : 805485910,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 5, 14 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805496877",
  "text" : "From @mittense (since he hates retweeting) GTA4 makes $500 million in the first week. http:\/\/www.shacknews.com\/onearticle.x\/52554",
  "id" : 805496877,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CariElf",
      "screen_name" : "CariElf",
      "indices" : [ 0, 8 ],
      "id_str" : "14238116",
      "id" : 14238116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805475466",
  "geo" : { },
  "id_str" : "805498485",
  "in_reply_to_user_id" : 14238116,
  "text" : "@CariElf I already do, I put crap he leaves in the living room in front of his door. Should I put the empty ramen bowl there too? &gt;:)",
  "id" : 805498485,
  "in_reply_to_status_id" : 805475466,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "CariElf",
  "in_reply_to_user_id_str" : "14238116",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805506047",
  "text" : "TechCrunch is becoming the tabloid of the internet. If not already.",
  "id" : 805506047,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805585561",
  "text" : "I'm not really seeing the benefit of Brightkite. Here's what mine would be: Home. School. Home. Wegmans. Home. Repeat.",
  "id" : 805585561,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stardock",
      "screen_name" : "Stardock",
      "indices" : [ 47, 56 ],
      "id_str" : "14462781",
      "id" : 14462781
    }, {
      "name" : "Brad Wardell",
      "screen_name" : "draginol",
      "indices" : [ 87, 96 ],
      "id_str" : "13972382",
      "id" : 13972382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804623463",
  "text" : "Wow! Lots of exciting things happening over at @stardock: http:\/\/is.gd\/cCH Now only if @draginol would update.",
  "id" : 804623463,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804628832",
  "text" : "Great synopsis of the PlaysForSure debacle: http:\/\/tinyurl.com\/3ewpx6",
  "id" : 804628832,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804632630",
  "geo" : { },
  "id_str" : "804634061",
  "in_reply_to_user_id" : 11204662,
  "text" : "@tw3nty3ight You might as well buy it. It's a truly awesome game, definitely worth it.",
  "id" : 804634061,
  "in_reply_to_status_id" : 804632630,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "F3SportsCards",
  "in_reply_to_user_id_str" : "11204662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804637946",
  "text" : "I need to give a speech for my communication class, in oh, 3 hours. Preparation: Zero. Grade: Hopefully not bad.",
  "id" : 804637946,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Nash",
      "screen_name" : "GeneNash",
      "indices" : [ 0, 9 ],
      "id_str" : "14250025",
      "id" : 14250025
    }, {
      "name" : "Robert Scoble",
      "screen_name" : "Scobleizer",
      "indices" : [ 20, 31 ],
      "id_str" : "13348",
      "id" : 13348
    }, {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 36, 44 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803925662",
  "geo" : { },
  "id_str" : "804663690",
  "in_reply_to_user_id" : 14250025,
  "text" : "@GeneNash: I bugged @scobleizer and @garyvee one day at the right time. ;)",
  "id" : 804663690,
  "in_reply_to_status_id" : 803925662,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "GeneNash",
  "in_reply_to_user_id_str" : "14250025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John C. Dvorak",
      "screen_name" : "THErealDVORAK",
      "indices" : [ 8, 22 ],
      "id_str" : "14326840",
      "id" : 14326840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804687490",
  "text" : "Oh man, @therealdvorak linked to twitter. And he's at 14,000 followers already. http:\/\/tinyurl.com\/4tsyhy",
  "id" : 804687490,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804689903",
  "text" : "CLASSIC! Professor tosses a candy bar for answering a question RIGHT at a student's forehead in the first row.",
  "id" : 804689903,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804874096",
  "text" : "Wow, this politics site looks REALLY nice. Seems like a reddit\/digg clone for only politics stuff: http:\/\/voteoften.us\/",
  "id" : 804874096,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 18, 23 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804888396",
  "text" : "I wish my TV from @woot would ship.",
  "id" : 804888396,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Ross",
      "screen_name" : "RossCode",
      "indices" : [ 0, 9 ],
      "id_str" : "5742002",
      "id" : 5742002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804914276",
  "geo" : { },
  "id_str" : "804916357",
  "in_reply_to_user_id" : 5742002,
  "text" : "@RossCode I hope that's an Office episode. Sadly though, I doubt that.",
  "id" : 804916357,
  "in_reply_to_status_id" : 804914276,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "RossCode",
  "in_reply_to_user_id_str" : "5742002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804930441",
  "text" : "65% full time student discount to Railsconf. Still though, it would be at least $500. Damn, conferences are expensive.",
  "id" : 804930441,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Trinity",
      "screen_name" : "TheProkrammer",
      "indices" : [ 0, 14 ],
      "id_str" : "1454222514",
      "id" : 1454222514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804939473",
  "geo" : { },
  "id_str" : "804940561",
  "in_reply_to_user_id" : 458173,
  "text" : "@TheProkrammer I hope you're not using their server-side controls, as they suck. Their client side JS library isn't half bad though.",
  "id" : 804940561,
  "in_reply_to_status_id" : 804939473,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "mletterle",
  "in_reply_to_user_id_str" : "458173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derik Whittaker",
      "screen_name" : "DerikWhittaker",
      "indices" : [ 0, 15 ],
      "id_str" : "14342157",
      "id" : 14342157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804947841",
  "geo" : { },
  "id_str" : "804948613",
  "in_reply_to_user_id" : 14342157,
  "text" : "@DerikWhittaker Provide a link and a little explanation? Can't really force a user to do something like that from server-side...",
  "id" : 804948613,
  "in_reply_to_status_id" : 804947841,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "DerikWhittaker",
  "in_reply_to_user_id_str" : "14342157",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derik Whittaker",
      "screen_name" : "DerikWhittaker",
      "indices" : [ 0, 15 ],
      "id_str" : "14342157",
      "id" : 14342157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804950152",
  "geo" : { },
  "id_str" : "804951154",
  "in_reply_to_user_id" : 14342157,
  "text" : "@DerikWhittaker Oh, I suppose that's possible. Would be quite easy to do with a .ashx handler.",
  "id" : 804951154,
  "in_reply_to_status_id" : 804950152,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "DerikWhittaker",
  "in_reply_to_user_id_str" : "14342157",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804954766",
  "text" : "I LIKE TURTLES.",
  "id" : 804954766,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Defren",
      "screen_name" : "TDefren",
      "indices" : [ 0, 8 ],
      "id_str" : "662763",
      "id" : 662763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804950978",
  "geo" : { },
  "id_str" : "804955389",
  "in_reply_to_user_id" : 662763,
  "text" : "@TDefren Myspace. Enough said.",
  "id" : 804955389,
  "in_reply_to_status_id" : 804950978,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "TDefren",
  "in_reply_to_user_id_str" : "662763",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patgannon",
      "screen_name" : "patgannon",
      "indices" : [ 0, 10 ],
      "id_str" : "11776772",
      "id" : 11776772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804958844",
  "geo" : { },
  "id_str" : "804961799",
  "in_reply_to_user_id" : 11776772,
  "text" : "@patgannon Have you heard their new vocalist?",
  "id" : 804961799,
  "in_reply_to_status_id" : 804958844,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "patgannon",
  "in_reply_to_user_id_str" : "11776772",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804968486",
  "text" : "What happened to http:\/\/www.live.com\/ ?",
  "id" : 804968486,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804980754",
  "text" : "Trying out Witty, again.",
  "id" : 804980754,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804983582",
  "text" : "What, no retweeting function in Witty? That blows.",
  "id" : 804983582,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804991478",
  "text" : "Twhirl and Witty have totally different approaches...for instance Witty doesn't seem to have a profile lookup, at least from what I can see.",
  "id" : 804991478,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804996736",
  "geo" : { },
  "id_str" : "804998009",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway Ahh, I'm on 0.1.7 beta 1. Perhaps I'll just build from source, I want to poke around in the project anyway :)",
  "id" : 804998009,
  "in_reply_to_status_id" : 804996736,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zer0Her0",
      "screen_name" : "Zer0Her0",
      "indices" : [ 0, 9 ],
      "id_str" : "662843",
      "id" : 662843
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805003101",
  "geo" : { },
  "id_str" : "805004935",
  "in_reply_to_user_id" : 662843,
  "text" : "@Zer0Her0 I agree. Except I am home. And it's tempting me.",
  "id" : 805004935,
  "in_reply_to_status_id" : 805003101,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "Zer0Her0",
  "in_reply_to_user_id_str" : "662843",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805026149",
  "geo" : { },
  "id_str" : "805029899",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee I turn 21 in November, I'm giving you the honor of choosing the first bottle of wine I purchase. I'll make sure to remind you :)",
  "id" : 805029899,
  "in_reply_to_status_id" : 805026149,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 27, 35 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805031427",
  "text" : "Finally watching Conan and @garyvee, hilarious: http:\/\/tinyurl.com\/3alp8a",
  "id" : 805031427,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kodak Alaris SM MGR",
      "screen_name" : "kodakCB",
      "indices" : [ 0, 8 ],
      "id_str" : "14590903",
      "id" : 14590903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805032461",
  "geo" : { },
  "id_str" : "805035081",
  "in_reply_to_user_id" : 14590903,
  "text" : "@kodakCB Hah! I don't think I like turtles that much, but that is quite astounding.",
  "id" : 805035081,
  "in_reply_to_status_id" : 805032461,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "kodakCB",
  "in_reply_to_user_id_str" : "14590903",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805032171",
  "geo" : { },
  "id_str" : "805035599",
  "in_reply_to_user_id" : 5744442,
  "text" : "@ablissfulgal Tell another story!",
  "id" : 805035599,
  "in_reply_to_status_id" : 805032171,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805056396",
  "text" : "It would be nice if Twitter didn't count the name of the person you're replying to against the 140 character count. Thoughts?",
  "id" : 805056396,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer P",
      "screen_name" : "jdots24",
      "indices" : [ 0, 8 ],
      "id_str" : "9897172",
      "id" : 9897172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805068875",
  "geo" : { },
  "id_str" : "805072138",
  "in_reply_to_user_id" : 9897172,
  "text" : "@jdots24 How so? Horribly long field\/table names?",
  "id" : 805072138,
  "in_reply_to_status_id" : 805068875,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "jdots24",
  "in_reply_to_user_id_str" : "9897172",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward O'Connor",
      "screen_name" : "hober",
      "indices" : [ 0, 6 ],
      "id_str" : "13607",
      "id" : 13607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "805078498",
  "geo" : { },
  "id_str" : "805084890",
  "in_reply_to_user_id" : 13607,
  "text" : "@hober It's just not consistent. Drives me nuts when I get 20-30 tweets every update.",
  "id" : 805084890,
  "in_reply_to_status_id" : 805078498,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "hober",
  "in_reply_to_user_id_str" : "13607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804298972",
  "text" : "does anyone actually bother to organize and sort their delicious tags?",
  "id" : 804298972,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 34, 43 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804303856",
  "text" : "Two face from batman, courtesy of @mittense: http:\/\/www.aintitcool.com\/node\/36628",
  "id" : 804303856,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804299513",
  "geo" : { },
  "id_str" : "804305455",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror I still need to plug my way through CC2. I get caught up in it because there's not a lot of practical 'go do this' examples.",
  "id" : 804305455,
  "in_reply_to_status_id" : 804299513,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    }, {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 63, 76 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804313324",
  "geo" : { },
  "id_str" : "804315421",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway What kind of black magic do you have to do to get @codinghorror to follow you? :)",
  "id" : 804315421,
  "in_reply_to_status_id" : 804313324,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804322040",
  "geo" : { },
  "id_str" : "804323701",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway Yeah, it just seems like he's using Twitter mostly just to keep track of people he knows, not necessarily meet\/follow others :\/",
  "id" : 804323701,
  "in_reply_to_status_id" : 804322040,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804330701",
  "text" : "Wow. $700 for RubyFringe. Such an awesome list of speakers though: http:\/\/rubyfringe.com\/speakers",
  "id" : 804330701,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804337382",
  "text" : "Forgoing Aptana tonight, trying out E-Text Editor and command line only.",
  "id" : 804337382,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803560269",
  "text" : "Retweeting @TheADOGuy: I usually don't like Conan, but if you play GTA4, you'll love this: http:\/\/is.gd\/c0C",
  "id" : 803560269,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803562708",
  "geo" : { },
  "id_str" : "803563283",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Crap.",
  "id" : 803563283,
  "in_reply_to_status_id" : 803562708,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803563826",
  "text" : "CORRECTION: Conan is awesome. If you've tried GTA, watch his bit on a 'nicer, softer' GTA:  http:\/\/is.gd\/c0C",
  "id" : 803563826,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : " Alec Couros",
      "screen_name" : "courosa",
      "indices" : [ 11, 19 ],
      "id_str" : "739293",
      "id" : 739293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803615225",
  "text" : "Retweeting @courosa: Homeland Security-driven Charter School seems a bit creepy - http:\/\/is.gd\/c4S",
  "id" : 803615225,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803618570",
  "geo" : { },
  "id_str" : "803620753",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Because they're STILL COUNTING.",
  "id" : 803620753,
  "in_reply_to_status_id" : 803618570,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Kedrosky",
      "screen_name" : "pkedrosky",
      "indices" : [ 0, 10 ],
      "id_str" : "1717291",
      "id" : 1717291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803620730",
  "geo" : { },
  "id_str" : "803622652",
  "in_reply_to_user_id" : 1717291,
  "text" : "@pkedrosky We've all got to start somewhere, hoping that someone will listen.",
  "id" : 803622652,
  "in_reply_to_status_id" : 803620730,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "pkedrosky",
  "in_reply_to_user_id_str" : "1717291",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803623481",
  "text" : "Ok, I can't stand working like this. I need a desk. And a comfy chair.",
  "id" : 803623481,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803828596",
  "text" : "Neat blog about why Japan's computer development and history differs from America's: http:\/\/is.gd\/cb0 (Or, why they have cooler phones)",
  "id" : 803828596,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803834002",
  "text" : "Have any bloggers used http:\/\/intensedebate.com\/ that you know of?",
  "id" : 803834002,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : " Jake McKee",
      "screen_name" : "jakemckee",
      "indices" : [ 11, 21 ],
      "id_str" : "734343",
      "id" : 734343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803836395",
  "text" : "Retweeting @jakemckee: Blog Update: Microsoft Photosynth is Amazing http:\/\/tinyurl.com\/6nnlv8",
  "id" : 803836395,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803839474",
  "text" : "Trying out Photosynth of St. Peter's in Rome is absolutely astounding. I hope the 3D Quicktime guys are crapping their pants.",
  "id" : 803839474,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee McKusick",
      "screen_name" : "LeeMcKusick",
      "indices" : [ 0, 12 ],
      "id_str" : "10234782",
      "id" : 10234782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803861853",
  "geo" : { },
  "id_str" : "803862842",
  "in_reply_to_user_id" : 10234782,
  "text" : "@leemckusick Week 9 is never good.",
  "id" : 803862842,
  "in_reply_to_status_id" : 803861853,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "LeeMcKusick",
  "in_reply_to_user_id_str" : "10234782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803863594",
  "geo" : { },
  "id_str" : "803863833",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Nintendo DS market to crash? The gameboy handheld market has been going strong for years now. Make pokemon, and they will buy.",
  "id" : 803863833,
  "in_reply_to_status_id" : 803863594,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Efisia",
      "screen_name" : "01000101",
      "indices" : [ 0, 9 ],
      "id_str" : "3638351",
      "id" : 3638351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803867368",
  "geo" : { },
  "id_str" : "803868508",
  "in_reply_to_user_id" : 3638351,
  "text" : "@01000101 I like how Ebaums' world now makes 100% sure you WANT to see what you clicked on.",
  "id" : 803868508,
  "in_reply_to_status_id" : 803867368,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "01000101",
  "in_reply_to_user_id_str" : "3638351",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Kelly",
      "screen_name" : "inkedmn",
      "indices" : [ 0, 8 ],
      "id_str" : "2844098929",
      "id" : 2844098929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803880174",
  "geo" : { },
  "id_str" : "803882446",
  "in_reply_to_user_id" : 434883,
  "text" : "@inkedmn At least I got chicken.",
  "id" : 803882446,
  "in_reply_to_status_id" : 803880174,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrbrettkelly",
  "in_reply_to_user_id_str" : "434883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer P",
      "screen_name" : "jdots24",
      "indices" : [ 0, 8 ],
      "id_str" : "9897172",
      "id" : 9897172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803963127",
  "geo" : { },
  "id_str" : "803965796",
  "in_reply_to_user_id" : 9897172,
  "text" : "@jdots24 I saw the pizza out there, the staff was guarding it ferociously.",
  "id" : 803965796,
  "in_reply_to_status_id" : 803963127,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "jdots24",
  "in_reply_to_user_id_str" : "9897172",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804047106",
  "text" : "Seth MacFarlane is one rich dude. http:\/\/tinyurl.com\/62b43m",
  "id" : 804047106,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804089984",
  "text" : "Wow. Debevec's HDR videos from SIGGRAPH are absolutely astounding. Watching the Parthenon from 2004 in CG class: http:\/\/is.gd\/cjZ",
  "id" : 804089984,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ Vaynerchuk",
      "screen_name" : "ajvchuk",
      "indices" : [ 0, 8 ],
      "id_str" : "15235124",
      "id" : 15235124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803930274",
  "geo" : { },
  "id_str" : "804092304",
  "in_reply_to_user_id" : 792537,
  "text" : "@ajvchuk Honestly, I'd be completely ok with my facebook profile looking like that.",
  "id" : 804092304,
  "in_reply_to_status_id" : 803930274,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "ajv",
  "in_reply_to_user_id_str" : "792537",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804205807",
  "text" : "Huge callouses are forming on my fingers, finally, after several weeks of bass playing.",
  "id" : 804205807,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Anttila",
      "screen_name" : "aanttila",
      "indices" : [ 0, 9 ],
      "id_str" : "14148170",
      "id" : 14148170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804218981",
  "geo" : { },
  "id_str" : "804221004",
  "in_reply_to_user_id" : 14148170,
  "text" : "@aanttila You're repeating what another person tweeted, usually because it's some funny\/special\/important.",
  "id" : 804221004,
  "in_reply_to_status_id" : 804218981,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "aanttila",
  "in_reply_to_user_id_str" : "14148170",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804225010",
  "text" : "I see an alternate future, where I am no longer a .NET\/Windows junkie, and I'm using a Macbook and I'm a Rails guru. It scares me, sort of.",
  "id" : 804225010,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804229134",
  "geo" : { },
  "id_str" : "804236590",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 Yeah, same concept. It's haunting.",
  "id" : 804236590,
  "in_reply_to_status_id" : 804229134,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804229134",
  "geo" : { },
  "id_str" : "804241054",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 I've heard that the OSX\/Cocoa APIs are just as scary as .NET. I actually don't mind .NET though.",
  "id" : 804241054,
  "in_reply_to_status_id" : 804229134,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Anttila",
      "screen_name" : "aanttila",
      "indices" : [ 0, 9 ],
      "id_str" : "14148170",
      "id" : 14148170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804242718",
  "geo" : { },
  "id_str" : "804244348",
  "in_reply_to_user_id" : 14148170,
  "text" : "@aanttila If you know of any pressing arguments to upgrade to ASP.NET 3.5, I could be glad to see them.",
  "id" : 804244348,
  "in_reply_to_status_id" : 804242718,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "aanttila",
  "in_reply_to_user_id_str" : "14148170",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Colligan",
      "screen_name" : "colligan",
      "indices" : [ 0, 9 ],
      "id_str" : "511283",
      "id" : 511283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "804256922",
  "geo" : { },
  "id_str" : "804259977",
  "in_reply_to_user_id" : 511283,
  "text" : "@colligan It's become self-aware. Stop it before it activates Skynet!",
  "id" : 804259977,
  "in_reply_to_status_id" : 804256922,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "colligan",
  "in_reply_to_user_id_str" : "511283",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803276886",
  "text" : "I haven't slept past noon in a long while. Definitely didn't help.",
  "id" : 803276886,
  "created_at" : "2008-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellie Banks",
      "screen_name" : "iEllie",
      "indices" : [ 0, 7 ],
      "id_str" : "8111452",
      "id" : 8111452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803288647",
  "geo" : { },
  "id_str" : "803292005",
  "in_reply_to_user_id" : 8111452,
  "text" : "@iellie Be glad...my college doesn't get out for another 3 weeks. :(",
  "id" : 803292005,
  "in_reply_to_status_id" : 803288647,
  "created_at" : "2008-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "iEllie",
  "in_reply_to_user_id_str" : "8111452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803400519",
  "text" : "Another afternoon with Ruby on Rails. Ahh, bliss.",
  "id" : 803400519,
  "created_at" : "2008-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802647528",
  "text" : "already tons of people at imagine RIT! lots of families too.",
  "id" : 802647528,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802658136",
  "text" : "ok, robotic hot dog machine is awesome. ill upload the video tonight",
  "id" : 802658136,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802542973",
  "geo" : { },
  "id_str" : "802664525",
  "in_reply_to_user_id" : 5744442,
  "text" : "@ablissfulgal is on rnews! yes we have a 24 hr news station. idk why.",
  "id" : 802664525,
  "in_reply_to_status_id" : 802542973,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802679996",
  "text" : "ok. no just a lot of people. its a mad house",
  "id" : 802679996,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "NateLewis",
      "indices" : [ 0, 10 ],
      "id_str" : "4614511",
      "id" : 4614511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802655202",
  "geo" : { },
  "id_str" : "802696412",
  "in_reply_to_user_id" : 4614511,
  "text" : "@NateLewis Yes sir, 3rd year software engineering. Technically 4th. Or something.",
  "id" : 802696412,
  "in_reply_to_status_id" : 802655202,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "NateLewis",
  "in_reply_to_user_id_str" : "4614511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "NateLewis",
      "indices" : [ 0, 10 ],
      "id_str" : "4614511",
      "id" : 4614511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802699168",
  "geo" : { },
  "id_str" : "802700181",
  "in_reply_to_user_id" : 4614511,
  "text" : "@NateLewis I don't know him. SSE is now full of mostly dbags that like to brownnose to the professors. :) Sad because they're why I chose SE",
  "id" : 802700181,
  "in_reply_to_status_id" : 802699168,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "NateLewis",
  "in_reply_to_user_id_str" : "4614511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana Taylor",
      "screen_name" : "alanataylor",
      "indices" : [ 0, 12 ],
      "id_str" : "12367712",
      "id" : 12367712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802705193",
  "geo" : { },
  "id_str" : "802706110",
  "in_reply_to_user_id" : 12367712,
  "text" : "@alanataylor Aren't you normal college people done already? (RIT is on quarters so we're not done for another 3 weeks)",
  "id" : 802706110,
  "in_reply_to_status_id" : 802705193,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "alanataylor",
  "in_reply_to_user_id_str" : "12367712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana Taylor",
      "screen_name" : "alanataylor",
      "indices" : [ 0, 12 ],
      "id_str" : "12367712",
      "id" : 12367712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802707346",
  "geo" : { },
  "id_str" : "802710886",
  "in_reply_to_user_id" : 12367712,
  "text" : "@alanataylor Correction: worthless AND expensive crap.",
  "id" : 802710886,
  "in_reply_to_status_id" : 802707346,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "alanataylor",
  "in_reply_to_user_id_str" : "12367712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Scoble",
      "screen_name" : "Scobleizer",
      "indices" : [ 0, 11 ],
      "id_str" : "13348",
      "id" : 13348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802723068",
  "geo" : { },
  "id_str" : "802724381",
  "in_reply_to_user_id" : 13348,
  "text" : "@Scobleizer Amen. I think you're the king of early adoption, reigning heir to the bleeding edge.",
  "id" : 802724381,
  "in_reply_to_status_id" : 802723068,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "Scobleizer",
  "in_reply_to_user_id_str" : "13348",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana Taylor",
      "screen_name" : "alanataylor",
      "indices" : [ 0, 12 ],
      "id_str" : "12367712",
      "id" : 12367712
    }, {
      "name" : "Robert Scoble",
      "screen_name" : "Scobleizer",
      "indices" : [ 24, 35 ],
      "id_str" : "13348",
      "id" : 13348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802707346",
  "geo" : { },
  "id_str" : "802724795",
  "in_reply_to_user_id" : 12367712,
  "text" : "@alanataylor looks like @scobleizer linked to your ustream! http:\/\/tinyurl.com\/56rruh",
  "id" : 802724795,
  "in_reply_to_status_id" : 802707346,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "alanataylor",
  "in_reply_to_user_id_str" : "12367712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802757655",
  "text" : "Feeling extremely gimped as I use a Mac to play with Renderman.",
  "id" : 802757655,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802825729",
  "text" : "Alright, Renderman isn't too bad. I just couldn't stand writing my own shaders from scratch. That would be hardcore.",
  "id" : 802825729,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802847406",
  "text" : "Done enough with Renderman, made a silly pac-man scene. Good enough! SHIP IT.",
  "id" : 802847406,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana Taylor",
      "screen_name" : "alanataylor",
      "indices" : [ 0, 12 ],
      "id_str" : "12367712",
      "id" : 12367712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802869259",
  "geo" : { },
  "id_str" : "802869430",
  "in_reply_to_user_id" : 12367712,
  "text" : "@alanataylor I am too! At some point tonight. How expensive are the movie tickets in NYC? I imagine it's worse than Rohcester.",
  "id" : 802869430,
  "in_reply_to_status_id" : 802869259,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "alanataylor",
  "in_reply_to_user_id_str" : "12367712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 5, 13 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802299162",
  "text" : "From @jeresig: This pub has a drink called ruby on rails: gin, strawberry syrup, and ros\u00E9. After two I can confirm that RoR scales well.",
  "id" : 802299162,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802299522",
  "text" : "Well, I went to Shabbat. Judaism is...interesting. Not my bag, but the ceremony (and food) was very nice.",
  "id" : 802299522,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802407443",
  "text" : "Having way too much fun with GTA4's multiplayer.",
  "id" : 802407443,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Elder",
      "screen_name" : "keithelder",
      "indices" : [ 0, 11 ],
      "id_str" : "6136542",
      "id" : 6136542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802564156",
  "geo" : { },
  "id_str" : "802567365",
  "in_reply_to_user_id" : 6136542,
  "text" : "@keithelder Your 'litany of verbal spillage' is a great tribute to KISS and design analysis. Great post, definitely bookmarked :)",
  "id" : 802567365,
  "in_reply_to_status_id" : 802564156,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "keithelder",
  "in_reply_to_user_id_str" : "6136542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0413\u0440\u0430\u043D\u043E\u0432\u0441\u043A\u0430\u044F \u0422\u0430\u0442\u044C\u044F\u043D\u0430",
      "screen_name" : "anjrued",
      "indices" : [ 0, 8 ],
      "id_str" : "2836824647",
      "id" : 2836824647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802364670",
  "geo" : { },
  "id_str" : "802612801",
  "in_reply_to_user_id" : 860851,
  "text" : "@anjrued Do you use Backpack's calendar? is it better than Google calendar?",
  "id" : 802612801,
  "in_reply_to_status_id" : 802364670,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewdobrow",
  "in_reply_to_user_id_str" : "860851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802640056",
  "text" : "Alright, I've reached the end of the internet. Heading to RIT's imagine fair for some robotically cooked hotdogs from @ablissfulgal's club.",
  "id" : 802640056,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "801862651",
  "text" : "REMINDER: It's Friday.",
  "id" : 801862651,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scheirman",
      "screen_name" : "subdigital",
      "indices" : [ 0, 11 ],
      "id_str" : "14133001",
      "id" : 14133001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801878630",
  "geo" : { },
  "id_str" : "801881923",
  "in_reply_to_user_id" : 14133001,
  "text" : "@subdigital Yes, it is. Awesome blog post about it: http:\/\/ifightrobots.com\/?p=62",
  "id" : 801881923,
  "in_reply_to_status_id" : 801878630,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "subdigital",
  "in_reply_to_user_id_str" : "14133001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "801896557",
  "text" : "Refacing government tender. Hilarious. http:\/\/www.flickr.com\/photos\/joefxd\/sets\/72157604423778692\/",
  "id" : 801896557,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802011243",
  "text" : "I really like the club I'm running, but I just plain suck at running it.",
  "id" : 802011243,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Hockenberry",
      "screen_name" : "chockenberry",
      "indices" : [ 0, 13 ],
      "id_str" : "36183",
      "id" : 36183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802065346",
  "geo" : { },
  "id_str" : "802070423",
  "in_reply_to_user_id" : 36183,
  "text" : "@chockenberry ALL CAPS IS CRUISE CONTROL FOR COOL",
  "id" : 802070423,
  "in_reply_to_status_id" : 802065346,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "chockenberry",
  "in_reply_to_user_id_str" : "36183",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Kelly",
      "screen_name" : "inkedmn",
      "indices" : [ 0, 8 ],
      "id_str" : "2844098929",
      "id" : 2844098929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802089281",
  "geo" : { },
  "id_str" : "802089551",
  "in_reply_to_user_id" : 434883,
  "text" : "@inkedmn Have you tried jQuery?",
  "id" : 802089551,
  "in_reply_to_status_id" : 802089281,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrbrettkelly",
  "in_reply_to_user_id_str" : "434883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kodak Alaris SM MGR",
      "screen_name" : "kodakCB",
      "indices" : [ 0, 8 ],
      "id_str" : "14590903",
      "id" : 14590903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802084976",
  "geo" : { },
  "id_str" : "802090014",
  "in_reply_to_user_id" : 14590903,
  "text" : "@kodakCB Hey there! I'm going to be interning for Kodak this summer :)",
  "id" : 802090014,
  "in_reply_to_status_id" : 802084976,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "kodakCB",
  "in_reply_to_user_id_str" : "14590903",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Kelly",
      "screen_name" : "inkedmn",
      "indices" : [ 0, 8 ],
      "id_str" : "2844098929",
      "id" : 2844098929
    }, {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 80, 88 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802090432",
  "geo" : { },
  "id_str" : "802091374",
  "in_reply_to_user_id" : 434883,
  "text" : "@inkedmn That's a shame, from my experience it's very speedy on IE. Perhaps bug @jeresig about it? (the creator himself!)",
  "id" : 802091374,
  "in_reply_to_status_id" : 802090432,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrbrettkelly",
  "in_reply_to_user_id_str" : "434883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Mah",
      "screen_name" : "JessicaMah",
      "indices" : [ 0, 11 ],
      "id_str" : "3940201",
      "id" : 3940201
    }, {
      "name" : "AJ Vaynerchuk",
      "screen_name" : "ajvchuk",
      "indices" : [ 50, 58 ],
      "id_str" : "15235124",
      "id" : 15235124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802090991",
  "geo" : { },
  "id_str" : "802092145",
  "in_reply_to_user_id" : 3940201,
  "text" : "@JessicaMah Congrats! So will you be working with @ajvchuk?",
  "id" : 802092145,
  "in_reply_to_status_id" : 802090991,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "JessicaMah",
  "in_reply_to_user_id_str" : "3940201",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802101306",
  "geo" : { },
  "id_str" : "802104218",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort That wouldn't make much sense, it doesn't really have threads. You have to use setInterval or setTimeout if you want a delay.",
  "id" : 802104218,
  "in_reply_to_status_id" : 802101306,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802119508",
  "text" : "Really getting sick of the Slashdot and Techcrunch talking about Twitter dropping Rails. It ain't happening, it can scale fine, get over it!",
  "id" : 802119508,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802121469",
  "geo" : { },
  "id_str" : "802122679",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco That's a load of bullcrap. Caching and database optimization are key. Load balancing and more machines won't help with that.",
  "id" : 802122679,
  "in_reply_to_status_id" : 802121469,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802125030",
  "geo" : { },
  "id_str" : "802134327",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco of course there's nothing that can be done if ActiveRecord is producing crap SQL and your DB model blows.",
  "id" : 802134327,
  "in_reply_to_status_id" : 802125030,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shella",
      "screen_name" : "Shella",
      "indices" : [ 0, 7 ],
      "id_str" : "814306",
      "id" : 814306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802162363",
  "geo" : { },
  "id_str" : "802169782",
  "in_reply_to_user_id" : 814306,
  "text" : "@Shella Alright, which movie features a badass who can FLY. Choose that one.",
  "id" : 802169782,
  "in_reply_to_status_id" : 802162363,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "Shella",
  "in_reply_to_user_id_str" : "814306",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
Grailbird.data.tweets_2013_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 19, 25 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418222086281121793",
  "text" : "Couch^H^H^H^HTRUCK @phish tour night four!",
  "id" : 418222086281121793,
  "created_at" : "2014-01-01 03:28:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 23, 33 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/tIlIaKWXRU",
      "expanded_url" : "https:\/\/qrush.exposure.so\/2013",
      "display_url" : "qrush.exposure.so\/2013"
    } ]
  },
  "geo" : { },
  "id_str" : "418148557598646272",
  "text" : "50 moments of mine and @aquaranto's from 2013: https:\/\/t.co\/tIlIaKWXRU Happy 2014 everyone!",
  "id" : 418148557598646272,
  "created_at" : "2013-12-31 22:35:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "indices" : [ 0, 13 ],
      "id_str" : "9154112",
      "id" : 9154112
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 14, 28 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Lindsay Felt",
      "screen_name" : "ArayaNexus",
      "indices" : [ 29, 40 ],
      "id_str" : "8253932",
      "id" : 8253932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/1JZrAUIxt8",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush\/8746762813\/",
      "display_url" : "flickr.com\/photos\/qrush\/8\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "418098494906564608",
  "geo" : { },
  "id_str" : "418119015723053057",
  "in_reply_to_user_id" : 9154112,
  "text" : "@jeremiahfelt @coworkbuffalo @ArayaNexus full shot - http:\/\/t.co\/1JZrAUIxt8",
  "id" : 418119015723053057,
  "in_reply_to_status_id" : 418098494906564608,
  "created_at" : "2013-12-31 20:38:36 +0000",
  "in_reply_to_screen_name" : "jeremiahfelt",
  "in_reply_to_user_id_str" : "9154112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "indices" : [ 0, 13 ],
      "id_str" : "9154112",
      "id" : 9154112
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 14, 28 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Lindsay Felt",
      "screen_name" : "ArayaNexus",
      "indices" : [ 29, 40 ],
      "id_str" : "8253932",
      "id" : 8253932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418098494906564608",
  "geo" : { },
  "id_str" : "418099055235829760",
  "in_reply_to_user_id" : 9154112,
  "text" : "@jeremiahfelt @coworkbuffalo @ArayaNexus it's an old stereotype from the Buffalo News printing press",
  "id" : 418099055235829760,
  "in_reply_to_status_id" : 418098494906564608,
  "created_at" : "2013-12-31 19:19:17 +0000",
  "in_reply_to_screen_name" : "jeremiahfelt",
  "in_reply_to_user_id_str" : "9154112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/418096634774298624\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/swzVlJYOFx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc1grHrCEAAaLuC.jpg",
      "id_str" : "418096634325504000",
      "id" : 418096634325504000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc1grHrCEAAaLuC.jpg",
      "sizes" : [ {
        "h" : 1811,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1061,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1811,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/swzVlJYOFx"
    } ],
    "hashtags" : [ {
      "text" : "OnOurWall",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418096868598374400",
  "text" : "RT @coworkbuffalo: Even in 1947, Kenmore traffic cops were intimidating. #OnOurWall http:\/\/t.co\/swzVlJYOFx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/carbonandroid\" rel=\"nofollow\"\u003ECarbon for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/418096634774298624\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/swzVlJYOFx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc1grHrCEAAaLuC.jpg",
        "id_str" : "418096634325504000",
        "id" : 418096634325504000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc1grHrCEAAaLuC.jpg",
        "sizes" : [ {
          "h" : 1811,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1061,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1811,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/swzVlJYOFx"
      } ],
      "hashtags" : [ {
        "text" : "OnOurWall",
        "indices" : [ 54, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "418096634774298624",
    "text" : "Even in 1947, Kenmore traffic cops were intimidating. #OnOurWall http:\/\/t.co\/swzVlJYOFx",
    "id" : 418096634774298624,
    "created_at" : "2013-12-31 19:09:40 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 418096868598374400,
  "created_at" : "2013-12-31 19:10:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strand McDadJokes ",
      "screen_name" : "Strabd",
      "indices" : [ 0, 7 ],
      "id_str" : "18032208",
      "id" : 18032208
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 8, 19 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418069222481068032",
  "geo" : { },
  "id_str" : "418072669037154304",
  "in_reply_to_user_id" : 18032208,
  "text" : "@Strabd @ashedryden not joking: BookIt for adults would be awesome. Complete with the certificates. And pizzas.",
  "id" : 418072669037154304,
  "in_reply_to_status_id" : 418069222481068032,
  "created_at" : "2013-12-31 17:34:26 +0000",
  "in_reply_to_screen_name" : "Strabd",
  "in_reply_to_user_id_str" : "18032208",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418059570716893184",
  "geo" : { },
  "id_str" : "418060846938349568",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox In any case, if you want to trade for the mp3s, let me know. Would be more than happy to swap for other shows.",
  "id" : 418060846938349568,
  "in_reply_to_status_id" : 418059570716893184,
  "created_at" : "2013-12-31 16:47:27 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418059570716893184",
  "geo" : { },
  "id_str" : "418060218358968320",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox I bought all 4 nights and the live webcasts. Seriously... $$$",
  "id" : 418060218358968320,
  "in_reply_to_status_id" : 418059570716893184,
  "created_at" : "2013-12-31 16:44:57 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Voss",
      "screen_name" : "seldo",
      "indices" : [ 3, 9 ],
      "id_str" : "15453",
      "id" : 15453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418040695119937536",
  "text" : "RT @seldo: 2013 in summary: every computer that exists is being used to spy on you. Here's one you can wear on your face!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "417759238249660416",
    "text" : "2013 in summary: every computer that exists is being used to spy on you. Here's one you can wear on your face!",
    "id" : 417759238249660416,
    "created_at" : "2013-12-30 20:48:58 +0000",
    "user" : {
      "name" : "Laurie Voss",
      "screen_name" : "seldo",
      "protected" : false,
      "id_str" : "15453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565049845677699072\/BKdxhQWl_normal.jpeg",
      "id" : 15453,
      "verified" : false
    }
  },
  "id" : 418040695119937536,
  "created_at" : "2013-12-31 15:27:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418013116602253312",
  "geo" : { },
  "id_str" : "418023789511708672",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler pizza",
  "id" : 418023789511708672,
  "in_reply_to_status_id" : 418013116602253312,
  "created_at" : "2013-12-31 14:20:12 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417893437782753280",
  "geo" : { },
  "id_str" : "417942891445891072",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden i loved this program. Sad to say but I love personal pan pizzas even more.",
  "id" : 417942891445891072,
  "in_reply_to_status_id" : 417893437782753280,
  "created_at" : "2013-12-31 08:58:44 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 0, 11 ],
      "id_str" : "14620776",
      "id" : 14620776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417865252198301697",
  "geo" : { },
  "id_str" : "417896510492123136",
  "in_reply_to_user_id" : 14620776,
  "text" : "@ellenchisa it's alright...but super difficult. Most games I've played end in utter but hilarious failure.",
  "id" : 417896510492123136,
  "in_reply_to_status_id" : 417865252198301697,
  "created_at" : "2013-12-31 05:54:26 +0000",
  "in_reply_to_screen_name" : "ellenchisa",
  "in_reply_to_user_id_str" : "14620776",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417859842586312704",
  "geo" : { },
  "id_str" : "417860268723425280",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror well how else would you log in, silly?",
  "id" : 417860268723425280,
  "in_reply_to_status_id" : 417859842586312704,
  "created_at" : "2013-12-31 03:30:26 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 0, 7 ],
      "id_str" : "34953",
      "id" : 34953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417854377320124416",
  "geo" : { },
  "id_str" : "417855468795482113",
  "in_reply_to_user_id" : 34953,
  "text" : "@nathos corporations are people last time I checked!",
  "id" : 417855468795482113,
  "in_reply_to_status_id" : 417854377320124416,
  "created_at" : "2013-12-31 03:11:21 +0000",
  "in_reply_to_screen_name" : "nathos",
  "in_reply_to_user_id_str" : "34953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 0, 12 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417854023468077056",
  "geo" : { },
  "id_str" : "417854363370274816",
  "in_reply_to_user_id" : 930061,
  "text" : "@ginatrapani I wonder if people who don't work on the web even notice the details like that...matters to us, but invisible to others I feel",
  "id" : 417854363370274816,
  "in_reply_to_status_id" : 417854023468077056,
  "created_at" : "2013-12-31 03:06:58 +0000",
  "in_reply_to_screen_name" : "ginatrapani",
  "in_reply_to_user_id_str" : "930061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penguinoh Waddles",
      "screen_name" : "penguinoh",
      "indices" : [ 0, 10 ],
      "id_str" : "93986627",
      "id" : 93986627
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417853944359288833",
  "geo" : { },
  "id_str" : "417854084650004480",
  "in_reply_to_user_id" : 93986627,
  "text" : "@penguinoh I got 99 penguins and you ain't one",
  "id" : 417854084650004480,
  "in_reply_to_status_id" : 417853944359288833,
  "created_at" : "2013-12-31 03:05:51 +0000",
  "in_reply_to_screen_name" : "penguinoh",
  "in_reply_to_user_id_str" : "93986627",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417853865795395584",
  "text" : "Also feels like Google Wallet missed the boat. They had almost the same system...but no app. Need both!",
  "id" : 417853865795395584,
  "created_at" : "2013-12-31 03:04:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 20, 26 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417838332274438144",
  "text" : "Couch tour night 3. @phish continues to kill it.",
  "id" : 417838332274438144,
  "created_at" : "2013-12-31 02:03:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417755767651835904",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden permission to email? quick question.",
  "id" : 417755767651835904,
  "created_at" : "2013-12-30 20:35:11 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/zdacW4Kc3E",
      "expanded_url" : "http:\/\/leaksource.wordpress.com\/2013\/12\/30\/nsas-ant-division-catalog-of-exploits-for-nearly-every-major-software-hardware-firmware\/",
      "display_url" : "leaksource.wordpress.com\/2013\/12\/30\/nsa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417741931695722496",
  "text" : "If this catalog of NSA contraptions doesn't scare the shit out of you, I don't know what would. http:\/\/t.co\/zdacW4Kc3E",
  "id" : 417741931695722496,
  "created_at" : "2013-12-30 19:40:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "indices" : [ 3, 14 ],
      "id_str" : "1232850504",
      "id" : 1232850504
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 88, 102 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/3kEaFstZdL",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417737664914546688",
  "text" : "RT @gdiBuffalo: Would you love to see more awesome meetup and classroom spaces? Support @coworkbuffalo. They have 10% more to go!  http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 72, 86 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/3kEaFstZdL",
        "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community",
        "display_url" : "kickstarter.com\/projects\/cowor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "417730663106637825",
    "text" : "Would you love to see more awesome meetup and classroom spaces? Support @coworkbuffalo. They have 10% more to go!  http:\/\/t.co\/3kEaFstZdL",
    "id" : 417730663106637825,
    "created_at" : "2013-12-30 18:55:25 +0000",
    "user" : {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "protected" : false,
      "id_str" : "1232850504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3326614365\/de10a9f13010fc569fd25c1a6392366c_normal.png",
      "id" : 1232850504,
      "verified" : false
    }
  },
  "id" : 417737664914546688,
  "created_at" : "2013-12-30 19:23:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 0, 12 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417683315572109312",
  "geo" : { },
  "id_str" : "417720344074391553",
  "in_reply_to_user_id" : 14231571,
  "text" : "@marcoarment what tool\/gem was this, btw?",
  "id" : 417720344074391553,
  "in_reply_to_status_id" : 417683315572109312,
  "created_at" : "2013-12-30 18:14:25 +0000",
  "in_reply_to_screen_name" : "marcoarment",
  "in_reply_to_user_id_str" : "14231571",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 22, 36 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/IKIiSJdGiK",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417717852607483904",
  "text" : "Hey, it's Monday, and @coworkbuffalo's campaign is 90% there. You know you want a sticker: http:\/\/t.co\/IKIiSJdGiK",
  "id" : 417717852607483904,
  "created_at" : "2013-12-30 18:04:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/QHKCnxl3Wp",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2013\/11\/23\/sync-and-edit-files-on-two-iphones\/",
      "display_url" : "quaran.to\/blog\/2013\/11\/2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "417716051913089025",
  "geo" : { },
  "id_str" : "417716578910609408",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam Plaintext. http:\/\/t.co\/QHKCnxl3Wp",
  "id" : 417716578910609408,
  "in_reply_to_status_id" : 417716051913089025,
  "created_at" : "2013-12-30 17:59:27 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Arreche",
      "screen_name" : "SaltineJustine",
      "indices" : [ 0, 15 ],
      "id_str" : "18210275",
      "id" : 18210275
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 122, 137 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417713553240363008",
  "geo" : { },
  "id_str" : "417715062590021632",
  "in_reply_to_user_id" : 18210275,
  "text" : "@SaltineJustine that it's possible to bring a lot of smart and fun people together to a small city and have a great time (@nickelcityruby)",
  "id" : 417715062590021632,
  "in_reply_to_status_id" : 417713553240363008,
  "created_at" : "2013-12-30 17:53:26 +0000",
  "in_reply_to_screen_name" : "SaltineJustine",
  "in_reply_to_user_id_str" : "18210275",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Gee",
      "screen_name" : "DerekGeePhoto",
      "indices" : [ 0, 14 ],
      "id_str" : "1634451608",
      "id" : 1634451608
    }, {
      "name" : "Exposure",
      "screen_name" : "exposure",
      "indices" : [ 83, 92 ],
      "id_str" : "1884366962",
      "id" : 1884366962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/4kQz2wSgmc",
      "expanded_url" : "https:\/\/exposure.so\/",
      "display_url" : "exposure.so"
    } ]
  },
  "in_reply_to_status_id_str" : "417714249448685568",
  "geo" : { },
  "id_str" : "417714692031668225",
  "in_reply_to_user_id" : 1634451608,
  "text" : "@DerekGeePhoto I wish these could be published in a way bigger resolution. Want an @exposure invite? :) https:\/\/t.co\/4kQz2wSgmc",
  "id" : 417714692031668225,
  "in_reply_to_status_id" : 417714249448685568,
  "created_at" : "2013-12-30 17:51:58 +0000",
  "in_reply_to_screen_name" : "DerekGeePhoto",
  "in_reply_to_user_id_str" : "1634451608",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ra Cha Cha",
      "screen_name" : "HeyRaChaCha",
      "indices" : [ 0, 12 ],
      "id_str" : "261031908",
      "id" : 261031908
    }, {
      "name" : "5 Nights at Jamie's*",
      "screen_name" : "death2normalcy",
      "indices" : [ 13, 28 ],
      "id_str" : "129537034",
      "id" : 129537034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417691803576328193",
  "geo" : { },
  "id_str" : "417704773609979905",
  "in_reply_to_user_id" : 261031908,
  "text" : "@HeyRaChaCha @death2normalcy Thanks! Really excited to be a part of the 600 block revival.",
  "id" : 417704773609979905,
  "in_reply_to_status_id" : 417691803576328193,
  "created_at" : "2013-12-30 17:12:33 +0000",
  "in_reply_to_screen_name" : "HeyRaChaCha",
  "in_reply_to_user_id_str" : "261031908",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 16, 27 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417689289791918080",
  "geo" : { },
  "id_str" : "417689582172254208",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante hey @shellscape, know anyone?",
  "id" : 417689582172254208,
  "in_reply_to_status_id" : 417689289791918080,
  "created_at" : "2013-12-30 16:12:11 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "5 Nights at Jamie's*",
      "screen_name" : "death2normalcy",
      "indices" : [ 0, 15 ],
      "id_str" : "129537034",
      "id" : 129537034
    }, {
      "name" : "Ra Cha Cha",
      "screen_name" : "HeyRaChaCha",
      "indices" : [ 16, 28 ],
      "id_str" : "261031908",
      "id" : 261031908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/axaiRQl5lI",
      "expanded_url" : "https:\/\/twitter.com\/coworkbuffalo\/status\/416226048548675584",
      "display_url" : "twitter.com\/coworkbuffalo\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "417681804725092352",
  "geo" : { },
  "id_str" : "417689429419884544",
  "in_reply_to_user_id" : 129537034,
  "text" : "@death2normalcy @HeyRaChaCha we are directly across from Shea's now. Our view last week: https:\/\/t.co\/axaiRQl5lI",
  "id" : 417689429419884544,
  "in_reply_to_status_id" : 417681804725092352,
  "created_at" : "2013-12-30 16:11:34 +0000",
  "in_reply_to_screen_name" : "death2normalcy",
  "in_reply_to_user_id_str" : "129537034",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 49, 63 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417668685898063872",
  "geo" : { },
  "id_str" : "417670811135537152",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit obviously biased but for Buffalo: @coworkbuffalo turned 1 year, moved to Main, running a Kickstarter?",
  "id" : 417670811135537152,
  "in_reply_to_status_id" : 417668685898063872,
  "created_at" : "2013-12-30 14:57:35 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417514129448914944",
  "geo" : { },
  "id_str" : "417514592823017472",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt hello, 911? Yes it's an emergency. Someone didn't apologize for unfollowing.",
  "id" : 417514592823017472,
  "in_reply_to_status_id" : 417514129448914944,
  "created_at" : "2013-12-30 04:36:50 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danimal\/Armcannon",
      "screen_name" : "armcannon",
      "indices" : [ 0, 10 ],
      "id_str" : "86775045",
      "id" : 86775045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/qBPkInmqiC",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "417511793431289856",
  "geo" : { },
  "id_str" : "417512212874682369",
  "in_reply_to_user_id" : 86775045,
  "text" : "@armcannon beats our GIFs...not by much! :P http:\/\/t.co\/qBPkInmqiC",
  "id" : 417512212874682369,
  "in_reply_to_status_id" : 417511793431289856,
  "created_at" : "2013-12-30 04:27:23 +0000",
  "in_reply_to_screen_name" : "armcannon",
  "in_reply_to_user_id_str" : "86775045",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Jay Notareschi",
      "screen_name" : "jnoid23",
      "indices" : [ 10, 18 ],
      "id_str" : "307619724",
      "id" : 307619724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417507953952821249",
  "geo" : { },
  "id_str" : "417511775081594880",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo @jnoid23 gag prediction: cover night?",
  "id" : 417511775081594880,
  "in_reply_to_status_id" : 417507953952821249,
  "created_at" : "2013-12-30 04:25:38 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Aimonetti",
      "screen_name" : "mattetti",
      "indices" : [ 0, 9 ],
      "id_str" : "16476741",
      "id" : 16476741
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 40, 53 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417490098423209985",
  "geo" : { },
  "id_str" : "417490416670228480",
  "in_reply_to_user_id" : 16476741,
  "text" : "@mattetti such value. Much shampoo. \/cc @steveklabnik",
  "id" : 417490416670228480,
  "in_reply_to_status_id" : 417490098423209985,
  "created_at" : "2013-12-30 03:00:46 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    }, {
      "name" : "Kevin Christner",
      "screen_name" : "sailflyer",
      "indices" : [ 25, 35 ],
      "id_str" : "1711505156",
      "id" : 1711505156
    }, {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 40, 48 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417489373689827328",
  "geo" : { },
  "id_str" : "417489618582249472",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss sounds like you, @sailflyer and @fending need to start a trust fund",
  "id" : 417489618582249472,
  "in_reply_to_status_id" : 417489373689827328,
  "created_at" : "2013-12-30 02:57:36 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "luke arduini",
      "screen_name" : "luk",
      "indices" : [ 0, 4 ],
      "id_str" : "16569603",
      "id" : 16569603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417487335798743040",
  "geo" : { },
  "id_str" : "417489417717039106",
  "in_reply_to_user_id" : 16569603,
  "text" : "@luk ...NOT",
  "id" : 417489417717039106,
  "in_reply_to_status_id" : 417487335798743040,
  "created_at" : "2013-12-30 02:56:48 +0000",
  "in_reply_to_screen_name" : "luk",
  "in_reply_to_user_id_str" : "16569603",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/417488814525788160\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/dZSWrhWLj8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bcs33VaCIAAHU4e.jpg",
      "id_str" : "417488814240571392",
      "id" : 417488814240571392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bcs33VaCIAAHU4e.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dZSWrhWLj8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417488814525788160",
  "text" : "I just found a real Dogecoin! http:\/\/t.co\/dZSWrhWLj8",
  "id" : 417488814525788160,
  "created_at" : "2013-12-30 02:54:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417465587241975809",
  "text" : "Couch tour night 2!",
  "id" : 417465587241975809,
  "created_at" : "2013-12-30 01:22:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 3, 15 ],
      "id_str" : "158098704",
      "id" : 158098704
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mikemikemac\/status\/414821037252313088\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/37kSlDHvaW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcG9iQDIMAAPOlg.jpg",
      "id_str" : "414821036816084992",
      "id" : 414821036816084992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcG9iQDIMAAPOlg.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/37kSlDHvaW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417422402931265536",
  "text" : "RT @mikemikemac: \"Jim Kelly, right? Can you take a picture? No, just of us. Thanks\" http:\/\/t.co\/37kSlDHvaW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mikemikemac\/status\/414821037252313088\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/37kSlDHvaW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BcG9iQDIMAAPOlg.jpg",
        "id_str" : "414821036816084992",
        "id" : 414821036816084992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcG9iQDIMAAPOlg.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/37kSlDHvaW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414821037252313088",
    "text" : "\"Jim Kelly, right? Can you take a picture? No, just of us. Thanks\" http:\/\/t.co\/37kSlDHvaW",
    "id" : 414821037252313088,
    "created_at" : "2013-12-22 18:13:36 +0000",
    "user" : {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "protected" : false,
      "id_str" : "158098704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1797045056\/mikemac_normal.png",
      "id" : 158098704,
      "verified" : false
    }
  },
  "id" : 417422402931265536,
  "created_at" : "2013-12-29 22:30:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417365658762874880",
  "text" : "The Wii to WiiU transfer process has been the cutest, most attentive to detail I've seen. Little pikmin carry your data over to a spaceship!",
  "id" : 417365658762874880,
  "created_at" : "2013-12-29 18:45:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    }, {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 8, 18 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417222445968265216",
  "geo" : { },
  "id_str" : "417224011341262848",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal @raganwald have had to do this for the past few years. Ain't easy but worth it. Also, hello 4am...",
  "id" : 417224011341262848,
  "in_reply_to_status_id" : 417222445968265216,
  "created_at" : "2013-12-29 09:22:10 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LivePhish",
      "screen_name" : "LivePhish",
      "indices" : [ 3, 13 ],
      "id_str" : "232312841",
      "id" : 232312841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417120989219016704",
  "text" : "HD @livephish webcast at its finest: camera zoomed out of an fan recording the show on his phone to the actual show. *mind explodes*",
  "id" : 417120989219016704,
  "created_at" : "2013-12-29 02:32:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 6, 12 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417105680021983232",
  "text" : "Couch @phish tour: engage!",
  "id" : 417105680021983232,
  "created_at" : "2013-12-29 01:31:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 6, 15 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/416990111696691200\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/Z6kfpc6MHt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BclyTBIIQAApyvl.jpg",
      "id_str" : "416990111554093056",
      "id" : 416990111554093056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BclyTBIIQAApyvl.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/Z6kfpc6MHt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416990111696691200",
  "text" : "Found @mittense's dream game. http:\/\/t.co\/Z6kfpc6MHt",
  "id" : 416990111696691200,
  "created_at" : "2013-12-28 17:52:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416966448028725248",
  "text" : "Protip: put the filter side of the aeropress up when you're brewing inverted or you're gonna have a bad time.",
  "id" : 416966448028725248,
  "created_at" : "2013-12-28 16:18:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416718153826447360",
  "geo" : { },
  "id_str" : "416719979673698304",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi haven't really had a chance yet to play it!",
  "id" : 416719979673698304,
  "in_reply_to_status_id" : 416718153826447360,
  "created_at" : "2013-12-27 23:59:20 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416713272977784832",
  "text" : "I'm quaranto on the WiiU thingy if you have one.",
  "id" : 416713272977784832,
  "created_at" : "2013-12-27 23:32:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    }, {
      "name" : "Societal Obstacle",
      "screen_name" : "laurenvoswinkel",
      "indices" : [ 14, 30 ],
      "id_str" : "19539935",
      "id" : 19539935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/dGLJMEnr4N",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=mBmzFYSjfdE",
      "display_url" : "youtube.com\/watch?v=mBmzFY\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "416680705390034944",
  "geo" : { },
  "id_str" : "416682525486882816",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda @laurenvoswinkel Are you not having FUN with Ruby!?! https:\/\/t.co\/dGLJMEnr4N",
  "id" : 416682525486882816,
  "in_reply_to_status_id" : 416680705390034944,
  "created_at" : "2013-12-27 21:30:30 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Stuff",
      "screen_name" : "BuffaloStuff",
      "indices" : [ 0, 13 ],
      "id_str" : "31921811",
      "id" : 31921811
    }, {
      "name" : "Pete Herr",
      "screen_name" : "peteherr",
      "indices" : [ 14, 23 ],
      "id_str" : "39545383",
      "id" : 39545383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416605992156418048",
  "geo" : { },
  "id_str" : "416639170992287745",
  "in_reply_to_user_id" : 31921811,
  "text" : "@BuffaloStuff @peteherr Thanks! We've moved over on Main a week or two ago. Also, we're totally bootstrapped...no millions, no investors :)",
  "id" : 416639170992287745,
  "in_reply_to_status_id" : 416605992156418048,
  "created_at" : "2013-12-27 18:38:13 +0000",
  "in_reply_to_screen_name" : "BuffaloStuff",
  "in_reply_to_user_id_str" : "31921811",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 3, 18 ],
      "id_str" : "18777886",
      "id" : 18777886
    }, {
      "name" : "The Atlantic Cities",
      "screen_name" : "atlanticcities",
      "indices" : [ 21, 36 ],
      "id_str" : "2352223932",
      "id" : 2352223932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/mB9gsjY8bP",
      "expanded_url" : "http:\/\/www.theatlanticcities.com\/arts-and-lifestyle\/2013\/12\/best-thing-my-city-did-year\/7885\/",
      "display_url" : "theatlanticcities.com\/arts-and-lifes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416637121651150848",
  "text" : "RT @colindabkowski: .@AtlanticCities asked 20 writers about \"the best thing my city did this year.\" I chose Torn Space's Motion Picture. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Atlantic Cities",
        "screen_name" : "atlanticcities",
        "indices" : [ 1, 16 ],
        "id_str" : "2352223932",
        "id" : 2352223932
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/mB9gsjY8bP",
        "expanded_url" : "http:\/\/www.theatlanticcities.com\/arts-and-lifestyle\/2013\/12\/best-thing-my-city-did-year\/7885\/",
        "display_url" : "theatlanticcities.com\/arts-and-lifes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "416636854440435712",
    "text" : ".@AtlanticCities asked 20 writers about \"the best thing my city did this year.\" I chose Torn Space's Motion Picture. http:\/\/t.co\/mB9gsjY8bP",
    "id" : 416636854440435712,
    "created_at" : "2013-12-27 18:29:01 +0000",
    "user" : {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "protected" : false,
      "id_str" : "18777886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3037884795\/352233dadcadefd39ba870c00adc3091_normal.jpeg",
      "id" : 18777886,
      "verified" : false
    }
  },
  "id" : 416637121651150848,
  "created_at" : "2013-12-27 18:30:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/XY4h2WaFEP",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/2013\/12\/24\/michael-thomasson-video-games-world-record_n_4497742.html",
      "display_url" : "huffingtonpost.com\/2013\/12\/24\/mic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416598091840499712",
  "text" : "I wonder if this guy actually shares his games with anyone: http:\/\/t.co\/XY4h2WaFEP",
  "id" : 416598091840499712,
  "created_at" : "2013-12-27 15:54:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iA Inc.",
      "screen_name" : "iA",
      "indices" : [ 3, 6 ],
      "id_str" : "2087371",
      "id" : 2087371
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 52, 56 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416591060635119616",
  "text" : "RT @iA: We will drop our patents pending. Thank you @dhh for clearing our minds.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DHH",
        "screen_name" : "dhh",
        "indices" : [ 44, 48 ],
        "id_str" : "14561327",
        "id" : 14561327
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "416393539182796800",
    "text" : "We will drop our patents pending. Thank you @dhh for clearing our minds.",
    "id" : 416393539182796800,
    "created_at" : "2013-12-27 02:22:10 +0000",
    "user" : {
      "name" : "iA Inc.",
      "screen_name" : "iA",
      "protected" : false,
      "id_str" : "2087371",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510071324580909056\/PGyJp57__normal.png",
      "id" : 2087371,
      "verified" : false
    }
  },
  "id" : 416591060635119616,
  "created_at" : "2013-12-27 15:27:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 3, 9 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Ig3w8Ip01k",
      "expanded_url" : "http:\/\/grugq.github.io\/blog\/2013\/12\/21\/in-search-of-opsec-magic-sauce\/",
      "display_url" : "grugq.github.io\/blog\/2013\/12\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416484976721682432",
  "text" : "RT @nzkoz: Great rundown of the numerous opsec failings of the Harvard bomb-threat-exam guy http:\/\/t.co\/Ig3w8Ip01k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/Ig3w8Ip01k",
        "expanded_url" : "http:\/\/grugq.github.io\/blog\/2013\/12\/21\/in-search-of-opsec-magic-sauce\/",
        "display_url" : "grugq.github.io\/blog\/2013\/12\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "416453055421239296",
    "text" : "Great rundown of the numerous opsec failings of the Harvard bomb-threat-exam guy http:\/\/t.co\/Ig3w8Ip01k",
    "id" : 416453055421239296,
    "created_at" : "2013-12-27 06:18:40 +0000",
    "user" : {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "protected" : false,
      "id_str" : "11294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000239013338\/8ef360106b3a7420ce56f3aa8a84506b_normal.jpeg",
      "id" : 11294,
      "verified" : false
    }
  },
  "id" : 416484976721682432,
  "created_at" : "2013-12-27 08:25:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 0, 6 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416417127566831616",
  "geo" : { },
  "id_str" : "416417175302184960",
  "in_reply_to_user_id" : 205281746,
  "text" : "@ahuj9 YEAHHHHHHHHH",
  "id" : 416417175302184960,
  "in_reply_to_status_id" : 416417127566831616,
  "created_at" : "2013-12-27 03:56:05 +0000",
  "in_reply_to_screen_name" : "ahuj9",
  "in_reply_to_user_id_str" : "205281746",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 0, 6 ],
      "id_str" : "205281746",
      "id" : 205281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416414674020597760",
  "geo" : { },
  "id_str" : "416417020691746816",
  "in_reply_to_user_id" : 205281746,
  "text" : "@ahuj9 Duff's!!",
  "id" : 416417020691746816,
  "in_reply_to_status_id" : 416414674020597760,
  "created_at" : "2013-12-27 03:55:29 +0000",
  "in_reply_to_screen_name" : "ahuj9",
  "in_reply_to_user_id_str" : "205281746",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 60, 73 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416373760821051392",
  "text" : "These terrible puns brought to you by my White Russians and @wayneeseguin's horrible mind.",
  "id" : 416373760821051392,
  "created_at" : "2013-12-27 01:03:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 3, 12 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/rv7jGqNDGk",
      "expanded_url" : "http:\/\/bundler.io\/v1.5\/whats_new.html",
      "display_url" : "bundler.io\/v1.5\/whats_new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416312840656416769",
  "text" : "RT @indirect: Bundler 1.5.0 is out! Support for parallel installation of gems, ruby patchlevels, and gem server mirrors. Phew. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/rv7jGqNDGk",
        "expanded_url" : "http:\/\/bundler.io\/v1.5\/whats_new.html",
        "display_url" : "bundler.io\/v1.5\/whats_new\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "416312526985392128",
    "text" : "Bundler 1.5.0 is out! Support for parallel installation of gems, ruby patchlevels, and gem server mirrors. Phew. http:\/\/t.co\/rv7jGqNDGk",
    "id" : 416312526985392128,
    "created_at" : "2013-12-26 21:00:15 +0000",
    "user" : {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "protected" : false,
      "id_str" : "5674672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518132954120204288\/yVvIdVOH_normal.jpeg",
      "id" : 5674672,
      "verified" : false
    }
  },
  "id" : 416312840656416769,
  "created_at" : "2013-12-26 21:01:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Adam",
      "screen_name" : "thekarladam",
      "indices" : [ 3, 15 ],
      "id_str" : "14237651",
      "id" : 14237651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/rMSoRvYqrJ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=72RqpItxd8M",
      "display_url" : "youtube.com\/watch?v=72RqpI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416312441400598528",
  "text" : "RT @thekarladam: I don't think I've ever seen anything I wanted to kickstart more https:\/\/t.co\/rMSoRvYqrJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/rMSoRvYqrJ",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=72RqpItxd8M",
        "display_url" : "youtube.com\/watch?v=72RqpI\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "416307375398608897",
    "text" : "I don't think I've ever seen anything I wanted to kickstart more https:\/\/t.co\/rMSoRvYqrJ",
    "id" : 416307375398608897,
    "created_at" : "2013-12-26 20:39:47 +0000",
    "user" : {
      "name" : "Karl Adam",
      "screen_name" : "thekarladam",
      "protected" : false,
      "id_str" : "14237651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/210863907\/Picture_1_normal.jpg",
      "id" : 14237651,
      "verified" : false
    }
  },
  "id" : 416312441400598528,
  "created_at" : "2013-12-26 20:59:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/PXQRYIDsX4",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416308736576065536",
  "text" : "RT @coworkbuffalo: Our Kickstarter http:\/\/t.co\/PXQRYIDsX4 is 85% there... Help us ring in the new year working on stretch goals!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/PXQRYIDsX4",
        "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community",
        "display_url" : "kickstarter.com\/projects\/cowor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "416254449837830145",
    "text" : "Our Kickstarter http:\/\/t.co\/PXQRYIDsX4 is 85% there... Help us ring in the new year working on stretch goals!",
    "id" : 416254449837830145,
    "created_at" : "2013-12-26 17:09:29 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 416308736576065536,
  "created_at" : "2013-12-26 20:45:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416274154682216448",
  "geo" : { },
  "id_str" : "416274838559281152",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh why are you stifling INNOVATION?",
  "id" : 416274838559281152,
  "in_reply_to_status_id" : 416274154682216448,
  "created_at" : "2013-12-26 18:30:30 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0CA0_\u0CA0",
      "screen_name" : "MikeIsaac",
      "indices" : [ 3, 13 ],
      "id_str" : "19040598",
      "id" : 19040598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/5eGPDbzG7t",
      "expanded_url" : "http:\/\/valleywag.gawker.com\/the-year-in-completely-incoherent-techcrunch-headlines-1489856853",
      "display_url" : "valleywag.gawker.com\/the-year-in-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416273533283487744",
  "text" : "RT @MikeIsaac: LOL http:\/\/t.co\/5eGPDbzG7t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 4, 26 ],
        "url" : "http:\/\/t.co\/5eGPDbzG7t",
        "expanded_url" : "http:\/\/valleywag.gawker.com\/the-year-in-completely-incoherent-techcrunch-headlines-1489856853",
        "display_url" : "valleywag.gawker.com\/the-year-in-co\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "416254318962941952",
    "text" : "LOL http:\/\/t.co\/5eGPDbzG7t",
    "id" : 416254318962941952,
    "created_at" : "2013-12-26 17:08:57 +0000",
    "user" : {
      "name" : "\u0CA0_\u0CA0",
      "screen_name" : "MikeIsaac",
      "protected" : false,
      "id_str" : "19040598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477487240281477120\/xzwfAg7s_normal.jpeg",
      "id" : 19040598,
      "verified" : true
    }
  },
  "id" : 416273533283487744,
  "created_at" : "2013-12-26 18:25:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Sergeant",
      "screen_name" : "nicksergeant",
      "indices" : [ 92, 105 ],
      "id_str" : "13459652",
      "id" : 13459652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/2xdlIJogDr",
      "expanded_url" : "http:\/\/dcurt.is\/the-future",
      "display_url" : "dcurt.is\/the-future"
    } ]
  },
  "geo" : { },
  "id_str" : "416273513977110528",
  "text" : "It's funny how \"I want\" is not the focus when you have a family http:\/\/t.co\/2xdlIJogDr (via @nicksergeant)",
  "id" : 416273513977110528,
  "created_at" : "2013-12-26 18:25:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 8, 20 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416264741464461312",
  "text" : "Instant @whereslloyd burrito service today. Downtown on a snowy day has its perks!",
  "id" : 416264741464461312,
  "created_at" : "2013-12-26 17:50:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Tufte",
      "screen_name" : "EdwardTufte",
      "indices" : [ 3, 15 ],
      "id_str" : "152862026",
      "id" : 152862026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416257324882214913",
  "text" : "RT @EdwardTufte: Like \"awesome,\"\n\"disruptive\" has lost all meaning.\nReplace \"disruptive\" with \"daily bullshit hubris,\"\nas in \"Our big new D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "416255071039401984",
    "text" : "Like \"awesome,\"\n\"disruptive\" has lost all meaning.\nReplace \"disruptive\" with \"daily bullshit hubris,\"\nas in \"Our big new DBH technology!!!\"",
    "id" : 416255071039401984,
    "created_at" : "2013-12-26 17:11:57 +0000",
    "user" : {
      "name" : "Edward Tufte",
      "screen_name" : "EdwardTufte",
      "protected" : false,
      "id_str" : "152862026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458847900957556736\/uArnnoBy_normal.png",
      "id" : 152862026,
      "verified" : false
    }
  },
  "id" : 416257324882214913,
  "created_at" : "2013-12-26 17:20:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    }, {
      "name" : "Justine Arreche",
      "screen_name" : "SaltineJustine",
      "indices" : [ 10, 25 ],
      "id_str" : "18210275",
      "id" : 18210275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416247981156106240",
  "geo" : { },
  "id_str" : "416248614130679808",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage @SaltineJustine and friending quaranto on game center, then challenging him to a match",
  "id" : 416248614130679808,
  "in_reply_to_status_id" : 416247981156106240,
  "created_at" : "2013-12-26 16:46:17 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/416226048548675584\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Th5Jp2iEB8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bca7YrSCEAAxTHB.jpg",
      "id_str" : "416226048187961344",
      "id" : 416226048187961344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bca7YrSCEAAxTHB.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Th5Jp2iEB8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416226240622649344",
  "text" : "RT @coworkbuffalo: Lake Effect doesn't stop us! We're open if you need to get some work done today. \uD83C\uDF85 http:\/\/t.co\/Th5Jp2iEB8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/416226048548675584\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/Th5Jp2iEB8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bca7YrSCEAAxTHB.jpg",
        "id_str" : "416226048187961344",
        "id" : 416226048187961344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bca7YrSCEAAxTHB.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Th5Jp2iEB8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "416226048548675584",
    "text" : "Lake Effect doesn't stop us! We're open if you need to get some work done today. \uD83C\uDF85 http:\/\/t.co\/Th5Jp2iEB8",
    "id" : 416226048548675584,
    "created_at" : "2013-12-26 15:16:37 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 416226240622649344,
  "created_at" : "2013-12-26 15:17:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Nagelhout",
      "screen_name" : "goosesroost",
      "indices" : [ 0, 12 ],
      "id_str" : "21283898",
      "id" : 21283898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415996034834120704",
  "geo" : { },
  "id_str" : "416013214049386496",
  "in_reply_to_user_id" : 21283898,
  "text" : "@goosesroost we had this on on the background too. My only thought; what terrible 90s sweaters",
  "id" : 416013214049386496,
  "in_reply_to_status_id" : 415996034834120704,
  "created_at" : "2013-12-26 01:10:54 +0000",
  "in_reply_to_screen_name" : "goosesroost",
  "in_reply_to_user_id_str" : "21283898",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 3, 17 ],
      "id_str" : "45490102",
      "id" : 45490102
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/markpoloncarz\/status\/415675386950078464\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ZPO5yyrCHm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcTGj8_IQAA2CMx.jpg",
      "id_str" : "415675386593558528",
      "id" : 415675386593558528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcTGj8_IQAA2CMx.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZPO5yyrCHm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "415686999505244160",
  "text" : "RT @markpoloncarz: Going to increase the coffers of county government by mining for some gold. Have to watch out for creepers though. http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/markpoloncarz\/status\/415675386950078464\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ZPO5yyrCHm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BcTGj8_IQAA2CMx.jpg",
        "id_str" : "415675386593558528",
        "id" : 415675386593558528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcTGj8_IQAA2CMx.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1820,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2064,
          "resize" : "fit",
          "w" : 1161
        }, {
          "h" : 1066,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ZPO5yyrCHm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "415675386950078464",
    "text" : "Going to increase the coffers of county government by mining for some gold. Have to watch out for creepers though. http:\/\/t.co\/ZPO5yyrCHm",
    "id" : 415675386950078464,
    "created_at" : "2013-12-25 02:48:29 +0000",
    "user" : {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "protected" : false,
      "id_str" : "45490102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572114131579179008\/EAk-fMOk_normal.jpeg",
      "id" : 45490102,
      "verified" : false
    }
  },
  "id" : 415686999505244160,
  "created_at" : "2013-12-25 03:34:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexa.",
      "screen_name" : "LexGaeta",
      "indices" : [ 0, 9 ],
      "id_str" : "1669269794",
      "id" : 1669269794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415591114289463296",
  "geo" : { },
  "id_str" : "415629922989015040",
  "in_reply_to_user_id" : 1669269794,
  "text" : "@LexGaeta the dude abides.",
  "id" : 415629922989015040,
  "in_reply_to_status_id" : 415591114289463296,
  "created_at" : "2013-12-24 23:47:50 +0000",
  "in_reply_to_screen_name" : "LexGaeta",
  "in_reply_to_user_id_str" : "1669269794",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IDEA",
      "screen_name" : "IDEAcuse",
      "indices" : [ 3, 12 ],
      "id_str" : "516930319",
      "id" : 516930319
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 40, 54 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartCNY",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/4ugbpfQRQG",
      "expanded_url" : "http:\/\/buff.ly\/1fmRDF9",
      "display_url" : "buff.ly\/1fmRDF9"
    } ]
  },
  "geo" : { },
  "id_str" : "415277201500557313",
  "text" : "RT @IDEAcuse: Let's help our neighbors! @coworkbuffalo has a Kickstarter! Spread the word and support! http:\/\/t.co\/4ugbpfQRQG #StartCNY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 26, 40 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StartCNY",
        "indices" : [ 112, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/4ugbpfQRQG",
        "expanded_url" : "http:\/\/buff.ly\/1fmRDF9",
        "display_url" : "buff.ly\/1fmRDF9"
      } ]
    },
    "geo" : { },
    "id_str" : "415220317091790849",
    "text" : "Let's help our neighbors! @coworkbuffalo has a Kickstarter! Spread the word and support! http:\/\/t.co\/4ugbpfQRQG #StartCNY",
    "id" : 415220317091790849,
    "created_at" : "2013-12-23 20:40:12 +0000",
    "user" : {
      "name" : "IDEA",
      "screen_name" : "IDEAcuse",
      "protected" : false,
      "id_str" : "516930319",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481275530570776576\/ayniykm7_normal.png",
      "id" : 516930319,
      "verified" : false
    }
  },
  "id" : 415277201500557313,
  "created_at" : "2013-12-24 00:26:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415272150690693120",
  "geo" : { },
  "id_str" : "415275954856935424",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo awesome. Do you stain them?",
  "id" : 415275954856935424,
  "in_reply_to_status_id" : 415272150690693120,
  "created_at" : "2013-12-24 00:21:17 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Handsome",
      "screen_name" : "Millennial_Dave",
      "indices" : [ 0, 16 ],
      "id_str" : "60185021",
      "id" : 60185021
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 17, 31 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 51, 60 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415238944658178048",
  "geo" : { },
  "id_str" : "415239630523355136",
  "in_reply_to_user_id" : 60185021,
  "text" : "@Millennial_Dave @coworkbuffalo thanks dude!! next @openhack should be 1\/7, 7pm.",
  "id" : 415239630523355136,
  "in_reply_to_status_id" : 415238944658178048,
  "created_at" : "2013-12-23 21:56:57 +0000",
  "in_reply_to_screen_name" : "Millennial_Dave",
  "in_reply_to_user_id_str" : "60185021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Handsome",
      "screen_name" : "Millennial_Dave",
      "indices" : [ 0, 16 ],
      "id_str" : "60185021",
      "id" : 60185021
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 58, 72 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "zobar",
      "screen_name" : "zobar",
      "indices" : [ 87, 93 ],
      "id_str" : "276099613",
      "id" : 276099613
    }, {
      "name" : "Brian Borncamp",
      "screen_name" : "borncamp",
      "indices" : [ 98, 107 ],
      "id_str" : "1002573926",
      "id" : 1002573926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415235592432005120",
  "geo" : { },
  "id_str" : "415237694059315200",
  "in_reply_to_user_id" : 60185021,
  "text" : "@Millennial_Dave we were actually just talking about this @coworkbuffalo. According to @zobar and @borncamp they're at Wegmans and Aldi.",
  "id" : 415237694059315200,
  "in_reply_to_status_id" : 415235592432005120,
  "created_at" : "2013-12-23 21:49:15 +0000",
  "in_reply_to_screen_name" : "Millennial_Dave",
  "in_reply_to_user_id_str" : "60185021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415215337240805376",
  "geo" : { },
  "id_str" : "415215886773923841",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit IKEAAAAAA",
  "id" : 415215886773923841,
  "in_reply_to_status_id" : 415215337240805376,
  "created_at" : "2013-12-23 20:22:36 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 3, 11 ],
      "id_str" : "234465384",
      "id" : 234465384
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 53, 63 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/ihX1yD0hnf",
      "expanded_url" : "https:\/\/weworkremotely.com\/jobs\/281",
      "display_url" : "weworkremotely.com\/jobs\/281"
    } ]
  },
  "geo" : { },
  "id_str" : "415189931611283456",
  "text" : "RT @noahhlo: Hard to believe today marks three years @37signals. Want to come hang out? We're hiring https:\/\/t.co\/ihX1yD0hnf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 40, 50 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/ihX1yD0hnf",
        "expanded_url" : "https:\/\/weworkremotely.com\/jobs\/281",
        "display_url" : "weworkremotely.com\/jobs\/281"
      } ]
    },
    "geo" : { },
    "id_str" : "414028071268655104",
    "text" : "Hard to believe today marks three years @37signals. Want to come hang out? We're hiring https:\/\/t.co\/ihX1yD0hnf",
    "id" : 414028071268655104,
    "created_at" : "2013-12-20 13:42:39 +0000",
    "user" : {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "protected" : false,
      "id_str" : "234465384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412045673408651264\/CPEGZ-93_normal.jpeg",
      "id" : 234465384,
      "verified" : false
    }
  },
  "id" : 415189931611283456,
  "created_at" : "2013-12-23 18:39:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wheatley ",
      "screen_name" : "jon",
      "indices" : [ 0, 4 ],
      "id_str" : "10917372",
      "id" : 10917372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415184451983769601",
  "geo" : { },
  "id_str" : "415185058580803584",
  "in_reply_to_user_id" : 10917372,
  "text" : "@jon it is :( Most firehalls are safe surrender points.",
  "id" : 415185058580803584,
  "in_reply_to_status_id" : 415184451983769601,
  "created_at" : "2013-12-23 18:20:06 +0000",
  "in_reply_to_screen_name" : "jon",
  "in_reply_to_user_id_str" : "10917372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "indices" : [ 0, 11 ],
      "id_str" : "1232850504",
      "id" : 1232850504
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 12, 23 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Adrian Roselli",
      "screen_name" : "aardrian",
      "indices" : [ 24, 33 ],
      "id_str" : "16515870",
      "id" : 16515870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415155007726444544",
  "geo" : { },
  "id_str" : "415181633222754304",
  "in_reply_to_user_id" : 1232850504,
  "text" : "@gdiBuffalo @kevinpurdy @aardrian yes, we do!",
  "id" : 415181633222754304,
  "in_reply_to_status_id" : 415155007726444544,
  "created_at" : "2013-12-23 18:06:29 +0000",
  "in_reply_to_screen_name" : "gdiBuffalo",
  "in_reply_to_user_id_str" : "1232850504",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/t97ME7ITiv",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ZEBoOr12BrI",
      "display_url" : "youtube.com\/watch?v=ZEBoOr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415179428629450752",
  "text" : "GoPro strapped to an AHL referee's helmet = awesome view. https:\/\/t.co\/t97ME7ITiv",
  "id" : 415179428629450752,
  "created_at" : "2013-12-23 17:57:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/gDD6GOj4cz",
      "expanded_url" : "http:\/\/nyti.ms\/1jxFPWj",
      "display_url" : "nyti.ms\/1jxFPWj"
    } ]
  },
  "geo" : { },
  "id_str" : "414870779096879104",
  "text" : "Spot on, dialect from Buffalo\/Rochester. \"Pop\" and \"thruway\" must have given it away. http:\/\/t.co\/gDD6GOj4cz",
  "id" : 414870779096879104,
  "created_at" : "2013-12-22 21:31:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414716212220682240",
  "text" : "Water on trees froze after some serious rain, looks like something out of a horror movie outside right now.",
  "id" : 414716212220682240,
  "created_at" : "2013-12-22 11:17:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    }, {
      "name" : "Caryn",
      "screen_name" : "Caryn1420",
      "indices" : [ 6, 16 ],
      "id_str" : "133676678",
      "id" : 133676678
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414388036365848576",
  "geo" : { },
  "id_str" : "414388336544194560",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo @Caryn1420 time to get that shotgun for the girls' boyfriends early?",
  "id" : 414388336544194560,
  "in_reply_to_status_id" : 414388036365848576,
  "created_at" : "2013-12-21 13:34:13 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414330971048005632",
  "geo" : { },
  "id_str" : "414331259897511936",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt today\u2019s special: Flea Poppers",
  "id" : 414331259897511936,
  "in_reply_to_status_id" : 414330971048005632,
  "created_at" : "2013-12-21 09:47:24 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/414113183691837440\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/gLcO2Wr5W7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb85vxsCEAA-IkP.jpg",
      "id_str" : "414113183696031744",
      "id" : 414113183696031744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb85vxsCEAA-IkP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gLcO2Wr5W7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414113183691837440",
  "text" : "My pair programmer for today wasn't too happy about my lack of tests. http:\/\/t.co\/gLcO2Wr5W7",
  "id" : 414113183691837440,
  "created_at" : "2013-12-20 19:20:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/414095250152361984\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/nQe06gIbKA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb8pb6ECEAAKR9h.jpg",
      "id_str" : "414095250160750592",
      "id" : 414095250160750592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb8pb6ECEAAKR9h.jpg",
      "sizes" : [ {
        "h" : 257,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 475
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 475
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 475
      } ],
      "display_url" : "pic.twitter.com\/nQe06gIbKA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/IKIiSJdGiK",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "414095250152361984",
  "text" : "66% funded and only 4 days in! http:\/\/t.co\/IKIiSJdGiK http:\/\/t.co\/nQe06gIbKA",
  "id" : 414095250152361984,
  "created_at" : "2013-12-20 18:09:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414091386703454208",
  "text" : "Just called out a friend on some bullshit from months ago. Why is this always so hard?",
  "id" : 414091386703454208,
  "created_at" : "2013-12-20 17:54:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 0, 8 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414079644082515968",
  "geo" : { },
  "id_str" : "414080238969036800",
  "in_reply_to_user_id" : 34175404,
  "text" : "@whit537 &lt;3",
  "id" : 414080238969036800,
  "in_reply_to_status_id" : 414079644082515968,
  "created_at" : "2013-12-20 17:09:56 +0000",
  "in_reply_to_screen_name" : "whit537",
  "in_reply_to_user_id_str" : "34175404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 88, 102 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/PjXRHPysgq",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=EEtcMIbpjs8",
      "display_url" : "youtube.com\/watch?v=EEtcMI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "414078992673538048",
  "text" : "Found out yesterday Greensky Bluegrass is coming to Buffalo (and basically next door to @coworkbuffalo) in Feb. Yes! http:\/\/t.co\/PjXRHPysgq",
  "id" : 414078992673538048,
  "created_at" : "2013-12-20 17:04:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413875409852592128",
  "text" : "New Agricola decks out too? \uD83D\uDCB8",
  "id" : 413875409852592128,
  "created_at" : "2013-12-20 03:36:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 26, 35 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/V832CRScIj",
      "expanded_url" : "http:\/\/wedding.jai.im\/",
      "display_url" : "wedding.jai.im"
    } ]
  },
  "geo" : { },
  "id_str" : "413762486941122560",
  "text" : "First wedding invites via @rubygems! http:\/\/t.co\/V832CRScIj",
  "id" : 413762486941122560,
  "created_at" : "2013-12-19 20:07:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413758826706649088",
  "geo" : { },
  "id_str" : "413760726134558720",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler I was actually programming at this point - HTML, VB, C++ while in high school. Insane to think about...",
  "id" : 413760726134558720,
  "in_reply_to_status_id" : 413758826706649088,
  "created_at" : "2013-12-19 20:00:19 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 3, 14 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413759559149555712",
  "text" : "RT @chadfowler: I realized today that we created RubyGems ten years ago. Bizarre.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 52.5348039, 13.4164537 ]
    },
    "id_str" : "413758826706649088",
    "text" : "I realized today that we created RubyGems ten years ago. Bizarre.",
    "id" : 413758826706649088,
    "created_at" : "2013-12-19 19:52:46 +0000",
    "user" : {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "protected" : false,
      "id_str" : "790205",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452359934806470656\/aDWT-R75_normal.jpeg",
      "id" : 790205,
      "verified" : false
    }
  },
  "id" : 413759559149555712,
  "created_at" : "2013-12-19 19:55:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/aY2RLGnrhL",
      "expanded_url" : "https:\/\/www.eventbrite.com\/e\/neighborly-wine-tasting-for-coworkbuffalo-tickets-9799557741",
      "display_url" : "eventbrite.com\/e\/neighborly-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413744676504866816",
  "text" : "RT @coworkbuffalo: If you're into trying out neat wines and meeting our neighbors, we're doing a wine tasting tonight, 4-7pm: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/aY2RLGnrhL",
        "expanded_url" : "https:\/\/www.eventbrite.com\/e\/neighborly-wine-tasting-for-coworkbuffalo-tickets-9799557741",
        "display_url" : "eventbrite.com\/e\/neighborly-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "413744595915124736",
    "text" : "If you're into trying out neat wines and meeting our neighbors, we're doing a wine tasting tonight, 4-7pm: https:\/\/t.co\/aY2RLGnrhL",
    "id" : 413744595915124736,
    "created_at" : "2013-12-19 18:56:13 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 413744676504866816,
  "created_at" : "2013-12-19 18:56:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 8, 22 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413707911387287553",
  "text" : "The new @coworkbuffalo space is packed today. Loving it.",
  "id" : 413707911387287553,
  "created_at" : "2013-12-19 16:30:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 3, 14 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/ccagaXUQQk",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413705598497075200",
  "text" : "RT @paddyforan: http:\/\/t.co\/ccagaXUQQk\n\nDrown this in money.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/ccagaXUQQk",
        "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community",
        "display_url" : "kickstarter.com\/projects\/cowor\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 40.677855, -73.986338 ]
    },
    "id_str" : "413703615598317569",
    "text" : "http:\/\/t.co\/ccagaXUQQk\n\nDrown this in money.",
    "id" : 413703615598317569,
    "created_at" : "2013-12-19 16:13:22 +0000",
    "user" : {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "protected" : false,
      "id_str" : "15445975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433766988179963904\/MjnoKMzP_normal.jpeg",
      "id" : 15445975,
      "verified" : false
    }
  },
  "id" : 413705598497075200,
  "created_at" : "2013-12-19 16:21:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/wGnsw4L47O",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/health-25405543",
      "display_url" : "bbc.co.uk\/news\/health-25\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413690622407475200",
  "text" : "Exactly what it sounds like: \"Severed hand kept alive on man's ankle\" http:\/\/t.co\/wGnsw4L47O",
  "id" : 413690622407475200,
  "created_at" : "2013-12-19 15:21:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413619562496917504",
  "text" : "First 6.5 hour sleep in over a month. I think I\u2019m dreaming. TOP SCORE for the little guy.",
  "id" : 413619562496917504,
  "created_at" : "2013-12-19 10:39:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Radcliff",
      "screen_name" : "scottradcliff",
      "indices" : [ 0, 14 ],
      "id_str" : "15789234",
      "id" : 15789234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413418963385597952",
  "geo" : { },
  "id_str" : "413420977846886401",
  "in_reply_to_user_id" : 15789234,
  "text" : "@scottradcliff thanks!!",
  "id" : 413420977846886401,
  "in_reply_to_status_id" : 413418963385597952,
  "created_at" : "2013-12-18 21:30:16 +0000",
  "in_reply_to_screen_name" : "scottradcliff",
  "in_reply_to_user_id_str" : "15789234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seed Coworking",
      "screen_name" : "seedcowork",
      "indices" : [ 4, 15 ],
      "id_str" : "403807816",
      "id" : 403807816
    }, {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 16, 24 ],
      "id_str" : "77673",
      "id" : 77673
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 43, 57 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/IKIiSJdGiK",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413404331908419584",
  "text" : "Hey @seedcowork @jwright, our campaign for @coworkbuffalo is up (finally!), mind passing it along? http:\/\/t.co\/IKIiSJdGiK",
  "id" : 413404331908419584,
  "created_at" : "2013-12-18 20:24:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413398259814526976",
  "text" : "Remember when spare cycles would get donated to searching for ET life or folding proteins to cure cancer and not towards cryptocurrency?",
  "id" : 413398259814526976,
  "created_at" : "2013-12-18 20:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IDEA",
      "screen_name" : "IDEAcuse",
      "indices" : [ 3, 12 ],
      "id_str" : "516930319",
      "id" : 516930319
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 40, 54 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartCNY",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/4ugbpfQRQG",
      "expanded_url" : "http:\/\/buff.ly\/1fmRDF9",
      "display_url" : "buff.ly\/1fmRDF9"
    } ]
  },
  "geo" : { },
  "id_str" : "413390286312980480",
  "text" : "RT @IDEAcuse: Let's help our neighbors! @coworkbuffalo has a Kickstarter! Spread the word and support! http:\/\/t.co\/4ugbpfQRQG #StartCNY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 26, 40 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StartCNY",
        "indices" : [ 112, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/4ugbpfQRQG",
        "expanded_url" : "http:\/\/buff.ly\/1fmRDF9",
        "display_url" : "buff.ly\/1fmRDF9"
      } ]
    },
    "geo" : { },
    "id_str" : "413375384554844160",
    "text" : "Let's help our neighbors! @coworkbuffalo has a Kickstarter! Spread the word and support! http:\/\/t.co\/4ugbpfQRQG #StartCNY",
    "id" : 413375384554844160,
    "created_at" : "2013-12-18 18:29:06 +0000",
    "user" : {
      "name" : "IDEA",
      "screen_name" : "IDEAcuse",
      "protected" : false,
      "id_str" : "516930319",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481275530570776576\/ayniykm7_normal.png",
      "id" : 516930319,
      "verified" : false
    }
  },
  "id" : 413390286312980480,
  "created_at" : "2013-12-18 19:28:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 3, 14 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/z5QKdO701V",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?feature=player_embedded&v=YR8CwZRBM1c",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413362138162274304",
  "text" : "RT @themcgruff: The Homeless Addiction: https:\/\/t.co\/z5QKdO701V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/z5QKdO701V",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?feature=player_embedded&v=YR8CwZRBM1c",
        "display_url" : "youtube.com\/watch?feature=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "413357636629708801",
    "text" : "The Homeless Addiction: https:\/\/t.co\/z5QKdO701V",
    "id" : 413357636629708801,
    "created_at" : "2013-12-18 17:18:35 +0000",
    "user" : {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "protected" : false,
      "id_str" : "13984262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539946640417619968\/0wwEYfHi_normal.png",
      "id" : 13984262,
      "verified" : false
    }
  },
  "id" : 413362138162274304,
  "created_at" : "2013-12-18 17:36:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IDEA",
      "screen_name" : "IDEAcuse",
      "indices" : [ 17, 26 ],
      "id_str" : "516930319",
      "id" : 516930319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413097319043579904",
  "geo" : { },
  "id_str" : "413349388321177600",
  "in_reply_to_user_id" : 358178745,
  "text" : "@TonyFrydBologna @IDEAcuse hey, thanks! If there's any way we could reach more people in Syracuse we'd love to know.",
  "id" : 413349388321177600,
  "in_reply_to_status_id" : 413097319043579904,
  "created_at" : "2013-12-18 16:45:48 +0000",
  "in_reply_to_screen_name" : "TechGarden_Tony",
  "in_reply_to_user_id_str" : "358178745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413334087450259456",
  "geo" : { },
  "id_str" : "413334337841418240",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss Kick ass dude. Congrats!",
  "id" : 413334337841418240,
  "in_reply_to_status_id" : 413334087450259456,
  "created_at" : "2013-12-18 15:46:00 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Hobbs",
      "screen_name" : "jeffehobbs",
      "indices" : [ 3, 14 ],
      "id_str" : "36953",
      "id" : 36953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413313410076377088",
  "text" : "RT @jeffehobbs: LIFE HACK: Change your terminal font to Papyrus so your shell session looks like the lunch menu at a vegetarian bistro",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "413307510192627712",
    "text" : "LIFE HACK: Change your terminal font to Papyrus so your shell session looks like the lunch menu at a vegetarian bistro",
    "id" : 413307510192627712,
    "created_at" : "2013-12-18 13:59:23 +0000",
    "user" : {
      "name" : "Jeff Hobbs",
      "screen_name" : "jeffehobbs",
      "protected" : false,
      "id_str" : "36953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1267010924\/water-skiing-squirrel_140_normal.jpg",
      "id" : 36953,
      "verified" : false
    }
  },
  "id" : 413313410076377088,
  "created_at" : "2013-12-18 14:22:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/TXFh7rxJdG",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=BtelgRzc3IU",
      "display_url" : "youtube.com\/watch?v=BtelgR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413311129423601664",
  "text" : "Alright, this might be a reason to buy a WiiU: http:\/\/t.co\/TXFh7rxJdG",
  "id" : 413311129423601664,
  "created_at" : "2013-12-18 14:13:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413271850136121344",
  "geo" : { },
  "id_str" : "413285365798027264",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz this actually scares me more: what vulns do they know about? Possibly are exploiting?",
  "id" : 413285365798027264,
  "in_reply_to_status_id" : 413271850136121344,
  "created_at" : "2013-12-18 12:31:24 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/MJOvXMNJdr",
      "expanded_url" : "http:\/\/www.nsa.gov\/public_info\/media_center\/careers\/video\/TheProgrammer\/index.html",
      "display_url" : "nsa.gov\/public_info\/me\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413231831979278336",
  "text" : "Should have figured this would happen, but disgusted and sad that Ruby and friends is used at the NSA: http:\/\/t.co\/MJOvXMNJdr",
  "id" : 413231831979278336,
  "created_at" : "2013-12-18 08:58:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3055\u308A",
      "screen_name" : "hiro_asari",
      "indices" : [ 3, 14 ],
      "id_str" : "14284130",
      "id" : 14284130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/ohEbSvW1Xd",
      "expanded_url" : "http:\/\/www.nsa.gov\/public_info\/media_center\/careers\/video\/TheProgrammer\/index.html",
      "display_url" : "nsa.gov\/public_info\/me\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413231591079411712",
  "text" : "RT @hiro_asari: NSA uses Ruby, Sinatra and Rails. http:\/\/t.co\/ohEbSvW1Xd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/ohEbSvW1Xd",
        "expanded_url" : "http:\/\/www.nsa.gov\/public_info\/media_center\/careers\/video\/TheProgrammer\/index.html",
        "display_url" : "nsa.gov\/public_info\/me\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "412606542371102720",
    "text" : "NSA uses Ruby, Sinatra and Rails. http:\/\/t.co\/ohEbSvW1Xd",
    "id" : 412606542371102720,
    "created_at" : "2013-12-16 15:34:00 +0000",
    "user" : {
      "name" : "\u3042\u3055\u308A",
      "screen_name" : "hiro_asari",
      "protected" : false,
      "id_str" : "14284130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502295590282465283\/IK1ZCcu8_normal.jpeg",
      "id" : 14284130,
      "verified" : false
    }
  },
  "id" : 413231591079411712,
  "created_at" : "2013-12-18 08:57:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413230082661302272",
  "text" : "New Carcassone expansion!!! My Game Center name is quaranto. Bring it! \uD83D\uDE24",
  "id" : 413230082661302272,
  "created_at" : "2013-12-18 08:51:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413145630270160896",
  "geo" : { },
  "id_str" : "413146312385630208",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant we should watch one or two of this year\u2019s run.",
  "id" : 413146312385630208,
  "in_reply_to_status_id" : 413145630270160896,
  "created_at" : "2013-12-18 03:18:51 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    }, {
      "name" : "Maxim Chernyak",
      "screen_name" : "hakunin",
      "indices" : [ 10, 18 ],
      "id_str" : "11622052",
      "id" : 11622052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413141537837424640",
  "geo" : { },
  "id_str" : "413141721795403776",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck @hakunin agreed. Moderation :)",
  "id" : 413141721795403776,
  "in_reply_to_status_id" : 413141537837424640,
  "created_at" : "2013-12-18 03:00:36 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    }, {
      "name" : "Maxim Chernyak",
      "screen_name" : "hakunin",
      "indices" : [ 10, 18 ],
      "id_str" : "11622052",
      "id" : 11622052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413141100090519553",
  "geo" : { },
  "id_str" : "413141433667686400",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck @hakunin it\u2019s definitely no excuse for proper OO design. There\u2019s ways to turn any feature into spaghetti.",
  "id" : 413141433667686400,
  "in_reply_to_status_id" : 413141100090519553,
  "created_at" : "2013-12-18 02:59:28 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413139353951424513",
  "geo" : { },
  "id_str" : "413140978355011584",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck also if \u201Cyou guys\u201D means 37\u2026there are many opinions, some strongly held :)",
  "id" : 413140978355011584,
  "in_reply_to_status_id" : 413139353951424513,
  "created_at" : "2013-12-18 02:57:39 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxim Chernyak",
      "screen_name" : "hakunin",
      "indices" : [ 0, 8 ],
      "id_str" : "11622052",
      "id" : 11622052
    }, {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 9, 18 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413139681174642688",
  "geo" : { },
  "id_str" : "413140441039523840",
  "in_reply_to_user_id" : 11622052,
  "text" : "@hakunin @fowlduck everything in moderation. I haven\u2019t seen it abused although I\u2019m sure it will.",
  "id" : 413140441039523840,
  "in_reply_to_status_id" : 413139681174642688,
  "created_at" : "2013-12-18 02:55:31 +0000",
  "in_reply_to_screen_name" : "hakunin",
  "in_reply_to_user_id_str" : "11622052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413137513813778433",
  "geo" : { },
  "id_str" : "413138783345733632",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck yep, it\u2019s that exactly. Granted we use it sparingly but it helps group similar methods together",
  "id" : 413138783345733632,
  "in_reply_to_status_id" : 413137513813778433,
  "created_at" : "2013-12-18 02:48:56 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Kane Parker",
      "screen_name" : "moonmaster9000",
      "indices" : [ 0, 15 ],
      "id_str" : "14391298",
      "id" : 14391298
    }, {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "indices" : [ 16, 30 ],
      "id_str" : "20104013",
      "id" : 20104013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413136348569026560",
  "geo" : { },
  "id_str" : "413137414928879616",
  "in_reply_to_user_id" : 14391298,
  "text" : "@moonmaster9000 @yukihiro_matz I missed the actual ruby and rails projects. I think it just associates size with activity",
  "id" : 413137414928879616,
  "in_reply_to_status_id" : 413136348569026560,
  "created_at" : "2013-12-18 02:43:30 +0000",
  "in_reply_to_screen_name" : "moonmaster9000",
  "in_reply_to_user_id_str" : "14391298",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/413133751682482176\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/J4HXNfGNQp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbu-9VJCQAEKok0.jpg",
      "id_str" : "413133751690870785",
      "id" : 413133751690870785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbu-9VJCQAEKok0.jpg",
      "sizes" : [ {
        "h" : 305,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1042,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/J4HXNfGNQp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/6b0LCA3iLk",
      "expanded_url" : "http:\/\/ekisto.sq.ro\/",
      "display_url" : "ekisto.sq.ro"
    } ]
  },
  "geo" : { },
  "id_str" : "413133751682482176",
  "text" : "Ruby city on Ekisto: http:\/\/t.co\/6b0LCA3iLk http:\/\/t.co\/J4HXNfGNQp",
  "id" : 413133751682482176,
  "created_at" : "2013-12-18 02:28:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 14, 25 ],
      "id_str" : "14620776",
      "id" : 14620776
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 30, 42 ],
      "id_str" : "16186995",
      "id" : 16186995
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 55, 69 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/ffhajjRr89",
      "expanded_url" : "http:\/\/www.kickstarter.com\/newsletters\/happening\/187",
      "display_url" : "kickstarter.com\/newsletters\/ha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413131961201213440",
  "text" : "Big thanks to @ellenchisa and @kickstarter for putting @coworkbuffalo's campaign on Happening! http:\/\/t.co\/ffhajjRr89",
  "id" : 413131961201213440,
  "created_at" : "2013-12-18 02:21:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker Wightman",
      "screen_name" : "parkerwightman",
      "indices" : [ 0, 15 ],
      "id_str" : "415345747",
      "id" : 415345747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413074264514777088",
  "geo" : { },
  "id_str" : "413079222219845633",
  "in_reply_to_user_id" : 415345747,
  "text" : "@parkerwightman yeah, changing my mind a bit. Haven't donated to any still.",
  "id" : 413079222219845633,
  "in_reply_to_status_id" : 413074264514777088,
  "created_at" : "2013-12-17 22:52:15 +0000",
  "in_reply_to_screen_name" : "parkerwightman",
  "in_reply_to_user_id_str" : "415345747",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "indices" : [ 3, 11 ],
      "id_str" : "19041990",
      "id" : 19041990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/GpNxpCM1l5",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=aO0TUI9r-So&feature=share&list=SP4NL9i-Fu15hhYGB-d0hmSWD1fcIvLvn1&index=4",
      "display_url" : "youtube.com\/watch?v=aO0TUI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413043049342595072",
  "text" : "RT @kkuchta: Every TED Talk: http:\/\/t.co\/GpNxpCM1l5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/GpNxpCM1l5",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=aO0TUI9r-So&feature=share&list=SP4NL9i-Fu15hhYGB-d0hmSWD1fcIvLvn1&index=4",
        "display_url" : "youtube.com\/watch?v=aO0TUI\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "413041646268207105",
    "text" : "Every TED Talk: http:\/\/t.co\/GpNxpCM1l5",
    "id" : 413041646268207105,
    "created_at" : "2013-12-17 20:22:57 +0000",
    "user" : {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "protected" : false,
      "id_str" : "19041990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1638281947\/KevSuit_normal.jpeg",
      "id" : 19041990,
      "verified" : false
    }
  },
  "id" : 413043049342595072,
  "created_at" : "2013-12-17 20:28:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 8, 22 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412979880486133760",
  "geo" : { },
  "id_str" : "412980948028772352",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 @coworkbuffalo Chalkboard (or Whiteboard) idea painted wall is definitely on the wish list.",
  "id" : 412980948028772352,
  "in_reply_to_status_id" : 412979880486133760,
  "created_at" : "2013-12-17 16:21:45 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 4, 13 ],
      "id_str" : "20531902",
      "id" : 20531902
    }, {
      "name" : "synace",
      "screen_name" : "synacecom",
      "indices" : [ 14, 24 ],
      "id_str" : "75330669",
      "id" : 75330669
    }, {
      "name" : "Buffalo PASS",
      "screen_name" : "BuffaloPASS",
      "indices" : [ 25, 37 ],
      "id_str" : "1468216825",
      "id" : 1468216825
    }, {
      "name" : "Buffalo JavaScript",
      "screen_name" : "BuffaloJS",
      "indices" : [ 38, 48 ],
      "id_str" : "817437266",
      "id" : 817437266
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 62, 71 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/MZ8R6KaDIO",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/13564",
      "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412967904141774848",
  "text" : "Hey @sabiddle @synacecom @BuffaloPASS @BuffaloJS - there's an @OpenHack tonight! http:\/\/t.co\/MZ8R6KaDIO",
  "id" : 412967904141774848,
  "created_at" : "2013-12-17 15:29:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 41, 50 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 73, 87 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/tcbPggCv1F",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/13564",
      "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412966362722496512",
  "text" : "RT @zobar2: Crappo! I forgot to mention- @openhack is tonight at the NEW @coworkbuffalo! Check out our new digs at 653 Main! http:\/\/t.co\/tc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 29, 38 ],
        "id_str" : "715440464",
        "id" : 715440464
      }, {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 61, 75 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/tcbPggCv1F",
        "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/13564",
        "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "412946779936526336",
    "text" : "Crappo! I forgot to mention- @openhack is tonight at the NEW @coworkbuffalo! Check out our new digs at 653 Main! http:\/\/t.co\/tcbPggCv1F",
    "id" : 412946779936526336,
    "created_at" : "2013-12-17 14:05:59 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 412966362722496512,
  "created_at" : "2013-12-17 15:23:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Ryan Nagelhout",
      "screen_name" : "goosesroost",
      "indices" : [ 12, 24 ],
      "id_str" : "21283898",
      "id" : 21283898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412964676134137857",
  "geo" : { },
  "id_str" : "412966076264099840",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @goosesroost thanks! Next time we need to throw in the gorilla taco eating gif.",
  "id" : 412966076264099840,
  "in_reply_to_status_id" : 412964676134137857,
  "created_at" : "2013-12-17 15:22:39 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 85, 99 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/IKIiSJdGiK",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412959142861492225",
  "text" : "Less than 24 hours in and 33% there! Blown away by the response and &lt;3 so far for @coworkbuffalo. http:\/\/t.co\/IKIiSJdGiK",
  "id" : 412959142861492225,
  "created_at" : "2013-12-17 14:55:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412957999276122112",
  "geo" : { },
  "id_str" : "412958603289452546",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack having been there 5 times in 2 weeks, I welcome our new robot overlords",
  "id" : 412958603289452546,
  "in_reply_to_status_id" : 412957999276122112,
  "created_at" : "2013-12-17 14:52:58 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412796456303464448",
  "text" : "I wonder how much would be different if the developer effort towards cryptocurrencies would be spent towards improving or creating OSS. \uD83D\uDCB8\uD83D\uDE29",
  "id" : 412796456303464448,
  "created_at" : "2013-12-17 04:08:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 3, 11 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/ZLj75xQY0c",
      "expanded_url" : "http:\/\/blog.parkermoore.de\/2013\/11\/04\/taking-over-someone-elses-open-source-project\/",
      "display_url" : "blog.parkermoore.de\/2013\/11\/04\/tak\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412794742246612993",
  "text" : "RT @mojombo: Curious how Jekyll came back to life? Hear it from Parker, the man who made it happen: http:\/\/t.co\/ZLj75xQY0c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/ZLj75xQY0c",
        "expanded_url" : "http:\/\/blog.parkermoore.de\/2013\/11\/04\/taking-over-someone-elses-open-source-project\/",
        "display_url" : "blog.parkermoore.de\/2013\/11\/04\/tak\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "398704325918093313",
    "text" : "Curious how Jekyll came back to life? Hear it from Parker, the man who made it happen: http:\/\/t.co\/ZLj75xQY0c",
    "id" : 398704325918093313,
    "created_at" : "2013-11-08 06:51:33 +0000",
    "user" : {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "protected" : false,
      "id_str" : "5502392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3276311659\/9a5ac16a84dc44337c3e09186273ada9_normal.png",
      "id" : 5502392,
      "verified" : false
    }
  },
  "id" : 412794742246612993,
  "created_at" : "2013-12-17 04:01:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Suggs",
      "screen_name" : "ktheory",
      "indices" : [ 0, 8 ],
      "id_str" : "1696",
      "id" : 1696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412721223668224001",
  "geo" : { },
  "id_str" : "412721502006837248",
  "in_reply_to_user_id" : 1696,
  "text" : "@ktheory I couldn\u2019t\u2026vines couldn\u2019t be embedded there. Would love some help if it can work!",
  "id" : 412721502006837248,
  "in_reply_to_status_id" : 412721223668224001,
  "created_at" : "2013-12-16 23:10:48 +0000",
  "in_reply_to_screen_name" : "ktheory",
  "in_reply_to_user_id_str" : "1696",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor L. Griffith",
      "screen_name" : "TaylorLeigh_G",
      "indices" : [ 0, 14 ],
      "id_str" : "29610330",
      "id" : 29610330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412713832461524993",
  "geo" : { },
  "id_str" : "412720964653580289",
  "in_reply_to_user_id" : 29610330,
  "text" : "@TaylorLeigh_G got it! We\u2019re looking into our availability. We want to make it happen.",
  "id" : 412720964653580289,
  "in_reply_to_status_id" : 412713832461524993,
  "created_at" : "2013-12-16 23:08:40 +0000",
  "in_reply_to_screen_name" : "TaylorLeigh_G",
  "in_reply_to_user_id_str" : "29610330",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Moazeni",
      "screen_name" : "zmoazeni",
      "indices" : [ 0, 9 ],
      "id_str" : "3576061",
      "id" : 3576061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412712988429127680",
  "geo" : { },
  "id_str" : "412717246256267264",
  "in_reply_to_user_id" : 3576061,
  "text" : "@zmoazeni no problem! nick at quaran.to",
  "id" : 412717246256267264,
  "in_reply_to_status_id" : 412712988429127680,
  "created_at" : "2013-12-16 22:53:54 +0000",
  "in_reply_to_screen_name" : "zmoazeni",
  "in_reply_to_user_id_str" : "3576061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 9, 21 ],
      "id_str" : "16186995",
      "id" : 16186995
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 48, 62 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/IKIiSJdGiK",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412708392696688640",
  "text" : "My first @Kickstarter! Help build our community @coworkbuffalo: http:\/\/t.co\/IKIiSJdGiK",
  "id" : 412708392696688640,
  "created_at" : "2013-12-16 22:18:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Bendyworks",
      "screen_name" : "bendyworks",
      "indices" : [ 36, 47 ],
      "id_str" : "31920143",
      "id" : 31920143
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/412686031033344000\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/SbfINK6uh0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbonwjTCcAA1bTh.jpg",
      "id_str" : "412686030920118272",
      "id" : 412686030920118272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbonwjTCcAA1bTh.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      } ],
      "display_url" : "pic.twitter.com\/SbfINK6uh0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412686131474731008",
  "text" : "RT @coworkbuffalo: Happy 2014, from @bendyworks! Thanks, and what an awesome card! http:\/\/t.co\/SbfINK6uh0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bendyworks",
        "screen_name" : "bendyworks",
        "indices" : [ 17, 28 ],
        "id_str" : "31920143",
        "id" : 31920143
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/412686031033344000\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/SbfINK6uh0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbonwjTCcAA1bTh.jpg",
        "id_str" : "412686030920118272",
        "id" : 412686030920118272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbonwjTCcAA1bTh.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 1136
        } ],
        "display_url" : "pic.twitter.com\/SbfINK6uh0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "412686031033344000",
    "text" : "Happy 2014, from @bendyworks! Thanks, and what an awesome card! http:\/\/t.co\/SbfINK6uh0",
    "id" : 412686031033344000,
    "created_at" : "2013-12-16 20:49:51 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 412686131474731008,
  "created_at" : "2013-12-16 20:50:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 5, 19 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 60, 71 ],
      "id_str" : "38408851",
      "id" : 38408851
    }, {
      "name" : "Bendyworks",
      "screen_name" : "bendyworks",
      "indices" : [ 76, 87 ],
      "id_str" : "31920143",
      "id" : 31920143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412685493160001536",
  "text" : "Wow! @coworkbuffalo just got its first holiday card. Thanks @Jonplussed and @bendyworks!",
  "id" : 412685493160001536,
  "created_at" : "2013-12-16 20:47:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412579734191865856",
  "geo" : { },
  "id_str" : "412580250716217345",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV :( this repat has seen a lot of positive change.",
  "id" : 412580250716217345,
  "in_reply_to_status_id" : 412579734191865856,
  "created_at" : "2013-12-16 13:49:31 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/deoNtWyR8B",
      "expanded_url" : "http:\/\/blog.moertel.com\/posts\/2013-12-14-great-old-timey-game-programming-hack.html",
      "display_url" : "blog.moertel.com\/posts\/2013-12-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412557179992813569",
  "text" : "Crazy story of optimizing a game: http:\/\/t.co\/deoNtWyR8B Modern programming is so far removed from this, I wonder how much that hurts us.",
  "id" : 412557179992813569,
  "created_at" : "2013-12-16 12:17:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/mVMMK2xSND",
      "expanded_url" : "https:\/\/vine.co\/v\/h20QnZELu3H",
      "display_url" : "vine.co\/v\/h20QnZELu3H"
    } ]
  },
  "geo" : { },
  "id_str" : "412248651671805952",
  "text" : "Geddy flipping out in the snow. https:\/\/t.co\/mVMMK2xSND",
  "id" : 412248651671805952,
  "created_at" : "2013-12-15 15:51:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412061040172883968",
  "geo" : { },
  "id_str" : "412062227550593025",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d it predicts rain and other precipitation accurately almost down to the minute. Not everyone\u2019s cup of tea.",
  "id" : 412062227550593025,
  "in_reply_to_status_id" : 412061040172883968,
  "created_at" : "2013-12-15 03:31:05 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/eoGA058gRs",
      "expanded_url" : "http:\/\/forecast.io",
      "display_url" : "forecast.io"
    } ]
  },
  "in_reply_to_status_id_str" : "412059770095681536",
  "geo" : { },
  "id_str" : "412060000455245824",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d http:\/\/t.co\/eoGA058gRs based on dark sky. It\u2019s the best, aggregates tons of sources together",
  "id" : 412060000455245824,
  "in_reply_to_status_id" : 412059770095681536,
  "created_at" : "2013-12-15 03:22:14 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412059604282277888",
  "geo" : { },
  "id_str" : "412059683185127424",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss gross. I love seasons.",
  "id" : 412059683185127424,
  "in_reply_to_status_id" : 412059604282277888,
  "created_at" : "2013-12-15 03:20:58 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/412059435486289921\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/RIGlBiHXEz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbft34mCUAAXJci.png",
      "id_str" : "412059435268198400",
      "id" : 412059435268198400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbft34mCUAAXJci.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RIGlBiHXEz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412059435486289921",
  "text" : "WINTER IS HERE http:\/\/t.co\/RIGlBiHXEz",
  "id" : 412059435486289921,
  "created_at" : "2013-12-15 03:19:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412057075460866048",
  "text" : "First shovel out of my own driveway tonight. If you\u2019re shoveling snow at all: don\u2019t forget to clear fire hydrants too. \uD83D\uDE92\uD83D\uDC4D",
  "id" : 412057075460866048,
  "created_at" : "2013-12-15 03:10:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411895585231216640",
  "geo" : { },
  "id_str" : "411895641451679745",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden dogsled.",
  "id" : 411895641451679745,
  "in_reply_to_status_id" : 411895585231216640,
  "created_at" : "2013-12-14 16:29:08 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NatashaChart",
      "screen_name" : "NatashaChart",
      "indices" : [ 0, 13 ],
      "id_str" : "11148162",
      "id" : 11148162
    }, {
      "name" : "Chris Bowers",
      "screen_name" : "ThisBowers",
      "indices" : [ 14, 25 ],
      "id_str" : "153251103",
      "id" : 153251103
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 26, 37 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411891133602856960",
  "geo" : { },
  "id_str" : "411895412975357952",
  "in_reply_to_user_id" : 11148162,
  "text" : "@NatashaChart @ThisBowers @ashedryden oooh. Good idea since we don\u2019t have snow tires for the stroller. :P",
  "id" : 411895412975357952,
  "in_reply_to_status_id" : 411891133602856960,
  "created_at" : "2013-12-14 16:28:13 +0000",
  "in_reply_to_screen_name" : "NatashaChart",
  "in_reply_to_user_id_str" : "11148162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 78, 86 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411827905401212928",
  "geo" : { },
  "id_str" : "411828304505602049",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik time to formalize a terms of usage finally (and a privacy policy) \/cc @evanphx",
  "id" : 411828304505602049,
  "in_reply_to_status_id" : 411827905401212928,
  "created_at" : "2013-12-14 12:01:33 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411825395928145920",
  "geo" : { },
  "id_str" : "411825655387402240",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik we have removed the namespaces from mass squatters like this before.",
  "id" : 411825655387402240,
  "in_reply_to_status_id" : 411825395928145920,
  "created_at" : "2013-12-14 11:51:02 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 15, 29 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411623822086123520",
  "text" : "Next pivot for @coworkbuffalo: writing children\u2019s books about coworking spaces.",
  "id" : 411623822086123520,
  "created_at" : "2013-12-13 22:29:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411287335741816832",
  "text" : "What idiot named them pack AND play\u2019s instead pack OR play\u2019s?",
  "id" : 411287335741816832,
  "created_at" : "2013-12-13 00:11:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "auntie moon",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411116885694877697",
  "geo" : { },
  "id_str" : "411118551949262848",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden agreed...and fuck hackathons.",
  "id" : 411118551949262848,
  "in_reply_to_status_id" : 411116885694877697,
  "created_at" : "2013-12-12 13:01:15 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411112996333563904",
  "geo" : { },
  "id_str" : "411116800240152576",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden yeah, we should clarify for newcomers specifically...there's no way to enforce though.",
  "id" : 411116800240152576,
  "in_reply_to_status_id" : 411112996333563904,
  "created_at" : "2013-12-12 12:54:18 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411104809140232192",
  "geo" : { },
  "id_str" : "411112158764990464",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden of course that doesn\u2019t address it fully\u2026but being a meetup, not a competition gives it an edge I feel to help more.",
  "id" : 411112158764990464,
  "in_reply_to_status_id" : 411104809140232192,
  "created_at" : "2013-12-12 12:35:51 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "auntie moon",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411104809140232192",
  "geo" : { },
  "id_str" : "411112034387132417",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden there\u2019s no requirement of performance or skills for OH. If someone is new to coding we help them get set up and started",
  "id" : 411112034387132417,
  "in_reply_to_status_id" : 411104809140232192,
  "created_at" : "2013-12-12 12:35:21 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "auntie moon",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411102765612429312",
  "geo" : { },
  "id_str" : "411104452905402369",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden I\u2019d say we don\u2019t address impostor syndrome well though.",
  "id" : 411104452905402369,
  "in_reply_to_status_id" : 411102765612429312,
  "created_at" : "2013-12-12 12:05:14 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Stef Lewandowski",
      "screen_name" : "stef",
      "indices" : [ 12, 17 ],
      "id_str" : "853471",
      "id" : 853471
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 101, 110 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411102765612429312",
  "geo" : { },
  "id_str" : "411103817590403072",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @stef this might be the piece I\u2019m missing for why hackathons suck, and we need more like @openhack.",
  "id" : 411103817590403072,
  "in_reply_to_status_id" : 411102765612429312,
  "created_at" : "2013-12-12 12:02:42 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Nakajima",
      "screen_name" : "nakajima",
      "indices" : [ 0, 9 ],
      "id_str" : "652983",
      "id" : 652983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411032383102922752",
  "geo" : { },
  "id_str" : "411077720685047808",
  "in_reply_to_user_id" : 652983,
  "text" : "@nakajima NO",
  "id" : 411077720685047808,
  "in_reply_to_status_id" : 411032383102922752,
  "created_at" : "2013-12-12 10:19:00 +0000",
  "in_reply_to_screen_name" : "nakajima",
  "in_reply_to_user_id_str" : "652983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 9, 16 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410982674577096704",
  "geo" : { },
  "id_str" : "411077124695404544",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver @sferik there were actual missionaries outside the theater when we saw it here in Buffalo. They really are owning it.",
  "id" : 411077124695404544,
  "in_reply_to_status_id" : 410982674577096704,
  "created_at" : "2013-12-12 10:16:38 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411028951201374208",
  "text" : "RT @rubygems_status: Sorry for the issues over the last few hours. `gem push` should be working again.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "411028643041640448",
    "text" : "Sorry for the issues over the last few hours. `gem push` should be working again.",
    "id" : 411028643041640448,
    "created_at" : "2013-12-12 07:03:59 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 411028951201374208,
  "created_at" : "2013-12-12 07:05:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "411025413008138241",
  "text" : "Up for a diaper change, and it seems that http:\/\/t.co\/2bA9BVLhWr needs one too. We're looking into why pushes don't work, sorry everyone.",
  "id" : 411025413008138241,
  "created_at" : "2013-12-12 06:51:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 8, 16 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 17, 28 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 29, 41 ],
      "id_str" : "19627341",
      "id" : 19627341
    }, {
      "name" : "Luke Chadwick",
      "screen_name" : "vertis",
      "indices" : [ 42, 49 ],
      "id_str" : "18786379",
      "id" : 18786379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411023513483374592",
  "geo" : { },
  "id_str" : "411024430240772096",
  "in_reply_to_user_id" : 5743852,
  "text" : "@sferik @evanphx @samkottler @dwradcliffe @vertis saw this alert in my email: description: [Triggered] Low disk space on rubygems app01",
  "id" : 411024430240772096,
  "in_reply_to_status_id" : 411023513483374592,
  "created_at" : "2013-12-12 06:47:15 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 8, 16 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 65, 76 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 77, 89 ],
      "id_str" : "19627341",
      "id" : 19627341
    }, {
      "name" : "Luke Chadwick",
      "screen_name" : "vertis",
      "indices" : [ 90, 97 ],
      "id_str" : "18786379",
      "id" : 18786379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411017642158616576",
  "geo" : { },
  "id_str" : "411023513483374592",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik @evanphx does new relic day anything? Can we revert? \/cc @samkottler @dwradcliffe @vertis",
  "id" : 411023513483374592,
  "in_reply_to_status_id" : 411017642158616576,
  "created_at" : "2013-12-12 06:43:36 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410945978125283328",
  "geo" : { },
  "id_str" : "410946619866378240",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo you need some more friends",
  "id" : 410946619866378240,
  "in_reply_to_status_id" : 410945978125283328,
  "created_at" : "2013-12-12 01:38:03 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Handsome",
      "screen_name" : "Millennial_Dave",
      "indices" : [ 0, 16 ],
      "id_str" : "60185021",
      "id" : 60185021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410888547877408769",
  "geo" : { },
  "id_str" : "410888737514483712",
  "in_reply_to_user_id" : 60185021,
  "text" : "@Millennial_Dave i still measure batteries for devices by how many game boys it could power.",
  "id" : 410888737514483712,
  "in_reply_to_status_id" : 410888547877408769,
  "created_at" : "2013-12-11 21:48:03 +0000",
  "in_reply_to_screen_name" : "Millennial_Dave",
  "in_reply_to_user_id_str" : "60185021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 13, 26 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410827531214811136",
  "text" : "@juliepagano @steveklabnik literal LOL at \"Minimum Viable Sex\"",
  "id" : 410827531214811136,
  "created_at" : "2013-12-11 17:44:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/veijE6YyfL",
      "expanded_url" : "http:\/\/valleywag.gawker.com\/happy-holidays-startup-ceo-complains-sf-is-full-of-hum-1481067192",
      "display_url" : "valleywag.gawker.com\/happy-holidays\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410820151500484608",
  "text" : "\"a hackathon for hackathons, an engorged, vomiting ouroboros in reverse\" http:\/\/t.co\/veijE6YyfL",
  "id" : 410820151500484608,
  "created_at" : "2013-12-11 17:15:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 14, 25 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410787309752033282",
  "geo" : { },
  "id_str" : "410787701516816384",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @ashedryden thanks! I would appreciate it.",
  "id" : 410787701516816384,
  "in_reply_to_status_id" : 410787309752033282,
  "created_at" : "2013-12-11 15:06:34 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 20, 26 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410780583560622081",
  "text" : "Do I know anyone at @IFTTT? I have a few questions for you :)",
  "id" : 410780583560622081,
  "created_at" : "2013-12-11 14:38:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/DMqVUMJJ7Q",
      "expanded_url" : "http:\/\/www.etsy.com\/listing\/108928748\/diy-get-your-hands-dirty-letterpress",
      "display_url" : "etsy.com\/listing\/108928\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410762352682749952",
  "text" : "If you want your own DIY poster: http:\/\/t.co\/DMqVUMJJ7Q",
  "id" : 410762352682749952,
  "created_at" : "2013-12-11 13:25:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 18, 32 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/410758419746807808\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/1pqBZPCO2K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbNOmzUCUAEHLO0.jpg",
      "id_str" : "410758419537088513",
      "id" : 410758419537088513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbNOmzUCUAEHLO0.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/1pqBZPCO2K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410758419746807808",
  "text" : "First day opening @coworkbuffalo 2.0, and my favorite poster so far is finally up. http:\/\/t.co\/1pqBZPCO2K",
  "id" : 410758419746807808,
  "created_at" : "2013-12-11 13:10:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank K",
      "screen_name" : "fkumro",
      "indices" : [ 0, 7 ],
      "id_str" : "14883887",
      "id" : 14883887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/M5HcpaRXds",
      "expanded_url" : "http:\/\/shieldedparking.com",
      "display_url" : "shieldedparking.com"
    } ]
  },
  "in_reply_to_status_id_str" : "408418730318655488",
  "geo" : { },
  "id_str" : "410648687728017408",
  "in_reply_to_user_id" : 14883887,
  "text" : "@fkumro parking on Washington and St Michaels Place is $2\/day, right behind us. Several lots too closeby including http:\/\/t.co\/M5HcpaRXds",
  "id" : 410648687728017408,
  "in_reply_to_status_id" : 408418730318655488,
  "created_at" : "2013-12-11 05:54:11 +0000",
  "in_reply_to_screen_name" : "fkumro",
  "in_reply_to_user_id_str" : "14883887",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410627326418759680",
  "geo" : { },
  "id_str" : "410643768292179968",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant it\u2019s kind of the like the theme to the Fish TV show. You know, with Abe Vigoda!",
  "id" : 410643768292179968,
  "in_reply_to_status_id" : 410627326418759680,
  "created_at" : "2013-12-11 05:34:38 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/410594717899165696\/photo\/1",
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/hJ79bP5Esc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbK5uGqIIAAxSbH.png",
      "id_str" : "410594717756563456",
      "id" : 410594717756563456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbK5uGqIIAAxSbH.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hJ79bP5Esc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410594717899165696",
  "text" : "STAHP http:\/\/t.co\/hJ79bP5Esc",
  "id" : 410594717899165696,
  "created_at" : "2013-12-11 02:19:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410574885853745152",
  "geo" : { },
  "id_str" : "410575059523481600",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove On Error Resume Next",
  "id" : 410575059523481600,
  "in_reply_to_status_id" : 410574885853745152,
  "created_at" : "2013-12-11 01:01:37 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 7, 15 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410364305562161153",
  "geo" : { },
  "id_str" : "410436565567930368",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy @evanphx ugh. yanking is such a snafu",
  "id" : 410436565567930368,
  "in_reply_to_status_id" : 410364305562161153,
  "created_at" : "2013-12-10 15:51:17 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 87, 101 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410373551678439424",
  "text" : "RT @zobar2: Submitting pull requests to household objects: just another surreal day at @coworkbuffalo.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 75, 89 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410214250221555713",
    "text" : "Submitting pull requests to household objects: just another surreal day at @coworkbuffalo.",
    "id" : 410214250221555713,
    "created_at" : "2013-12-10 01:07:53 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 410373551678439424,
  "created_at" : "2013-12-10 11:40:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Mulligan",
      "screen_name" : "ryantm",
      "indices" : [ 3, 10 ],
      "id_str" : "13724812",
      "id" : 13724812
    }, {
      "name" : "Pololu",
      "screen_name" : "Pololu",
      "indices" : [ 16, 23 ],
      "id_str" : "22675870",
      "id" : 22675870
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 29, 39 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "Ruby on Rails",
      "screen_name" : "rubyonrails",
      "indices" : [ 55, 67 ],
      "id_str" : "1182391",
      "id" : 1182391
    }, {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 94, 101 ],
      "id_str" : "14432203",
      "id" : 14432203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/dUPw9PbJjI",
      "expanded_url" : "http:\/\/www.raspberrypi.org\/archives\/5398",
      "display_url" : "raspberrypi.org\/archives\/5398"
    } ]
  },
  "geo" : { },
  "id_str" : "410371337765781504",
  "text" : "RT @ryantm: We (@pololu) use @37signals' web framework @rubyonrails to sell robot parts they (@will_j) use. http:\/\/t.co\/dUPw9PbJjI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pololu",
        "screen_name" : "Pololu",
        "indices" : [ 4, 11 ],
        "id_str" : "22675870",
        "id" : 22675870
      }, {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 17, 27 ],
        "id_str" : "11132462",
        "id" : 11132462
      }, {
        "name" : "Ruby on Rails",
        "screen_name" : "rubyonrails",
        "indices" : [ 43, 55 ],
        "id_str" : "1182391",
        "id" : 1182391
      }, {
        "name" : "Will Jessop",
        "screen_name" : "will_j",
        "indices" : [ 82, 89 ],
        "id_str" : "14432203",
        "id" : 14432203
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/dUPw9PbJjI",
        "expanded_url" : "http:\/\/www.raspberrypi.org\/archives\/5398",
        "display_url" : "raspberrypi.org\/archives\/5398"
      } ]
    },
    "geo" : { },
    "id_str" : "410297996278915073",
    "text" : "We (@pololu) use @37signals' web framework @rubyonrails to sell robot parts they (@will_j) use. http:\/\/t.co\/dUPw9PbJjI",
    "id" : 410297996278915073,
    "created_at" : "2013-12-10 06:40:39 +0000",
    "user" : {
      "name" : "Ryan Mulligan",
      "screen_name" : "ryantm",
      "protected" : false,
      "id_str" : "13724812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1590306370\/Untitled_normal.png",
      "id" : 13724812,
      "verified" : false
    }
  },
  "id" : 410371337765781504,
  "created_at" : "2013-12-10 11:32:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410237043260657665",
  "geo" : { },
  "id_str" : "410239916258234368",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej they used to do this with elephants.",
  "id" : 410239916258234368,
  "in_reply_to_status_id" : 410237043260657665,
  "created_at" : "2013-12-10 02:49:52 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rust Belt Hipster",
      "screen_name" : "Buffalo_Hipster",
      "indices" : [ 3, 19 ],
      "id_str" : "547376889",
      "id" : 547376889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410211854628057088",
  "text" : "RT @Buffalo_Hipster: Still upset the Co-op doesn't accept Bitcoin.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410209371487215616",
    "text" : "Still upset the Co-op doesn't accept Bitcoin.",
    "id" : 410209371487215616,
    "created_at" : "2013-12-10 00:48:30 +0000",
    "user" : {
      "name" : "Rust Belt Hipster",
      "screen_name" : "Buffalo_Hipster",
      "protected" : false,
      "id_str" : "547376889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2055610413\/centterm2_normal.jpg",
      "id" : 547376889,
      "verified" : false
    }
  },
  "id" : 410211854628057088,
  "created_at" : "2013-12-10 00:58:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410194544597024768",
  "text" : "Took the turn and I smelt burnt rubber, and as they squeezed onto Bidwell the back car almost got into an accident. WTF.",
  "id" : 410194544597024768,
  "created_at" : "2013-12-09 23:49:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410194427240390656",
  "text" : "On the wrong side of the road, too. Front car turned his lights off, I completely froze as they barreled at me.",
  "id" : 410194427240390656,
  "created_at" : "2013-12-09 23:49:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410194316460433408",
  "text" : "Well that was terrifying. Walked down Dorchester with the dog, 2 cars swung out from Richmond speeding at me.",
  "id" : 410194316460433408,
  "created_at" : "2013-12-09 23:48:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Howell",
      "screen_name" : "mxcl",
      "indices" : [ 0, 5 ],
      "id_str" : "3374231",
      "id" : 3374231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410145875789631488",
  "geo" : { },
  "id_str" : "410150289987993600",
  "in_reply_to_user_id" : 3374231,
  "text" : "@mxcl I love it, use it for Basecamp for iPhone in some places, and the VFL is great. Not right for everything but it's good!",
  "id" : 410150289987993600,
  "in_reply_to_status_id" : 410145875789631488,
  "created_at" : "2013-12-09 20:53:44 +0000",
  "in_reply_to_screen_name" : "mxcl",
  "in_reply_to_user_id_str" : "3374231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike susz",
      "screen_name" : "mikesusz",
      "indices" : [ 0, 9 ],
      "id_str" : "14531472",
      "id" : 14531472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/5YUwQb4X28",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/newsletter\/2013\/10\/21\/hey-coworkbuffalo-has-some-pretty-big-news.html",
      "display_url" : "coworkbuffalo.com\/newsletter\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "410087140094394368",
  "geo" : { },
  "id_str" : "410090231807754240",
  "in_reply_to_user_id" : 14531472,
  "text" : "@mikesusz yep! http:\/\/t.co\/5YUwQb4X28",
  "id" : 410090231807754240,
  "in_reply_to_status_id" : 410087140094394368,
  "created_at" : "2013-12-09 16:55:05 +0000",
  "in_reply_to_screen_name" : "mikesusz",
  "in_reply_to_user_id_str" : "14531472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410087140576722945",
  "geo" : { },
  "id_str" : "410090135435231232",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr I asked for 4.",
  "id" : 410090135435231232,
  "in_reply_to_status_id" : 410087140576722945,
  "created_at" : "2013-12-09 16:54:42 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 45, 55 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 76, 90 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/410084672488882176\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/g1dzZVz9bJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbDp1i9IYAEGJ8h.jpg",
      "id_str" : "410084672216260609",
      "id" : 410084672216260609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbDp1i9IYAEGJ8h.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/g1dzZVz9bJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410084672488882176",
  "text" : "Big week: Back from paternity leave, 2 years @37signals, and a new view for @coworkbuffalo! http:\/\/t.co\/g1dzZVz9bJ",
  "id" : 410084672488882176,
  "created_at" : "2013-12-09 16:32:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409892750524293120",
  "text" : "Snippet of an email I just sent: \"Given I'm going to be continually purchasing things until I die...\"",
  "id" : 409892750524293120,
  "created_at" : "2013-12-09 03:50:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409878817994309632",
  "geo" : { },
  "id_str" : "409886702853828608",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh 5C over here works great on pin unlock, every time :)",
  "id" : 409886702853828608,
  "in_reply_to_status_id" : 409878817994309632,
  "created_at" : "2013-12-09 03:26:19 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409753793119535104",
  "text" : "Setting up Amazon Payments has been the absolute worst payment gateway experience.",
  "id" : 409753793119535104,
  "created_at" : "2013-12-08 18:38:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409495579354333184",
  "text" : "RT @aquaranto: The only appropriate emoji depicting \"pumping\" in our baby log: \uD83D\uDC04",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409494916624969728",
    "text" : "The only appropriate emoji depicting \"pumping\" in our baby log: \uD83D\uDC04",
    "id" : 409494916624969728,
    "created_at" : "2013-12-08 01:29:30 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 409495579354333184,
  "created_at" : "2013-12-08 01:32:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409493291395067905",
  "text" : "Finally got huge cube ice trays, celebrating with a White Russian. \uD83C\uDFB3",
  "id" : 409493291395067905,
  "created_at" : "2013-12-08 01:23:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/RbwuPuLDrb",
      "expanded_url" : "http:\/\/i.imgur.com\/VsAzNDn.jpg",
      "display_url" : "i.imgur.com\/VsAzNDn.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "409486790798483456",
  "text" : "The Dad Test: http:\/\/t.co\/RbwuPuLDrb",
  "id" : 409486790798483456,
  "created_at" : "2013-12-08 00:57:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/YWI3f5UOVB",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/7851145",
      "display_url" : "gist.github.com\/qrush\/7851145"
    } ]
  },
  "geo" : { },
  "id_str" : "409461872765571073",
  "text" : "What killed the dinosaurs? THE ICE AGE! https:\/\/t.co\/YWI3f5UOVB",
  "id" : 409461872765571073,
  "created_at" : "2013-12-07 23:18:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    }, {
      "name" : "Xavier Noria",
      "screen_name" : "fxn",
      "indices" : [ 5, 9 ],
      "id_str" : "11253302",
      "id" : 11253302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/YWI3f5UOVB",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/7851145",
      "display_url" : "gist.github.com\/qrush\/7851145"
    } ]
  },
  "in_reply_to_status_id_str" : "409460996491988992",
  "geo" : { },
  "id_str" : "409461685032742912",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz @fxn ALLOW ME TO BREAK THE ICE https:\/\/t.co\/YWI3f5UOVB",
  "id" : 409461685032742912,
  "in_reply_to_status_id" : 409460996491988992,
  "created_at" : "2013-12-07 23:17:27 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    }, {
      "name" : "Xavier Noria",
      "screen_name" : "fxn",
      "indices" : [ 5, 9 ],
      "id_str" : "11253302",
      "id" : 11253302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409460069726560256",
  "geo" : { },
  "id_str" : "409460550926471169",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz @fxn why stop there? \u2744\uFE0Efoo\u2744\uFE0E \u2745bar\u2745 \u2746baz\u2746",
  "id" : 409460550926471169,
  "in_reply_to_status_id" : 409460069726560256,
  "created_at" : "2013-12-07 23:12:57 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Severini",
      "screen_name" : "luckiestmonkey",
      "indices" : [ 0, 15 ],
      "id_str" : "7141792",
      "id" : 7141792
    }, {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 16, 27 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409456355464851456",
  "geo" : { },
  "id_str" : "409458365920591872",
  "in_reply_to_user_id" : 7141792,
  "text" : "@luckiestmonkey @joshsusser but will it blend?",
  "id" : 409458365920591872,
  "in_reply_to_status_id" : 409456355464851456,
  "created_at" : "2013-12-07 23:04:16 +0000",
  "in_reply_to_screen_name" : "luckiestmonkey",
  "in_reply_to_user_id_str" : "7141792",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alberto grespan",
      "screen_name" : "albertogg",
      "indices" : [ 0, 10 ],
      "id_str" : "57244212",
      "id" : 57244212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/eYCiYX9t49",
      "expanded_url" : "http:\/\/quaran.to\/signal",
      "display_url" : "quaran.to\/signal"
    } ]
  },
  "in_reply_to_status_id_str" : "409435568385568768",
  "geo" : { },
  "id_str" : "409442573766656000",
  "in_reply_to_user_id" : 57244212,
  "text" : "@albertogg I sent this: http:\/\/t.co\/eYCiYX9t49",
  "id" : 409442573766656000,
  "in_reply_to_status_id" : 409435568385568768,
  "created_at" : "2013-12-07 22:01:31 +0000",
  "in_reply_to_screen_name" : "albertogg",
  "in_reply_to_user_id_str" : "57244212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409242455809089536",
  "geo" : { },
  "id_str" : "409245905041104896",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc 9 people?!? Funny how there\u2019s no mention of the terrible platform choices they made. Also lol at blaming a major game launch.",
  "id" : 409245905041104896,
  "in_reply_to_status_id" : 409242455809089536,
  "created_at" : "2013-12-07 09:00:01 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sela Davis",
      "screen_name" : "sela_davis",
      "indices" : [ 0, 11 ],
      "id_str" : "7488582",
      "id" : 7488582
    }, {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 93, 106 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409199599090282496",
  "geo" : { },
  "id_str" : "409199991421698048",
  "in_reply_to_user_id" : 7488582,
  "text" : "@sela_davis herp derp. Now I want a sub. Or a plate, but not intoxicated enough to forget it @codemastermm",
  "id" : 409199991421698048,
  "in_reply_to_status_id" : 409199599090282496,
  "created_at" : "2013-12-07 05:57:35 +0000",
  "in_reply_to_screen_name" : "sela_davis",
  "in_reply_to_user_id_str" : "7488582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sela Davis",
      "screen_name" : "sela_davis",
      "indices" : [ 0, 11 ],
      "id_str" : "7488582",
      "id" : 7488582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409191104207011840",
  "geo" : { },
  "id_str" : "409199095396306944",
  "in_reply_to_user_id" : 7488582,
  "text" : "@sela_davis didn't know you're from WNY! Welcome back and I hope Jim's Regret doesn't haunt you.",
  "id" : 409199095396306944,
  "in_reply_to_status_id" : 409191104207011840,
  "created_at" : "2013-12-07 05:54:01 +0000",
  "in_reply_to_screen_name" : "sela_davis",
  "in_reply_to_user_id_str" : "7488582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409198377008525314",
  "text" : "@juliepagano yeah it's a huge shift in time and energy. Glad you realize this, most don't. \uD83D\uDE15",
  "id" : 409198377008525314,
  "created_at" : "2013-12-07 05:51:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 14, 26 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409196697311801345",
  "geo" : { },
  "id_str" : "409198103896793089",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda @juliepagano how about a fleet of quadcopters hovering 3' overhead. They could be named the Nopecopters\u2122",
  "id" : 409198103896793089,
  "in_reply_to_status_id" : 409196697311801345,
  "created_at" : "2013-12-07 05:50:05 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409196491249422336",
  "text" : "@juliepagano sraly though, getting a dog completely changed how I viewed late night (and anytime) walks. Draws attention but differently.",
  "id" : 409196491249422336,
  "created_at" : "2013-12-07 05:43:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409196156456280065",
  "text" : "@juliepagano :( how about 1) a puppy 2) attack drones or 3) puppy attack drones",
  "id" : 409196156456280065,
  "created_at" : "2013-12-07 05:42:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409125714164989952",
  "geo" : { },
  "id_str" : "409136184195952640",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius password, phone authentication, and a sphinx riddle",
  "id" : 409136184195952640,
  "in_reply_to_status_id" : 409125714164989952,
  "created_at" : "2013-12-07 01:44:02 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409116615574577152",
  "text" : "Angry Orchard Cinnful Apple. Get you some. \uD83C\uDF4E\uD83C\uDF7A\uD83D\uDC4C",
  "id" : 409116615574577152,
  "created_at" : "2013-12-07 00:26:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "coffee dad",
      "screen_name" : "coffee_dad",
      "indices" : [ 3, 14 ],
      "id_str" : "510770821",
      "id" : 510770821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409099834336219136",
  "text" : "RT @coffee_dad: thankful for coffee#",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409099370777554944",
    "text" : "thankful for coffee#",
    "id" : 409099370777554944,
    "created_at" : "2013-12-06 23:17:45 +0000",
    "user" : {
      "name" : "coffee dad",
      "screen_name" : "coffee_dad",
      "protected" : false,
      "id_str" : "510770821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000823347939\/036f78135425d19367fcbb76ef58e86d_normal.jpeg",
      "id" : 510770821,
      "verified" : false
    }
  },
  "id" : 409099834336219136,
  "created_at" : "2013-12-06 23:19:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 0, 4 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409095709866983424",
  "geo" : { },
  "id_str" : "409097070943797248",
  "in_reply_to_user_id" : 10079052,
  "text" : "@rjs game consoles? Not sure what you're missing",
  "id" : 409097070943797248,
  "in_reply_to_status_id" : 409095709866983424,
  "created_at" : "2013-12-06 23:08:37 +0000",
  "in_reply_to_screen_name" : "rjs",
  "in_reply_to_user_id_str" : "10079052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/avxC0hxffc",
      "expanded_url" : "https:\/\/s3.amazonaws.com\/s3.documentcloud.org\/documents\/885843\/banks-research-report-on-bitcoin.pdf",
      "display_url" : "s3.amazonaws.com\/s3.documentclo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408901199195148288",
  "text" : "A good explanation and analysis into the Bitcoin hype, explaining what it is, advantages\/disadvantages: https:\/\/t.co\/avxC0hxffc",
  "id" : 408901199195148288,
  "created_at" : "2013-12-06 10:10:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan Storck",
      "screen_name" : "ivanoats",
      "indices" : [ 0, 9 ],
      "id_str" : "13337",
      "id" : 13337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408852260551028736",
  "geo" : { },
  "id_str" : "408852474158911488",
  "in_reply_to_user_id" : 13337,
  "text" : "@ivanoats works on mobile ;(",
  "id" : 408852474158911488,
  "in_reply_to_status_id" : 408852260551028736,
  "created_at" : "2013-12-06 06:56:40 +0000",
  "in_reply_to_screen_name" : "ivanoats",
  "in_reply_to_user_id_str" : "13337",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 9, 15 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/xR5FYR1m7h",
      "expanded_url" : "https:\/\/www.amazon.com\/gp\/dmusic\/device\/mp3\/store\/album\/B007J7LJYI\/highlight:B007J7LKCE?ie=UTF8",
      "display_url" : "amazon.com\/gp\/dmusic\/devi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408851617489121280",
  "text" : "Amazing, @phish lullaby covers: https:\/\/t.co\/xR5FYR1m7h",
  "id" : 408851617489121280,
  "created_at" : "2013-12-06 06:53:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 8, 18 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408637581325119488",
  "geo" : { },
  "id_str" : "408850368966053888",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 @aquaranto YES",
  "id" : 408850368966053888,
  "in_reply_to_status_id" : 408637581325119488,
  "created_at" : "2013-12-06 06:48:18 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "NPR News",
      "screen_name" : "nprnews",
      "indices" : [ 90, 98 ],
      "id_str" : "5392522",
      "id" : 5392522
    }, {
      "name" : "Gene Demby",
      "screen_name" : "GeeDee215",
      "indices" : [ 132, 140 ],
      "id_str" : "87359651",
      "id" : 87359651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/TLwCW765l2",
      "expanded_url" : "http:\/\/n.pr\/18n3S3k",
      "display_url" : "n.pr\/18n3S3k"
    } ]
  },
  "geo" : { },
  "id_str" : "408847095446007808",
  "text" : "RT @ashedryden: My post about the ethics of unpaid labor and open source was picked up by @nprnews:  http:\/\/t.co\/TLwCW765l2 thanks, @GeeDee\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NPR News",
        "screen_name" : "nprnews",
        "indices" : [ 74, 82 ],
        "id_str" : "5392522",
        "id" : 5392522
      }, {
        "name" : "Gene Demby",
        "screen_name" : "GeeDee215",
        "indices" : [ 116, 126 ],
        "id_str" : "87359651",
        "id" : 87359651
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/TLwCW765l2",
        "expanded_url" : "http:\/\/n.pr\/18n3S3k",
        "display_url" : "n.pr\/18n3S3k"
      } ]
    },
    "geo" : { },
    "id_str" : "408844645989642240",
    "text" : "My post about the ethics of unpaid labor and open source was picked up by @nprnews:  http:\/\/t.co\/TLwCW765l2 thanks, @GeeDee215!",
    "id" : 408844645989642240,
    "created_at" : "2013-12-06 06:25:34 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 408847095446007808,
  "created_at" : "2013-12-06 06:35:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 0, 12 ],
      "id_str" : "19627341",
      "id" : 19627341
    }, {
      "name" : "Daniel McOrmond",
      "screen_name" : "DanielMcOrmond",
      "indices" : [ 13, 28 ],
      "id_str" : "17237976",
      "id" : 17237976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408711892132036608",
  "geo" : { },
  "id_str" : "408712043454144513",
  "in_reply_to_user_id" : 19627341,
  "text" : "@dwradcliffe @DanielMcOrmond Sneaky.",
  "id" : 408712043454144513,
  "in_reply_to_status_id" : 408711892132036608,
  "created_at" : "2013-12-05 21:38:39 +0000",
  "in_reply_to_screen_name" : "dwradcliffe",
  "in_reply_to_user_id_str" : "19627341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 3, 15 ],
      "id_str" : "19627341",
      "id" : 19627341
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 17, 23 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408711972369100801",
  "text" : "RT @dwradcliffe: @qrush Good to know. Square probably wants the interest on those few days.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "408711571683020800",
    "geo" : { },
    "id_str" : "408711892132036608",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush Good to know. Square probably wants the interest on those few days.",
    "id" : 408711892132036608,
    "in_reply_to_status_id" : 408711571683020800,
    "created_at" : "2013-12-05 21:38:03 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "protected" : false,
      "id_str" : "19627341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3211374432\/0142a899989e313aa8401455e74a50da_normal.png",
      "id" : 19627341,
      "verified" : false
    }
  },
  "id" : 408711972369100801,
  "created_at" : "2013-12-05 21:38:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408711571683020800",
  "text" : "Just a heads up Square Cash users: once you send cash, it comes out of your account *instantly*, not when the receiver accepts it.",
  "id" : 408711571683020800,
  "created_at" : "2013-12-05 21:36:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Block Club",
      "screen_name" : "BlockClub",
      "indices" : [ 1, 11 ],
      "id_str" : "21003240",
      "id" : 21003240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/6RCnCb2z6y",
      "expanded_url" : "http:\/\/www.wherelifeworks.com\/",
      "display_url" : "wherelifeworks.com"
    } ]
  },
  "geo" : { },
  "id_str" : "408415280919232512",
  "text" : ".@BlockClub continues to kill it with designing great resources for people who want to move to Buffalo: http:\/\/t.co\/6RCnCb2z6y",
  "id" : 408415280919232512,
  "created_at" : "2013-12-05 01:59:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/aLPdxBhCyi",
      "expanded_url" : "https:\/\/twitter.com\/evanphx\/status\/408325154532372480",
      "display_url" : "twitter.com\/evanphx\/status\u2026"
    }, {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/xQmnQXwiTY",
      "expanded_url" : "https:\/\/twitter.com\/evanphx\/status\/408327183933779968",
      "display_url" : "twitter.com\/evanphx\/status\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "408400799874568192",
  "geo" : { },
  "id_str" : "408401718901501952",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr you're missing some context: https:\/\/t.co\/aLPdxBhCyi https:\/\/t.co\/xQmnQXwiTY",
  "id" : 408401718901501952,
  "in_reply_to_status_id" : 408400799874568192,
  "created_at" : "2013-12-05 01:05:32 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408253353076875265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9373725217, -78.8810276834 ]
  },
  "id_str" : "408400819118415872",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape babby.",
  "id" : 408400819118415872,
  "in_reply_to_status_id" : 408253353076875265,
  "created_at" : "2013-12-05 01:01:57 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408400207018471424",
  "geo" : { },
  "id_str" : "408400753557245952",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss Ruby Central!",
  "id" : 408400753557245952,
  "in_reply_to_status_id" : 408400207018471424,
  "created_at" : "2013-12-05 01:01:42 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "408394901781364736",
  "text" : "Crazy: when we switched over the billing for http:\/\/t.co\/2bA9BVLhWr to Ruby Central, the AWS bill was $452.68.",
  "id" : 408394901781364736,
  "created_at" : "2013-12-05 00:38:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408393679636688896",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx It could also highlight who gives us free service (and be a general page to point people at when they ask how to help)",
  "id" : 408393679636688896,
  "created_at" : "2013-12-05 00:33:35 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/LwpxDpkV8Z",
      "expanded_url" : "http:\/\/money.rubygems.org",
      "display_url" : "money.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "408393596505583616",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx +1 for transparency! maybe we should just keep a simple list of monthly costs for posterity's sake? http:\/\/t.co\/LwpxDpkV8Z ?",
  "id" : 408393596505583616,
  "created_at" : "2013-12-05 00:33:15 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 3, 11 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/ykvP3ygW9p",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "408393244494401536",
  "text" : "RT @evanphx: In case anyone is curious: The http:\/\/t.co\/ykvP3ygW9p bill for November was $5,733.36.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/ykvP3ygW9p",
        "expanded_url" : "http:\/\/rubygems.org",
        "display_url" : "rubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "408325154532372480",
    "text" : "In case anyone is curious: The http:\/\/t.co\/ykvP3ygW9p bill for November was $5,733.36.",
    "id" : 408325154532372480,
    "created_at" : "2013-12-04 20:01:17 +0000",
    "user" : {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "protected" : false,
      "id_str" : "5444392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500424848519077892\/9BhPED16_normal.jpeg",
      "id" : 5444392,
      "verified" : false
    }
  },
  "id" : 408393244494401536,
  "created_at" : "2013-12-05 00:31:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    }, {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 8, 20 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408370020729634816",
  "geo" : { },
  "id_str" : "408370336946995200",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman @SaraJChipps \uD83D\uDC3D",
  "id" : 408370336946995200,
  "in_reply_to_status_id" : 408370020729634816,
  "created_at" : "2013-12-04 23:00:50 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408359774816702464",
  "geo" : { },
  "id_str" : "408360021513478144",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn not open yet!",
  "id" : 408360021513478144,
  "in_reply_to_status_id" : 408359774816702464,
  "created_at" : "2013-12-04 22:19:50 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 27, 41 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408359371794829312",
  "text" : "Yet another reason to be a @coworkbuffalo member: Dino BBQ. One. Block. Away. \uD83C\uDF0B",
  "id" : 408359371794829312,
  "created_at" : "2013-12-04 22:17:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 12, 23 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 69, 83 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408351752959041536",
  "geo" : { },
  "id_str" : "408352346713112576",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin @kevinpurdy just signed up! You'll have to check the new @coworkbuffalo digs next time you're in town.",
  "id" : 408352346713112576,
  "in_reply_to_status_id" : 408351752959041536,
  "created_at" : "2013-12-04 21:49:20 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 53, 64 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408351586340315136",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin hey are you going to be in town too? \/cc @kevinpurdy",
  "id" : 408351586340315136,
  "created_at" : "2013-12-04 21:46:19 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth Godin",
      "screen_name" : "ThisIsSethsBlog",
      "indices" : [ 1, 17 ],
      "id_str" : "17825445",
      "id" : 17825445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/Hs5ilUg5ke",
      "expanded_url" : "https:\/\/www.eventbrite.com\/e\/z80-labs-feeding-innovation-series-qa-with-seth-godin-and-jordan-levy-tickets-5940860273",
      "display_url" : "eventbrite.com\/e\/z80-labs-fee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408351426411495424",
  "text" : ",@ThisIsSethsBlog is coming to Buffalo to speak on 12\/17! Join me there: https:\/\/t.co\/Hs5ilUg5ke",
  "id" : 408351426411495424,
  "created_at" : "2013-12-04 21:45:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 41, 53 ],
      "id_str" : "6707392",
      "id" : 6707392
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 75, 85 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408320769211371520",
  "text" : "RT @dhh: It's been an honor to work with @sstephenson for the past 8 years @37signals. Today is his anniversary with the company. To anothe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Stephenson",
        "screen_name" : "sstephenson",
        "indices" : [ 32, 44 ],
        "id_str" : "6707392",
        "id" : 6707392
      }, {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 66, 76 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408263809183137792",
    "text" : "It's been an honor to work with @sstephenson for the past 8 years @37signals. Today is his anniversary with the company. To another 8+8+8!",
    "id" : 408263809183137792,
    "created_at" : "2013-12-04 15:57:31 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 408320769211371520,
  "created_at" : "2013-12-04 19:43:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 3, 12 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/mw3G64KywL",
      "expanded_url" : "https:\/\/github.com\/37signals\/concerning",
      "display_url" : "github.com\/37signals\/conc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408314717707698176",
  "text" : "RT @bitsweat: One weird trick to split up monolithic Ruby classes, discovered by stay-at-home programmer https:\/\/t.co\/mw3G64KywL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/mw3G64KywL",
        "expanded_url" : "https:\/\/github.com\/37signals\/concerning",
        "display_url" : "github.com\/37signals\/conc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "408309700778655744",
    "text" : "One weird trick to split up monolithic Ruby classes, discovered by stay-at-home programmer https:\/\/t.co\/mw3G64KywL",
    "id" : 408309700778655744,
    "created_at" : "2013-12-04 18:59:53 +0000",
    "user" : {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "protected" : false,
      "id_str" : "9462972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510089088129458177\/L_F1zcVv_normal.png",
      "id" : 9462972,
      "verified" : false
    }
  },
  "id" : 408314717707698176,
  "created_at" : "2013-12-04 19:19:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408203443393036288",
  "text" : "\"As an online discussion grows longer, the probability of a comparison involving Bitcoin approaches 1.\"",
  "id" : 408203443393036288,
  "created_at" : "2013-12-04 11:57:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 31, 43 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408012489667129344",
  "text" : "It had to happen: baby's first @whereslloyd taco run!! Only took 3 weeks.",
  "id" : 408012489667129344,
  "created_at" : "2013-12-03 23:18:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408001274916130816",
  "geo" : { },
  "id_str" : "408002015525343232",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 you could park and ride it",
  "id" : 408002015525343232,
  "in_reply_to_status_id" : 408001274916130816,
  "created_at" : "2013-12-03 22:37:15 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407998823186055168",
  "geo" : { },
  "id_str" : "408000189299834880",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 Oof. What street?",
  "id" : 408000189299834880,
  "in_reply_to_status_id" : 407998823186055168,
  "created_at" : "2013-12-03 22:30:00 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Donohoe",
      "screen_name" : "atmos",
      "indices" : [ 0, 6 ],
      "id_str" : "1438261",
      "id" : 1438261
    }, {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 7, 13 ],
      "id_str" : "10403812",
      "id" : 10403812
    }, {
      "name" : "Charlie Somerville",
      "screen_name" : "charliesome",
      "indices" : [ 14, 26 ],
      "id_str" : "16142240",
      "id" : 16142240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407996969018077184",
  "geo" : { },
  "id_str" : "407997294836199424",
  "in_reply_to_user_id" : 1438261,
  "text" : "@atmos @wfarr @charliesome \uD83D\uDE10",
  "id" : 407997294836199424,
  "in_reply_to_status_id" : 407996969018077184,
  "created_at" : "2013-12-03 22:18:29 +0000",
  "in_reply_to_screen_name" : "atmos",
  "in_reply_to_user_id_str" : "1438261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Roselli",
      "screen_name" : "aardrian",
      "indices" : [ 0, 9 ],
      "id_str" : "16515870",
      "id" : 16515870
    }, {
      "name" : "asbuffalo",
      "screen_name" : "asbuffalo",
      "indices" : [ 10, 20 ],
      "id_str" : "3032011745",
      "id" : 3032011745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407972479576326144",
  "geo" : { },
  "id_str" : "407974120303755264",
  "in_reply_to_user_id" : 16515870,
  "text" : "@aardrian @ASBuffalo that's a long time for a server to cycle...",
  "id" : 407974120303755264,
  "in_reply_to_status_id" : 407972479576326144,
  "created_at" : "2013-12-03 20:46:24 +0000",
  "in_reply_to_screen_name" : "aardrian",
  "in_reply_to_user_id_str" : "16515870",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407968727510958080",
  "text" : "THANKS OBAMA",
  "id" : 407968727510958080,
  "created_at" : "2013-12-03 20:24:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407968160554299392",
  "text" : "lol at the password: ILuv3Y@nk33s",
  "id" : 407968160554299392,
  "created_at" : "2013-12-03 20:22:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asbuffalo",
      "screen_name" : "asbuffalo",
      "indices" : [ 4, 14 ],
      "id_str" : "3032011745",
      "id" : 3032011745
    }, {
      "name" : "Adrian Roselli",
      "screen_name" : "aardrian",
      "indices" : [ 15, 24 ],
      "id_str" : "16515870",
      "id" : 16515870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/uwfLeiiqYz",
      "expanded_url" : "http:\/\/www.buffalowaterauthority.com\/",
      "display_url" : "buffalowaterauthority.com"
    } ]
  },
  "geo" : { },
  "id_str" : "407967632160079872",
  "text" : "Hey @ASBuffalo @aardrian http:\/\/t.co\/uwfLeiiqYz is mega broken, showing database passwords and more...",
  "id" : 407967632160079872,
  "created_at" : "2013-12-03 20:20:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407957762509778944",
  "text" : "3 weeks today, and first successful MamaRoo nap. Full power, car ride, white noise blasting from an iOS app. \uD83D\uDE24",
  "id" : 407957762509778944,
  "created_at" : "2013-12-03 19:41:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Handsome",
      "screen_name" : "Millennial_Dave",
      "indices" : [ 0, 16 ],
      "id_str" : "60185021",
      "id" : 60185021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407907815068413952",
  "geo" : { },
  "id_str" : "407931583811690496",
  "in_reply_to_user_id" : 60185021,
  "text" : "@Millennial_Dave still do! He's my boss.",
  "id" : 407931583811690496,
  "in_reply_to_status_id" : 407907815068413952,
  "created_at" : "2013-12-03 17:57:23 +0000",
  "in_reply_to_screen_name" : "Millennial_Dave",
  "in_reply_to_user_id_str" : "60185021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Handsome",
      "screen_name" : "Millennial_Dave",
      "indices" : [ 0, 16 ],
      "id_str" : "60185021",
      "id" : 60185021
    }, {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 17, 24 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/6dtmO7lT0z",
      "expanded_url" : "http:\/\/developer.ubuntu.com\/resources\/programming-languages\/c-sharp\/",
      "display_url" : "developer.ubuntu.com\/resources\/prog\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "407864877269516288",
  "geo" : { },
  "id_str" : "407875850948718592",
  "in_reply_to_user_id" : 60185021,
  "text" : "@Millennial_Dave @zobar2 definitely does! Most of ubuntu's stuff is in Mono http:\/\/t.co\/6dtmO7lT0z",
  "id" : 407875850948718592,
  "in_reply_to_status_id" : 407864877269516288,
  "created_at" : "2013-12-03 14:15:55 +0000",
  "in_reply_to_screen_name" : "Millennial_Dave",
  "in_reply_to_user_id_str" : "60185021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 13, 27 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407852207837413376",
  "text" : "First day of @coworkbuffalo on Main Street today. Still hard to believe it's real!",
  "id" : 407852207837413376,
  "created_at" : "2013-12-03 12:41:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407739012888006657",
  "text" : "Little guy has been asleep for over 3 hours, and my brain is too full of IFTTT, Twilio, and Heroku schemes to sleep.",
  "id" : 407739012888006657,
  "created_at" : "2013-12-03 05:12:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yannick \u2603 Schutz",
      "screen_name" : "yann_ck",
      "indices" : [ 0, 8 ],
      "id_str" : "14835545",
      "id" : 14835545
    }, {
      "name" : "Smallnest",
      "screen_name" : "smallnestinc",
      "indices" : [ 9, 22 ],
      "id_str" : "511486386",
      "id" : 511486386
    }, {
      "name" : "Simon",
      "screen_name" : "Cimm",
      "indices" : [ 23, 28 ],
      "id_str" : "2561501",
      "id" : 2561501
    }, {
      "name" : "Steve Verlinden",
      "screen_name" : "verlinden",
      "indices" : [ 29, 39 ],
      "id_str" : "14843242",
      "id" : 14843242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/X6rgMFpa0N",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2013\/11\/23\/sync-and-edit-files-on-two-iphones",
      "display_url" : "quaran.to\/blog\/2013\/11\/2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "407527844613738496",
  "geo" : { },
  "id_str" : "407686043240890368",
  "in_reply_to_user_id" : 14835545,
  "text" : "@yann_ck @smallnestinc @Cimm @verlinden this is my setup: http:\/\/t.co\/X6rgMFpa0N",
  "id" : 407686043240890368,
  "in_reply_to_status_id" : 407527844613738496,
  "created_at" : "2013-12-03 01:41:41 +0000",
  "in_reply_to_screen_name" : "yann_ck",
  "in_reply_to_user_id_str" : "14835545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 0, 16 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407336509550129152",
  "geo" : { },
  "id_str" : "407337484247257089",
  "in_reply_to_user_id" : 10114802,
  "text" : "@whentheponydies holy poop. Literally.",
  "id" : 407337484247257089,
  "in_reply_to_status_id" : 407336509550129152,
  "created_at" : "2013-12-02 02:36:38 +0000",
  "in_reply_to_screen_name" : "whentheponydies",
  "in_reply_to_user_id_str" : "10114802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 3, 9 ],
      "id_str" : "1679",
      "id" : 1679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/Ny4Oypl55E",
      "expanded_url" : "https:\/\/gist.github.com\/javan\/7725255",
      "display_url" : "gist.github.com\/javan\/7725255"
    } ]
  },
  "geo" : { },
  "id_str" : "407145700435451904",
  "text" : "RT @javan: Plug leaky js requests in your Rails app: https:\/\/t.co\/Ny4Oypl55E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/Ny4Oypl55E",
        "expanded_url" : "https:\/\/gist.github.com\/javan\/7725255",
        "display_url" : "gist.github.com\/javan\/7725255"
      } ]
    },
    "geo" : { },
    "id_str" : "406907340919554048",
    "text" : "Plug leaky js requests in your Rails app: https:\/\/t.co\/Ny4Oypl55E",
    "id" : 406907340919554048,
    "created_at" : "2013-11-30 22:07:24 +0000",
    "user" : {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "protected" : false,
      "id_str" : "1679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526722729123143680\/0-ppDKP__normal.jpeg",
      "id" : 1679,
      "verified" : false
    }
  },
  "id" : 407145700435451904,
  "created_at" : "2013-12-01 13:54:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]